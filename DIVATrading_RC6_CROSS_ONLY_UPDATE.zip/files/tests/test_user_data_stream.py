from __future__ import annotations

import asyncio
import json
import time
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from divatrading.execution.account_runtime import AccountRuntimeConfig, ExecutionAccountRuntime
from divatrading.execution.account_state import BinanceAccountStateService
from divatrading.execution.binance_private import BinancePrivateRestClient
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.reconciliation import AccountReconciliationService
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.execution.user_data_stream import (
    BinanceUserDataStreamSupervisor, UserDataStreamConfig, UserDataStreamProcessor,
)
from divatrading.trading.coordinator import MultiPairExecutionCoordinator, PortfolioSnapshot
from divatrading.trading.models import QualifiedSignal
from divatrading.trading.risk import PortfolioRiskManager
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.strategy.scalping_market_data import InstrumentSpec

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def _intent_and_position(ledger: ExecutionLedger, signal_id: str = "managed-1") -> None:
    ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side="LONG",
                        client_order_id=f"DIVA-{signal_id}", payload={})
    ledger.record_position(symbol="BTCUSDT", position_side="BOTH", signal_id=signal_id,
                           quantity="0.1", entry_price="50000", stop_loss="49900",
                           take_profit="50300")


class FakeAccountClient:
    def __init__(self, *, positions=None, algo_orders=None, standard_orders=None):
        self.positions = positions if positions is not None else [{
            "symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "0.1",
            "entryPrice": "50000", "markPrice": "50100", "unRealizedProfit": "10",
            "notional": "5010", "isolated": "false",
        }]
        self.algo_orders = algo_orders if algo_orders is not None else [
            {"symbol": "BTCUSDT", "positionSide": "BOTH", "type": "STOP_MARKET",
             "side": "SELL", "algoStatus": "NEW", "closePosition": True,
             "triggerPrice": "49900", "algoId": 11},
            {"symbol": "BTCUSDT", "positionSide": "BOTH", "type": "TAKE_PROFIT_MARKET",
             "side": "SELL", "algoStatus": "NEW", "closePosition": True,
             "triggerPrice": "50300", "algoId": 12},
        ]
        self.standard_orders = standard_orders if standard_orders is not None else []

    def get_exchange_account(self):
        return {"totalWalletBalance": "1000", "totalMarginBalance": "1010", "availableBalance": "800"}

    def get_position_risk(self, symbol=None):
        return self.positions

    def get_open_orders(self, symbol=None):
        return self.standard_orders

    def get_open_algo_orders(self, symbol=None):
        return self.algo_orders


def test_user_stream_processor_deduplicates_and_projects_partial_account_updates(tmp_path):
    ledger = ExecutionLedger(tmp_path / "stream-events.sqlite")
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 1_800_000_000_000)
    payload = {
        "e": "ACCOUNT_UPDATE", "E": 1000, "T": 999,
        "a": {"m": "ORDER", "B": [{"a": "USDT", "wb": "1000", "cw": "900", "bc": "5"}],
              "P": [{"s": "BTCUSDT", "ps": "BOTH", "pa": "0.1", "ep": "50000",
                     "bep": "50001", "up": "10", "mt": "crossed", "iw": "0"}]},
    }
    first = processor.process(payload)
    duplicate = processor.process(payload)
    assert not first.duplicate
    assert duplicate.duplicate
    assert first.event_id == duplicate.event_id
    assert ledger.user_stream_balances()[0]["wallet_balance"] == "1000"
    position = ledger.user_stream_positions()[0]
    assert position["symbol"] == "BTCUSDT"
    assert position["break_even_price"] == "50001"
    assert ledger.get_user_stream_state()["last_event_at_ms"] == 1_800_000_000_000


def test_user_stream_processor_projects_standard_and_algo_order_events(tmp_path):
    ledger = ExecutionLedger(tmp_path / "stream-orders.sqlite")
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 2000)
    processor.process({"e": "ORDER_TRADE_UPDATE", "E": 100, "T": 99,
                       "o": {"s": "BTCUSDT", "i": 101, "c": "DIVAENTRY", "X": "PARTIALLY_FILLED"}})
    processor.process({"e": "ALGO_UPDATE", "E": 110, "T": 109,
                       "o": {"s": "BTCUSDT", "aid": 202, "caid": "DIVASL", "X": "NEW",
                             "algoStatus": "NEW", "type": "STOP_MARKET"}})
    orders = ledger.user_stream_orders()
    assert {(row["order_kind"], row["status"]) for row in orders} == {
        ("STANDARD", "PARTIALLY_FILLED"), ("ALGO", "NEW")
    }


def test_private_client_listen_key_calls_use_api_key_without_hmac_signature():
    seen = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.method == "POST":
            return httpx.Response(200, json={"listenKey": "listen-token"})
        if request.method == "PUT":
            return httpx.Response(200, json={"listenKey": "listen-token"})
        return httpx.Response(200, json={})

    client_http = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinancePrivateRestClient("api-key", "api-secret", environment="TESTNET", http_client=client_http)
    try:
        assert client.start_user_data_stream() == "listen-token"
        assert client.keepalive_user_data_stream("listen-token")["listenKey"] == "listen-token"
        client.close_user_data_stream("listen-token")
    finally:
        client.close()
    assert [(request.method, request.url.path) for request in seen] == [
        ("POST", "/fapi/v1/listenKey"), ("PUT", "/fapi/v1/listenKey"),
        ("DELETE", "/fapi/v1/listenKey"),
    ]
    for request in seen:
        assert request.headers["X-MBX-APIKEY"] == "api-key"
        query = parse_qs(request.url.query.decode())
        assert "timestamp" not in query
        assert "signature" not in query


def test_user_stream_url_uses_current_usdm_private_path():
    class Client:
        environment = "LIVE"

    class Ledger:
        pass

    supervisor = BinanceUserDataStreamSupervisor(client=Client(), ledger=Ledger())
    assert supervisor.websocket_url("abc-123") == (
        "wss://fstream.binance.com/private/ws?listenKey=abc-123&events="
        "ORDER_TRADE_UPDATE/ACCOUNT_UPDATE/ALGO_UPDATE/TRADE_LITE/"
        "ACCOUNT_CONFIG_UPDATE/MARGIN_CALL/listenKeyExpired"
    )


def test_user_stream_url_uses_current_usdm_demo_futures_endpoint():
    class Client:
        environment = "TESTNET"

    class Ledger:
        pass

    supervisor = BinanceUserDataStreamSupervisor(client=Client(), ledger=Ledger())
    assert supervisor.websocket_url("demo-key") == (
        "wss://demo-fstream.binance.com/private/ws?listenKey=demo-key&events="
        "ORDER_TRADE_UPDATE/ACCOUNT_UPDATE/ALGO_UPDATE/TRADE_LITE/"
        "ACCOUNT_CONFIG_UPDATE/MARGIN_CALL/listenKeyExpired"
    )


def test_user_stream_supervisor_persists_event_and_closes_key_on_stop(tmp_path):
    ledger = ExecutionLedger(tmp_path / "supervisor.sqlite")
    stop = asyncio.Event()
    calls = []
    event_payload = json.dumps({"e": "ORDER_TRADE_UPDATE", "E": 500, "T": 499,
                                "o": {"s": "BTCUSDT", "i": 1, "c": "DIVAENTRY", "X": "NEW"}})

    class Client:
        environment = "TESTNET"
        def start_user_data_stream(self):
            calls.append("start")
            return "test-listen-key"
        def keepalive_user_data_stream(self, listen_key):
            calls.append(("keepalive", listen_key))
            return {"listenKey": listen_key}
        def close_user_data_stream(self, listen_key):
            calls.append(("close", listen_key))
            return {}

    class Websocket:
        def __init__(self):
            self.messages = [event_payload]
        async def recv(self):
            if self.messages:
                return self.messages.pop(0)
            await asyncio.sleep(10)
            return None

    class Context:
        async def __aenter__(self):
            return Websocket()
        async def __aexit__(self, *args):
            return False

    urls = []
    def connector(uri, **kwargs):
        urls.append(uri)
        return Context()

    def on_event(event):
        assert event.event_type == "ORDER_TRADE_UPDATE"
        stop.set()

    supervisor = BinanceUserDataStreamSupervisor(
        client=Client(), ledger=ledger, connector=connector, on_event=on_event,
        clock_ms=lambda: 1_800_000_000_000,
        config=UserDataStreamConfig(keepalive_interval_seconds=100,
                                    max_connection_seconds=20, receive_poll_seconds=0.01,
                                    reconnect_initial_seconds=0.01, reconnect_max_seconds=0.02),
    )
    asyncio.run(supervisor.run(stop))
    assert urls == [
        "wss://demo-fstream.binance.com/private/ws?listenKey=test-listen-key&events="
        "ORDER_TRADE_UPDATE/ACCOUNT_UPDATE/ALGO_UPDATE/TRADE_LITE/"
        "ACCOUNT_CONFIG_UPDATE/MARGIN_CALL/listenKeyExpired"
    ]
    assert calls == ["start", ("close", "test-listen-key")]
    assert ledger.user_stream_orders()[0]["status"] == "NEW"
    assert ledger.get_user_stream_state()["status"] == "STOPPED"


def test_reconciliation_ready_requires_matching_positions_and_stop_tp(tmp_path):
    ledger = ExecutionLedger(tmp_path / "reconcile-ready.sqlite")
    _intent_and_position(ledger)
    now = time.time_ns() // 1_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        clock_ms=lambda: now + 100,
    )
    report = reconciler.reconcile()
    assert report.ready and report.status == "READY"
    ready, reasons = ledger.execution_readiness(now_ms=now + 200)
    assert ready and reasons == ()


def test_reconciliation_blocks_unmanaged_position_or_missing_protection(tmp_path):
    ledger = ExecutionLedger(tmp_path / "reconcile-block.sqlite")
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    client = FakeAccountClient(algo_orders=[])
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(client), ledger=ledger,
        clock_ms=lambda: now + 100,
    )
    report = reconciler.reconcile()
    codes = {item["code"] for item in report.discrepancies}
    assert not report.ready
    assert "UNMANAGED_EXCHANGE_POSITION" in codes
    assert "POSITION_MISSING_PROTECTION" in codes
    halted, reason = ledger.entries_halted()
    assert halted and reason == "ACCOUNT_RECONCILIATION_MISMATCH"
    assert not ledger.execution_readiness(now_ms=now + 200)[0]


def test_wrong_side_protective_order_does_not_satisfy_position_protection(tmp_path):
    ledger = ExecutionLedger(tmp_path / "wrong-side-protection.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    client = FakeAccountClient(algo_orders=[
        {"symbol": "BTCUSDT", "positionSide": "BOTH", "side": "BUY",
         "type": "STOP_MARKET", "algoStatus": "NEW", "closePosition": True,
         "triggerPrice": "49900"},
        {"symbol": "BTCUSDT", "positionSide": "BOTH", "side": "SELL",
         "type": "TAKE_PROFIT_MARKET", "algoStatus": "NEW", "closePosition": True,
         "triggerPrice": "50300"},
    ])
    report = AccountReconciliationService(
        account_state=BinanceAccountStateService(client), ledger=ledger,
        clock_ms=lambda: now + 100,
    ).reconcile()
    missing = [item for item in report.discrepancies if item["code"] == "POSITION_MISSING_PROTECTION"]
    assert not report.ready
    assert len(missing) == 1 and missing[0]["role"] == "STOP_LOSS"


def test_account_event_invalidates_previous_reconciliation_readiness(tmp_path):
    ledger = ExecutionLedger(tmp_path / "event-invalidates-ready.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        clock_ms=lambda: now + 100,
    )
    assert reconciler.reconcile().ready
    assert ledger.execution_readiness(now_ms=now + 200)[0]
    UserDataStreamProcessor(ledger, clock_ms=lambda: now + 300).process({
        "e": "ACCOUNT_UPDATE", "E": now + 250, "T": now + 249,
        "a": {"B": [{"a": "USDT", "wb": "1000", "cw": "900", "bc": "0"}], "P": []},
    })
    ready, reasons = ledger.execution_readiness(now_ms=now + 400)
    assert not ready
    assert "ACCOUNT_ACCOUNT_EVENT_PENDING_RECONCILIATION" in reasons


def test_reconciliation_detects_stream_event_arriving_during_snapshot(tmp_path):
    ledger = ExecutionLedger(tmp_path / "event-during-reconciliation.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    class RacingAccountClient(FakeAccountClient):
        def get_exchange_account(self):
            UserDataStreamProcessor(ledger, clock_ms=lambda: now + 150).process({
                "e": "ACCOUNT_UPDATE", "E": now + 140, "T": now + 139,
                "a": {"B": [{"a": "USDT", "wb": "1000", "cw": "900", "bc": "0"}], "P": []},
            })
            return super().get_exchange_account()

    report = AccountReconciliationService(
        account_state=BinanceAccountStateService(RacingAccountClient()), ledger=ledger,
        clock_ms=lambda: now + 100,
    ).reconcile()
    assert not report.ready
    assert report.status == "EVENT_DURING_RECONCILIATION"
    halted, _ = ledger.entries_halted()
    assert not halted


def test_atomic_reconciliation_commit_rejects_late_stream_event(tmp_path):
    ledger = ExecutionLedger(tmp_path / "late-event-watermark.sqlite")
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=now + 100,
                                    stream_event_watermark_ms=0)
    UserDataStreamProcessor(ledger, clock_ms=lambda: now + 200).process({
        "e": "ORDER_TRADE_UPDATE", "E": now + 190, "T": now + 189,
        "o": {"s": "BTCUSDT", "i": 123, "c": "DIVAENTRY", "X": "NEW"},
    })
    # Simulate a reconciliation whose last REST call finished before this event,
    # but whose commit is delayed until after it was stored.
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=now + 150,
                                    stream_event_watermark_ms=0)
    state = ledger.get_reconciliation_state()
    assert not state["ready"]
    assert state["status"] == "EVENT_DURING_RECONCILIATION"


def test_reconciliation_commit_rejects_stream_disconnect(tmp_path):
    ledger = ExecutionLedger(tmp_path / "late-disconnect.sqlite")
    now = time.time_ns() // 1_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    ledger.set_user_stream_state("DISCONNECTED", updated_at_ms=now + 1)
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=now + 2,
                                    stream_event_watermark_ms=0)
    state = ledger.get_reconciliation_state()
    assert not state["ready"]
    assert state["status"] == "USER_STREAM_NOT_CONNECTED_AT_COMMIT"


def test_testnet_entry_is_blocked_until_stream_and_reconciliation_are_ready(tmp_path):
    ledger = ExecutionLedger(tmp_path / "readiness.sqlite")
    snapshot = parse_exchange_info(json.loads(FIXTURE.read_text()), source_endpoint="fixture")
    instrument = InstrumentSpec.from_symbol_info(snapshot.get_symbol("BTCUSDT"))
    class NoOrderClient:
        environment = "TESTNET"
    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=NoOrderClient(),
    )
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": instrument}, risk_manager=PortfolioRiskManager(),
        execution_service=service, ledger=ledger,
    )
    signal = QualifiedSignal("readiness-signal", "BTCUSDT", "LONG", "LIMIT",
                             Decimal("50000"), Decimal("49900"), Decimal("50300"),
                             "5m", "SMC_V2", 1_800_000_000_000)
    portfolio = PortfolioSnapshot(Decimal("10000"), Decimal("0"), 0, {}, 1_800_000_000_000)
    routed = coordinator.route(signal, portfolio)
    assert not routed.risk.accepted
    assert routed.risk.reason.startswith("ACCOUNT_NOT_READY:")
    assert ledger.get_risk_reservation("readiness-signal") is None
    assert ledger.get_intent("readiness-signal") is None


def test_testnet_configuration_cannot_disable_account_readiness_gate():
    with pytest.raises(ValueError, match="cannot disable the account stream"):
        ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True,
                        require_account_readiness=False)


def test_direct_testnet_submit_rechecks_readiness_immediately_before_order_post(tmp_path):
    from divatrading.trading.models import TradePlan

    ledger = ExecutionLedger(tmp_path / "last-moment-account-change.sqlite")
    now = time.time_ns() // 1_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=now,
                                    stream_event_watermark_ms=0)
    signal = QualifiedSignal("last-moment-gate", "BTCUSDT", "LONG", "LIMIT",
                             Decimal("50000"), Decimal("49900"), Decimal("50300"),
                             "5m", "SMC_V2", now)
    plan = TradePlan(signal, Decimal("0.1"), Decimal("5000"), Decimal("10"),
                     Decimal("1666.67"), 3, "DIVA-LAST-MOMENT-GATE")
    ledger.reserve_portfolio_risk(
        signal_id=signal.signal_id, symbol=signal.symbol, risk_usdt=plan.risk_usdt,
        notional_usdt=plan.notional_usdt, equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
        max_positions=5, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"), max_symbol_notional_usdt=Decimal("60000"),
    )

    class RacingClient:
        environment = "TESTNET"
        posted = False
        leverage = 2
        def sync_server_time(self):
            return None
        def get_position_mode(self):
            return {"dualSidePosition": False}
        def get_position_risk(self, symbol):
            return []
        def get_open_orders(self, symbol):
            return []
        def get_open_algo_orders(self, symbol):
            return []
        def get_symbol_config(self, symbol):
            return [{"symbol": symbol, "marginType": "CROSSED", "leverage": self.leverage}]
        def set_leverage(self, symbol, leverage):
            self.leverage = leverage
            UserDataStreamProcessor(ledger, clock_ms=lambda: now + 200).process({
                "e": "ACCOUNT_UPDATE", "E": now + 190, "T": now + 189,
                "a": {"B": [], "P": []},
            })
        def new_order(self, **params):
            self.posted = True
            raise AssertionError("entry order must not be posted after account readiness changes")

    client = RacingClient()
    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=client,
    )
    result = service.submit(plan)
    assert result.status == "ENTRY_BLOCKED_ACCOUNT_NOT_READY"
    assert not client.posted
    assert ledger.get_intent(signal.signal_id)["status"] == "ENTRY_BLOCKED_ACCOUNT_NOT_READY"
    assert ledger.get_risk_reservation(signal.signal_id)["status"] == "RELEASED"


def test_user_stream_supervisor_reconnects_and_keeps_listen_key_alive(tmp_path):
    ledger = ExecutionLedger(tmp_path / "reconnect.sqlite")
    stop = asyncio.Event()
    calls = {"start": 0, "keepalive": 0, "closed": []}
    message = json.dumps({"e": "ACCOUNT_UPDATE", "E": 700, "T": 699,
                          "a": {"m": "ORDER", "B": [], "P": []}})

    class Client:
        environment = "LIVE"
        def start_user_data_stream(self):
            calls["start"] += 1
            return f"listen-{calls['start']}"
        def keepalive_user_data_stream(self, listen_key):
            calls["keepalive"] += 1
            return {"listenKey": listen_key}
        def close_user_data_stream(self, listen_key):
            calls["closed"].append(listen_key)
            return {}

    class Websocket:
        def __init__(self, attempt):
            self.attempt = attempt
            self.deadline = asyncio.get_running_loop().time() + 0.04
            self.sent = False
        async def recv(self):
            if self.attempt == 1:
                raise ConnectionError("simulated disconnect")
            if not self.sent and asyncio.get_running_loop().time() >= self.deadline:
                self.sent = True
                return message
            return None

    class Context:
        def __init__(self, attempt):
            self.attempt = attempt
        async def __aenter__(self):
            return Websocket(self.attempt)
        async def __aexit__(self, *args):
            return False

    attempts = []
    def connector(uri, **kwargs):
        attempts.append(uri)
        return Context(len(attempts))

    supervisor = BinanceUserDataStreamSupervisor(
        client=Client(), ledger=ledger, connector=connector,
        on_event=lambda event: stop.set(),
        config=UserDataStreamConfig(keepalive_interval_seconds=0.01,
                                    max_connection_seconds=5, receive_poll_seconds=0.005,
                                    reconnect_initial_seconds=0.005, reconnect_max_seconds=0.01),
    )
    asyncio.run(supervisor.run(stop))
    assert len(attempts) == 2
    assert calls["start"] == 2
    assert calls["keepalive"] >= 1
    assert calls["closed"] == ["listen-1", "listen-2"]
    assert ledger.get_user_stream_state()["status"] == "STOPPED"


def test_testnet_direct_execution_is_blocked_when_account_is_not_reconciled(tmp_path):
    from divatrading.trading.models import TradePlan

    ledger = ExecutionLedger(tmp_path / "direct-readiness.sqlite")
    signal = QualifiedSignal("direct-gate", "BTCUSDT", "LONG", "LIMIT",
                             Decimal("50000"), Decimal("49900"), Decimal("50300"),
                             "5m", "SMC_V2", 1_800_000_000_000)
    plan = TradePlan(signal, Decimal("0.1"), Decimal("5000"), Decimal("10"),
                     Decimal("1666.67"), 3, "DIVA-DIRECT-GATE")
    ledger.reserve_portfolio_risk(
        signal_id=signal.signal_id, symbol=signal.symbol, risk_usdt=plan.risk_usdt,
        notional_usdt=plan.notional_usdt, equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
        max_positions=5, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"), max_symbol_notional_usdt=Decimal("60000"),
    )

    class NoOrderClient:
        environment = "TESTNET"

    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=NoOrderClient(),
    )
    with pytest.raises(RuntimeError, match="ACCOUNT_NOT_READY"):
        service.submit(plan)
    assert ledger.get_intent(signal.signal_id) is None


def test_order_trade_fill_is_durably_attributed_to_signal_and_deduplicated(tmp_path):
    ledger = ExecutionLedger(tmp_path / "fill-attribution.sqlite")
    ledger.claim_intent(signal_id="sig-fill", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-FILL", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-FILL", signal_id="sig-fill", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="NEW", exchange_order_id=10,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 2000)
    payload = {
        "e": "ORDER_TRADE_UPDATE", "E": 1500, "T": 1499,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-FILL", "S": "BUY", "ps": "BOTH",
              "x": "TRADE", "X": "PARTIALLY_FILLED", "l": "0.25", "L": "50000",
              "t": 777, "z": "0.25"},
    }
    first = processor.process(payload)
    duplicate = processor.process(payload)
    rows = ledger.list_position_fill_allocations()
    assert not first.duplicate and duplicate.duplicate
    assert len(rows) == 1
    assert rows[0]["signal_id"] == "sig-fill"
    assert rows[0]["effect"] == "OPEN"
    assert rows[0]["allocation_status"] == "ATTRIBUTED"
    assert rows[0]["quantity"] == "0.25"


def test_lifecycle_order_fill_maps_back_to_originating_signal(tmp_path):
    ledger = ExecutionLedger(tmp_path / "management-fill-attribution.sqlite")
    ledger.claim_intent(signal_id="sig-exit", symbol="ETHUSDT", side="SHORT",
                        client_order_id="DIVAENTRY-EXIT", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-EXIT", signal_id="sig-exit", symbol="ETHUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=87,
        payload={"positionSide": "BOTH"},
    )
    ledger.claim_position_management_action(
        action_id="action-exit", signal_id="sig-exit", action_kind="PARTIAL_TP",
        payload={"client_order_id": "DIVAPC-EXIT", "symbol": "ETHUSDT",
                "position_side": "BOTH", "side": "SHORT"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 3000)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 1900, "T": 1899,
        "o": {"s": "ETHUSDT", "c": "DIVAENTRY-EXIT", "S": "SELL", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.5", "L": "3000", "t": 87, "i": 87},
    })
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 2000, "T": 1999,
        "o": {"s": "ETHUSDT", "c": "DIVAPC-EXIT", "S": "BUY", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.5", "L": "3000", "t": 88},
    })
    row = next(fill for fill in ledger.list_position_fill_allocations() if fill["effect"] == "CLOSE")
    assert row["signal_id"] == "sig-exit"
    assert row["order_role"] == "PARTIAL_TP"


def test_unattributed_diva_fill_latches_entry_halt(tmp_path):
    ledger = ExecutionLedger(tmp_path / "unattributed-fill.sqlite")
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 4000)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 3000, "T": 2999,
        "o": {"s": "BTCUSDT", "c": "DIVA-UNKNOWN", "S": "SELL", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.1", "L": "50000", "t": 99},
    })
    halted, reason = ledger.entries_halted()
    assert halted and reason == "UNATTRIBUTED_DIVATRADING_FILL:DIVA-UNKNOWN"
    row = ledger.list_position_fill_allocations()[0]
    assert row["allocation_status"] == "UNATTRIBUTED"
    assert row["signal_id"] is None


def test_stream_fill_racing_order_persistence_is_backfilled_when_owner_is_recorded(tmp_path):
    ledger = ExecutionLedger(tmp_path / "fill-backfill.sqlite")
    ledger.claim_intent(signal_id="sig-race", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-RACE", payload={})
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 5000)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 4000, "T": 3999,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-RACE", "S": "BUY", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.2", "L": "50000", "t": 100},
    })
    assert ledger.list_position_fill_allocations()[0]["allocation_status"] == "UNATTRIBUTED"
    ledger.record_order(
        client_id="DIVAENTRY-RACE", signal_id="sig-race", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=11,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    row = ledger.list_position_fill_allocations()[0]
    assert row["allocation_status"] == "ATTRIBUTED"
    assert row["signal_id"] == "sig-race"
    # The entry halt is intentionally not auto-cleared by a late attribution.
    assert ledger.entries_halted()[0] is True


def test_trade_lite_and_order_trade_update_deduplicate_same_exchange_fill(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-lite-dedupe.sqlite")
    ledger.claim_intent(signal_id="sig-lite", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-LITE", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-LITE", signal_id="sig-lite", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="NEW", exchange_order_id=12,
        payload={"positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 6000)
    trade_lite = {"e": "TRADE_LITE", "E": 5000, "T": 4999, "s": "BTCUSDT",
                  "q": "0.3", "p": "0", "m": False, "c": "DIVAENTRY-LITE",
                  "S": "BUY", "L": "50000", "l": "0.3", "t": 123, "i": 12}
    order_update = {"e": "ORDER_TRADE_UPDATE", "E": 5001, "T": 5000,
                    "o": {"s": "BTCUSDT", "c": "DIVAENTRY-LITE", "S": "BUY", "ps": "BOTH",
                          "x": "TRADE", "X": "FILLED", "l": "0.3", "L": "50000", "t": 123}}
    processor.process(trade_lite)
    processor.process(order_update)
    fills = ledger.list_position_fill_allocations()
    assert len(fills) == 1
    assert fills[0]["signal_id"] == "sig-lite"
    assert fills[0]["quantity"] == "0.3"


def test_trade_lite_is_enriched_with_commission_and_realized_pnl_and_fill_projection_is_idempotent(tmp_path):
    ledger = ExecutionLedger(tmp_path / "fill-projection.sqlite")
    ledger.claim_intent(signal_id="sig-projection", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-PROJECTION", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-PROJECTION", signal_id="sig-projection", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=100,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    ledger.record_order(
        client_id="DIVATPCLOSE-PROJECTION", signal_id="sig-projection", symbol="BTCUSDT",
        role="TAKE_PROFIT", order_kind="STANDARD", status="FILLED", exchange_order_id=101,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 9000)

    def lite(trade_id, quantity, price, client_id, order_id, event_time):
        processor.process({
            "e": "TRADE_LITE", "E": event_time, "T": event_time - 1,
            "s": "BTCUSDT", "c": client_id, "S": "BUY" if client_id == "DIVAENTRY-PROJECTION" else "SELL",
            "l": quantity, "L": price, "t": trade_id, "i": order_id,
            "m": True,
        })

    lite(1, "0.5", "100", "DIVAENTRY-PROJECTION", 100, 5001)
    # The detailed ORDER_TRADE_UPDATE enriches the same trade ID instead of
    # creating a second fill record.
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 5002, "T": 5002,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-PROJECTION", "S": "BUY", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.5", "L": "100", "t": 1,
              "i": 100, "n": "-0.001", "N": "BNB", "rp": "0", "m": True},
    })
    lite(2, "0.5", "110", "DIVAENTRY-PROJECTION", 100, 5003)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 5004, "T": 5004,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-PROJECTION", "S": "BUY", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.5", "L": "110", "t": 2,
              "i": 100, "n": "0.002", "N": "BNB", "rp": "0", "m": False},
    })
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 5005, "T": 5005,
        "o": {"s": "BTCUSDT", "c": "DIVATPCLOSE-PROJECTION", "S": "SELL", "ps": "BOTH",
              "x": "TRADE", "X": "FILLED", "l": "0.4", "L": "120", "t": 3,
              "i": 101, "n": "0.003", "N": "BNB", "rp": "6.0", "m": False},
    })

    fills = ledger.list_position_fill_allocations()
    assert len(fills) == 3
    assert fills[0]["commission"] == "-0.001"
    assert fills[0]["commission_asset"] == "BNB"
    assert fills[2]["realized_pnl"] == "6.0"

    first = ledger.apply_position_fill_allocations(signal_id="sig-projection")[0]
    second = ledger.apply_position_fill_allocations(signal_id="sig-projection")[0]
    assert first["entry_quantity"] == second["entry_quantity"] == "1.0"
    assert Decimal(first["weighted_entry_price"]) == Decimal("105")
    assert first["close_quantity"] == "0.4"
    assert first["net_quantity"] == "0.6"
    assert first["commissions"]["BNB"] == "0.004"
    assert first["realized_pnl"]["USDT"] == "6.0"
    with ledger._connection() as db:
        assert db.execute("SELECT COUNT(*) FROM position_fill_applications").fetchone()[0] == 3
        assert db.execute("SELECT COUNT(*) FROM position_fill_projections").fetchone()[0] == 1


def test_fill_can_be_attributed_by_actual_exchange_order_id_when_client_id_differs(tmp_path):
    ledger = ExecutionLedger(tmp_path / "actual-order-id-attribution.sqlite")
    ledger.claim_intent(signal_id="sig-actual", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-ACTUAL", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-ACTUAL", signal_id="sig-actual", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=776,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 10000)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 8000, "T": 7999,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-ACTUAL", "i": 776, "S": "BUY",
              "ps": "BOTH", "x": "TRADE", "X": "FILLED", "l": "0.25",
              "L": "50000", "t": 887},
    })
    ledger.record_order(
        client_id="autoclose-owner", signal_id="sig-actual", symbol="BTCUSDT",
        role="STOP_LOSS", order_kind="STANDARD", status="FILLED", exchange_order_id=777,
        payload={"symbol": "BTCUSDT", "positionSide": "BOTH"},
    )
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 9000, "T": 8999,
        "o": {"s": "BTCUSDT", "c": "exchange-generated-client-id", "i": 777,
              "S": "SELL", "ps": "BOTH", "x": "TRADE", "X": "FILLED",
              "l": "0.25", "L": "49000", "t": 888},
    })
    fill = next(item for item in ledger.list_position_fill_allocations() if item["exchange_order_id"] == "777")
    assert fill["signal_id"] == "sig-actual"
    assert fill["effect"] == "CLOSE"
    assert fill["order_role"] == "STOP_LOSS"


def test_fill_applier_rejects_close_quantity_exceeding_entry_and_latches_halt(tmp_path):
    ledger = ExecutionLedger(tmp_path / "fill-overclose.sqlite")
    ledger.claim_intent(signal_id="sig-overclose", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-OVERCLOSE", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-OVERCLOSE", signal_id="sig-overclose", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=200,
        payload={"positionSide": "BOTH"},
    )
    ledger.record_order(
        client_id="DIVACLOSE-OVERCLOSE", signal_id="sig-overclose", symbol="BTCUSDT",
        role="STOP_LOSS", order_kind="STANDARD", status="FILLED", exchange_order_id=201,
        payload={"positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 11000)
    processor.process({"e": "ORDER_TRADE_UPDATE", "E": 10001, "T": 10000,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-OVERCLOSE", "i": 200, "S": "BUY",
              "ps": "BOTH", "x": "TRADE", "X": "FILLED", "l": "0.2", "L": "100", "t": 1}})
    with pytest.raises(RuntimeError, match="FILL_CLOSE_EXCEEDS_OPEN"):
        processor.process({"e": "ORDER_TRADE_UPDATE", "E": 10002, "T": 10001,
            "o": {"s": "BTCUSDT", "c": "DIVACLOSE-OVERCLOSE", "i": 201, "S": "SELL",
                  "ps": "BOTH", "x": "TRADE", "X": "FILLED", "l": "0.3", "L": "90", "t": 2}})
    assert ledger.entries_halted()[0] is True


def test_late_actual_order_id_mapping_backfills_external_stream_fill_and_applies_projection(tmp_path):
    ledger = ExecutionLedger(tmp_path / "late-actual-order-link.sqlite")
    ledger.claim_intent(signal_id="sig-late-map", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAENTRY-LATE-MAP", payload={})
    ledger.record_order(
        client_id="DIVAENTRY-LATE-MAP", signal_id="sig-late-map", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=901,
        payload={"positionSide": "BOTH"},
    )
    processor = UserDataStreamProcessor(ledger, clock_ms=lambda: 12000)
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 11000, "T": 10999,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-LATE-MAP", "i": 901, "S": "BUY",
              "ps": "BOTH", "x": "TRADE", "X": "FILLED", "l": "1", "L": "100", "t": 901},
    })
    processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 11001, "T": 11000,
        "o": {"s": "BTCUSDT", "c": "exchange-generated-client-id", "i": 902,
              "S": "SELL", "ps": "BOTH", "x": "TRADE", "X": "FILLED",
              "l": "0.25", "L": "95", "t": 902},
    })
    before = next(fill for fill in ledger.list_position_fill_allocations() if fill["trade_id"] == "902")
    assert before["allocation_status"] == "EXTERNAL"
    ledger.record_order(
        client_id="autoclose-owner", signal_id="sig-late-map", symbol="BTCUSDT",
        role="STOP_LOSS", order_kind="STANDARD", status="FILLED", exchange_order_id=902,
        payload={"positionSide": "BOTH"},
    )
    after = next(fill for fill in ledger.list_position_fill_allocations() if fill["trade_id"] == "902")
    assert after["allocation_status"] == "ATTRIBUTED"
    assert after["signal_id"] == "sig-late-map"
    assert after["effect"] == "CLOSE"
    assert ledger.get_position_fill_projection("sig-late-map")["net_quantity"] == "0.75"


def test_v053_ledger_schema_migrates_existing_v052_fill_table(tmp_path):
    import sqlite3

    database = tmp_path / "v052-existing.sqlite"
    with sqlite3.connect(database) as db:
        db.execute("""CREATE TABLE position_fill_allocations (
            fill_key TEXT PRIMARY KEY, event_id TEXT NOT NULL, client_order_id TEXT NOT NULL,
            signal_id TEXT, symbol TEXT NOT NULL, position_side TEXT NOT NULL,
            order_role TEXT NOT NULL, effect TEXT NOT NULL, quantity TEXT NOT NULL,
            price TEXT NOT NULL, trade_id TEXT NOT NULL, event_time_ms INTEGER NOT NULL,
            allocation_status TEXT NOT NULL, payload_json TEXT NOT NULL, created_at_utc TEXT NOT NULL
        )""")
    ledger = ExecutionLedger(database)
    with ledger._connection() as db:
        columns = {row["name"] for row in db.execute("PRAGMA table_info(position_fill_allocations)")}
        tables = {row["name"] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {
        "exchange_order_id", "order_side", "commission", "commission_asset",
        "realized_pnl", "is_maker", "source",
    }.issubset(columns)
    assert {"execution_exchange_order_links", "position_fill_applications", "position_fill_projections"}.issubset(tables)


def test_reconciliation_runs_trade_backfill_under_transient_entry_halt(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-backfill-reconcile.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    class Backfill:
        def __init__(self):
            self.symbols = []
        def backfill_symbol(self, symbol):
            halted, reason = ledger.entries_halted()
            assert halted and reason == "TRADE_HISTORY_BACKFILL_IN_PROGRESS"
            self.symbols.append(symbol)

    backfill = Backfill()
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        trade_backfill_service=backfill, clock_ms=lambda: now + 100,
    )
    report = reconciler.reconcile()
    assert report.ready and report.status == "READY"
    assert backfill.symbols == ["BTCUSDT"]
    assert ledger.entries_halted() == (False, None)
    # The interval throttle prevents a REST userTrades call every 10-second reconcile cycle.
    reconciler.reconcile()
    assert backfill.symbols == ["BTCUSDT"]


def test_reconciliation_force_backfill_after_reconnect_bypasses_interval(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-backfill-forced-reconnect.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    class Backfill:
        def __init__(self):
            self.calls = []

        def backfill_symbol(self, symbol):
            self.calls.append(symbol)

    backfill = Backfill()
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        trade_backfill_service=backfill, trade_backfill_interval_ms=3_600_000,
        clock_ms=lambda: now + 100,
    )
    assert reconciler.reconcile().ready
    assert backfill.calls == ["BTCUSDT"]

    # A healthy periodic cycle is throttled, but a new private-stream connection
    # explicitly requests recovery even though the normal interval has not elapsed.
    assert reconciler.reconcile().ready
    assert backfill.calls == ["BTCUSDT"]
    reconciler.request_trade_backfill()
    assert reconciler.reconcile().ready
    assert backfill.calls == ["BTCUSDT", "BTCUSDT"]


def test_forced_trade_backfill_request_survives_failure_until_full_success(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-backfill-forced-retry.sqlite")
    _intent_and_position(ledger, "managed-btc")
    ledger.claim_intent(signal_id="managed-eth", symbol="ETHUSDT", side="LONG",
                        client_order_id="DIVA-managed-eth", payload={})
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    class Backfill:
        def __init__(self):
            self.calls = []
            self.fail_eth_once = False

        def backfill_symbol(self, symbol):
            self.calls.append(symbol)
            if self.fail_eth_once and symbol == "ETHUSDT":
                self.fail_eth_once = False
                raise RuntimeError("temporary ETH userTrades outage")

    backfill = Backfill()
    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        trade_backfill_service=backfill, trade_backfill_interval_ms=3_600_000,
        clock_ms=lambda: now + 100,
    )
    assert reconciler.reconcile().ready
    assert backfill.calls == ["BTCUSDT", "ETHUSDT"]

    reconciler.request_trade_backfill()
    backfill.calls.clear()
    backfill.fail_eth_once = True
    failed = reconciler.reconcile()
    assert failed.status == "TRADE_HISTORY_BACKFILL_FAILED"
    assert ledger.entries_halted() == (True, "TRADE_HISTORY_BACKFILL_FAILED")

    # Failure must not consume the reconnect recovery request. The next reconcile
    # retries all tracked symbols before allowing a fresh account snapshot.
    backfill.calls.clear()
    recovered = reconciler.reconcile()
    assert recovered.ready
    assert backfill.calls == ["BTCUSDT", "ETHUSDT"]
    assert ledger.entries_halted() == (False, None)


def test_account_runtime_requests_user_trade_backfill_on_each_stream_connection(tmp_path):
    from types import SimpleNamespace

    ledger = ExecutionLedger(tmp_path / "runtime-user-trade-reconnect.sqlite")
    requests = {"forced_backfill": 0, "reconcile": 0}
    now = 1_800_000_000_000

    class ReconnectingUserStream:
        on_event = None

        async def run(self, stop_event):
            ledger.set_user_stream_state("CONNECTED", connected_at_ms=now,
                                         updated_at_ms=now)
            await asyncio.sleep(0.025)
            ledger.set_user_stream_state("DISCONNECTED", updated_at_ms=now + 1)
            await asyncio.sleep(0.015)
            if not stop_event.is_set():
                ledger.set_user_stream_state("CONNECTED", connected_at_ms=now + 100,
                                             updated_at_ms=now + 100)
            await stop_event.wait()
            ledger.set_user_stream_state("STOPPED", updated_at_ms=now + 200)

    class Reconciler:
        def request_trade_backfill(self):
            requests["forced_backfill"] += 1

        def reconcile(self):
            requests["reconcile"] += 1
            return SimpleNamespace(status="READY", captured_at_ms=now + requests["reconcile"])

    runtime = ExecutionAccountRuntime(
        user_stream=ReconnectingUserStream(), reconciler=Reconciler(), ledger=ledger,
        config=AccountRuntimeConfig(reconciliation_interval_seconds=0.005,
                                    disconnected_poll_seconds=0.002),
    )

    async def run_runtime():
        stop = asyncio.Event()
        asyncio.get_running_loop().call_later(0.08, stop.set)
        await runtime.run(stop)

    asyncio.run(run_runtime())
    assert requests["forced_backfill"] == 2
    assert requests["reconcile"] >= 2


def test_reconciliation_never_clears_preexisting_operator_halt_during_backfill(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-backfill-operator-halt.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    ledger.set_entries_halted(True, "MANUAL_KILL_SWITCH")

    class Backfill:
        def backfill_symbol(self, symbol):
            assert ledger.entries_halted() == (True, "MANUAL_KILL_SWITCH")

    reconciler = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        trade_backfill_service=Backfill(), clock_ms=lambda: now + 100,
    )
    report = reconciler.reconcile()
    assert not report.ready
    assert ledger.entries_halted() == (True, "MANUAL_KILL_SWITCH")


def test_trade_backfill_failure_keeps_entries_halted_and_blocks_reconciliation(tmp_path):
    ledger = ExecutionLedger(tmp_path / "trade-backfill-failure.sqlite")
    _intent_and_position(ledger)
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    class BrokenBackfill:
        def backfill_symbol(self, symbol):
            raise RuntimeError("REST history unavailable")

    report = AccountReconciliationService(
        account_state=BinanceAccountStateService(FakeAccountClient()), ledger=ledger,
        trade_backfill_service=BrokenBackfill(), clock_ms=lambda: now + 100,
    ).reconcile()
    assert not report.ready and report.status == "TRADE_HISTORY_BACKFILL_FAILED"
    assert report.discrepancies[0]["code"] == "TRADE_HISTORY_BACKFILL_FAILED"
    assert ledger.entries_halted() == (True, "TRADE_HISTORY_BACKFILL_FAILED")
    assert not ledger.get_reconciliation_state()["ready"]


@pytest.mark.parametrize("dual,position_side", [(False, "BOTH"), (True, "LONG")])
@pytest.mark.parametrize("missing_second_lot_protection", [False, True])
def test_reconciliation_verifies_protection_for_each_same_side_signal_lot(
    tmp_path, dual, position_side, missing_second_lot_protection,
):
    ledger = ExecutionLedger(
        tmp_path / f"multi-lot-reconcile-{position_side}-{missing_second_lot_protection}.sqlite"
    )
    for signal_id in ("sig-one", "sig-two"):
        ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side="LONG",
                            client_order_id=f"DIVA-{signal_id}", payload={})
        ledger.record_position(symbol="BTCUSDT", position_side=position_side,
                               signal_id=signal_id, quantity="0.1", entry_price="50000",
                               stop_loss="49900", take_profit="50300")
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)

    protective = []
    signal_ids = ["sig-one"] if missing_second_lot_protection else ["sig-one", "sig-two"]
    for signal_id in signal_ids:
        for role, order_type in (("STOP_LOSS", "STOP_MARKET"),
                                 ("TAKE_PROFIT", "TAKE_PROFIT_MARKET")):
            protective.append({
                "symbol": "BTCUSDT", "positionSide": position_side, "side": "SELL",
                "type": order_type, "algoStatus": "NEW", "quantity": "0.1",
                "reduceOnly": not dual, "closePosition": False,
                "clientAlgoId": ledger.deterministic_client_id(signal_id, role),
                "triggerPrice": "49900" if role == "STOP_LOSS" else "50300",
            })
    account_client = FakeAccountClient(
        positions=[{
            "symbol": "BTCUSDT", "positionSide": position_side, "positionAmt": "0.2",
            "entryPrice": "50000", "markPrice": "50100", "unRealizedProfit": "20",
            "notional": "10020", "isolated": "false",
        }],
        algo_orders=protective,
    )
    report = AccountReconciliationService(
        account_state=BinanceAccountStateService(account_client), ledger=ledger,
        clock_ms=lambda: now + 100,
    ).reconcile()

    missing = [item for item in report.discrepancies if item["code"] == "POSITION_MISSING_PROTECTION"]
    if missing_second_lot_protection:
        assert not report.ready
        assert {(item.get("signal_id"), item.get("role")) for item in missing} == {
            ("sig-two", "STOP_LOSS"), ("sig-two", "TAKE_PROFIT"),
        }
    else:
        assert report.ready
        assert missing == []


def test_user_stream_url_encodes_listen_key_and_uses_multi_event_query():
    from urllib.parse import parse_qs, urlsplit

    class Client:
        environment = "TESTNET"

    class Ledger:
        pass

    supervisor = BinanceUserDataStreamSupervisor(client=Client(), ledger=Ledger())
    url = supervisor.websocket_url("listen key/+?")
    parsed = urlsplit(url)
    query = parse_qs(parsed.query)
    assert parsed.scheme == "wss"
    assert parsed.netloc == "demo-fstream.binance.com"
    assert parsed.path == "/private/ws"
    assert query["listenKey"] == ["listen key/+?"]
    assert query["events"] == [
        "ORDER_TRADE_UPDATE/ACCOUNT_UPDATE/ALGO_UPDATE/TRADE_LITE/"
        "ACCOUNT_CONFIG_UPDATE/MARGIN_CALL/listenKeyExpired"
    ]


def test_reconciliation_rejects_quantity_scoped_protection_with_wrong_trigger_price(tmp_path):
    ledger = ExecutionLedger(tmp_path / "wrong-trigger-protection.sqlite")
    _intent_and_position(ledger)
    stop_id = ledger.deterministic_client_id("managed-1", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("managed-1", "TAKE_PROFIT")
    now = 1_800_000_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    client = FakeAccountClient(algo_orders=[
        {
            "symbol": "BTCUSDT", "positionSide": "BOTH", "side": "SELL",
            "type": "STOP_MARKET", "algoStatus": "NEW", "quantity": "0.1",
            "reduceOnly": True, "closePosition": False,
            "clientAlgoId": stop_id, "triggerPrice": "49950",
        },
        {
            "symbol": "BTCUSDT", "positionSide": "BOTH", "side": "SELL",
            "type": "TAKE_PROFIT_MARKET", "algoStatus": "NEW", "quantity": "0.1",
            "reduceOnly": True, "closePosition": False,
            "clientAlgoId": take_id, "triggerPrice": "50300",
        },
    ])
    report = AccountReconciliationService(
        account_state=BinanceAccountStateService(client), ledger=ledger,
        clock_ms=lambda: now + 100,
    ).reconcile()
    missing = [item for item in report.discrepancies if item["code"] == "POSITION_MISSING_PROTECTION"]
    assert not report.ready
    assert [(item.get("role"), item.get("signal_id")) for item in missing] == [
        ("STOP_LOSS", "managed-1"),
    ]
