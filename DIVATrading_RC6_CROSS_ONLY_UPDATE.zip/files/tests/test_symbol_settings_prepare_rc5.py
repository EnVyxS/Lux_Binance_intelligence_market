from __future__ import annotations

from dataclasses import replace
from decimal import Decimal

import pytest

from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.trading.models import QualifiedSignal, TradePlan


class SymbolSettingsClient:
    environment = "TESTNET"
    def __init__(self, *, open_position=False):
        self.margin = "CROSSED"
        self.leverage = 3
        self.open_position = open_position
        self.calls = []
    def get_position_risk(self, symbol):
        self.calls.append(("position", symbol))
        return [{"symbol": symbol, "positionAmt": "0.01" if self.open_position else "0"}]
    def get_open_orders(self, symbol): self.calls.append(("orders", symbol)); return []
    def get_open_algo_orders(self, symbol): self.calls.append(("algo", symbol)); return []
    def sync_server_time(self): self.calls.append(("time",))
    def get_position_mode(self): return {"dualSidePosition": False}
    def get_symbol_config(self, symbol):
        self.calls.append(("config", symbol))
        return [{"symbol": symbol, "marginType": self.margin, "leverage": self.leverage}]
    def change_margin_type(self, symbol, margin):
        self.calls.append(("margin-write", symbol, margin)); self.margin = margin
    def set_leverage(self, symbol, leverage):
        self.calls.append(("leverage-write", symbol, leverage)); self.leverage = leverage
        return {"symbol": symbol, "leverage": leverage}


@pytest.mark.parametrize("current_leverage", [3, 150])
def test_symbol_margin_and_leverage_are_read_before_write_and_verified(tmp_path, current_leverage):
    ledger = ExecutionLedger(tmp_path / "settings.sqlite")
    client = SymbolSettingsClient()
    client.leverage = current_leverage
    service = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True), client=client)
    service._prepare_symbol_settings(symbol="BTCUSDT", leverage=10, margin_mode="CROSSED")
    assert client.margin == "CROSSED" and client.leverage == 10
    assert client.calls[:4] == [
        ("position", "BTCUSDT"), ("orders", "BTCUSDT"), ("algo", "BTCUSDT"), ("config", "BTCUSDT")
    ]
    assert not any(call[0] == "margin-write" for call in client.calls)
    assert ("leverage-write", "BTCUSDT", 10) in client.calls
    assert client.calls[-1] == ("config", "BTCUSDT")
    import sqlite3
    with sqlite3.connect(tmp_path / "settings.sqlite") as db:
        rows = db.execute("SELECT event_type FROM execution_events ORDER BY id DESC LIMIT 1").fetchone()
    assert rows[0] == "SYMBOL_SETTINGS_VERIFIED"


def test_symbol_settings_never_mutate_when_position_is_open(tmp_path):
    ledger = ExecutionLedger(tmp_path / "settings-open.sqlite")
    client = SymbolSettingsClient(open_position=True)
    service = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True), client=client)
    with pytest.raises(RuntimeError, match="BLOCKED_OPEN_POSITION"):
        service._prepare_symbol_settings(symbol="BTCUSDT", leverage=10, margin_mode="CROSSED")
    assert not any(call[0].endswith("-write") for call in client.calls)


def test_symbol_settings_accept_cross_alias_without_an_unnecessary_write(tmp_path):
    client = SymbolSettingsClient()
    client.margin = "cross"
    service = ExecutionService(
        ExecutionLedger(tmp_path / "settings-cross.sqlite"),
        config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=client,
    )
    service._prepare_symbol_settings(symbol="BTCUSDT", leverage=3, margin_mode="CROSSED")
    assert not any(call[0].endswith("-write") for call in client.calls)


def test_symbol_settings_reject_readback_for_a_different_symbol(tmp_path):
    class WrongReadbackClient(SymbolSettingsClient):
        def get_symbol_config(self, symbol):
            row, = super().get_symbol_config(symbol)
            if self.calls.count(("config", symbol)) == 2:
                row["symbol"] = "ETHUSDT"
            return [row]

    service = ExecutionService(
        ExecutionLedger(tmp_path / "settings-readback.sqlite"),
        config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=WrongReadbackClient(),
    )
    with pytest.raises(RuntimeError, match="SYMBOL_CONFIG_READBACK_INVALID:BTCUSDT:SYMBOL_ROW_MISSING"):
        service._prepare_symbol_settings(symbol="BTCUSDT", leverage=10, margin_mode="CROSSED")


def test_non_cross_entry_is_blocked_before_writes_and_releases_new_reservation(tmp_path):
    ledger = ExecutionLedger(tmp_path / "settings-isolated.sqlite")
    client = SymbolSettingsClient()
    client.margin = "ISOLATED"
    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True,
                                       enable_testnet_stage_c=True), client=client,
    )
    signal = QualifiedSignal(
        signal_id="cross-margin-check", symbol="BTCUSDT", timeframe="5m", side="LONG",
        entry_type="LIMIT", entry_price=Decimal("100"), stop_loss=Decimal("98"),
        take_profit=Decimal("104"), score=80, created_at_ms=1, strategy_id="test",
    )
    plan = TradePlan(
        signal=signal, quantity=Decimal("0.1"), notional_usdt=Decimal("10"),
        risk_usdt=Decimal("0.20"), margin_estimate_usdt=Decimal("3.50"),
        leverage=3, client_order_id="cross-margin-check",
    )
    with pytest.raises(RuntimeError, match="CROSS_MARGIN_REQUIRED"):
        service.submit(replace(plan, margin_mode="ISOLATED"))
    assert client.calls == []
    assert ledger.get_intent(signal.signal_id) is None

    ledger.reserve_portfolio_risk(
        signal_id=signal.signal_id, symbol=signal.symbol, risk_usdt=plan.risk_usdt,
        notional_usdt=plan.notional_usdt, equity_usdt=Decimal("25"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
        max_portfolio_open_risk_pct=Decimal("20"),
        max_positions=1, exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal("100"),
    )
    service.ledger.execution_readiness = lambda **_: (True, ())
    result = service.submit(plan)
    assert result.status == "ENTRY_BLOCKED_MARGIN_MODE"
    assert not any(call[0].endswith("-write") for call in client.calls)
    assert ledger.get_risk_reservation(signal.signal_id)["status"] == "RELEASED"
    assert ledger.entries_halted() == (False, None)
