"""Command-line entry points for checking the foundation and initializing storage."""

from __future__ import annotations

import argparse
import asyncio
from decimal import Decimal
import json
import logging
import os
import sys
import time
from pathlib import Path
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from divatrading import __version__
from divatrading.core.config import ConfigurationError, Settings, _parse_env_file
from divatrading.core.database import Database
from divatrading.core.logging_setup import configure_logging
from divatrading.core.runtime import RuntimeCompatibilityError, validate_runtime
from divatrading.core.reliability import ProcessLock, live_exchange_lock, operator_status
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient, DEFAULT_BASE_URL
from divatrading.exchange.binance.resolver import SymbolResolver
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.exchange.binance.service import BinanceMetadataService
from divatrading.trading.universe import SymbolUniverseConfig, SymbolUniverseSelector
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.execution.binance_private import BinancePrivateRestClient
from divatrading.execution.testnet_qualification import BinanceTestnetPreflight
from divatrading.execution.live_preflight import BinanceLiveReadOnlyPreflight
from divatrading.execution.binance_private import (
    BinancePrivateApiError, BinancePrivateTransportError, TESTNET_BASE_URL,
)
from divatrading.execution.test_order import (
    TestOrderSpec, TestOrderValidationError, prepare_test_order,
)
from divatrading.execution.account_state import BinanceAccountStateService
from divatrading.execution.user_data_stream import BinanceUserDataStreamSupervisor
from divatrading.execution.reconciliation import AccountReconciliationService
from divatrading.execution.trade_backfill import BinanceUserTradesBackfillService
from divatrading.execution.income_backfill import BinanceIncomeHistoryBackfillService
from divatrading.execution.trade_risk_ledger import CompletedTradeRiskLedger
from divatrading.execution.trade_risk_reconciliation import (CompletedTradeRiskReconciler, derive_day_start_equity)
from divatrading.execution.account_runtime import ExecutionAccountRuntime
from divatrading.execution.position_lifecycle_execution import (
    PositionLifecycleExecutionAdapter, PositionLifecycleFillReducer,
)
from divatrading.execution.position_supervisor import (
    ManagedPositionSupervisor, PositionSupervisorConfig,
)
from divatrading.market_data.mark_price import BinanceMarkPriceWebSocketFeed
from divatrading.market_data.klines import Kline, INTERVAL_MILLISECONDS
from divatrading.intelligence.kronos import KronosConfig, KronosShadowAdapter
from divatrading.intelligence.kronos_install import KronosInstallError, install_kronos
from divatrading.intelligence.kronos_evaluation import evaluate_kronos_forecast
from divatrading.signals.telegram import SignalPublicationStore, SignalTelegramPublisher
from concurrent.futures import ThreadPoolExecutor
from threading import Event, Lock, Thread
from collections import deque
from divatrading.market_data.websocket import (
    BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
)
from divatrading.market_data.history import HistoricalKlineService
from divatrading.market_data.live_feed_graph import BinanceFeedGraphConfig, BinancePublicFeedFactory
from divatrading.trading.commissioning import (
    LIVE_MAX_POSITIONS, TestnetCommissioningCaps, LiveFirstCommissioningCaps,
)
from divatrading.core.runtime_supervision import run_with_account_supervision
from divatrading.trading.coordinator import MultiPairExecutionCoordinator
from divatrading.trading.live_runtime import LiveMarketRuntimeConfig, MultiPairLiveMarketRuntime
from divatrading.trading.signal_planner import SMCTradePlannerConfig, SMCV2TradePlanner
from divatrading.trading.dispatcher import (
    AutonomousDispatcherConfig, AutonomousEntryDispatcher,
    BinancePortfolioSnapshotProvider, PaperPortfolioSnapshotProvider,
)
from divatrading.strategy.scalping_market_data import InstrumentSpec
from divatrading.trading.risk import PortfolioRiskConfig, PortfolioRiskManager
from divatrading.trading.control_plane import (OperatorControlStore, TelegramControlBot, LossState, evaluate_loss_limits, enforce_bot_only_account)
from divatrading.trading.telegram_ops import TelegramOperationalNotifier
from divatrading.strategy.fixture_intake import validate_reference_fixture
from divatrading.replay import (
    DatasetQualityAuditError,
    ReplayAnalyticsError,
    WarmupConvergenceError,
    analyze_replay_ledger,
    analyze_warmup_convergence,
    write_evidence_analytics_report,
    write_warmup_convergence_report,
    HistoricalReplayRunner,
    ReplayConfig,
    ReplayDatasetManifest,
    ReplayManifestError,
    ReplayMetadataSnapshot,
    ReplayQualitySource,
    ReplayRunnerError,
    audit_replay_dataset_quality,
    audit_replay_manifest_quality,
    write_dataset_quality_report,
    ReplayWorkflowError,
    run_stage6b_workflow,
    BinanceIntakeError,
    collect_binance_um_klines_rest,
    capture_current_binance_um_metadata,
)


def _settings() -> Settings:
    return Settings.load(Path.cwd())


def _configure(settings: Settings) -> logging.Logger:
    return configure_logging(
        settings.log_dir,
        settings.log_level,
        secrets=(
            settings.binance_api_key or "",
            settings.binance_api_secret or "",
            settings.telegram_bot_token or "",
        ),
    )


def command_check(_: argparse.Namespace) -> int:
    settings = _settings()
    runtime = validate_runtime()
    logger = _configure(settings)
    logger.info("Foundation runtime check passed")
    print(f"DIVATrading Binance Bot {__version__}")
    print(f"Python: {runtime.python_version} ({runtime.bitness}-bit)")
    print(f"OS: {runtime.operating_system} {runtime.platform_release}")
    execution_config = ExecutionConfig.from_env()
    print(f"Foundation profile: {settings.trading_mode}")
    print(f"Execution mode: {execution_config.mode.value}")
    print(f"Live trading opt-in: {'SET' if settings.live_trading_enabled else 'NOT SET'}")
    print(f"Database: {settings.database_path}")
    print("Runtime check: OK")
    return 0


def command_init_db(_: argparse.Namespace) -> int:
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    database = Database(settings.database_path)
    version = database.initialize()
    database.record_event(
        "INFO", "foundation", "database_initialized", "SQLite database initialized",
        {"schema_version": version},
    )
    logger.info("SQLite initialized at schema version %s", version)
    print(f"Database initialized: {settings.database_path}")
    print(f"Schema version: {version}")
    return 0


def command_exchange_info(_: argparse.Namespace) -> int:
    """Refresh public Binance USD-M contract metadata; no credentials are used."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    database = Database(settings.database_path)
    database.initialize()
    try:
        with BinanceUsdMFuturesRestClient() as client:
            result = BinanceMetadataService(client, database).refresh()
    except Exception as exc:
        logger.exception("Binance Exchange Information refresh failed")
        print(f"ERROR: Exchange Information refresh failed: {exc}", file=sys.stderr)
        return 3
    print("Binance USD-M Exchange Information refreshed")
    print(f"Source: {result.snapshot.source_endpoint}")
    print(f"Fetched at (UTC): {result.snapshot.fetched_at_utc}")
    print(f"All contracts returned: {result.all_symbol_count}")
    print(f"Active USDT perpetual contracts: {result.tradable_symbol_count}")
    print(f"Database snapshot ID: {result.database_snapshot_id}")
    return 0


def command_instruments(args: argparse.Namespace) -> int:
    """List the most recently cached tradable USDT perpetual contracts."""
    settings = _settings()
    validate_runtime()
    database = Database(settings.database_path)
    database.initialize()
    service = BinanceMetadataService(client=None, database=database)
    snapshot = service.load_latest_cached()
    if snapshot is None:
        print("No cached Binance metadata. Run: divatrading exchange-info", file=sys.stderr)
        return 4
    resolver = SymbolResolver(snapshot)
    instruments = resolver.list_tradable()
    if args.symbol:
        try:
            selected = resolver.resolve(args.symbol)
        except (LookupError, ValueError) as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 5
        instruments = (selected,)
    print(f"Cached at (UTC): {snapshot.fetched_at_utc}")
    print(f"Source: {snapshot.source_endpoint}")
    print(f"Tradable USDT perpetual contracts: {len(resolver.list_tradable())}")
    print("SYMBOL       BASE       QUOTE   STATUS    TICK SIZE       LOT STEP       MIN NOTIONAL")
    for item in instruments[: args.limit]:
        tick = item.price_filter.tick_size if item.price_filter else None
        step = item.lot_size.step_size if item.lot_size else None
        minimum = None
        if item.notional_filter and item.notional_filter.min_notional is not None:
            minimum = item.notional_filter.min_notional
        elif item.min_notional_filter:
            minimum = item.min_notional_filter.min_notional
        print(
            f"{item.symbol:<12} {item.base_asset:<10} {item.quote_asset:<7} "
            f"{item.status:<9} {str(tick or '-'): <15} {str(step or '-'): <14} {minimum or '-'}"
        )
    return 0


def command_klines_history(args: argparse.Namespace) -> int:
    """Fetch a bounded historical Kline window using public REST only."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    try:
        with BinanceUsdMFuturesRestClient() as client:
            batch = HistoricalKlineService(
                client,
                page_limit=args.page_limit,
                max_pages=args.max_pages,
            ).fetch(
                symbol=args.symbol,
                interval=args.interval,
                start_time_ms=args.start_time_ms,
                end_time_ms=args.end_time_ms,
            )
    except Exception as exc:
        logger.exception("Binance historical Kline collection failed")
        print(f"ERROR: Historical Kline collection failed: {exc}", file=sys.stderr)
        return 6

    print("Binance USD-M historical Klines fetched")
    print(f"Symbol / interval: {batch.symbol} / {batch.interval}")
    print(f"Candles: {len(batch.candles)}")
    print(f"Pages fetched: {batch.pages_fetched}")
    print(f"Complete: {'YES' if batch.complete else 'NO — page cap reached'}")
    print(f"Missing interval opens detected: {len(batch.missing_open_times_ms)}")
    if batch.candles:
        print(f"First open (UTC): {batch.candles[0].open_time_utc.isoformat()}")
        print(f"Last open (UTC): {batch.candles[-1].open_time_utc.isoformat()}")
    if batch.next_start_time_ms is not None:
        print(f"Resume with --start-time-ms {batch.next_start_time_ms}")
    if batch.missing_open_times_ms:
        sample = ", ".join(str(value) for value in batch.missing_open_times_ms[:10])
        print(f"Missing open-time sample (ms): {sample}")
    print(f"Source: {batch.source_endpoint}")
    return 0 if batch.complete else 7



def command_validate_pine_fixture(args: argparse.Namespace) -> int:
    """Validate the fixture and the retained raw TradingView CSV exports."""
    report = validate_reference_fixture(
        args.fixture, source_dir=args.source_dir, schema_path=args.schema
    )
    print(f"Fixture: {args.fixture}")
    print(f"Fixture SHA-256: {report.fixture_sha256 or 'UNAVAILABLE'}")
    print(f"Status: {'ACCEPTED' if report.accepted else 'REJECTED'}")
    print(f"Reference signals: {report.signal_count}")
    for timeframe, count in report.candle_counts:
        print(f"Candles {timeframe}: {count}")
    for issue in report.issues:
        print(f"{issue.code} {issue.path}: {issue.message}")
    return 0 if report.accepted else 8




def command_replay_validate(args: argparse.Namespace) -> int:
    manifest = ReplayDatasetManifest.load(args.manifest)
    root = args.root or args.manifest.parent
    info = manifest.validate(root, strict_metadata=not args.allow_current_metadata)
    print("Replay dataset manifest: VALID")
    print(f"Dataset ID: {manifest.dataset_id}")
    print(f"Symbol: {manifest.symbol}")
    print(f"Intervals: {', '.join(manifest.intervals)}")
    print(f"Window (UTC open times): [{manifest.start_open_time_ms}, {manifest.end_open_time_ms})")
    print(f"Metadata quality: {manifest.metadata.quality}")
    print(f"Metadata SHA-256: {manifest.metadata.sha256}")
    print(f"Exact PRICE_FILTER tickSize: {info.price_filter.tick_size if info.price_filter else None}")
    for item in manifest.files:
        print(f"{item.interval}: {item.path} rows={item.row_count} sha256={item.sha256}")
    if manifest.metadata.quality != "HISTORICAL_EFFECTIVE":
        print("WARNING: diagnostic-only metadata; do not use for strict historical calibration")
    return 0


def command_replay_run(args: argparse.Namespace) -> int:
    manifest = ReplayDatasetManifest.load(args.manifest)
    root = args.root or args.manifest.parent
    config = ReplayConfig(
        max_history_candles=args.max_history_candles,
        include_m15="15m" in manifest.intervals,
        strict_metadata=not args.allow_current_metadata,
        checkpoint_every_captures=args.checkpoint_every_captures,
        evidence_start_time_ms=args.evidence_start_time_ms,
    )
    runner = HistoricalReplayRunner(manifest, dataset_root=root, config=config)
    summary = runner.run_to_file(
        args.ledger,
        checkpoint_path=args.checkpoint,
        resume_from_checkpoint=args.resume,
    )
    print("Historical replay complete" if args.resume is False or (args.checkpoint and json.loads(args.checkpoint.read_text(encoding="utf-8")).get("completed")) else "Historical replay checkpoint saved")
    print(f"Replay run ID: {summary.replay_run_id}")
    print(f"Dataset ID: {summary.dataset_id}")
    print(f"Captures: {summary.capture_count}")
    print(f"Data gaps: {summary.gap_count}")
    print(f"JSONL records written in this invocation: {summary.emitted_record_count}")
    print(f"Suppressed pre-roll evidence records: {summary.suppressed_pre_roll_record_count}")
    print(f"Right-censored OBs: {summary.right_censored_ob_count}")
    print(f"Right-censored FVGs: {summary.right_censored_fvg_count}")
    print(f"Ledger SHA-256: {summary.ledger_sha256}")
    return 0



def _parse_quality_source(value: str) -> tuple[str, str]:
    if "=" not in value:
        raise DatasetQualityAuditError("--source must use INTERVAL=RELATIVE_PATH")
    interval, path = value.split("=", 1)
    return interval.strip(), path.strip()


def _parse_quality_mapping(value: str, *, label: str) -> tuple[str, str]:
    if "=" not in value:
        raise DatasetQualityAuditError(f"{label} must use RELATIVE_PATH=VALUE")
    key, item = value.split("=", 1)
    return key.strip(), item.strip()


def command_replay_quality(args: argparse.Namespace) -> int:
    root = args.root or (args.manifest.parent if args.manifest else Path.cwd())
    if args.manifest:
        manifest = ReplayDatasetManifest.load(args.manifest)
        report = audit_replay_manifest_quality(
            manifest,
            dataset_root=root,
            independent_evidence_ref=args.metadata_evidence_ref,
            sample_cap=args.sample_cap,
        )
        symbol = manifest.symbol
    else:
        sources_raw = [_parse_quality_source(value) for value in args.source]
        hashes = dict(_parse_quality_mapping(value, label="--source-sha256") for value in args.source_sha256)
        row_counts = dict(_parse_quality_mapping(value, label="--source-row-count") for value in args.source_row_count)
        source_paths = {path for _, path in sources_raw}
        unknown_mapping_paths = (set(hashes) | set(row_counts)) - source_paths
        if unknown_mapping_paths:
            raise DatasetQualityAuditError(
                f"hash/row-count mapping references an undeclared source: {sorted(unknown_mapping_paths)}"
            )
        sources_list = []
        for interval, path in sources_raw:
            declared_count = None
            if path in row_counts:
                try:
                    declared_count = int(row_counts[path])
                except ValueError as exc:
                    raise DatasetQualityAuditError(
                        f"source row count for {path} must be a non-negative integer"
                    ) from exc
            sources_list.append(ReplayQualitySource(
                interval=interval,
                path=path,
                expected_sha256=hashes.get(path),
                row_count_declared=declared_count,
            ))
        sources = tuple(sources_list)
        metadata = None
        if args.metadata:
            try:
                metadata_payload = json.loads(args.metadata.read_text(encoding="utf-8"))
                metadata = ReplayMetadataSnapshot.from_dict(metadata_payload)
            except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
                raise DatasetQualityAuditError(f"cannot load metadata snapshot: {exc}") from exc
        report = audit_replay_dataset_quality(
            dataset_root=root,
            symbol=args.symbol,
            start_open_time_ms=args.start_open_time_ms,
            end_open_time_ms_exclusive=args.end_open_time_ms,
            sources=sources,
            metadata=metadata,
            independent_evidence_ref=args.metadata_evidence_ref,
            sample_cap=args.sample_cap,
        )
        symbol = args.symbol.upper()

    schema_path = args.schema or Path(__file__).resolve().parents[2] / "docs" / "schemas" / "stage6b_dataset_quality_report.schema.json"
    try:
        from jsonschema import Draft202012Validator
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(report)
    except Exception as exc:
        raise DatasetQualityAuditError(f"quality report failed schema validation: {exc}") from exc
    write_dataset_quality_report(report, args.report)
    summary = report["quality_summary"]
    print(f"Dataset quality report: {summary['quality_status']}")
    print(f"Symbol: {symbol}")
    print(f"Dataset ID: {report['dataset_id']}")
    print(f"Timeframes: {', '.join(item['interval'] for item in report['timeframes'])}")
    print(f"Strict replay eligible: {'YES' if summary['strict_replay_eligible'] else 'NO'}")
    gates = report["eligibility_gates"]
    print(f"Market-data gate: {gates['market_data']['status']} (strategy replay eligible: {'YES' if gates['market_data']['eligible_for_strategy_replay'] else 'NO'})")
    print(f"Execution-metadata gate: {gates['execution_metadata']['status']} (strict: {'YES' if gates['execution_metadata']['strict_replay_eligible'] else 'NO'})")
    print(f"Provisional strategy replay eligible: {'YES' if gates['provisional_strategy_replay_eligible'] else 'NO'}")
    print(f"Failures: {summary['failure_count']} | Warnings: {summary['warning_count']}")
    print(f"Report SHA-256: {report['report_sha256']}")
    print(f"Report: {args.report}")
    return 0 if summary["quality_status"] != "FAIL" else 9


def command_replay_analyze(args: argparse.Namespace) -> int:
    if args.split_ratios != "60/20/20":
        raise ReplayAnalyticsError("this release supports only the frozen 60/20/20 chronological split protocol")
    report = analyze_replay_ledger(args.ledger)
    schema_path = args.schema or Path(__file__).resolve().parents[2] / "docs" / "schemas" / "stage6b_evidence_analytics_report.schema.json"
    try:
        from jsonschema import Draft202012Validator
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(report)
    except Exception as exc:
        raise ReplayAnalyticsError(f"evidence analytics report failed schema validation: {exc}") from exc
    write_evidence_analytics_report(report, args.report)
    print("Replay evidence analytics completed")
    print(f"Replay run: {report['provenance']['replay_run_id']}")
    print(f"Ledger SHA-256: {report['provenance']['ledger_sha256']}")
    print(f"Alignment quantum: {report['split_plan']['alignment_quantum_ms']} ms")
    for item in report["metrics_by_split"]:
        bars = ", ".join(f"{tf}={count}" for tf, count in item["closed_bars_by_timeframe"].items())
        print(f"{item['split_label']}: {bars or 'no closed bars'} | censored OB={item['right_censored']['ob_count']} FVG={item['right_censored']['fvg_count']}")
    print(f"Report SHA-256: {report['report_sha256']}")
    print(f"Report: {args.report}")
    return 0


def command_replay_workflow(args: argparse.Namespace) -> int:
    report = run_stage6b_workflow(
        args.plan,
        args.report,
        output_dir=args.output_dir,
        plan_schema_path=args.plan_schema,
        report_schema_path=args.report_schema,
    )
    print("Integrated Stage 6B replay workflow completed")
    print(f"Symbol: {report['symbol']}")
    print(f"Trials: {len(report['trials'])}")
    print(f"Convergence comparisons: {report['convergence']['pairwise_comparison_count']}")
    print(f"Frozen code SHA-256: {report['frozen_identity']['code_sha256']}")
    print(f"Workflow report SHA-256: {report['report_sha256']}")
    print(f"Report: {args.report}")
    return 0


def command_universe(args: argparse.Namespace) -> int:
    """Discover AUTO/MANUAL eligible USDⓈ-M perpetual symbols using live 24h stats."""
    settings = _settings()
    validate_runtime()
    database = Database(settings.database_path)
    database.initialize()
    cached = BinanceMetadataService(client=None, database=database).load_latest_cached()
    if cached is None:
        print("ERROR: No cached Exchange Information. Run 'divatrading exchange-info' first.", file=sys.stderr)
        return 4
    manual = tuple(item.strip().upper() for item in (args.symbols or "").split(",") if item.strip())
    try:
        config = SymbolUniverseConfig(
            mode=args.mode,
            max_active_symbols=args.max_symbols,
            min_quote_volume_usdt=Decimal(args.min_quote_volume),
            min_trade_count_24h=args.min_trades,
            manual_symbols=manual,
            exclude_symbols=tuple(item.strip().upper() for item in (args.exclude or "").split(",") if item.strip()),
        )
        with BinanceUsdMFuturesRestClient() as client:
            tickers = client.get_ticker_24h()
        selection = SymbolUniverseSelector(config).select(cached, tickers)
    except Exception as exc:
        print(f"ERROR: Universe selection failed: {exc}", file=sys.stderr)
        return 5
    print(f"Universe mode: {selection.mode}")
    print(f"Selected symbols: {len(selection.selected)} / cap {args.max_symbols}")
    print("RANK  SYMBOL       QUOTE VOLUME 24H (USDT)      TRADES")
    for item in selection.selected:
        print(f"{item.rank:<5} {item.info.symbol:<12} {str(item.quote_volume_24h):<30} {item.trade_count_24h}")
    print(f"Rejected candidates: {len(selection.rejected)}")
    for symbol, reason in selection.rejected[:20]:
        print(f"  {symbol}: {reason}")
    print("No orders are submitted by this command.")
    return 0


def command_market_runtime(args: argparse.Namespace) -> int:
    """Run read-only Binance multi-pair feeds and deliver complete SMC V2 captures."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    database = Database(settings.database_path)
    database.initialize()
    manual = tuple(item.strip().upper() for item in (args.symbols or "").split(",") if item.strip())
    try:
        universe = SymbolUniverseConfig(
            mode=args.mode,
            max_active_symbols=args.max_symbols,
            min_quote_volume_usdt=Decimal(args.min_quote_volume),
            min_trade_count_24h=args.min_trades,
            manual_symbols=manual,
            exclude_symbols=tuple(item.strip().upper() for item in (args.exclude or "").split(",") if item.strip()),
        )
        graph_config = BinanceFeedGraphConfig(
            bootstrap_candles=args.bootstrap_candles,
            strategy_candles=args.strategy_candles,
            snapshot_interval_seconds=args.snapshot_interval,
        )
        planner = SMCV2TradePlanner(
            config=SMCTradePlannerConfig(
                entry_model=args.entry_model,
                min_candidate_score=args.min_signal_score,
                target_r_multiple=Decimal(args.target_r_multiple),
            ),
            risk_manager=PortfolioRiskManager(PortfolioRiskConfig(
                risk_per_trade_pct=Decimal(args.risk_per_trade_pct),
                max_portfolio_open_risk_pct=Decimal(args.max_portfolio_risk_pct),
            )),
        )
        publisher = None
        if args.telegram_signals:
            if not settings.telegram_bot_token or not settings.telegram_owner_id:
                raise ValueError("Set TELEGRAM_BOT_TOKEN and TELEGRAM_OWNER_ID in local .env for --telegram-signals")
            publisher = SignalTelegramPublisher(
                settings.telegram_bot_token, settings.telegram_owner_id,
                SignalPublicationStore(database),
            )
        kronos = (
            KronosShadowAdapter(
                root=Path.cwd(),
                config=KronosConfig(
                    context_bars=args.kronos_context_bars,
                    minimum_input_bars=args.kronos_minimum_input_bars,
                    horizon_bars=args.kronos_horizon_bars,
                ),
            ) if args.kronos_shadow else None
        )
        if args.kronos_shadow and not (kronos and kronos.installed_status().get("installed")):
            logger.warning("KRONOS_SHADOW_UNAVAILABLE; signal publication remains available without forecast")
        forecast_cache: dict[tuple[str, int], object] = {}
        forecast_cache_order: deque[tuple[str, int]] = deque()
        forecast_cache_lock = Lock()
        publish_seen: set[str] = set()
        publish_seen_order: deque[str] = deque()
        publish_seen_lock = Lock()
        executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="diva-signal-publisher") if publisher else None

        with BinanceUsdMFuturesRestClient() as client:
            feed_factory = BinancePublicFeedFactory(
                rest_client=client, database=database, config=graph_config,
            )

            def publish_ready(snapshot, evaluations) -> None:
                if publisher is None or executor is None:
                    return
                signals = [item for item in evaluations if item.signal is not None]
                if not signals:
                    return
                with publish_seen_lock:
                    fresh = [item for item in signals if item.signal.signal_id not in publish_seen]
                    for item in fresh:
                        signal_id = item.signal.signal_id
                        publish_seen.add(signal_id)
                        publish_seen_order.append(signal_id)
                    while len(publish_seen_order) > 5000:
                        expired = publish_seen_order.popleft()
                        publish_seen.discard(expired)
                if not fresh:
                    return

                def worker() -> None:
                    m5 = snapshot.market_view.m5.candles
                    forecast = None
                    forecast_status = "NOT_REQUESTED"
                    if kronos is not None:
                        last_open = m5[-1].open_time_ms if m5 else 0
                        cache_key = (snapshot.symbol, last_open)
                        with forecast_cache_lock:
                            cached = forecast_cache.get(cache_key)
                        if cached is not None:
                            forecast = cached
                            forecast_status = "READY"
                        else:
                            try:
                                forecast = kronos.forecast(m5, now_ms=snapshot.captured_at_ms)
                                forecast_status = "READY"
                                with forecast_cache_lock:
                                    if cache_key not in forecast_cache:
                                        forecast_cache_order.append(cache_key)
                                    forecast_cache[cache_key] = forecast
                                    while len(forecast_cache_order) > 256:
                                        expired_key = forecast_cache_order.popleft()
                                        forecast_cache.pop(expired_key, None)
                            except Exception as exc:
                                forecast_status = f"UNAVAILABLE:{type(exc).__name__}"
                                logger.warning("KRONOS_FORECAST_UNAVAILABLE symbol=%s reason=%s", snapshot.symbol, type(exc).__name__)
                    for evaluation in fresh:
                        try:
                            candidate = evaluation.candidate
                            zone = (candidate.ob.zone_bottom, candidate.ob.zone_top) if candidate else None
                            delivered = publisher.publish(
                                evaluation.signal, m5, ob_zone=zone,
                                forecast=forecast, forecast_status=forecast_status,
                            )
                            if delivered:
                                logger.info("TELEGRAM_SIGNAL_SENT signal_id=%s symbol=%s side=%s", evaluation.signal.signal_id, evaluation.signal.symbol, evaluation.signal.side)
                        except Exception as exc:
                            logger.error("TELEGRAM_SIGNAL_FAILED signal_id=%s reason=%s", evaluation.signal.signal_id, type(exc).__name__)
                executor.submit(worker)

            def on_evidence(snapshot) -> None:
                logger.info(
                    "SMC_CAPTURE symbol=%s captured_at_ms=%s active_fresh_ob=%s touched_ob=%s "
                    "fvg=%s",
                    snapshot.symbol, snapshot.captured_at_ms,
                    len(snapshot.active_fresh_order_blocks), len(snapshot.touched_order_blocks),
                    len(snapshot.liquidity_fvg.fvgs),
                )
                planned = planner.evaluate(
                    snapshot, equity_usdt=Decimal(args.paper_equity_usdt),
                    qualification_only=True,
                    qualification_defer_reason="SIGNAL_ONLY_EXECUTION_SIZING_NOT_APPLICABLE",
                )
                for evaluation in planned.evaluations:
                    logger.info("TRADE_CANDIDATE %s", json.dumps(
                        evaluation.to_dict(), sort_keys=True, separators=(",", ":"),
                    ))
                publish_ready(snapshot, planned.evaluations)

            runtime = MultiPairLiveMarketRuntime(
                rest_client=client,
                feed_factory=feed_factory,
                on_evidence=on_evidence,
                config=LiveMarketRuntimeConfig(
                    universe=universe,
                    universe_refresh_seconds=args.universe_refresh_seconds,
                    max_concurrent_workers=args.max_symbols,
                ),
            )
            print("DIVATrading multi-pair read-only SMC V2 signal runtime")
            print(f"Universe mode: {args.mode}; worker cap: {args.max_symbols}")
            print("Feeds: Kline M1/M5/M15, Mark Price, Aggregate Trades/Delta-CVD, Depth/Order Book")
            print(f"Signal qualification: {args.entry_model}; execution sizing is intentionally bypassed in SIGNAL_ONLY")
            print("Orders: DISABLED — this command is market-data/SMC only")
            print(f"Telegram SIGNAL_ONLY: {'ENABLED' if publisher else 'DISABLED'}")
            print(f"Kronos M5 shadow: {'ENABLED' if kronos else 'DISABLED'}; forecast never gates SMC")
            print("Press Ctrl+C to stop.")
            try:
                with ProcessLock(settings.log_dir / "market-runtime.lock"):
                    asyncio.run(runtime.run())
            except KeyboardInterrupt:
                logger.info("Market runtime stopped by user")
            finally:
                feed_factory.close()
                if executor is not None:
                    executor.shutdown(wait=True, cancel_futures=False)
        return 0
    except Exception as exc:
        logger.exception("Read-only multi-pair market runtime failed")
        print(f"ERROR: Market runtime failed: {exc}", file=sys.stderr)
        return 9


def _autonomous_market_endpoints(mode: ExecutionMode) -> tuple[str, str]:
    """Always select matching public REST and WebSocket market environment.

    Never mix Demo execution with production candles/mark/flow/depth; it would
    admit trades on prices that the Demo matching engine cannot guarantee.
    """
    if mode == ExecutionMode.TESTNET:
        return TESTNET_BASE_URL, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT
    return DEFAULT_BASE_URL, BINANCE_UM_MARKET_WS_ENDPOINT


def _autonomous_max_positions(mode: ExecutionMode, requested: int | None) -> int:
    if requested is None:
        return 1 if mode == ExecutionMode.LIVE else 5
    if type(requested) is not int or not 1 <= requested <= LIVE_MAX_POSITIONS:
        raise ValueError(f"--max-positions must be between 1 and {LIVE_MAX_POSITIONS}")
    return requested


def _exchange_actor_lock(service: ExecutionService, fallback: Path) -> ProcessLock:
    if service.config.mode == ExecutionMode.LIVE:
        assert service.client is not None
        return live_exchange_lock(service.client.api_key)
    return ProcessLock(fallback)


def _autonomous_planner(args: argparse.Namespace, risk_manager: PortfolioRiskManager,
                        mode: ExecutionMode):
    if args.strategy == "sweep-reclaim":
        from divatrading.trading.sweep_reclaim import SweepReclaimConfig, SweepReclaimPlanner

        return SweepReclaimPlanner(config=SweepReclaimConfig(
            require_flow_alignment=args.require_flow_alignment,
        ), risk_manager=risk_manager)
    return SMCV2TradePlanner(config=SMCTradePlannerConfig(
        entry_model=args.entry_model,
        min_candidate_score=args.min_signal_score,
        setup_timeframes=tuple(x.strip() for x in args.setup_timeframes.split(",") if x.strip()),
        max_sweep_age_bars=args.max_sweep_age_bars,
        max_fvg_age_bars=args.max_fvg_age_bars,
        max_retest_confirmation_bars=args.max_retest_confirmation_bars,
        require_flow_alignment=args.require_flow_alignment,
        target_r_multiple=Decimal(args.target_r_multiple),
        min_target_r_multiple=min(Decimal("1.5"), Decimal(args.target_r_multiple)),
        strict_structural_target_rr=mode == ExecutionMode.LIVE,
    ), risk_manager=risk_manager)


def command_autonomous_runtime(args: argparse.Namespace) -> int:
    """Run the integrated SMC -> global risk -> entry -> protected position pipeline."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    service = None
    feed_factory = None
    try:
        for label, value, maximum in (
            ("risk-per-trade-pct", args.risk_per_trade_pct, Decimal("100")),
            ("max-portfolio-risk-pct", args.max_portfolio_risk_pct, Decimal("100")),
            ("live-max-daily-loss-pct", args.live_max_daily_loss_pct, Decimal("100")),
            ("live-max-drawdown-pct", args.live_max_drawdown_pct, Decimal("100")),
        ):
            if value is None:
                continue
            number = Decimal(str(value))
            if not number.is_finite() or not Decimal("0") < number <= maximum:
                raise ValueError(f"INVALID_AUTONOMOUS_RISK_LIMIT:{label}")
        database = Database(settings.database_path)
        database.initialize()
        service = ExecutionService.from_environment(settings.database_path)
        max_positions = _autonomous_max_positions(service.config.mode, args.max_positions)
        if service.config.mode == ExecutionMode.TESTNET:
            if not service.config.enforce_entry_quote_guard:
                raise ValueError("Autonomous TESTNET order routing requires DIVA_ENFORCE_ENTRY_QUOTE_GUARD=true")
            selected_symbols = tuple(item.strip().upper() for item in (args.symbols or "").split(",") if item.strip())
            if args.mode != "MANUAL" or len(selected_symbols) != 1 or args.max_symbols != 1:
                raise ValueError("Stage C TESTNET qualification is restricted to --mode MANUAL --symbols ONE_SYMBOL --max-symbols 1")
            if Decimal(args.risk_per_trade_pct) > Decimal("0.10"):
                raise ValueError("Stage C TESTNET risk-per-trade cap is 0.10%; reduce --risk-per-trade-pct")
            if Decimal(args.max_portfolio_risk_pct) > Decimal("0.25"):
                raise ValueError("Stage C TESTNET portfolio-risk cap is 0.25%; reduce --max-portfolio-risk-pct")
            logger.warning("TESTNET_STAGE_C_ARMED symbol=%s risk_per_trade_pct=%s max_portfolio_risk_pct=%s",
                           selected_symbols[0], args.risk_per_trade_pct, args.max_portfolio_risk_pct)
        if service.config.mode == ExecutionMode.LIVE:
            # Opt-in is command-local (never persistent). No execution is permitted
            # merely by editing .env or by launching the default BAT file.
            if not args.activate_live:
                raise ValueError("LIVE_FIRST_REQUIRES_EXPLICIT_--activate-live")
            live_symbols = tuple(item.strip().upper() for item in (args.symbols or "").split(",") if item.strip())
            if args.mode == "MANUAL" and (not live_symbols or len(live_symbols) > args.max_symbols):
                raise ValueError("LIVE_MANUAL_SYMBOL_COUNT_EXCEEDS_WORKER_CAP")
            if Decimal(args.max_portfolio_risk_pct) > Decimal("20"):
                raise ValueError("LIVE_PORTFOLIO_PERCENT_RISK_CAP_20")
            if not service.config.enforce_entry_quote_guard:
                raise ValueError("LIVE_FIRST_REQUIRES_EXECUTABLE_QUOTE_GUARD")
            if not service.config.enable_protection_recovery:
                raise ValueError("LIVE_FIRST_REQUIRES_PROTECTION_RECOVERY")
            logger.warning("LIVE_OPERATOR_ACTIVATED universe=%s symbols=%s max_workers=%s REAL_FUNDS_AT_RISK",
                           args.mode, ",".join(live_symbols), args.max_symbols)
        elif args.activate_live:
            raise ValueError("--activate-live is accepted only with DIVA_EXECUTION_MODE=LIVE")
        ledger = service.ledger
        control_store = OperatorControlStore(database)
        telegram_configured = bool(settings.telegram_bot_token and settings.telegram_owner_id)
        if bool(settings.telegram_bot_token) != bool(settings.telegram_owner_id):
            raise ValueError("TELEGRAM_CONFIGURATION_INCOMPLETE: both TELEGRAM_BOT_TOKEN and TELEGRAM_OWNER_ID are required")
        telegram_notifier = (TelegramOperationalNotifier(settings.telegram_bot_token, settings.telegram_owner_id)
                             if telegram_configured else None)
        telegram_alerts = os.getenv("TELEGRAM_NOTIFY_TRADES", "true").strip().lower() in {"true", "1", "yes", "on"}
        if telegram_alerts:
            values = _parse_env_file(Path.cwd() / ".env")
            telegram_alerts = values.get("TELEGRAM_NOTIFY_TRADES", os.getenv("TELEGRAM_NOTIFY_TRADES", "true")).strip().lower() in {"true", "1", "yes", "on"}
        operator_state = control_store.get()
        persisted_risk = operator_state.get("risk", {})
        fixed_risk = (Decimal(str(persisted_risk["value"]))
                      if persisted_risk.get("mode") == "FIXED" and persisted_risk.get("value") else None)
        percent_risk = (Decimal(str(persisted_risk["value"]))
                        if persisted_risk.get("mode") == "PERCENT" and persisted_risk.get("value")
                        else Decimal(args.risk_per_trade_pct))
        risk_manager = PortfolioRiskManager(PortfolioRiskConfig(
            risk_per_trade_pct=percent_risk,
            risk_per_trade_fixed_usdt=fixed_risk,
            max_portfolio_open_risk_pct=Decimal(args.max_portfolio_risk_pct),
            max_positions=max_positions,
            leverage=3,
            max_leverage=125 if service.config.mode == ExecutionMode.LIVE else 5,
        ))
        commissioning_caps = (TestnetCommissioningCaps()
                              if service.config.mode == ExecutionMode.TESTNET else None)
        if commissioning_caps is not None:
            # Startup check is only the first gate. The coordinator also checks
            # the effective persisted risk against actual equity before any POST.
            startup_violation = commissioning_caps.violation(
                risk_manager.config, equity_usdt=None,
            )
            if startup_violation and startup_violation != "TESTNET_COMMISSIONING_FIXED_RISK_EQUITY_REQUIRED":
                raise ValueError(startup_violation)
        coordinator = MultiPairExecutionCoordinator(
            instruments={}, risk_manager=risk_manager,
            execution_service=service, ledger=ledger, allow_empty_instruments=True,
            testnet_commissioning_caps=commissioning_caps,
            live_first_caps=LiveFirstCommissioningCaps() if service.config.mode == ExecutionMode.LIVE else None,
        )
        dispatcher_config = AutonomousDispatcherConfig(
            max_signal_age_ms=args.max_signal_age_ms,
            max_snapshot_age_ms=args.max_account_snapshot_age_ms,
        )
        if service.config.mode == ExecutionMode.PAPER:
            snapshot_provider = PaperPortfolioSnapshotProvider(Decimal(args.paper_equity_usdt))
        else:
            assert service.client is not None
            snapshot_provider = BinancePortfolioSnapshotProvider(
                BinanceAccountStateService(service.client), ledger=ledger,
            )
        dispatcher = AutonomousEntryDispatcher(
            coordinator=coordinator, snapshot_provider=snapshot_provider,
            ledger=ledger, config=dispatcher_config,
        )
        planner = _autonomous_planner(args, risk_manager, service.config.mode)
        universe = SymbolUniverseConfig(
            mode=args.mode,
            max_active_symbols=args.max_symbols,
            min_quote_volume_usdt=Decimal(args.min_quote_volume),
            min_trade_count_24h=args.min_trades,
            manual_symbols=tuple(item.strip().upper() for item in (args.symbols or "").split(",") if item.strip()),
            exclude_symbols=tuple(item.strip().upper() for item in (args.exclude or "").split(",") if item.strip()),
        )
        market_rest_endpoint, market_ws_endpoint = _autonomous_market_endpoints(service.config.mode)
        graph_config = BinanceFeedGraphConfig(
            bootstrap_candles=args.bootstrap_candles,
            strategy_candles=args.strategy_candles,
            snapshot_interval_seconds=args.snapshot_interval,
            ws_endpoint=market_ws_endpoint,
        )

        account_runtime = None
        position_supervisor = None
        trade_risk_ledger = None
        trade_risk_reconciler = None
        if service.config.mode != ExecutionMode.PAPER:
            assert service.client is not None
            trade_risk_ledger = CompletedTradeRiskLedger(database)
            trade_risk_reconciler = CompletedTradeRiskReconciler(
                execution_ledger=ledger, risk_ledger=trade_risk_ledger,
            )
            stream = BinanceUserDataStreamSupervisor(client=service.client, ledger=ledger)
            trade_backfill = BinanceUserTradesBackfillService(client=service.client, ledger=ledger)
            income_backfill = BinanceIncomeHistoryBackfillService(client=service.client, ledger=ledger)
            reconciler = AccountReconciliationService(
                account_state=BinanceAccountStateService(service.client),
                ledger=ledger, execution_service=service,
                trade_backfill_service=trade_backfill,
                income_backfill_service=income_backfill,
                trade_risk_reconciler=trade_risk_reconciler,
            )
            lifecycle_adapter = PositionLifecycleExecutionAdapter(
                client=service.client, ledger=ledger,
                working_type=service.config.working_type,
                price_protect=service.config.price_protect,
                max_account_snapshot_age_ms=service.config.max_account_snapshot_age_ms,
            )
            lifecycle_reducer = PositionLifecycleFillReducer(adapter=lifecycle_adapter, ledger=ledger)
            filter_provider = _market_rules_provider(service.client.base_url)
            mark_endpoint = _mark_price_endpoint(service.config.mode.value)

            def mark_feed_factory(symbol: str):
                return BinanceMarkPriceWebSocketFeed(
                    symbols=[symbol], endpoint=mark_endpoint, max_subscriptions=1,
                    max_event_age_ms=5_000, max_reconnect_attempts=5,
                )

            position_supervisor = ManagedPositionSupervisor(
                ledger=ledger, adapter=lifecycle_adapter,
                filter_provider=filter_provider, feed_factory=mark_feed_factory,
                config=PositionSupervisorConfig(
                    max_active_symbols=16, max_mark_age_ms=5_000,
                    early_exit_protection=args.early_exit_protection,
                ),
            )
            account_runtime = ExecutionAccountRuntime(
                user_stream=stream, reconciler=reconciler, ledger=ledger,
                lifecycle_fill_reducer=lifecycle_reducer,
                position_supervisor=position_supervisor,
                enable_protection_recovery=service.config.enable_protection_recovery,
            )

        with BinanceUsdMFuturesRestClient(base_url=market_rest_endpoint) as market_client:
            feed_factory = BinancePublicFeedFactory(
                rest_client=market_client, database=database, config=graph_config,
            )

            def on_universe(selection, _metadata) -> None:
                instruments = {
                    item.info.symbol: InstrumentSpec.from_symbol_info(item.info)
                    for item in selection.selected
                }
                coordinator.update_universe(instruments)
                logger.info("AUTONOMOUS_UNIVERSE_UPDATED mode=%s symbols=%s",
                            selection.mode, ",".join(sorted(instruments)))

            async def on_evidence(snapshot) -> None:
                if args.early_exit_protection and position_supervisor is not None:
                    position_supervisor.observe_market(snapshot.market_view)
                # Telegram changes are persisted and re-read before every candidate.
                control = control_store.get()
                runtime_control = control.get("runtime", {})
                if runtime_control.get("paused") or runtime_control.get("killed"):
                    logger.warning("OPERATOR_ENTRY_GATE_CLOSED paused=%s killed=%s",
                                   runtime_control.get("paused"), runtime_control.get("killed"))
                    return
                configured_risk = control.get("risk", {})
                leverage_control = control.get("leverage", {})
                try:
                    risk_manager.config = PortfolioRiskConfig(
                    risk_per_trade_pct=(Decimal(str(configured_risk["value"]))
                                        if configured_risk.get("mode") == "PERCENT" and configured_risk.get("value")
                                        else Decimal(args.risk_per_trade_pct)),
                    risk_per_trade_fixed_usdt=(Decimal(str(configured_risk["value"]))
                                               if configured_risk.get("mode") == "FIXED" and configured_risk.get("value")
                                               else None),
                    max_portfolio_open_risk_pct=Decimal(args.max_portfolio_risk_pct),
                    max_positions=max_positions,
                    leverage=min(3, int(leverage_control.get("max", 125))),
                    max_leverage=min(int(leverage_control.get("max", 125)), 125),
                    leverage_mode=str(leverage_control.get("mode", "AUTO")).upper(),
                    slippage_reserve_bps=risk_manager.config.slippage_reserve_bps,
                    funding_reserve_bps=risk_manager.config.funding_reserve_bps,
                    fee_reserve_multiplier=risk_manager.config.fee_reserve_multiplier,
                    )
                except (ValueError, KeyError, ArithmeticError) as exc:
                    logger.error("OPERATOR_RISK_CONFIGURATION_INVALID type=%s; entries skipped", type(exc).__name__)
                    return
                planning_equity = Decimal(args.paper_equity_usdt)
                if service.config.mode != ExecutionMode.PAPER:
                    ready, reasons = ledger.execution_readiness(
                        now_ms=time.time_ns() // 1_000_000,
                        max_reconciliation_age_ms=service.config.max_account_snapshot_age_ms,
                    )
                    if not ready:
                        logger.warning("AUTONOMOUS_SIGNAL_GATE_CLOSED symbol=%s reasons=%s",
                                       snapshot.symbol, ",".join(reasons))
                        return
                    if trade_risk_ledger is None or trade_risk_reconciler is None:
                        logger.warning("AUTONOMOUS_SIGNAL_GATE_CLOSED reason=TRADE_RISK_RECONCILER_UNAVAILABLE")
                        return
                    trade_risk_state = trade_risk_ledger.snapshot(datetime.now(UTC))
                    if not trade_risk_state.reconciliation_ready:
                        logger.warning("AUTONOMOUS_SIGNAL_GATE_CLOSED reason=%s",
                                       trade_risk_state.block_reason or "TRADE_RISK_LEDGER_NOT_RECONCILED")
                        return
                    live_account = BinanceAccountStateService(service.client).capture()
                    planning_equity = live_account.equity
                    loss_settings = control.get("max_loss", {})
                    zone = ZoneInfo(str(loss_settings.get("timezone", "Asia/Jakarta")))
                    now_local = datetime.now(zone)
                    day_key = now_local.date().isoformat()
                    transfer_adjustment = trade_risk_reconciler.transfer_adjustment_usdt()
                    flow_neutral_equity = live_account.equity - transfer_adjustment
                    realized_net = trade_risk_reconciler.daily_realized_net_pnl(datetime.now(UTC))
                    floating = sum((p.unrealized_pnl for p in live_account.positions), Decimal("0"))
                    anchor = database.get_setting("daily_equity_anchor_v2", {})
                    if anchor.get("day") != day_key:
                        reconstructed_start = derive_day_start_equity(
                            flow_neutral_current_equity=flow_neutral_equity,
                            daily_realized_net_pnl=realized_net,
                            current_floating_pnl=floating,
                        )
                        anchor = {"day": day_key, "equity": str(reconstructed_start),
                                  "source": "RECONCILED_INCOME_AND_CURRENT_MARGIN_BALANCE"}
                        database.set_setting("daily_equity_anchor_v2", anchor)
                    peak = Decimal(str(database.get_setting("equity_high_watermark_flow_neutral_v1",
                                                             str(flow_neutral_equity))))
                    peak = max(peak, flow_neutral_equity)
                    database.set_setting("equity_high_watermark_flow_neutral_v1", str(peak))
                    loss_state = LossState(
                        daily_net_pnl_usdt=realized_net,
                        floating_pnl_usdt=floating,
                        consecutive_losses=trade_risk_state.consecutive_losses,
                        equity_peak_usdt=peak,
                        current_equity_usdt=flow_neutral_equity,
                        day_key=day_key,
                        day_start_equity_usdt=Decimal(str(anchor["equity"])),
                    )
                    if service.config.mode == ExecutionMode.LIVE:
                        if args.live_max_daily_loss_pct is not None:
                            live_loss_cap = Decimal(args.live_max_daily_loss_pct) / Decimal("100")
                            if realized_net + floating <= -(Decimal(str(anchor["equity"])) * live_loss_cap):
                                ledger.set_entries_halted(True, "LIVE_ADDITIONAL_DAILY_LOSS_PERCENT_LIMIT")
                                logger.error("LIVE_ADDITIONAL_DAILY_LOSS_PERCENT_LIMIT breached")
                                return
                        if args.live_max_drawdown_pct is not None:
                            peak_dd = (peak - flow_neutral_equity) / peak * Decimal("100") if peak > 0 else Decimal("100")
                            if peak_dd >= Decimal(args.live_max_drawdown_pct):
                                ledger.set_entries_halted(True, "LIVE_ADDITIONAL_EQUITY_DRAWDOWN_LIMIT")
                                logger.error("LIVE_ADDITIONAL_EQUITY_DRAWDOWN_LIMIT breached")
                                return
                    if any(loss_settings.get(k) is not None
                           for k in ("daily_value", "streak", "drawdown_pct")):
                        loss_gate = evaluate_loss_limits(control, loss_state)
                        if not loss_gate.allow_new_entries:
                            logger.warning("AUTONOMOUS_SIGNAL_GATE_CLOSED reason=%s", ",".join(loss_gate.reasons))
                            return
                planned = planner.evaluate(
                    snapshot, equity_usdt=planning_equity,
                    qualification_only=True,
                    mark_qualified_emitted=False,
                )
                qualified = tuple(
                    item.signal for item in planned.evaluations
                    if item.status == "QUALIFIED" and item.signal is not None
                )
                for evaluation in planned.evaluations:
                    if evaluation.status in {"REJECTED", "RISK_REJECTED"}:
                        logger.debug("SMC_CANDIDATE_REJECTED %s", json.dumps(
                            evaluation.to_dict(), sort_keys=True, separators=(",", ":"),
                        ))
                if qualified:
                    outcomes = await dispatcher.dispatch_signals(qualified)
                    for outcome in outcomes:
                        logger.info(
                            "AUTONOMOUS_DISPATCH signal_id=%s status=%s reason=%s duplicate=%s",
                            outcome.signal_id, outcome.status, outcome.reason, outcome.duplicate,
                        )
                        if telegram_notifier and telegram_alerts and not outcome.duplicate and outcome.status in {"DISPATCHED", "REQUIRES_RECONCILIATION"}:
                            source = next((sig for sig in qualified if sig.signal_id == outcome.signal_id), None)
                            if source is not None:
                                try:
                                    await asyncio.to_thread(telegram_notifier.notify_dispatch,
                                        symbol=source.symbol, timeframe=source.timeframe,
                                        side=source.side, status=outcome.status,
                                        reason=outcome.reason, signal_id=outcome.signal_id)
                                except Exception:
                                    logger.warning("TELEGRAM_DISPATCH_NOTIFICATION_FAILED (token redacted)")

            market_runtime = MultiPairLiveMarketRuntime(
                rest_client=market_client, feed_factory=feed_factory,
                on_evidence=on_evidence, on_universe=on_universe,
                config=LiveMarketRuntimeConfig(
                    universe=universe,
                    universe_refresh_seconds=args.universe_refresh_seconds,
                    max_concurrent_workers=args.max_symbols,
                ),
            )

            async def run_integrated() -> None:
                # A configured but non-working Telegram endpoint is a startup error.
                # When omitted entirely, Telegram is optional: only Binance keys
                # are required for trading. No Telegram token can be auto-created.
                if telegram_notifier and service.config.mode == ExecutionMode.LIVE:
                    await asyncio.to_thread(telegram_notifier.verify_connection)
                    logger.info("TELEGRAM_LIVE_PREFLIGHT_OK: private owner chat reachable")
                stop_event = asyncio.Event()
                account_task = None
                telegram_stop = Event()
                telegram_thread = None
                if settings.telegram_bot_token and settings.telegram_owner_id:
                    control_bot = TelegramControlBot(settings.telegram_bot_token,
                                                     settings.telegram_owner_id, control_store)
                    def run_control_bot() -> None:
                        while not telegram_stop.is_set():
                            try:
                                control_bot.run_forever(stop_event=telegram_stop)
                            except Exception as exc:
                                logger.error("TELEGRAM_CONTROL_CHANNEL_INTERRUPTED error_type=%s; retrying while runtime retains persisted settings",
                                             type(exc).__name__)
                                telegram_stop.wait(5.0)
                    telegram_thread = Thread(target=run_control_bot, name="diva:telegram-control", daemon=True)
                    telegram_thread.start()
                else:
                    logger.warning("TELEGRAM_CONTROL_UNAVAILABLE: local .env token/owner not configured")
                try:
                    if account_runtime is not None:
                        account_task = asyncio.create_task(
                            account_runtime.run(stop_event), name="diva:account-runtime",
                        )
                        deadline = asyncio.get_running_loop().time() + args.account_ready_timeout_seconds
                        while True:
                            if account_task.done():
                                error = account_task.exception()
                                if error:
                                    raise RuntimeError("Account runtime failed before market dispatch") from error
                                raise RuntimeError("Account runtime stopped before market dispatch")
                            ready, reasons = ledger.execution_readiness(
                                now_ms=time.time_ns() // 1_000_000,
                                max_reconciliation_age_ms=service.config.max_account_snapshot_age_ms,
                            )
                            risk_ready = False
                            risk_reasons = ("TRADE_RISK_LEDGER_NOT_RECONCILED",)
                            if trade_risk_ledger is not None:
                                risk_snapshot = trade_risk_ledger.snapshot(datetime.now(UTC))
                                risk_ready = risk_snapshot.reconciliation_ready
                                risk_reasons = () if risk_ready else (risk_snapshot.block_reason or "TRADE_RISK_LEDGER_NOT_RECONCILED",)
                            ready = ready and risk_ready
                            if ready:
                                # Dedicated BOT_ONLY account policy: any exchange position or
                                # open order without exact local ownership halts startup.
                                account_snapshot = BinanceAccountStateService(service.client).capture()
                                exchange_positions = [
                                    {"symbol": p.symbol, "positionSide": p.position_side,
                                     "positionAmt": str(p.quantity)}
                                    for p in account_snapshot.positions
                                ]
                                managed_positions = ledger.list_managed_positions(status="OPEN")
                                bot_only_ok, bot_only_reasons = enforce_bot_only_account(
                                    exchange_positions=exchange_positions,
                                    managed_positions=managed_positions,
                                    open_standard_orders=account_snapshot.open_standard_orders,
                                    open_algo_orders=account_snapshot.open_algo_orders,
                                    managed_orders=ledger.list_all_execution_orders(),
                                )
                                if not bot_only_ok:
                                    ledger.set_entries_halted(True, "BOT_ONLY_EXTERNAL_EXPOSURE_OR_ORDER")
                                    raise RuntimeError("BOT_ONLY account isolation failed: " + ",".join(bot_only_reasons))
                                break
                            if asyncio.get_running_loop().time() >= deadline:
                                raise TimeoutError(
                                    "LIVE/TESTNET account stream/reconciliation not ready: " + ",".join((*reasons, *risk_reasons))
                                )
                            await asyncio.sleep(0.5)
                    if account_task is None:
                        await market_runtime.run(stop_event)
                    else:
                        await run_with_account_supervision(
                            market_runtime.run, account_task, stop_event,
                            lambda reason: ledger.set_entries_halted(True, reason),
                        )
                finally:
                    stop_event.set()
                    telegram_stop.set()
                    if telegram_thread is not None:
                        telegram_thread.join(timeout=2.0)
                    if account_task is not None:
                        try:
                            await account_task
                        except asyncio.CancelledError:
                            pass
                        except Exception:
                            logger.exception("Integrated account runtime stopped with an error")

            print("DIVATrading autonomous SMC-to-entry runtime")
            print(f"Execution mode: {service.config.mode.value}")
            print(f"Universe: {args.mode}; active pair cap: {args.max_symbols}")
            print(f"Strategy: {args.strategy}; near-TP order-flow exit: {args.early_exit_protection and position_supervisor is not None}")
            print("Pipeline: SMC V2 -> durable dispatch -> fresh account snapshot -> global risk -> idempotent entry -> fill/protection -> position supervisor")
            if service.config.mode == ExecutionMode.PAPER:
                print(f"PAPER equity: {args.paper_equity_usdt} USDT; simulated fills: {service.config.paper_simulate_fills}")
            elif service.config.mode == ExecutionMode.TESTNET:
                print("TESTNET Stage C: one manual symbol; risk <=0.10% per trade and <=0.25% portfolio")
                print("DEMO market + signed exchange environment matched")
            else:
                print("WARNING: LIVE FIRST operator opt-in; real order placement is enabled, NOT exchange-validated")
                if fixed_risk is not None:
                    risk_description = f"{fixed_risk} USDT per trade"
                else:
                    risk_description = f"{percent_risk}% equity per trade"
                print(f"LIVE: up to {max_positions} simultaneous managed positions, including pending entries.")
                print(f"LIVE selected risk: {risk_description}.")
                print("Account, market quote and protection readiness remain mandatory")
            print("Default: no order is submitted before a qualifying SMC signal and all risk/readiness checks")
            print("Press Ctrl+C to stop.")
            try:
                with _exchange_actor_lock(service, settings.log_dir / "autonomous-runtime.lock"):
                    asyncio.run(run_integrated())
            except KeyboardInterrupt:
                logger.info("Autonomous trading runtime stopped by operator")
            finally:
                feed_factory.close()
        return 0
    except Exception as exc:
        logger.exception("Autonomous SMC-to-entry runtime failed")
        print(f"ERROR: autonomous runtime failed: {exc}", file=sys.stderr)
        return 9
    finally:
        if service is not None and service.client is not None:
            service.client.close()


def command_signal_history(args: argparse.Namespace) -> int:
    settings = _settings()
    database = Database(settings.database_path)
    database.initialize()
    rows = SignalPublicationStore(database).history(limit=args.limit)
    print(json.dumps(rows, indent=2, sort_keys=True))
    return 0


def command_kronos_status(_: argparse.Namespace) -> int:
    """Report optional Kronos model installation status without importing torch."""
    status = KronosShadowAdapter(root=Path.cwd()).installed_status()
    print(json.dumps(status, indent=2, sort_keys=True))
    return 0 if status.get("installed") else 2


def command_kronos_install(args: argparse.Namespace) -> int:
    """Explicitly install Kronos-mini CPU runtime, source and Hugging Face snapshots."""
    validate_runtime()
    try:
        manifest = install_kronos(Path.cwd(), install_dependencies=not args.no_install_dependencies)
    except KronosInstallError as exc:
        print(f"ERROR: Kronos installation failed: {exc}", file=sys.stderr)
        return 4
    print("Kronos-mini installed successfully (CPU-only shadow mode)")
    print(f"Source commit: {manifest['source_commit']}")
    print(f"Model revision: {manifest['model_revision']}")
    print(f"Tokenizer revision: {manifest['tokenizer_revision']}")
    print("Model weights are stored under .kronos/ and are not part of the DIVATrading ZIP.")
    return 0


def command_kronos_evaluate(args: argparse.Namespace) -> int:
    """Evaluate a stored shadow forecast against later closed M5 candles in the local DB."""
    settings = _settings()
    database = Database(settings.database_path)
    database.initialize()
    store = SignalPublicationStore(database)
    stored = store.forecast(args.forecast_id)
    if stored is None:
        print("ERROR: forecast_id not found in local signal ledger", file=sys.stderr)
        return 2
    from divatrading.intelligence.kronos import KronosForecast, KronosForecastBar
    from datetime import UTC, datetime
    from decimal import Decimal
    try:
        raw = stored["forecast"]
        forecast = KronosForecast(
            forecast_id=raw["forecast_id"], symbol=raw["symbol"], interval=raw["interval"],
            created_at_utc=raw["created_at_utc"], model_repo=raw["model_repo"],
            tokenizer_repo=raw["tokenizer_repo"], source_commit=raw["source_commit"],
            model_revision=raw["model_revision"], tokenizer_revision=raw["tokenizer_revision"],
            input_bars=raw["input_bars"], context_bars=raw["context_bars"],
            horizon_bars=raw["horizon_bars"], last_observed_open_time_ms=raw["last_observed_open_time_ms"],
            last_observed_close=Decimal(raw["last_observed_close"]),
            projected_close=Decimal(raw["projected_close"]),
            projected_return_pct=Decimal(raw["projected_return_pct"]), direction=raw["direction"],
            forecast_bars=tuple(KronosForecastBar(
                open_time_ms=item["open_time_ms"], open=Decimal(item["open"]),
                high=Decimal(item["high"]), low=Decimal(item["low"]), close=Decimal(item["close"]),
                volume=Decimal(item["volume"]), amount=Decimal(item["amount"]),
            ) for item in raw["forecast_bars"]),
        )
        now_ms = int(time.time_ns() // 1_000_000)
        start_open = forecast.forecast_bars[0].open_time_ms
        end_open = forecast.forecast_bars[-1].open_time_ms
        with database.connection() as connection:
            rows = connection.execute(
                """SELECT * FROM market_klines WHERE exchange='BINANCE_UM' AND symbol=?
                   AND interval='5m' AND open_time_ms BETWEEN ? AND ?
                   AND close_time_ms < ? ORDER BY open_time_ms ASC""",
                (forecast.symbol, start_open, end_open, now_ms),
            ).fetchall()
        actual = tuple(Kline(
            exchange=row["exchange"], symbol=row["symbol"], interval=row["interval"],
            open_time_ms=int(row["open_time_ms"]), open=Decimal(row["open"]),
            high=Decimal(row["high"]), low=Decimal(row["low"]), close=Decimal(row["close"]),
            volume=Decimal(row["volume"]), close_time_ms=int(row["close_time_ms"]),
            quote_asset_volume=Decimal(row["quote_asset_volume"]), trade_count=int(row["trade_count"]),
            taker_buy_base_volume=Decimal(row["taker_buy_base_volume"]),
            taker_buy_quote_volume=Decimal(row["taker_buy_quote_volume"]),
            ignore_value=row["ignore_value"], source_endpoint=row["source_endpoint"],
        ) for row in rows)
        result = evaluate_kronos_forecast(forecast, actual)
    except Exception as exc:
        print(f"WAITING_OR_INVALID: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 4
    store.save_evaluation(args.forecast_id, result.to_dict())
    print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
    print("Note: forecast metrics only; not strategy PnL, fill quality, or profitability proof.")
    return 0


def command_kronos_forecast(args: argparse.Namespace) -> int:
    """Generate one optional M5 Kronos shadow forecast from public Binance candles."""
    settings = _settings()
    validate_runtime()
    adapter = KronosShadowAdapter(
        root=Path.cwd(),
        config=KronosConfig(
            context_bars=args.context_bars,
            minimum_input_bars=args.minimum_input_bars,
            horizon_bars=args.horizon_bars,
        ),
    )
    if not adapter.installed_status().get("installed"):
        print("Kronos-mini is not installed. Run: python -m divatrading kronos-install", file=sys.stderr)
        return 3
    now_ms = int(time.time_ns() // 1_000_000)
    start_ms = now_ms - args.context_bars * INTERVAL_MILLISECONDS["5m"]
    try:
        with BinanceUsdMFuturesRestClient() as client:
            raw = client.get_klines(
                symbol=args.symbol, interval="5m", start_time_ms=start_ms,
                end_time_ms=now_ms, limit=min(1500, args.context_bars + 5),
            )
        candles = tuple(
            item for item in (
                Kline.from_binance_row(
                    row, symbol=args.symbol, interval="5m", source_endpoint="/fapi/v1/klines",
                ) for row in raw
            ) if item.close_time_ms < now_ms
        )
        forecast = adapter.forecast(candles, horizon_bars=args.horizon_bars, now_ms=now_ms)
    except Exception as exc:
        print(f"ERROR: Kronos forecast failed ({type(exc).__name__}): {exc}", file=sys.stderr)
        return 5
    print(json.dumps(forecast.to_dict(), indent=2, sort_keys=True))
    return 0


def command_telegram_check(_: argparse.Namespace) -> int:
    """Telegram-only live-network GET checks; no Binance signed requests or orders."""
    settings = _settings()
    if not settings.telegram_bot_token or not settings.telegram_owner_id:
        print("TELEGRAM_NOT_CONFIGURED: set TELEGRAM_BOT_TOKEN and TELEGRAM_OWNER_ID in .env", file=sys.stderr)
        return 2
    try:
        report = TelegramOperationalNotifier(settings.telegram_bot_token, settings.telegram_owner_id).verify_connection()
        print(json.dumps(report, ensure_ascii=False, sort_keys=True))
        return 0
    except Exception as exc:
        print(f"TELEGRAM_CHECK_FAILED: {type(exc).__name__} (token redacted)", file=sys.stderr)
        return 2


def command_telegram_control(_: argparse.Namespace) -> int:
    """Run owner-authenticated Telegram long-polling control plane."""
    settings = _settings()
    validate_runtime()
    if not settings.telegram_bot_token or not settings.telegram_owner_id:
        raise ValueError("Set TELEGRAM_BOT_TOKEN and TELEGRAM_OWNER_ID in local .env")
    database = Database(settings.database_path)
    store = OperatorControlStore(database)
    bot = TelegramControlBot(settings.telegram_bot_token, settings.telegram_owner_id, store)
    print("DIVATrading Telegram Control Center running (long polling; owner-only). Ctrl+C to stop.")
    bot.run_forever()
    return 0


def command_risk_config(args: argparse.Namespace) -> int:
    """Read or update the selected local operator risk profile."""
    if (args.mode is None) != (args.value is None):
        print("ERROR: --mode and --value must be provided together.", file=sys.stderr)
        return 2
    settings = _settings()
    store = OperatorControlStore(Database(settings.database_path))
    try:
        state = store.get() if args.mode is None else store.set_risk(args.mode, args.value)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({
        "database_path": str(settings.database_path),
        "risk": state["risk"],
    }, sort_keys=True))
    return 0


def command_status(_: argparse.Namespace) -> int:
    settings = _settings()
    validate_runtime()
    database = Database(settings.database_path)
    version = database.schema_version()
    print(f"Application version: {__version__}")
    execution_config = ExecutionConfig.from_env()
    print(f"Foundation profile: {settings.trading_mode}")
    print(f"Execution mode: {execution_config.mode.value}")
    print(f"Live trading opt-in: {'SET' if settings.live_trading_enabled else 'NOT SET'}")
    print(f"Database exists: {'YES' if settings.database_path.exists() else 'NO'}")
    print(f"Database schema: {version}")
    print("Auto-trading core: AVAILABLE (universe selector, risk sizing, signed REST, idempotent execution ledger)")
    print("Exchange metadata: READ-ONLY provider; run 'divatrading exchange-info'")
    print("Historical Klines: READ-ONLY provider; run 'divatrading klines-history --help'")
    print("Mark Price: READ-ONLY WebSocket service; consume BinanceMarkPriceWebSocketFeed from divatrading.market_data")
    print("Aggregate Trades: READ-ONLY WebSocket + REST persistence/recovery services")
    print("Delta/CVD: continuity-aware Decimal aggregation service; see docs/ORDER_FLOW_GUIDE.md")
    print("Autonomous SMC-to-entry runtime: AVAILABLE via auto-trade-runtime (PAPER default; LIVE operator opt-in)")
    print("Execution defaults: PAPER; TESTNET/LIVE require explicit local opt-in")
    return 0


def command_runtime_status(args: argparse.Namespace) -> int:
    """Print a read-only local operational snapshot from the execution ledger."""
    settings = _settings()
    validate_runtime()
    service = ExecutionService.from_environment(settings.database_path)
    try:
        snapshot = operator_status(service.ledger)
        print(json.dumps(snapshot, indent=2, sort_keys=True, default=str))
        return 0
    finally:
        if service.client is not None:
            service.client.close()


def command_replay_convergence(args: argparse.Namespace) -> int:
    report = analyze_warmup_convergence(args.plan)
    write_warmup_convergence_report(report, args.report, args.schema)
    print("Replay warm-up convergence comparison completed")
    print(f"Symbol: {report['symbol']}")
    print(f"Trials: {len(report['trials'])} ({report['comparison_mode']})")
    print(f"Pairwise comparisons: {len(report['comparisons'])}")
    print(f"Frozen identity SHA-256: {report['frozen_identity']['identity_sha256']}")
    print(f"Report SHA-256: {report['report_sha256']}")
    print(f"Report: {args.report}")
    return 0



def command_binance_rest_kline_intake(args: argparse.Namespace) -> int:
    """Retain public REST Kline response pages and a derived native CSV."""
    validate_runtime()
    try:
        with BinanceUsdMFuturesRestClient() as client:
            result = collect_binance_um_klines_rest(
                symbol=args.symbol,
                interval=args.interval,
                start_open_time_ms=args.start_open_time_ms,
                end_open_time_ms_exclusive=args.end_open_time_ms_exclusive,
                dataset_root=args.dataset_root,
                capture_id=args.capture_id,
                page_limit=args.page_limit,
                max_pages=args.max_pages,
                request_interval_seconds=args.request_interval_seconds,
                client=client,
            )
    except (BinanceIntakeError, OSError, ValueError) as exc:
        print(f"ERROR: Binance REST Kline intake failed: {exc}", file=sys.stderr)
        return 6

    print("Binance USD-M REST Kline intake completed")
    print(f"Symbol / interval: {result.symbol} / {result.interval}")
    print(f"Capture ID: {result.capture_id}")
    print(f"Rows / pages: {result.row_count} / {result.page_count}")
    print(f"API window fully paginated: {'YES' if result.complete else 'NO — page cap reached'}")
    print(f"Detected missing interval count: {result.gap_count}")
    if result.gap_sample_open_times_ms:
        print(f"Missing open-time sample (ms): {', '.join(map(str, result.gap_sample_open_times_ms[:10]))}")
    print(f"Raw capture: {result.raw_capture_dir}")
    print(f"Raw page index: {result.pages_index_path}")
    print(f"Derived CSV: {result.csv_path}")
    print(f"Derived CSV SHA-256: {result.derived_csv_sha256}")
    print(f"Provenance: {result.provenance_path}")
    print("Source response bytes retained unchanged; missing candles were not synthesized.")
    return 0 if result.complete else 7


def command_binance_current_metadata(args: argparse.Namespace) -> int:
    """Capture current metadata for diagnostics, never as historical effectiveness evidence."""
    validate_runtime()
    try:
        result = capture_current_binance_um_metadata(
            symbol=args.symbol,
            output_dir=args.output_dir,
            timeout=args.timeout,
            attempts=args.attempts,
        )
    except (BinanceIntakeError, OSError, ValueError) as exc:
        print(f"ERROR: Binance metadata capture failed: {exc}", file=sys.stderr)
        return 6
    print("Binance USD-M current metadata retained")
    print(f"Symbol: {result.symbol}")
    print(f"Current tickSize: {result.tick_size}")
    print(f"Binance server time (ms): {result.server_time_ms}")
    print(f"Raw exchangeInfo SHA-256: {result.raw_exchange_info_sha256}")
    print(f"Symbol snapshot SHA-256: {result.snapshot_sha256}")
    print(f"Raw response: {result.raw_exchange_info_path}")
    print(f"Replay snapshot: {result.replay_snapshot_path}")
    print(f"Provenance: {result.provenance_path}")
    print("Metadata quality: CURRENT_SNAPSHOT_ONLY")
    print("Strict historical calibration eligibility: NO")
    return 0

def _market_rules_provider(base_url: str):
    """Fetch one verified Exchange Information snapshot for lifecycle order filters."""
    with BinanceUsdMFuturesRestClient(base_url=base_url) as public_client:
        payload = public_client.get_exchange_info()
        snapshot = parse_exchange_info(
            payload, source_endpoint=public_client.exchange_info_endpoint
        )
    by_symbol = {item.symbol: item for item in snapshot.symbols}

    def rules_for(symbol: str) -> dict[str, Decimal]:
        info = by_symbol.get(symbol.strip().upper())
        if info is None or not info.is_tradable_usdt_perpetual:
            raise RuntimeError(f"No active USDT perpetual metadata for {symbol}")
        quantity_filter = info.market_lot_size
        if (quantity_filter is None or quantity_filter.step_size is None
                or quantity_filter.step_size <= 0 or quantity_filter.min_qty is None
                or quantity_filter.min_qty <= 0):
            quantity_filter = info.lot_size
        if (quantity_filter is None or quantity_filter.step_size is None
                or quantity_filter.step_size <= 0 or quantity_filter.min_qty is None
                or quantity_filter.min_qty <= 0):
            raise RuntimeError(f"Missing valid market quantity filters for {symbol}")
        if info.price_filter is None or info.price_filter.tick_size is None or info.price_filter.tick_size <= 0:
            raise RuntimeError(f"Missing valid PRICE_FILTER tickSize for {symbol}")
        return {
            "market_step_size": quantity_filter.step_size,
            "market_min_qty": quantity_filter.min_qty,
            "tick_size": info.price_filter.tick_size,
        }

    return rules_for


def _mark_price_endpoint(environment: str) -> str:
    """Select the matching USD-M public market-stream endpoint.

    DIVA_MARK_PRICE_WS_ENDPOINT can override the endpoint in a controlled deployment.
    TESTNET uses Binance Demo Trading's dedicated Futures market stream host.
    """
    import os
    override = os.environ.get("DIVA_MARK_PRICE_WS_ENDPOINT", "").strip()
    if override:
        if not override.startswith("wss://"):
            raise ValueError("DIVA_MARK_PRICE_WS_ENDPOINT must start with wss://")
        return override
    if environment == "TESTNET":
        return BINANCE_UM_DEMO_MARKET_WS_ENDPOINT
    return BINANCE_UM_MARKET_WS_ENDPOINT


def command_account_runtime(_: argparse.Namespace) -> int:
    """Run private User Data Stream and account reconciliation (no new entry signals)."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    service = None
    try:
        service = ExecutionService.from_environment(settings.database_path)
        if service.config.mode == ExecutionMode.PAPER:
            raise ValueError("account-runtime requires DIVA_EXECUTION_MODE=TESTNET or LIVE")
        assert service.client is not None
        ledger = service.ledger
        stream = BinanceUserDataStreamSupervisor(client=service.client, ledger=ledger)
        trade_backfill = BinanceUserTradesBackfillService(
            client=service.client, ledger=ledger,
        )
        reconciler = AccountReconciliationService(
            account_state=BinanceAccountStateService(service.client),
            ledger=ledger,
            execution_service=service,
            trade_backfill_service=trade_backfill,
        )
        lifecycle_adapter = PositionLifecycleExecutionAdapter(
            client=service.client, ledger=ledger,
            working_type=service.config.working_type,
            price_protect=service.config.price_protect,
            max_account_snapshot_age_ms=service.config.max_account_snapshot_age_ms,
        )
        lifecycle_reducer = PositionLifecycleFillReducer(adapter=lifecycle_adapter, ledger=ledger)
        filter_provider = _market_rules_provider(service.client.base_url)
        mark_endpoint = _mark_price_endpoint(service.config.mode.value)

        def mark_feed_factory(symbol: str):
            return BinanceMarkPriceWebSocketFeed(
                symbols=[symbol], endpoint=mark_endpoint, max_subscriptions=1,
                max_event_age_ms=5_000, max_reconnect_attempts=5,
            )

        position_supervisor = ManagedPositionSupervisor(
            ledger=ledger, adapter=lifecycle_adapter, filter_provider=filter_provider,
            feed_factory=mark_feed_factory,
            config=PositionSupervisorConfig(max_active_symbols=16, max_mark_age_ms=5_000),
        )
        runtime = ExecutionAccountRuntime(
            user_stream=stream, reconciler=reconciler, ledger=ledger,
            lifecycle_fill_reducer=lifecycle_reducer,
            position_supervisor=position_supervisor,
            enable_protection_recovery=service.config.enable_protection_recovery,
        )
        print(f"DIVATrading account runtime started: {service.config.mode.value}")
        print("Runtime supervises account events, REST trade-history backfill, reconciliation, Mark Price and managed-position lifecycle actions.")
        print("Press Ctrl+C to stop. A fresh stream and reconciliation are required before TESTNET/LIVE entries.")
        with _exchange_actor_lock(service, settings.log_dir / "account-runtime.lock"):
            asyncio.run(runtime.run(asyncio.Event()))
        return 0
    except KeyboardInterrupt:
        print("Account runtime stopped by operator.")
        return 0
    except Exception as exc:
        logger.exception("Account runtime failed")
        print(f"ERROR: account runtime failed: {exc}", file=sys.stderr)
        return 9
    finally:
        if service is not None and service.client is not None:
            service.client.close()


def command_testnet_order_test(args: argparse.Namespace) -> int:
    """Validate one signed LIMIT/MARKET request on the Demo test-order endpoint."""
    root = Path.cwd()
    values = _parse_env_file(root / ".env")
    values.update(dict(os.environ))
    mode = values.get("DIVA_EXECUTION_MODE", "PAPER").strip().upper()
    live_enabled = values.get("DIVA_LIVE_TRADING_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
    test_order_enabled = values.get("DIVA_ENABLE_TESTNET_ORDER_TEST", "false").strip().lower() in {"1", "true", "yes", "on"}
    actual_testnet_orders_enabled = values.get("DIVA_ENABLE_TESTNET_ORDERS", "false").strip().lower() in {"1", "true", "yes", "on"}
    api_key = values.get("BINANCE_API_KEY", "")
    api_secret = values.get("BINANCE_API_SECRET", "")
    base = {
        "environment": "TESTNET",
        "endpoint": f"{TESTNET_BASE_URL}/fapi/v1/order/test",
        "matching_engine_submission": False,
        "order_created": False,
        "actual_execution": False,
    }
    if mode != "TESTNET" or live_enabled or actual_testnet_orders_enabled:
        print(json.dumps({**base, "status": "BLOCKED_CONFIGURATION",
                          "reason": "Set DIVA_EXECUTION_MODE=TESTNET; keep DIVA_ENABLE_TESTNET_ORDERS=false and DIVA_LIVE_TRADING_ENABLED=false"}, indent=2))
        return 2
    if not test_order_enabled or not args.confirm_test_order:
        print(json.dumps({**base, "status": "BLOCKED_EXPLICIT_OPT_IN",
                          "reason": "Set DIVA_ENABLE_TESTNET_ORDER_TEST=true locally and pass --confirm-test-order"}, indent=2))
        return 2
    if not api_key or not api_secret:
        print(json.dumps({**base, "status": "BLOCKED_CREDENTIALS",
                          "reason": "BINANCE_API_KEY and BINANCE_API_SECRET must be configured locally in .env"}, indent=2))
        return 2

    client = BinancePrivateRestClient(api_key, api_secret, environment="TESTNET")
    try:
        # Stage A is rerun immediately before the test-order request. It must
        # prove endpoint isolation, signed account reads and a clean account.
        preflight = BinanceTestnetPreflight(client, symbols=(args.symbol,)).run()
        if not preflight.ready_for_test_order:
            print(json.dumps({**base, "status": "BLOCKED_PREFLIGHT",
                              "preflight_status": preflight.status,
                              "failed_checks": [
                                  {"code": check.code, "status": check.status}
                                  for check in preflight.checks if check.status == "FAIL"
                              ]}, indent=2, sort_keys=True))
            return 2

        snapshot = parse_exchange_info(
            client.get_exchange_info(),
            source_endpoint=f"{TESTNET_BASE_URL}/fapi/v1/exchangeInfo",
        )
        symbol_info = snapshot.get_symbol(args.symbol.strip().upper())
        if symbol_info is None:
            raise TestOrderValidationError("symbol is not present in current Demo exchange metadata")
        instrument = InstrumentSpec.from_symbol_info(symbol_info)
        position_mode_payload = client.get_position_mode()
        dual_side_raw = position_mode_payload.get("dualSidePosition")
        if isinstance(dual_side_raw, bool):
            dual_side = dual_side_raw
        elif isinstance(dual_side_raw, str) and dual_side_raw.strip().lower() in {"true", "false"}:
            dual_side = dual_side_raw.strip().lower() == "true"
        else:
            dual_side = None
        if dual_side is None:
            raise TestOrderValidationError("could not establish current account position mode")
        position_mode = "HEDGE" if dual_side else "ONE_WAY"

        spec = TestOrderSpec(
            symbol=args.symbol, side=args.side, order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
            time_in_force=args.time_in_force if args.order_type == "LIMIT" else None,
            position_mode=position_mode, position_side=args.position_side,
        )
        prepared = prepare_test_order(spec, instrument)
        started = time.monotonic_ns()
        try:
            response = client.new_test_order(**prepared.params)
        except BinancePrivateApiError as exc:
            rejected = (exc.code is not None and exc.code < 0) or 400 <= exc.status_code < 500
            print(json.dumps({**base, "status": "EXCHANGE_REJECTED" if rejected else "EXCHANGE_RESPONSE_ERROR",
                              "http_status": exc.status_code, "exchange_code": exc.code,
                              "endpoint_path": exc.endpoint, "request": prepared.summary(),
                              "automatic_retry": False,
                              "preflight_status": preflight.status}, indent=2, sort_keys=True))
            return 3 if rejected else 4
        except BinancePrivateTransportError as exc:
            print(json.dumps({**base, "status": "TEST_ORDER_TRANSPORT_UNCONFIRMED",
                              "error_type": type(exc).__name__,
                              "endpoint_path": "/fapi/v1/order/test",
                              "request": prepared.summary(),
                              "automatic_retry": False}, indent=2, sort_keys=True))
            return 4
        latency_ms = (time.monotonic_ns() - started) / 1_000_000
        response_keys = sorted(response.keys()) if isinstance(response, dict) else []
        print(json.dumps({**base, "status": "TEST_ORDER_ACCEPTED",
                          "validation_only": True, "trade_permission_validated": True,
                          "symbol": args.symbol.strip().upper(),
                          "position_mode": position_mode,
                          "request": prepared.summary(),
                          "submitted_at_ms": time.time_ns() // 1_000_000,
                          "latency_ms": round(latency_ms, 3),
                          "response_field_names": response_keys,
                          "automatic_retry": False,
                          "preflight_status": preflight.status}, indent=2, sort_keys=True))
        return 0
    except (TestOrderValidationError, ValueError) as exc:
        print(json.dumps({**base, "status": "BLOCKED_ORDER_PARAMETERS",
                          "reason": str(exc)}, indent=2, sort_keys=True))
        return 2
    except Exception as exc:
        # Do not surface arbitrary exception strings: some HTTP libraries
        # embed full request URLs, which may contain signatures.
        print(json.dumps({**base, "status": "TEST_ORDER_FAILED",
                          "error_type": type(exc).__name__}, indent=2, sort_keys=True))
        return 5
    finally:
        client.close()


def command_testnet_preflight(args: argparse.Namespace) -> int:
    """Run a read-only TESTNET environment/account preflight; never sends orders."""
    root = Path.cwd()
    values = _parse_env_file(root / ".env")
    values.update(dict(os.environ))
    mode = values.get("DIVA_EXECUTION_MODE", "PAPER").strip().upper()
    live_enabled = values.get("DIVA_LIVE_TRADING_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
    api_key = values.get("BINANCE_API_KEY", "")
    api_secret = values.get("BINANCE_API_SECRET", "")
    if mode != "TESTNET" or live_enabled:
        print(json.dumps({
            "status": "BLOCKED_CONFIGURATION",
            "reason": "Set DIVA_EXECUTION_MODE=TESTNET and keep DIVA_LIVE_TRADING_ENABLED=false",
            "order_submission_performed": False,
        }, indent=2))
        return 2
    if not api_key or not api_secret:
        print(json.dumps({
            "status": "BLOCKED_CREDENTIALS",
            "reason": "BINANCE_API_KEY and BINANCE_API_SECRET must be configured locally in .env",
            "order_submission_performed": False,
        }, indent=2))
        return 2
    symbols = tuple(part.strip().upper() for part in args.symbols.split(",") if part.strip())
    client = BinancePrivateRestClient(api_key, api_secret, environment="TESTNET")
    try:
        report = BinanceTestnetPreflight(client, symbols=symbols).run()
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
        return 0 if report.ready_for_test_order else 2
    except Exception as exc:
        print(json.dumps({
            "status": "BLOCKED_PREFLIGHT_EXCEPTION",
            "reason": type(exc).__name__,
            "order_submission_performed": False,
        }, indent=2))
        return 2
    finally:
        client.close()


def command_live_read_only_preflight(args: argparse.Namespace) -> int:
    """Read-only LIVE account/metadata inspection; never sends orders or changes settings."""
    root = Path.cwd()
    values = _parse_env_file(root / ".env")
    values.update(dict(os.environ))
    mode = values.get("DIVA_EXECUTION_MODE", "PAPER").strip().upper()
    live_enabled = values.get("DIVA_LIVE_TRADING_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
    if mode != "LIVE" or live_enabled:
        print(json.dumps({"status": "BLOCKED_CONFIGURATION", "reason": "Set DIVA_EXECUTION_MODE=LIVE and keep DIVA_LIVE_TRADING_ENABLED=false; this command is read-only", "order_submission_performed": False, "account_mutation_performed": False}, indent=2))
        return 2
    if values.get("DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT", "false").strip().lower() not in {"1", "true", "yes", "on"}:
        print(json.dumps({"status": "BLOCKED_OPT_IN", "reason": "Set DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true locally to authorize read-only account inspection", "order_submission_performed": False, "account_mutation_performed": False}, indent=2))
        return 2
    api_key, api_secret = values.get("BINANCE_API_KEY", ""), values.get("BINANCE_API_SECRET", "")
    if not api_key or not api_secret:
        print(json.dumps({"status": "BLOCKED_CREDENTIALS", "reason": "Local Binance API credentials are required", "order_submission_performed": False, "account_mutation_performed": False}, indent=2))
        return 2
    symbols = tuple(x.strip().upper() for x in args.symbols.split(",") if x.strip())
    client = BinancePrivateRestClient(api_key, api_secret, environment="LIVE")
    try:
        report = BinanceLiveReadOnlyPreflight(client, symbols=symbols).run()
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
        return 0 if report.ready_for_next_stage else 2
    except Exception as exc:
        print(json.dumps({"status": "BLOCKED_LIVE_PREFLIGHT_EXCEPTION", "error_type": type(exc).__name__, "order_submission_performed": False, "account_mutation_performed": False}, indent=2))
        return 2
    finally:
        client.close()


def command_emergency_close(args: argparse.Namespace) -> int:
    """Submit one explicitly confirmed managed-position emergency market close."""
    settings = _settings()
    validate_runtime()
    logger = _configure(settings)
    service = None
    try:
        if args.confirm != "CLOSE DIVA POSITION":
            raise ValueError('Emergency close requires --confirm "CLOSE DIVA POSITION"')
        service = ExecutionService.from_environment(settings.database_path)
        if service.config.mode == ExecutionMode.PAPER:
            raise ValueError("emergency-close requires explicitly enabled TESTNET or LIVE execution")
        assert service.client is not None
        filter_provider = _market_rules_provider(service.client.base_url)
        adapter = PositionLifecycleExecutionAdapter(
            client=service.client, ledger=service.ledger,
            working_type=service.config.working_type,
            price_protect=service.config.price_protect,
            max_account_snapshot_age_ms=service.config.max_account_snapshot_age_ms,
        )
        supervisor = ManagedPositionSupervisor(
            ledger=service.ledger, adapter=adapter, filter_provider=filter_provider,
            feed_factory=lambda _symbol: None,
        )
        with _exchange_actor_lock(service, settings.log_dir / "account-runtime.lock"):
            result = supervisor.emergency_close(args.signal_id, reason=args.reason)
        print(json.dumps(result, sort_keys=True, default=str))
        return 0 if result.get("status") == "CLOSED_CONFIRMED" else 5
    except Exception as exc:
        logger.exception("Emergency close failed")
        print(f"ERROR: emergency close failed: {exc}", file=sys.stderr)
        return 9
    finally:
        if service is not None and service.client is not None:
            service.client.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="divatrading",
        description="DIVATrading Binance Bot market and staged auto-trading foundation; execution remains PAPER-default, with separate guarded TESTNET/LIVE services.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command, help_text, handler in (
        ("check", "Check supported runtime and safe configuration.", command_check),
        ("init-db", "Initialize or migrate the local SQLite database.", command_init_db),
        ("status", "Show local foundation and service status.", command_status),
        ("exchange-info", "Refresh public Binance USD-M contract metadata.", command_exchange_info),
    ):
        sub = subparsers.add_parser(command, help=help_text)
        sub.set_defaults(handler=handler)

    kronos_status = subparsers.add_parser(
        "kronos-status", help="Inspect local optional Kronos-mini installation without loading PyTorch."
    )
    kronos_status.set_defaults(handler=command_kronos_status)

    kronos_install = subparsers.add_parser(
        "kronos-install", help="Explicitly download and install Kronos-mini and CPU dependencies."
    )
    kronos_install.add_argument("--no-install-dependencies", action="store_true", help="Only download source/model snapshots; dependencies must already be installed.")
    kronos_install.set_defaults(handler=command_kronos_install)

    kronos_forecast = subparsers.add_parser(
        "kronos-forecast", help="Run a one-shot Kronos-mini M5 shadow forecast from Binance public data."
    )
    kronos_forecast.add_argument("--symbol", required=True, help="Binance USD-M symbol, e.g. BTCUSDT.")
    kronos_forecast.add_argument("--context-bars", type=int, default=512)
    kronos_forecast.add_argument("--minimum-input-bars", type=int, default=64)
    kronos_forecast.add_argument("--horizon-bars", type=int, default=6)
    kronos_forecast.set_defaults(handler=command_kronos_forecast)

    kronos_evaluate = subparsers.add_parser(
        "kronos-evaluate", help="Evaluate a saved Kronos forecast once its complete future M5 horizon has closed."
    )
    kronos_evaluate.add_argument("--forecast-id", required=True)
    kronos_evaluate.set_defaults(handler=command_kronos_evaluate)

    signal_history = subparsers.add_parser(
        "signal-history", help="Inspect locally persisted Telegram signal publication history."
    )
    signal_history.add_argument("--limit", type=int, default=50)
    signal_history.set_defaults(handler=command_signal_history)

    history = subparsers.add_parser(
        "klines-history", help="Fetch bounded public Binance historical Klines (M1/M5/M15)."
    )
    history.add_argument("--symbol", required=True, help="Exact Binance contract symbol, e.g. BTCUSDT.")
    history.add_argument("--interval", required=True, choices=("1m", "5m", "15m"))
    history.add_argument("--start-time-ms", required=True, type=int, help="Inclusive UTC Unix timestamp in ms.")
    history.add_argument("--end-time-ms", required=True, type=int, help="Inclusive UTC Unix timestamp in ms.")
    history.add_argument("--page-limit", type=int, default=499, help="Rows per page (1-1500; default 499).")
    history.add_argument("--max-pages", type=int, default=20, help="Hard page cap (1-100; default 20).")
    history.set_defaults(handler=command_klines_history)

    fixture = subparsers.add_parser(
        "validate-pine-fixture",
        help="Validate a TradingView Pine reference fixture and retained CSV exports.",
    )
    fixture.add_argument("--fixture", required=True, type=Path, help="Built reference_fixture.v2.json")
    fixture.add_argument("--source-dir", type=Path, help="Directory containing the three retained CSV exports")
    fixture.add_argument(
        "--schema", type=Path,
        default=Path("reference/pine_smc/reference_fixture.v2.schema.json"),
        help="JSON Schema v2 path (default: project reference directory).",
    )
    fixture.set_defaults(handler=command_validate_pine_fixture)

    replay_validate = subparsers.add_parser(
        "replay-validate", help="Validate a local historical replay manifest and source hashes."
    )
    replay_validate.add_argument("--manifest", required=True, type=Path)
    replay_validate.add_argument("--root", type=Path, help="Dataset root (default: manifest directory).")
    replay_validate.add_argument(
        "--allow-current-metadata", action="store_true",
        help="Allow diagnostic-only CURRENT_SNAPSHOT_ONLY metadata; never strict calibration.",
    )
    replay_validate.set_defaults(handler=command_replay_validate)

    replay_run = subparsers.add_parser(
        "replay-run", help="Run deterministic evidence-only Stage 1-5 historical replay."
    )
    replay_run.add_argument("--manifest", required=True, type=Path)
    replay_run.add_argument("--root", type=Path, help="Dataset root (default: manifest directory).")
    replay_run.add_argument("--ledger", required=True, type=Path, help="Output JSONL ledger.")
    replay_run.add_argument("--checkpoint", type=Path, help="Optional restart checkpoint JSON.")
    replay_run.add_argument("--resume", action="store_true", help="Resume an incomplete ledger/checkpoint pair.")
    replay_run.add_argument("--max-history-candles", type=int, default=1000)
    replay_run.add_argument("--checkpoint-every-captures", type=int, default=1000)
    replay_run.add_argument("--evidence-start-time-ms", type=int, help="UTC epoch milliseconds: process all earlier candles but omit their verbose ledger rows, retaining a digest/count commitment.")
    replay_run.add_argument("--allow-current-metadata", action="store_true")
    replay_run.set_defaults(handler=command_replay_run)

    replay_quality = subparsers.add_parser(
        "replay-quality",
        help="Audit raw or manifest-backed historical Kline sources without modifying them.",
    )
    replay_quality.add_argument("--report", required=True, type=Path, help="Output quality JSON report.")
    replay_quality.add_argument("--root", type=Path, help="Dataset root (default: current directory or manifest parent).")
    replay_quality.add_argument("--manifest", type=Path, help="Optional Stage 6A manifest for hash/row-count verification.")
    replay_quality.add_argument("--symbol", help="Exact symbol for raw-source mode, e.g. BTCUSDT.")
    replay_quality.add_argument("--start-open-time-ms", type=int, help="Inclusive UTC dataset start (raw-source mode).")
    replay_quality.add_argument("--end-open-time-ms", type=int, help="Exclusive UTC dataset end (raw-source mode).")
    replay_quality.add_argument("--source", action="append", default=[], help="Raw source as INTERVAL=RELATIVE_PATH; repeat for M1/M5/M15.")
    replay_quality.add_argument("--metadata", type=Path, help="Replay metadata snapshot JSON; optional but required for strict eligibility.")
    replay_quality.add_argument("--metadata-evidence-ref", help="Reference to independently retained metadata evidence.")
    replay_quality.add_argument("--source-sha256", action="append", default=[], help="Expected hash as RELATIVE_PATH=SHA256; repeat as needed.")
    replay_quality.add_argument("--source-row-count", action="append", default=[], help="Expected rows as RELATIVE_PATH=COUNT; repeat as needed.")
    replay_quality.add_argument("--sample-cap", type=int, default=100, help="Maximum issue samples across report (1-100).")
    replay_quality.add_argument("--schema", type=Path, help="Optional report JSON Schema path.")
    replay_quality.set_defaults(handler=command_replay_quality)

    replay_analyze = subparsers.add_parser(
        "replay-analyze",
        help="Validate and analyze a complete immutable Stage 6A JSONL ledger.",
    )
    replay_analyze.add_argument("--ledger", required=True, type=Path, help="Input Stage 6A JSONL ledger (read-only).")
    replay_analyze.add_argument("--report", required=True, type=Path, help="Output analytics JSON report.")
    replay_analyze.add_argument("--split-ratios", default="60/20/20", help="Frozen chronological split ratios (only 60/20/20 is supported).")
    replay_analyze.add_argument("--schema", type=Path, help="Optional analytics JSON Schema path.")
    replay_analyze.set_defaults(handler=command_replay_analyze)

    replay_convergence = subparsers.add_parser(
        "replay-convergence",
        help="Compare Stage 2-5 evidence after differing pre-roll windows on an identical evaluation slice.",
    )
    replay_convergence.add_argument("--plan", required=True, type=Path, help="JSON plan declaring evaluation window and two or more replay trials.")
    replay_convergence.add_argument("--report", required=True, type=Path, help="Output convergence report JSON.")
    replay_convergence.add_argument("--schema", type=Path, help="Optional warm-up convergence JSON Schema path.")
    replay_convergence.set_defaults(handler=command_replay_convergence)

    replay_workflow = subparsers.add_parser(
        "replay-workflow",
        help="Run the complete Stage 6B quality, replay, analytics and warm-up workflow.",
    )
    replay_workflow.add_argument("--plan", required=True, type=Path, help="Stage 6B integrated workflow plan JSON.")
    replay_workflow.add_argument("--report", required=True, type=Path, help="Final workflow report JSON.")
    replay_workflow.add_argument("--output-dir", type=Path, help="Override plan output_dir for generated trial artifacts.")
    replay_workflow.add_argument("--plan-schema", type=Path, help="Optional workflow plan schema override.")
    replay_workflow.add_argument("--report-schema", type=Path, help="Optional workflow report schema override.")
    replay_workflow.set_defaults(handler=command_replay_workflow)

    rest_intake = subparsers.add_parser(
        "binance-rest-kline-intake",
        help="Retain exact Binance USD-M REST Kline pages and create a derived native CSV.",
    )
    rest_intake.add_argument("--symbol", required=True, help="Exact symbol, e.g. BTCUSDT.")
    rest_intake.add_argument("--interval", required=True, choices=("1m", "5m", "15m"))
    rest_intake.add_argument("--start-open-time-ms", required=True, type=int, help="Inclusive UTC aligned Kline open time.")
    rest_intake.add_argument("--end-open-time-ms-exclusive", required=True, type=int, help="Exclusive UTC aligned boundary; current candle interval is rejected.")
    rest_intake.add_argument("--dataset-root", required=True, type=Path)
    rest_intake.add_argument("--capture-id", help="Optional unique safe capture identifier; generated when omitted.")
    rest_intake.add_argument("--page-limit", type=int, default=1500, help="Rows per request (1-1500; default 1500).")
    rest_intake.add_argument("--max-pages", type=int, default=1000, help="Hard request cap (1-10000).")
    rest_intake.add_argument("--request-interval-seconds", type=float, default=1.0, help="Minimum delay between requests (default 1 second).")
    rest_intake.set_defaults(handler=command_binance_rest_kline_intake)

    current_metadata = subparsers.add_parser(
        "binance-current-metadata",
        help="Retain current Binance USD-M exchangeInfo for diagnostics (not historical tickSize proof).",
    )
    current_metadata.add_argument("--symbol", required=True, help="Exact symbol, e.g. BTCUSDT.")
    current_metadata.add_argument("--output-dir", required=True, type=Path)
    current_metadata.add_argument("--timeout", type=float, default=30.0)
    current_metadata.add_argument("--attempts", type=int, default=3)
    current_metadata.set_defaults(handler=command_binance_current_metadata)

    account_runtime = subparsers.add_parser(
        "account-runtime",
        help="Run TESTNET/LIVE private User Data Stream, reconcile account state, and recover pending execution protection.",
    )
    account_runtime.set_defaults(handler=command_account_runtime)

    runtime_status = subparsers.add_parser(
        "runtime-status", help="Show read-only account, positions, risk reservations and pending lifecycle actions from local ledger."
    )
    runtime_status.set_defaults(handler=command_runtime_status)

    emergency_close = subparsers.add_parser(
        "emergency-close",
        help="Explicitly close one DIVA-managed position by market order; requires exact confirmation.",
    )
    emergency_close.add_argument("--signal-id", required=True, help="Exact managed DIVA signal ID.")
    emergency_close.add_argument("--reason", required=True, help="Required operator reason for the exit.")
    emergency_close.add_argument("--confirm", required=True, help='Must equal "CLOSE DIVA POSITION".')
    emergency_close.set_defaults(handler=command_emergency_close)

    testnet_preflight = subparsers.add_parser(
        "testnet-preflight",
        help="Run read-only Binance USDⓈ-M Demo Futures connectivity/account/metadata checks; no orders are sent.",
    )
    testnet_preflight.add_argument(
        "--symbols", default="BTCUSDT",
        help="Comma-separated active USDT perpetual symbols to validate (default: BTCUSDT).",
    )
    testnet_preflight.set_defaults(handler=command_testnet_preflight)

    live_preflight = subparsers.add_parser(
        "live-read-only-preflight",
        help="Read-only LIVE USD-M account, clean-account, symbol and leverage-bracket checks; never places orders.",
    )
    live_preflight.add_argument("--symbols", default="BTCUSDT", help="Comma-separated USDT perpetual symbols (default: BTCUSDT).")
    live_preflight.set_defaults(handler=command_live_read_only_preflight)

    testnet_order_test = subparsers.add_parser(
        "testnet-order-test",
        help="Validate one signed Demo LIMIT/MARKET request via /fapi/v1/order/test; no matching-engine submission.",
    )
    testnet_order_test.add_argument("--symbol", required=True, help="Exact active USDT perpetual, e.g. BTCUSDT.")
    testnet_order_test.add_argument("--side", required=True, choices=("BUY", "SELL"))
    testnet_order_test.add_argument("--order-type", required=True, choices=("LIMIT", "MARKET"))
    testnet_order_test.add_argument("--quantity", required=True, help="Exact decimal quantity aligned to current exchange filters.")
    testnet_order_test.add_argument("--price", help="Required for LIMIT; forbidden for MARKET.")
    testnet_order_test.add_argument("--time-in-force", choices=("GTC", "IOC", "FOK", "GTX", "RPI"), default="GTC")
    testnet_order_test.add_argument("--position-side", choices=("LONG", "SHORT", "BOTH"), help="Required in Hedge Mode; omitted in One-way Mode.")
    testnet_order_test.add_argument("--confirm-test-order", action="store_true", help="Explicitly authorize this validation-only request.")
    testnet_order_test.set_defaults(handler=command_testnet_order_test)

    market_runtime = subparsers.add_parser(
        "market-runtime",
        help="Run read-only production public market feeds and complete multi-pair SMC V2 captures.",
    )
    market_runtime.add_argument("--mode", choices=("AUTO", "MANUAL"), default="AUTO")
    market_runtime.add_argument("--max-symbols", type=int, default=8, help="Active pair cap (1-24 for this 8GB-oriented profile).")
    market_runtime.add_argument("--min-quote-volume", default="10000000", help="AUTO mode minimum 24h quote volume in USDT.")
    market_runtime.add_argument("--min-trades", type=int, default=1000)
    market_runtime.add_argument("--symbols", help="Comma-separated exact symbols for MANUAL mode.")
    market_runtime.add_argument("--exclude", help="Comma-separated symbols to exclude.")
    market_runtime.add_argument("--bootstrap-candles", type=int, default=500, help="Initial closed candles fetched per timeframe (20-1000).")
    market_runtime.add_argument("--strategy-candles", type=int, default=500, help="Bounded closed-candle window retained per timeframe (20-1000).")
    market_runtime.add_argument("--snapshot-interval", type=float, default=0.5)
    market_runtime.add_argument("--universe-refresh-seconds", type=float, default=300.0)
    market_runtime.add_argument(
        "--entry-model", choices=("LIMIT_RETRACEMENT", "CONFIRMATION_MARKET"),
        default="LIMIT_RETRACEMENT",
    )
    market_runtime.add_argument("--paper-equity-usdt", default="1000", help="Reference equity for PAPER trade-plan sizing; not an account read.")
    market_runtime.add_argument("--risk-per-trade-pct", default="0.25")
    market_runtime.add_argument("--max-portfolio-risk-pct", default="1.00")
    market_runtime.add_argument("--target-r-multiple", default="2.0")
    market_runtime.add_argument("--min-signal-score", type=int, default=55)
    market_runtime.add_argument("--telegram-signals", action="store_true", help="Publish READY SMC signals to the Telegram owner chat; no order is submitted.")
    market_runtime.add_argument("--kronos-shadow", action="store_true", help="Attach optional Kronos-mini M5 forecast to Telegram signal charts; never gates SMC.")
    market_runtime.add_argument("--kronos-context-bars", type=int, default=512)
    market_runtime.add_argument("--kronos-minimum-input-bars", type=int, default=64)
    market_runtime.add_argument("--kronos-horizon-bars", type=int, default=6)
    market_runtime.set_defaults(handler=command_market_runtime)

    autonomous_runtime = subparsers.add_parser(
        "auto-trade-runtime",
        help="Run SMC V2 -> global risk -> execution. PAPER default; LIVE requires explicit command and .env opt-in.",
    )
    autonomous_runtime.add_argument("--mode", choices=("AUTO", "MANUAL"), default="AUTO")
    autonomous_runtime.add_argument("--activate-live", action="store_true",
                                    help="Real-money opt-in. Requires LIVE .env guards and explicit operator consent.")
    autonomous_runtime.add_argument("--live-max-daily-loss-pct", default=None,
                                    help="Optional extra daily percentage loss cap; default limit comes from operator USDT settings ($1).")
    autonomous_runtime.add_argument("--live-max-drawdown-pct", default=None,
                                    help="Optional extra peak-equity drawdown cap; disabled if omitted.")
    autonomous_runtime.add_argument("--max-symbols", type=int, default=8)
    autonomous_runtime.add_argument("--min-quote-volume", default="10000000")
    autonomous_runtime.add_argument("--min-trades", type=int, default=1000)
    autonomous_runtime.add_argument("--symbols", help="Comma-separated exact symbols for MANUAL mode.")
    autonomous_runtime.add_argument("--exclude", help="Comma-separated symbols to exclude.")
    autonomous_runtime.add_argument("--bootstrap-candles", type=int, default=500)
    autonomous_runtime.add_argument("--strategy-candles", type=int, default=500)
    autonomous_runtime.add_argument("--snapshot-interval", type=float, default=0.5)
    autonomous_runtime.add_argument("--universe-refresh-seconds", type=float, default=300.0)
    autonomous_runtime.add_argument("--strategy", choices=("rc6", "sweep-reclaim"), default="rc6",
                                    help="Select native RC6 or the merged M15/M5 sweep-reclaim strategy.")
    autonomous_runtime.add_argument("--early-exit-protection", action="store_true",
                                    help="Enable sampled near-TP order-flow exits for TESTNET or LIVE positions.")
    autonomous_runtime.add_argument("--entry-model", choices=("LIMIT_RETRACEMENT", "CONFIRMATION_MARKET"), default="LIMIT_RETRACEMENT")
    autonomous_runtime.add_argument("--setup-timeframes", default="1m,5m", help="Independent source timeframes, e.g. 1m,5m")
    autonomous_runtime.add_argument("--max-sweep-age-bars", type=int, default=12)
    autonomous_runtime.add_argument("--max-fvg-age-bars", type=int, default=24)
    autonomous_runtime.add_argument("--max-retest-confirmation-bars", type=int, default=5)
    autonomous_runtime.add_argument("--require-flow-alignment", action="store_true",
                                    help="Require the selected strategy's fresh order-flow confirmation.")
    autonomous_runtime.add_argument("--paper-equity-usdt", default="1000")
    autonomous_runtime.add_argument("--risk-per-trade-pct", default="0.25")
    autonomous_runtime.add_argument("--max-portfolio-risk-pct", default="20.00")
    autonomous_runtime.add_argument(
        "--max-positions", type=int, choices=range(1, LIVE_MAX_POSITIONS + 1),
        help="Simultaneous managed positions, including pending entries. Defaults to 1 in LIVE and 5 otherwise.",
    )
    autonomous_runtime.add_argument("--target-r-multiple", default="2.0")
    autonomous_runtime.add_argument("--min-signal-score", type=int, default=55)
    autonomous_runtime.add_argument("--max-signal-age-ms", type=int, default=30_000)
    autonomous_runtime.add_argument("--max-account-snapshot-age-ms", type=int, default=30_000)
    autonomous_runtime.add_argument("--account-ready-timeout-seconds", type=float, default=180.0)
    autonomous_runtime.set_defaults(handler=command_autonomous_runtime)

    telegram = subparsers.add_parser(
        "telegram-control", help="Run persistent owner-only Telegram operator controls."
    )
    telegram.set_defaults(handler=command_telegram_control)
    telegram_check = subparsers.add_parser("telegram-check", help="Check Telegram bot and private owner chat (no Binance orders).")
    telegram_check.set_defaults(handler=command_telegram_check)

    risk_config = subparsers.add_parser(
        "risk-config", help="Read or change the selected local risk profile without making network requests.",
    )
    risk_config.add_argument("--mode", choices=("fixed", "percent"))
    risk_config.add_argument("--value", help="USDT per trade for fixed mode or percent of equity for percent mode.")
    risk_config.set_defaults(handler=command_risk_config)

    universe = subparsers.add_parser(
        "universe", help="Discover eligible multi-pair USDT perpetuals using live 24h liquidity statistics."
    )
    universe.add_argument("--mode", choices=("AUTO", "MANUAL"), default="AUTO")
    universe.add_argument("--max-symbols", type=int, default=24)
    universe.add_argument("--min-quote-volume", default="10000000", help="Minimum 24h quote volume in USDT for AUTO mode.")
    universe.add_argument("--min-trades", type=int, default=1000)
    universe.add_argument("--symbols", help="Comma-separated exact contract symbols for MANUAL mode.")
    universe.add_argument("--exclude", help="Comma-separated symbols to exclude.")
    universe.set_defaults(handler=command_universe)

    instruments = subparsers.add_parser(
        "instruments", help="List cached active USDT perpetual contracts."
    )
    instruments.add_argument("--symbol", help="Resolve one exact contract symbol, e.g. BTCUSDT.")
    instruments.add_argument("--limit", type=int, default=50, help="Maximum rows to print (1-5000).")
    instruments.set_defaults(handler=command_instruments)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "limit", 1) < 1 or getattr(args, "limit", 1) > 5000:
        parser.error("--limit must be between 1 and 5000")
    if getattr(args, "command", None) == "signal-history" and not 1 <= args.limit <= 500:
        parser.error("signal-history --limit must be between 1 and 500")
    if getattr(args, "page_limit", 1) < 1 or getattr(args, "page_limit", 1) > 1500:
        parser.error("--page-limit must be between 1 and 1500")
    max_pages = getattr(args, "max_pages", 1)
    if args.command == "binance-rest-kline-intake":
        if max_pages < 1 or max_pages > 10000:
            parser.error("--max-pages must be between 1 and 10000")
    elif max_pages < 1 or max_pages > 100:
        parser.error("--max-pages must be between 1 and 100")
    if getattr(args, "start_time_ms", 0) < 0 or getattr(args, "end_time_ms", 0) < 0:
        parser.error("timestamps must be non-negative Unix milliseconds")
    if getattr(args, "start_time_ms", 0) > getattr(args, "end_time_ms", 0):
        parser.error("--start-time-ms must be <= --end-time-ms")
    if getattr(args, "max_history_candles", 2) < 2 or getattr(args, "max_history_candles", 2) > 2000:
        parser.error("--max-history-candles must be between 2 and 2000")
    if getattr(args, "checkpoint_every_captures", 1) < 1:
        parser.error("--checkpoint-every-captures must be positive")
    if getattr(args, "sample_cap", 1) < 1 or getattr(args, "sample_cap", 1) > 100:
        parser.error("--sample-cap must be between 1 and 100")
    if getattr(args, "command", None) == "replay-quality":
        if args.manifest:
            if args.source or args.metadata or args.symbol or args.start_open_time_ms is not None or args.end_open_time_ms is not None:
                parser.error("--manifest mode cannot be combined with raw-source arguments")
            if args.source_sha256 or args.source_row_count:
                parser.error("--source-sha256/--source-row-count are raw-source options; manifest mode uses declared values")
        elif not args.symbol or args.start_open_time_ms is None or args.end_open_time_ms is None or not args.source:
            parser.error("raw mode requires --symbol, --start-open-time-ms, --end-open-time-ms and at least one --source")
    if getattr(args, "command", None) == "kronos-forecast":
        if not 64 <= args.context_bars <= 2048:
            parser.error("--context-bars must be between 64 and 2048")
        if not 32 <= args.minimum_input_bars <= args.context_bars:
            parser.error("--minimum-input-bars must be between 32 and --context-bars")
        if not 1 <= args.horizon_bars <= 48:
            parser.error("--horizon-bars must be between 1 and 48")
    if getattr(args, "command", None) == "market-runtime":
        if not 64 <= args.kronos_context_bars <= 2048:
            parser.error("--kronos-context-bars must be between 64 and 2048")
        if not 32 <= args.kronos_minimum_input_bars <= args.kronos_context_bars:
            parser.error("--kronos-minimum-input-bars must be between 32 and --kronos-context-bars")
        if not 1 <= args.kronos_horizon_bars <= 48:
            parser.error("--kronos-horizon-bars must be between 1 and 48")
        if args.kronos_shadow and not args.telegram_signals:
            parser.error("--kronos-shadow requires --telegram-signals in market-runtime")
    if getattr(args, "command", None) in {"market-runtime", "auto-trade-runtime"}:
        if not 1 <= args.max_symbols <= 24:
            parser.error("--max-symbols must be between 1 and 24 for the bounded live feed profile")
        if not 20 <= args.bootstrap_candles <= 1000:
            parser.error("--bootstrap-candles must be between 20 and 1000")
        if not 20 <= args.strategy_candles <= 1000:
            parser.error("--strategy-candles must be between 20 and 1000")
        if not 0.1 <= args.snapshot_interval <= 5:
            parser.error("--snapshot-interval must be between 0.1 and 5 seconds")
        if args.universe_refresh_seconds <= 0:
            parser.error("--universe-refresh-seconds must be positive")
        if args.mode == "MANUAL" and not args.symbols:
            parser.error("--mode MANUAL requires --symbols")
        try:
            equity_value = Decimal(args.paper_equity_usdt)
            risk_value = Decimal(args.risk_per_trade_pct)
            portfolio_risk_value = Decimal(args.max_portfolio_risk_pct)
            target_r_value = Decimal(args.target_r_multiple)
            if not equity_value.is_finite() or equity_value <= 0:
                raise ValueError
            if not risk_value.is_finite() or not portfolio_risk_value.is_finite() or not Decimal("0") < risk_value <= portfolio_risk_value <= Decimal("100"):
                raise ValueError
            if not target_r_value.is_finite() or target_r_value <= 0:
                raise ValueError
        except Exception:
            parser.error("paper equity, risk percentages, and target R must be valid positive Decimals; per-trade risk <= portfolio risk <= 100")
        if not 0 <= args.min_signal_score <= 100:
            parser.error("--min-signal-score must be between 0 and 100")
        if args.command == "auto-trade-runtime":
            if args.max_signal_age_ms < 1000 or args.max_account_snapshot_age_ms < 1000:
                parser.error("signal and account snapshot age limits must be >= 1000 ms")
            if args.account_ready_timeout_seconds <= 0:
                parser.error("--account-ready-timeout-seconds must be positive")
    try:
        return int(args.handler(args))
    except (ConfigurationError, RuntimeCompatibilityError, RuntimeError, OSError, ReplayManifestError, ReplayRunnerError, DatasetQualityAuditError, ReplayAnalyticsError, WarmupConvergenceError, ReplayWorkflowError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
