"""Persistent operator controls, loss guards, leverage feasibility and BOT_ONLY policy.

This module is deliberately exchange-write-free. It persists control intent and
provides deterministic gates consumed by the trading runtime.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation, ROUND_DOWN
import json
import math
from typing import Any, Callable

from divatrading.core.database import Database


CONTROL_KEY = "operator_control_v1"
TELEGRAM_OFFSET_KEY = "telegram_control_update_offset_v1"
DEFAULTS: dict[str, Any] = {
    "risk": {"mode": "FIXED", "value": "0.20"},
    "max_loss": {"daily_mode": "USDT", "daily_value": "1.00",
                  "streak": None, "drawdown_pct": None, "timezone": "Asia/Jakarta"},
    "leverage": {"mode": "AUTO", "max": 125},
    "margin_mode": "CROSSED",
    "runtime": {"paused": False, "killed": False},
    "account_policy": "BOT_ONLY",
    "revision": 0,
}


def _decimal(value: str | int | float | Decimal) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("value must be a valid decimal number") from exc
    if not result.is_finite() or result <= 0:
        raise ValueError("value must be finite and greater than zero")
    return result


class OperatorControlStore:
    """Atomic SQLite-backed operator settings with an audit event per mutation."""
    def __init__(self, database: Database) -> None:
        self.database = database
        self.database.initialize()
        old = self.database.get_setting(CONTROL_KEY)
        if old is None:
            self.database.set_setting(CONTROL_KEY, DEFAULTS)
        else:
            # Upgrade unconfigured RC5 controls without overwriting user-selected
            # risk / loss / leverage policies. Fully configured old databases stay intact.
            needs_risk = old.get("risk", {}).get("mode") == "UNCONFIGURED"
            needs_loss = old.get("max_loss", {}).get("daily_mode") == "UNCONFIGURED"
            if needs_risk or needs_loss:
                def migrate(state: dict[str, Any]) -> None:
                    if needs_risk:
                        state["risk"] = dict(DEFAULTS["risk"])
                    if needs_loss:
                        state["max_loss"]["daily_mode"] = "USDT"
                        state["max_loss"]["daily_value"] = "1.00"
                self.update(migrate, "RC6_UNCONFIGURED_DEFAULTS_MIGRATED",
                            {"fixed_bullet_default": needs_risk, "daily_loss_default": needs_loss})
            if old.get("margin_mode") != "CROSSED":
                self.update(lambda state: state.update(margin_mode="CROSSED"),
                            "CROSS_MARGIN_POLICY_APPLIED", {"mode": "CROSSED"})

    def get(self) -> dict[str, Any]:
        value = self.database.get_setting(CONTROL_KEY, DEFAULTS)
        # Return a detached structure; callers cannot mutate persisted state in-place.
        return json.loads(json.dumps(value))

    def get_telegram_offset(self) -> int:
        value = self.database.get_setting(TELEGRAM_OFFSET_KEY, 0)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise RuntimeError("Persisted Telegram update offset is invalid")
        return value

    def set_telegram_offset(self, offset: int) -> None:
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
            raise ValueError("Telegram update offset must be a non-negative integer")
        # Offset is monotonic: a stale worker cannot rewind acknowledged updates.
        with self.database.transaction() as connection:
            row = connection.execute(
                "SELECT value_json FROM app_settings WHERE setting_key=?", (TELEGRAM_OFFSET_KEY,),
            ).fetchone()
            current = json.loads(row[0]) if row else 0
            if isinstance(current, bool) or not isinstance(current, int) or current < 0:
                raise RuntimeError("Persisted Telegram update offset is invalid")
            if offset > current:
                now = datetime.now(UTC).isoformat()
                connection.execute(
                    """INSERT INTO app_settings(setting_key,value_json,updated_at_utc) VALUES(?,?,?)
                       ON CONFLICT(setting_key) DO UPDATE SET value_json=excluded.value_json,
                       updated_at_utc=excluded.updated_at_utc""",
                    (TELEGRAM_OFFSET_KEY, json.dumps(offset), now),
                )

    def update(self, mutator: Callable[[dict[str, Any]], None], event: str, details: dict[str, Any]) -> dict[str, Any]:
        # SQLite transaction serializes concurrent operator updates.
        with self.database.transaction() as connection:
            row = connection.execute("SELECT value_json FROM app_settings WHERE setting_key=?", (CONTROL_KEY,)).fetchone()
            state = json.loads(row[0]) if row else json.loads(json.dumps(DEFAULTS))
            mutator(state)
            state["revision"] = int(state.get("revision", 0)) + 1
            payload = json.dumps(state, ensure_ascii=False, separators=(",", ":"))
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """INSERT INTO app_settings(setting_key,value_json,updated_at_utc) VALUES(?,?,?)
                   ON CONFLICT(setting_key) DO UPDATE SET value_json=excluded.value_json,updated_at_utc=excluded.updated_at_utc""",
                (CONTROL_KEY, payload, now),
            )
            connection.execute(
                """INSERT INTO runtime_events(occurred_at_utc,level,component,event_name,message,details_json)
                   VALUES(?,?,?,?,?,?)""",
                (now, "WARNING", "operator_control", event, event, json.dumps(details, separators=(",", ":"))),
            )
        return self.get()

    def set_risk(self, mode: str, value: str) -> dict[str, Any]:
        mode = mode.strip().upper()
        amount = _decimal(value)
        if mode not in {"FIXED", "PERCENT"}:
            raise ValueError("risk mode must be fixed or percent")
        if mode == "PERCENT" and amount > Decimal("100"):
            raise ValueError("risk percent cannot exceed 100")
        def mutate(s: dict[str, Any]) -> None:
            s["risk"] = {"mode": mode, "value": str(amount)}
        return self.update(mutate, "RISK_CONFIGURATION_CHANGED", {"mode": mode, "value": str(amount)})

    def set_maxloss(self, kind: str, value: str, unit: str = "USDT") -> dict[str, Any]:
        kind, unit = kind.lower(), unit.upper()
        if kind == "daily":
            amount = _decimal(value)
            if unit not in {"USDT", "PERCENT"}:
                raise ValueError("daily max loss unit must be USDT or PERCENT")
            if unit == "PERCENT" and amount > 100:
                raise ValueError("daily max loss percent cannot exceed 100")
            def mutate(s: dict[str, Any]) -> None:
                s["max_loss"].update({"daily_mode": unit, "daily_value": str(amount)})
            return self.update(mutate, "DAILY_MAX_LOSS_CHANGED", {"unit": unit, "value": str(amount)})
        if kind == "streak":
            n = int(value)
            if str(n) != str(value).strip() or not 1 <= n <= 100:
                raise ValueError("loss streak must be an integer from 1 to 100")
            def mutate(s: dict[str, Any]) -> None:
                s["max_loss"]["streak"] = n
            return self.update(mutate, "LOSS_STREAK_CHANGED", {"streak": n})
        if kind == "drawdown":
            amount = _decimal(value)
            if unit != "PERCENT" or amount > 100:
                raise ValueError("drawdown syntax is percent and value must be <= 100")
            def mutate(s: dict[str, Any]) -> None:
                s["max_loss"]["drawdown_pct"] = str(amount)
            return self.update(mutate, "DRAWDOWN_LIMIT_CHANGED", {"percent": str(amount)})
        raise ValueError("maxloss kind must be daily, streak or drawdown")

    def set_leverage(self, mode: str, maximum: str | None = None) -> dict[str, Any]:
        mode = mode.upper()
        if mode not in {"AUTO", "FIXED"}:
            raise ValueError("leverage mode must be auto or fixed")
        cap = int(maximum) if maximum is not None else int(self.get()["leverage"]["max"])
        if str(cap) != str(maximum) and maximum is not None or not 1 <= cap <= 125:
            raise ValueError("maximum leverage must be an integer from 1 to 125")
        def mutate(s: dict[str, Any]) -> None:
            s["leverage"] = {"mode": mode, "max": cap}
        return self.update(mutate, "LEVERAGE_POLICY_CHANGED", {"mode": mode, "max": cap})

    def set_margin(self, mode: str) -> dict[str, Any]:
        if mode.strip().upper() not in {"CROSS", "CROSSED"}:
            raise ValueError("New entries require Cross margin")
        mode = "CROSSED"
        def mutate(s: dict[str, Any]) -> None:
            s["margin_mode"] = mode
        return self.update(mutate, "MARGIN_MODE_CHANGED", {"mode": mode})

    def set_runtime(self, *, paused: bool | None = None, killed: bool | None = None) -> dict[str, Any]:
        def mutate(s: dict[str, Any]) -> None:
            if paused is not None: s["runtime"]["paused"] = paused
            if killed is not None: s["runtime"]["killed"] = killed
        return self.update(mutate, "RUNTIME_CONTROL_CHANGED", {"paused": paused, "killed": killed})


@dataclass(frozen=True, slots=True)
class LossState:
    daily_net_pnl_usdt: Decimal
    floating_pnl_usdt: Decimal
    consecutive_losses: int
    equity_peak_usdt: Decimal
    current_equity_usdt: Decimal
    day_key: str
    day_start_equity_usdt: Decimal | None = None


@dataclass(frozen=True, slots=True)
class LossGate:
    allow_new_entries: bool
    reasons: tuple[str, ...]


def evaluate_loss_limits(settings: dict[str, Any], state: LossState) -> LossGate:
    limits = settings["max_loss"]
    reasons: list[str] = []
    daily_value = limits.get("daily_value")
    if daily_value is not None:
        cap = Decimal(str(daily_value))
        if limits.get("daily_mode") == "PERCENT":
            basis = state.day_start_equity_usdt or state.current_equity_usdt
            cap = basis * cap / Decimal("100")
        # Net PnL includes realized PnL, fees/funding as supplied by account ledger;
        # floating loss is added conservatively to prevent fresh entries.
        loss = max(Decimal("0"), -(state.daily_net_pnl_usdt + min(Decimal("0"), state.floating_pnl_usdt)))
        if loss >= cap: reasons.append("DAILY_MAX_LOSS_REACHED")
    streak = limits.get("streak")
    if streak is not None and state.consecutive_losses >= int(streak):
        reasons.append("CONSECUTIVE_LOSS_LIMIT_REACHED")
    dd = limits.get("drawdown_pct")
    if dd is not None and state.equity_peak_usdt > 0:
        drawdown = max(Decimal("0"), (state.equity_peak_usdt - state.current_equity_usdt) / state.equity_peak_usdt * 100)
        if drawdown >= Decimal(str(dd)): reasons.append("MAX_DRAWDOWN_REACHED")
    return LossGate(not reasons, tuple(reasons))


@dataclass(frozen=True, slots=True)
class LeverageDecision:
    accepted: bool
    leverage: int | None
    required_margin_usdt: Decimal | None
    reason: str


def choose_leverage(*, notional_usdt: Decimal, available_margin_usdt: Decimal,
                    max_leverage: int, min_liquidation_buffer_pct: Decimal,
                    estimated_liquidation_buffer_by_leverage: dict[int, Decimal],
                    fee_reserve_usdt: Decimal = Decimal("0"), slippage_reserve_usdt: Decimal = Decimal("0")) -> LeverageDecision:
    """Choose the lowest leverage that fits margin while preserving a risk buffer.

    Exchange min-notional/quantity checks must already have passed. This function
    never increases notional or quantity to satisfy exchange minimums.
    """
    if notional_usdt <= 0 or available_margin_usdt <= 0 or not 1 <= max_leverage <= 125:
        return LeverageDecision(False, None, None, "INVALID_MARGIN_INPUT")
    reserve = fee_reserve_usdt + slippage_reserve_usdt
    for lev in range(1, max_leverage + 1):
        buffer = estimated_liquidation_buffer_by_leverage.get(lev)
        if buffer is None or buffer < min_liquidation_buffer_pct: continue
        margin = notional_usdt / Decimal(lev) + reserve
        if margin <= available_margin_usdt:
            return LeverageDecision(True, lev, margin, "LEVERAGE_FEASIBLE")
    return LeverageDecision(False, None, None, "INSUFFICIENT_MARGIN_OR_LIQUIDATION_BUFFER")


def enforce_bot_only_account(*, exchange_positions: list[dict[str, Any]],
                             managed_positions: list[dict[str, Any]],
                             open_standard_orders: Iterable[dict[str, Any]],
                             open_algo_orders: Iterable[dict[str, Any]],
                             managed_orders: Iterable[dict[str, Any]]) -> tuple[bool, tuple[str, ...]]:
    """Fail closed on any exchange exposure/order not attributable to DIVATrading.

    Binance nets same-side exposure, so aggregate quantities must reconcile
    exactly. In One-Way Mode the sign of the quantity carries the direction.
    Numeric order IDs are scoped by symbol and order namespace.
    """
    reasons: list[str] = []
    managed_qty: dict[tuple[str, str], Decimal] = {}
    for p in managed_positions:
        key = (str(p.get("symbol", "")).upper(),
               str(p.get("position_side", p.get("positionSide", "BOTH"))).upper())
        qty = abs(Decimal(str(p.get("quantity", "0"))))
        if qty and key[1] == "BOTH":
            direction = str(p.get("signal_side") or "").upper()
            if direction not in {"LONG", "SHORT"}:
                reasons.append("MANAGED_POSITION_DIRECTION_UNKNOWN")
                continue
            if direction == "SHORT":
                qty = -qty
            existing = managed_qty.get(key, Decimal("0"))
            if existing and (existing > 0) != (qty > 0):
                reasons.append("MANAGED_POSITION_DIRECTION_CONFLICT")
        if qty:
            managed_qty[key] = managed_qty.get(key, Decimal("0")) + qty
    seen_keys: set[tuple[str, str]] = set()
    for p in exchange_positions:
        qty = Decimal(str(p.get("positionAmt", p.get("quantity", "0"))))
        if qty == 0:
            continue
        key = (str(p.get("symbol", "")).upper(), str(p.get("positionSide", "BOTH")).upper())
        seen_keys.add(key)
        expected = managed_qty.get(key, Decimal("0"))
        if expected == 0:
            reasons.append("EXTERNAL_POSITION_DETECTED")
        else:
            if key[1] == "BOTH" and (qty > 0) != (expected > 0):
                reasons.append("POSITION_DIRECTION_MISMATCH")
            if abs(qty) != abs(expected):
                reasons.append("POSITION_QUANTITY_MISMATCH")
    for key, expected in managed_qty.items():
        if expected and key not in seen_keys:
            reasons.append("MANAGED_POSITION_MISSING_ON_EXCHANGE")
    exchange_keys: dict[tuple[str, str, str], str] = {}
    client_keys: dict[tuple[str, str, str], str] = {}
    for order in managed_orders:
        symbol = str(order.get("symbol") or "").strip().upper()
        kind = str(order.get("order_kind") or "").upper()
        if not symbol or kind not in {"STANDARD", "ALGO"}:
            continue
        exchange_id = str(order.get("exchange_order_id") or "")
        client_id = str(order.get("client_id") or "")
        if exchange_id:
            exchange_keys[(symbol, kind, exchange_id)] = client_id
        if client_id:
            client_keys[(symbol, kind, client_id)] = exchange_id

    for kind, orders, exchange_field, client_field, alternate_client_field in (
        ("STANDARD", open_standard_orders, "orderId", "clientOrderId", "origClientOrderId"),
        ("ALGO", open_algo_orders, "algoId", "clientAlgoId", "algoClientId"),
    ):
        for order in orders:
            symbol = str(order.get("symbol") or "").strip().upper()
            exchange_id = str(order.get(exchange_field) or "")
            client_id = str(order.get(client_field) or order.get(alternate_client_field) or "")
            if client_id:
                recorded_id = client_keys.get((symbol, kind, client_id))
                recorded_client = exchange_keys.get((symbol, kind, exchange_id))
                owned = (
                    recorded_id is not None
                    and (not exchange_id or not recorded_id or exchange_id == recorded_id)
                    and (not recorded_client or client_id == recorded_client)
                )
            else:
                owned = (symbol, kind, exchange_id) in exchange_keys
            if not owned:
                reasons.append("EXTERNAL_OPEN_ORDER_DETECTED")
    return not reasons, tuple(sorted(set(reasons)))


class TelegramControlBot:
    """Owner-only Telegram long-polling control plane using Bot API HTTPS."""
    def __init__(self, token: str, owner_id: str, store: OperatorControlStore) -> None:
        if not token or not owner_id or not owner_id.isdigit():
            raise ValueError("Telegram token and numeric owner ID are required")
        self.token, self.owner_id, self.store = token, owner_id, store
        self.offset = store.get_telegram_offset()
        self._seen: set[int] = set()

    def handle(self, sender_id: str, text: str) -> str:
        if str(sender_id) != self.owner_id:
            return "Unauthorized."
        parts = text.strip().split()
        if not parts: return "Use /help"
        cmd = parts[0].split("@", 1)[0].lower()
        args = parts[1:]
        if cmd in {"/start", "/help"}:
            return ("DIVATrading Control Center\n/status\n/risk fixed <USDT> | /risk percent <PCT>\n"
                    "/maxloss daily <USDT> | /maxloss daily percent <PCT> | /maxloss streak <N> | /maxloss drawdown percent <PCT>\n"
                    "/leverage auto [MAX] | /margin crossed\n/pause | /resume | /kill | /resetkill confirm")
        if cmd == "/status": return json.dumps(self.store.get(), indent=2)
        if cmd == "/risk" and len(args) == 2:
            s = self.store.set_risk(args[0], args[1]); return f"Risk saved: {s['risk']}"
        if cmd == "/maxloss" and len(args) == 2:
            s = self.store.set_maxloss(args[0], args[1]); return f"Max loss saved: {s['max_loss']}"
        if cmd == "/maxloss" and len(args) == 3 and args[0] == "daily":
            s = self.store.set_maxloss("daily", args[2], args[1]); return f"Daily max loss saved: {s['max_loss']}"
        if cmd == "/maxloss" and len(args) == 3 and args[0] == "drawdown":
            s = self.store.set_maxloss("drawdown", args[2], args[1]); return f"Drawdown saved: {s['max_loss']}"
        if cmd == "/leverage" and len(args) in {1, 2}:
            s = self.store.set_leverage(args[0], args[1] if len(args) == 2 else None); return f"Leverage policy saved: {s['leverage']}"
        if cmd == "/margin" and len(args) == 1:
            s = self.store.set_margin(args[0]); return f"Margin mode saved: {s['margin_mode']}"
        if cmd == "/pause" and not args: self.store.set_runtime(paused=True); return "New entries paused; position supervision must continue."
        if cmd == "/resume" and not args: self.store.set_runtime(paused=False); return "Pause cleared; account readiness gate still applies."
        if cmd == "/kill" and not args: self.store.set_runtime(paused=True, killed=True); return "KILL LATCHED: new entries blocked. Existing positions are not blindly closed."
        if cmd == "/resetkill" and args == ["confirm"]:
            self.store.set_runtime(paused=False, killed=False)
            return "KILL LATCH CLEARED: entry readiness and risk gates still apply."
        return "Invalid command. Use /help"

    def run_forever(self, poll_seconds: int = 25, stop_event: Any | None = None) -> None:
        """Poll until stopped; a lost control channel never stops position supervision."""
        import httpx
        if isinstance(poll_seconds, bool) or not 1 <= poll_seconds <= 50:
            raise ValueError("poll_seconds must be between 1 and 50")
        base = f"https://api.telegram.org/bot{self.token}"
        with httpx.Client(timeout=httpx.Timeout(poll_seconds + 10)) as client:
            while stop_event is None or not stop_event.is_set():
                try:
                    response = client.get(f"{base}/getUpdates", params={"timeout": poll_seconds, "offset": self.offset})
                    response.raise_for_status()
                    payload = response.json()
                except Exception as exc:
                    # Never surface the Bot API URL: it contains the bot token.
                    raise RuntimeError(f"Telegram polling failed ({type(exc).__name__}); token redacted") from None
                if not payload.get("ok"):
                    raise RuntimeError("Telegram getUpdates returned ok=false; response body suppressed")
                for update in payload.get("result", []):
                    uid = int(update["update_id"])
                    if uid < 0:
                        raise RuntimeError("Telegram update id is invalid")
                    if uid in self._seen:
                        self.offset = max(self.offset, uid + 1)
                        self.store.set_telegram_offset(self.offset)
                        continue
                    message = update.get("message") or update.get("edited_message") or {}
                    chat = message.get("chat", {})
                    body = message.get("text", "")
                    if not body:
                        self.offset = max(self.offset, uid + 1)
                        self.store.set_telegram_offset(self.offset)
                        continue
                    sender_id = str((message.get("from") or {}).get("id", ""))
                    try:
                        reply = self.handle(sender_id, body)
                    except (ValueError, ArithmeticError) as exc:
                        reply = f"Invalid setting: {exc}"
                    # Persist acknowledgement only after the command effect is durable.
                    # If a crash happens before this write, replay is safe because all
                    # operator commands are state-setting/idempotent operations.
                    self.offset = max(self.offset, uid + 1)
                    self.store.set_telegram_offset(self.offset)
                    self._seen.add(uid)
                    if len(self._seen) > 5000: self._seen = set(sorted(self._seen)[-2500:])
                    try:
                        client.post(f"{base}/sendMessage", json={"chat_id": chat.get("id"), "text": reply}).raise_for_status()
                    except Exception as exc:
                        raise RuntimeError(f"Telegram reply failed ({type(exc).__name__}); token redacted") from None
