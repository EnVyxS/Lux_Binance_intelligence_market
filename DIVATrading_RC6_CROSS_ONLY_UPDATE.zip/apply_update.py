"""Apply the Cross-only source update to RC6 LEVERAGE_PREFLIGHT_FIX."""
from __future__ import annotations

import argparse
from datetime import UTC, datetime
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile


REPLACEMENTS = {
    "README.md",
    "RELEASE_SHA256_MANIFEST.json",
    "docs/MERGED_TRIAL_ID.md",
    "src/divatrading/cli.py",
    "src/divatrading/execution/service.py",
    "src/divatrading/trading/control_plane.py",
    "src/divatrading/trading/models.py",
    "src/divatrading/trading/risk.py",
    "tests/test_rc6_operator_defaults.py",
    "tests/test_symbol_settings_prepare_rc5.py",
    "tests/test_user_data_stream.py",
}


def replace_file(target: Path, content: bytes) -> None:
    with NamedTemporaryFile(dir=target.parent, delete=False) as stream:
        staged = Path(stream.name)
    try:
        staged.write_bytes(content)
        os.replace(staged, target)
    finally:
        staged.unlink(missing_ok=True)


def apply_update(project: Path, package: Path) -> None:
    manifest = json.loads((package / "update_manifest.json").read_text(encoding="utf-8"))
    if set(manifest) != REPLACEMENTS:
        raise ValueError("Update has an unexpected file list")

    changes = {}
    mismatches = []
    for relative, hashes in sorted(manifest.items()):
        target = project / relative
        if not target.is_file() or not target.resolve().is_relative_to(project):
            mismatches.append(relative)
            continue
        original = target.read_bytes()
        patched = (package / "files" / relative).read_bytes()
        if sha256(patched).hexdigest() != hashes["after"]:
            raise ValueError(f"Update payload checksum mismatch: {relative}")
        current = sha256(original).hexdigest()
        if current == hashes["before"]:
            changes[relative] = (original, patched)
        elif current != hashes["after"]:
            mismatches.append(relative)

    if mismatches:
        raise ValueError("Expected the original LEVERAGE_PREFLIGHT_FIX files. Mismatched files: "
                         + ", ".join(mismatches))
    if not changes:
        print("CROSS_UPDATE_ALREADY_APPLIED")
        return

    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    backup = project / "_rc6_update_backups" / stamp
    for relative, (original, _) in changes.items():
        old = backup / relative
        old.parent.mkdir(parents=True, exist_ok=True)
        old.write_bytes(original)
    print(f"Backup: {backup}", flush=True)

    written = []
    try:
        for relative, (_, patched) in changes.items():
            written.append(relative)
            replace_file(project / relative, patched)
            if (project / relative).read_bytes() != patched:
                raise OSError(f"Post-update verification failed: {relative}")
    except (OSError, KeyboardInterrupt) as error:
        restore_failures = []
        for relative in reversed(written):
            target = project / relative
            original = changes[relative][0]
            try:
                if target.read_bytes() != original:
                    replace_file(target, original)
            except OSError:
                restore_failures.append(relative)
        if restore_failures:
            raise RuntimeError(f"Restore from {backup} before starting the bot. Files: "
                               + ", ".join(restore_failures)) from error
        raise RuntimeError("Update interrupted. Restored original files.") from error

    print(f"CROSS_UPDATE_APPLIED ({len(written)} files)")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path.cwd())
    args = parser.parse_args()
    try:
        apply_update(args.project.resolve(strict=True), Path(__file__).resolve().parent)
    except (OSError, ValueError, RuntimeError) as error:
        print(f"UPDATE_FAILED: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
