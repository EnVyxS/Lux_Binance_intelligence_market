"""Read-only LIVE USDⓈ-M onboarding preflight. Never mutates account state."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import urlsplit
from .binance_private import (
    BinancePrivateApiError, BinancePrivateMetadataError, LIVE_BASE_URL, LIVE_USER_STREAM_BASE_URL,
)
from divatrading.trading.exchange_feasibility import (
    SymbolCommission, SymbolConfiguration, SymbolMetadataError, parse_leverage_brackets,
)


def _metadata_failure(error: Exception) -> str:
    if isinstance(error, (SymbolMetadataError, BinancePrivateMetadataError)):
        return str(error)
    if isinstance(error, BinancePrivateApiError):
        code = f", Binance code {error.code}" if type(error.code) is int else ""
        return f"HTTP {error.status_code}{code}"
    return type(error).__name__

@dataclass(frozen=True, slots=True)
class LiveCheck:
    code: str
    status: str
    detail: str

@dataclass(frozen=True, slots=True)
class LivePreflightReport:
    status: str
    environment: str
    rest_host: str
    websocket_host: str
    wallet_balance_usdt: str | None
    available_balance_usdt: str | None
    position_mode: str | None
    active_positions: int | None
    open_standard_orders: int | None
    open_algo_orders: int | None
    symbols: tuple[str, ...]
    checks: tuple[LiveCheck, ...]
    order_submission_performed: bool = False
    account_mutation_performed: bool = False
    @property
    def ready_for_next_stage(self) -> bool:
        return self.status == "READ_ONLY_PREFLIGHT_PASSED"
    def to_dict(self) -> dict[str, Any]:
        d = asdict(self); d["symbols"] = list(self.symbols); d["checks"] = [asdict(x) for x in self.checks]; return d

class BinanceLiveReadOnlyPreflight:
    """Initial clean-account gate; any unknown exposure/order blocks progression."""
    def __init__(self, client: Any, *, symbols: tuple[str, ...] = ("BTCUSDT",), max_time_sync_rtt_ms: int = 2000):
        if not symbols: raise ValueError("At least one symbol is required")
        self.client = client
        self.symbols = tuple(dict.fromkeys(str(x).strip().upper() for x in symbols))
        if any(not x or not x.isalnum() for x in self.symbols): raise ValueError("Invalid symbol")
        self.max_rtt = max_time_sync_rtt_ms
        self.checks: list[LiveCheck] = []
    def add(self, code: str, status: str, detail: str) -> None: self.checks.append(LiveCheck(code, status, detail))
    @staticmethod
    def dec(v: Any, name: str) -> Decimal:
        try: d = Decimal(str(v))
        except (InvalidOperation, ValueError, TypeError): raise ValueError(f"Invalid {name}")
        if not d.is_finite(): raise ValueError(f"Non-finite {name}")
        return d
    @staticmethod
    def rows(v: Any, name: str) -> list[dict[str, Any]]:
        if not isinstance(v, list) or any(not isinstance(x, dict) for x in v): raise ValueError(f"Invalid {name} response")
        return v
    def run(self) -> LivePreflightReport:
        host = urlsplit(self.client.base_url).hostname or ""
        if self.client.environment != "LIVE" or self.client.base_url.rstrip("/") != LIVE_BASE_URL:
            self.add("ENDPOINT_PINNING", "FAIL", "Client is not pinned to official Binance LIVE USD-M REST host")
            return self.report(None, None, None, None, None, None)
        self.add("ENDPOINT_PINNING", "PASS", "Official Binance LIVE REST endpoint pinned")
        for code, fn in (("REST_PING", self.client.ping), ("SERVER_TIME", self.client.sync_server_time)):
            try:
                fn()
                if code == "SERVER_TIME" and int(getattr(self.client, "last_time_sync_rtt_ms", 0)) > self.max_rtt:
                    self.add(code, "FAIL", "Server time RTT exceeds configured limit")
                else: self.add(code, "PASS", "Read-only endpoint succeeded")
            except Exception as e: self.add(code, "FAIL", f"Request failed: {type(e).__name__}")
        wallet = available = position_mode = None
        active = standard_n = algo_n = None
        symbols_ok: list[str] = []
        try:
            info = self.client.get_exchange_info(); rows = self.rows(info.get("symbols"), "exchangeInfo")
            by_symbol = {r.get("symbol"): r for r in rows}
            for symbol in self.symbols:
                row = by_symbol.get(symbol)
                if not row or row.get("status") != "TRADING" or row.get("contractType") != "PERPETUAL" or row.get("quoteAsset") != "USDT":
                    self.add("SYMBOL_"+symbol, "FAIL", "Not an active USDT perpetual")
                else: symbols_ok.append(symbol); self.add("SYMBOL_"+symbol, "PASS", "Active USDT perpetual metadata found")
        except Exception as e: self.add("EXCHANGE_INFO", "FAIL", f"Metadata request failed: {type(e).__name__}")
        try:
            account = self.client.get_exchange_account()
            wallet = str(self.dec(account.get("totalWalletBalance"), "wallet balance")); available = str(self.dec(account.get("availableBalance"), "available balance"))
            self.add("SIGNED_ACCOUNT", "PASS", "Signed LIVE account read succeeded")
            if self.dec(available, "available balance") <= 0: self.add("AVAILABLE_BALANCE", "FAIL", "Available USDT balance is not positive")
            else: self.add("AVAILABLE_BALANCE", "PASS", "Available balance is positive")
        except Exception as e: self.add("SIGNED_ACCOUNT", "FAIL", f"Account read failed: {type(e).__name__}")
        try:
            cfg = self.client.get_account_config()
            if cfg.get("canTrade") is True: self.add("CAN_TRADE", "PASS", "Exchange reports canTrade=true")
            else: self.add("CAN_TRADE", "FAIL", "Exchange does not confirm canTrade=true")
            if cfg.get("multiAssetsMargin") is False: self.add("SINGLE_ASSET_MODE", "PASS", "Single-asset mode confirmed")
            else: self.add("SINGLE_ASSET_MODE", "FAIL", "Multi-Assets mode enabled or unknown")
        except Exception as e: self.add("ACCOUNT_CONFIG", "FAIL", f"Account config unavailable: {type(e).__name__}")
        try:
            mode = self.client.get_position_mode(); dual = mode.get("dualSidePosition")
            if isinstance(dual, bool): position_mode = "HEDGE" if dual else "ONE_WAY"; self.add("POSITION_MODE", "PASS", position_mode)
            else: self.add("POSITION_MODE", "FAIL", "Position mode missing/invalid")
        except Exception as e: self.add("POSITION_MODE", "FAIL", f"Position mode unavailable: {type(e).__name__}")
        for code, fn in (("POSITIONS", self.client.get_position_risk), ("STANDARD_ORDERS", self.client.get_open_orders), ("ALGO_ORDERS", self.client.get_open_algo_orders)):
            try:
                data = self.rows(fn(), code)
                if code == "POSITIONS":
                    active = sum(1 for x in data if self.dec(x.get("positionAmt", "0"), "positionAmt") != 0)
                elif code == "STANDARD_ORDERS": standard_n = len(data)
                else: algo_n = len(data)
                count = active if code == "POSITIONS" else standard_n if code == "STANDARD_ORDERS" else algo_n
                self.add(code, "PASS" if count == 0 else "FAIL", "No external exposure/orders" if count == 0 else f"{count} active row(s); clean dedicated account required")
            except Exception as e: self.add(code, "FAIL", f"Read failed: {type(e).__name__}")
        # Per-symbol leverage brackets are read-only and are required before any leverage decision.
        for symbol in symbols_ok:
            try:
                brackets = parse_leverage_brackets(self.client.get_leverage_brackets(symbol), symbol)
                self.add("LEVERAGE_BRACKETS_"+symbol, "PASS", f"{len(brackets)} typed account-specific tier(s) parsed")
            except Exception as e:
                self.add("LEVERAGE_BRACKETS_"+symbol, "FAIL", _metadata_failure(e))
            try:
                commission = SymbolCommission.from_binance(self.client.get_commission_rate(symbol))
                self.add("COMMISSION_RATE_"+symbol, "PASS", f"Maker/taker commission retrieved ({commission.maker_rate}/{commission.taker_rate})")
            except Exception as e: self.add("COMMISSION_RATE_"+symbol, "FAIL", f"Commission read/parse failed: {type(e).__name__}")
            try:
                config = SymbolConfiguration.from_binance(self.client.get_symbol_config(symbol), symbol)
                self.add("SYMBOL_CONFIG_"+symbol, "PASS",
                         f"Current marginType={config.margin_type} leverage={config.leverage}; read-only")
            except Exception as e:
                self.add("SYMBOL_CONFIG_"+symbol, "FAIL", _metadata_failure(e))
        return self.report(wallet, available, position_mode, active, standard_n, algo_n, tuple(symbols_ok))
    def report(self, wallet, available, position_mode, active, standard_n, algo_n, symbols=None):
        failed = any(x.status == "FAIL" for x in self.checks)
        return LivePreflightReport("BLOCKED_LIVE_PREFLIGHT" if failed else "READ_ONLY_PREFLIGHT_PASSED", "LIVE", urlsplit(self.client.base_url).hostname or "", urlsplit(LIVE_USER_STREAM_BASE_URL).hostname or "", wallet, available, position_mode, active, standard_n, algo_n, tuple(symbols or ()), tuple(self.checks))
