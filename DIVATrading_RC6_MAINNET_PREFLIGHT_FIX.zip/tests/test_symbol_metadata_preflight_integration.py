"""End-to-end metadata checks with the signed transport and read-only preflight."""

from collections import Counter

import httpx
import pytest

from divatrading.execution.binance_private import BinancePrivateRestClient
from divatrading.execution.live_preflight import BinanceLiveReadOnlyPreflight


pytestmark = pytest.mark.usefixtures("isolated_cli_environment")

SYMBOL = "BTCUSDT"
NOW = 1_800_000_000_000
API_KEY = "mock-preflight-api-key"
API_SECRET = "mock-preflight-api-secret"
UNSAFE_DETAIL = "untrusted-metadata-detail"
LEVERAGE = "/fapi/v1/leverageBracket"
CONFIG = "/fapi/v1/symbolConfig"
METADATA_CHECKS = {
    LEVERAGE: f"LEVERAGE_BRACKETS_{SYMBOL}",
    CONFIG: f"SYMBOL_CONFIG_{SYMBOL}",
}

BRACKET_ROW = {
    "symbol": SYMBOL,
    "brackets": [{
        "bracket": 1,
        "initialLeverage": 20,
        "notionalFloor": "0",
        "notionalCap": "50000",
        "maintMarginRatio": "0.004",
        "cum": "0",
    }],
}
CONFIG_ROW = {"symbol": SYMBOL, "marginType": "CROSS", "leverage": "20.0"}


def _run_preflight(*, brackets=BRACKET_ROW, config=CONFIG_ROW, status_overrides=None):
    responses = {
        "/fapi/v1/ping": {},
        "/fapi/v1/time": {"serverTime": NOW},
        "/fapi/v1/exchangeInfo": {"symbols": [{
            "symbol": SYMBOL, "status": "TRADING", "contractType": "PERPETUAL", "quoteAsset": "USDT",
        }]},
        "/fapi/v3/account": {"totalWalletBalance": "25", "availableBalance": "20"},
        "/fapi/v1/accountConfig": {"canTrade": True, "multiAssetsMargin": False},
        "/fapi/v1/positionSide/dual": {"dualSidePosition": False},
        "/fapi/v3/positionRisk": [{"symbol": SYMBOL, "positionAmt": "0"}],
        "/fapi/v1/openOrders": [],
        "/fapi/v1/openAlgoOrders": [],
        "/fapi/v1/commissionRate": {"makerCommissionRate": "0.0002", "takerCommissionRate": "0.0005"},
        LEVERAGE: brackets,
        CONFIG: config,
    }
    seen = []

    def handle(request):
        seen.append(request)
        path = request.url.path
        return httpx.Response((status_overrides or {}).get(path, 200), json=responses[path])

    with httpx.Client(transport=httpx.MockTransport(handle), trust_env=False) as http:
        client = BinancePrivateRestClient(
            API_KEY, API_SECRET, environment="LIVE", http_client=http, wall_clock_ms=lambda: NOW,
        )
        report = BinanceLiveReadOnlyPreflight(client, symbols=(SYMBOL,)).run()

    assert Counter(request.url.path for request in seen) == Counter(responses.keys())
    assert all(request.url.host == "fapi.binance.com" and request.method == "GET" for request in seen)
    for request in seen:
        if request.url.path in (LEVERAGE, CONFIG):
            assert request.url.params["symbol"] == SYMBOL
            assert "signature" in request.url.params
    assert report.account_mutation_performed is False
    assert report.order_submission_performed is False
    rendered = repr(report.to_dict())
    assert all(value not in rendered for value in (API_KEY, API_SECRET, UNSAFE_DETAIL, "signature="))
    return report, {check.code: check for check in report.checks}


@pytest.mark.parametrize(
    "config,expected_margin",
    [
        (CONFIG_ROW, "CROSSED"),
        ([{"symbol": SYMBOL, "marginType": "isolated", "leverage": 20}], "ISOLATED"),
    ],
)
def test_preflight_reads_scoped_leverage_object_with_either_symbol_config_shape(config, expected_margin):
    report, checks = _run_preflight(config=config)

    assert report.ready_for_next_stage
    assert checks[METADATA_CHECKS[LEVERAGE]].status == "PASS"
    assert checks[METADATA_CHECKS[CONFIG]].status == "PASS"
    assert f"marginType={expected_margin} leverage=20;" in checks[METADATA_CHECKS[CONFIG]].detail


@pytest.mark.parametrize(
    "endpoint,payload,reason",
    [
        (LEVERAGE, {"detail": UNSAFE_DETAIL}, "INVALID_LEVERAGE_BRACKET_RESPONSE_SHAPE"),
        (LEVERAGE, {**BRACKET_ROW, "brackets": []}, "BRACKET_TIERS_MISSING"),
        (LEVERAGE, [BRACKET_ROW, BRACKET_ROW], "SYMBOL_ROW_DUPLICATE"),
        (LEVERAGE, {**BRACKET_ROW, "symbol": "ETHUSDT"}, "SYMBOL_ROW_MISSING"),
        (CONFIG, [UNSAFE_DETAIL], "INVALID_SYMBOL_CONFIG_RESPONSE_SHAPE"),
        (CONFIG, {**CONFIG_ROW, "marginType": UNSAFE_DETAIL}, "INVALID_MARGIN_TYPE"),
        (CONFIG, {**CONFIG_ROW, "leverage": "20.5"}, "INVALID_LEVERAGE"),
        (CONFIG, [CONFIG_ROW, CONFIG_ROW], "SYMBOL_ROW_DUPLICATE"),
        (CONFIG, [], "SYMBOL_ROW_MISSING"),
    ],
)
def test_preflight_blocks_unusable_symbol_metadata_with_safe_diagnostic(endpoint, payload, reason):
    report, checks = _run_preflight(**({"brackets": payload} if endpoint == LEVERAGE else {"config": payload}))

    assert not report.ready_for_next_stage
    failed = [check for check in checks.values() if check.status == "FAIL"]
    assert [(check.code, check.detail) for check in failed] == [(METADATA_CHECKS[endpoint], reason)]


def test_preflight_reports_provider_status_without_exposing_metadata_error_body():
    report, checks = _run_preflight(
        brackets={"code": -1100, "msg": f"{UNSAFE_DETAIL} {API_KEY} {API_SECRET} signature=mock-signature"},
        status_overrides={LEVERAGE: 400},
    )

    assert not report.ready_for_next_stage
    check = checks[METADATA_CHECKS[LEVERAGE]]
    assert check.status == "FAIL"
    assert check.detail == "HTTP 400, Binance code -1100"
