# Test Report v0.50.0

- Full regression suite: **838 passed**.
- New reliability tests: process lock contention/release, unknown discrepancy fail-closed behavior, discrepancy policy categories, worker stale heartbeat.
- `python -m compileall -q src/divatrading`: PASS.
- `python -m divatrading --help`: PASS; `runtime-status`, `account-runtime`, and `market-runtime` are registered.
- Clean extraction test: see companion report.

Environment: Linux, Python 3.13.5. Project target remains Python 3.12.9. No Binance TESTNET/LIVE network calls or order submissions were performed. These are local deterministic tests, not exchange integration certification.
