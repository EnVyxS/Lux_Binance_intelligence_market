# v0.49.0 — Managed Position Supervisor (2026-11-13)

- Adds per-symbol Mark Price workers with symbol/timestamp validation, bounded symbol capacity, stale-feed detection, restart and fail-closed halt semantics.
- Integrates the supervisor into `account-runtime` beside User Data Stream, lifecycle event reducer and periodic REST reconciliation.
- Dispatches partial TP and BE/trailing STOP replacement actions automatically from fresh Mark Price observations.
- Adds full structural-invalidation MARKET exit at the approved TradePlan stop boundary and explicit operator `emergency-close` CLI flow.
- Uses exact current ExchangeInfo MARKET quantity filters and PRICE_FILTER tick size for lifecycle actions.
- Confirms full exits against REST position quantity, removes only DIVA-linked protection after flat confirmation, and releases risk only after verified finalization.
- Adds cumulative partial TP target accounting based on original position quantity; terminal partial fills do not cause the 50% target to be recomputed against a smaller residual.
- Allows existing-position management during a new-entry halt only if exchange reconciliation remains discrepancy-free, fresh and event-watermark-consistent.
- Adds per-symbol/position-side single managed signal guard; same-side scale-in is deliberately unsupported.
- Full regression: 834 passed; focused lifecycle/supervisor: 37 passed; compileall, CLI help and clean extraction: PASS.
- No real Binance TESTNET/LIVE request/order/stream was performed; Windows target not tested.
