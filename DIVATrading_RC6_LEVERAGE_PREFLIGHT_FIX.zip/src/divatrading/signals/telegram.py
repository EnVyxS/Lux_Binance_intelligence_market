"""Signal-only Telegram publication with durable deduplication and chart rendering.

This module can only publish an already-qualified SMC signal. It has no exchange
client and no order-submission API by design.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime
from decimal import Decimal
from io import BytesIO
from pathlib import Path
from typing import Any, Iterable

from divatrading.core.database import Database, utc_now_iso
from divatrading.intelligence.kronos import KronosForecast
from divatrading.market_data.klines import Kline
from divatrading.trading.models import QualifiedSignal


class TelegramSignalError(RuntimeError):
    """Signal delivery or chart-generation failure; Telegram token is never echoed."""


class SignalPublicationStore:
    """SQLite-backed signal/forecast ledger with insert-once publication claims."""

    def __init__(self, database: Database) -> None:
        self.database = database
        self.database.initialize()
        if self.database.schema_version() < 6:
            raise RuntimeError("Signal Center requires database schema version 6 or later")

    def reserve(self, signal: QualifiedSignal, *, payload: dict[str, Any]) -> bool:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        now = utc_now_iso()
        with self.database.transaction() as connection:
            cursor = connection.execute(
                """INSERT OR IGNORE INTO signal_publications (
                    signal_id, symbol, timeframe, side, created_at_ms, status,
                    signal_json, created_at_utc, updated_at_utc
                ) VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?)""",
                (signal.signal_id, signal.symbol, signal.timeframe, signal.side,
                 signal.created_at_ms, encoded, now, now),
            )
            return cursor.rowcount == 1

    def save_forecast(self, signal_id: str, forecast: KronosForecast) -> None:
        payload = json.dumps(forecast.to_dict(), sort_keys=True, separators=(",", ":"))
        with self.database.transaction() as connection:
            connection.execute(
                """INSERT OR IGNORE INTO kronos_shadow_forecasts (
                    forecast_id, symbol, interval, last_observed_open_time_ms,
                    model_revision, forecast_json, created_at_utc
                ) VALUES (?, ?, '5m', ?, ?, ?, ?)""",
                (forecast.forecast_id, forecast.symbol, forecast.last_observed_open_time_ms,
                 forecast.model_revision, payload, utc_now_iso()),
            )
            connection.execute(
                "INSERT OR IGNORE INTO signal_forecast_links(signal_id, forecast_id) VALUES (?, ?)",
                (signal_id, forecast.forecast_id),
            )

    def finish(self, signal_id: str, status: str, *, message_id: str | None = None, error_code: str | None = None) -> None:
        if status not in {"SENT", "DELIVERY_UNKNOWN", "FAILED"}:
            raise ValueError("invalid publication terminal status")
        with self.database.transaction() as connection:
            connection.execute(
                """UPDATE signal_publications SET status=?, telegram_message_id=?,
                   error_code=?, updated_at_utc=? WHERE signal_id=?""",
                (status, message_id, error_code, utc_now_iso(), signal_id),
            )

    def forecast(self, forecast_id: str) -> dict[str, Any] | None:
        with self.database.connection() as connection:
            row = connection.execute(
                "SELECT * FROM kronos_shadow_forecasts WHERE forecast_id=?", (forecast_id,)
            ).fetchone()
        if row is None:
            return None
        return {
            "forecast_id": row["forecast_id"],
            "symbol": row["symbol"], "interval": row["interval"],
            "last_observed_open_time_ms": row["last_observed_open_time_ms"],
            "model_revision": row["model_revision"],
            "forecast": json.loads(row["forecast_json"]),
        }

    def save_evaluation(self, forecast_id: str, evaluation: dict[str, Any]) -> None:
        encoded = json.dumps(evaluation, sort_keys=True, separators=(",", ":"))
        with self.database.transaction() as connection:
            connection.execute(
                """INSERT INTO kronos_shadow_evaluations(forecast_id, evaluation_json, evaluated_at_utc)
                   VALUES (?, ?, ?) ON CONFLICT(forecast_id) DO UPDATE SET
                   evaluation_json=excluded.evaluation_json, evaluated_at_utc=excluded.evaluated_at_utc""",
                (forecast_id, encoded, utc_now_iso()),
            )

    def history(self, *, limit: int = 50) -> tuple[dict[str, Any], ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
            raise ValueError("limit must be between 1 and 500")
        with self.database.connection() as connection:
            rows = connection.execute(
                "SELECT * FROM signal_publications ORDER BY created_at_ms DESC LIMIT ?", (limit,)
            ).fetchall()
        return tuple({
            "signal_id": row["signal_id"], "symbol": row["symbol"],
            "timeframe": row["timeframe"], "side": row["side"],
            "created_at_ms": row["created_at_ms"], "status": row["status"],
            "telegram_message_id": row["telegram_message_id"], "error_code": row["error_code"],
            "signal": json.loads(row["signal_json"]),
        } for row in rows)


def _one_r_target(signal: QualifiedSignal) -> Decimal:
    distance = abs(signal.entry_price - signal.stop_loss)
    return signal.entry_price + distance if signal.side == "LONG" else signal.entry_price - distance


def _price(value: Decimal) -> str:
    return format(value, "f")


def render_signal_chart(
    signal: QualifiedSignal,
    candles: Iterable[Kline],
    *,
    ob_zone: tuple[Decimal, Decimal] | None = None,
    forecast: KronosForecast | None = None,
    forecast_status: str = "UNAVAILABLE",
) -> bytes:
    """Render actual M5 candles and distinctly dashed Kronos forecast bars."""
    if not isinstance(signal, QualifiedSignal):
        raise TypeError("signal must be QualifiedSignal")
    rows = tuple(candles)
    if len(rows) < 10 or any(not isinstance(item, Kline) for item in rows):
        raise TelegramSignalError("at least 10 validated candles are required for a signal chart")
    if any(item.exchange != "BINANCE_UM" or item.symbol != signal.symbol or item.interval != "5m" for item in rows):
        raise TelegramSignalError("signal chart requires Binance USD-M M5 candles for the same symbol")
    if any(rows[i].open_time_ms >= rows[i + 1].open_time_ms for i in range(len(rows) - 1)):
        raise TelegramSignalError("chart candles must be chronological and unique")
    chart_rows = rows[-100:]
    if any(
        chart_rows[i + 1].open_time_ms - chart_rows[i].open_time_ms != 300_000
        for i in range(len(chart_rows) - 1)
    ):
        raise TelegramSignalError("chart candles contain an M5 gap; no interpolated chart is allowed")
    if forecast is not None and (forecast.symbol != signal.symbol or forecast.interval != "5m"):
        raise TelegramSignalError("Kronos forecast must match the signal symbol and M5 timeframe")

    try:
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        from matplotlib.figure import Figure
        from matplotlib.patches import Rectangle
    except ImportError as exc:
        raise TelegramSignalError("chart dependency missing; run kronos-install to install matplotlib") from exc

    rows = chart_rows
    figure = Figure(figsize=(13.5, 7.6), dpi=150, facecolor="#10151f")
    canvas = FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    axis.set_facecolor("#10151f")
    actual_count = len(rows)
    forecast_count = len(forecast.forecast_bars) if forecast else 0
    gap = 2
    axis.set_xlim(-1, actual_count + forecast_count + gap + 1)
    all_values = [float(value) for row in rows for value in (row.high, row.low)]
    if forecast:
        all_values.extend(float(value) for bar in forecast.forecast_bars for value in (bar.high, bar.low))
    all_values.extend(float(value) for value in (signal.entry_price, signal.stop_loss, signal.take_profit, _one_r_target(signal)))
    if ob_zone:
        all_values.extend(float(value) for value in ob_zone)
    low = min(all_values)
    high = max(all_values)
    span = max(high - low, abs(high) * 0.001, 1e-9)
    axis.set_ylim(low - span * 0.12, high + span * 0.16)

    if ob_zone:
        zlow, zhigh = sorted(float(value) for value in ob_zone)
        axis.axhspan(zlow, zhigh, color="#f59e0b", alpha=0.16, label="SMC ORDER BLOCK")

    for index, row in enumerate(rows):
        up = row.close >= row.open
        color = "#22c55e" if up else "#ef4444"
        axis.vlines(index, float(row.low), float(row.high), color=color, linewidth=1.0, zorder=3)
        bottom = min(float(row.open), float(row.close))
        height = max(abs(float(row.close - row.open)), span * 0.0012)
        axis.add_patch(Rectangle((index - 0.31, bottom), 0.62, height,
                                 facecolor=color, edgecolor=color, linewidth=0.6, zorder=4))

    forecast_boundary = actual_count - 0.5
    if forecast:
        axis.axvline(forecast_boundary, color="#a78bfa", linestyle=(0, (4, 3)), linewidth=1.2)
        for index, bar in enumerate(forecast.forecast_bars):
            x = actual_count + gap + index
            color = "#c4b5fd" if bar.close >= bar.open else "#f0abfc"
            axis.vlines(x, float(bar.low), float(bar.high), color=color, linewidth=1.3,
                        linestyle=(0, (3, 2)), zorder=3)
            bottom = min(float(bar.open), float(bar.close))
            height = max(abs(float(bar.close - bar.open)), span * 0.0012)
            axis.add_patch(Rectangle((x - 0.28, bottom), 0.56, height,
                                     facecolor="none", edgecolor=color, linewidth=1.2,
                                     linestyle=(0, (3, 2)), zorder=4))
        axis.text(actual_count + gap, high + span * 0.10,
                  f"KRONOS-MINI SHADOW • {forecast.horizon_bars} x M5 • {forecast.direction}",
                  color="#c4b5fd", fontsize=8, ha="left", va="center")
    else:
        axis.text(actual_count + 0.3, high + span * 0.10,
                  f"KRONOS: {forecast_status}", color="#fbbf24", fontsize=8, ha="left")

    levels = [
        (signal.entry_price, "ENTRY", "#38bdf8", "-") ,
        (signal.stop_loss, "SL", "#ef4444", "--"),
        (_one_r_target(signal), "TP1 • 1R", "#fbbf24", ":"),
        (signal.take_profit, "FINAL TP", "#22c55e", "-.") ,
    ]
    for value, label, color, style in levels:
        axis.axhline(float(value), color=color, linestyle=style, linewidth=1.0, alpha=0.95)
        axis.text(actual_count + forecast_count + gap + 0.8, float(value),
                  f"{label}  {_price(value)}", color=color, fontsize=8,
                  va="center", ha="left", clip_on=False)
    rr = signal.reward_risk
    axis.set_title(
        f"{signal.symbol}  |  {signal.side}  |  SMC {signal.timeframe.upper()}  |  "
        f"GROSS RRR 1:{rr.quantize(Decimal('0.01'))}",
        color="#f8fafc", fontsize=13, loc="left", pad=14, fontweight="bold",
    )
    axis.text(0.01, 0.985,
              "ACTUAL BINANCE M5 CANDLES  •  KRONOS PROJECTION IS NOT ACTUAL PRICE OR A TRADE CONFIRMATION",
              transform=axis.transAxes, color="#94a3b8", fontsize=7, va="top")
    axis.grid(True, color="#334155", alpha=0.45, linewidth=0.5)
    axis.tick_params(colors="#94a3b8", labelsize=7)
    for spine in axis.spines.values():
        spine.set_color("#475569")
    axis.set_ylabel("Price (USDT)", color="#cbd5e1", fontsize=8)
    axis.set_xticks([0, actual_count // 2, actual_count - 1] + ([actual_count + gap + forecast_count // 2] if forecast else []))
    axis.set_xticklabels(["Historical", "", "Last closed M5"] + (["Forecast horizon"] if forecast else []))
    figure.subplots_adjust(left=0.07, right=0.82, top=0.90, bottom=0.12)
    buffer = BytesIO()
    canvas.print_png(buffer)
    figure.clear()
    result = buffer.getvalue()
    if not result.startswith(b"\x89PNG\r\n\x1a\n"):
        raise TelegramSignalError("chart renderer did not produce a PNG image")
    return result


class SignalTelegramPublisher:
    """Outbound-only Telegram signal delivery. Does not poll Telegram updates."""

    def __init__(self, token: str, chat_id: str, store: SignalPublicationStore) -> None:
        if not token or not chat_id or not str(chat_id).lstrip("-").isdigit():
            raise ValueError("Telegram token and numeric signal chat ID are required")
        self.token = token
        self.chat_id = str(chat_id)
        self.store = store

    def publish(
        self,
        signal: QualifiedSignal,
        candles: Iterable[Kline],
        *,
        ob_zone: tuple[Decimal, Decimal] | None = None,
        forecast: KronosForecast | None = None,
        forecast_status: str = "UNAVAILABLE",
    ) -> bool:
        payload = {
            "signal_id": signal.signal_id, "symbol": signal.symbol, "side": signal.side,
            "timeframe": signal.timeframe, "entry_type": signal.entry_type,
            "entry": str(signal.entry_price), "stop_loss": str(signal.stop_loss),
            "take_profit": str(signal.take_profit), "gross_rrr": str(signal.reward_risk),
            "created_at_ms": signal.created_at_ms, "reason_codes": list(signal.reason_codes),
        }
        if not self.store.reserve(signal, payload=payload):
            return False
        try:
            if forecast is not None:
                self.store.save_forecast(signal.signal_id, forecast)
            png = render_signal_chart(
                signal, candles, ob_zone=ob_zone, forecast=forecast, forecast_status=forecast_status,
            )
        except Exception as exc:
            self.store.finish(signal.signal_id, "FAILED", error_code=f"CHART_{type(exc).__name__}")
            raise
        target = _one_r_target(signal)
        caption = (
            f"DIVA SIGNAL • READY\n{signal.symbol} {signal.side} • {signal.timeframe.upper()}\n"
            f"Entry: {_price(signal.entry_price)} ({signal.entry_type})\n"
            f"SL: {_price(signal.stop_loss)}\nTP1 (1R): {_price(target)}\n"
            f"Final TP: {_price(signal.take_profit)}\n"
            f"Gross RRR: 1:{signal.reward_risk.quantize(Decimal('0.01'))} (fees/slippage excluded)\n"
            f"Net RRR: NOT_CALCULATED (fee tier/slippage profile not configured)\n"
            f"Reasons: {', '.join(signal.reason_codes[:4]) or 'SMC_QUALIFIED'}\n"
            f"Score: {signal.score if signal.score is not None else 'N/A'}\n"
            f"Kronos M5: {forecast.direction} / {forecast.horizon_bars} bars / "
            f"projected return {forecast.projected_return_pct.quantize(Decimal('0.01'))}%"
            if forecast else
            f"DIVA SIGNAL • READY\n{signal.symbol} {signal.side} • {signal.timeframe.upper()}\n"
            f"Entry: {_price(signal.entry_price)} ({signal.entry_type})\nSL: {_price(signal.stop_loss)}\n"
            f"TP1 (1R): {_price(target)}\nFinal TP: {_price(signal.take_profit)}\n"
            f"Gross RRR: 1:{signal.reward_risk.quantize(Decimal('0.01'))} (fees/slippage excluded)\n"
            f"Net RRR: NOT_CALCULATED (fee tier/slippage profile not configured)\n"
            f"Reasons: {', '.join(signal.reason_codes[:4]) or 'SMC_QUALIFIED'}\n"
            f"Score: {signal.score if signal.score is not None else 'N/A'}\n"
            f"Kronos M5: {forecast_status} (shadow only)"
        )
        try:
            import httpx
            base = f"https://api.telegram.org/bot{self.token}"
            with httpx.Client(timeout=httpx.Timeout(20.0)) as client:
                response = client.post(
                    f"{base}/sendPhoto",
                    data={"chat_id": self.chat_id, "caption": caption[:1024]},
                    files={"photo": (f"{signal.signal_id}.png", png, "image/png")},
                )
                response.raise_for_status()
                result = response.json()
                if not result.get("ok"):
                    raise TelegramSignalError("Telegram sendPhoto returned ok=false; response body suppressed")
                message_id = str((result.get("result") or {}).get("message_id", "")) or None
        except Exception as exc:
            self.store.finish(signal.signal_id, "DELIVERY_UNKNOWN", error_code=type(exc).__name__)
            if isinstance(exc, TelegramSignalError):
                raise
            raise TelegramSignalError(f"Telegram signal delivery failed ({type(exc).__name__}); token redacted") from None
        self.store.finish(signal.signal_id, "SENT", message_id=message_id)
        return True


__all__ = [
    "SignalPublicationStore", "SignalTelegramPublisher", "TelegramSignalError",
    "render_signal_chart",
]
