"""Bounded public Binance USDⓈ-M Futures Aggregate Trade WebSocket feed."""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Iterable

from websockets.asyncio.client import connect as websocket_connect

from divatrading.market_data.websocket import (
    WEBSOCKET_MAX_FRAME_QUEUE,
    WEBSOCKET_MAX_MESSAGE_BYTES,
)

BINANCE_UM_AGG_TRADE_WS_ENDPOINT = "wss://fstream.binance.com/market/ws"
DEFAULT_AGG_TRADE_MAX_SUBSCRIPTIONS = 16
HARD_MAX_AGG_TRADE_SUBSCRIPTIONS = 48
DEFAULT_AGG_TRADE_QUEUE_CAPACITY = 8192
HARD_MAX_AGG_TRADE_QUEUE_CAPACITY = 32768
DEFAULT_AGG_TRADE_MAX_AGE_MS = 10_000
DEFAULT_AGG_TRADE_FUTURE_SKEW_MS = 5_000
_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{2,30}$")


class AggregateTradeWebSocketError(RuntimeError):
    """Base error for the public Aggregate Trade feed."""


class AggregateTradeWebSocketParseError(AggregateTradeWebSocketError):
    """Raised when an Aggregate Trade event cannot be normalized safely."""


class AggregateTradeWebSocketProtocolError(AggregateTradeWebSocketError):
    """Raised when Binance rejects a WebSocket request or subscription."""


class AggregateTradeStaleEventError(AggregateTradeWebSocketParseError):
    """Raised when an event is outside the configured freshness window."""


class AggregateTradeQueueFullError(AggregateTradeWebSocketError):
    """Raised rather than silently dropping an Aggregate Trade update."""


class AggregateTradeReconnectExhausted(AggregateTradeWebSocketError):
    """Raised after the configured number of consecutive reconnect attempts."""


@dataclass(frozen=True, slots=True)
class AggregateTradeEvent:
    """One Binance aggregate trade, grouped by taker order/price/time.

    ``buyer_is_maker`` follows Binance's ``m`` field. When true, the buyer
    was passive and the seller was the taker/aggressor. When false, the buyer
    was the taker/aggressor. Signed volume is therefore negative for sell
    aggression and positive for buy aggression.
    """

    symbol: str
    aggregate_trade_id: int
    price: Decimal
    quantity: Decimal
    first_trade_id: int
    last_trade_id: int
    event_time_ms: int
    trade_time_ms: int
    buyer_is_maker: bool
    source_endpoint: str
    stream_name: str
    received_at_utc: datetime
    missed_aggregate_trades_before: int = 0

    @property
    def aggressor_side(self) -> str:
        """Return BUY or SELL for the taker-initiated side."""
        return "SELL" if self.buyer_is_maker else "BUY"

    @property
    def is_buy_initiated(self) -> bool:
        return not self.buyer_is_maker

    @property
    def is_sell_initiated(self) -> bool:
        return self.buyer_is_maker

    @property
    def signed_quantity(self) -> Decimal:
        """Base-asset quantity signed by taker aggression (buy positive)."""
        return -self.quantity if self.buyer_is_maker else self.quantity

    @property
    def quote_quantity(self) -> Decimal:
        """Exact price × base quantity in quote-asset terms."""
        return self.price * self.quantity

    @property
    def signed_quote_quantity(self) -> Decimal:
        return self.price * self.signed_quantity

    @property
    def underlying_trade_count(self) -> int:
        """Number of trade IDs represented by the inclusive first/last range."""
        return self.last_trade_id - self.first_trade_id + 1

    @property
    def event_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(
            milliseconds=self.event_time_ms
        )

    @property
    def trade_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(
            milliseconds=self.trade_time_ms
        )


@dataclass(slots=True)
class AggregateTradeFeedStats:
    """Counters updated by the feed's single asyncio task."""

    connection_count: int = 0
    reconnect_attempts: int = 0
    subscription_messages_sent: int = 0
    messages_received: int = 0
    events_emitted: int = 0
    acknowledgements_received: int = 0
    malformed_messages: int = 0
    stale_messages: int = 0
    duplicate_or_out_of_order_messages: int = 0
    aggregate_id_gaps: int = 0
    queue_overflows: int = 0
    last_error: str | None = None


def _exact_integer(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise AggregateTradeWebSocketParseError(f"{field_name} must be an integer")
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise AggregateTradeWebSocketParseError(
            f"{field_name} must be an integer"
        ) from exc
    if str(value).strip() not in {str(parsed), f"{parsed}.0"}:
        raise AggregateTradeWebSocketParseError(
            f"{field_name} must be an exact integer"
        )
    if parsed < 0:
        raise AggregateTradeWebSocketParseError(f"{field_name} cannot be negative")
    return parsed


def _decimal(value: Any, field_name: str, *, positive: bool = False) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise AggregateTradeWebSocketParseError(
            f"{field_name} must be a valid decimal"
        ) from exc
    if not parsed.is_finite():
        raise AggregateTradeWebSocketParseError(f"{field_name} must be finite")
    if positive and parsed <= 0:
        raise AggregateTradeWebSocketParseError(f"{field_name} must be positive")
    return parsed


def normalize_aggregate_trade_subscriptions(
    symbols: Iterable[str],
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Validate and deduplicate exact contract symbols and aggTrade stream names."""
    normalized: list[str] = []
    for value in symbols:
        if not isinstance(value, str):
            raise ValueError("Every symbol must be a string")
        symbol = value.strip().upper()
        if not _SYMBOL_PATTERN.fullmatch(symbol):
            raise ValueError(f"Invalid Binance contract symbol: {value!r}")
        if symbol not in normalized:
            normalized.append(symbol)

    if not normalized:
        raise ValueError("At least one Binance symbol is required")

    streams = tuple(f"{symbol.lower()}@aggTrade" for symbol in normalized)
    return tuple(normalized), streams


def parse_aggregate_trade_stream_message(
    message: str | bytes,
    *,
    source_endpoint: str = BINANCE_UM_AGG_TRADE_WS_ENDPOINT,
    allowed_symbols: Iterable[str] | None = None,
    received_at_utc: datetime | None = None,
    now_ms: int | None = None,
    max_event_age_ms: int | None = None,
    max_future_skew_ms: int = DEFAULT_AGG_TRADE_FUTURE_SKEW_MS,
) -> AggregateTradeEvent | None:
    """Parse raw or combined USDⓈ-M aggTrade events; acks return ``None``.

    Freshness validation is opt-in at parser level. The feed enables it using
    its injectable wall clock to keep tests deterministic.
    """
    if isinstance(message, bytes):
        try:
            message = message.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AggregateTradeWebSocketParseError(
                "WebSocket message is not valid UTF-8"
            ) from exc
    if not isinstance(message, str) or not message:
        raise AggregateTradeWebSocketParseError(
            "WebSocket message must be non-empty text or bytes"
        )
    try:
        payload = json.loads(message)
    except (json.JSONDecodeError, TypeError) as exc:
        raise AggregateTradeWebSocketParseError(
            "WebSocket message is not valid JSON"
        ) from exc
    if not isinstance(payload, dict):
        raise AggregateTradeWebSocketParseError("WebSocket message root must be an object")

    if "id" in payload and "result" in payload:
        if payload.get("result") is not None:
            raise AggregateTradeWebSocketProtocolError(
                "Unexpected non-empty subscription acknowledgement"
            )
        return None
    if "code" in payload and "msg" in payload:
        raise AggregateTradeWebSocketProtocolError(
            f"Binance WebSocket error {payload.get('code')}: {payload.get('msg')}"
        )

    stream_name = payload.get("stream")
    event_payload = payload.get("data", payload)
    if not isinstance(event_payload, dict):
        raise AggregateTradeWebSocketParseError("Aggregate Trade event data must be an object")
    if event_payload.get("e") != "aggTrade":
        raise AggregateTradeWebSocketParseError("Unexpected WebSocket event type")

    symbol_value = event_payload.get("s")
    if not isinstance(symbol_value, str):
        raise AggregateTradeWebSocketParseError("Aggregate Trade event must contain a symbol")
    symbol = symbol_value.strip().upper()
    if not _SYMBOL_PATTERN.fullmatch(symbol):
        raise AggregateTradeWebSocketParseError("Aggregate Trade event has an invalid symbol")

    allowed = None if allowed_symbols is None else {item.upper() for item in allowed_symbols}
    if allowed is not None and symbol not in allowed:
        raise AggregateTradeWebSocketParseError(f"Received an unsubscribed symbol: {symbol}")

    expected_stream = f"{symbol.lower()}@aggTrade"
    if stream_name is not None and stream_name != expected_stream:
        raise AggregateTradeWebSocketParseError(
            "Combined-stream name does not match the Aggregate Trade payload"
        )

    try:
        aggregate_trade_id = _exact_integer(event_payload["a"], "aggregate_trade_id")
        event_time_ms = _exact_integer(event_payload["E"], "event_time_ms")
        trade_time_ms = _exact_integer(event_payload["T"], "trade_time_ms")
        price = _decimal(event_payload["p"], "price", positive=True)
        quantity = _decimal(event_payload["q"], "quantity", positive=True)
        first_trade_id = _exact_integer(event_payload["f"], "first_trade_id")
        last_trade_id = _exact_integer(event_payload["l"], "last_trade_id")
        buyer_is_maker = event_payload["m"]
    except KeyError as exc:
        raise AggregateTradeWebSocketParseError(
            f"Aggregate Trade payload is missing field {exc.args[0]!r}"
        ) from exc

    if not isinstance(buyer_is_maker, bool):
        raise AggregateTradeWebSocketParseError("buyer_is_maker ('m') must be boolean")
    if event_time_ms <= 0 or trade_time_ms <= 0:
        raise AggregateTradeWebSocketParseError("Event and trade timestamps must be positive")
    if last_trade_id < first_trade_id:
        raise AggregateTradeWebSocketParseError(
            "last_trade_id cannot be lower than first_trade_id"
        )
    if (
        isinstance(max_future_skew_ms, bool)
        or not isinstance(max_future_skew_ms, int)
        or max_future_skew_ms < 0
    ):
        raise ValueError("max_future_skew_ms must be a non-negative integer")
    if max_event_age_ms is not None:
        if (
            isinstance(max_event_age_ms, bool)
            or not isinstance(max_event_age_ms, int)
            or max_event_age_ms < 0
        ):
            raise ValueError("max_event_age_ms must be a non-negative integer")
        if now_ms is None:
            raise ValueError("now_ms is required when max_event_age_ms is configured")
        if isinstance(now_ms, bool) or not isinstance(now_ms, int) or now_ms < 0:
            raise ValueError("now_ms must be a non-negative integer")
        oldest_timestamp = min(event_time_ms, trade_time_ms)
        newest_timestamp = max(event_time_ms, trade_time_ms)
        if oldest_timestamp < now_ms - max_event_age_ms:
            raise AggregateTradeStaleEventError(
                "Aggregate Trade event/trade timestamp is stale by "
                f"{now_ms - oldest_timestamp} ms"
            )
        if newest_timestamp > now_ms + max_future_skew_ms:
            raise AggregateTradeStaleEventError(
                "Aggregate Trade event/trade timestamp is "
                f"{newest_timestamp - now_ms} ms in the future"
            )

    received_at = received_at_utc or datetime.now(UTC)
    if received_at.tzinfo is None or received_at.utcoffset() is None:
        raise AggregateTradeWebSocketParseError(
            "received_at_utc must be timezone-aware"
        )

    return AggregateTradeEvent(
        symbol=symbol,
        aggregate_trade_id=aggregate_trade_id,
        price=price,
        quantity=quantity,
        first_trade_id=first_trade_id,
        last_trade_id=last_trade_id,
        event_time_ms=event_time_ms,
        trade_time_ms=trade_time_ms,
        buyer_is_maker=buyer_is_maker,
        source_endpoint=source_endpoint,
        stream_name=expected_stream,
        received_at_utc=received_at.astimezone(UTC),
    )


class BinanceAggregateTradeWebSocketFeed:
    """Async exact-symbol aggTrade feed with bounded resources and reconnects."""

    def __init__(
        self,
        *,
        symbols: Iterable[str],
        endpoint: str = BINANCE_UM_AGG_TRADE_WS_ENDPOINT,
        max_subscriptions: int = DEFAULT_AGG_TRADE_MAX_SUBSCRIPTIONS,
        queue_capacity: int = DEFAULT_AGG_TRADE_QUEUE_CAPACITY,
        max_event_age_ms: int = DEFAULT_AGG_TRADE_MAX_AGE_MS,
        max_future_skew_ms: int = DEFAULT_AGG_TRADE_FUTURE_SKEW_MS,
        max_reconnect_attempts: int = 5,
        reconnect_base_delay_seconds: float = 1.0,
        reconnect_max_delay_seconds: float = 30.0,
        stable_connection_reset_seconds: float = 30.0,
        connector: Callable[..., Any] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        wall_clock_ms: Callable[[], int] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith("wss://"):
            raise ValueError("endpoint must be a secure wss:// URL")
        if (
            isinstance(max_subscriptions, bool)
            or not 1 <= max_subscriptions <= HARD_MAX_AGG_TRADE_SUBSCRIPTIONS
        ):
            raise ValueError(
                f"max_subscriptions must be between 1 and {HARD_MAX_AGG_TRADE_SUBSCRIPTIONS}"
            )
        if (
            isinstance(queue_capacity, bool)
            or not 1 <= queue_capacity <= HARD_MAX_AGG_TRADE_QUEUE_CAPACITY
        ):
            raise ValueError(
                f"queue_capacity must be between 1 and {HARD_MAX_AGG_TRADE_QUEUE_CAPACITY}"
            )
        if (
            isinstance(max_event_age_ms, bool)
            or not isinstance(max_event_age_ms, int)
            or max_event_age_ms < 0
        ):
            raise ValueError("max_event_age_ms must be a non-negative integer")
        if (
            isinstance(max_future_skew_ms, bool)
            or not isinstance(max_future_skew_ms, int)
            or max_future_skew_ms < 0
        ):
            raise ValueError("max_future_skew_ms must be a non-negative integer")
        if isinstance(max_reconnect_attempts, bool) or not 0 <= max_reconnect_attempts <= 20:
            raise ValueError("max_reconnect_attempts must be between 0 and 20")
        if reconnect_base_delay_seconds < 0 or reconnect_max_delay_seconds < 0:
            raise ValueError("Reconnect delays cannot be negative")
        if reconnect_max_delay_seconds < reconnect_base_delay_seconds:
            raise ValueError("Reconnect maximum delay cannot be below its base delay")
        if stable_connection_reset_seconds < 0:
            raise ValueError("stable_connection_reset_seconds cannot be negative")

        normalized_symbols, streams = normalize_aggregate_trade_subscriptions(symbols)
        if len(streams) > max_subscriptions:
            raise ValueError(
                f"Requested {len(streams)} streams exceeds configured cap {max_subscriptions}"
            )

        self.symbols = normalized_symbols
        self.stream_names = streams
        self.endpoint = endpoint
        self.max_subscriptions = max_subscriptions
        self.max_event_age_ms = max_event_age_ms
        self.max_future_skew_ms = max_future_skew_ms
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_base_delay_seconds = reconnect_base_delay_seconds
        self.reconnect_max_delay_seconds = reconnect_max_delay_seconds
        self.stable_connection_reset_seconds = stable_connection_reset_seconds
        self.events: asyncio.Queue[AggregateTradeEvent] = asyncio.Queue(
            maxsize=queue_capacity
        )
        self.stats = AggregateTradeFeedStats()
        self._connector = connector or websocket_connect
        self._monotonic = monotonic
        self._wall_clock_ms = wall_clock_ms or (lambda: int(time.time() * 1000))
        self._request_id = 1
        self._connected = False
        self._last_aggregate_id_by_symbol: dict[str, int] = {}

    @property
    def is_connected(self) -> bool:
        """Whether a WebSocket session is currently established."""
        return self._connected

    def subscription_request(self) -> dict[str, Any]:
        """Return the deterministic SUBSCRIBE request for the configured streams."""
        return {
            "method": "SUBSCRIBE",
            "params": list(self.stream_names),
            "id": self._request_id,
        }

    async def get_event(self) -> AggregateTradeEvent:
        """Wait for the next normalized Aggregate Trade event."""
        return await self.events.get()

    async def run(self, stop_event: asyncio.Event) -> None:
        """Run until stopped; reconnect with bounded exponential backoff."""
        if not isinstance(stop_event, asyncio.Event):
            raise TypeError("stop_event must be an asyncio.Event")

        consecutive_reconnects = 0
        while not stop_event.is_set():
            session_started = self._monotonic()
            try:
                async with self._connector(
                    self.endpoint,
                    open_timeout=10,
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=5,
                    max_size=WEBSOCKET_MAX_MESSAGE_BYTES,
                    max_queue=WEBSOCKET_MAX_FRAME_QUEUE,
                    compression=None,
                ) as websocket:
                    self.stats.connection_count += 1
                    self._connected = True
                    try:
                        request = self.subscription_request()
                        self._request_id += 1
                        await websocket.send(json.dumps(request, separators=(",", ":")))
                        self.stats.subscription_messages_sent += 1
                        await self._receive_until_stopped(websocket, stop_event)
                        if stop_event.is_set():
                            return
                        raise ConnectionError(
                            "Binance Aggregate Trade WebSocket closed without a stop request"
                        )
                    finally:
                        self._connected = False
            except AggregateTradeQueueFullError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.stats.last_error = f"{type(exc).__name__}: {exc}"
                if stop_event.is_set():
                    return
                if self._monotonic() - session_started >= self.stable_connection_reset_seconds:
                    consecutive_reconnects = 0
                if consecutive_reconnects >= self.max_reconnect_attempts:
                    raise AggregateTradeReconnectExhausted(
                        "Aggregate Trade reconnect limit exhausted after "
                        f"{consecutive_reconnects} retries"
                    ) from exc
                consecutive_reconnects += 1
                self.stats.reconnect_attempts += 1
                delay = min(
                    self.reconnect_base_delay_seconds * (2 ** (consecutive_reconnects - 1)),
                    self.reconnect_max_delay_seconds,
                )
                await self._wait_or_stop(stop_event, delay)

    async def _receive_until_stopped(
        self,
        websocket: Any,
        stop_event: asyncio.Event,
    ) -> None:
        while not stop_event.is_set():
            message = await self._recv_or_stop(websocket, stop_event)
            if message is None:
                return
            self.stats.messages_received += 1
            try:
                event = parse_aggregate_trade_stream_message(
                    message,
                    source_endpoint=self.endpoint,
                    allowed_symbols=self.symbols,
                    now_ms=self._wall_clock_ms(),
                    max_event_age_ms=self.max_event_age_ms,
                    max_future_skew_ms=self.max_future_skew_ms,
                )
            except AggregateTradeStaleEventError:
                self.stats.stale_messages += 1
                continue
            except AggregateTradeWebSocketProtocolError:
                raise
            except AggregateTradeWebSocketParseError:
                self.stats.malformed_messages += 1
                continue

            if event is None:
                self.stats.acknowledgements_received += 1
                continue

            previous_id = self._last_aggregate_id_by_symbol.get(event.symbol)
            if previous_id is not None:
                if event.aggregate_trade_id <= previous_id:
                    self.stats.duplicate_or_out_of_order_messages += 1
                    continue
                gap = event.aggregate_trade_id - previous_id - 1
                if gap > 0:
                    event = replace(event, missed_aggregate_trades_before=gap)
                    self.stats.aggregate_id_gaps += gap

            try:
                self.events.put_nowait(event)
            except asyncio.QueueFull as exc:
                self.stats.queue_overflows += 1
                raise AggregateTradeQueueFullError(
                    "Aggregate Trade event queue is full; consumer is not keeping up"
                ) from exc
            self._last_aggregate_id_by_symbol[event.symbol] = event.aggregate_trade_id
            self.stats.events_emitted += 1

    @staticmethod
    async def _recv_or_stop(
        websocket: Any,
        stop_event: asyncio.Event,
    ) -> str | bytes | None:
        receive_task = asyncio.create_task(websocket.recv())
        stop_task = asyncio.create_task(stop_event.wait())
        try:
            done, _ = await asyncio.wait(
                (receive_task, stop_task), return_when=asyncio.FIRST_COMPLETED
            )
            if receive_task in done:
                return receive_task.result()
            return None
        finally:
            for task in (receive_task, stop_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(receive_task, stop_task, return_exceptions=True)

    @staticmethod
    async def _wait_or_stop(stop_event: asyncio.Event, delay: float) -> None:
        if delay <= 0:
            await asyncio.sleep(0)
            return
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except TimeoutError:
            return
