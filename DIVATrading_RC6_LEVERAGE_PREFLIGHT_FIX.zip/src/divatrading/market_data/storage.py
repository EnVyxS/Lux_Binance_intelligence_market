"""SQLite repository for normalized Binance USD-M Kline records."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Iterable

from divatrading.core.database import Database, utc_now_iso
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline


MAX_READ_LIMIT = 5_000
MAX_EXISTENCE_KEYS = 5_000


class KlineStorageError(ValueError):
    """Raised when a Kline storage request violates the repository contract."""


@dataclass(frozen=True, slots=True)
class StoredKline:
    """A Kline with persistence timestamps for audit and recovery workflows."""

    kline: Kline
    first_seen_at_utc: str
    last_fetched_at_utc: str
    last_saved_at_utc: str


class KlineRepository:
    """Persist and query Klines using their exchange candle identity.

    Prices and volumes are written as decimal strings in SQLite TEXT columns.
    The repository expects ``Database.initialize()`` to have applied migrations.
    """

    def __init__(self, database: Database) -> None:
        self.database = database

    @staticmethod
    def _utc_timestamp(value: str | None, *, field_name: str) -> str:
        if value is None:
            return utc_now_iso()
        if not isinstance(value, str) or not value.strip():
            raise KlineStorageError(f"{field_name} must be a non-empty UTC ISO-8601 string")
        normalized = value.strip()
        parse_value = normalized[:-1] + "+00:00" if normalized.endswith("Z") else normalized
        try:
            parsed = datetime.fromisoformat(parse_value)
        except ValueError as exc:
            raise KlineStorageError(f"{field_name} must be a valid ISO-8601 timestamp") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None or parsed.utcoffset().total_seconds() != 0:
            raise KlineStorageError(f"{field_name} must use UTC timezone")
        return parsed.astimezone(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    @staticmethod
    def _validate_kline(kline: Kline) -> None:
        if not isinstance(kline, Kline):
            raise KlineStorageError("Only validated Kline model instances can be stored")
        if not isinstance(kline.exchange, str) or kline.exchange != "BINANCE_UM":
            raise KlineStorageError("Only BINANCE_UM Klines are supported by this repository")
        if (
            not isinstance(kline.symbol, str)
            or not kline.symbol
            or kline.symbol != kline.symbol.strip().upper()
        ):
            raise KlineStorageError("Kline symbol must be a non-empty uppercase contract symbol")
        if not isinstance(kline.interval, str) or kline.interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {kline.interval}")
        interval_ms = INTERVAL_MILLISECONDS[kline.interval]
        if (
            isinstance(kline.open_time_ms, bool)
            or not isinstance(kline.open_time_ms, int)
            or kline.open_time_ms < 0
            or kline.open_time_ms % interval_ms
        ):
            raise KlineStorageError("Kline open time is invalid or not aligned to its interval")
        if (
            isinstance(kline.close_time_ms, bool)
            or not isinstance(kline.close_time_ms, int)
            or kline.close_time_ms != kline.open_time_ms + interval_ms - 1
        ):
            raise KlineStorageError("Kline close time does not match the interval boundary")
        if not isinstance(kline.source_endpoint, str) or not kline.source_endpoint.strip():
            raise KlineStorageError("Kline source_endpoint cannot be empty")
        if not isinstance(kline.ignore_value, str):
            raise KlineStorageError("Kline ignore_value must be a string")
        decimal_values = (
            kline.open,
            kline.high,
            kline.low,
            kline.close,
            kline.volume,
            kline.quote_asset_volume,
            kline.taker_buy_base_volume,
            kline.taker_buy_quote_volume,
        )
        if any(not isinstance(value, Decimal) or not value.is_finite() for value in decimal_values):
            raise KlineStorageError("Kline price and volume values must be finite Decimal instances")
        if min(kline.open, kline.high, kline.low, kline.close) <= 0:
            raise KlineStorageError("Kline OHLC prices must be positive")
        if kline.high < max(kline.open, kline.low, kline.close):
            raise KlineStorageError("Kline high is below another OHLC value")
        if kline.low > min(kline.open, kline.high, kline.close):
            raise KlineStorageError("Kline low is above another OHLC value")
        if min(
            kline.volume,
            kline.quote_asset_volume,
            kline.taker_buy_base_volume,
            kline.taker_buy_quote_volume,
        ) < 0:
            raise KlineStorageError("Kline volume fields cannot be negative")
        if isinstance(kline.trade_count, bool) or not isinstance(kline.trade_count, int) or kline.trade_count < 0:
            raise KlineStorageError("Kline trade_count must be a non-negative integer")

    def upsert_many(
        self,
        klines: Iterable[Kline],
        *,
        fetched_at_utc: str | None = None,
    ) -> int:
        """Insert or update Klines atomically; return the number of input rows processed.

        The primary key prevents duplicate candles. Repeated identities update the
        candle payload and latest fetch/save timestamps while preserving first-seen time.
        """
        rows = list(klines)
        if not rows:
            return 0
        for kline in rows:
            self._validate_kline(kline)

        fetched_at = self._utc_timestamp(fetched_at_utc, field_name="fetched_at_utc")
        saved_at = utc_now_iso()
        values = [
            (
                item.exchange,
                item.symbol,
                item.interval,
                item.open_time_ms,
                str(item.open),
                str(item.high),
                str(item.low),
                str(item.close),
                str(item.volume),
                item.close_time_ms,
                str(item.quote_asset_volume),
                item.trade_count,
                str(item.taker_buy_base_volume),
                str(item.taker_buy_quote_volume),
                item.ignore_value,
                item.source_endpoint,
                saved_at,
                fetched_at,
                saved_at,
            )
            for item in rows
        ]

        with self.database.transaction() as connection:
            connection.executemany(
                """INSERT INTO market_klines(
                    exchange, symbol, interval, open_time_ms,
                    open, high, low, close, volume, close_time_ms,
                    quote_asset_volume, trade_count,
                    taker_buy_base_volume, taker_buy_quote_volume,
                    ignore_value, source_endpoint,
                    first_seen_at_utc, last_fetched_at_utc, last_saved_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(exchange, symbol, interval, open_time_ms) DO UPDATE SET
                    open=excluded.open,
                    high=excluded.high,
                    low=excluded.low,
                    close=excluded.close,
                    volume=excluded.volume,
                    close_time_ms=excluded.close_time_ms,
                    quote_asset_volume=excluded.quote_asset_volume,
                    trade_count=excluded.trade_count,
                    taker_buy_base_volume=excluded.taker_buy_base_volume,
                    taker_buy_quote_volume=excluded.taker_buy_quote_volume,
                    ignore_value=excluded.ignore_value,
                    source_endpoint=excluded.source_endpoint,
                    last_fetched_at_utc=excluded.last_fetched_at_utc,
                    last_saved_at_utc=excluded.last_saved_at_utc""",
                values,
            )
        return len(rows)

    def read(
        self,
        *,
        exchange: str = "BINANCE_UM",
        symbol: str,
        interval: str,
        start_open_time_ms: int | None = None,
        end_open_time_ms: int | None = None,
        limit: int = 500,
    ) -> list[StoredKline]:
        """Read a bounded, ascending range; time bounds are inclusive."""
        exchange_key = exchange.strip().upper() if isinstance(exchange, str) else ""
        symbol_key = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not exchange_key or not symbol_key:
            raise KlineStorageError("exchange and symbol are required")
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {interval}")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_READ_LIMIT:
            raise KlineStorageError(f"limit must be between 1 and {MAX_READ_LIMIT}")
        for name, value in (("start_open_time_ms", start_open_time_ms), ("end_open_time_ms", end_open_time_ms)):
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
                raise KlineStorageError(f"{name} must be a non-negative integer")
        if start_open_time_ms is not None and end_open_time_ms is not None:
            if start_open_time_ms > end_open_time_ms:
                raise KlineStorageError("start_open_time_ms cannot exceed end_open_time_ms")

        clauses = ["exchange = ?", "symbol = ?", "interval = ?"]
        parameters: list[object] = [exchange_key, symbol_key, interval]
        if start_open_time_ms is not None:
            clauses.append("open_time_ms >= ?")
            parameters.append(start_open_time_ms)
        if end_open_time_ms is not None:
            clauses.append("open_time_ms <= ?")
            parameters.append(end_open_time_ms)
        parameters.append(limit)

        with self.database.connection() as connection:
            rows = connection.execute(
                f"""SELECT * FROM market_klines
                    WHERE {' AND '.join(clauses)}
                    ORDER BY open_time_ms ASC LIMIT ?""",
                parameters,
            ).fetchall()

        result: list[StoredKline] = []
        for row in rows:
            kline = Kline(
                exchange=row["exchange"],
                symbol=row["symbol"],
                interval=row["interval"],
                open_time_ms=row["open_time_ms"],
                open=Decimal(row["open"]),
                high=Decimal(row["high"]),
                low=Decimal(row["low"]),
                close=Decimal(row["close"]),
                volume=Decimal(row["volume"]),
                close_time_ms=row["close_time_ms"],
                quote_asset_volume=Decimal(row["quote_asset_volume"]),
                trade_count=row["trade_count"],
                taker_buy_base_volume=Decimal(row["taker_buy_base_volume"]),
                taker_buy_quote_volume=Decimal(row["taker_buy_quote_volume"]),
                ignore_value=row["ignore_value"],
                source_endpoint=row["source_endpoint"],
            )
            result.append(
                StoredKline(
                    kline=kline,
                    first_seen_at_utc=row["first_seen_at_utc"],
                    last_fetched_at_utc=row["last_fetched_at_utc"],
                    last_saved_at_utc=row["last_saved_at_utc"],
                )
            )
        return result

    def read_tail(
        self,
        *,
        exchange: str = "BINANCE_UM",
        symbol: str,
        interval: str,
        limit: int = 500,
        end_open_time_ms: int | None = None,
    ) -> list[StoredKline]:
        """Read the most recent bounded candles in ascending time order.

        This query uses the composite primary-key index in reverse and then
        reverses the bounded result in memory. It avoids scanning an unbounded
        history when a recovery pass audits the latest local candle sequence.
        """
        exchange_key = exchange.strip().upper() if isinstance(exchange, str) else ""
        symbol_key = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not exchange_key or not symbol_key:
            raise KlineStorageError("exchange and symbol are required")
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {interval}")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_READ_LIMIT:
            raise KlineStorageError(f"limit must be between 1 and {MAX_READ_LIMIT}")
        if end_open_time_ms is not None and (
            isinstance(end_open_time_ms, bool)
            or not isinstance(end_open_time_ms, int)
            or end_open_time_ms < 0
            or end_open_time_ms % INTERVAL_MILLISECONDS[interval]
        ):
            raise KlineStorageError("end_open_time_ms must be a non-negative aligned integer")

        query = [
            "SELECT * FROM market_klines WHERE exchange = ? AND symbol = ? AND interval = ?"
        ]
        parameters: list[object] = [exchange_key, symbol_key, interval]
        if end_open_time_ms is not None:
            query.append("AND open_time_ms <= ?")
            parameters.append(end_open_time_ms)
        query.append("ORDER BY open_time_ms DESC LIMIT ?")
        parameters.append(limit)
        with self.database.connection() as connection:
            rows = connection.execute(" ".join(query), parameters).fetchall()

        result: list[StoredKline] = []
        for row in reversed(rows):
            kline = Kline(
                exchange=row["exchange"],
                symbol=row["symbol"],
                interval=row["interval"],
                open_time_ms=row["open_time_ms"],
                open=Decimal(row["open"]),
                high=Decimal(row["high"]),
                low=Decimal(row["low"]),
                close=Decimal(row["close"]),
                volume=Decimal(row["volume"]),
                close_time_ms=row["close_time_ms"],
                quote_asset_volume=Decimal(row["quote_asset_volume"]),
                trade_count=row["trade_count"],
                taker_buy_base_volume=Decimal(row["taker_buy_base_volume"]),
                taker_buy_quote_volume=Decimal(row["taker_buy_quote_volume"]),
                ignore_value=row["ignore_value"],
                source_endpoint=row["source_endpoint"],
            )
            result.append(
                StoredKline(
                    kline=kline,
                    first_seen_at_utc=row["first_seen_at_utc"],
                    last_fetched_at_utc=row["last_fetched_at_utc"],
                    last_saved_at_utc=row["last_saved_at_utc"],
                )
            )
        return result

    def earliest_open_time_ms(
        self,
        *,
        exchange: str = "BINANCE_UM",
        symbol: str,
        interval: str,
    ) -> int | None:
        """Return the oldest stored candle open time for one stream, if any."""
        exchange_key = exchange.strip().upper() if isinstance(exchange, str) else ""
        symbol_key = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not exchange_key or not symbol_key:
            raise KlineStorageError("exchange and symbol are required")
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {interval}")
        with self.database.connection() as connection:
            row = connection.execute(
                """SELECT open_time_ms FROM market_klines
                   WHERE exchange = ? AND symbol = ? AND interval = ?
                   ORDER BY open_time_ms ASC LIMIT 1""",
                (exchange_key, symbol_key, interval),
            ).fetchone()
        return int(row["open_time_ms"]) if row is not None else None

    def exists(
        self,
        *,
        exchange: str = "BINANCE_UM",
        symbol: str,
        interval: str,
        open_time_ms: int,
    ) -> bool:
        """Check whether one exact candle identity is persisted."""
        if not isinstance(open_time_ms, int) or isinstance(open_time_ms, bool) or open_time_ms < 0:
            raise KlineStorageError("open_time_ms must be a non-negative integer")
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {interval}")
        if open_time_ms % INTERVAL_MILLISECONDS[interval]:
            raise KlineStorageError("open_time_ms is not aligned to its interval")
        exchange_key = exchange.strip().upper() if isinstance(exchange, str) else ""
        symbol_key = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not exchange_key or not symbol_key:
            raise KlineStorageError("exchange and symbol are required")
        with self.database.connection() as connection:
            row = connection.execute(
                """SELECT 1 FROM market_klines
                   WHERE exchange = ? AND symbol = ? AND interval = ? AND open_time_ms = ?""",
                (exchange_key, symbol_key, interval, open_time_ms),
            ).fetchone()
        return row is not None

    def existing_open_times(
        self,
        *,
        exchange: str = "BINANCE_UM",
        symbol: str,
        interval: str,
        open_times_ms: Iterable[int],
    ) -> set[int]:
        """Return the subset of supplied open times that already exists."""
        supplied_times = list(open_times_ms)
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0
            for value in supplied_times
        ):
            raise KlineStorageError("open_times_ms values must be non-negative integers")
        times = list(dict.fromkeys(supplied_times))
        if len(times) > MAX_EXISTENCE_KEYS:
            raise KlineStorageError(f"open_times_ms cannot exceed {MAX_EXISTENCE_KEYS} values")
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineStorageError(f"Unsupported Kline interval: {interval}")
        interval_ms = INTERVAL_MILLISECONDS[interval]
        if any(value % interval_ms for value in times):
            raise KlineStorageError("open_times_ms contain values not aligned to the interval")
        exchange_key = exchange.strip().upper() if isinstance(exchange, str) else ""
        symbol_key = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not exchange_key or not symbol_key:
            raise KlineStorageError("exchange and symbol are required")
        if not times:
            return set()

        found: set[int] = set()
        chunk_size = 900
        with self.database.connection() as connection:
            for offset in range(0, len(times), chunk_size):
                chunk = times[offset : offset + chunk_size]
                placeholders = ",".join("?" for _ in chunk)
                rows = connection.execute(
                    f"""SELECT open_time_ms FROM market_klines
                        WHERE exchange = ? AND symbol = ? AND interval = ?
                          AND open_time_ms IN ({placeholders})""",
                    [exchange_key, symbol_key, interval, *chunk],
                ).fetchall()
                found.update(int(row["open_time_ms"]) for row in rows)
        return found
