"""Bounded public Binance USD-M Futures Mark Price WebSocket feed."""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Iterable

from websockets.asyncio.client import connect as websocket_connect

from divatrading.market_data.websocket import (
    BINANCE_UM_MARKET_WS_ENDPOINT,
    WEBSOCKET_MAX_FRAME_QUEUE,
    WEBSOCKET_MAX_MESSAGE_BYTES,
)

DEFAULT_MARK_PRICE_MAX_SUBSCRIPTIONS = 48
HARD_MAX_MARK_PRICE_SUBSCRIPTIONS = 128
DEFAULT_MARK_PRICE_QUEUE_CAPACITY = 2048
HARD_MAX_MARK_PRICE_QUEUE_CAPACITY = 8192
DEFAULT_MARK_PRICE_MAX_AGE_MS = 10_000
DEFAULT_MARK_PRICE_FUTURE_SKEW_MS = 5_000
_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{2,30}$")


class MarkPriceWebSocketError(RuntimeError):
    """Base error raised by the Mark Price WebSocket feed."""


class MarkPriceWebSocketParseError(MarkPriceWebSocketError):
    """Raised when a Mark Price event is malformed or inconsistent."""


class MarkPriceWebSocketProtocolError(MarkPriceWebSocketError):
    """Raised when Binance rejects a WebSocket subscription or request."""


class MarkPriceStaleEventError(MarkPriceWebSocketParseError):
    """Raised when an event is outside the configured event-time freshness window."""


class MarkPriceQueueFullError(MarkPriceWebSocketError):
    """Raised rather than silently dropping a Mark Price update."""


class MarkPriceReconnectExhausted(MarkPriceWebSocketError):
    """Raised after the configured number of consecutive reconnect attempts."""


@dataclass(frozen=True, slots=True)
class MarkPriceEvent:
    """Normalized Mark Price, index, and funding information for one UM contract."""

    symbol: str
    mark_price: Decimal
    index_price: Decimal
    funding_rate: Decimal
    next_funding_time_ms: int
    event_time_ms: int
    estimated_settle_price: Decimal | None
    mark_price_moving_average: Decimal | None
    symbol_type: int | None
    source_endpoint: str
    stream_name: str
    received_at_utc: datetime

    @property
    def event_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(milliseconds=self.event_time_ms)

    @property
    def next_funding_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(
            milliseconds=self.next_funding_time_ms
        )

    @property
    def mark_index_basis(self) -> Decimal:
        """Absolute mark-minus-index basis; callers can derive a percentage separately."""
        return self.mark_price - self.index_price


@dataclass(slots=True)
class MarkPriceFeedStats:
    """Observable counters updated by the feed's single asyncio task."""

    connection_count: int = 0
    reconnect_attempts: int = 0
    subscription_messages_sent: int = 0
    messages_received: int = 0
    events_emitted: int = 0
    acknowledgements_received: int = 0
    malformed_messages: int = 0
    stale_messages: int = 0
    queue_overflows: int = 0
    last_error: str | None = None


def _exact_integer(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise MarkPriceWebSocketParseError(f"{field_name} must be an integer")
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarkPriceWebSocketParseError(f"{field_name} must be an integer") from exc
    if str(value).strip() not in {str(parsed), f"{parsed}.0"}:
        raise MarkPriceWebSocketParseError(f"{field_name} must be an exact integer")
    if parsed < 0:
        raise MarkPriceWebSocketParseError(f"{field_name} cannot be negative")
    return parsed


def _decimal(value: Any, field_name: str, *, positive: bool = False) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise MarkPriceWebSocketParseError(f"{field_name} must be a valid decimal") from exc
    if not parsed.is_finite():
        raise MarkPriceWebSocketParseError(f"{field_name} must be finite")
    if positive and parsed <= 0:
        raise MarkPriceWebSocketParseError(f"{field_name} must be positive")
    return parsed


def normalize_mark_price_subscriptions(
    symbols: Iterable[str], *, update_speed: str = "1s"
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Validate exact symbols and return normalized per-symbol Mark Price streams."""
    if update_speed not in {"1s", "3s"}:
        raise ValueError("update_speed must be '1s' or '3s'")

    normalized: list[str] = []
    for value in symbols:
        if not isinstance(value, str):
            raise ValueError("Every symbol must be a string")
        symbol = value.strip().upper()
        if not _SYMBOL_PATTERN.fullmatch(symbol):
            raise ValueError(f"Invalid Binance contract symbol: {value!r}")
        if symbol not in normalized:
            normalized.append(symbol)

    if not normalized:
        raise ValueError("At least one Binance symbol is required")

    streams = tuple(f"{symbol.lower()}@markPrice@{update_speed}" for symbol in normalized)
    return tuple(normalized), streams


def parse_mark_price_stream_message(
    message: str | bytes,
    *,
    source_endpoint: str = BINANCE_UM_MARKET_WS_ENDPOINT,
    allowed_symbols: Iterable[str] | None = None,
    update_speed: str = "1s",
    received_at_utc: datetime | None = None,
    now_ms: int | None = None,
    max_event_age_ms: int | None = None,
    max_future_skew_ms: int = DEFAULT_MARK_PRICE_FUTURE_SKEW_MS,
) -> MarkPriceEvent | None:
    """Parse raw/combined Mark Price messages; return ``None`` for acknowledgements.

    Freshness checks are opt-in at parser level (set ``max_event_age_ms`` and
    ``now_ms``). The feed applies them using its injectable wall clock.
    """
    if update_speed not in {"1s", "3s"}:
        raise MarkPriceWebSocketParseError("update_speed must be '1s' or '3s'")
    if isinstance(message, bytes):
        try:
            message = message.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise MarkPriceWebSocketParseError("WebSocket message is not valid UTF-8") from exc
    if not isinstance(message, str) or not message:
        raise MarkPriceWebSocketParseError("WebSocket message must be non-empty text or bytes")
    try:
        payload = json.loads(message)
    except (json.JSONDecodeError, TypeError) as exc:
        raise MarkPriceWebSocketParseError("WebSocket message is not valid JSON") from exc
    if not isinstance(payload, dict):
        raise MarkPriceWebSocketParseError("WebSocket message root must be an object")

    if "id" in payload and "result" in payload:
        if payload.get("result") is not None:
            raise MarkPriceWebSocketProtocolError(
                "Unexpected non-empty subscription acknowledgement"
            )
        return None
    if "code" in payload and "msg" in payload:
        raise MarkPriceWebSocketProtocolError(
            f"Binance WebSocket error {payload.get('code')}: {payload.get('msg')}"
        )

    stream_name = payload.get("stream")
    event_payload = payload.get("data", payload)
    if not isinstance(event_payload, dict):
        raise MarkPriceWebSocketParseError("Mark Price event data must be an object")
    if event_payload.get("e") != "markPriceUpdate":
        raise MarkPriceWebSocketParseError("Unexpected WebSocket event type")

    symbol_value = event_payload.get("s")
    if not isinstance(symbol_value, str):
        raise MarkPriceWebSocketParseError("Mark Price event must contain a symbol")
    symbol = symbol_value.strip().upper()
    if not _SYMBOL_PATTERN.fullmatch(symbol):
        raise MarkPriceWebSocketParseError("Mark Price event contains an invalid symbol")
    if allowed_symbols is not None and symbol not in {
        item.upper() for item in allowed_symbols
    }:
        raise MarkPriceWebSocketParseError(f"Received an unsubscribed symbol: {symbol}")

    expected_stream = f"{symbol.lower()}@markPrice@{update_speed}"
    if stream_name is not None and stream_name != expected_stream:
        raise MarkPriceWebSocketParseError(
            "Combined-stream name does not match the Mark Price event payload"
        )

    try:
        mark_price = _decimal(event_payload["p"], "mark_price", positive=True)
        index_price = _decimal(event_payload["i"], "index_price", positive=True)
        funding_rate = _decimal(event_payload["r"], "funding_rate")
        event_time_ms = _exact_integer(event_payload["E"], "event_time_ms")
        next_funding_time_ms = _exact_integer(
            event_payload["T"], "next_funding_time_ms"
        )
    except KeyError as exc:
        raise MarkPriceWebSocketParseError(
            f"Mark Price payload is missing field {exc.args[0]!r}"
        ) from exc

    if event_time_ms <= 0:
        raise MarkPriceWebSocketParseError("event_time_ms must be positive")
    if next_funding_time_ms <= event_time_ms:
        raise MarkPriceWebSocketParseError(
            "next_funding_time_ms must be later than event_time_ms for UM perpetuals"
        )

    estimated_value = event_payload.get("P")
    estimated_settle_price = (
        None
        if estimated_value in (None, "")
        else _decimal(estimated_value, "estimated_settle_price", positive=True)
    )
    moving_average_value = event_payload.get("ap")
    mark_price_moving_average = (
        None
        if moving_average_value in (None, "")
        else _decimal(moving_average_value, "mark_price_moving_average", positive=True)
    )

    symbol_type_value = event_payload.get("st")
    symbol_type = (
        None if symbol_type_value is None else _exact_integer(symbol_type_value, "symbol_type")
    )
    if symbol_type not in (None, 1):
        raise MarkPriceWebSocketParseError(
            "Only Binance USDⓈ-M contracts (symbol type 1) are supported"
        )

    if isinstance(max_future_skew_ms, bool) or not isinstance(max_future_skew_ms, int) or max_future_skew_ms < 0:
        raise ValueError("max_future_skew_ms must be a non-negative integer")
    if max_event_age_ms is not None:
        if isinstance(max_event_age_ms, bool) or not isinstance(max_event_age_ms, int) or max_event_age_ms < 0:
            raise ValueError("max_event_age_ms must be a non-negative integer")
        if now_ms is None:
            raise ValueError("now_ms is required when max_event_age_ms is configured")
        if isinstance(now_ms, bool) or not isinstance(now_ms, int) or now_ms < 0:
            raise ValueError("now_ms must be a non-negative integer")
        if event_time_ms < now_ms - max_event_age_ms:
            raise MarkPriceStaleEventError(
                f"Mark Price event is stale by {now_ms - event_time_ms} ms"
            )
        if event_time_ms > now_ms + max_future_skew_ms:
            raise MarkPriceStaleEventError(
                f"Mark Price event timestamp is {event_time_ms - now_ms} ms in the future"
            )

    received_at = received_at_utc or datetime.now(UTC)
    if received_at.tzinfo is None or received_at.utcoffset() is None:
        raise MarkPriceWebSocketParseError("received_at_utc must be timezone-aware")

    return MarkPriceEvent(
        symbol=symbol,
        mark_price=mark_price,
        index_price=index_price,
        funding_rate=funding_rate,
        next_funding_time_ms=next_funding_time_ms,
        event_time_ms=event_time_ms,
        estimated_settle_price=estimated_settle_price,
        mark_price_moving_average=mark_price_moving_average,
        symbol_type=symbol_type,
        source_endpoint=source_endpoint,
        stream_name=expected_stream,
        received_at_utc=received_at.astimezone(UTC),
    )


class BinanceMarkPriceWebSocketFeed:
    """Async per-symbol Mark Price feed with bounded queue and reconnect policy."""

    def __init__(
        self,
        *,
        symbols: Iterable[str],
        update_speed: str = "1s",
        endpoint: str = BINANCE_UM_MARKET_WS_ENDPOINT,
        max_subscriptions: int = DEFAULT_MARK_PRICE_MAX_SUBSCRIPTIONS,
        queue_capacity: int = DEFAULT_MARK_PRICE_QUEUE_CAPACITY,
        max_event_age_ms: int = DEFAULT_MARK_PRICE_MAX_AGE_MS,
        max_future_skew_ms: int = DEFAULT_MARK_PRICE_FUTURE_SKEW_MS,
        max_reconnect_attempts: int = 5,
        reconnect_base_delay_seconds: float = 1.0,
        reconnect_max_delay_seconds: float = 30.0,
        stable_connection_reset_seconds: float = 30.0,
        connector: Callable[..., Any] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        wall_clock_ms: Callable[[], int] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith("wss://"):
            raise ValueError("endpoint must be a secure wss:// URL")
        if isinstance(max_subscriptions, bool) or not 1 <= max_subscriptions <= HARD_MAX_MARK_PRICE_SUBSCRIPTIONS:
            raise ValueError(
                f"max_subscriptions must be between 1 and {HARD_MAX_MARK_PRICE_SUBSCRIPTIONS}"
            )
        if isinstance(queue_capacity, bool) or not 1 <= queue_capacity <= HARD_MAX_MARK_PRICE_QUEUE_CAPACITY:
            raise ValueError(
                f"queue_capacity must be between 1 and {HARD_MAX_MARK_PRICE_QUEUE_CAPACITY}"
            )
        if isinstance(max_event_age_ms, bool) or not isinstance(max_event_age_ms, int) or max_event_age_ms < 0:
            raise ValueError("max_event_age_ms must be a non-negative integer")
        if isinstance(max_future_skew_ms, bool) or not isinstance(max_future_skew_ms, int) or max_future_skew_ms < 0:
            raise ValueError("max_future_skew_ms must be a non-negative integer")
        if isinstance(max_reconnect_attempts, bool) or not 0 <= max_reconnect_attempts <= 20:
            raise ValueError("max_reconnect_attempts must be between 0 and 20")
        if reconnect_base_delay_seconds < 0 or reconnect_max_delay_seconds < 0:
            raise ValueError("Reconnect delays cannot be negative")
        if reconnect_max_delay_seconds < reconnect_base_delay_seconds:
            raise ValueError("Reconnect maximum delay cannot be below its base delay")
        if stable_connection_reset_seconds < 0:
            raise ValueError("stable_connection_reset_seconds cannot be negative")

        normalized_symbols, streams = normalize_mark_price_subscriptions(
            symbols, update_speed=update_speed
        )
        if len(streams) > max_subscriptions:
            raise ValueError(
                f"Requested {len(streams)} streams exceeds configured cap {max_subscriptions}"
            )

        self.symbols = normalized_symbols
        self.update_speed = update_speed
        self.stream_names = streams
        self.endpoint = endpoint
        self.max_subscriptions = max_subscriptions
        self.max_event_age_ms = max_event_age_ms
        self.max_future_skew_ms = max_future_skew_ms
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_base_delay_seconds = reconnect_base_delay_seconds
        self.reconnect_max_delay_seconds = reconnect_max_delay_seconds
        self.stable_connection_reset_seconds = stable_connection_reset_seconds
        self.events: asyncio.Queue[MarkPriceEvent] = asyncio.Queue(maxsize=queue_capacity)
        self.stats = MarkPriceFeedStats()
        self._connector = connector or websocket_connect
        self._monotonic = monotonic
        self._wall_clock_ms = wall_clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._request_id = 1
        self._connected = False
        self._last_event_time_by_symbol: dict[str, int] = {}

    @property
    def is_connected(self) -> bool:
        """Whether the underlying WebSocket session is currently established."""
        return self._connected

    def subscription_request(self) -> dict[str, Any]:
        """Return the deterministic SUBSCRIBE message for configured exact streams."""
        return {
            "method": "SUBSCRIBE",
            "params": list(self.stream_names),
            "id": self._request_id,
        }

    async def get_event(self) -> MarkPriceEvent:
        """Wait for the next non-stale normalized Mark Price update."""
        return await self.events.get()

    async def run(self, stop_event: asyncio.Event) -> None:
        """Run until stopped, reconnecting with bounded exponential backoff."""
        if not isinstance(stop_event, asyncio.Event):
            raise TypeError("stop_event must be an asyncio.Event")

        consecutive_reconnects = 0
        while not stop_event.is_set():
            session_started = self._monotonic()
            try:
                async with self._connector(
                    self.endpoint,
                    open_timeout=10,
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=5,
                    max_size=WEBSOCKET_MAX_MESSAGE_BYTES,
                    max_queue=WEBSOCKET_MAX_FRAME_QUEUE,
                    compression=None,
                ) as websocket:
                    self.stats.connection_count += 1
                    self._connected = True
                    try:
                        request = self.subscription_request()
                        self._request_id += 1
                        await websocket.send(json.dumps(request, separators=(",", ":")))
                        self.stats.subscription_messages_sent += 1
                        await self._receive_until_stopped(websocket, stop_event)
                        if stop_event.is_set():
                            return
                        raise ConnectionError("Binance WebSocket closed without a stop request")
                    finally:
                        self._connected = False
            except MarkPriceQueueFullError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.stats.last_error = f"{type(exc).__name__}: {exc}"
                if stop_event.is_set():
                    return
                if self._monotonic() - session_started >= self.stable_connection_reset_seconds:
                    consecutive_reconnects = 0
                if consecutive_reconnects >= self.max_reconnect_attempts:
                    raise MarkPriceReconnectExhausted(
                        "Mark Price WebSocket reconnect limit exhausted after "
                        f"{consecutive_reconnects} retries"
                    ) from exc
                consecutive_reconnects += 1
                self.stats.reconnect_attempts += 1
                delay = min(
                    self.reconnect_base_delay_seconds * (2 ** (consecutive_reconnects - 1)),
                    self.reconnect_max_delay_seconds,
                )
                await self._wait_or_stop(stop_event, delay)

    async def _receive_until_stopped(self, websocket: Any, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            message = await self._recv_or_stop(websocket, stop_event)
            if message is None:
                return
            self.stats.messages_received += 1
            try:
                event = parse_mark_price_stream_message(
                    message,
                    source_endpoint=self.endpoint,
                    allowed_symbols=self.symbols,
                    update_speed=self.update_speed,
                    now_ms=self._wall_clock_ms(),
                    max_event_age_ms=self.max_event_age_ms,
                    max_future_skew_ms=self.max_future_skew_ms,
                )
            except MarkPriceStaleEventError:
                self.stats.stale_messages += 1
                continue
            except MarkPriceWebSocketProtocolError:
                raise
            except MarkPriceWebSocketParseError:
                self.stats.malformed_messages += 1
                continue
            if event is None:
                self.stats.acknowledgements_received += 1
                continue

            previous_event_time = self._last_event_time_by_symbol.get(event.symbol)
            if previous_event_time is not None and event.event_time_ms <= previous_event_time:
                self.stats.stale_messages += 1
                continue
            self._last_event_time_by_symbol[event.symbol] = event.event_time_ms
            try:
                self.events.put_nowait(event)
            except asyncio.QueueFull as exc:
                self.stats.queue_overflows += 1
                raise MarkPriceQueueFullError(
                    "Mark Price event queue is full; consumer is not keeping up with the stream"
                ) from exc
            self.stats.events_emitted += 1

    @staticmethod
    async def _recv_or_stop(websocket: Any, stop_event: asyncio.Event) -> str | bytes | None:
        receive_task = asyncio.create_task(websocket.recv())
        stop_task = asyncio.create_task(stop_event.wait())
        try:
            done, _ = await asyncio.wait(
                (receive_task, stop_task), return_when=asyncio.FIRST_COMPLETED
            )
            if receive_task in done:
                return receive_task.result()
            return None
        finally:
            for task in (receive_task, stop_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(receive_task, stop_task, return_exceptions=True)

    @staticmethod
    async def _wait_or_stop(stop_event: asyncio.Event, delay: float) -> None:
        if delay <= 0:
            await asyncio.sleep(0)
            return
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except TimeoutError:
            return
