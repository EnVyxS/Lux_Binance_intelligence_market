"""Bounded per-symbol orchestration for Binance USDⓈ-M depth books.

The supervisor owns feed consumption, REST snapshot pacing, buffering,
sequence synchronization and resynchronization. It exposes metrics only when
the feed, snapshot, sequence, freshness and queue-health gates all pass.
"""
from __future__ import annotations

import asyncio
import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

from divatrading.market_data.order_book import (
    BinanceDepthSnapshotClient,
    BinanceDepthWebSocketFeed,
    DepthEvent,
    LocalOrderBook,
    OrderBookError,
    OrderBookMetrics,
    OrderBookNotReady,
)

DEFAULT_MAX_BUFFERED_DEPTH_EVENTS = 2048
HARD_MAX_BUFFERED_DEPTH_EVENTS = 10000
DEFAULT_RESYNC_ATTEMPTS = 5
DEFAULT_RESYNC_RETRY_SECONDS = 0.25
DEFAULT_QUEUE_HEALTH_WATERMARK = 0.75


@dataclass(frozen=True, slots=True)
class OrderBookSymbolHealth:
    """Readiness contract for one exact Binance USDⓈ-M symbol."""

    symbol: str
    connection_state: str
    snapshot_state: str
    sequence_integrity: bool
    event_fresh: bool
    queue_healthy: bool
    ready: bool
    update_id: int | None
    event_age_ms: int | None
    queue_depth: int
    queue_capacity: int
    buffered_events: int
    invalid_reason: str
    last_error: str | None


@dataclass(slots=True)
class _SymbolRuntime:
    symbol: str
    book: LocalOrderBook
    buffer: deque[DepthEvent]
    buffer_ready: asyncio.Event = field(default_factory=asyncio.Event)
    resync_requested: asyncio.Event = field(default_factory=asyncio.Event)
    snapshot_state: str = "WAITING_FOR_STREAM"
    last_error: str | None = None
    consecutive_snapshot_failures: int = 0


class BinanceOrderBookSupervisor:
    """Own a bounded, sequence-safe depth book for each selected symbol.

    The supplied feed and REST client remain public/read-only components. A
    single REST lock serializes snapshots across symbols, while each blocking
    snapshot call runs in a worker thread so the event loop keeps draining the
    WebSocket queue. No depth diff persistence is performed.
    """

    def __init__(
        self,
        *,
        feed: BinanceDepthWebSocketFeed,
        snapshot_client: BinanceDepthSnapshotClient,
        max_buffered_events: int = DEFAULT_MAX_BUFFERED_DEPTH_EVENTS,
        max_levels: int = 100,
        depth_levels: int = 20,
        max_resync_attempts: int = DEFAULT_RESYNC_ATTEMPTS,
        resync_retry_seconds: float = DEFAULT_RESYNC_RETRY_SECONDS,
        queue_health_watermark: float = DEFAULT_QUEUE_HEALTH_WATERMARK,
        wall_clock_ms: Callable[[], int] | None = None,
    ) -> None:
        if isinstance(max_buffered_events, bool) or not 1 <= max_buffered_events <= HARD_MAX_BUFFERED_DEPTH_EVENTS:
            raise ValueError("max_buffered_events must be between 1 and 10000")
        if isinstance(max_resync_attempts, bool) or not 1 <= max_resync_attempts <= 20:
            raise ValueError("max_resync_attempts must be between 1 and 20")
        if not 0.05 <= resync_retry_seconds <= 10:
            raise ValueError("resync_retry_seconds must be between 0.05 and 10 seconds")
        if not 0.5 <= queue_health_watermark <= 0.95:
            raise ValueError("queue_health_watermark must be between 0.5 and 0.95")
        if not callable(getattr(feed, "get_event", None)) or not callable(getattr(feed, "run", None)):
            raise TypeError("feed must provide async run() and get_event()")
        feed_queue = getattr(feed, "events", None)
        if feed_queue is None or int(getattr(feed_queue, "maxsize", 0)) <= 0:
            raise ValueError("feed must expose a bounded events queue")
        if not callable(getattr(snapshot_client, "fetch", None)):
            raise TypeError("snapshot_client must provide fetch(symbol)")
        self.feed = feed
        self.snapshot_client = snapshot_client
        self.max_buffered_events = max_buffered_events
        self.max_resync_attempts = max_resync_attempts
        self.resync_retry_seconds = float(resync_retry_seconds)
        self.queue_health_watermark = float(queue_health_watermark)
        self._now_ms = wall_clock_ms or (lambda: time.time_ns() // 1_000_000)
        age_limit = int(getattr(feed, "max_event_age_ms", 3000))
        self._states: dict[str, _SymbolRuntime] = {
            symbol: _SymbolRuntime(
                symbol=symbol,
                book=LocalOrderBook(
                    symbol,
                    max_levels=max_levels,
                    depth_levels=depth_levels,
                    max_event_age_ms=age_limit,
                    wall_clock_ms=self._now_ms,
                ),
                buffer=deque(),
            )
            for symbol in tuple(feed.symbols)
        }
        if not self._states:
            raise ValueError("feed must contain at least one exact symbol")
        self._snapshot_lock = asyncio.Lock()
        self._last_connection_generation: int | None = None
        self._was_connected = False
        self._running = False

    @property
    def symbols(self) -> tuple[str, ...]:
        return tuple(self._states)

    @property
    def is_ready(self) -> bool:
        return all(self.health(symbol).ready for symbol in self.symbols)

    def health(self, symbol: str) -> OrderBookSymbolHealth:
        runtime = self._state(symbol)
        self._observe_connection_state()
        connected = bool(self.feed.is_connected)
        queue = getattr(self.feed, "events", None)
        queue_depth = int(queue.qsize()) if queue is not None else 0
        queue_capacity = int(queue.maxsize) if queue is not None else 0
        threshold = math.ceil(queue_capacity * self.queue_health_watermark) if queue_capacity else 0
        queue_healthy = not queue_capacity or queue_depth < threshold
        event_age: int | None = None
        event_fresh = False
        if runtime.book.synchronized and runtime.book.last_event_time_ms is not None:
            event_age = self._now_ms() - runtime.book.last_event_time_ms
            try:
                runtime.book.metrics()
                event_fresh = event_age <= runtime.book.max_event_age_ms and event_age >= -5000
            except OrderBookNotReady:
                runtime.snapshot_state = "RESYNC_REQUIRED"
                runtime.resync_requested.set()
        sequence_integrity = runtime.book.synchronized and runtime.book.update_id is not None
        ready = (
            connected
            and runtime.snapshot_state == "READY"
            and sequence_integrity
            and event_fresh
            and queue_healthy
        )
        return OrderBookSymbolHealth(
            symbol=runtime.symbol,
            connection_state="CONNECTED" if connected else "DISCONNECTED",
            snapshot_state=runtime.snapshot_state,
            sequence_integrity=sequence_integrity,
            event_fresh=event_fresh,
            queue_healthy=queue_healthy,
            ready=ready,
            update_id=runtime.book.update_id,
            event_age_ms=event_age,
            queue_depth=queue_depth,
            queue_capacity=queue_capacity,
            buffered_events=len(runtime.buffer),
            invalid_reason=runtime.book.invalid_reason,
            last_error=runtime.last_error,
        )

    def metrics(self, symbol: str) -> OrderBookMetrics:
        health = self.health(symbol)
        if not health.ready:
            raise OrderBookNotReady(
                f"{symbol} order book is not ready: connection={health.connection_state}, "
                f"snapshot={health.snapshot_state}, sequence={health.sequence_integrity}, "
                f"fresh={health.event_fresh}, queue_healthy={health.queue_healthy}"
            )
        return self._state(symbol).book.metrics()

    async def run(self, stop_event: asyncio.Event) -> None:
        """Run feed consumption and per-symbol resynchronization until stopped."""
        if self._running:
            raise RuntimeError("Order-book supervisor is already running")
        self._running = True
        feed_task = asyncio.create_task(self.feed.run(stop_event), name="depth-websocket-feed")
        resync_tasks = [
            asyncio.create_task(self._resync_loop(runtime, stop_event), name=f"depth-resync-{runtime.symbol}")
            for runtime in self._states.values()
        ]
        for runtime in self._states.values():
            runtime.resync_requested.set()
        event_task: asyncio.Task[DepthEvent] | None = asyncio.create_task(self.feed.get_event())
        try:
            while not stop_event.is_set():
                assert event_task is not None
                done, _ = await asyncio.wait(
                    {event_task, feed_task}, timeout=0.05, return_when=asyncio.FIRST_COMPLETED
                )
                self._observe_connection_state()
                if feed_task in done:
                    self._invalidate_all("FEED_STOPPED_UNEXPECTEDLY")
                    if feed_task.cancelled():
                        raise OrderBookError("Depth feed task was cancelled unexpectedly")
                    error = feed_task.exception()
                    if error is not None:
                        raise OrderBookError(f"Depth feed terminated: {error}") from error
                    if not stop_event.is_set():
                        raise OrderBookError("Depth feed stopped before supervisor shutdown")
                    break
                if event_task in done:
                    event = event_task.result()
                    self._accept_event(event)
                    event_task = asyncio.create_task(self.feed.get_event())
        finally:
            self._invalidate_all("SUPERVISOR_STOPPED")
            if not stop_event.is_set():
                stop_event.set()
            if event_task is not None and not event_task.done():
                event_task.cancel()
            for task in resync_tasks:
                task.cancel()
            if not feed_task.done():
                feed_task.cancel()
            await asyncio.gather(
                *(task for task in [event_task, feed_task, *resync_tasks] if task is not None),
                return_exceptions=True,
            )
            self._running = False

    def _state(self, symbol: str) -> _SymbolRuntime:
        if not isinstance(symbol, str):
            raise ValueError("symbol must be a string")
        key = symbol.strip().upper()
        try:
            return self._states[key]
        except KeyError as exc:
            raise KeyError(f"Unconfigured order-book symbol: {key}") from exc

    def _observe_connection_state(self) -> None:
        connected = bool(self.feed.is_connected)
        stats = getattr(self.feed, "stats", None)
        generation = int(getattr(stats, "connection_count", 0))
        if not connected:
            if self._was_connected:
                self._invalidate_all("FEED_DISCONNECTED")
            self._was_connected = False
            return
        if self._last_connection_generation is None:
            self._last_connection_generation = generation
        elif generation != self._last_connection_generation:
            self._last_connection_generation = generation
            self._invalidate_all("FEED_RECONNECTED")
        self._was_connected = True

    def _invalidate_symbol(self, runtime: _SymbolRuntime, reason: str) -> None:
        runtime.book.invalidate(reason)
        runtime.snapshot_state = "RESYNC_REQUIRED"
        runtime.buffer.clear()
        runtime.buffer_ready.clear()
        runtime.resync_requested.set()

    def _invalidate_all(self, reason: str) -> None:
        for runtime in self._states.values():
            self._invalidate_symbol(runtime, reason)

    def _accept_event(self, event: DepthEvent) -> None:
        runtime = self._states.get(event.symbol)
        if runtime is None:
            self._invalidate_all("UNEXPECTED_SYMBOL")
            raise OrderBookError(f"Feed emitted an unconfigured symbol: {event.symbol}")
        if runtime.snapshot_state == "ERROR":
            # A new event starts a fresh bounded retry cycle. Do not retain the
            # potentially stale batch that exhausted the previous retry budget.
            runtime.buffer.clear()
            runtime.buffer_ready.clear()
            runtime.consecutive_snapshot_failures = 0
            runtime.snapshot_state = "RESYNC_REQUIRED"
            runtime.resync_requested.set()
        if runtime.book.synchronized and runtime.snapshot_state == "READY":
            try:
                runtime.book.apply(event)
                return
            except OrderBookError as exc:
                runtime.last_error = f"{type(exc).__name__}: {exc}"
                self._invalidate_symbol(runtime, runtime.book.invalid_reason or "APPLY_FAILED")
        if len(runtime.buffer) >= self.max_buffered_events:
            self._invalidate_symbol(runtime, "INITIAL_BUFFER_OVERFLOW")
            runtime.last_error = "Initial diff buffer overflow; buffered sequence was discarded"
        runtime.buffer.append(event)
        runtime.buffer_ready.set()
        if runtime.snapshot_state == "ERROR":
            runtime.resync_requested.set()

    async def _resync_loop(self, runtime: _SymbolRuntime, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            await runtime.resync_requested.wait()
            runtime.resync_requested.clear()
            runtime.consecutive_snapshot_failures = 0
            while not stop_event.is_set() and runtime.snapshot_state != "READY":
                if not self.feed.is_connected:
                    runtime.snapshot_state = "WAITING_FOR_STREAM"
                    await self._wait_or_stop(stop_event, 0.05)
                    continue
                if not runtime.buffer:
                    runtime.snapshot_state = "BUFFERING"
                    runtime.buffer_ready.clear()
                    await self._wait_event_or_stop(runtime.buffer_ready, stop_event)
                    continue
                generation_before = int(getattr(getattr(self.feed, "stats", None), "connection_count", 0))
                runtime.snapshot_state = "FETCHING_SNAPSHOT"
                try:
                    async with self._snapshot_lock:
                        snapshot = await asyncio.to_thread(self.snapshot_client.fetch, runtime.symbol)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    runtime.consecutive_snapshot_failures += 1
                    runtime.last_error = f"{type(exc).__name__}: {exc}"
                    if runtime.consecutive_snapshot_failures >= self.max_resync_attempts:
                        runtime.snapshot_state = "ERROR"
                        break
                    runtime.snapshot_state = "RESYNC_REQUIRED"
                    await self._wait_or_stop(
                        stop_event, min(self.resync_retry_seconds * (2 ** (runtime.consecutive_snapshot_failures - 1)), 10.0)
                    )
                    continue
                generation_after = int(getattr(getattr(self.feed, "stats", None), "connection_count", 0))
                if not self.feed.is_connected or generation_after != generation_before:
                    runtime.snapshot_state = "RESYNC_REQUIRED"
                    runtime.last_error = "Feed connection changed during snapshot acquisition"
                    continue
                buffered = tuple(runtime.buffer)
                runtime.buffer.clear()
                runtime.buffer_ready.clear()
                try:
                    applied = runtime.book.synchronize(snapshot, buffered)
                    if applied > 0 and runtime.book.synchronized:
                        runtime.snapshot_state = "READY"
                        runtime.last_error = None
                        runtime.consecutive_snapshot_failures = 0
                        break
                    runtime.snapshot_state = "BUFFERING"
                    runtime.last_error = runtime.book.invalid_reason or "Snapshot did not bridge buffered events"
                except OrderBookError as exc:
                    runtime.last_error = f"{type(exc).__name__}: {exc}"
                    runtime.snapshot_state = "RESYNC_REQUIRED"
                    runtime.book.invalidate(runtime.book.invalid_reason or "SYNCHRONIZATION_FAILED")
                    runtime.consecutive_snapshot_failures += 1
                    if runtime.consecutive_snapshot_failures >= self.max_resync_attempts:
                        runtime.snapshot_state = "ERROR"
                        break
                # A non-bridging snapshot waits for another diff event before
                # requesting a new REST snapshot; this avoids a tight REST loop.

    @staticmethod
    async def _wait_or_stop(stop_event: asyncio.Event, seconds: float) -> None:
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=seconds)
        except TimeoutError:
            return

    @staticmethod
    async def _wait_event_or_stop(target: asyncio.Event, stop_event: asyncio.Event) -> None:
        target_task = asyncio.create_task(target.wait())
        stop_task = asyncio.create_task(stop_event.wait())
        try:
            await asyncio.wait({target_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for task in (target_task, stop_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(target_task, stop_task, return_exceptions=True)
