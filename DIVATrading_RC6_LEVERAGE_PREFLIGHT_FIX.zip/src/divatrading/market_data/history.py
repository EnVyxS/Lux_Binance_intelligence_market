"""Bounded, rate-aware historical Kline pagination for Binance USD-M Futures."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable

from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline


class KlineHistoryError(RuntimeError):
    """Base class for historical Kline collection errors."""


class KlinePaginationError(KlineHistoryError):
    """Raised when a page is unordered, duplicated or outside the requested window."""


@dataclass(frozen=True, slots=True)
class HistoricalKlineBatch:
    symbol: str
    interval: str
    requested_start_time_ms: int
    requested_end_time_ms: int
    candles: tuple[Kline, ...]
    pages_fetched: int
    complete: bool
    next_start_time_ms: int | None
    missing_open_times_ms: tuple[int, ...]
    source_endpoint: str


class HistoricalKlineService:
    """Fetch Klines using inclusive time bounds and cursor-safe pagination.

    A batch is bounded by ``max_pages``. If the cap is reached, ``complete`` is
    false and ``next_start_time_ms`` can be supplied to resume without overlap.
    Missing intervals are reported, never synthesized, because a returned gap must
    not be silently converted into fabricated market data.
    """

    def __init__(
        self,
        client: BinanceUsdMFuturesRestClient,
        *,
        page_limit: int = 499,
        max_pages: int = 20,
        min_request_interval_seconds: float = 0.1,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if not 1 <= page_limit <= 1500:
            raise ValueError("page_limit must be between 1 and 1500")
        if not 1 <= max_pages <= 100:
            raise ValueError("max_pages must be between 1 and 100")
        if min_request_interval_seconds < 0:
            raise ValueError("min_request_interval_seconds cannot be negative")
        self.client = client
        self.page_limit = page_limit
        self.max_pages = max_pages
        self.min_request_interval_seconds = min_request_interval_seconds
        self._sleep = sleep
        self._monotonic = monotonic

    def fetch(
        self,
        *,
        symbol: str,
        interval: str,
        start_time_ms: int,
        end_time_ms: int,
        max_pages: int | None = None,
    ) -> HistoricalKlineBatch:
        normalized_symbol = symbol.strip().upper()
        if not normalized_symbol:
            raise ValueError("symbol cannot be empty")
        if interval not in INTERVAL_MILLISECONDS:
            raise ValueError("interval must be one of: 1m, 5m, 15m")
        if isinstance(start_time_ms, bool) or not isinstance(start_time_ms, int) or start_time_ms < 0:
            raise ValueError("start_time_ms must be a non-negative integer")
        if isinstance(end_time_ms, bool) or not isinstance(end_time_ms, int) or end_time_ms < start_time_ms:
            raise ValueError("end_time_ms must be an integer greater than or equal to start_time_ms")
        page_cap = self.max_pages if max_pages is None else max_pages
        if isinstance(page_cap, bool) or not isinstance(page_cap, int) or not 1 <= page_cap <= 100:
            raise ValueError("max_pages must be between 1 and 100")

        interval_ms = INTERVAL_MILLISECONDS[interval]
        cursor = start_time_ms
        candles: list[Kline] = []
        pages_fetched = 0
        previous_request_at: float | None = None
        last_open_time: int | None = None
        source_endpoint = self.client.klines_endpoint

        while cursor <= end_time_ms and pages_fetched < page_cap:
            if previous_request_at is not None and self.min_request_interval_seconds:
                elapsed = self._monotonic() - previous_request_at
                remaining = self.min_request_interval_seconds - elapsed
                if remaining > 0:
                    self._sleep(remaining)
            previous_request_at = self._monotonic()

            rows = self.client.get_klines(
                symbol=normalized_symbol,
                interval=interval,
                start_time_ms=cursor,
                end_time_ms=end_time_ms,
                limit=self.page_limit,
            )
            pages_fetched += 1
            if not rows:
                cursor = end_time_ms + 1
                break
            if len(rows) > self.page_limit:
                raise KlinePaginationError("Binance returned more rows than the requested page limit")

            page_open_times: list[int] = []
            page_candles: list[Kline] = []
            for row in rows:
                candle = Kline.from_binance_row(
                    row,
                    symbol=normalized_symbol,
                    interval=interval,
                    source_endpoint=source_endpoint,
                )
                if candle.open_time_ms < cursor or candle.open_time_ms > end_time_ms:
                    raise KlinePaginationError(
                        "Binance returned a Kline outside the requested page time window"
                    )
                if last_open_time is not None and candle.open_time_ms <= last_open_time:
                    raise KlinePaginationError("Kline pagination returned a duplicate or out-of-order candle")
                if page_open_times and candle.open_time_ms <= page_open_times[-1]:
                    raise KlinePaginationError("Kline page is not strictly chronological")
                page_open_times.append(candle.open_time_ms)
                page_candles.append(candle)
                last_open_time = candle.open_time_ms

            candles.extend(page_candles)
            if len(rows) < self.page_limit:
                cursor = end_time_ms + 1
                break

            # Binance's time parameters are inclusive. Move the next page to the
            # next interval open, not the previous candle's close time.
            cursor = page_open_times[-1] + interval_ms

        complete = cursor > end_time_ms
        missing: list[int] = []
        for previous, current in zip(candles, candles[1:]):
            expected = previous.open_time_ms + interval_ms
            while expected < current.open_time_ms:
                missing.append(expected)
                expected += interval_ms

        return HistoricalKlineBatch(
            symbol=normalized_symbol,
            interval=interval,
            requested_start_time_ms=start_time_ms,
            requested_end_time_ms=end_time_ms,
            candles=tuple(candles),
            pages_fetched=pages_fetched,
            complete=complete,
            next_start_time_ms=None if complete else cursor,
            missing_open_times_ms=tuple(missing),
            source_endpoint=source_endpoint,
        )
