"""Bounded REST reconciliation for Binance USD-M WebSocket Kline feeds."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Callable, Iterable, Mapping

from divatrading.market_data.history import HistoricalKlineService
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.storage import KlineRepository
from divatrading.market_data.websocket import (
    BinanceKlineWebSocketFeed,
    MarketKlineEvent,
    normalize_subscriptions,
)


class RecoveryError(RuntimeError):
    """Base exception for market-data recovery failures."""


class RecoveryNotConnectedError(RecoveryError):
    """Raised when REST recovery is requested while the feed is disconnected."""


class RecoveryConfigurationError(RecoveryError):
    """Raised when a stream lacks a safe recovery starting point."""


class RecoveryIncompleteError(RecoveryError):
    """Raised when a closed WebSocket candle cannot yet be safely ingested."""


class FeedHealth(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    RECOVERING = "RECOVERING"
    DEGRADED = "DEGRADED"
    HEALTHY = "HEALTHY"


@dataclass(frozen=True, slots=True, order=True)
class RecoveryKey:
    symbol: str
    interval: str


@dataclass(frozen=True, slots=True)
class GapRange:
    """Inclusive interval-open range containing candles absent from local storage."""

    start_open_time_ms: int
    end_open_time_ms: int

    def __post_init__(self) -> None:
        if self.start_open_time_ms < 0 or self.end_open_time_ms < self.start_open_time_ms:
            raise ValueError("GapRange bounds are invalid")


@dataclass(frozen=True, slots=True)
class RecoveryResult:
    symbol: str
    interval: str
    target_end_open_time_ms: int
    gaps_detected: tuple[GapRange, ...]
    candles_fetched: int
    candles_persisted: int
    pages_fetched: int
    missing_open_times_ms: tuple[int, ...]
    complete: bool
    next_start_open_time_ms: int | None
    health: FeedHealth
    detail: str | None = None


@dataclass(slots=True)
class _StreamState:
    bootstrap_start_open_time_ms: int | None
    health: FeedHealth = FeedHealth.DISCONNECTED
    last_target_open_time_ms: int | None = None
    last_error: str | None = None
    last_result: RecoveryResult | None = None


class KlineRecoveryService:
    """Recover candle gaps between Binance WebSocket, REST history and SQLite.

    Recovery is deliberately explicit: callers register the exact subscribed
    streams, mark connection transitions, then call ``recover_stream`` for each
    required stream before treating market data as ready. REST requests and each
    recovery pass are bounded. No candle is synthesized.
    """

    def __init__(
        self,
        history_service: HistoricalKlineService,
        repository: KlineRepository,
        *,
        max_pages_per_recovery: int = 20,
        audit_window_candles: int = 5_000,
        now_ms: Callable[[], int] | None = None,
    ) -> None:
        if isinstance(max_pages_per_recovery, bool) or not isinstance(max_pages_per_recovery, int):
            raise ValueError("max_pages_per_recovery must be an integer")
        if not 1 <= max_pages_per_recovery <= min(100, history_service.max_pages):
            raise ValueError("max_pages_per_recovery must be between 1 and the history service page cap")
        if isinstance(audit_window_candles, bool) or not isinstance(audit_window_candles, int):
            raise ValueError("audit_window_candles must be an integer")
        if not 2 <= audit_window_candles <= 5_000:
            raise ValueError("audit_window_candles must be between 2 and 5000")
        self.history_service = history_service
        self.repository = repository
        self.max_pages_per_recovery = max_pages_per_recovery
        self.audit_window_candles = audit_window_candles
        self._now_ms = now_ms or (lambda: int(datetime.now(UTC).timestamp() * 1000))
        self._streams: dict[RecoveryKey, _StreamState] = {}
        self._feed_connected = False
        self._observed_connection_count = 0

    @property
    def feed_connected(self) -> bool:
        return self._feed_connected

    @property
    def health(self) -> FeedHealth:
        if not self._feed_connected:
            return FeedHealth.DISCONNECTED
        if not self._streams:
            return FeedHealth.DEGRADED
        states = {stream.health for stream in self._streams.values()}
        if FeedHealth.DEGRADED in states:
            return FeedHealth.DEGRADED
        if states == {FeedHealth.HEALTHY}:
            return FeedHealth.HEALTHY
        return FeedHealth.RECOVERING

    @property
    def is_ready(self) -> bool:
        """True only when the feed is connected and every required stream is reconciled."""
        return self.health is FeedHealth.HEALTHY

    def register_stream(
        self,
        *,
        symbol: str,
        interval: str,
        bootstrap_start_open_time_ms: int | None = None,
    ) -> RecoveryKey:
        symbols, intervals, _ = normalize_subscriptions([symbol], [interval])
        normalized_symbol = symbols[0]
        normalized_interval = intervals[0]
        if bootstrap_start_open_time_ms is not None:
            self._validate_open_time(
                bootstrap_start_open_time_ms,
                normalized_interval,
                field_name="bootstrap_start_open_time_ms",
            )
        key = RecoveryKey(normalized_symbol, normalized_interval)
        existing = self._streams.get(key)
        if existing is None:
            initial_health = FeedHealth.RECOVERING if self._feed_connected else FeedHealth.DISCONNECTED
            self._streams[key] = _StreamState(bootstrap_start_open_time_ms, health=initial_health)
        elif bootstrap_start_open_time_ms is not None:
            existing.bootstrap_start_open_time_ms = bootstrap_start_open_time_ms
        return key

    def mark_feed_connected(self) -> None:
        """Mark a new/current WebSocket session; every registered stream needs recovery."""
        self._feed_connected = True
        for state in self._streams.values():
            state.health = FeedHealth.RECOVERING
            state.last_error = None
            state.last_result = None

    def observe_websocket_feed(self, feed: BinanceKlineWebSocketFeed) -> FeedHealth:
        """Synchronize recovery health with the Unit 03C feed's live connection state.

        Call this from the market-data supervisor. ``connection_count`` detects a
        fast internal reconnect even when polling never observes ``is_connected``
        changing to false between two polls.
        """
        if not isinstance(feed, BinanceKlineWebSocketFeed):
            raise TypeError("feed must be a BinanceKlineWebSocketFeed")
        connection_count = feed.stats.connection_count
        if not feed.is_connected:
            if self._feed_connected:
                self.mark_feed_disconnected(feed.stats.last_error or "WebSocket disconnected")
            return self.health
        if not self._feed_connected or connection_count != self._observed_connection_count:
            self.mark_feed_connected()
            self._observed_connection_count = connection_count
        return self.health

    def mark_feed_disconnected(self, reason: str = "WebSocket disconnected") -> None:
        self._feed_connected = False
        for state in self._streams.values():
            state.health = FeedHealth.DISCONNECTED
            state.last_error = reason[:500]
            state.last_result = None

    def stream_health(self, *, symbol: str, interval: str) -> FeedHealth:
        key = self._key(symbol, interval)
        state = self._streams.get(key)
        return state.health if state is not None else FeedHealth.DISCONNECTED

    def stream_error(self, *, symbol: str, interval: str) -> str | None:
        key = self._key(symbol, interval)
        state = self._streams.get(key)
        return state.last_error if state is not None else "Stream is not registered"

    def recover_registered_streams(
        self,
        target_end_open_times_ms: Mapping[tuple[str, str], int],
    ) -> tuple[RecoveryResult, ...]:
        """Recover all registered streams; missing targets are treated as failures."""
        if not self._feed_connected:
            raise RecoveryNotConnectedError("Cannot recover while the WebSocket feed is disconnected")
        normalized_targets = {
            (symbol.strip().upper(), interval): target
            for (symbol, interval), target in target_end_open_times_ms.items()
        }
        results: list[RecoveryResult] = []
        for key in sorted(self._streams):
            target = normalized_targets.get((key.symbol, key.interval))
            if target is None:
                state = self._streams[key]
                state.health = FeedHealth.DEGRADED
                state.last_error = "No confirmed target candle supplied for registered stream"
                continue
            results.append(
                self.recover_stream(
                    symbol=key.symbol,
                    interval=key.interval,
                    target_end_open_time_ms=target,
                )
            )
        return tuple(results)

    def recover_stream(
        self,
        *,
        symbol: str,
        interval: str,
        target_end_open_time_ms: int,
    ) -> RecoveryResult:
        """Backfill missing *closed* candles through one bounded REST recovery pass.

        ``target_end_open_time_ms`` must identify a candle known to be closed. The
        injected clock is checked independently so callers cannot accidentally ask
        the service to persist a still-forming REST candle.
        """
        if not self._feed_connected:
            raise RecoveryNotConnectedError("Cannot recover while the WebSocket feed is disconnected")
        key = self._key(symbol, interval)
        state = self._streams.get(key)
        if state is None:
            key = self.register_stream(symbol=key.symbol, interval=key.interval)
            state = self._streams[key]

        self._validate_open_time(target_end_open_time_ms, key.interval, field_name="target_end_open_time_ms")
        interval_ms = INTERVAL_MILLISECONDS[key.interval]
        target_close_time_ms = target_end_open_time_ms + interval_ms - 1
        if target_close_time_ms >= self._now_ms():
            state.health = FeedHealth.DEGRADED
            state.last_error = "Target candle is not confirmed closed by the local clock"
            raise RecoveryConfigurationError(state.last_error)

        state.health = FeedHealth.RECOVERING
        state.last_error = None
        try:
            rows = self.repository.read_tail(
                symbol=key.symbol,
                interval=key.interval,
                limit=self.audit_window_candles,
                end_open_time_ms=target_end_open_time_ms,
            )
            existing_klines = [item.kline for item in rows]
            earliest_open = self.repository.earliest_open_time_ms(
                symbol=key.symbol,
                interval=key.interval,
            )
            gaps = self._find_gap_ranges(
                existing_klines,
                interval_ms=interval_ms,
                target_end_open_time_ms=target_end_open_time_ms,
                bootstrap_start_open_time_ms=state.bootstrap_start_open_time_ms,
                earliest_open_time_ms=earliest_open,
            )
            if not gaps:
                result = RecoveryResult(
                    symbol=key.symbol,
                    interval=key.interval,
                    target_end_open_time_ms=target_end_open_time_ms,
                    gaps_detected=(),
                    candles_fetched=0,
                    candles_persisted=0,
                    pages_fetched=0,
                    missing_open_times_ms=(),
                    complete=True,
                    next_start_open_time_ms=None,
                    health=FeedHealth.HEALTHY,
                )
                state.health = FeedHealth.HEALTHY
                state.last_target_open_time_ms = target_end_open_time_ms
                state.last_result = result
                return result

            return self._execute_gaps(key, state, target_end_open_time_ms, gaps)
        except Exception as exc:
            if state.health is not FeedHealth.HEALTHY:
                state.health = FeedHealth.DEGRADED
                state.last_error = f"{type(exc).__name__}: {exc}"[:500]
            raise

    def ingest_websocket_event(self, event: MarketKlineEvent) -> bool:
        """Persist a CLOSED WS event only after all earlier gaps are reconciled.

        FORMING events are deliberately ignored. If backfill is incomplete, the
        closed event is not written yet and ``RecoveryIncompleteError`` is raised;
        the consumer should retain/retry the event rather than advancing strategy
        readiness past a gap.
        """
        if not isinstance(event, MarketKlineEvent):
            raise TypeError("event must be a MarketKlineEvent")
        if not event.is_closed:
            return False
        if not self._feed_connected:
            raise RecoveryNotConnectedError("Cannot ingest WebSocket candles while disconnected")

        kline = event.kline
        key = self._key(kline.symbol, kline.interval)
        if key not in self._streams:
            self.register_stream(symbol=key.symbol, interval=key.interval)
        previous_open = kline.open_time_ms - INTERVAL_MILLISECONDS[kline.interval]
        if previous_open >= 0:
            result = self.recover_stream(
                symbol=key.symbol,
                interval=key.interval,
                target_end_open_time_ms=previous_open,
            )
            if not result.complete:
                raise RecoveryIncompleteError(
                    f"Earlier candle gaps remain for {key.symbol} {key.interval}; "
                    "closed WebSocket candle was not persisted"
                )
        if self.stream_health(symbol=key.symbol, interval=key.interval) is not FeedHealth.HEALTHY:
            raise RecoveryIncompleteError("Stream is not healthy; closed candle was not persisted")
        if event.received_at_utc.tzinfo is None or event.received_at_utc.utcoffset() is None:
            raise RecoveryConfigurationError("WebSocket event receive timestamp must be timezone-aware")
        fetched_at = event.received_at_utc.astimezone(UTC).isoformat(timespec="milliseconds").replace(
            "+00:00", "Z"
        )
        self.repository.upsert_many([kline], fetched_at_utc=fetched_at)
        state = self._streams[key]
        state.last_target_open_time_ms = kline.open_time_ms
        return True

    def _execute_gaps(
        self,
        key: RecoveryKey,
        state: _StreamState,
        target_end_open_time_ms: int,
        gaps: tuple[GapRange, ...],
    ) -> RecoveryResult:
        interval_ms = INTERVAL_MILLISECONDS[key.interval]
        pages_remaining = self.max_pages_per_recovery
        candles_fetched = 0
        candles_persisted = 0
        pages_fetched = 0
        unresolved: set[int] = set()
        next_start: int | None = None
        detail: str | None = None
        bounded_out = False
        now_ms = self._now_ms()

        # Keep one audit-window slot for the candle immediately before the
        # recovered chunk. This lets the next bounded pass detect any REST gap
        # from the preceding anchor without scanning unbounded history.
        max_candles = min(
            self.history_service.page_limit * self.max_pages_per_recovery,
            self.audit_window_candles - 1,
        )
        candles_remaining = max_candles
        for gap in gaps:
            if pages_remaining <= 0 or candles_remaining <= 0:
                next_start = gap.start_open_time_ms
                bounded_out = True
                detail = "Per-recovery page/candle budget reached"
                break

            expected_count = ((gap.end_open_time_ms - gap.start_open_time_ms) // interval_ms) + 1
            requested_count = min(expected_count, candles_remaining)
            requested_end_open = gap.start_open_time_ms + (requested_count - 1) * interval_ms
            clipped = requested_end_open < gap.end_open_time_ms
            batch = self.history_service.fetch(
                symbol=key.symbol,
                interval=key.interval,
                start_time_ms=gap.start_open_time_ms,
                end_time_ms=requested_end_open + interval_ms - 1,
                max_pages=pages_remaining,
            )
            pages_fetched += batch.pages_fetched
            pages_remaining -= batch.pages_fetched
            candles_remaining -= requested_count
            candles_fetched += len(batch.candles)

            confirmed = tuple(candle for candle in batch.candles if candle.close_time_ms < now_ms)
            confirmed_opens = {candle.open_time_ms for candle in confirmed}
            expected_opens = range(
                gap.start_open_time_ms,
                requested_end_open + 1,
                interval_ms,
            )
            missing_this_range = {open_time for open_time in expected_opens if open_time not in confirmed_opens}
            if missing_this_range:
                unresolved.update(missing_this_range)
            unconfirmed_count = len(batch.candles) - len(confirmed)
            if unconfirmed_count:
                detail = "REST returned one or more candles that are not yet closed"

            if confirmed:
                candles_persisted += self.repository.upsert_many(
                    confirmed,
                    fetched_at_utc=datetime.fromtimestamp(now_ms / 1000, tz=UTC)
                    .isoformat(timespec="milliseconds")
                    .replace("+00:00", "Z"),
                )

            if not batch.complete:
                next_start = batch.next_start_time_ms or (
                    (max(confirmed_opens) + interval_ms) if confirmed_opens else gap.start_open_time_ms
                )
                bounded_out = True
                detail = detail or "Historical REST pagination reached its page cap"
                break
            if clipped:
                next_start = requested_end_open + interval_ms
                bounded_out = True
                detail = detail or "Per-recovery candle budget reached"
                break
            if missing_this_range:
                first_missing = min(missing_this_range)
                next_start = first_missing
                detail = detail or "Binance REST did not return every expected candle; no synthetic candle created"
                # Continue with later independent ranges only when budget remains.
                continue

        # Re-check the bounded local tail. A recovery is complete only if every
        # detected range has been represented by confirmed persisted candles.
        if not bounded_out and not unresolved:
            remaining_rows = self.repository.read_tail(
                symbol=key.symbol,
                interval=key.interval,
                limit=self.audit_window_candles,
                end_open_time_ms=target_end_open_time_ms,
            )
            remaining_gaps = self._find_gap_ranges(
                [item.kline for item in remaining_rows],
                interval_ms=interval_ms,
                target_end_open_time_ms=target_end_open_time_ms,
                bootstrap_start_open_time_ms=state.bootstrap_start_open_time_ms,
                earliest_open_time_ms=self.repository.earliest_open_time_ms(
                    symbol=key.symbol,
                    interval=key.interval,
                ),
            )
            if remaining_gaps:
                for remaining in remaining_gaps:
                    unresolved.update(
                        range(
                            remaining.start_open_time_ms,
                            remaining.end_open_time_ms + 1,
                            interval_ms,
                        )
                    )
                next_start = min(unresolved) if unresolved else None
                detail = detail or "Local storage still contains unresolved candle gaps"

        complete = not bounded_out and not unresolved
        health = FeedHealth.HEALTHY if complete else FeedHealth.DEGRADED
        state.health = health
        state.last_error = None if complete else detail
        state.last_target_open_time_ms = target_end_open_time_ms if complete else state.last_target_open_time_ms
        result = RecoveryResult(
            symbol=key.symbol,
            interval=key.interval,
            target_end_open_time_ms=target_end_open_time_ms,
            gaps_detected=gaps,
            candles_fetched=candles_fetched,
            candles_persisted=candles_persisted,
            pages_fetched=pages_fetched,
            missing_open_times_ms=tuple(sorted(unresolved)),
            complete=complete,
            next_start_open_time_ms=next_start,
            health=health,
            detail=detail,
        )
        state.last_result = result
        return result

    @staticmethod
    def _find_gap_ranges(
        existing_klines: Iterable[Kline],
        *,
        interval_ms: int,
        target_end_open_time_ms: int,
        bootstrap_start_open_time_ms: int | None,
        earliest_open_time_ms: int | None,
    ) -> tuple[GapRange, ...]:
        candles = sorted(
            (item for item in existing_klines if item.open_time_ms <= target_end_open_time_ms),
            key=lambda item: item.open_time_ms,
        )
        gaps: list[GapRange] = []
        if candles:
            if (
                bootstrap_start_open_time_ms is not None
                and earliest_open_time_ms is not None
                and bootstrap_start_open_time_ms < earliest_open_time_ms
                and bootstrap_start_open_time_ms <= target_end_open_time_ms
            ):
                leading_end = min(target_end_open_time_ms, earliest_open_time_ms - interval_ms)
                if bootstrap_start_open_time_ms <= leading_end:
                    gaps.append(GapRange(bootstrap_start_open_time_ms, leading_end))
            for previous, current in zip(candles, candles[1:]):
                expected = previous.open_time_ms + interval_ms
                if expected < current.open_time_ms:
                    gaps.append(GapRange(expected, current.open_time_ms - interval_ms))
            next_expected = candles[-1].open_time_ms + interval_ms
            if next_expected <= target_end_open_time_ms:
                gaps.append(GapRange(next_expected, target_end_open_time_ms))
        elif bootstrap_start_open_time_ms is not None:
            if bootstrap_start_open_time_ms <= target_end_open_time_ms:
                gaps.append(GapRange(bootstrap_start_open_time_ms, target_end_open_time_ms))
        else:
            raise RecoveryConfigurationError(
                "No local Kline exists; configure bootstrap_start_open_time_ms for this stream"
            )
        return tuple(gaps)

    @staticmethod
    def _validate_open_time(value: int, interval: str, *, field_name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise RecoveryConfigurationError(f"{field_name} must be a non-negative integer")
        if interval not in INTERVAL_MILLISECONDS or value % INTERVAL_MILLISECONDS[interval]:
            raise RecoveryConfigurationError(f"{field_name} is not aligned to {interval}")

    @staticmethod
    def _key(symbol: str, interval: str) -> RecoveryKey:
        symbols, intervals, _ = normalize_subscriptions([symbol], [interval])
        return RecoveryKey(symbols[0], intervals[0])
