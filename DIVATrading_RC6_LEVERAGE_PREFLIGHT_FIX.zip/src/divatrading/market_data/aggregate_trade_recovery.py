"""Durable Aggregate Trade bootstrap, gap detection and REST reconciliation."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Callable

from divatrading.market_data.aggregate_trade_history import (
    BINANCE_AGG_TRADE_HISTORY_WINDOW_MS,
    AggregateTradeHistoryBatch,
    AggregateTradeHistoryError,
    AggregateTradeRecord,
    BinanceAggregateTradeHistoryService,
)
from divatrading.market_data.aggregate_trade_storage import (
    AggregateTradeRepository,
    AggregateTradeStreamState,
    AggregateTradeStreamStateError,
)
from divatrading.market_data.aggregate_trades import AggregateTradeEvent


class AggregateTradeRecoveryError(RuntimeError):
    """Base class for Aggregate Trade recovery failures."""


class AggregateTradeRecoveryRequired(AggregateTradeRecoveryError):
    """Raised when a stream needs bootstrap/reconciliation before use."""


@dataclass(frozen=True, slots=True)
class AggregateTradeRecoveryResult:
    symbol: str
    status: str
    records_recovered: int
    pages_fetched: int
    complete: bool
    next_from_id: int | None
    missing_id: int | None
    reason: str | None


class AggregateTradeRecoveryService:
    """Connect Unit 04A WebSocket events to REST history and SQLite continuity.

    The caller must connect the WebSocket and start draining its bounded queue
    before calling ``bootstrap_latest``. This overlaps the REST baseline window
    with live traffic so events arriving during bootstrap are not discarded.
    """

    def __init__(
        self,
        history: BinanceAggregateTradeHistoryService,
        repository: AggregateTradeRepository,
        *,
        history_window_ms: int = BINANCE_AGG_TRADE_HISTORY_WINDOW_MS,
        now_ms: Callable[[], int] | None = None,
    ) -> None:
        if isinstance(history_window_ms, bool) or not isinstance(history_window_ms, int) or history_window_ms <= 0:
            raise ValueError("history_window_ms must be a positive integer")
        self.history = history
        self.repository = repository
        self.history_window_ms = history_window_ms
        self._now_ms = now_ms or (lambda: int(datetime.now(UTC).timestamp() * 1000))

    def bootstrap_latest(self, *, symbol: str, limit: int | None = None) -> AggregateTradeStreamState:
        """Establish an explicit recent baseline from a contiguous latest REST page."""
        batch = self.history.fetch_latest(symbol=symbol, limit=limit)
        if not batch.records:
            raise AggregateTradeRecoveryRequired(
                "Binance returned no recent aggregate trades; no baseline can be established"
            )
        return self.repository.bootstrap_latest(batch.records)

    def ingest_websocket_event(self, event: AggregateTradeEvent) -> AggregateTradeStreamState:
        """Persist a live event; gaps remain durable and block HEALTHY status."""
        if not isinstance(event, AggregateTradeEvent):
            raise TypeError("event must be an AggregateTradeEvent")
        return self.repository.record_observed(AggregateTradeRecord.from_websocket(event))

    def recover_gap(self, *, symbol: str) -> AggregateTradeRecoveryResult:
        """Backfill missing IDs in a bounded pass; never synthesize missing trades."""
        try:
            state = self.repository.get_stream_state(symbol)
        except AggregateTradeStreamStateError as exc:
            raise AggregateTradeRecoveryRequired(
                f"Stream {symbol} must be bootstrapped before recovery"
            ) from exc

        if state.status == "HEALTHY":
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=True, next_from_id=None, missing_id=None, reason=None,
            )
        if state.status == "UNRESOLVED":
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=False,
                next_from_id=state.unresolved_gap_from_id,
                missing_id=state.unresolved_gap_from_id,
                reason="A previous recovery marked this gap as outside/unavailable in exchange history",
            )

        expected_id = state.last_contiguous_aggregate_trade_id + 1
        through_id = state.latest_observed_aggregate_trade_id - 1
        if through_id < expected_id:
            # This can be a just-registered stream awaiting its first expected row.
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=False, next_from_id=expected_id,
                missing_id=expected_id, reason="No later observed ID defines a closed recovery range",
            )

        cutoff_ms = self._now_ms() - self.history_window_ms
        baseline_time = state.last_contiguous_trade_time_ms
        observed_time = state.latest_observed_trade_time_ms
        if baseline_time is not None and baseline_time < cutoff_ms:
            reason = (
                "The missing range begins before the exchange's documented recent aggregate-trade history window; "
                "historical IDs cannot be assumed retrievable."
            )
            updated = self.repository.mark_unresolved(
                symbol=state.symbol, status="UNRESOLVED_RETENTION", reason=reason
            )
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=updated.status, records_recovered=0,
                pages_fetched=0, complete=False, next_from_id=expected_id,
                missing_id=expected_id, reason=reason,
            )
        if observed_time is not None and observed_time < cutoff_ms:
            reason = "Observed gap endpoint is older than the supported exchange history window."
            updated = self.repository.mark_unresolved(
                symbol=state.symbol, status="UNRESOLVED_RETENTION", reason=reason
            )
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=updated.status, records_recovered=0,
                pages_fetched=0, complete=False, next_from_id=expected_id,
                missing_id=expected_id, reason=reason,
            )

        try:
            batch = self.history.fetch_range(
                symbol=state.symbol, from_id=expected_id, through_id=through_id
            )
        except AggregateTradeHistoryError:
            raise
        recovered = self.repository.persist_recovered(batch.records, symbol=state.symbol)
        state_after = self.repository.get_stream_state(state.symbol)
        if batch.complete and state_after.last_contiguous_aggregate_trade_id >= state.latest_observed_aggregate_trade_id:
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state_after.status,
                records_recovered=len(batch.records), pages_fetched=batch.pages_fetched,
                complete=state_after.status == "HEALTHY", next_from_id=None,
                missing_id=None, reason=None,
            )

        if batch.missing_id is not None:
            reason = (
                f"REST history did not provide expected aggregate trade ID {batch.missing_id}. "
                "The range remains unresolved; no synthetic trade was created."
            )
            updated = self.repository.mark_unresolved(
                symbol=state.symbol, status="UNRESOLVED_HISTORY", reason=reason
            )
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=updated.status,
                records_recovered=len(batch.records), pages_fetched=batch.pages_fetched,
                complete=False, next_from_id=batch.missing_id,
                missing_id=batch.missing_id, reason=reason,
            )

        return AggregateTradeRecoveryResult(
            symbol=state.symbol, status=recovered.status,
            records_recovered=len(batch.records), pages_fetched=batch.pages_fetched,
            complete=False, next_from_id=batch.next_from_id,
            missing_id=None,
            reason="Per-pass page cap reached; continue from next_from_id in another bounded pass.",
        )
