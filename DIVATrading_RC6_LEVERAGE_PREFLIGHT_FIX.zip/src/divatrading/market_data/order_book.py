"""Bounded Binance USDⓈ-M diff-depth feed and sequence-safe local order book.

The book is intentionally read-only. Depth metrics are available only while the
snapshot/diff sequence is synchronized and fresh.
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Iterable

import httpx
from websockets.asyncio.client import connect as websocket_connect

from divatrading.market_data.websocket import WEBSOCKET_MAX_FRAME_QUEUE, WEBSOCKET_MAX_MESSAGE_BYTES

BINANCE_UM_DEPTH_REST_ENDPOINT = "https://fapi.binance.com/fapi/v1/depth"
BINANCE_UM_DEPTH_WS_ENDPOINT = "wss://fstream.binance.com/public/stream"
BINANCE_UM_DEMO_DEPTH_WS_ENDPOINT = "wss://demo-fstream.binance.com/public/stream"
VALID_DEPTH_LIMITS = (5, 10, 20, 50, 100, 500, 1000)
DEFAULT_DEPTH_LIMIT = 100
DEFAULT_BOOK_LEVELS = 100
DEFAULT_DEPTH_QUEUE_CAPACITY = 4096
HARD_MAX_DEPTH_QUEUE_CAPACITY = 16384
DEFAULT_DEPTH_MAX_SUBSCRIPTIONS = 8
HARD_MAX_DEPTH_SUBSCRIPTIONS = 32
DEFAULT_DEPTH_MAX_AGE_MS = 3000
_SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,30}$")


class OrderBookError(RuntimeError): pass
class OrderBookParseError(OrderBookError): pass
class OrderBookProtocolError(OrderBookError): pass
class OrderBookSequenceError(OrderBookError): pass
class OrderBookStaleEventError(OrderBookError): pass
class OrderBookQueueFullError(OrderBookError): pass
class OrderBookNotReady(OrderBookError): pass


@dataclass(frozen=True, slots=True)
class DepthLevel:
    price: Decimal
    quantity: Decimal


@dataclass(frozen=True, slots=True)
class DepthEvent:
    symbol: str
    first_update_id: int
    final_update_id: int
    previous_final_update_id: int | None
    event_time_ms: int
    transaction_time_ms: int | None
    bids: tuple[DepthLevel, ...]
    asks: tuple[DepthLevel, ...]
    stream_name: str
    received_at_utc: datetime


@dataclass(frozen=True, slots=True)
class DepthSnapshot:
    symbol: str
    last_update_id: int
    bids: tuple[DepthLevel, ...]
    asks: tuple[DepthLevel, ...]
    event_time_ms: int | None = None
    transaction_time_ms: int | None = None


@dataclass(frozen=True, slots=True)
class OrderBookMetrics:
    symbol: str
    update_id: int
    best_bid: Decimal
    best_ask: Decimal
    spread: Decimal
    spread_bps: Decimal
    bid_depth: Decimal
    ask_depth: Decimal
    imbalance: Decimal
    level_count_bid: int
    level_count_ask: int
    synchronized: bool
    last_event_time_ms: int


@dataclass(slots=True)
class OrderBookFeedStats:
    connection_count: int = 0
    reconnect_attempts: int = 0
    messages_received: int = 0
    events_emitted: int = 0
    malformed_messages: int = 0
    stale_messages: int = 0
    queue_overflows: int = 0
    last_error: str | None = None


def _integer(value: Any, name: str) -> int:
    if isinstance(value, bool): raise OrderBookParseError(f"{name} must be an integer")
    try: parsed = int(value)
    except (TypeError, ValueError, OverflowError) as exc: raise OrderBookParseError(f"{name} must be an integer") from exc
    if str(value).strip() not in {str(parsed), f"{parsed}.0"} or parsed < 0:
        raise OrderBookParseError(f"{name} must be a non-negative exact integer")
    return parsed


def _decimal(value: Any, name: str, *, allow_zero: bool = False) -> Decimal:
    try: result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc: raise OrderBookParseError(f"{name} must be Decimal-compatible") from exc
    if not result.is_finite() or result < 0 or (not allow_zero and result == 0):
        raise OrderBookParseError(f"{name} must be finite and {'non-negative' if allow_zero else 'positive'}")
    return result


def normalize_depth_subscriptions(symbols: Iterable[str], *, update_speed: str = "100ms") -> tuple[tuple[str, ...], tuple[str, ...]]:
    if update_speed not in {"100ms", "500ms"}: raise ValueError("update_speed must be '100ms' or '500ms'")
    result: list[str] = []
    for raw in symbols:
        if not isinstance(raw, str): raise ValueError("symbols must contain strings")
        symbol = raw.strip().upper()
        if not _SYMBOL_RE.fullmatch(symbol): raise ValueError(f"Invalid exact contract symbol: {raw!r}")
        if symbol not in result: result.append(symbol)
    if not result: raise ValueError("At least one exact symbol is required")
    return tuple(result), tuple(f"{s.lower()}@depth@{update_speed}" for s in result)


def _parse_levels(rows: Any, name: str, *, max_levels: int = 1000) -> tuple[DepthLevel, ...]:
    if not isinstance(rows, list) or len(rows) > max_levels: raise OrderBookParseError(f"{name} must be a bounded array")
    parsed: list[DepthLevel] = []
    seen: set[Decimal] = set()
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) != 2: raise OrderBookParseError(f"Invalid {name} level")
        price = _decimal(row[0], f"{name}.price")
        quantity = _decimal(row[1], f"{name}.quantity", allow_zero=True)
        if price in seen: raise OrderBookParseError(f"Duplicate {name} price level")
        seen.add(price)
        parsed.append(DepthLevel(price, quantity))
    return tuple(parsed)


def parse_depth_stream_message(message: str | bytes, *, allowed_symbols: Iterable[str] | None = None,
                               received_at_utc: datetime | None = None, now_ms: int | None = None,
                               max_event_age_ms: int | None = None, max_future_skew_ms: int = 5000) -> DepthEvent | None:
    if isinstance(message, bytes):
        try: message = message.decode("utf-8")
        except UnicodeDecodeError as exc: raise OrderBookParseError("Depth message is not UTF-8") from exc
    if not isinstance(message, str) or not message or len(message.encode("utf-8")) > WEBSOCKET_MAX_MESSAGE_BYTES:
        raise OrderBookParseError("Depth message is empty or exceeds the message-size limit")
    try: root = json.loads(message)
    except (json.JSONDecodeError, TypeError) as exc: raise OrderBookParseError("Depth message is invalid JSON") from exc
    if not isinstance(root, dict): raise OrderBookParseError("Depth message root must be an object")
    if "id" in root and "result" in root:
        if root.get("result") is not None: raise OrderBookProtocolError("Unexpected subscription acknowledgement")
        return None
    if "code" in root and "msg" in root: raise OrderBookProtocolError(f"Binance WebSocket error {root.get('code')}: {root.get('msg')}")
    data = root.get("data", root)
    if not isinstance(data, dict) or data.get("e") != "depthUpdate": raise OrderBookParseError("Unexpected depth event type")
    symbol = str(data.get("s", "")).strip().upper()
    if not _SYMBOL_RE.fullmatch(symbol): raise OrderBookParseError("Invalid depth event symbol")
    allowed = None if allowed_symbols is None else {s.upper() for s in allowed_symbols}
    if allowed is not None and symbol not in allowed: raise OrderBookParseError(f"Unsubscribed symbol: {symbol}")
    stream = root.get("stream", f"{symbol.lower()}@depth@100ms")
    if stream not in {f"{symbol.lower()}@depth@100ms", f"{symbol.lower()}@depth@500ms"}:
        raise OrderBookParseError("Combined stream does not match depth event symbol")
    first = _integer(data.get("U"), "U"); final = _integer(data.get("u"), "u")
    if final < first: raise OrderBookParseError("Final update ID precedes first update ID")
    prev = _integer(data["pu"], "pu") if data.get("pu") is not None else None
    event_ms = _integer(data.get("E"), "E")
    transact = _integer(data["T"], "T") if data.get("T") is not None else None
    bids = _parse_levels(data.get("b"), "b"); asks = _parse_levels(data.get("a"), "a")
    now = int(time.time() * 1000) if now_ms is None else now_ms
    if max_event_age_ms is not None and now - event_ms > max_event_age_ms: raise OrderBookStaleEventError("Depth event is stale")
    if event_ms - now > max_future_skew_ms: raise OrderBookStaleEventError("Depth event is too far in the future")
    received = received_at_utc or datetime.now(UTC)
    if received.tzinfo is None: raise OrderBookParseError("received_at_utc must be timezone-aware")
    return DepthEvent(symbol, first, final, prev, event_ms, transact, bids, asks, stream, received.astimezone(UTC))


class BinanceDepthSnapshotClient:
    """Public, paced REST adapter for GET /fapi/v1/depth."""
    def __init__(self, *, base_url: str = "https://fapi.binance.com", limit: int = DEFAULT_DEPTH_LIMIT,
                 min_request_interval_seconds: float = 0.25, http_client: httpx.Client | None = None,
                 sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.monotonic):
        if limit not in VALID_DEPTH_LIMITS: raise ValueError(f"limit must be one of {VALID_DEPTH_LIMITS}")
        if min_request_interval_seconds < 0: raise ValueError("request interval cannot be negative")
        self.endpoint = base_url.rstrip("/") + "/fapi/v1/depth"; self.limit = limit
        self.interval = min_request_interval_seconds; self._sleep = sleep; self._clock = clock
        self._last_request = float("-inf"); self._owns = http_client is None
        self._client = http_client or httpx.Client(timeout=httpx.Timeout(5.0, connect=3.0), follow_redirects=False)
    def close(self) -> None:
        if self._owns: self._client.close()
    def fetch(self, symbol: str) -> DepthSnapshot:
        symbol = symbol.strip().upper()
        if not _SYMBOL_RE.fullmatch(symbol): raise ValueError("symbol must be an exact Binance contract symbol")
        wait = self.interval - (self._clock() - self._last_request)
        if wait > 0: self._sleep(wait)
        self._last_request = self._clock()
        response = self._client.get(self.endpoint, params={"symbol": symbol, "limit": self.limit})
        response.raise_for_status()
        try: payload = response.json()
        except ValueError as exc: raise OrderBookParseError("Invalid REST depth JSON") from exc
        if not isinstance(payload, dict): raise OrderBookParseError("REST depth response must be an object")
        last = _integer(payload.get("lastUpdateId"), "lastUpdateId")
        bids = _parse_levels(payload.get("bids"), "snapshot.bids", max_levels=self.limit)
        asks = _parse_levels(payload.get("asks"), "snapshot.asks", max_levels=self.limit)
        return DepthSnapshot(symbol, last, bids, asks,
            _integer(payload["E"], "E") if payload.get("E") is not None else None,
            _integer(payload["T"], "T") if payload.get("T") is not None else None)


class LocalOrderBook:
    """Per-symbol bounded book. Apply snapshot and each diff atomically."""
    def __init__(self, symbol: str, *, max_levels: int = DEFAULT_BOOK_LEVELS, depth_levels: int = 20,
                 max_event_age_ms: int = DEFAULT_DEPTH_MAX_AGE_MS, wall_clock_ms: Callable[[], int] | None = None):
        symbol = symbol.strip().upper()
        if not _SYMBOL_RE.fullmatch(symbol): raise ValueError("Invalid symbol")
        if not 1 <= max_levels <= 1000 or not 1 <= depth_levels <= max_levels: raise ValueError("Invalid book/depth level bounds")
        if max_event_age_ms < 0: raise ValueError("max_event_age_ms cannot be negative")
        self.symbol=symbol; self.max_levels=max_levels; self.depth_levels=depth_levels; self.max_event_age_ms=max_event_age_ms
        self._now=wall_clock_ms or (lambda: int(time.time()*1000)); self._bids: dict[Decimal,Decimal]={}; self._asks: dict[Decimal,Decimal]={}
        self.update_id: int | None=None; self.last_event_time_ms: int | None=None; self.synchronized=False; self.invalid_reason="NOT_INITIALIZED"
    def invalidate(self, reason: str) -> None:
        self.synchronized=False; self.invalid_reason=reason; self.update_id=None; self.last_event_time_ms=None; self._bids.clear(); self._asks.clear()
    def synchronize(self, snapshot: DepthSnapshot, buffered_events: Iterable[DepthEvent]) -> int:
        if snapshot.symbol != self.symbol: raise OrderBookSequenceError("Snapshot symbol mismatch")
        events = list(buffered_events)
        if len(events) > 10000: raise OrderBookSequenceError("Buffered event budget exceeded")
        if snapshot.event_time_ms is not None:
            snapshot_age = self._now() - snapshot.event_time_ms
            if snapshot_age > self.max_event_age_ms or snapshot_age < -5000:
                self.invalidate("STALE_SNAPSHOT")
                raise OrderBookStaleEventError("REST depth snapshot is stale or future-dated")
        if not events: self.invalidate("WAITING_FOR_BRIDGING_EVENT"); return 0
        # Futures first event must straddle the snapshot update ID; subsequent
        # events are chained by pu == previous u (not Spot's U == previous u + 1).
        candidates = [e for e in events if e.symbol == self.symbol and e.final_update_id >= snapshot.last_update_id]
        if not candidates: self.invalidate("SNAPSHOT_BEHIND_BUFFER"); return 0
        first = candidates[0]
        if not (first.first_update_id <= snapshot.last_update_id <= first.final_update_id):
            self.invalidate("NO_SNAPSHOT_BRIDGE"); return 0
        bids = {x.price:x.quantity for x in snapshot.bids if x.quantity > 0}
        asks = {x.price:x.quantity for x in snapshot.asks if x.quantity > 0}
        if len(bids)>self.max_levels or len(asks)>self.max_levels: raise OrderBookSequenceError("Snapshot exceeds configured book capacity")
        current = snapshot.last_update_id; last_event = 0; bridge_consumed = False
        try:
            self._validate_book(bids, asks)
            for event in candidates:
                age = self._now() - event.event_time_ms
                if age > self.max_event_age_ms or age < -5000:
                    raise OrderBookStaleEventError("Buffered depth event is stale or future-dated")
                if event.final_update_id <= current:
                    if not bridge_consumed:
                        bridge_consumed = True
                        last_event = event.event_time_ms
                    continue
                if bridge_consumed and event.previous_final_update_id != current:
                    raise OrderBookSequenceError(f"pu mismatch: expected {current}, got {event.previous_final_update_id}")
                self._apply_levels(bids, event.bids); self._apply_levels(asks, event.asks)
                current=event.final_update_id; last_event=event.event_time_ms; bridge_consumed=True
                self._validate_book(bids, asks)
        except Exception as exc:
            self.invalidate(str(exc)); raise
        self._bids=self._trim(bids, reverse=True); self._asks=self._trim(asks, reverse=False)
        self.update_id=current; self.last_event_time_ms=last_event or first.event_time_ms; self.synchronized=True; self.invalid_reason=""
        return len(candidates)
    def apply(self, event: DepthEvent) -> None:
        if not self.synchronized or self.update_id is None: raise OrderBookNotReady("Book is not synchronized")
        if event.symbol != self.symbol: self.invalidate("SYMBOL_MISMATCH"); raise OrderBookSequenceError("Event symbol mismatch")
        if self._now()-event.event_time_ms > self.max_event_age_ms: self.invalidate("STALE_EVENT"); raise OrderBookStaleEventError("Depth event is stale")
        if event.final_update_id <= self.update_id: return
        if event.previous_final_update_id is None or event.previous_final_update_id != self.update_id:
            self.invalidate("SEQUENCE_GAP"); raise OrderBookSequenceError("Depth pu does not match previous final update ID")
        bids=dict(self._bids); asks=dict(self._asks)
        try:
            self._apply_levels(bids,event.bids); self._apply_levels(asks,event.asks); self._validate_book(bids,asks)
            self._bids=self._trim(bids,reverse=True); self._asks=self._trim(asks,reverse=False)
            self.update_id=event.final_update_id; self.last_event_time_ms=event.event_time_ms
        except Exception as exc:
            self.invalidate(str(exc)); raise
    @staticmethod
    def _apply_levels(book: dict[Decimal,Decimal], levels: tuple[DepthLevel,...]) -> None:
        for level in levels:
            if level.quantity == 0: book.pop(level.price,None)
            else: book[level.price]=level.quantity
    def _trim(self, book: dict[Decimal,Decimal], *, reverse: bool) -> dict[Decimal,Decimal]:
        prices=sorted(book, reverse=reverse)[:self.max_levels]
        return {p:book[p] for p in prices}
    @staticmethod
    def _validate_book(bids: dict[Decimal,Decimal], asks: dict[Decimal,Decimal]) -> None:
        if not bids or not asks: raise OrderBookSequenceError("Local book has an empty side")
        if max(bids) >= min(asks): raise OrderBookSequenceError("Local book is crossed or locked")
        if any(q<=0 for q in (*bids.values(),*asks.values())): raise OrderBookSequenceError("Local book contains non-positive quantity")
    def metrics(self) -> OrderBookMetrics:
        if not self.synchronized or self.update_id is None or self.last_event_time_ms is None: raise OrderBookNotReady(f"Book is not healthy: {self.invalid_reason}")
        if self._now()-self.last_event_time_ms > self.max_event_age_ms: self.invalidate("STALE_BOOK"); raise OrderBookNotReady("Book metrics are stale")
        bids=sorted(self._bids.items(),reverse=True)[:self.depth_levels]; asks=sorted(self._asks.items())[:self.depth_levels]
        if not bids or not asks: self.invalidate("EMPTY_METRIC_DEPTH"); raise OrderBookNotReady("No depth levels available")
        bid=sum((q for _,q in bids),Decimal(0)); ask=sum((q for _,q in asks),Decimal(0)); total=bid+ask
        best_bid=bids[0][0]; best_ask=asks[0][0]; spread=best_ask-best_bid
        mid=(best_ask+best_bid)/Decimal(2)
        return OrderBookMetrics(self.symbol,self.update_id,best_bid,best_ask,spread,(spread/mid)*Decimal(10000),bid,ask,(bid-ask)/total,len(bids),len(asks),True,self.last_event_time_ms)


class BinanceDepthWebSocketFeed:
    """Exact-symbol, bounded USDⓈ-M diff-depth WebSocket feed."""

    def __init__(
        self, *, symbols: Iterable[str], update_speed: str = "100ms",
        endpoint: str = BINANCE_UM_DEPTH_WS_ENDPOINT,
        queue_capacity: int = DEFAULT_DEPTH_QUEUE_CAPACITY,
        max_subscriptions: int = DEFAULT_DEPTH_MAX_SUBSCRIPTIONS,
        max_event_age_ms: int = DEFAULT_DEPTH_MAX_AGE_MS,
        max_reconnect_attempts: int = 5,
        connector: Callable[..., Any] | None = None,
        wall_clock_ms: Callable[[], int] | None = None,
    ):
        syms, streams = normalize_depth_subscriptions(symbols, update_speed=update_speed)
        if not isinstance(endpoint, str) or not endpoint.startswith("wss://"):
            raise ValueError("endpoint must use wss://")
        if isinstance(max_subscriptions, bool) or not 1 <= max_subscriptions <= HARD_MAX_DEPTH_SUBSCRIPTIONS:
            raise ValueError("Invalid maximum depth subscriptions")
        if len(syms) > max_subscriptions:
            raise ValueError("Depth subscription cap exceeded")
        if isinstance(queue_capacity, bool) or not 1 <= queue_capacity <= HARD_MAX_DEPTH_QUEUE_CAPACITY:
            raise ValueError("Invalid depth queue capacity")
        if isinstance(max_event_age_ms, bool) or not isinstance(max_event_age_ms, int) or max_event_age_ms < 0:
            raise ValueError("max_event_age_ms must be a non-negative integer")
        if isinstance(max_reconnect_attempts, bool) or not 0 <= max_reconnect_attempts <= 20:
            raise ValueError("Invalid reconnect budget")
        self.symbols = syms
        self.stream_names = streams
        self.endpoint = endpoint
        self.max_event_age_ms = max_event_age_ms
        self.events: asyncio.Queue[DepthEvent] = asyncio.Queue(maxsize=queue_capacity)
        self.stats = OrderBookFeedStats()
        self._connector = connector or websocket_connect
        self._now = wall_clock_ms or (lambda: int(time.time() * 1000))
        self.max_reconnect_attempts = max_reconnect_attempts
        self._request_id = 1
        self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected

    def subscription_request(self) -> dict[str, Any]:
        return {"method": "SUBSCRIBE", "params": list(self.stream_names), "id": self._request_id}

    async def get_event(self) -> DepthEvent:
        return await self.events.get()

    async def run(self, stop_event: asyncio.Event) -> None:
        retries = 0
        while not stop_event.is_set():
            try:
                async with self._connector(
                    self.endpoint, open_timeout=10, ping_interval=20, ping_timeout=20,
                    close_timeout=5, max_size=WEBSOCKET_MAX_MESSAGE_BYTES,
                    max_queue=WEBSOCKET_MAX_FRAME_QUEUE, compression=None,
                ) as ws:
                    self._connected = True
                    self.stats.connection_count += 1
                    try:
                        await ws.send(json.dumps(self.subscription_request(), separators=(",", ":")))
                        self._request_id += 1
                        while not stop_event.is_set():
                            try:
                                msg = await asyncio.wait_for(ws.recv(), timeout=0.5)
                            except TimeoutError:
                                continue
                            self.stats.messages_received += 1
                            try:
                                event = parse_depth_stream_message(
                                    msg, allowed_symbols=self.symbols, now_ms=self._now(),
                                    max_event_age_ms=self.max_event_age_ms,
                                )
                            except OrderBookStaleEventError:
                                self.stats.stale_messages += 1
                                continue
                            except OrderBookParseError:
                                self.stats.malformed_messages += 1
                                continue
                            if event is None:
                                continue
                            try:
                                self.events.put_nowait(event)
                            except asyncio.QueueFull as exc:
                                self.stats.queue_overflows += 1
                                raise OrderBookQueueFullError(
                                    "Depth queue overflow; book must be invalidated and resynchronized"
                                ) from exc
                            self.stats.events_emitted += 1
                    finally:
                        self._connected = False
                if stop_event.is_set():
                    return
                raise ConnectionError("Depth WebSocket closed")
            except OrderBookQueueFullError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._connected = False
                self.stats.last_error = f"{type(exc).__name__}: {exc}"
                if stop_event.is_set():
                    return
                if retries >= self.max_reconnect_attempts:
                    raise OrderBookError("Depth WebSocket reconnect budget exhausted") from exc
                retries += 1
                self.stats.reconnect_attempts += 1
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=min(2 ** (retries - 1), 15))
                except TimeoutError:
                    pass
