"""Read-only alignment of aggressive trade flow and supervised displayed depth.

The detector emits evidence candidates only. Public depth cannot establish hidden
liquidity, participant intent, spoofing, or a guaranteed reversal.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Deque

from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot

ZERO = Decimal("0")
ONE = Decimal("1")
BPS = Decimal("10000")
HARD_MAX_SYMBOLS = 32
HARD_MAX_SAMPLES_PER_SYMBOL = 120


class AbsorptionError(RuntimeError):
    """Base error for flow/depth evidence alignment."""


class AbsorptionInputError(AbsorptionError):
    """Raised when caller-supplied identities or timestamps are invalid."""


@dataclass(frozen=True, slots=True)
class AbsorptionConfig:
    window_ms: int = 5_000
    min_window_ms: int = 3_000
    max_sample_gap_ms: int = 2_000
    max_input_skew_ms: int = 3_000
    max_flow_age_ms: int = 10_000
    max_depth_age_ms: int = 3_000
    min_net_aggression_quote: Decimal = Decimal("1000")
    max_price_progress_bps: Decimal = Decimal("2")
    min_opposing_depth_ratio: Decimal = Decimal("0.80")
    max_samples_per_symbol: int = 120
    max_symbols: int = 32

    def __post_init__(self) -> None:
        for name in ("window_ms", "min_window_ms", "max_sample_gap_ms", "max_input_skew_ms",
                     "max_flow_age_ms", "max_depth_age_ms", "max_samples_per_symbol", "max_symbols"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.max_symbols > HARD_MAX_SYMBOLS:
            raise ValueError(f"max_symbols cannot exceed {HARD_MAX_SYMBOLS}")
        if self.max_samples_per_symbol > HARD_MAX_SAMPLES_PER_SYMBOL:
            raise ValueError(f"max_samples_per_symbol cannot exceed {HARD_MAX_SAMPLES_PER_SYMBOL}")
        if self.min_window_ms > self.window_ms:
            raise ValueError("min_window_ms cannot exceed window_ms")
        if self.max_sample_gap_ms > self.window_ms:
            raise ValueError("max_sample_gap_ms cannot exceed window_ms")
        for name in ("min_net_aggression_quote", "max_price_progress_bps", "min_opposing_depth_ratio"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value < ZERO:
                raise ValueError(f"{name} must be a finite non-negative Decimal")
        if self.min_net_aggression_quote <= ZERO:
            raise ValueError("min_net_aggression_quote must be greater than zero")
        if self.min_opposing_depth_ratio > ONE:
            raise ValueError("min_opposing_depth_ratio cannot exceed 1")


@dataclass(frozen=True, slots=True)
class AbsorptionEvidence:
    symbol: str
    status: str  # UNAVAILABLE, WARMING_UP, NO_CANDIDATE, CANDIDATE
    absorbed_aggressor: str | None  # BUY or SELL aggression
    reason_codes: tuple[str, ...]
    window_start_ms: int | None
    window_end_ms: int | None
    sample_count: int
    window_duration_ms: int
    aggressive_buy_quote: Decimal
    aggressive_sell_quote: Decimal
    latest_delta_quote: Decimal
    cvd_change_quote: Decimal
    price_progress_bps: Decimal | None
    start_mid: Decimal | None
    end_mid: Decimal | None
    start_opposing_depth: Decimal | None
    min_opposing_depth: Decimal | None
    end_opposing_depth: Decimal | None
    opposing_depth_min_ratio: Decimal | None
    opposing_depth_end_ratio: Decimal | None
    start_imbalance: Decimal | None
    end_imbalance: Decimal | None
    start_best_bid: Decimal | None
    end_best_bid: Decimal | None
    start_best_ask: Decimal | None
    end_best_ask: Decimal | None
    source_update_id: int | None


@dataclass(frozen=True, slots=True)
class _Sample:
    observed_at_ms: int
    flow_trade_time_ms: int
    flow_cursor_id: int
    depth_event_time_ms: int
    buy_quote: Decimal
    sell_quote: Decimal
    delta_quote: Decimal
    cvd_quote: Decimal
    best_bid: Decimal
    best_ask: Decimal
    bid_depth: Decimal
    ask_depth: Decimal
    imbalance: Decimal
    update_id: int

    @property
    def mid(self) -> Decimal:
        return (self.best_bid + self.best_ask) / Decimal("2")


@dataclass(slots=True)
class _SymbolWindow:
    samples: Deque[_Sample] = field(default_factory=deque)
    invalid_reason: str | None = None


class DepthAggressorAlignmentService:
    """Align fresh Delta/CVD and READY order-book samples into bounded windows.

    Call ``observe`` on a serialized market-data worker. Call ``reset_symbol``
    whenever the aggregate-trade feed reconnects or its continuity is reset.
    The service intentionally does not persist depth or alter strategy signals.
    """

    def __init__(self, *, config: AbsorptionConfig | None = None) -> None:
        self.config = config or AbsorptionConfig()
        self._windows: dict[str, _SymbolWindow] = {}

    @property
    def symbols(self) -> tuple[str, ...]:
        return tuple(self._windows)

    def reset_symbol(self, symbol: str, reason: str = "SOURCE_CONTINUITY_RESET") -> None:
        key = self._symbol(symbol)
        state = self._window_for(key)
        state.samples.clear()
        state.invalid_reason = reason

    def observe(
        self,
        *,
        symbol: str,
        flow: OrderFlowSnapshot,
        book_health: OrderBookSymbolHealth,
        book: OrderBookMetrics,
        observed_at_ms: int,
    ) -> AbsorptionEvidence:
        key = self._symbol(symbol)
        if isinstance(observed_at_ms, bool) or not isinstance(observed_at_ms, int) or observed_at_ms < 0:
            raise AbsorptionInputError("observed_at_ms must be a non-negative integer")
        state = self._window_for(key)
        reasons = self._validate_inputs(key, flow, book_health, book, observed_at_ms)
        if reasons:
            state.samples.clear()
            state.invalid_reason = ";".join(reasons)
            return self._unavailable(key, reasons)

        assert flow.last_trade_time_ms is not None
        flow_time = flow.last_trade_time_ms
        depth_time = book.last_event_time_ms
        if abs(flow_time - depth_time) > self.config.max_input_skew_ms:
            state.samples.clear()
            state.invalid_reason = "SOURCE_TIMESTAMP_SKEW"
            return self._unavailable(key, ("SOURCE_TIMESTAMP_SKEW",))

        sample = _Sample(
            observed_at_ms=observed_at_ms,
            flow_trade_time_ms=flow_time,
            flow_cursor_id=flow.last_processed_aggregate_trade_id,
            depth_event_time_ms=depth_time,
            buy_quote=flow.buy_volume_quote,
            sell_quote=flow.sell_volume_quote,
            delta_quote=flow.delta_quote,
            cvd_quote=flow.cvd_quote,
            best_bid=book.best_bid,
            best_ask=book.best_ask,
            bid_depth=book.bid_depth,
            ask_depth=book.ask_depth,
            imbalance=book.imbalance,
            update_id=book.update_id,
        )
        if state.samples:
            previous = state.samples[-1]
            if observed_at_ms <= previous.observed_at_ms:
                state.samples.clear()
                state.invalid_reason = "CLOCK_REGRESSION_OR_DUPLICATE_SAMPLE"
                return self._unavailable(key, ("CLOCK_REGRESSION_OR_DUPLICATE_SAMPLE",))
            if observed_at_ms - previous.observed_at_ms > self.config.max_sample_gap_ms:
                state.samples.clear()
                state.invalid_reason = "SAMPLE_GAP_RESET"
            if flow_time < previous.flow_trade_time_ms or depth_time < previous.depth_event_time_ms:
                state.samples.clear()
                state.invalid_reason = "SOURCE_TIMESTAMP_REGRESSION"
                return self._unavailable(key, ("SOURCE_TIMESTAMP_REGRESSION",))
            if flow.last_processed_aggregate_trade_id < previous.flow_cursor_id:
                state.samples.clear()
                state.invalid_reason = "AGGREGATE_TRADE_CURSOR_REGRESSION"
                return self._unavailable(key, ("AGGREGATE_TRADE_CURSOR_REGRESSION",))
            if book.update_id < previous.update_id:
                state.samples.clear()
                state.invalid_reason = "DEPTH_UPDATE_ID_REGRESSION"
                return self._unavailable(key, ("DEPTH_UPDATE_ID_REGRESSION",))

        state.samples.append(sample)
        cutoff = observed_at_ms - self.config.window_ms
        while state.samples and state.samples[0].observed_at_ms < cutoff:
            state.samples.popleft()
        while len(state.samples) > self.config.max_samples_per_symbol:
            state.samples.popleft()
        state.invalid_reason = None
        return self._assess(key, state.samples)

    def _window_for(self, symbol: str) -> _SymbolWindow:
        state = self._windows.get(symbol)
        if state is not None:
            return state
        if len(self._windows) >= self.config.max_symbols:
            raise AbsorptionInputError("configured symbol window capacity exceeded")
        state = _SymbolWindow()
        self._windows[symbol] = state
        return state

    def _validate_inputs(self, symbol: str, flow: OrderFlowSnapshot,
                         health: OrderBookSymbolHealth, book: OrderBookMetrics,
                         now_ms: int) -> tuple[str, ...]:
        reasons: list[str] = []
        if flow.symbol != symbol or health.symbol != symbol or book.symbol != symbol:
            raise AbsorptionInputError("symbol mismatch between requested symbol and source snapshots")
        if flow.status != "HEALTHY" or not flow.continuity_valid:
            reasons.append("DELTA_CVD_CONTINUITY_INVALID")
        if not flow.is_fresh or flow.last_trade_time_ms is None:
            reasons.append("DELTA_CVD_NOT_FRESH")
        elif not -5_000 <= now_ms - flow.last_trade_time_ms <= self.config.max_flow_age_ms:
            reasons.append("DELTA_CVD_AGE_OUT_OF_RANGE")
        if not health.ready or not health.sequence_integrity or not health.event_fresh or not health.queue_healthy:
            reasons.append("ORDER_BOOK_NOT_READY")
        if not book.synchronized:
            reasons.append("ORDER_BOOK_NOT_SYNCHRONIZED")
        if health.update_id != book.update_id:
            reasons.append("ORDER_BOOK_HEALTH_METRICS_MISMATCH")
        if not -5_000 <= now_ms - book.last_event_time_ms <= self.config.max_depth_age_ms:
            reasons.append("ORDER_BOOK_AGE_OUT_OF_RANGE")
        if flow.trade_count <= 0:
            reasons.append("NO_AGGRESSOR_TRADES_IN_FLOW_WINDOW")
        if book.bid_depth <= ZERO or book.ask_depth <= ZERO or book.best_bid >= book.best_ask:
            reasons.append("INVALID_DISPLAYED_BOOK_METRICS")
        if flow.cvd_quote.is_finite() is False or flow.delta_quote.is_finite() is False:
            reasons.append("NON_FINITE_FLOW_METRIC")
        return tuple(reasons)

    def _assess(self, symbol: str, samples: Deque[_Sample]) -> AbsorptionEvidence:
        if len(samples) < 2:
            return self._warming(symbol, samples)
        first, last = samples[0], samples[-1]
        duration = last.observed_at_ms - first.observed_at_ms
        if duration < self.config.min_window_ms:
            return self._warming(symbol, samples)

        cvd_change = last.cvd_quote - first.cvd_quote
        # The latest flow bucket is retained as a second, independent direction check.
        latest_delta = last.delta_quote
        if cvd_change > ZERO and latest_delta > ZERO:
            side = "BUY"
            opposing_start, opposing_values = first.ask_depth, [s.ask_depth for s in samples]
            aggression_ok = cvd_change >= self.config.min_net_aggression_quote
        elif cvd_change < ZERO and latest_delta < ZERO:
            side = "SELL"
            opposing_start, opposing_values = first.bid_depth, [s.bid_depth for s in samples]
            aggression_ok = -cvd_change >= self.config.min_net_aggression_quote
        else:
            return self._no_candidate(symbol, samples, "AGGRESSOR_FLOW_NOT_DIRECTIONALLY_ALIGNED",
                                      cvd_change=cvd_change, latest_delta=latest_delta)

        signed_progress = ((last.mid - first.mid) / first.mid) * BPS
        directional_progress = signed_progress if side == "BUY" else -signed_progress
        min_depth = min(opposing_values)
        min_ratio = min_depth / opposing_start if opposing_start else ZERO
        end_depth = opposing_values[-1]
        end_ratio = end_depth / opposing_start if opposing_start else ZERO
        depth_persisted = min_ratio >= self.config.min_opposing_depth_ratio
        depth_replenished = min_ratio < self.config.min_opposing_depth_ratio and end_ratio >= ONE
        reasons: list[str] = []
        if not aggression_ok:
            reasons.append("NET_AGGRESSION_BELOW_THRESHOLD")
        if directional_progress > self.config.max_price_progress_bps:
            reasons.append("PRICE_PROGRESS_EXCEEDS_ABSORPTION_LIMIT")
        if not (depth_persisted or depth_replenished):
            reasons.append("OPPOSING_DISPLAYED_DEPTH_NOT_PERSISTENT")
        status = "CANDIDATE" if not reasons else "NO_CANDIDATE"
        reasons.insert(0, "BUY_AGGRESSION_AT_ASK" if side == "BUY" else "SELL_AGGRESSION_AT_BID")
        return AbsorptionEvidence(
            symbol=symbol, status=status, absorbed_aggressor=side, reason_codes=tuple(reasons),
            window_start_ms=first.observed_at_ms, window_end_ms=last.observed_at_ms,
            sample_count=len(samples), window_duration_ms=duration,
            aggressive_buy_quote=last.buy_quote, aggressive_sell_quote=last.sell_quote,
            latest_delta_quote=latest_delta, cvd_change_quote=cvd_change,
            price_progress_bps=directional_progress, start_mid=first.mid, end_mid=last.mid,
            start_opposing_depth=opposing_start, min_opposing_depth=min_depth,
            end_opposing_depth=end_depth, opposing_depth_min_ratio=min_ratio,
            opposing_depth_end_ratio=end_ratio, start_imbalance=first.imbalance,
            end_imbalance=last.imbalance, start_best_bid=first.best_bid,
            end_best_bid=last.best_bid, start_best_ask=first.best_ask,
            end_best_ask=last.best_ask, source_update_id=last.update_id,
        )

    def _warming(self, symbol: str, samples: Deque[_Sample]) -> AbsorptionEvidence:
        return AbsorptionEvidence(
            symbol, "WARMING_UP", None, ("INSUFFICIENT_WINDOW_SAMPLES",),
            samples[0].observed_at_ms if samples else None,
            samples[-1].observed_at_ms if samples else None, len(samples),
            samples[-1].observed_at_ms - samples[0].observed_at_ms if len(samples) > 1 else 0,
            samples[-1].buy_quote if samples else ZERO,
            samples[-1].sell_quote if samples else ZERO,
            samples[-1].delta_quote if samples else ZERO,
            samples[-1].cvd_quote - samples[0].cvd_quote if len(samples) > 1 else ZERO,
            None, samples[0].mid if samples else None, samples[-1].mid if samples else None,
            None, None, None, None, None,
            samples[0].imbalance if samples else None,
            samples[-1].imbalance if samples else None,
            samples[0].best_bid if samples else None,
            samples[-1].best_bid if samples else None,
            samples[0].best_ask if samples else None,
            samples[-1].best_ask if samples else None,
            samples[-1].update_id if samples else None,
        )

    def _unavailable(self, symbol: str, reasons: tuple[str, ...]) -> AbsorptionEvidence:
        return AbsorptionEvidence(
            symbol=symbol, status="UNAVAILABLE", absorbed_aggressor=None,
            reason_codes=reasons, window_start_ms=None, window_end_ms=None,
            sample_count=0, window_duration_ms=0, aggressive_buy_quote=ZERO,
            aggressive_sell_quote=ZERO, latest_delta_quote=ZERO, cvd_change_quote=ZERO,
            price_progress_bps=None, start_mid=None, end_mid=None,
            start_opposing_depth=None, min_opposing_depth=None, end_opposing_depth=None,
            opposing_depth_min_ratio=None, opposing_depth_end_ratio=None,
            start_imbalance=None, end_imbalance=None, start_best_bid=None,
            end_best_bid=None, start_best_ask=None, end_best_ask=None,
            source_update_id=None,
        )

    def _no_candidate(self, symbol: str, samples: Deque[_Sample], reason: str,
                      *, cvd_change: Decimal, latest_delta: Decimal) -> AbsorptionEvidence:
        first, last = samples[0], samples[-1]
        return AbsorptionEvidence(
            symbol, "NO_CANDIDATE", None, (reason,), first.observed_at_ms,
            last.observed_at_ms, len(samples), last.observed_at_ms-first.observed_at_ms,
            last.buy_quote, last.sell_quote, latest_delta, cvd_change, None,
            first.mid, last.mid, None, None, None, None, None,
            first.imbalance, last.imbalance, first.best_bid, last.best_bid,
            first.best_ask, last.best_ask, last.update_id,
        )

    @staticmethod
    def _symbol(symbol: str) -> str:
        if not isinstance(symbol, str):
            raise AbsorptionInputError("symbol must be a string")
        key = symbol.strip().upper()
        if not key or not key.isalnum():
            raise AbsorptionInputError("symbol must be an exact alphanumeric contract symbol")
        return key


__all__ = [
    "AbsorptionConfig", "AbsorptionError", "AbsorptionEvidence", "AbsorptionInputError",
    "DepthAggressorAlignmentService",
]
