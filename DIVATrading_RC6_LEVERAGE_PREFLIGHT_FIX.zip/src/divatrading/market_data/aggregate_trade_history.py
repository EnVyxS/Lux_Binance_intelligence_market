"""Bounded Binance USDⓈ-M Aggregate Trade REST history and normalization."""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Callable

from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.market_data.aggregate_trades import AggregateTradeEvent

BINANCE_UM_AGG_TRADES_REST_ENDPOINT = "https://fapi.binance.com/fapi/v1/aggTrades"
MAX_AGG_TRADE_REST_PAGE_SIZE = 1000
DEFAULT_AGG_TRADE_REST_PAGE_SIZE = 1000
MAX_AGG_TRADE_REST_PAGES_PER_PASS = 3
BINANCE_AGG_TRADE_HISTORY_WINDOW_MS = 48 * 60 * 60 * 1000


class AggregateTradeHistoryError(RuntimeError):
    """Base class for Aggregate Trade REST history failures."""


class AggregateTradeHistoryParseError(AggregateTradeHistoryError):
    """Raised when a REST aggregate trade row is malformed."""


class AggregateTradeHistoryContinuityError(AggregateTradeHistoryError):
    """Raised when a REST response is unordered or violates its requested ID range."""


class AggregateTradeHistoryUnavailable(AggregateTradeHistoryError):
    """Raised when the exchange cannot supply an ID range needed for continuity."""


def _integer(value: Any, field: str) -> int:
    if isinstance(value, bool):
        raise AggregateTradeHistoryParseError(f"{field} must be an integer")
    try:
        result = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise AggregateTradeHistoryParseError(f"{field} must be an integer") from exc
    if str(value).strip() != str(result):
        raise AggregateTradeHistoryParseError(f"{field} must be an exact integer")
    if result < 0:
        raise AggregateTradeHistoryParseError(f"{field} cannot be negative")
    return result


def _decimal(value: Any, field: str, *, positive: bool) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise AggregateTradeHistoryParseError(f"{field} must be a valid decimal") from exc
    if not result.is_finite() or (positive and result <= 0) or (not positive and result < 0):
        rule = "positive and finite" if positive else "non-negative and finite"
        raise AggregateTradeHistoryParseError(f"{field} must be {rule}")
    return result


@dataclass(frozen=True, slots=True)
class AggregateTradeRecord:
    """Source-neutral persisted aggregate trade; REST event time is unavailable."""

    exchange: str
    symbol: str
    aggregate_trade_id: int
    price: Decimal
    quantity: Decimal
    normal_quantity: Decimal | None
    first_trade_id: int
    last_trade_id: int
    event_time_ms: int | None
    trade_time_ms: int
    buyer_is_maker: bool
    source_kind: str
    source_endpoint: str
    received_at_utc: str

    @property
    def aggressor_side(self) -> str:
        return "SELL" if self.buyer_is_maker else "BUY"

    @property
    def quote_quantity(self) -> Decimal:
        return self.price * self.quantity

    @property
    def signed_quantity(self) -> Decimal:
        return -self.quantity if self.buyer_is_maker else self.quantity

    @property
    def signed_quote_quantity(self) -> Decimal:
        return self.price * self.signed_quantity

    @classmethod
    def from_websocket(cls, event: AggregateTradeEvent) -> "AggregateTradeRecord":
        if not isinstance(event, AggregateTradeEvent):
            raise TypeError("event must be an AggregateTradeEvent")
        return cls(
            exchange="BINANCE_UM",
            symbol=event.symbol,
            aggregate_trade_id=event.aggregate_trade_id,
            price=event.price,
            quantity=event.quantity,
            normal_quantity=None,
            first_trade_id=event.first_trade_id,
            last_trade_id=event.last_trade_id,
            event_time_ms=event.event_time_ms,
            trade_time_ms=event.trade_time_ms,
            buyer_is_maker=event.buyer_is_maker,
            source_kind="WEBSOCKET",
            source_endpoint=event.source_endpoint,
            received_at_utc=event.received_at_utc.astimezone(UTC).isoformat(
                timespec="milliseconds"
            ).replace("+00:00", "Z"),
        )


def parse_aggregate_trade_rest_row(
    payload: dict[str, Any],
    *,
    symbol: str,
    source_endpoint: str = BINANCE_UM_AGG_TRADES_REST_ENDPOINT,
    received_at_utc: datetime | None = None,
) -> AggregateTradeRecord:
    """Normalize one `/fapi/v1/aggTrades` REST row without binary floats."""
    if not isinstance(payload, dict):
        raise AggregateTradeHistoryParseError("REST aggregate trade row must be an object")
    required = {"a", "p", "q", "f", "l", "T", "m"}
    missing = required.difference(payload)
    if missing:
        raise AggregateTradeHistoryParseError(
            f"REST aggregate trade row is missing fields: {', '.join(sorted(missing))}"
        )
    aggregate_id = _integer(payload["a"], "aggregate_trade_id")
    first_id = _integer(payload["f"], "first_trade_id")
    last_id = _integer(payload["l"], "last_trade_id")
    trade_time = _integer(payload["T"], "trade_time_ms")
    if trade_time <= 0:
        raise AggregateTradeHistoryParseError("trade_time_ms must be positive")
    if last_id < first_id:
        raise AggregateTradeHistoryParseError("last_trade_id cannot be lower than first_trade_id")
    if not isinstance(payload["m"], bool):
        raise AggregateTradeHistoryParseError("buyer_is_maker ('m') must be boolean")
    price = _decimal(payload["p"], "price", positive=True)
    quantity = _decimal(payload["q"], "quantity", positive=True)
    normal_quantity = None
    if payload.get("nq") is not None:
        normal_quantity = _decimal(payload["nq"], "normal_quantity", positive=False)
        if normal_quantity > quantity:
            raise AggregateTradeHistoryParseError("normal_quantity cannot exceed total quantity")

    received = received_at_utc or datetime.now(UTC)
    if received.tzinfo is None or received.utcoffset() is None:
        raise AggregateTradeHistoryParseError("received_at_utc must be timezone-aware")
    normalized_symbol = symbol.strip().upper() if isinstance(symbol, str) else ""
    if not normalized_symbol or not normalized_symbol.isalnum():
        raise AggregateTradeHistoryParseError("symbol must be an exact Binance contract symbol")
    return AggregateTradeRecord(
        exchange="BINANCE_UM",
        symbol=normalized_symbol,
        aggregate_trade_id=aggregate_id,
        price=price,
        quantity=quantity,
        normal_quantity=normal_quantity,
        first_trade_id=first_id,
        last_trade_id=last_id,
        event_time_ms=None,
        trade_time_ms=trade_time,
        buyer_is_maker=payload["m"],
        source_kind="REST",
        source_endpoint=source_endpoint,
        received_at_utc=received.astimezone(UTC).isoformat(timespec="milliseconds").replace(
            "+00:00", "Z"
        ),
    )


@dataclass(frozen=True, slots=True)
class AggregateTradeHistoryBatch:
    symbol: str
    requested_from_id: int | None
    requested_through_id: int | None
    records: tuple[AggregateTradeRecord, ...]
    pages_fetched: int
    complete: bool
    next_from_id: int | None
    missing_id: int | None
    source_endpoint: str


class BinanceAggregateTradeHistoryService:
    """Fetch bounded ID-ordered pages using the public USDⓈ-M aggTrades endpoint."""

    def __init__(
        self,
        client: BinanceUsdMFuturesRestClient,
        *,
        page_limit: int = DEFAULT_AGG_TRADE_REST_PAGE_SIZE,
        max_pages_per_pass: int = MAX_AGG_TRADE_REST_PAGES_PER_PASS,
        page_pause_seconds: float = 0.2,
        sleep: Callable[[float], None] = time.sleep,
        now: Callable[[], datetime] = lambda: datetime.now(UTC),
    ) -> None:
        if not 1 <= page_limit <= MAX_AGG_TRADE_REST_PAGE_SIZE:
            raise ValueError(f"page_limit must be between 1 and {MAX_AGG_TRADE_REST_PAGE_SIZE}")
        if not 1 <= max_pages_per_pass <= 20:
            raise ValueError("max_pages_per_pass must be between 1 and 20")
        if page_pause_seconds < 0:
            raise ValueError("page_pause_seconds cannot be negative")
        self.client = client
        self.page_limit = page_limit
        self.max_pages_per_pass = max_pages_per_pass
        self.page_pause_seconds = page_pause_seconds
        self._sleep = sleep
        self._now = now
        self.source_endpoint = client.aggregate_trades_endpoint

    @staticmethod
    def _validate_symbol(symbol: str) -> str:
        value = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not value or not value.isalnum():
            raise ValueError("symbol must be a non-empty exact Binance contract symbol")
        return value

    def fetch_latest(self, *, symbol: str, limit: int | None = None) -> AggregateTradeHistoryBatch:
        """Fetch the latest bounded page to establish an explicit new local baseline."""
        normalized = self._validate_symbol(symbol)
        page_limit = self.page_limit if limit is None else limit
        if isinstance(page_limit, bool) or not isinstance(page_limit, int) or not 1 <= page_limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        payload = self.client.get_aggregate_trades(symbol=normalized, limit=page_limit)
        records = tuple(
            parse_aggregate_trade_rest_row(
                row,
                symbol=normalized,
                source_endpoint=self.source_endpoint,
                received_at_utc=self._now(),
            )
            for row in payload
        )
        self._validate_ordered(records, expected_from_id=None)
        return AggregateTradeHistoryBatch(
            symbol=normalized,
            requested_from_id=None,
            requested_through_id=None,
            records=records,
            pages_fetched=1,
            complete=bool(records),
            next_from_id=(records[-1].aggregate_trade_id + 1) if records else None,
            missing_id=None,
            source_endpoint=self.source_endpoint,
        )

    def fetch_range(
        self,
        *,
        symbol: str,
        from_id: int,
        through_id: int,
        max_pages: int | None = None,
    ) -> AggregateTradeHistoryBatch:
        """Fetch a closed inclusive aggregate-ID range with cursor-safe pagination."""
        normalized = self._validate_symbol(symbol)
        if any(isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in (from_id, through_id)):
            raise ValueError("from_id and through_id must be non-negative integers")
        if through_id < from_id:
            raise ValueError("through_id cannot be lower than from_id")
        page_cap = self.max_pages_per_pass if max_pages is None else max_pages
        if isinstance(page_cap, bool) or not isinstance(page_cap, int) or not 1 <= page_cap <= 20:
            raise ValueError("max_pages must be between 1 and 20")

        records: list[AggregateTradeRecord] = []
        cursor = from_id
        pages = 0
        missing_id: int | None = None
        complete = False
        while pages < page_cap and cursor <= through_id:
            if pages and self.page_pause_seconds:
                self._sleep(self.page_pause_seconds)
            payload = self.client.get_aggregate_trades(
                symbol=normalized, from_id=cursor, limit=self.page_limit
            )
            pages += 1
            page_records = tuple(
                parse_aggregate_trade_rest_row(
                    row,
                    symbol=normalized,
                    source_endpoint=self.source_endpoint,
                    received_at_utc=self._now(),
                )
                for row in payload
            )
            if not page_records:
                missing_id = cursor
                break
            expected = cursor
            for record in page_records:
                trade_id = record.aggregate_trade_id
                if trade_id < expected:
                    raise AggregateTradeHistoryContinuityError(
                        f"REST response returned duplicate/out-of-order ID {trade_id}; expected {expected}"
                    )
                if trade_id > through_id:
                    complete = expected > through_id
                    break
                if trade_id != expected:
                    missing_id = expected
                    break
                records.append(record)
                expected += 1
            if missing_id is not None:
                cursor = missing_id
                break
            if expected > through_id:
                cursor = expected
                complete = True
                break
            cursor = expected
            if len(page_records) < self.page_limit:
                missing_id = cursor
                break

        next_id = None if complete else cursor
        return AggregateTradeHistoryBatch(
            symbol=normalized,
            requested_from_id=from_id,
            requested_through_id=through_id,
            records=tuple(records),
            pages_fetched=pages,
            complete=complete,
            next_from_id=next_id,
            missing_id=missing_id,
            source_endpoint=self.source_endpoint,
        )

    @staticmethod
    def _validate_ordered(
        records: tuple[AggregateTradeRecord, ...], *, expected_from_id: int | None
    ) -> None:
        previous: int | None = None
        for record in records:
            current = record.aggregate_trade_id
            if previous is not None and current != previous + 1:
                raise AggregateTradeHistoryContinuityError(
                    f"Latest REST page is not ID-contiguous: {previous} -> {current}"
                )
            if previous is None and expected_from_id is not None and current != expected_from_id:
                raise AggregateTradeHistoryContinuityError(
                    f"REST page began at {current}; expected {expected_from_id}"
                )
            previous = current
