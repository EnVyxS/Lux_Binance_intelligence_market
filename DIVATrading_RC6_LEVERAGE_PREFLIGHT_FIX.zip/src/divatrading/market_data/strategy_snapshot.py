"""Immutable strategy-facing snapshots over validated Binance market data.

This module is an adapter only: it performs no network/database I/O, has no
mutable cache, does not calculate SMC signals, and cannot place orders.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Iterable

from divatrading.market_data.absorption import AbsorptionEvidence
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.mark_price import MarkPriceEvent
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot
from divatrading.market_data.orchestrator import MarketDataReadiness
from divatrading.market_data.websocket import MarketKlineEvent


class StrategyMarketDataError(ValueError):
    """Base error for malformed strategy-facing market-data inputs."""


class StrategyMarketDataInputError(StrategyMarketDataError):
    """Raised when a source object violates its typed market-data contract."""


@dataclass(frozen=True, slots=True)
class StrategyMarketDataConfig:
    """Fail-closed freshness and memory limits for strategy snapshots."""

    required_intervals: tuple[str, ...] = ("1m", "5m", "15m")
    max_candles_per_interval: int = 500
    max_kline_age_intervals: int = 2
    max_mark_price_age_ms: int = 10_000
    max_flow_age_ms: int = 10_000
    max_depth_age_ms: int = 5_000
    max_orchestrator_age_ms: int = 1_000
    max_future_skew_ms: int = 5_000

    def __post_init__(self) -> None:
        normalized = tuple(self.required_intervals)
        if not normalized or len(set(normalized)) != len(normalized):
            raise ValueError("required_intervals must be non-empty and unique")
        if any(interval not in INTERVAL_MILLISECONDS for interval in normalized):
            raise ValueError("required_intervals may contain only 1m, 5m and 15m")
        object.__setattr__(self, "required_intervals", normalized)
        if (
            isinstance(self.max_candles_per_interval, bool)
            or not isinstance(self.max_candles_per_interval, int)
            or not 1 <= self.max_candles_per_interval <= 2000
        ):
            raise ValueError("max_candles_per_interval must be between 1 and 2000")
        if (
            isinstance(self.max_kline_age_intervals, bool)
            or not isinstance(self.max_kline_age_intervals, int)
            or not 1 <= self.max_kline_age_intervals <= 10
        ):
            raise ValueError("max_kline_age_intervals must be between 1 and 10")
        for name in (
            "max_mark_price_age_ms",
            "max_flow_age_ms",
            "max_depth_age_ms",
            "max_orchestrator_age_ms",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if (
            isinstance(self.max_future_skew_ms, bool)
            or not isinstance(self.max_future_skew_ms, int)
            or self.max_future_skew_ms < 0
        ):
            raise ValueError("max_future_skew_ms must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class KlineSeriesInput:
    """Caller-supplied closed-candle series and optional live forming event.

    ``candles`` must contain closed, chronological candles only. A forming
    candle is carried separately so a downstream strategy cannot accidentally
    mistake it for confirmed-bar input.
    """

    symbol: str
    interval: str
    candles: tuple[Kline, ...]
    source_observed_at_ms: int
    source_healthy: bool = True
    source_complete: bool = True
    missing_open_times_ms: tuple[int, ...] = ()
    forming_event: MarketKlineEvent | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.symbol, str) or not self.symbol.strip():
            raise ValueError("KlineSeriesInput.symbol is required")
        object.__setattr__(self, "symbol", self.symbol.strip().upper())
        if self.interval not in INTERVAL_MILLISECONDS:
            raise ValueError("KlineSeriesInput.interval must be one of 1m, 5m, 15m")
        try:
            object.__setattr__(self, "candles", tuple(self.candles))
            object.__setattr__(self, "missing_open_times_ms", tuple(self.missing_open_times_ms))
        except TypeError as exc:
            raise ValueError("candles and missing_open_times_ms must be iterable") from exc
        if (
            isinstance(self.source_observed_at_ms, bool)
            or not isinstance(self.source_observed_at_ms, int)
            or self.source_observed_at_ms < 0
        ):
            raise ValueError("source_observed_at_ms must be a non-negative integer")
        if not isinstance(self.source_healthy, bool) or not isinstance(self.source_complete, bool):
            raise ValueError("source_healthy and source_complete must be boolean")
        if self.forming_event is not None and not isinstance(self.forming_event, MarketKlineEvent):
            raise ValueError("forming_event must be a MarketKlineEvent or None")
        for value in self.missing_open_times_ms:
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError("missing_open_times_ms must contain non-negative integers")


@dataclass(frozen=True, slots=True)
class StrategyComponentReadiness:
    """Readiness and age for one input component."""

    component: str
    status: str
    ready: bool
    age_ms: int | None
    reason_codes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class KlineIntervalSnapshot:
    """Validated closed candles for one Binance contract/timeframe."""

    symbol: str
    interval: str
    candles: tuple[Kline, ...]
    forming_candle: Kline | None
    source_observed_at_ms: int
    age_ms: int | None
    ready: bool
    reason_codes: tuple[str, ...]

    @property
    def latest_closed_candle(self) -> Kline | None:
        return self.candles[-1] if self.candles else None


@dataclass(frozen=True, slots=True)
class StrategyMarketDataSnapshot:
    """Immutable read-only market-data handoff to downstream strategy code."""

    symbol: str
    captured_at_ms: int
    status: str
    ready: bool
    reason_codes: tuple[str, ...]
    klines: tuple[KlineIntervalSnapshot, ...]
    mark_price: MarkPriceEvent | None
    flow: OrderFlowSnapshot | None
    order_book_health: OrderBookSymbolHealth | None
    order_book_metrics: OrderBookMetrics | None
    absorption: AbsorptionEvidence | None
    orchestrator_readiness: MarketDataReadiness | None
    components: tuple[StrategyComponentReadiness, ...]

    def kline(self, interval: str) -> KlineIntervalSnapshot | None:
        """Return the requested timeframe without exposing a mutable mapping."""
        return next((item for item in self.klines if item.interval == interval), None)

    def component(self, name: str) -> StrategyComponentReadiness | None:
        return next((item for item in self.components if item.component == name), None)


class StrategyMarketDataAdapter:
    """Build bounded immutable snapshots from already validated source services."""

    def __init__(self, *, config: StrategyMarketDataConfig | None = None) -> None:
        self.config = config or StrategyMarketDataConfig()

    def build_snapshot(
        self,
        *,
        symbol: str,
        now_ms: int,
        kline_series: Iterable[KlineSeriesInput],
        mark_price: MarkPriceEvent | None,
        mark_price_connected: bool,
        readiness: MarketDataReadiness | None,
        order_book_metrics: OrderBookMetrics | None,
    ) -> StrategyMarketDataSnapshot:
        normalized = self._symbol(symbol)
        self._timestamp(now_ms, "now_ms")
        if not isinstance(mark_price_connected, bool):
            raise StrategyMarketDataInputError("mark_price_connected must be boolean")
        if mark_price is not None and not isinstance(mark_price, MarkPriceEvent):
            raise StrategyMarketDataInputError("mark_price must be a MarkPriceEvent or None")
        if readiness is not None and not isinstance(readiness, MarketDataReadiness):
            raise StrategyMarketDataInputError("readiness must be a MarketDataReadiness or None")
        if order_book_metrics is not None and not isinstance(order_book_metrics, OrderBookMetrics):
            raise StrategyMarketDataInputError("order_book_metrics must be OrderBookMetrics or None")

        try:
            series_items = tuple(kline_series)
        except TypeError as exc:
            raise StrategyMarketDataInputError("kline_series must be iterable") from exc
        if len(series_items) > len(INTERVAL_MILLISECONDS):
            raise StrategyMarketDataInputError("kline_series exceeds the supported timeframe count")
        intervals = [item.interval for item in series_items if isinstance(item, KlineSeriesInput)]
        if len(intervals) != len(series_items):
            raise StrategyMarketDataInputError("kline_series must contain KlineSeriesInput items")
        if len(set(intervals)) != len(intervals):
            raise StrategyMarketDataInputError("kline_series contains duplicate intervals")
        unexpected = set(intervals) - set(self.config.required_intervals)
        if unexpected:
            raise StrategyMarketDataInputError(
                f"kline_series contains intervals not configured as required: {sorted(unexpected)}"
            )

        kline_snapshots: list[KlineIntervalSnapshot] = []
        for interval in self.config.required_intervals:
            item = next((candidate for candidate in series_items if candidate.interval == interval), None)
            if item is None:
                kline_snapshots.append(
                    KlineIntervalSnapshot(
                        symbol=normalized,
                        interval=interval,
                        candles=(),
                        forming_candle=None,
                        source_observed_at_ms=0,
                        age_ms=None,
                        ready=False,
                        reason_codes=("KLINE_INTERVAL_MISSING",),
                    )
                )
            else:
                if item.symbol != normalized:
                    raise StrategyMarketDataInputError("Kline series symbol does not match snapshot symbol")
                kline_snapshots.append(self._build_kline_snapshot(item, now_ms))

        components: list[StrategyComponentReadiness] = []
        kline_ready = all(item.ready for item in kline_snapshots)
        kline_reasons = tuple(
            dict.fromkeys(reason for item in kline_snapshots for reason in item.reason_codes)
        )
        components.append(
            StrategyComponentReadiness(
                component="KLINES",
                status="READY" if kline_ready else "DEGRADED",
                ready=kline_ready,
                age_ms=max((item.age_ms for item in kline_snapshots if item.age_ms is not None), default=None),
                reason_codes=kline_reasons,
            )
        )

        mark_age: int | None = None
        mark_reasons: list[str] = []
        if mark_price is None:
            mark_reasons.append("MARK_PRICE_MISSING")
        else:
            self._validate_mark_price(normalized, mark_price)
            mark_age = now_ms - mark_price.event_time_ms
            if not mark_price_connected:
                mark_reasons.append("MARK_PRICE_FEED_DISCONNECTED")
            if mark_age < -self.config.max_future_skew_ms:
                mark_reasons.append("MARK_PRICE_FUTURE_TIMESTAMP")
            elif mark_age > self.config.max_mark_price_age_ms:
                mark_reasons.append("MARK_PRICE_STALE")
        if mark_price is not None and not mark_price_connected and "MARK_PRICE_FEED_DISCONNECTED" not in mark_reasons:
            mark_reasons.append("MARK_PRICE_FEED_DISCONNECTED")
        mark_ready = mark_price is not None and mark_price_connected and not mark_reasons
        components.append(
            StrategyComponentReadiness(
                component="MARK_PRICE",
                status="READY" if mark_ready else "DEGRADED",
                ready=mark_ready,
                age_ms=mark_age,
                reason_codes=tuple(mark_reasons),
            )
        )

        orchestrator_reasons: list[str] = []
        flow = readiness.flow if readiness is not None else None
        depth_health = readiness.order_book_health if readiness is not None else None
        absorption = readiness.evidence if readiness is not None else None
        if readiness is None:
            orchestrator_reasons.append("ORCHESTRATOR_READINESS_MISSING")
        else:
            if readiness.symbol != normalized:
                raise StrategyMarketDataInputError("Orchestrator readiness symbol does not match")
            if isinstance(readiness.updated_at_ms, bool) or not isinstance(readiness.updated_at_ms, int) or readiness.updated_at_ms < 0:
                raise StrategyMarketDataInputError("Orchestrator updated_at_ms is invalid")
            readiness_age = now_ms - readiness.updated_at_ms
            if readiness_age < -self.config.max_future_skew_ms:
                orchestrator_reasons.append("ORCHESTRATOR_FUTURE_TIMESTAMP")
            elif readiness_age > self.config.max_orchestrator_age_ms:
                orchestrator_reasons.append("ORCHESTRATOR_READINESS_STALE")
            if readiness.status != "READY" or not readiness.ready:
                orchestrator_reasons.append("ORCHESTRATOR_NOT_READY")
                orchestrator_reasons.extend(readiness.reason_codes)
            if not readiness.aggregate_trade_connected:
                orchestrator_reasons.append("AGGREGATE_TRADE_DISCONNECTED")
            if not readiness.aggregate_trade_continuity:
                orchestrator_reasons.append("AGGREGATE_TRADE_CONTINUITY_INVALID")
            if not readiness.queues_healthy:
                orchestrator_reasons.append("MARKET_DATA_QUEUES_UNHEALTHY")

        flow_age: int | None = None
        flow_reasons: list[str] = []
        if flow is None:
            flow_reasons.append("DELTA_CVD_MISSING")
        else:
            self._validate_flow(normalized, flow)
            flow_age = None if flow.last_trade_time_ms is None else now_ms - flow.last_trade_time_ms
            if flow.status != "HEALTHY" or not flow.continuity_valid:
                flow_reasons.append("DELTA_CVD_CONTINUITY_INVALID")
            if not readiness or not readiness.delta_cvd_ready:
                flow_reasons.append("DELTA_CVD_ORCHESTRATOR_GATE_CLOSED")
            if not flow.is_fresh or flow_age is None:
                flow_reasons.append("DELTA_CVD_NOT_FRESH")
            elif flow_age < -self.config.max_future_skew_ms:
                flow_reasons.append("DELTA_CVD_FUTURE_TIMESTAMP")
            elif flow_age > self.config.max_flow_age_ms:
                flow_reasons.append("DELTA_CVD_STALE")
            if flow.trade_count <= 0:
                flow_reasons.append("DELTA_CVD_EMPTY_WINDOW")
        flow_ready = flow is not None and not flow_reasons
        components.append(
            StrategyComponentReadiness(
                component="DELTA_CVD",
                status="READY" if flow_ready else "DEGRADED",
                ready=flow_ready,
                age_ms=flow_age,
                reason_codes=tuple(dict.fromkeys(flow_reasons)),
            )
        )

        depth_age: int | None = None
        depth_reasons: list[str] = []
        if depth_health is None:
            depth_reasons.append("DEPTH_HEALTH_MISSING")
        else:
            if depth_health.symbol != normalized:
                raise StrategyMarketDataInputError("Depth health symbol does not match snapshot symbol")
            depth_age = depth_health.event_age_ms
            if depth_health.update_id is not None and (
                isinstance(depth_health.update_id, bool)
                or not isinstance(depth_health.update_id, int)
                or depth_health.update_id < 0
            ):
                raise StrategyMarketDataInputError("Depth health update_id is invalid")
            if not depth_health.ready or not depth_health.sequence_integrity:
                depth_reasons.append("DEPTH_SEQUENCE_OR_READINESS_INVALID")
            if not depth_health.event_fresh:
                depth_reasons.append("DEPTH_EVENT_NOT_FRESH")
            if not depth_health.queue_healthy:
                depth_reasons.append("DEPTH_QUEUE_UNHEALTHY")
            if depth_age is None:
                depth_reasons.append("DEPTH_AGE_UNAVAILABLE")
            elif depth_age < -self.config.max_future_skew_ms:
                depth_reasons.append("DEPTH_FUTURE_TIMESTAMP")
            elif depth_age > self.config.max_depth_age_ms:
                depth_reasons.append("DEPTH_STALE")
        if order_book_metrics is None:
            depth_reasons.append("DEPTH_METRICS_MISSING")
        else:
            self._validate_depth_metrics(normalized, order_book_metrics)
            if depth_health is not None and order_book_metrics.update_id != depth_health.update_id:
                depth_reasons.append("DEPTH_UPDATE_ID_MISMATCH")
            metrics_age = now_ms - order_book_metrics.last_event_time_ms
            if metrics_age < -self.config.max_future_skew_ms:
                depth_reasons.append("DEPTH_METRICS_FUTURE_TIMESTAMP")
            elif metrics_age > self.config.max_depth_age_ms:
                depth_reasons.append("DEPTH_METRICS_STALE")
            if depth_age is None:
                depth_age = metrics_age
        depth_ready = depth_health is not None and order_book_metrics is not None and not depth_reasons
        components.append(
            StrategyComponentReadiness(
                component="DEPTH",
                status="READY" if depth_ready else "DEGRADED",
                ready=depth_ready,
                age_ms=depth_age,
                reason_codes=tuple(dict.fromkeys(depth_reasons)),
            )
        )

        absorption_reasons: list[str] = []
        absorption_status = readiness.evidence_status if readiness is not None else "UNAVAILABLE"
        if absorption is None:
            absorption_reasons.append("ABSORPTION_EVIDENCE_MISSING")
        else:
            self._validate_absorption(normalized, absorption)
            if absorption.status != absorption_status:
                raise StrategyMarketDataInputError("Absorption status disagrees with orchestrator readiness")
            if absorption.status == "UNAVAILABLE":
                absorption_reasons.extend(absorption.reason_codes or ("ABSORPTION_UNAVAILABLE",))
            elif absorption.status not in {"WARMING_UP", "NO_CANDIDATE", "CANDIDATE"}:
                raise StrategyMarketDataInputError("Absorption evidence has an unsupported status")
            if (
                order_book_metrics is not None
                and absorption.source_update_id is not None
                and absorption.source_update_id != order_book_metrics.update_id
            ):
                absorption_reasons.append("ABSORPTION_DEPTH_UPDATE_ID_MISMATCH")
            if absorption.window_end_ms is not None:
                evidence_age = now_ms - absorption.window_end_ms
                if evidence_age < -self.config.max_future_skew_ms:
                    absorption_reasons.append("ABSORPTION_FUTURE_TIMESTAMP")
                elif evidence_age > self.config.max_flow_age_ms:
                    absorption_reasons.append("ABSORPTION_EVIDENCE_STALE")
        absorption_ready = absorption is not None and not absorption_reasons
        components.append(
            StrategyComponentReadiness(
                component="ABSORPTION",
                status=absorption_status if absorption_ready else "UNAVAILABLE",
                ready=absorption_ready,
                age_ms=(None if absorption is None else max(0, now_ms - absorption.window_end_ms)
                        if absorption.window_end_ms is not None else None),
                reason_codes=tuple(absorption_reasons),
            )
        )

        components.append(
            StrategyComponentReadiness(
                component="ORCHESTRATOR",
                status="READY" if readiness is not None and readiness.ready and not orchestrator_reasons else "DEGRADED",
                ready=readiness is not None and readiness.ready and not orchestrator_reasons,
                age_ms=(None if readiness is None else now_ms - readiness.updated_at_ms),
                reason_codes=tuple(dict.fromkeys(orchestrator_reasons)),
            )
        )

        required_components = ("KLINES", "MARK_PRICE", "DELTA_CVD", "DEPTH", "ABSORPTION", "ORCHESTRATOR")
        component_map = {item.component: item for item in components}
        ready = all(component_map[name].ready for name in required_components)
        reasons = tuple(
            dict.fromkeys(
                reason
                for name in required_components
                for reason in component_map[name].reason_codes
            )
        )
        source_count = sum(
            value is not None
            for value in (mark_price, readiness, order_book_metrics)
        ) + len(series_items)
        status = "READY" if ready else ("UNAVAILABLE" if source_count == 0 else "DEGRADED")

        return StrategyMarketDataSnapshot(
            symbol=normalized,
            captured_at_ms=now_ms,
            status=status,
            ready=ready,
            reason_codes=reasons,
            klines=tuple(kline_snapshots),
            mark_price=mark_price,
            flow=flow,
            order_book_health=depth_health,
            order_book_metrics=order_book_metrics,
            absorption=absorption,
            orchestrator_readiness=readiness,
            components=tuple(components),
        )

    def _build_kline_snapshot(self, item: KlineSeriesInput, now_ms: int) -> KlineIntervalSnapshot:
        interval_ms = INTERVAL_MILLISECONDS[item.interval]
        reasons: list[str] = []
        if len(item.candles) > self.config.max_candles_per_interval:
            raise StrategyMarketDataInputError(
                f"{item.interval} candle count exceeds {self.config.max_candles_per_interval}"
            )
        if not item.source_healthy:
            reasons.append("KLINE_SOURCE_UNHEALTHY")
        if not item.source_complete or item.missing_open_times_ms:
            reasons.append("KLINE_HISTORY_INCOMPLETE")
        source_age = now_ms - item.source_observed_at_ms
        if source_age < -self.config.max_future_skew_ms:
            reasons.append("KLINE_SOURCE_FUTURE_TIMESTAMP")
        elif source_age > interval_ms * self.config.max_kline_age_intervals:
            reasons.append("KLINE_SOURCE_STALE")
        if not item.candles:
            reasons.append("KLINE_CANDLES_MISSING")
        previous_open: int | None = None
        for candle in item.candles:
            self._validate_kline(candle, item.symbol, item.interval)
            if previous_open is not None and candle.open_time_ms != previous_open + interval_ms:
                reasons.append("KLINE_CANDLE_GAP")
            if candle.close_time_ms >= now_ms:
                reasons.append("KLINE_LATEST_CANDLE_NOT_CLOSED")
            previous_open = candle.open_time_ms
        age_ms: int | None = None
        if item.candles:
            age_ms = now_ms - item.candles[-1].close_time_ms
            if age_ms < 0:
                reasons.append("KLINE_CANDLE_FUTURE_TIMESTAMP")
            elif age_ms > interval_ms * self.config.max_kline_age_intervals:
                reasons.append("KLINE_CANDLE_STALE")

        forming: Kline | None = None
        event = item.forming_event
        if event is not None:
            self._validate_kline_event(event, item.symbol, item.interval)
            event_age = now_ms - event.event_time_ms
            if event.is_closed:
                raise StrategyMarketDataInputError("forming_event must have is_closed=False")
            if event_age < -self.config.max_future_skew_ms or event_age > interval_ms * self.config.max_kline_age_intervals:
                reasons.append("KLINE_FORMING_EVENT_STALE_OR_FUTURE")
            if event.kline.close_time_ms < now_ms:
                reasons.append("KLINE_FORMING_EVENT_EXPIRED")
            if item.candles and event.kline.open_time_ms != item.candles[-1].open_time_ms + interval_ms:
                reasons.append("KLINE_FORMING_EVENT_NOT_CONTIGUOUS")
            forming = event.kline
        ready = not reasons
        return KlineIntervalSnapshot(
            symbol=item.symbol,
            interval=item.interval,
            candles=item.candles,
            forming_candle=forming,
            source_observed_at_ms=item.source_observed_at_ms,
            age_ms=age_ms,
            ready=ready,
            reason_codes=tuple(dict.fromkeys(reasons)),
        )

    @staticmethod
    def _validate_kline(candle: Kline, symbol: str, interval: str) -> None:
        if not isinstance(candle, Kline):
            raise StrategyMarketDataInputError("Closed candle series must contain Kline objects")
        if candle.exchange != "BINANCE_UM" or candle.symbol != symbol or candle.interval != interval:
            raise StrategyMarketDataInputError("Kline exchange, symbol or interval mismatch")
        interval_ms = INTERVAL_MILLISECONDS[interval]
        if (
            isinstance(candle.open_time_ms, bool)
            or not isinstance(candle.open_time_ms, int)
            or candle.open_time_ms < 0
            or candle.open_time_ms % interval_ms
        ):
            raise StrategyMarketDataInputError("Kline open time is invalid or misaligned")
        if candle.close_time_ms != candle.open_time_ms + interval_ms - 1:
            raise StrategyMarketDataInputError("Kline close time does not match its interval")
        if not isinstance(candle.source_endpoint, str) or not candle.source_endpoint.strip():
            raise StrategyMarketDataInputError("Kline source endpoint cannot be empty")
        decimals = (
            candle.open,
            candle.high,
            candle.low,
            candle.close,
            candle.volume,
            candle.quote_asset_volume,
            candle.taker_buy_base_volume,
            candle.taker_buy_quote_volume,
        )
        if any(not isinstance(value, Decimal) or not value.is_finite() for value in decimals):
            raise StrategyMarketDataInputError("Kline values must be finite Decimal instances")
        if min(candle.open, candle.high, candle.low, candle.close) <= 0:
            raise StrategyMarketDataInputError("Kline OHLC prices must be positive")
        if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(candle.open, candle.high, candle.close):
            raise StrategyMarketDataInputError("Kline OHLC range is inconsistent")
        if min(candle.volume, candle.quote_asset_volume, candle.taker_buy_base_volume,
               candle.taker_buy_quote_volume) < 0:
            raise StrategyMarketDataInputError("Kline volume values cannot be negative")
        if isinstance(candle.trade_count, bool) or not isinstance(candle.trade_count, int) or candle.trade_count < 0:
            raise StrategyMarketDataInputError("Kline trade_count must be a non-negative integer")

    @classmethod
    def _validate_kline_event(cls, event: MarketKlineEvent, symbol: str, interval: str) -> None:
        if not isinstance(event, MarketKlineEvent):
            raise StrategyMarketDataInputError("forming_event must be a MarketKlineEvent")
        cls._validate_kline(event.kline, symbol, interval)
        if isinstance(event.event_time_ms, bool) or not isinstance(event.event_time_ms, int) or event.event_time_ms < 0:
            raise StrategyMarketDataInputError("Kline event timestamp must be non-negative")
        if not isinstance(event.is_closed, bool):
            raise StrategyMarketDataInputError("Kline event close flag must be boolean")
        if not isinstance(event.received_at_utc, datetime) or event.received_at_utc.tzinfo is None or event.received_at_utc.utcoffset() is None:
            raise StrategyMarketDataInputError("Kline event receive time must be timezone-aware")
        expected_stream = f"{symbol.lower()}@kline_{interval}"
        if event.stream_name != expected_stream:
            raise StrategyMarketDataInputError("Kline event stream name does not match symbol/interval")

    @staticmethod
    def _validate_mark_price(symbol: str, event: MarkPriceEvent) -> None:
        if event.symbol != symbol:
            raise StrategyMarketDataInputError("Mark Price symbol does not match snapshot symbol")
        if (
            not isinstance(event.mark_price, Decimal)
            or not isinstance(event.index_price, Decimal)
            or not isinstance(event.funding_rate, Decimal)
            or not event.mark_price.is_finite()
            or not event.index_price.is_finite()
            or not event.funding_rate.is_finite()
            or event.mark_price <= 0
            or event.index_price <= 0
        ):
            raise StrategyMarketDataInputError("Mark Price values must be finite Decimal values and prices positive")
        if isinstance(event.event_time_ms, bool) or not isinstance(event.event_time_ms, int) or event.event_time_ms < 0:
            raise StrategyMarketDataInputError("Mark Price event_time_ms must be non-negative")
        if not isinstance(event.received_at_utc, datetime) or event.received_at_utc.tzinfo is None or event.received_at_utc.utcoffset() is None:
            raise StrategyMarketDataInputError("Mark Price receive time must be timezone-aware")
        if not isinstance(event.source_endpoint, str) or not event.source_endpoint.strip():
            raise StrategyMarketDataInputError("Mark Price source endpoint cannot be empty")
        if not isinstance(event.stream_name, str) or not event.stream_name.strip():
            raise StrategyMarketDataInputError("Mark Price stream name cannot be empty")
        for field_name in ("next_funding_time_ms",):
            field_value = getattr(event, field_name)
            if isinstance(field_value, bool) or not isinstance(field_value, int) or field_value < 0:
                raise StrategyMarketDataInputError(f"Mark Price {field_name} must be a non-negative integer")
        for field_name in ("estimated_settle_price", "mark_price_moving_average"):
            field_value = getattr(event, field_name)
            if field_value is not None and (
                not isinstance(field_value, Decimal) or not field_value.is_finite() or field_value <= 0
            ):
                raise StrategyMarketDataInputError(f"Mark Price {field_name} must be a positive finite Decimal")

    @staticmethod
    def _validate_flow(symbol: str, flow: OrderFlowSnapshot) -> None:
        if flow.symbol != symbol:
            raise StrategyMarketDataInputError("Delta/CVD symbol does not match snapshot symbol")
        decimal_fields = (
            flow.cvd_base, flow.cvd_quote, flow.buy_volume_base, flow.sell_volume_base,
            flow.delta_base, flow.buy_volume_quote, flow.sell_volume_quote, flow.delta_quote,
            flow.buy_imbalance_base, flow.buy_imbalance_quote,
        )
        if any(not isinstance(value, Decimal) or not value.is_finite() for value in decimal_fields):
            raise StrategyMarketDataInputError("Delta/CVD values must be finite Decimal instances")
        if min(flow.buy_volume_base, flow.sell_volume_base, flow.buy_volume_quote, flow.sell_volume_quote) < 0:
            raise StrategyMarketDataInputError("Delta/CVD buy and sell volumes cannot be negative")
        if (
            isinstance(flow.baseline_aggregate_trade_id, bool)
            or not isinstance(flow.baseline_aggregate_trade_id, int)
            or flow.baseline_aggregate_trade_id < 0
            or flow.last_processed_aggregate_trade_id < flow.baseline_aggregate_trade_id
        ):
            raise StrategyMarketDataInputError("Delta/CVD aggregate trade baseline/cursor is invalid")
        if isinstance(flow.trade_count, bool) or not isinstance(flow.trade_count, int) or flow.trade_count < 0:
            raise StrategyMarketDataInputError("Delta/CVD trade_count must be a non-negative integer")
        if flow.data_age_ms is not None and (
            isinstance(flow.data_age_ms, bool) or not isinstance(flow.data_age_ms, int) or flow.data_age_ms < 0
        ):
            raise StrategyMarketDataInputError("Delta/CVD data_age_ms must be a non-negative integer or None")
        if (
            isinstance(flow.last_processed_aggregate_trade_id, bool)
            or not isinstance(flow.last_processed_aggregate_trade_id, int)
            or flow.last_processed_aggregate_trade_id < 0
        ):
            raise StrategyMarketDataInputError("Delta/CVD aggregate trade cursor is invalid")
        if flow.last_trade_time_ms is not None and (
            isinstance(flow.last_trade_time_ms, bool) or not isinstance(flow.last_trade_time_ms, int)
            or flow.last_trade_time_ms < 0
        ):
            raise StrategyMarketDataInputError("Delta/CVD last_trade_time_ms is invalid")

    @staticmethod
    def _validate_depth_metrics(symbol: str, metrics: OrderBookMetrics) -> None:
        if metrics.symbol != symbol:
            raise StrategyMarketDataInputError("Depth metrics symbol does not match snapshot symbol")
        decimals = (
            metrics.best_bid, metrics.best_ask, metrics.spread, metrics.spread_bps,
            metrics.bid_depth, metrics.ask_depth, metrics.imbalance,
        )
        if any(not isinstance(value, Decimal) or not value.is_finite() for value in decimals):
            raise StrategyMarketDataInputError("Depth metrics must contain finite Decimal values")
        if metrics.best_bid <= 0 or metrics.best_ask <= metrics.best_bid or metrics.spread <= 0:
            raise StrategyMarketDataInputError("Depth best bid/ask or spread is invalid")
        if metrics.spread != metrics.best_ask - metrics.best_bid:
            raise StrategyMarketDataInputError("Depth spread does not match best bid/ask")
        if metrics.bid_depth < 0 or metrics.ask_depth < 0 or metrics.spread_bps < 0:
            raise StrategyMarketDataInputError("Depth sizes and spread must be non-negative")
        if not -Decimal("1") <= metrics.imbalance <= Decimal("1"):
            raise StrategyMarketDataInputError("Depth imbalance must be between -1 and 1")
        if isinstance(metrics.update_id, bool) or not isinstance(metrics.update_id, int) or metrics.update_id < 0:
            raise StrategyMarketDataInputError("Depth update_id is invalid")
        if isinstance(metrics.last_event_time_ms, bool) or not isinstance(metrics.last_event_time_ms, int) or metrics.last_event_time_ms < 0:
            raise StrategyMarketDataInputError("Depth last_event_time_ms is invalid")
        if not metrics.synchronized:
            raise StrategyMarketDataInputError("Depth metrics are not synchronized")

    @staticmethod
    def _validate_absorption(symbol: str, evidence: AbsorptionEvidence) -> None:
        if evidence.symbol != symbol:
            raise StrategyMarketDataInputError("Absorption symbol does not match snapshot symbol")
        if evidence.status not in {"UNAVAILABLE", "WARMING_UP", "NO_CANDIDATE", "CANDIDATE"}:
            raise StrategyMarketDataInputError("Absorption status is invalid")
        if (
            isinstance(evidence.sample_count, bool)
            or not isinstance(evidence.sample_count, int)
            or evidence.sample_count < 0
            or isinstance(evidence.window_duration_ms, bool)
            or not isinstance(evidence.window_duration_ms, int)
            or evidence.window_duration_ms < 0
        ):
            raise StrategyMarketDataInputError("Absorption sample count/window duration is invalid")
        decimal_values = (
            evidence.aggressive_buy_quote, evidence.aggressive_sell_quote,
            evidence.latest_delta_quote, evidence.cvd_change_quote,
        )
        if any(not isinstance(value, Decimal) or not value.is_finite() for value in decimal_values):
            raise StrategyMarketDataInputError("Absorption flow measurements must be finite Decimal values")

    @staticmethod
    def _symbol(value: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise StrategyMarketDataInputError("symbol is required")
        normalized = value.strip().upper()
        if normalized != value.strip():
            raise StrategyMarketDataInputError("symbol must already be uppercase")
        return normalized

    @staticmethod
    def _timestamp(value: int, name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise StrategyMarketDataInputError(f"{name} must be a non-negative integer")


__all__ = [
    "KlineIntervalSnapshot",
    "KlineSeriesInput",
    "StrategyComponentReadiness",
    "StrategyMarketDataAdapter",
    "StrategyMarketDataConfig",
    "StrategyMarketDataError",
    "StrategyMarketDataInputError",
    "StrategyMarketDataSnapshot",
]
