"""Typed Binance USD-M Kline model and defensive payload parser."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Sequence


INTERVAL_MILLISECONDS: dict[str, int] = {"1m": 60_000, "5m": 300_000, "15m": 900_000}


class KlineParseError(ValueError):
    """Raised when a Binance Kline row is malformed or internally inconsistent."""


def _decimal(value: Any, field_name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise KlineParseError(f"Kline {field_name} is not a valid decimal") from exc
    if not result.is_finite():
        raise KlineParseError(f"Kline {field_name} must be finite")
    return result


def _integer(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise KlineParseError(f"Kline {field_name} must be an integer")
    try:
        result = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise KlineParseError(f"Kline {field_name} must be an integer") from exc
    if str(value).strip() not in {str(result), f"{result}.0"}:
        raise KlineParseError(f"Kline {field_name} must be an exact integer")
    return result


@dataclass(frozen=True, slots=True)
class Kline:
    exchange: str
    symbol: str
    interval: str
    open_time_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    close_time_ms: int
    quote_asset_volume: Decimal
    trade_count: int
    taker_buy_base_volume: Decimal
    taker_buy_quote_volume: Decimal
    ignore_value: str
    source_endpoint: str

    @property
    def open_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(milliseconds=self.open_time_ms)

    @property
    def close_time_utc(self) -> datetime:
        return datetime(1970, 1, 1, tzinfo=UTC) + timedelta(milliseconds=self.close_time_ms)

    @classmethod
    def from_binance_row(
        cls,
        row: Sequence[Any],
        *,
        symbol: str,
        interval: str,
        source_endpoint: str,
    ) -> "Kline":
        if interval not in INTERVAL_MILLISECONDS:
            raise KlineParseError(f"Unsupported Kline interval: {interval}")
        if not isinstance(row, (list, tuple)) or len(row) != 12:
            raise KlineParseError("Binance Kline row must contain exactly 12 fields")
        if not symbol.strip() or not source_endpoint.strip():
            raise KlineParseError("Kline symbol and source_endpoint are required")

        open_time = _integer(row[0], "open_time_ms")
        close_time = _integer(row[6], "close_time_ms")
        trade_count = _integer(row[8], "trade_count")
        interval_ms = INTERVAL_MILLISECONDS[interval]
        if open_time < 0 or open_time % interval_ms != 0:
            raise KlineParseError("Kline open time is negative or not aligned to its interval")
        if close_time != open_time + interval_ms - 1:
            raise KlineParseError("Kline close time does not match the interval boundary")
        if trade_count < 0:
            raise KlineParseError("Kline trade_count cannot be negative")

        open_price = _decimal(row[1], "open")
        high_price = _decimal(row[2], "high")
        low_price = _decimal(row[3], "low")
        close_price = _decimal(row[4], "close")
        volume = _decimal(row[5], "volume")
        quote_volume = _decimal(row[7], "quote_asset_volume")
        taker_base = _decimal(row[9], "taker_buy_base_volume")
        taker_quote = _decimal(row[10], "taker_buy_quote_volume")

        if min(open_price, high_price, low_price, close_price) <= 0:
            raise KlineParseError("Kline OHLC prices must be positive")
        if high_price < max(open_price, low_price, close_price):
            raise KlineParseError("Kline high is below another OHLC value")
        if low_price > min(open_price, high_price, close_price):
            raise KlineParseError("Kline low is above another OHLC value")
        if min(volume, quote_volume, taker_base, taker_quote) < 0:
            raise KlineParseError("Kline volumes cannot be negative")

        return cls(
            exchange="BINANCE_UM",
            symbol=symbol.strip().upper(),
            interval=interval,
            open_time_ms=open_time,
            open=open_price,
            high=high_price,
            low=low_price,
            close=close_price,
            volume=volume,
            close_time_ms=close_time,
            quote_asset_volume=quote_volume,
            trade_count=trade_count,
            taker_buy_base_volume=taker_base,
            taker_buy_quote_volume=taker_quote,
            ignore_value=str(row[11]),
            source_endpoint=source_endpoint,
        )
