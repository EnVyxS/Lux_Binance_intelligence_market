"""Bounded public Binance USD-M Futures WebSocket Kline feed."""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Callable, Iterable

from websockets.asyncio.client import connect as websocket_connect

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline, KlineParseError


BINANCE_UM_MARKET_WS_ENDPOINT = "wss://fstream.binance.com/market/stream"
BINANCE_UM_DEMO_MARKET_WS_ENDPOINT = "wss://demo-fstream.binance.com/market/stream"
DEFAULT_MAX_SUBSCRIPTIONS = 48
HARD_MAX_SUBSCRIPTIONS = 128
DEFAULT_EVENT_QUEUE_CAPACITY = 2048
HARD_MAX_EVENT_QUEUE_CAPACITY = 8192
WEBSOCKET_MAX_MESSAGE_BYTES = 64 * 1024
WEBSOCKET_MAX_FRAME_QUEUE = 16
_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{2,30}$")


class KlineWebSocketError(RuntimeError):
    """Base error for the public Kline WebSocket feed."""


class KlineWebSocketParseError(KlineWebSocketError):
    """Raised when a Kline event cannot be validated or normalized."""


class KlineWebSocketProtocolError(KlineWebSocketError):
    """Raised when Binance rejects a WebSocket subscription or request."""


class FeedQueueFullError(KlineWebSocketError):
    """Raised rather than silently dropping a market event when the queue is full."""


class WebSocketReconnectExhausted(KlineWebSocketError):
    """Raised after the configured number of consecutive reconnect attempts."""


@dataclass(frozen=True, slots=True)
class MarketKlineEvent:
    """Normalized Kline update from the Binance market stream."""

    kline: Kline
    event_time_ms: int
    is_closed: bool
    stream_name: str
    received_at_utc: datetime

    @property
    def status(self) -> str:
        return "CLOSED" if self.is_closed else "FORMING"


@dataclass(slots=True)
class WebSocketFeedStats:
    """Observable feed counters; updated by the feed's single async task."""

    connection_count: int = 0
    reconnect_attempts: int = 0
    subscription_messages_sent: int = 0
    messages_received: int = 0
    events_emitted: int = 0
    acknowledgements_received: int = 0
    malformed_messages: int = 0
    queue_overflows: int = 0
    last_error: str | None = None


def _exact_integer(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise KlineWebSocketParseError(f"{field_name} must be an integer")
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise KlineWebSocketParseError(f"{field_name} must be an integer") from exc
    if str(value).strip() not in {str(parsed), f"{parsed}.0"}:
        raise KlineWebSocketParseError(f"{field_name} must be an exact integer")
    if parsed < 0:
        raise KlineWebSocketParseError(f"{field_name} cannot be negative")
    return parsed


def normalize_subscriptions(
    symbols: Iterable[str], intervals: Iterable[str]
) -> tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
    """Validate and deduplicate symbols/timeframes, returning Binance stream names."""
    normalized_symbols: list[str] = []
    for value in symbols:
        if not isinstance(value, str):
            raise ValueError("Every symbol must be a string")
        symbol = value.strip().upper()
        if not _SYMBOL_PATTERN.fullmatch(symbol):
            raise ValueError(f"Invalid Binance contract symbol: {value!r}")
        if symbol not in normalized_symbols:
            normalized_symbols.append(symbol)

    if not normalized_symbols:
        raise ValueError("At least one Binance symbol is required")

    normalized_intervals: list[str] = []
    for value in intervals:
        if not isinstance(value, str) or value not in INTERVAL_MILLISECONDS:
            raise ValueError("Intervals must be selected from: 1m, 5m, 15m")
        if value not in normalized_intervals:
            normalized_intervals.append(value)

    if not normalized_intervals:
        raise ValueError("At least one Kline interval is required")

    streams = tuple(
        f"{symbol.lower()}@kline_{interval}"
        for symbol in normalized_symbols
        for interval in normalized_intervals
    )
    return tuple(normalized_symbols), tuple(normalized_intervals), streams


def parse_kline_stream_message(
    message: str | bytes,
    *,
    source_endpoint: str = BINANCE_UM_MARKET_WS_ENDPOINT,
    allowed_symbols: Iterable[str] | None = None,
    allowed_intervals: Iterable[str] | None = None,
    received_at_utc: datetime | None = None,
) -> MarketKlineEvent | None:
    """Parse raw or combined Binance Kline events; return ``None`` for acks."""
    if isinstance(message, bytes):
        try:
            message = message.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise KlineWebSocketParseError("WebSocket message is not valid UTF-8") from exc
    if not isinstance(message, str) or not message:
        raise KlineWebSocketParseError("WebSocket message must be non-empty text or bytes")
    try:
        payload = json.loads(message)
    except (json.JSONDecodeError, TypeError) as exc:
        raise KlineWebSocketParseError("WebSocket message is not valid JSON") from exc
    if not isinstance(payload, dict):
        raise KlineWebSocketParseError("WebSocket message root must be an object")

    if "id" in payload and "result" in payload:
        if payload.get("result") is not None:
            raise KlineWebSocketProtocolError("Unexpected non-empty subscription acknowledgement")
        return None
    if "code" in payload and "msg" in payload:
        raise KlineWebSocketProtocolError(
            f"Binance WebSocket error {payload.get('code')}: {payload.get('msg')}"
        )

    stream_name = payload.get("stream")
    event_payload = payload.get("data", payload)
    if not isinstance(event_payload, dict):
        raise KlineWebSocketParseError("Kline event data must be an object")
    if event_payload.get("e") != "kline":
        raise KlineWebSocketParseError("Unexpected WebSocket event type")

    symbol = event_payload.get("s")
    kline_payload = event_payload.get("k")
    if not isinstance(symbol, str) or not isinstance(kline_payload, dict):
        raise KlineWebSocketParseError("Kline event must contain symbol and kline objects")
    symbol = symbol.strip().upper()
    if not _SYMBOL_PATTERN.fullmatch(symbol):
        raise KlineWebSocketParseError("Kline event contains an invalid symbol")

    kline_symbol = kline_payload.get("s")
    interval = kline_payload.get("i")
    if not isinstance(kline_symbol, str) or kline_symbol.strip().upper() != symbol:
        raise KlineWebSocketParseError("Outer and inner Kline symbols do not match")
    if not isinstance(interval, str) or interval not in INTERVAL_MILLISECONDS:
        raise KlineWebSocketParseError("Kline event contains an unsupported interval")

    if allowed_symbols is not None and symbol not in {item.upper() for item in allowed_symbols}:
        raise KlineWebSocketParseError(f"Received an unsubscribed symbol: {symbol}")
    if allowed_intervals is not None and interval not in set(allowed_intervals):
        raise KlineWebSocketParseError(f"Received an unsubscribed interval: {interval}")

    expected_stream = f"{symbol.lower()}@kline_{interval}"
    if stream_name is not None and stream_name != expected_stream:
        raise KlineWebSocketParseError("Combined-stream name does not match the event payload")

    is_closed = kline_payload.get("x")
    if not isinstance(is_closed, bool):
        raise KlineWebSocketParseError("Kline close flag 'x' must be boolean")

    try:
        row = (
            kline_payload["t"],
            kline_payload["o"],
            kline_payload["h"],
            kline_payload["l"],
            kline_payload["c"],
            kline_payload["v"],
            kline_payload["T"],
            kline_payload["q"],
            kline_payload["n"],
            kline_payload["V"],
            kline_payload["Q"],
            kline_payload["B"],
        )
    except KeyError as exc:
        raise KlineWebSocketParseError(f"Kline payload is missing field {exc.args[0]!r}") from exc

    try:
        kline = Kline.from_binance_row(
            row,
            symbol=symbol,
            interval=interval,
            source_endpoint=source_endpoint,
        )
    except KlineParseError as exc:
        raise KlineWebSocketParseError(str(exc)) from exc

    event_time_ms = _exact_integer(event_payload.get("E"), "event_time_ms")
    received_at = received_at_utc or datetime.now(UTC)
    if received_at.tzinfo is None or received_at.utcoffset() is None:
        raise KlineWebSocketParseError("received_at_utc must be timezone-aware")

    return MarketKlineEvent(
        kline=kline,
        event_time_ms=event_time_ms,
        is_closed=is_closed,
        stream_name=expected_stream,
        received_at_utc=received_at.astimezone(UTC),
    )


class BinanceKlineWebSocketFeed:
    """Async Kline feed with bounded subscriptions, queue and reconnect attempts.

    A caller owns the task running :meth:`run` and must continuously drain
    :attr:`events`. Queue overflow raises ``FeedQueueFullError`` rather than
    silently dropping an update. REST reconciliation after disconnect belongs to
    Unit 03D, not this class.
    """

    def __init__(
        self,
        *,
        symbols: Iterable[str],
        intervals: Iterable[str] = ("1m", "5m", "15m"),
        endpoint: str = BINANCE_UM_MARKET_WS_ENDPOINT,
        max_subscriptions: int = DEFAULT_MAX_SUBSCRIPTIONS,
        queue_capacity: int = DEFAULT_EVENT_QUEUE_CAPACITY,
        max_reconnect_attempts: int = 5,
        reconnect_base_delay_seconds: float = 1.0,
        reconnect_max_delay_seconds: float = 30.0,
        stable_connection_reset_seconds: float = 30.0,
        connector: Callable[..., Any] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith("wss://"):
            raise ValueError("endpoint must be a secure wss:// URL")
        if isinstance(max_subscriptions, bool) or not 1 <= max_subscriptions <= HARD_MAX_SUBSCRIPTIONS:
            raise ValueError(f"max_subscriptions must be between 1 and {HARD_MAX_SUBSCRIPTIONS}")
        if isinstance(queue_capacity, bool) or not 1 <= queue_capacity <= HARD_MAX_EVENT_QUEUE_CAPACITY:
            raise ValueError(
                f"queue_capacity must be between 1 and {HARD_MAX_EVENT_QUEUE_CAPACITY}"
            )
        if isinstance(max_reconnect_attempts, bool) or not 0 <= max_reconnect_attempts <= 20:
            raise ValueError("max_reconnect_attempts must be between 0 and 20")
        if reconnect_base_delay_seconds < 0 or reconnect_max_delay_seconds < 0:
            raise ValueError("Reconnect delays cannot be negative")
        if reconnect_max_delay_seconds < reconnect_base_delay_seconds:
            raise ValueError("Reconnect maximum delay cannot be below its base delay")
        if stable_connection_reset_seconds < 0:
            raise ValueError("stable_connection_reset_seconds cannot be negative")

        normalized_symbols, normalized_intervals, streams = normalize_subscriptions(
            symbols, intervals
        )
        if len(streams) > max_subscriptions:
            raise ValueError(
                f"Requested {len(streams)} streams exceeds configured cap {max_subscriptions}"
            )

        self.symbols = normalized_symbols
        self.intervals = normalized_intervals
        self.stream_names = streams
        self.endpoint = endpoint
        self.max_subscriptions = max_subscriptions
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_base_delay_seconds = reconnect_base_delay_seconds
        self.reconnect_max_delay_seconds = reconnect_max_delay_seconds
        self.stable_connection_reset_seconds = stable_connection_reset_seconds
        self.events: asyncio.Queue[MarketKlineEvent] = asyncio.Queue(maxsize=queue_capacity)
        self.stats = WebSocketFeedStats()
        self._connector = connector or websocket_connect
        self._monotonic = monotonic
        self._request_id = 1
        self._connected = False

    @property
    def is_connected(self) -> bool:
        """Whether the underlying WebSocket session is currently established."""
        return self._connected

    def subscription_request(self) -> dict[str, Any]:
        """Return the deterministic SUBSCRIBE message for the configured streams."""
        return {
            "method": "SUBSCRIBE",
            "params": list(self.stream_names),
            "id": self._request_id,
        }

    async def get_event(self) -> MarketKlineEvent:
        """Wait for the next normalized Kline event."""
        return await self.events.get()

    async def run(self, stop_event: asyncio.Event) -> None:
        """Run until stopped; reconnect a bounded number of times after disconnects."""
        if not isinstance(stop_event, asyncio.Event):
            raise TypeError("stop_event must be an asyncio.Event")

        consecutive_reconnects = 0
        while not stop_event.is_set():
            session_started = self._monotonic()
            try:
                async with self._connector(
                    self.endpoint,
                    open_timeout=10,
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=5,
                    max_size=WEBSOCKET_MAX_MESSAGE_BYTES,
                    max_queue=WEBSOCKET_MAX_FRAME_QUEUE,
                    compression=None,
                ) as websocket:
                    self.stats.connection_count += 1
                    self._connected = True
                    try:
                        request = self.subscription_request()
                        self._request_id += 1
                        await websocket.send(json.dumps(request, separators=(",", ":")))
                        self.stats.subscription_messages_sent += 1
                        await self._receive_until_stopped(websocket, stop_event)
                        if stop_event.is_set():
                            return
                        raise ConnectionError("Binance WebSocket closed without a stop request")
                    finally:
                        self._connected = False
            except FeedQueueFullError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.stats.last_error = f"{type(exc).__name__}: {exc}"
                if stop_event.is_set():
                    return
                if self._monotonic() - session_started >= self.stable_connection_reset_seconds:
                    consecutive_reconnects = 0
                if consecutive_reconnects >= self.max_reconnect_attempts:
                    raise WebSocketReconnectExhausted(
                        f"WebSocket reconnect limit exhausted after {consecutive_reconnects} retries"
                    ) from exc
                consecutive_reconnects += 1
                self.stats.reconnect_attempts += 1
                delay = min(
                    self.reconnect_base_delay_seconds * (2 ** (consecutive_reconnects - 1)),
                    self.reconnect_max_delay_seconds,
                )
                await self._wait_or_stop(stop_event, delay)

    async def _receive_until_stopped(
        self,
        websocket: Any,
        stop_event: asyncio.Event,
    ) -> None:
        while not stop_event.is_set():
            message = await self._recv_or_stop(websocket, stop_event)
            if message is None:
                return
            self.stats.messages_received += 1
            try:
                event = parse_kline_stream_message(
                    message,
                    source_endpoint=self.endpoint,
                    allowed_symbols=self.symbols,
                    allowed_intervals=self.intervals,
                )
            except KlineWebSocketParseError:
                self.stats.malformed_messages += 1
                continue
            if event is None:
                self.stats.acknowledgements_received += 1
                continue
            try:
                self.events.put_nowait(event)
            except asyncio.QueueFull as exc:
                self.stats.queue_overflows += 1
                raise FeedQueueFullError(
                    "Kline event queue is full; consumer is not keeping up with the stream"
                ) from exc
            self.stats.events_emitted += 1
    @staticmethod
    async def _recv_or_stop(websocket: Any, stop_event: asyncio.Event) -> str | bytes | None:
        receive_task = asyncio.create_task(websocket.recv())
        stop_task = asyncio.create_task(stop_event.wait())
        try:
            done, _ = await asyncio.wait(
                (receive_task, stop_task), return_when=asyncio.FIRST_COMPLETED
            )
            if receive_task in done:
                return receive_task.result()
            return None
        finally:
            for task in (receive_task, stop_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(receive_task, stop_task, return_exceptions=True)

    @staticmethod
    async def _wait_or_stop(stop_event: asyncio.Event, delay: float) -> None:
        if delay <= 0:
            await asyncio.sleep(0)
            return
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except TimeoutError:
            return
