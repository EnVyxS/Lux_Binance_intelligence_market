"""Bounded, fail-closed fan-out for normalized Binance Aggregate Trade events."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import re
from typing import Final

from divatrading.market_data.aggregate_trades import AggregateTradeEvent

_SYMBOL_RE: Final[re.Pattern[str]] = re.compile(r"^[A-Z0-9]{2,30}$")
DEFAULT_FANOUT_QUEUE_CAPACITY: Final[int] = 2048
MAX_FANOUT_QUEUE_CAPACITY: Final[int] = 8192
DEFAULT_MAX_FANOUT_SUBSCRIBERS: Final[int] = 32


class AggregateTradeFanoutError(RuntimeError):
    """Base class for bounded Aggregate Trade fan-out errors."""


class AggregateTradeFanoutQueueFullError(AggregateTradeFanoutError):
    """A subscriber cannot accept the next event; publishing fails closed."""


class AggregateTradeFanoutSubscriptionError(AggregateTradeFanoutError):
    """A subscription is invalid or no longer registered."""


@dataclass(frozen=True, slots=True)
class AggregateTradeFanoutStats:
    subscriber_count: int
    events_published: int
    events_delivered: int
    queue_overflows: int


class AggregateTradeEventSubscription:
    """One bounded consumer queue. The consumer owns its get/task_done cycle."""

    __slots__ = ("subscription_id", "symbol", "_queue", "_fanout")

    def __init__(
        self,
        subscription_id: int,
        symbol: str | None,
        queue: asyncio.Queue[AggregateTradeEvent],
        fanout: "AggregateTradeEventFanout",
    ) -> None:
        self.subscription_id = subscription_id
        self.symbol = symbol
        self._queue = queue
        self._fanout = fanout

    @property
    def queue_depth(self) -> int:
        return self._queue.qsize()

    @property
    def queue_capacity(self) -> int:
        return self._queue.maxsize

    async def get_event(self) -> AggregateTradeEvent:
        return await self._queue.get()

    def get_nowait(self) -> AggregateTradeEvent:
        return self._queue.get_nowait()

    def task_done(self) -> None:
        self._queue.task_done()

    def unsubscribe(self) -> bool:
        return self._fanout.unsubscribe(self)


class AggregateTradeEventFanout:
    """Copy each normalized event into bounded strategy subscriber queues.

    Publishing is synchronous and contains no await point, so capacity is
    checked for every matching subscriber before the event is delivered to any
    subscriber. If one queue is full, no subscriber receives that event and a
    hard error is raised; callers must stop/fail the strategy pipeline rather
    than silently lose data.
    """

    def __init__(
        self,
        *,
        default_queue_capacity: int = DEFAULT_FANOUT_QUEUE_CAPACITY,
        max_subscribers: int = DEFAULT_MAX_FANOUT_SUBSCRIBERS,
    ) -> None:
        self._validate_capacity(default_queue_capacity)
        if (
            isinstance(max_subscribers, bool)
            or not isinstance(max_subscribers, int)
            or not 1 <= max_subscribers <= DEFAULT_MAX_FANOUT_SUBSCRIBERS
        ):
            raise ValueError(
                f"max_subscribers must be between 1 and {DEFAULT_MAX_FANOUT_SUBSCRIBERS}"
            )
        self.default_queue_capacity = default_queue_capacity
        self.max_subscribers = max_subscribers
        self._next_id = 1
        self._subscribers: dict[int, AggregateTradeEventSubscription] = {}
        self._events_published = 0
        self._events_delivered = 0
        self._queue_overflows = 0

    @property
    def stats(self) -> AggregateTradeFanoutStats:
        return AggregateTradeFanoutStats(
            subscriber_count=len(self._subscribers),
            events_published=self._events_published,
            events_delivered=self._events_delivered,
            queue_overflows=self._queue_overflows,
        )

    def subscribe(
        self,
        *,
        symbol: str | None = None,
        queue_capacity: int | None = None,
    ) -> AggregateTradeEventSubscription:
        """Create a subscriber optionally filtered to one exact contract symbol."""
        if len(self._subscribers) >= self.max_subscribers:
            raise AggregateTradeFanoutSubscriptionError("Maximum Aggregate Trade subscribers reached")
        normalized_symbol: str | None = None
        if symbol is not None:
            if not isinstance(symbol, str):
                raise ValueError("symbol must be a string or None")
            normalized_symbol = symbol.strip().upper()
            if not _SYMBOL_RE.fullmatch(normalized_symbol):
                raise ValueError("symbol must be an exact Binance contract symbol")
        capacity = self.default_queue_capacity if queue_capacity is None else queue_capacity
        self._validate_capacity(capacity)
        subscription_id = self._next_id
        self._next_id += 1
        subscription = AggregateTradeEventSubscription(
            subscription_id,
            normalized_symbol,
            asyncio.Queue(maxsize=capacity),
            self,
        )
        self._subscribers[subscription_id] = subscription
        return subscription

    def unsubscribe(self, subscription: AggregateTradeEventSubscription) -> bool:
        if not isinstance(subscription, AggregateTradeEventSubscription):
            raise TypeError("subscription must be an AggregateTradeEventSubscription")
        current = self._subscribers.get(subscription.subscription_id)
        if current is not subscription:
            return False
        del self._subscribers[subscription.subscription_id]
        return True

    def publish(self, event: AggregateTradeEvent) -> int:
        """Atomically enqueue event to all matching subscribers; return deliveries."""
        if not isinstance(event, AggregateTradeEvent):
            raise TypeError("event must be an AggregateTradeEvent")
        targets = tuple(
            subscriber
            for subscriber in self._subscribers.values()
            if subscriber.symbol is None or subscriber.symbol == event.symbol
        )
        if any(subscriber._queue.full() for subscriber in targets):
            self._queue_overflows += 1
            full_ids = tuple(
                str(subscriber.subscription_id)
                for subscriber in targets
                if subscriber._queue.full()
            )
            raise AggregateTradeFanoutQueueFullError(
                "Aggregate Trade fan-out queue full for subscriber(s): " + ",".join(full_ids)
            )
        for subscriber in targets:
            subscriber._queue.put_nowait(event)
        self._events_published += 1
        self._events_delivered += len(targets)
        return len(targets)

    @staticmethod
    def _validate_capacity(value: int) -> None:
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or not 1 <= value <= MAX_FANOUT_QUEUE_CAPACITY
        ):
            raise ValueError(
                f"queue_capacity must be between 1 and {MAX_FANOUT_QUEUE_CAPACITY}"
            )
