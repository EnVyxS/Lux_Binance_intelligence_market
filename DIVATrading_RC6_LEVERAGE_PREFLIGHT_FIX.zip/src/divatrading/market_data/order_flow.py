"""Deterministic, continuity-aware Delta and CVD aggregation for USDⓈ-M trades."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Iterable

from divatrading.core.database import Database, utc_now_iso
from divatrading.market_data.aggregate_trade_storage import (
    AggregateTradeRepository,
    AggregateTradeStreamStateError,
    StoredAggregateTrade,
)

EXCHANGE = "BINANCE_UM"
INTERVAL_MS: dict[str, int] = {
    "1s": 1_000,
    "5s": 5_000,
    "15s": 15_000,
    "1m": 60_000,
    "5m": 300_000,
}
DEFAULT_BUCKET_INTERVALS = tuple(INTERVAL_MS)
DEFAULT_PROCESS_BATCH = 1_000
MAX_PROCESS_BATCH = 5_000
DEFAULT_MAX_DATA_AGE_MS = 10_000
DEFAULT_FUTURE_SKEW_MS = 5_000
DEFAULT_LOOKBACK_BUCKETS = 60
MAX_LOOKBACK_BUCKETS = 1_440
ZERO = Decimal("0")


class OrderFlowError(RuntimeError):
    """Base error for Delta/CVD aggregation."""


class OrderFlowNotReady(OrderFlowError):
    """Raised when raw Aggregate Trade data has not established a baseline."""


class OrderFlowIntegrityError(OrderFlowError):
    """Raised when persisted trade identities cannot form a continuous sequence."""


class OrderFlowStorageError(OrderFlowError):
    """Raised when an order-flow persistence contract is violated."""


@dataclass(frozen=True, slots=True)
class OrderFlowState:
    exchange: str
    symbol: str
    baseline_aggregate_trade_id: int
    last_processed_aggregate_trade_id: int
    cumulative_delta_base: Decimal
    cumulative_delta_quote: Decimal
    last_trade_time_ms: int | None
    status: str
    integrity_reason: str | None
    updated_at_utc: str


@dataclass(frozen=True, slots=True)
class OrderFlowSnapshot:
    symbol: str
    status: str
    continuity_valid: bool
    is_fresh: bool
    data_age_ms: int | None
    baseline_aggregate_trade_id: int
    last_processed_aggregate_trade_id: int
    last_trade_time_ms: int | None
    cvd_base: Decimal
    cvd_quote: Decimal
    bucket_interval: str
    lookback_buckets: int
    window_start_ms: int
    window_end_ms: int
    buy_volume_base: Decimal
    sell_volume_base: Decimal
    delta_base: Decimal
    buy_volume_quote: Decimal
    sell_volume_quote: Decimal
    delta_quote: Decimal
    buy_imbalance_base: Decimal
    buy_imbalance_quote: Decimal
    trade_count: int
    integrity_reason: str | None


@dataclass(frozen=True, slots=True)
class OrderFlowProcessResult:
    symbol: str
    status: str
    records_processed: int
    last_processed_aggregate_trade_id: int
    source_contiguous_aggregate_trade_id: int
    complete: bool
    next_from_id: int | None
    integrity_reason: str | None


@dataclass(slots=True)
class _BucketDelta:
    buy_base: Decimal = ZERO
    sell_base: Decimal = ZERO
    buy_quote: Decimal = ZERO
    sell_quote: Decimal = ZERO
    trade_count: int = 0
    first_id: int = 0
    last_id: int = 0
    first_time_ms: int = 0
    last_time_ms: int = 0


def _validate_symbol(symbol: str) -> str:
    if not isinstance(symbol, str):
        raise OrderFlowStorageError("symbol must be a string")
    normalized = symbol.strip().upper()
    if not normalized or not normalized.isalnum():
        raise OrderFlowStorageError("symbol must be an exact uppercase Binance contract symbol")
    return normalized


def _validate_decimal(value: Decimal, field: str, *, non_negative: bool = True) -> None:
    if not isinstance(value, Decimal) or not value.is_finite():
        raise OrderFlowStorageError(f"{field} must be a finite Decimal")
    if non_negative and value < 0:
        raise OrderFlowStorageError(f"{field} cannot be negative")


def _ratio(numerator: Decimal, denominator: Decimal) -> Decimal:
    return numerator / denominator if denominator else ZERO


class OrderFlowRepository:
    """Persist cumulative flow state and exact-decimal time buckets atomically."""

    def __init__(self, database: Database) -> None:
        self.database = database

    @staticmethod
    def _row_to_state(row) -> OrderFlowState:
        return OrderFlowState(
            exchange=row["exchange"],
            symbol=row["symbol"],
            baseline_aggregate_trade_id=int(row["baseline_aggregate_trade_id"]),
            last_processed_aggregate_trade_id=int(row["last_processed_aggregate_trade_id"]),
            cumulative_delta_base=Decimal(row["cumulative_delta_base"]),
            cumulative_delta_quote=Decimal(row["cumulative_delta_quote"]),
            last_trade_time_ms=(int(row["last_trade_time_ms"]) if row["last_trade_time_ms"] is not None else None),
            status=row["status"],
            integrity_reason=row["integrity_reason"],
            updated_at_utc=row["updated_at_utc"],
        )

    def get_state(self, *, symbol: str) -> OrderFlowState:
        normalized = _validate_symbol(symbol)
        with self.database.connection() as connection:
            row = connection.execute(
                "SELECT * FROM order_flow_state WHERE exchange=? AND symbol=?",
                (EXCHANGE, normalized),
            ).fetchone()
        if row is None:
            raise OrderFlowNotReady(f"Order-flow baseline has not been initialized for {normalized}")
        return self._row_to_state(row)

    def initialize_baseline(self, *, symbol: str, baseline_id: int) -> OrderFlowState:
        normalized = _validate_symbol(symbol)
        if isinstance(baseline_id, bool) or not isinstance(baseline_id, int) or baseline_id < 0:
            raise OrderFlowStorageError("baseline_id must be a non-negative integer")
        with self.database.transaction() as connection:
            connection.execute(
                """INSERT INTO order_flow_state(
                    exchange, symbol, baseline_aggregate_trade_id,
                    last_processed_aggregate_trade_id, cumulative_delta_base,
                    cumulative_delta_quote, last_trade_time_ms, status,
                    integrity_reason, updated_at_utc
                ) VALUES (?, ?, ?, ?, '0', '0', NULL, 'BOOTSTRAPPING', NULL, ?) 
                ON CONFLICT(exchange, symbol) DO NOTHING""",
                (EXCHANGE, normalized, baseline_id, baseline_id - 1, utc_now_iso()),
            )
            row = connection.execute(
                "SELECT baseline_aggregate_trade_id FROM order_flow_state WHERE exchange=? AND symbol=?",
                (EXCHANGE, normalized),
            ).fetchone()
            if int(row["baseline_aggregate_trade_id"]) != baseline_id:
                raise OrderFlowStorageError("Existing order-flow baseline differs; use explicit replay reset")
        return self.get_state(symbol=normalized)

    def reset_for_replay(self, *, symbol: str, baseline_id: int) -> OrderFlowState:
        """Explicitly reset derived aggregates; raw Aggregate Trade rows remain untouched."""
        normalized = _validate_symbol(symbol)
        if isinstance(baseline_id, bool) or not isinstance(baseline_id, int) or baseline_id < 0:
            raise OrderFlowStorageError("baseline_id must be a non-negative integer")
        with self.database.transaction() as connection:
            connection.execute(
                "DELETE FROM order_flow_buckets WHERE exchange=? AND symbol=?",
                (EXCHANGE, normalized),
            )
            connection.execute(
                """INSERT INTO order_flow_state(
                    exchange, symbol, baseline_aggregate_trade_id,
                    last_processed_aggregate_trade_id, cumulative_delta_base,
                    cumulative_delta_quote, last_trade_time_ms, status,
                    integrity_reason, updated_at_utc
                ) VALUES (?, ?, ?, ?, '0', '0', NULL, 'BOOTSTRAPPING', NULL, ?) 
                ON CONFLICT(exchange, symbol) DO UPDATE SET
                    baseline_aggregate_trade_id=excluded.baseline_aggregate_trade_id,
                    last_processed_aggregate_trade_id=excluded.last_processed_aggregate_trade_id,
                    cumulative_delta_base='0', cumulative_delta_quote='0',
                    last_trade_time_ms=NULL, status='BOOTSTRAPPING',
                    integrity_reason=NULL, updated_at_utc=excluded.updated_at_utc""",
                (EXCHANGE, normalized, baseline_id, baseline_id - 1, utc_now_iso()),
            )
        return self.get_state(symbol=normalized)

    def apply_batch(
        self,
        *,
        symbol: str,
        expected_previous_id: int,
        records: list[StoredAggregateTrade],
        bucket_deltas: dict[tuple[str, int], _BucketDelta],
        cumulative_delta_base: Decimal,
        cumulative_delta_quote: Decimal,
        last_trade_time_ms: int,
        source_status: str,
        integrity_reason: str | None = None,
    ) -> OrderFlowState:
        normalized = _validate_symbol(symbol)
        if source_status not in {"BOOTSTRAPPING", "HEALTHY", "DEGRADED", "UNRESOLVED"}:
            raise OrderFlowStorageError("Invalid source stream status")
        if isinstance(expected_previous_id, bool) or not isinstance(expected_previous_id, int) or expected_previous_id < -1:
            raise OrderFlowStorageError("expected_previous_id must be an integer >= -1")
        if not records or len(records) > MAX_PROCESS_BATCH:
            raise OrderFlowStorageError(f"records must contain 1..{MAX_PROCESS_BATCH} rows")
        expected_id = expected_previous_id + 1
        for stored in records:
            record = stored.record
            if record.exchange != EXCHANGE or record.symbol != normalized:
                raise OrderFlowStorageError("A flow batch must contain one BINANCE_UM symbol")
            if record.aggregate_trade_id != expected_id:
                raise OrderFlowIntegrityError(
                    f"Flow batch expected aggregate ID {expected_id}, received {record.aggregate_trade_id}"
                )
            _validate_decimal(record.quantity, "quantity")
            _validate_decimal(record.price, "price")
            if record.quantity <= 0 or record.price <= 0:
                raise OrderFlowStorageError("Trade price and quantity must be positive")
            if not isinstance(record.buyer_is_maker, bool):
                raise OrderFlowStorageError("buyer_is_maker must be boolean")
            expected_id += 1
        _validate_decimal(cumulative_delta_base, "cumulative_delta_base", non_negative=False)
        _validate_decimal(cumulative_delta_quote, "cumulative_delta_quote", non_negative=False)
        if isinstance(last_trade_time_ms, bool) or not isinstance(last_trade_time_ms, int) or last_trade_time_ms < 0:
            raise OrderFlowStorageError("last_trade_time_ms must be a non-negative integer")
        if last_trade_time_ms != records[-1].record.trade_time_ms:
            raise OrderFlowStorageError("last_trade_time_ms must match the final record in the batch")
        with self.database.transaction() as connection:
            current = connection.execute(
                "SELECT * FROM order_flow_state WHERE exchange=? AND symbol=?",
                (EXCHANGE, normalized),
            ).fetchone()
            if current is None:
                raise OrderFlowNotReady(f"Order-flow state for {normalized} disappeared")
            current_cursor = int(current["last_processed_aggregate_trade_id"])
            if current_cursor != expected_previous_id:
                raise OrderFlowStorageError("Order-flow cursor changed during batch processing")
            if current["status"] == "UNRESOLVED":
                raise OrderFlowIntegrityError("Order-flow stream is already UNRESOLVED; replay is required")
            now = utc_now_iso()
            for (interval, bucket_start), delta in bucket_deltas.items():
                if interval not in INTERVAL_MS:
                    raise OrderFlowStorageError(f"Unsupported bucket interval: {interval}")
                existing = connection.execute(
                    """SELECT * FROM order_flow_buckets
                       WHERE exchange=? AND symbol=? AND interval=? AND bucket_start_ms=?""",
                    (EXCHANGE, normalized, interval, bucket_start),
                ).fetchone()
                if existing is None:
                    connection.execute(
                        """INSERT INTO order_flow_buckets(
                            exchange, symbol, interval, bucket_start_ms,
                            buy_volume_base, sell_volume_base,
                            buy_volume_quote, sell_volume_quote, trade_count,
                            first_aggregate_trade_id, last_aggregate_trade_id,
                            first_trade_time_ms, last_trade_time_ms, updated_at_utc
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            EXCHANGE, normalized, interval, bucket_start,
                            str(delta.buy_base), str(delta.sell_base),
                            str(delta.buy_quote), str(delta.sell_quote), delta.trade_count,
                            delta.first_id, delta.last_id, delta.first_time_ms,
                            delta.last_time_ms, now,
                        ),
                    )
                else:
                    connection.execute(
                        """UPDATE order_flow_buckets SET
                            buy_volume_base=?, sell_volume_base=?,
                            buy_volume_quote=?, sell_volume_quote=?,
                            trade_count=?, first_aggregate_trade_id=?,
                            last_aggregate_trade_id=?, first_trade_time_ms=?,
                            last_trade_time_ms=?, updated_at_utc=?
                           WHERE exchange=? AND symbol=? AND interval=? AND bucket_start_ms=?""",
                        (
                            str(Decimal(existing["buy_volume_base"]) + delta.buy_base),
                            str(Decimal(existing["sell_volume_base"]) + delta.sell_base),
                            str(Decimal(existing["buy_volume_quote"]) + delta.buy_quote),
                            str(Decimal(existing["sell_volume_quote"]) + delta.sell_quote),
                            int(existing["trade_count"]) + delta.trade_count,
                            min(int(existing["first_aggregate_trade_id"]), delta.first_id),
                            max(int(existing["last_aggregate_trade_id"]), delta.last_id),
                            min(int(existing["first_trade_time_ms"]), delta.first_time_ms),
                            max(int(existing["last_trade_time_ms"]), delta.last_time_ms),
                            now, EXCHANGE, normalized, interval, bucket_start,
                        ),
                    )
            final_id = records[-1].record.aggregate_trade_id if records else expected_previous_id
            connection.execute(
                """UPDATE order_flow_state SET
                    last_processed_aggregate_trade_id=?, cumulative_delta_base=?,
                    cumulative_delta_quote=?, last_trade_time_ms=?, status=?,
                    integrity_reason=?, updated_at_utc=?
                   WHERE exchange=? AND symbol=?""",
                (
                    final_id, str(cumulative_delta_base), str(cumulative_delta_quote),
                    last_trade_time_ms, source_status, integrity_reason, now,
                    EXCHANGE, normalized,
                ),
            )
        return self.get_state(symbol=normalized)

    def set_status(self, *, symbol: str, status: str, reason: str | None = None) -> OrderFlowState:
        normalized = _validate_symbol(symbol)
        if status not in {"BOOTSTRAPPING", "HEALTHY", "DEGRADED", "UNRESOLVED"}:
            raise OrderFlowStorageError("Invalid order-flow status")
        with self.database.transaction() as connection:
            connection.execute(
                """UPDATE order_flow_state SET status=?, integrity_reason=?, updated_at_utc=?
                   WHERE exchange=? AND symbol=?""",
                (status, reason, utc_now_iso(), EXCHANGE, normalized),
            )
        return self.get_state(symbol=normalized)

    def read_window(
        self, *, symbol: str, interval: str, start_ms: int, end_ms: int
    ) -> list[dict[str, object]]:
        normalized = _validate_symbol(symbol)
        if interval not in INTERVAL_MS:
            raise OrderFlowStorageError(f"Unsupported bucket interval: {interval}")
        if any(isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in (start_ms, end_ms)):
            raise OrderFlowStorageError("window bounds must be non-negative integer milliseconds")
        if end_ms < start_ms:
            raise OrderFlowStorageError("end_ms cannot be lower than start_ms")
        with self.database.connection() as connection:
            rows = connection.execute(
                """SELECT * FROM order_flow_buckets
                   WHERE exchange=? AND symbol=? AND interval=?
                     AND bucket_start_ms>=? AND bucket_start_ms<?
                   ORDER BY bucket_start_ms ASC LIMIT ?""",
                (EXCHANGE, normalized, interval, start_ms, end_ms, MAX_LOOKBACK_BUCKETS),
            ).fetchall()
        return [dict(row) for row in rows]


class DeltaCvdService:
    """Incrementally aggregate only the gap-free Aggregate Trade ID prefix."""

    def __init__(
        self,
        trades: AggregateTradeRepository,
        order_flow: OrderFlowRepository,
        *,
        bucket_intervals: Iterable[str] = DEFAULT_BUCKET_INTERVALS,
        max_data_age_ms: int = DEFAULT_MAX_DATA_AGE_MS,
        future_skew_ms: int = DEFAULT_FUTURE_SKEW_MS,
    ) -> None:
        intervals = tuple(dict.fromkeys(bucket_intervals))
        if not intervals or any(interval not in INTERVAL_MS for interval in intervals):
            raise ValueError(f"bucket_intervals must be selected from {tuple(INTERVAL_MS)}")
        if isinstance(max_data_age_ms, bool) or not isinstance(max_data_age_ms, int) or max_data_age_ms <= 0:
            raise ValueError("max_data_age_ms must be a positive integer")
        if isinstance(future_skew_ms, bool) or not isinstance(future_skew_ms, int) or future_skew_ms < 0:
            raise ValueError("future_skew_ms must be a non-negative integer")
        self.trades = trades
        self.order_flow = order_flow
        self.bucket_intervals = intervals
        self.max_data_age_ms = max_data_age_ms
        self.future_skew_ms = future_skew_ms

    def _ensure_baseline(self, symbol: str) -> OrderFlowState:
        try:
            return self.order_flow.get_state(symbol=symbol)
        except OrderFlowNotReady:
            pass
        try:
            source_state = self.trades.get_stream_state(symbol)
        except AggregateTradeStreamStateError as exc:
            raise OrderFlowNotReady("Aggregate Trade stream must be bootstrapped first") from exc
        if source_state.last_contiguous_aggregate_trade_id < 0:
            raise OrderFlowNotReady("Aggregate Trade stream has no contiguous baseline")
        earliest = self.trades.read(symbol=symbol, from_id=0, limit=1)
        if not earliest:
            raise OrderFlowNotReady("No retained Aggregate Trade rows are available for Delta/CVD baseline")
        first_id = earliest[0].record.aggregate_trade_id
        if first_id > source_state.last_contiguous_aggregate_trade_id:
            raise OrderFlowIntegrityError("Retained trade history starts after the contiguous source cursor")
        return self.order_flow.initialize_baseline(symbol=symbol, baseline_id=first_id)

    @staticmethod
    def _add_trade(
        buckets: dict[tuple[str, int], _BucketDelta],
        record: StoredAggregateTrade,
        intervals: tuple[str, ...],
    ) -> None:
        trade = record.record
        is_buy = not trade.buyer_is_maker
        base = trade.quantity
        quote = trade.price * trade.quantity
        for interval in intervals:
            duration = INTERVAL_MS[interval]
            start = (trade.trade_time_ms // duration) * duration
            key = (interval, start)
            bucket = buckets.get(key)
            if bucket is None:
                bucket = _BucketDelta(
                    first_id=trade.aggregate_trade_id,
                    last_id=trade.aggregate_trade_id,
                    first_time_ms=trade.trade_time_ms,
                    last_time_ms=trade.trade_time_ms,
                )
                buckets[key] = bucket
            bucket.trade_count += 1
            bucket.last_id = trade.aggregate_trade_id
            bucket.last_time_ms = trade.trade_time_ms
            if is_buy:
                bucket.buy_base += base
                bucket.buy_quote += quote
            else:
                bucket.sell_base += base
                bucket.sell_quote += quote

    def process_available(
        self, *, symbol: str, max_records: int = DEFAULT_PROCESS_BATCH
    ) -> OrderFlowProcessResult:
        """Process one bounded page through the durable source contiguous cursor."""
        normalized = _validate_symbol(symbol)
        if isinstance(max_records, bool) or not isinstance(max_records, int) or not 1 <= max_records <= MAX_PROCESS_BATCH:
            raise ValueError(f"max_records must be between 1 and {MAX_PROCESS_BATCH}")
        flow = self._ensure_baseline(normalized)
        source = self.trades.get_stream_state(normalized)
        if flow.status == "UNRESOLVED":
            return OrderFlowProcessResult(
                normalized, "UNRESOLVED", 0, flow.last_processed_aggregate_trade_id,
                source.last_contiguous_aggregate_trade_id, False,
                flow.last_processed_aggregate_trade_id + 1, flow.integrity_reason,
            )
        safe_through = source.last_contiguous_aggregate_trade_id
        cursor = flow.last_processed_aggregate_trade_id
        if source.status == "BOOTSTRAPPING" and safe_through < cursor + 1:
            self.order_flow.set_status(symbol=normalized, status="BOOTSTRAPPING", reason="Waiting for a contiguous Aggregate Trade baseline")
            current = self.order_flow.get_state(symbol=normalized)
            return OrderFlowProcessResult(normalized, current.status, 0, cursor, safe_through, False, cursor + 1, current.integrity_reason)
        if safe_through <= cursor:
            status = source.status
            reason = None if status == "HEALTHY" else f"Upstream Aggregate Trade stream is {status}"
            current = self.order_flow.set_status(symbol=normalized, status=status, reason=reason)
            complete = status == "HEALTHY"
            return OrderFlowProcessResult(normalized, current.status, 0, cursor, safe_through, complete, None if complete else cursor + 1, reason)

        rows = self.trades.read(
            symbol=normalized, from_id=cursor + 1, through_id=safe_through, limit=max_records
        )
        if not rows:
            reason = f"Stored Aggregate Trade ID {cursor + 1} is missing before the source contiguous cursor {safe_through}"
            current = self.order_flow.set_status(symbol=normalized, status="UNRESOLVED", reason=reason)
            return OrderFlowProcessResult(normalized, current.status, 0, cursor, safe_through, False, cursor + 1, reason)

        expected = cursor + 1
        previous_time = flow.last_trade_time_ms
        prefix: list[StoredAggregateTrade] = []
        integrity_reason: str | None = None
        for row in rows:
            trade = row.record
            if trade.aggregate_trade_id != expected:
                integrity_reason = f"Aggregate Trade ID continuity break: expected {expected}, received {trade.aggregate_trade_id}"
                break
            if previous_time is not None and trade.trade_time_ms < previous_time:
                integrity_reason = f"Trade time regressed at aggregate trade ID {trade.aggregate_trade_id}"
                break
            prefix.append(row)
            previous_time = trade.trade_time_ms
            expected += 1

        if not prefix:
            reason = integrity_reason or "No contiguous Aggregate Trade rows available"
            current = self.order_flow.set_status(symbol=normalized, status="UNRESOLVED", reason=reason)
            return OrderFlowProcessResult(normalized, current.status, 0, cursor, safe_through, False, cursor + 1, reason)

        bucket_deltas: dict[tuple[str, int], _BucketDelta] = {}
        cvd_base = flow.cumulative_delta_base
        cvd_quote = flow.cumulative_delta_quote
        for row in prefix:
            self._add_trade(bucket_deltas, row, self.bucket_intervals)
            cvd_base += row.record.signed_quantity
            cvd_quote += row.record.signed_quote_quantity

        last_record = prefix[-1].record
        if integrity_reason:
            status = "UNRESOLVED"
        elif source.status == "UNRESOLVED":
            status = "UNRESOLVED"
        elif source.status == "DEGRADED":
            status = "DEGRADED"
        elif source.status == "BOOTSTRAPPING":
            status = "BOOTSTRAPPING"
        elif last_record.aggregate_trade_id < safe_through:
            status = "DEGRADED"
        else:
            status = "HEALTHY"
        reason = integrity_reason or (None if status == "HEALTHY" else f"Upstream/backlog status: {status}")
        try:
            updated = self.order_flow.apply_batch(
                symbol=normalized,
                expected_previous_id=cursor,
                records=prefix,
                bucket_deltas=bucket_deltas,
                cumulative_delta_base=cvd_base,
                cumulative_delta_quote=cvd_quote,
                last_trade_time_ms=last_record.trade_time_ms,
                source_status=status,
                integrity_reason=reason,
            )
        except OrderFlowStorageError:
            raise
        complete = updated.status == "HEALTHY" and updated.last_processed_aggregate_trade_id >= safe_through
        return OrderFlowProcessResult(
            normalized, updated.status, len(prefix), updated.last_processed_aggregate_trade_id,
            safe_through, complete,
            None if complete or updated.status == "UNRESOLVED" else updated.last_processed_aggregate_trade_id + 1,
            updated.integrity_reason,
        )

    def process_until_caught_up(
        self, *, symbol: str, max_passes: int = 5, records_per_pass: int = DEFAULT_PROCESS_BATCH
    ) -> OrderFlowProcessResult:
        """Run a bounded number of pages; caller can call again using persisted cursor."""
        if isinstance(max_passes, bool) or not isinstance(max_passes, int) or not 1 <= max_passes <= 20:
            raise ValueError("max_passes must be between 1 and 20")
        if isinstance(records_per_pass, bool) or not isinstance(records_per_pass, int) or not 1 <= records_per_pass <= MAX_PROCESS_BATCH:
            raise ValueError(f"records_per_pass must be between 1 and {MAX_PROCESS_BATCH}")
        result: OrderFlowProcessResult | None = None
        for _ in range(max_passes):
            result = self.process_available(symbol=symbol, max_records=records_per_pass)
            if result.complete or result.status == "UNRESOLVED" or result.records_processed == 0:
                break
        assert result is not None
        return result

    def reset_for_replay(self, *, symbol: str) -> OrderFlowState:
        """Reset derived Delta/CVD and replay from the earliest currently retained raw row."""
        normalized = _validate_symbol(symbol)
        source = self.trades.get_stream_state(normalized)
        if source.status != "HEALTHY":
            raise OrderFlowIntegrityError("Deterministic replay requires a HEALTHY Aggregate Trade source")
        earliest = self.trades.read(symbol=normalized, from_id=0, limit=1)
        if not earliest:
            raise OrderFlowNotReady("No retained raw Aggregate Trade rows are available for replay")
        first_id = earliest[0].record.aggregate_trade_id
        state = self.order_flow.reset_for_replay(symbol=normalized, baseline_id=first_id)
        return state

    def snapshot(
        self,
        *,
        symbol: str,
        interval: str = "1m",
        lookback_buckets: int = DEFAULT_LOOKBACK_BUCKETS,
        now_ms: int | None = None,
    ) -> OrderFlowSnapshot:
        normalized = _validate_symbol(symbol)
        if interval not in self.bucket_intervals:
            raise ValueError(f"interval must be one of the configured bucket intervals: {self.bucket_intervals}")
        if isinstance(lookback_buckets, bool) or not isinstance(lookback_buckets, int) or not 1 <= lookback_buckets <= MAX_LOOKBACK_BUCKETS:
            raise ValueError(f"lookback_buckets must be between 1 and {MAX_LOOKBACK_BUCKETS}")
        if now_ms is None:
            now_ms = int(datetime.now(UTC).timestamp() * 1000)
        if isinstance(now_ms, bool) or not isinstance(now_ms, int) or now_ms < 0:
            raise ValueError("now_ms must be a non-negative integer")
        flow = self.order_flow.get_state(symbol=normalized)
        source = self.trades.get_stream_state(normalized)
        if flow.status == "UNRESOLVED" or source.status == "UNRESOLVED":
            status = "UNRESOLVED"
        elif source.status != "HEALTHY" or flow.status != "HEALTHY":
            status = "DEGRADED" if source.status != "BOOTSTRAPPING" else "BOOTSTRAPPING"
        elif flow.last_processed_aggregate_trade_id < source.last_contiguous_aggregate_trade_id:
            status = "DEGRADED"
        else:
            status = "HEALTHY"
        duration = INTERVAL_MS[interval]
        current_bucket = (now_ms // duration) * duration
        window_start = max(0, current_bucket - (lookback_buckets - 1) * duration)
        window_end = current_bucket + duration
        buckets = self.order_flow.read_window(
            symbol=normalized, interval=interval, start_ms=window_start, end_ms=window_end
        )
        buy_base = sum((Decimal(str(row["buy_volume_base"])) for row in buckets), ZERO)
        sell_base = sum((Decimal(str(row["sell_volume_base"])) for row in buckets), ZERO)
        buy_quote = sum((Decimal(str(row["buy_volume_quote"])) for row in buckets), ZERO)
        sell_quote = sum((Decimal(str(row["sell_volume_quote"])) for row in buckets), ZERO)
        trade_count = sum(int(row["trade_count"]) for row in buckets)
        age = None if flow.last_trade_time_ms is None else now_ms - flow.last_trade_time_ms
        fresh = age is not None and -self.future_skew_ms <= age <= self.max_data_age_ms
        return OrderFlowSnapshot(
            symbol=normalized,
            status=status,
            continuity_valid=status == "HEALTHY",
            is_fresh=fresh,
            data_age_ms=age,
            baseline_aggregate_trade_id=flow.baseline_aggregate_trade_id,
            last_processed_aggregate_trade_id=flow.last_processed_aggregate_trade_id,
            last_trade_time_ms=flow.last_trade_time_ms,
            cvd_base=flow.cumulative_delta_base,
            cvd_quote=flow.cumulative_delta_quote,
            bucket_interval=interval,
            lookback_buckets=lookback_buckets,
            window_start_ms=window_start,
            window_end_ms=window_end,
            buy_volume_base=buy_base,
            sell_volume_base=sell_base,
            delta_base=buy_base - sell_base,
            buy_volume_quote=buy_quote,
            sell_volume_quote=sell_quote,
            delta_quote=buy_quote - sell_quote,
            buy_imbalance_base=_ratio(buy_base - sell_base, buy_base + sell_base),
            buy_imbalance_quote=_ratio(buy_quote - sell_quote, buy_quote + sell_quote),
            trade_count=trade_count,
            integrity_reason=flow.integrity_reason,
        )


__all__ = [
    "DEFAULT_BUCKET_INTERVALS",
    "DEFAULT_LOOKBACK_BUCKETS",
    "DEFAULT_MAX_DATA_AGE_MS",
    "DEFAULT_PROCESS_BATCH",
    "INTERVAL_MS",
    "MAX_LOOKBACK_BUCKETS",
    "MAX_PROCESS_BATCH",
    "DeltaCvdService",
    "OrderFlowError",
    "OrderFlowIntegrityError",
    "OrderFlowNotReady",
    "OrderFlowProcessResult",
    "OrderFlowRepository",
    "OrderFlowSnapshot",
    "OrderFlowState",
    "OrderFlowStorageError",
]
