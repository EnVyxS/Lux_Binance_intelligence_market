"""Causal sweep, reclaim, and structure-break detection from closed candles."""

from collections import deque
from dataclasses import dataclass
from decimal import Decimal

from divatrading.market_data.klines import Kline


M5_MS = 5 * 60 * 1_000
RECENT_LEVELS = 32


@dataclass(frozen=True, slots=True)
class SweepSetup:
    side: int
    confirmed_at: int
    retest_level: Decimal
    stop: Decimal
    target: Decimal
    expires_at: int


@dataclass(frozen=True, slots=True)
class _Pivot:
    price: Decimal
    confirmed_at: int


@dataclass(slots=True)
class _Sweep:
    side: int
    level: Decimal
    break_level: Decimal
    extreme: Decimal
    swept_at: int
    reclaimed_at: int | None = None


class SweepStructure:
    """Find sweeps of M15 pivots using the wick and close of M5 candles."""

    def __init__(
        self,
        tick_size: Decimal,
        *,
        swing_bars: int = 2,
        reclaim_bars: int = 2,
        confirmation_bars: int = 4,
        retest_bars: int = 4,
        stop_buffer_ticks: int = 2,
        target_buffer_ticks: int = 2,
    ) -> None:
        if not tick_size.is_finite() or tick_size <= 0:
            raise ValueError("tick size must be finite and positive")
        if min(swing_bars, reclaim_bars, confirmation_bars, retest_bars) < 1:
            raise ValueError("bar limits must be positive")
        if min(stop_buffer_ticks, target_buffer_ticks) < 1:
            raise ValueError("price buffers must be at least one tick")
        self.tick_size = tick_size
        self.swing_bars = swing_bars
        self.reclaim_ms = reclaim_bars * M5_MS
        self.confirmation_ms = confirmation_bars * M5_MS
        self.retest_ms = retest_bars * M5_MS
        self.stop_buffer = stop_buffer_ticks * tick_size
        self.target_buffer = target_buffer_ticks * tick_size
        self.reset()

    def reset(self) -> None:
        window = 2 * self.swing_bars + 1
        self._bars: dict[str, deque[Kline]] = {
            interval: deque(maxlen=window) for interval in ("5m", "15m")
        }
        self._major: dict[int, deque[_Pivot]] = {
            side: deque(maxlen=RECENT_LEVELS) for side in (1, -1)
        }
        self._minor: dict[int, _Pivot] = {}
        self.consume()

    def consume(self) -> None:
        self.signal: SweepSetup | None = None
        self._pending: _Sweep | None = None

    def on_candle(self, candle: Kline) -> None:
        bars = self._bars.get(candle.interval)
        if bars is None or (bars and candle.close_time_ms <= bars[-1].close_time_ms):
            return
        if self.signal is not None and candle.close_time_ms > self.signal.expires_at:
            self.consume()
        if candle.interval == "5m" and bars:
            self._on_m5(candle, bars[-1].close)

        bars.append(candle)
        if len(bars) == bars.maxlen:
            self._confirm_pivots(candle, tuple(bars))

    def _confirm_pivots(self, candle: Kline, bars: tuple[Kline, ...]) -> None:
        pivot = bars[self.swing_bars]
        neighbors = bars[: self.swing_bars] + bars[self.swing_bars + 1 :]
        for side, price, confirmed in (
            (1, pivot.high, all(pivot.high > bar.high for bar in neighbors)),
            (-1, pivot.low, all(pivot.low < bar.low for bar in neighbors)),
        ):
            if confirmed:
                level = _Pivot(price, candle.close_time_ms)
                if candle.interval == "15m":
                    self._major[side].append(level)
                else:
                    self._minor[side] = level

    def _on_m5(self, candle: Kline, previous_close: Decimal) -> None:
        swept_highs = self._swept_levels(1, candle.high, candle.close_time_ms)
        swept_lows = self._swept_levels(-1, candle.low, candle.close_time_ms)
        if self.signal is not None:
            side = self.signal.side
            adverse = candle.low if side == 1 else candle.high
            favorable = candle.high if side == 1 else candle.low
            if (
                side * (adverse - self.signal.stop) <= 0
                or side * (favorable - self.signal.target) >= 0
            ):
                self.consume()
            return

        if swept_highs and swept_lows:
            # OHLC cannot resolve the sequence in a two-sided sweep.
            self.consume()
            return

        if self._pending is not None:
            opposing_sweep = swept_highs if self._pending.side == 1 else swept_lows
            if opposing_sweep:
                self.consume()
            else:
                self._advance(candle, previous_close)
                if self._pending is not None or self.signal is not None:
                    return

        for side, levels, extreme in (
            (1, swept_lows, candle.low),
            (-1, swept_highs, candle.high),
        ):
            minor = self._minor.get(side)
            if levels and minor is not None and minor.confirmed_at < candle.close_time_ms:
                level = levels[-1].price
                if side * (minor.price - level) > 0:
                    self._pending = _Sweep(side, level, minor.price, extreme, candle.close_time_ms)
                    self._advance(candle, previous_close)

    def _swept_levels(self, side: int, price: Decimal, ts: int) -> list[_Pivot]:
        levels = self._major[side]
        swept = [
            pivot
            for pivot in levels
            if pivot.confirmed_at < ts
            and side * (price - pivot.price) >= self.tick_size
        ]
        if swept:
            self._major[side] = deque(
                (pivot for pivot in levels if pivot not in swept), maxlen=RECENT_LEVELS
            )
        return swept

    def _advance(self, candle: Kline, previous_close: Decimal) -> None:
        pending = self._pending
        if pending is None:
            return
        side = pending.side
        closes_reclaimed = side * (candle.close - pending.level) > 0
        adverse = candle.low if side == 1 else candle.high
        if side * (adverse - pending.extreme) < 0:
            pending.extreme = adverse

        if pending.reclaimed_at is None:
            if candle.close_time_ms - pending.swept_at > self.reclaim_ms:
                self.consume()
            elif closes_reclaimed:
                pending.reclaimed_at = candle.close_time_ms
            return

        if not closes_reclaimed or candle.close_time_ms - pending.reclaimed_at > self.confirmation_ms:
            self.consume()
            return

        if (
            candle.close_time_ms <= pending.reclaimed_at
            or side * (previous_close - pending.break_level) > 0
            or side * (candle.close - pending.break_level) <= 0
        ):
            return

        target_levels = (
            side * pivot.price
            for pivot in self._major[side]
            if pivot.confirmed_at < candle.close_time_ms and side * (pivot.price - candle.close) > 0
        )
        nearest = min(target_levels, default=None)
        self.consume()
        if nearest is None:
            return
        target = side * (nearest - self.target_buffer)
        stop = pending.extreme - side * self.stop_buffer
        if min(stop, target) > 0 and side * (target - candle.close) > 0:
            self.signal = SweepSetup(
                side=side,
                confirmed_at=candle.close_time_ms,
                retest_level=pending.break_level,
                stop=stop,
                target=target,
                expires_at=candle.close_time_ms + self.retest_ms,
            )
