"""Provenance-first intake and validation for TradingView Pine reference fixtures.

The module does not generate or infer Pine signals. It only converts the additive
TradingView CSV export fields into a fixture and verifies that the embedded candle
and signal records still match the retained source CSV exports.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Mapping
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from jsonschema import Draft202012Validator, FormatChecker

from divatrading.strategy.parity_contract import ParityContractError, ParitySignal

PINE_SOURCE_SHA256 = "46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c"
INSTRUMENTATION_ID = "DIVATrading Pine Capture Instrumentation v1"
INSTRUMENTATION_SHA256 = "4901facc8365692b51397eabc34d232d7de86a78e6f3c28e2eb894df81a160ed"
TIMEFRAME_MS = {"1m": 60_000, "5m": 300_000, "15m": 900_000}
TIMEFRAME_PINE = {"1m": "M1", "5m": "M5", "15m": "M15"}

_SIGNAL_FIELDS = (
    ("EVENT_TIME_MS", "event_time_ms"),
    ("DIRECTION", "direction"),
    ("TRIGGER", "trigger"),
    ("ENTRY_PROXY", "entry_proxy"),
    ("STOP_LOSS", "stop_loss"),
    ("TAKE_PROFIT", "take_profit"),
    ("OB_TOP", "ob_top"),
    ("OB_BOTTOM", "ob_bottom"),
    ("OB_SOURCE_TIME_MS", "ob_source_time_ms"),
    ("SETUP_SCORE", "setup_score"),
    ("OB_QUALITY_SCORE", "ob_quality_score"),
    ("TIMING_SCORE", "timing_score"),
    ("ENTRY_BAND_LOW", "entry_band_low"),
    ("ENTRY_BAND_HIGH", "entry_band_high"),
)
_SIGNAL_COLUMNS = {
    f"DIVA_{TIMEFRAME_PINE[tf]}_{suffix}"
    for tf in TIMEFRAME_MS
    for suffix, _ in _SIGNAL_FIELDS
}
_SIGNAL_COLUMNS.add("DIVA_EVALUATION_TIME_MS")
_SIGNAL_FLAGS = {
    "DIVA_M1_INDEPENDENT_FLAG",
    "DIVA_M5_NESTED_FLAG",
    "DIVA_M5_STANDALONE_FLAG",
    "DIVA_M15_PRIMARY_FLAG",
}
_SIGNAL_COLUMNS.update(_SIGNAL_FLAGS)


@dataclass(frozen=True, slots=True)
class FixtureValidationIssue:
    code: str
    path: str
    message: str


@dataclass(frozen=True, slots=True)
class FixtureValidationReport:
    accepted: bool
    fixture_sha256: str | None
    candle_counts: tuple[tuple[str, int], ...]
    signal_count: int
    issues: tuple[FixtureValidationIssue, ...]


class PineFixtureIntakeError(ValueError):
    """Raised for invalid capture manifests or TradingView CSV exports."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _decimal_text(value: str, label: str) -> str:
    raw = value.strip()
    if not raw or raw.lower() in {"na", "nan", "none", "null"}:
        raise PineFixtureIntakeError(f"{label} is empty/NA")
    try:
        parsed = Decimal(raw)
    except InvalidOperation as exc:
        raise PineFixtureIntakeError(f"{label} is not a Decimal: {raw!r}") from exc
    if not parsed.is_finite():
        raise PineFixtureIntakeError(f"{label} must be finite")
    return raw


def _timestamp_ms(raw: str, encoding: str, chart_timezone: str, label: str) -> int:
    value = raw.strip()
    if encoding in {"unix_ms", "unix_s"}:
        try:
            decimal_value = Decimal(value)
        except InvalidOperation as exc:
            raise PineFixtureIntakeError(f"{label} is not numeric") from exc
        if decimal_value != decimal_value.to_integral_value():
            raise PineFixtureIntakeError(f"{label} must be an integer timestamp")
        result = int(decimal_value)
        return result if encoding == "unix_ms" else result * 1000
    if encoding not in {"iso8601_with_offset", "iso8601_chart_timezone"}:
        raise PineFixtureIntakeError(f"unsupported timestamp_encoding: {encoding}")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise PineFixtureIntakeError(f"{label} is not ISO-8601: {value!r}") from exc
    if parsed.tzinfo is None:
        if encoding != "iso8601_chart_timezone":
            raise PineFixtureIntakeError(f"{label} lacks a UTC offset")
        try:
            zone = ZoneInfo(chart_timezone)
        except ZoneInfoNotFoundError as exc:
            raise PineFixtureIntakeError(f"unknown chart_timezone: {chart_timezone}") from exc
        first = parsed.replace(tzinfo=zone, fold=0)
        second = parsed.replace(tzinfo=zone, fold=1)
        if first.utcoffset() != second.utcoffset():
            raise PineFixtureIntakeError(f"{label} is ambiguous/nonexistent in {chart_timezone}")
        parsed = first
    elif encoding == "iso8601_chart_timezone":
        # An explicit offset is still authoritative; do not reinterpret it.
        pass
    utc_value = parsed.astimezone(timezone.utc)
    if utc_value.microsecond % 1000:
        raise PineFixtureIntakeError(f"{label} precision exceeds Unix milliseconds")
    delta = utc_value - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return delta.days * 86_400_000 + delta.seconds * 1000 + delta.microseconds // 1000


def _csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames is None:
                raise PineFixtureIntakeError(f"CSV has no header: {path.name}")
            headers = [name.strip() for name in reader.fieldnames]
            if len({name.casefold() for name in headers}) != len(headers):
                raise PineFixtureIntakeError(f"CSV has duplicate header names: {path.name}")
            rows = []
            for row_number, raw in enumerate(reader, start=2):
                if raw is None or all(value is None or not value.strip() for value in raw.values()):
                    continue
                normalized = {str(k).strip(): (v or "").strip() for k, v in raw.items()}
                rows.append(normalized)
    except OSError as exc:
        raise PineFixtureIntakeError(f"cannot read {path}: {exc}") from exc
    if not rows:
        raise PineFixtureIntakeError(f"CSV has no data rows: {path.name}")
    return headers, rows


def _header_lookup(headers: list[str]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for header in headers:
        key = header.strip().casefold()
        if key in lookup:
            raise PineFixtureIntakeError(f"duplicate normalized CSV header: {header}")
        lookup[key] = header
    return lookup


def _require_headers(headers: list[str], required: set[str], path: Path) -> dict[str, str]:
    lookup = _header_lookup(headers)
    missing = sorted(name for name in required if name.casefold() not in lookup)
    if missing:
        raise PineFixtureIntakeError(f"{path.name} is missing required columns: {', '.join(missing)}")
    return lookup


def _load_candles(
    path: Path, timeframe: str, encoding: str, chart_timezone: str
) -> list[dict[str, Any]]:
    headers, rows = _csv_rows(path)
    aliases = {"time", "open", "high", "low", "close", "volume"}
    lookup = _require_headers(headers, aliases, path)
    candles: list[dict[str, Any]] = []
    for row_number, row in enumerate(rows, start=2):
        label = f"{path.name}:{row_number}"
        open_time = _timestamp_ms(row[lookup["time"]], encoding, chart_timezone, f"{label}.time")
        candles.append({
            "open_time_ms": open_time,
            "open": _decimal_text(row[lookup["open"]], f"{label}.open"),
            "high": _decimal_text(row[lookup["high"]], f"{label}.high"),
            "low": _decimal_text(row[lookup["low"]], f"{label}.low"),
            "close": _decimal_text(row[lookup["close"]], f"{label}.close"),
            "volume": _decimal_text(row[lookup["volume"]], f"{label}.volume"),
        })
    return candles


def _optional_csv_number(row: Mapping[str, str], header: str, label: str) -> str | None:
    raw = row.get(header, "").strip()
    if not raw or raw.lower() in {"na", "nan", "none", "null"}:
        return None
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise PineFixtureIntakeError(f"{label} is not numeric: {raw!r}") from exc
    if not value.is_finite():
        raise PineFixtureIntakeError(f"{label} is not finite")
    return raw


def _integer_plot(raw: str, label: str) -> int:
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise PineFixtureIntakeError(f"{label} is not numeric") from exc
    if not value.is_finite() or value != value.to_integral_value():
        raise PineFixtureIntakeError(f"{label} must be an integer-valued plot")
    return int(value)


def _signals_from_m1_export(
    path: Path, symbol: str, encoding: str, chart_timezone: str
) -> list[dict[str, Any]]:
    headers, rows = _csv_rows(path)
    lookup = _require_headers(headers, _SIGNAL_COLUMNS | {"time"}, path)
    eval_col = lookup["diva_evaluation_time_ms"]
    chart_time_col = lookup["time"]
    signals: list[dict[str, Any]] = []
    for row_number, raw_row in enumerate(rows, start=2):
        row = {k.casefold(): v for k, v in raw_row.items()}
        eval_raw = row.get(eval_col.casefold(), "").strip()
        chart_time_raw = row.get(chart_time_col.casefold(), "").strip()
        if not eval_raw or not chart_time_raw:
            raise PineFixtureIntakeError(f"{path.name}:{row_number}: evaluation/chart time is absent")
        evaluation_time_from_plot = _integer_plot(eval_raw, f"{path.name}:{row_number}.evaluation_time_ms")
        chart_time = _timestamp_ms(
            chart_time_raw, encoding, chart_timezone, f"{path.name}:{row_number}.time"
        )
        if evaluation_time_from_plot != chart_time:
            raise PineFixtureIntakeError(
                f"{path.name}:{row_number}: DIVA evaluation timestamp does not equal M1 chart bar open"
            )
        flag_values: dict[str, int] = {}
        for flag in _SIGNAL_FLAGS:
            raw_flag = row.get(flag.casefold(), "").strip()
            if not raw_flag:
                raise PineFixtureIntakeError(f"{path.name}:{row_number}: {flag} is blank")
            flag_value = _integer_plot(raw_flag, f"{path.name}:{row_number}.{flag}")
            if flag_value not in {0, 1}:
                raise PineFixtureIntakeError(f"{path.name}:{row_number}: {flag} must be 0 or 1")
            flag_values[flag] = flag_value
        accepted_flags = {
            "1m": flag_values["DIVA_M1_INDEPENDENT_FLAG"] == 1,
            "5m": flag_values["DIVA_M5_NESTED_FLAG"] == 1 or flag_values["DIVA_M5_STANDALONE_FLAG"] == 1,
            "15m": flag_values["DIVA_M15_PRIMARY_FLAG"] == 1,
        }
        for timeframe, prefix in TIMEFRAME_PINE.items():
            event_col = f"DIVA_{prefix}_EVENT_TIME_MS".casefold()
            event_raw = row.get(event_col, "").strip()
            has_event = bool(event_raw) and event_raw.lower() not in {"na", "nan", "none", "null"}
            if has_event != accepted_flags[timeframe]:
                raise PineFixtureIntakeError(
                    f"{path.name}:{row_number}:{prefix}: event output and accepted-arbitration flag disagree"
                )
            if not has_event:
                for suffix, _ in _SIGNAL_FIELDS[1:]:
                    other = row.get(f"DIVA_{prefix}_{suffix}".casefold(), "").strip()
                    if other and other.lower() not in {"na", "nan", "none", "null"}:
                        raise PineFixtureIntakeError(
                            f"{path.name}:{row_number}:{prefix}: partial signal values exist without an event time"
                        )
                continue
            label = f"{path.name}:{row_number}:{prefix}"
            if not eval_raw:
                raise PineFixtureIntakeError(f"{label}: evaluation timestamp is absent")
            values: dict[str, Any] = {}
            for suffix, field_name in _SIGNAL_FIELDS:
                col = f"DIVA_{prefix}_{suffix}".casefold()
                raw_value = row.get(col, "").strip()
                if not raw_value or raw_value.lower() in {"na", "nan", "none", "null"}:
                    raise PineFixtureIntakeError(f"{label}: missing {suffix} value")
                if field_name in {"event_time_ms", "ob_source_time_ms", "direction", "trigger"}:
                    values[field_name] = _integer_plot(raw_value, f"{label}.{suffix}")
                else:
                    values[field_name] = _decimal_text(raw_value, f"{label}.{suffix}")
            evaluation_time = evaluation_time_from_plot
            direction_value = values.pop("direction")
            trigger_value = values.pop("trigger")
            if direction_value not in {-1, 1}:
                raise PineFixtureIntakeError(f"{label}: direction plot must be -1 or 1")
            if trigger_value not in {1, 2}:
                raise PineFixtureIntakeError(f"{label}: trigger plot must be 1 or 2")
            record = {
                "symbol": symbol,
                "timeframe": timeframe,
                "event_time_ms": values.pop("event_time_ms"),
                "evaluation_time_ms": evaluation_time,
                "direction": "BUY" if direction_value == 1 else "SELL",
                "trigger": "REJECTION" if trigger_value == 1 else "STRUCTURE",
                **values,
            }
            signals.append(record)
    return signals


def build_fixture_from_capture_manifest(manifest_path: str | Path, output_path: str | Path) -> Path:
    """Build a v2 JSON fixture from three retained TradingView chart CSV exports."""
    manifest_file = Path(manifest_path).resolve()
    output_file = Path(output_path).resolve()
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PineFixtureIntakeError(f"cannot load capture manifest: {exc}") from exc
    try:
        provenance = manifest["provenance"]
        replay = manifest["replay"]
        capture_files = manifest["capture_files"]
        coverage = manifest["coverage"]
        encoding = manifest["timestamp_encoding"]
        symbol = replay["symbol"]
        source_dir = manifest_file.parent
        candle_series: dict[str, list[dict[str, Any]]] = {}
        exports: dict[str, dict[str, Any]] = {}
        for timeframe in TIMEFRAME_MS:
            file_name = capture_files[timeframe]
            if Path(file_name).name != file_name or file_name in {".", ".."}:
                raise PineFixtureIntakeError(f"capture_files.{timeframe} must be a local file name")
            csv_path = (source_dir / file_name).resolve()
            if source_dir not in csv_path.parents:
                raise PineFixtureIntakeError("capture export path escapes manifest directory")
            if not csv_path.is_file():
                raise PineFixtureIntakeError(f"missing source export: {csv_path}")
            candle_series[timeframe] = _load_candles(
                csv_path, timeframe, encoding, provenance["chart_timezone"]
            )
            exports[timeframe] = {
                "file_name": file_name,
                "sha256": _sha256(csv_path),
                "size_bytes": csv_path.stat().st_size,
                "contains_signal_plots": timeframe == "1m",
            }
        signals = _signals_from_m1_export(
            source_dir / capture_files["1m"], symbol, encoding, provenance["chart_timezone"]
        )
        fixture = {
            "fixture_version": 2,
            "provenance": {
                **provenance,
                "instrumentation_id": INSTRUMENTATION_ID,
                "instrumentation_patch_sha256": INSTRUMENTATION_SHA256,
                "timestamp_encoding": encoding,
            },
            "replay": {
                **replay,
                "first_bar_open_time_ms_by_timeframe": {
                    tf: candles[0]["open_time_ms"] for tf, candles in candle_series.items()
                },
                "last_bar_open_time_ms_by_timeframe": {
                    tf: candles[-1]["open_time_ms"] for tf, candles in candle_series.items()
                },
            },
            "source_exports": exports,
            "candle_series": candle_series,
            "coverage": coverage,
            "reference_signals": signals,
            "engine_observations": [],
        }
    except (KeyError, TypeError) as exc:
        raise PineFixtureIntakeError(f"capture manifest is missing/invalid field: {exc}") from exc

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(fixture, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return output_file


def _issue(code: str, path: str, message: str) -> FixtureValidationIssue:
    return FixtureValidationIssue(code=code, path=path, message=message)


def validate_reference_fixture(
    fixture_path: str | Path,
    *,
    source_dir: str | Path | None = None,
    schema_path: str | Path | None = None,
) -> FixtureValidationReport:
    """Validate schema, semantic integrity and hashes/content of retained CSV exports."""
    fixture_file = Path(fixture_path).resolve()
    issues: list[FixtureValidationIssue] = []
    try:
        raw_bytes = fixture_file.read_bytes()
        fixture = json.loads(raw_bytes)
    except (OSError, json.JSONDecodeError) as exc:
        return FixtureValidationReport(False, None, (), 0, (_issue("FIXTURE_READ_ERROR", "$", str(exc)),))
    fixture_hash = hashlib.sha256(raw_bytes).hexdigest()
    schema_file = Path(schema_path).resolve() if schema_path else Path(__file__).with_name(
        "reference_fixture.v2.schema.json"
    )
    try:
        schema = json.loads(schema_file.read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema, format_checker=FormatChecker())
        for error in sorted(validator.iter_errors(fixture), key=lambda item: list(map(str, item.path))):
            location = "$" + "".join(f"[{part}]" if isinstance(part, int) else f".{part}" for part in error.path)
            issues.append(_issue("SCHEMA_ERROR", location, error.message))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return FixtureValidationReport(False, fixture_hash, (), 0, (_issue("SCHEMA_LOAD_ERROR", "$", str(exc)),))
    if issues:
        return FixtureValidationReport(False, fixture_hash, (), 0, tuple(issues))

    provenance = fixture["provenance"]
    replay = fixture["replay"]
    symbol = replay["symbol"]
    expected_ticker = f"BINANCE:{symbol}.P"
    if provenance["tradingview_ticker_id"] != expected_ticker:
        issues.append(_issue("TICKER_SYMBOL_MISMATCH", "$.provenance.tradingview_ticker_id",
                             f"expected {expected_ticker!r} for Binance USD-M perpetual {symbol}"))
    if replay["warmup_bars"] != provenance["effective_inputs"]["warmupBars"]:
        issues.append(_issue("WARMUP_INPUT_MISMATCH", "$.replay.warmup_bars",
                             "must equal effective_inputs.warmupBars"))
    if provenance["timestamp_encoding"] == "iso8601_chart_timezone":
        try:
            ZoneInfo(provenance["chart_timezone"])
        except ZoneInfoNotFoundError:
            issues.append(_issue("INVALID_TIMEZONE", "$.provenance.chart_timezone", "unknown IANA timezone"))
    try:
        captured_at = datetime.fromisoformat(provenance["captured_at_utc"].replace("Z", "+00:00"))
        if captured_at.tzinfo is None or captured_at.utcoffset().total_seconds() != 0:
            issues.append(_issue("CAPTURE_TIME_NOT_UTC", "$.provenance.captured_at_utc",
                                 "capture timestamp must include an explicit UTC offset"))
    except (ValueError, AttributeError):
        captured_at = None
        issues.append(_issue("INVALID_CAPTURE_TIME", "$.provenance.captured_at_utc",
                             "capture timestamp must be valid ISO-8601 date-time"))

    tick = Decimal(provenance["tick_size"])
    candle_counts: list[tuple[str, int]] = []
    for timeframe, duration in TIMEFRAME_MS.items():
        candles = fixture["candle_series"][timeframe]
        candle_counts.append((timeframe, len(candles)))
        if not candles:
            continue
        expected_first = replay["first_bar_open_time_ms_by_timeframe"][timeframe]
        expected_last = replay["last_bar_open_time_ms_by_timeframe"][timeframe]
        if candles[0]["open_time_ms"] != expected_first:
            issues.append(_issue("FIRST_BAR_MISMATCH", f"$.candle_series.{timeframe}[0].open_time_ms",
                                 "does not match replay first_bar_open_time_ms"))
        if candles[-1]["open_time_ms"] != expected_last:
            issues.append(_issue("LAST_BAR_MISMATCH", f"$.candle_series.{timeframe}[-1].open_time_ms",
                                 "does not match replay last_bar_open_time_ms"))
        previous = None
        for index, candle in enumerate(candles):
            current = candle["open_time_ms"]
            path = f"$.candle_series.{timeframe}[{index}]"
            if current % duration:
                issues.append(_issue("MISALIGNED_CANDLE_TIME", path + ".open_time_ms",
                                     f"open time must align to {duration} ms UTC grid"))
            if previous is not None and current - previous != duration:
                issues.append(_issue("CANDLE_GAP_OR_DUPLICATE", path + ".open_time_ms",
                                     f"expected contiguous {duration} ms spacing after {previous}"))
            previous = current
            values = {name: Decimal(candle[name]) for name in ("open", "high", "low", "close", "volume")}
            if values["low"] > min(values["open"], values["close"]) or values["high"] < max(values["open"], values["close"]):
                issues.append(_issue("INVALID_OHLC_RANGE", path, "low/high do not contain open and close"))
            if values["high"] < values["low"]:
                issues.append(_issue("INVALID_OHLC_RANGE", path, "high is below low"))
            for name in ("open", "high", "low", "close"):
                if values[name] % tick:
                    issues.append(_issue("PRICE_OFF_TICK_GRID", path + "." + name,
                                         f"{values[name]} is not a multiple of tick_size {tick}"))
    if captured_at is not None:
        capture_delta = captured_at.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
        capture_ms = capture_delta.days * 86_400_000 + capture_delta.seconds * 1000 + capture_delta.microseconds // 1000
        for timeframe, candles in fixture["candle_series"].items():
            if candles and candles[-1]["open_time_ms"] > capture_ms:
                issues.append(_issue("CANDLE_AFTER_CAPTURE_TIME", f"$.candle_series.{timeframe}[-1]",
                                     "last source candle opens after fixture capture time"))
    coverage = fixture["coverage"]
    if coverage["start_time_ms"] > coverage["end_time_ms"]:
        issues.append(_issue("INVALID_COVERAGE_RANGE", "$.coverage", "start_time_ms must be <= end_time_ms"))
    if coverage["assert_no_other_signals"] and not coverage["complete"]:
        issues.append(_issue("INCOMPLETE_NEGATIVE_COVERAGE", "$.coverage",
                             "cannot assert no other signals when coverage is incomplete"))
    first_m1 = replay["first_bar_open_time_ms_by_timeframe"]["1m"]
    last_m1 = replay["last_bar_open_time_ms_by_timeframe"]["1m"]
    for timeframe in ("5m", "15m"):
        expected_last_open = (last_m1 // TIMEFRAME_MS[timeframe]) * TIMEFRAME_MS[timeframe]
        actual_last_open = replay["last_bar_open_time_ms_by_timeframe"][timeframe]
        if actual_last_open != expected_last_open:
            issues.append(_issue("MTF_LAST_BAR_BOUNDARY_MISMATCH",
                                 f"$.replay.last_bar_open_time_ms_by_timeframe.{timeframe}",
                                 f"must match the active {timeframe} bar containing the last M1 chart bar"))
    if not (first_m1 <= coverage["start_time_ms"] <= coverage["end_time_ms"] <= last_m1 + TIMEFRAME_MS["1m"]):
        issues.append(_issue("COVERAGE_OUTSIDE_M1_HISTORY", "$.coverage",
                             "comparison interval must be inside the captured M1 source history"))

    signals = fixture["reference_signals"]
    candles_by_timeframe = {
        timeframe: {candle["open_time_ms"]: candle for candle in fixture["candle_series"][timeframe]}
        for timeframe in TIMEFRAME_MS
    }
    seen: set[tuple[str, str, int, str]] = set()
    for index, signal in enumerate(signals):
        path = f"$.reference_signals[{index}]"
        if signal["symbol"] != symbol:
            issues.append(_issue("SIGNAL_SYMBOL_MISMATCH", path + ".symbol", "signal symbol must match replay symbol"))
        tf_duration = TIMEFRAME_MS[signal["timeframe"]]
        if signal["event_time_ms"] % tf_duration or signal["ob_source_time_ms"] % tf_duration:
            issues.append(_issue("SIGNAL_TIME_MISALIGNED", path,
                                 "event and OB source times must align to the signal timeframe"))
        event_candle = candles_by_timeframe[signal["timeframe"]].get(signal["event_time_ms"])
        if event_candle is None:
            issues.append(_issue("SIGNAL_EVENT_CANDLE_MISSING", path + ".event_time_ms",
                                 "signal event time must exist in captured source timeframe candles"))
        elif Decimal(signal["entry_proxy"]) != Decimal(event_candle["close"]):
            issues.append(_issue("ENTRY_PROXY_NOT_SOURCE_CLOSE", path + ".entry_proxy",
                                 "Pine signal entry proxy must equal close of its event-time source candle"))
        if signal["ob_source_time_ms"] not in candles_by_timeframe[signal["timeframe"]]:
            issues.append(_issue("OB_SOURCE_CANDLE_MISSING", path + ".ob_source_time_ms",
                                 "OB source time must exist in captured source timeframe candles"))
        if not (coverage["start_time_ms"] <= signal["evaluation_time_ms"] <= coverage["end_time_ms"]):
            issues.append(_issue("SIGNAL_OUTSIDE_COVERAGE", path + ".evaluation_time_ms",
                                 "signal evaluation time is outside declared coverage"))
        try:
            direction = signal["direction"]
            trigger = signal["trigger"]
            normalized = ParitySignal(
                symbol=signal["symbol"], timeframe=signal["timeframe"],
                event_time_ms=signal["event_time_ms"], evaluation_time_ms=signal["evaluation_time_ms"],
                direction=direction, trigger=trigger, ob_source_time_ms=signal["ob_source_time_ms"],
                entry_proxy=Decimal(signal["entry_proxy"]), stop_loss=Decimal(signal["stop_loss"]),
                take_profit=Decimal(signal["take_profit"]), ob_top=Decimal(signal["ob_top"]),
                ob_bottom=Decimal(signal["ob_bottom"]), entry_band_low=Decimal(signal["entry_band_low"]),
                entry_band_high=Decimal(signal["entry_band_high"]), setup_score=Decimal(signal["setup_score"]),
                ob_quality_score=Decimal(signal["ob_quality_score"]), timing_score=Decimal(signal["timing_score"]),
            )
            if normalized.key in seen:
                issues.append(_issue("DUPLICATE_SIGNAL", path, f"duplicate signal identity {normalized.key}"))
            seen.add(normalized.key)
            for field_name in ("entry_proxy", "stop_loss", "take_profit", "ob_top", "ob_bottom", "entry_band_low", "entry_band_high"):
                if Decimal(signal[field_name]) % tick:
                    issues.append(_issue("SIGNAL_PRICE_OFF_TICK_GRID", path + "." + field_name,
                                         f"price is not a multiple of tick_size {tick}"))
        except (ParityContractError, InvalidOperation) as exc:
            issues.append(_issue("INVALID_SIGNAL_SEMANTICS", path, str(exc)))

    root = Path(source_dir).resolve() if source_dir else fixture_file.parent
    for timeframe, metadata in fixture["source_exports"].items():
        file_name = metadata["file_name"]
        source_path = (root / file_name).resolve()
        if root not in source_path.parents:
            issues.append(_issue("EXPORT_PATH_ESCAPE", f"$.source_exports.{timeframe}.file_name",
                                 "source export must remain within source_dir"))
            continue
        if not source_path.is_file():
            issues.append(_issue("SOURCE_EXPORT_MISSING", f"$.source_exports.{timeframe}",
                                 f"source CSV not found: {source_path}"))
            continue
        actual_size = source_path.stat().st_size
        actual_hash = _sha256(source_path)
        if actual_size != metadata["size_bytes"] or actual_hash != metadata["sha256"]:
            issues.append(_issue("SOURCE_EXPORT_HASH_MISMATCH", f"$.source_exports.{timeframe}",
                                 "source CSV size/hash does not match fixture manifest"))
            continue
        try:
            export_candles = _load_candles(
                source_path, timeframe, provenance["timestamp_encoding"], provenance["chart_timezone"]
            )
            if export_candles != fixture["candle_series"][timeframe]:
                issues.append(_issue("SOURCE_CANDLE_CONTENT_MISMATCH", f"$.candle_series.{timeframe}",
                                     "embedded OHLCV differs from its raw TradingView CSV export"))
            if timeframe == "1m":
                export_signals = _signals_from_m1_export(
                    source_path, symbol, provenance["timestamp_encoding"], provenance["chart_timezone"]
                )
                if export_signals != signals:
                    issues.append(_issue("SOURCE_SIGNAL_CONTENT_MISMATCH", "$.reference_signals",
                                         "normalized signals differ from raw M1 CSV plot values"))
        except PineFixtureIntakeError as exc:
            issues.append(_issue("SOURCE_EXPORT_PARSE_ERROR", f"$.source_exports.{timeframe}", str(exc)))

    return FixtureValidationReport(
        accepted=not issues,
        fixture_sha256=fixture_hash,
        candle_counts=tuple(candle_counts),
        signal_count=len(signals),
        issues=tuple(issues),
    )
