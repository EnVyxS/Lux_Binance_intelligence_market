"""Deterministic SMC V2 market-structure engine for Binance USD-M scalping.

The engine consumes only validated, closed candles from ScalpingMarketDataView.
M1 and M5 maintain independent swing/internal state; M15 is advisory context.
No OB, displacement, FVG, sweep, entry, risk, or execution logic lives here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
import hashlib
import json
from typing import Any, Literal

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineIntervalSnapshot
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataInputError,
    ScalpingMarketDataView,
)

LayerName = Literal["SWING", "INTERNAL"]
PivotKind = Literal["HIGH", "LOW"]
EventKind = Literal["BOS", "CHoCH"]

_TIMEFRAME_ORDER = ("1m", "5m", "15m")
_TIMEFRAME_MS = INTERVAL_MILLISECONDS
_LAYER_SETTINGS = {
    "SWING": ("swing_left_bars", "swing_right_bars"),
    "INTERNAL": ("internal_left_bars", "internal_right_bars"),
}


class ScalpingMarketStructureError(ValueError):
    """Base error for V2 market-structure inputs or replay state."""


class ScalpingMarketStructureInputError(ScalpingMarketStructureError):
    """Raised when a snapshot or candle violates the V2 structure contract."""


class ScalpingMarketStructureContinuityError(ScalpingMarketStructureError):
    """Raised when incremental snapshots cannot be safely joined to prior state."""


class ScalpingMarketStructureCapacityError(ScalpingMarketStructureError):
    """Raised when the configured symbol-state budget would be exceeded."""


def _direction_name(direction: int) -> str:
    return "BULLISH" if direction > 0 else "BEARISH" if direction < 0 else "NEUTRAL"


def _hash_id(*parts: object) -> str:
    payload = "|".join(str(part) for part in parts).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def _decimal_text(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


@dataclass(frozen=True, slots=True)
class StructureTimeframeSettings:
    """Optional per-timeframe pivot sensitivity override."""

    timeframe: str
    swing_left_bars: int
    swing_right_bars: int
    internal_left_bars: int
    internal_right_bars: int

    def __post_init__(self) -> None:
        if self.timeframe not in _TIMEFRAME_ORDER:
            raise ValueError("timeframe settings must target 1m, 5m or 15m")
        for name in (
            "swing_left_bars", "swing_right_bars", "internal_left_bars", "internal_right_bars"
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 50:
                raise ValueError(f"{name} must be an integer between 1 and 50")


@dataclass(frozen=True, slots=True)
class ScalpingMarketStructureConfig:
    """Bounded structure sensitivity settings.

    Defaults (swing 3/3, internal 1/1) are scaffolding for deterministic replay,
    not calibrated trading recommendations. Per-timeframe overrides allow M1,
    M5 and M15 sensitivity to be tuned independently after historical replay.
    """

    swing_left_bars: int = 3
    swing_right_bars: int = 3
    internal_left_bars: int = 1
    internal_right_bars: int = 1
    timeframe_settings: tuple[StructureTimeframeSettings, ...] = ()
    max_symbols: int = 16
    max_pivots_per_layer: int = 256
    max_events_per_timeframe: int = 512
    max_bar_traces_per_timeframe: int = 1500
    enable_m15_context: bool = True

    def __post_init__(self) -> None:
        for name in (
            "swing_left_bars", "swing_right_bars", "internal_left_bars", "internal_right_bars"
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 50:
                raise ValueError(f"{name} must be an integer between 1 and 50")
        try:
            overrides = tuple(self.timeframe_settings)
        except TypeError as exc:
            raise ValueError("timeframe_settings must be an iterable of StructureTimeframeSettings") from exc
        if any(not isinstance(item, StructureTimeframeSettings) for item in overrides):
            raise ValueError("timeframe_settings must contain StructureTimeframeSettings values")
        if len({item.timeframe for item in overrides}) != len(overrides):
            raise ValueError("timeframe_settings cannot contain duplicate intervals")
        object.__setattr__(self, "timeframe_settings", overrides)
        for name, low, high in (
            ("max_symbols", 1, 32),
            ("max_pivots_per_layer", 8, 2048),
            ("max_events_per_timeframe", 8, 4096),
            ("max_bar_traces_per_timeframe", 8, 5000),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise ValueError(f"{name} must be between {low} and {high}")
        if not isinstance(self.enable_m15_context, bool):
            raise ValueError("enable_m15_context must be boolean")

    def settings_for(self, timeframe: str) -> StructureTimeframeSettings:
        """Return explicit interval override or the base sensitivity values."""
        for item in self.timeframe_settings:
            if item.timeframe == timeframe:
                return item
        return StructureTimeframeSettings(
            timeframe=timeframe,
            swing_left_bars=self.swing_left_bars,
            swing_right_bars=self.swing_right_bars,
            internal_left_bars=self.internal_left_bars,
            internal_right_bars=self.internal_right_bars,
        )

    @property
    def max_left_bars(self) -> int:
        return max(self.swing_left_bars, self.internal_left_bars)

    @property
    def max_right_bars(self) -> int:
        return max(self.swing_right_bars, self.internal_right_bars)


@dataclass(frozen=True, slots=True)
class StructurePivot:
    pivot_id: str
    symbol: str
    timeframe: str
    layer: LayerName
    kind: PivotKind
    price: Decimal
    source_open_time_ms: int
    confirmation_close_time_ms: int
    source_index: int
    confirmation_index: int


@dataclass(frozen=True, slots=True)
class StructurePivotState:
    pivot: StructurePivot
    broken: bool


@dataclass(frozen=True, slots=True)
class StructureEvent:
    event_id: str
    symbol: str
    timeframe: str
    layer: LayerName
    event_type: EventKind
    direction: int
    broken_level: Decimal
    pivot_id: str
    pivot_price: Decimal
    pivot_source_open_time_ms: int
    pivot_confirmation_close_time_ms: int
    break_bar_open_time_ms: int
    confirmation_time_ms: int
    previous_close: Decimal
    confirmation_close: Decimal
    protected_pivot_id: str | None
    protected_price: Decimal | None
    protected_kind: PivotKind | None

    @property
    def direction_name(self) -> str:
        return _direction_name(self.direction)


@dataclass(frozen=True, slots=True)
class StructureLayerSnapshot:
    layer: LayerName
    direction: int
    direction_name: str
    protected_high: StructurePivot | None
    protected_low: StructurePivot | None
    latest_event: StructureEvent | None


@dataclass(frozen=True, slots=True)
class StructureBarTrace:
    symbol: str
    timeframe: str
    bar_index: int
    bar_open_time_ms: int
    confirmation_time_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    new_pivots: tuple[StructurePivot, ...]
    events: tuple[StructureEvent, ...]
    swing: StructureLayerSnapshot
    internal: StructureLayerSnapshot

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "BAR_TRACE",
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "bar_index": self.bar_index,
            "bar_open_time_ms": self.bar_open_time_ms,
            "confirmation_time_ms": self.confirmation_time_ms,
            "ohlc": {
                "open": _decimal_text(self.open),
                "high": _decimal_text(self.high),
                "low": _decimal_text(self.low),
                "close": _decimal_text(self.close),
            },
            "new_pivots": [_pivot_to_dict(item) for item in self.new_pivots],
            "events": [_event_to_dict(item) for item in self.events],
            "swing": _layer_to_dict(self.swing),
            "internal": _layer_to_dict(self.internal),
        }


@dataclass(frozen=True, slots=True)
class StructureTimeframeResult:
    symbol: str
    timeframe: str
    status: str
    reason_codes: tuple[str, ...]
    bars_processed: int
    warmup_required_bars: int
    warmup_remaining_bars: int
    latest_bar_open_time_ms: int | None
    latest_confirmation_time_ms: int | None
    pivots: tuple[StructurePivotState, ...]
    events: tuple[StructureEvent, ...]
    bar_traces: tuple[StructureBarTrace, ...]
    swing: StructureLayerSnapshot
    internal: StructureLayerSnapshot

    @property
    def ready(self) -> bool:
        return self.status == "READY"


@dataclass(frozen=True, slots=True)
class ScalpingMarketStructureResult:
    symbol: str
    captured_at_ms: int
    timeframes: tuple[StructureTimeframeResult, ...]
    m1_setup_ready: bool
    m5_setup_ready: bool
    m15_context_available: bool

    def timeframe(self, interval: str) -> StructureTimeframeResult | None:
        return next((item for item in self.timeframes if item.timeframe == interval), None)

    def to_jsonl(self) -> str:
        """Serialize retained bar traces in stable timeframe/bar order."""
        records = [
            trace.to_dict()
            for timeframe in self.timeframes
            for trace in timeframe.bar_traces
        ]
        return "\n".join(
            json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for item in records
        )


@dataclass(slots=True)
class _TrackedPivot:
    pivot: StructurePivot
    broken: bool = False


@dataclass(slots=True)
class _LayerState:
    layer: LayerName
    direction: int = 0
    pivots: list[_TrackedPivot] = field(default_factory=list)
    protected_high: StructurePivot | None = None
    protected_low: StructurePivot | None = None
    latest_event: StructureEvent | None = None


@dataclass(slots=True)
class _TimeframeState:
    symbol: str
    timeframe: str
    bars_processed: int = 0
    last_candle: Kline | None = None
    history_window: list[tuple[int, Kline]] = field(default_factory=list)
    swing: _LayerState = field(default_factory=lambda: _LayerState("SWING"))
    internal: _LayerState = field(default_factory=lambda: _LayerState("INTERNAL"))
    events: list[StructureEvent] = field(default_factory=list)
    traces: list[StructureBarTrace] = field(default_factory=list)


class ScalpingMarketStructureEngine:
    """Incremental, per-symbol/timeframe confirmed market-structure engine."""

    def __init__(self, *, config: ScalpingMarketStructureConfig | None = None) -> None:
        self.config = config or ScalpingMarketStructureConfig()
        self._states: dict[tuple[str, str], _TimeframeState] = {}

    def reset(self, *, symbol: str | None = None, timeframe: str | None = None) -> None:
        """Clear all state, one symbol, or one symbol/timeframe partition."""
        if timeframe is not None and timeframe not in _TIMEFRAME_ORDER:
            raise ValueError("timeframe must be 1m, 5m or 15m")
        if symbol is None and timeframe is not None:
            raise ValueError("symbol is required when resetting one timeframe")
        if symbol is None and timeframe is None:
            self._states.clear()
            return
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized:
            raise ValueError("symbol must be a non-empty string")
        keys = [
            key for key in self._states
            if key[0] == normalized and (timeframe is None or key[1] == timeframe)
        ]
        for key in keys:
            del self._states[key]

    def process(self, view: ScalpingMarketDataView) -> ScalpingMarketStructureResult:
        """Process newly closed candles from a validated V2 market-data view.

        The view's data readiness is honored independently by timeframe. M15 is
        never consulted as a veto for M1/M5. A gap/correction or missing overlap
        requires an explicit reset and fresh bounded history replay.
        """
        if not isinstance(view, ScalpingMarketDataView):
            raise ScalpingMarketStructureInputError("view must be a ScalpingMarketDataView")
        if not view.readiness.instrument_price_grid_ready:
            results = tuple(
                self._unavailable(view, interval, "INSTRUMENT_PRICE_GRID_NOT_READY")
                for interval in _TIMEFRAME_ORDER
                if interval != "15m" or self.config.enable_m15_context
            )
            return ScalpingMarketStructureResult(
                view.symbol, view.captured_at_ms, results, False, False, False
            )

        results: list[StructureTimeframeResult] = []
        permissions = {
            "1m": view.readiness.m1_setup_ready,
            "5m": view.readiness.m5_setup_ready,
            "15m": self.config.enable_m15_context and view.readiness.m15_context_available,
        }
        ready_inputs: dict[str, tuple[KlineIntervalSnapshot, tuple[Kline, ...]]] = {}
        unavailable: dict[str, str] = {}

        # Preflight every participating source before mutating any timeframe
        # state. A corrupt M5 snapshot must not leave M1 half-advanced.
        for interval in _TIMEFRAME_ORDER:
            if interval == "15m" and not self.config.enable_m15_context:
                continue
            snapshot = view.kline(interval)
            if not permissions[interval] or snapshot is None or not snapshot.ready:
                unavailable[interval] = (
                    "TIMEFRAME_DATA_NOT_READY"
                    if snapshot is None or not snapshot.ready
                    else "TIMEFRAME_PERMISSION_CLOSED"
                )
                continue
            candles = tuple(snapshot.candles)
            self._validate_candles(view, snapshot, candles)
            known_symbols = {key[0] for key in self._states}
            if view.symbol not in known_symbols and len(known_symbols) >= self.config.max_symbols:
                raise ScalpingMarketStructureCapacityError(
                    f"structure engine symbol cap reached ({self.config.max_symbols})"
                )
            existing = self._states.get((view.symbol, interval))
            if existing is not None:
                # This is a non-mutating continuity check. The same validated
                # series is passed to the processing phase below.
                self._new_candles(existing, candles)
            ready_inputs[interval] = (snapshot, candles)

        for interval in _TIMEFRAME_ORDER:
            if interval == "15m" and not self.config.enable_m15_context:
                continue
            if interval in unavailable:
                results.append(self._unavailable(view, interval, unavailable[interval]))
                continue
            snapshot, candles = ready_inputs[interval]
            results.append(self._process_timeframe(view, snapshot, candles))

        by_tf = {item.timeframe: item for item in results}
        m1 = by_tf.get("1m")
        m5 = by_tf.get("5m")
        m15 = by_tf.get("15m")
        return ScalpingMarketStructureResult(
            symbol=view.symbol,
            captured_at_ms=view.captured_at_ms,
            timeframes=tuple(results),
            m1_setup_ready=bool(m1 and m1.ready),
            m5_setup_ready=bool(m5 and m5.ready),
            m15_context_available=bool(m15 and m15.ready),
        )

    def _unavailable(
        self, view: ScalpingMarketDataView, timeframe: str, reason: str
    ) -> StructureTimeframeResult:
        state = self._states.get((view.symbol, timeframe))
        if state is None:
            state = _TimeframeState(view.symbol, timeframe)
        swing = self._layer_snapshot(state.swing)
        internal = self._layer_snapshot(state.internal)
        required = self._warmup_required(timeframe)
        return StructureTimeframeResult(
            symbol=view.symbol,
            timeframe=timeframe,
            status="UNAVAILABLE",
            reason_codes=(reason,),
            bars_processed=state.bars_processed,
            warmup_required_bars=required,
            warmup_remaining_bars=max(0, required - state.bars_processed),
            latest_bar_open_time_ms=None if state.last_candle is None else state.last_candle.open_time_ms,
            latest_confirmation_time_ms=None if state.last_candle is None else state.last_candle.close_time_ms,
            pivots=self._pivot_snapshots(state),
            events=tuple(state.events),
            bar_traces=tuple(state.traces),
            swing=swing,
            internal=internal,
        )

    def _process_timeframe(
        self,
        view: ScalpingMarketDataView,
        snapshot: KlineIntervalSnapshot,
        candles: tuple[Kline, ...],
    ) -> StructureTimeframeResult:
        interval = snapshot.interval
        key = (view.symbol, interval)
        state = self._states.get(key)
        if state is None:
            state = _TimeframeState(view.symbol, interval)
            self._states[key] = state

        new_candles = self._new_candles(state, candles)
        for candle in new_candles:
            self._process_candle(state, candle)

        required = self._warmup_required(interval)
        remaining = max(0, required - state.bars_processed)
        status = "READY" if remaining == 0 else "WARMING_UP"
        return StructureTimeframeResult(
            symbol=view.symbol,
            timeframe=interval,
            status=status,
            reason_codes=() if status == "READY" else ("STRUCTURE_WARMUP_INCOMPLETE",),
            bars_processed=state.bars_processed,
            warmup_required_bars=required,
            warmup_remaining_bars=remaining,
            latest_bar_open_time_ms=None if state.last_candle is None else state.last_candle.open_time_ms,
            latest_confirmation_time_ms=None if state.last_candle is None else state.last_candle.close_time_ms,
            pivots=self._pivot_snapshots(state),
            events=tuple(state.events),
            bar_traces=tuple(state.traces),
            swing=self._layer_snapshot(state.swing),
            internal=self._layer_snapshot(state.internal),
        )

    def _validate_candles(
        self,
        view: ScalpingMarketDataView,
        snapshot: KlineIntervalSnapshot,
        candles: tuple[Kline, ...],
    ) -> None:
        if snapshot.symbol != view.symbol or snapshot.interval not in _TIMEFRAME_MS:
            raise ScalpingMarketStructureInputError("Kline snapshot identity mismatch")
        previous: Kline | None = None
        interval_ms = _TIMEFRAME_MS[snapshot.interval]
        for candle in candles:
            if not isinstance(candle, Kline):
                raise ScalpingMarketStructureInputError("closed candle series must contain Kline values")
            if candle.exchange != "BINANCE_UM" or candle.symbol != view.symbol or candle.interval != snapshot.interval:
                raise ScalpingMarketStructureInputError("candle exchange/symbol/timeframe identity mismatch")
            if candle.close_time_ms != candle.open_time_ms + interval_ms - 1:
                raise ScalpingMarketStructureInputError("candle close-time boundary is invalid")
            if candle.close_time_ms >= view.captured_at_ms:
                raise ScalpingMarketStructureInputError("forming or not-yet-closed candle cannot enter structure engine")
            if min(candle.open, candle.high, candle.low, candle.close) <= 0:
                raise ScalpingMarketStructureInputError("candle OHLC prices must be positive")
            if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(
                candle.open, candle.high, candle.close
            ):
                raise ScalpingMarketStructureInputError("candle OHLC range is inconsistent")
            for price in (candle.open, candle.high, candle.low, candle.close):
                try:
                    view.instrument.require_price_on_tick(price)
                except ScalpingMarketDataInputError as exc:
                    raise ScalpingMarketStructureInputError(str(exc)) from exc
            if previous is not None:
                if candle.open_time_ms != previous.open_time_ms + interval_ms:
                    raise ScalpingMarketStructureContinuityError("closed candle sequence contains a gap or duplicate")
                if candle.close_time_ms <= previous.close_time_ms:
                    raise ScalpingMarketStructureContinuityError("closed candle times are not strictly increasing")
            previous = candle

    def _new_candles(self, state: _TimeframeState, candles: tuple[Kline, ...]) -> tuple[Kline, ...]:
        if not candles:
            return ()
        if state.last_candle is None:
            return candles
        last_index = next(
            (i for i, candle in enumerate(candles) if candle.open_time_ms == state.last_candle.open_time_ms),
            None,
        )
        if last_index is None:
            raise ScalpingMarketStructureContinuityError(
                "snapshot no longer overlaps engine's last candle; reset and replay a fresh bounded window"
            )
        if self._candle_fingerprint(candles[last_index]) != self._candle_fingerprint(state.last_candle):
            raise ScalpingMarketStructureContinuityError(
                "previously processed closed candle was revised; reset and replay required"
            )
        new_candles = candles[last_index + 1 :]
        if new_candles and new_candles[0].open_time_ms != state.last_candle.open_time_ms + _TIMEFRAME_MS[state.timeframe]:
            raise ScalpingMarketStructureContinuityError("incremental candle append is not contiguous")
        return new_candles

    @staticmethod
    def _candle_fingerprint(candle: Kline) -> tuple[object, ...]:
        return (
            candle.open_time_ms, candle.close_time_ms, candle.open, candle.high, candle.low,
            candle.close, candle.volume, candle.quote_asset_volume, candle.trade_count,
            candle.taker_buy_base_volume, candle.taker_buy_quote_volume,
        )

    def _process_candle(self, state: _TimeframeState, candle: Kline) -> None:
        index = state.bars_processed
        state.history_window.append((index, candle))
        new_pivots: list[StructurePivot] = []
        events: list[StructureEvent] = []
        for layer_state in (state.swing, state.internal):
            pivots = self._detect_confirmed_pivots(state, layer_state, candle, index)
            for pivot in pivots:
                layer_state.pivots.append(_TrackedPivot(pivot))
                if len(layer_state.pivots) > self.config.max_pivots_per_layer:
                    del layer_state.pivots[: len(layer_state.pivots) - self.config.max_pivots_per_layer]
                new_pivots.append(pivot)

        for layer_state in (state.swing, state.internal):
            event = self._detect_break(state, layer_state, candle, index)
            if event is not None:
                events.append(event)
                state.events.append(event)
                layer_state.latest_event = event
        if len(state.events) > self.config.max_events_per_timeframe:
            del state.events[: len(state.events) - self.config.max_events_per_timeframe]

        trace = StructureBarTrace(
            symbol=state.symbol,
            timeframe=state.timeframe,
            bar_index=index,
            bar_open_time_ms=candle.open_time_ms,
            confirmation_time_ms=candle.close_time_ms,
            open=candle.open,
            high=candle.high,
            low=candle.low,
            close=candle.close,
            new_pivots=tuple(new_pivots),
            events=tuple(events),
            swing=self._layer_snapshot(state.swing),
            internal=self._layer_snapshot(state.internal),
        )
        state.traces.append(trace)
        if len(state.traces) > self.config.max_bar_traces_per_timeframe:
            del state.traces[: len(state.traces) - self.config.max_bar_traces_per_timeframe]

        timeframe_settings = self.config.settings_for(state.timeframe)
        max_window = max(
            timeframe_settings.swing_left_bars + timeframe_settings.swing_right_bars + 1,
            timeframe_settings.internal_left_bars + timeframe_settings.internal_right_bars + 1,
        )
        if len(state.history_window) > max_window:
            del state.history_window[: len(state.history_window) - max_window]
        state.last_candle = candle
        state.bars_processed += 1

    def _detect_confirmed_pivots(
        self,
        state: _TimeframeState,
        layer_state: _LayerState,
        current: Kline,
        current_index: int,
    ) -> tuple[StructurePivot, ...]:
        settings = self.config.settings_for(state.timeframe)
        left_name, right_name = _LAYER_SETTINGS[layer_state.layer]
        left = getattr(settings, left_name)
        right = getattr(settings, right_name)
        required = left + right + 1
        if len(state.history_window) < required:
            return ()
        window = state.history_window[-required:]
        if window[-1][0] != current_index:
            raise ScalpingMarketStructureError("internal history window index invariant failed")
        pivot_index, candidate = window[left]
        neighbors = [bar for _, bar in window[:left] + window[left + 1 :]]
        high_pivot = all(candidate.high > item.high for item in neighbors)
        low_pivot = all(candidate.low < item.low for item in neighbors)
        if not high_pivot and not low_pivot:
            return ()
        # An outside candle may be both a strict high and strict low pivot.
        # Emit both with stable identities rather than choosing by branch order.
        detected: list[StructurePivot] = []
        for kind, is_pivot, value in (
            ("HIGH", high_pivot, candidate.high),
            ("LOW", low_pivot, candidate.low),
        ):
            if not is_pivot:
                continue
            pivot_id = _hash_id(
                state.symbol, state.timeframe, layer_state.layer, kind,
                candidate.open_time_ms, format(value.normalize(), "f"),
            )
            detected.append(StructurePivot(
                pivot_id=pivot_id,
                symbol=state.symbol,
                timeframe=state.timeframe,
                layer=layer_state.layer,
                kind=kind,
                price=value,
                source_open_time_ms=candidate.open_time_ms,
                confirmation_close_time_ms=current.close_time_ms,
                source_index=pivot_index,
                confirmation_index=current_index,
            ))
        return tuple(detected)

    def _detect_break(
        self,
        state: _TimeframeState,
        layer_state: _LayerState,
        candle: Kline,
        index: int,
    ) -> StructureEvent | None:
        if state.last_candle is None:
            return None
        previous_close = state.last_candle.close
        direction = 1 if candle.close > previous_close else -1 if candle.close < previous_close else 0
        if direction == 0:
            return None
        kind: PivotKind = "HIGH" if direction > 0 else "LOW"
        eligible: list[_TrackedPivot] = []
        for tracked in layer_state.pivots:
            pivot = tracked.pivot
            if tracked.broken or pivot.kind != kind or pivot.confirmation_index >= index:
                continue
            crossed = (
                previous_close <= pivot.price < candle.close
                if direction > 0
                else previous_close >= pivot.price > candle.close
            )
            if crossed:
                eligible.append(tracked)
        if not eligible:
            return None

        # One event per layer per candle: choose the most recently confirmed
        # crossed pivot; mark every crossed level consumed to prevent stale repeats.
        selected = max(
            eligible,
            key=lambda item: (item.pivot.confirmation_index, item.pivot.source_index, item.pivot.pivot_id),
        )
        for tracked in eligible:
            tracked.broken = True
        pivot = selected.pivot
        event_type: EventKind = "BOS" if layer_state.direction in (0, direction) else "CHoCH"

        protection_kind: PivotKind = "LOW" if direction > 0 else "HIGH"
        protection_candidates = [
            item.pivot for item in layer_state.pivots
            if item.pivot.kind == protection_kind
            and not item.broken
            and item.pivot.confirmation_index <= index
            and item.pivot.source_index < index
        ]
        protected = max(
            protection_candidates,
            key=lambda item: (item.source_index, item.confirmation_index, item.pivot_id),
            default=None,
        )
        if direction > 0 and protected is not None:
            layer_state.protected_low = protected
        elif direction < 0 and protected is not None:
            layer_state.protected_high = protected

        event_id = _hash_id(
            state.symbol, state.timeframe, layer_state.layer, event_type, direction,
            pivot.pivot_id, candle.open_time_ms,
        )
        event = StructureEvent(
            event_id=event_id,
            symbol=state.symbol,
            timeframe=state.timeframe,
            layer=layer_state.layer,
            event_type=event_type,
            direction=direction,
            broken_level=pivot.price,
            pivot_id=pivot.pivot_id,
            pivot_price=pivot.price,
            pivot_source_open_time_ms=pivot.source_open_time_ms,
            pivot_confirmation_close_time_ms=pivot.confirmation_close_time_ms,
            break_bar_open_time_ms=candle.open_time_ms,
            confirmation_time_ms=candle.close_time_ms,
            previous_close=previous_close,
            confirmation_close=candle.close,
            protected_pivot_id=None if protected is None else protected.pivot_id,
            protected_price=None if protected is None else protected.price,
            protected_kind=None if protected is None else protected.kind,
        )
        layer_state.direction = direction
        return event

    def _warmup_required(self, timeframe: str) -> int:
        settings = self.config.settings_for(timeframe)
        return max(
            settings.swing_left_bars + settings.swing_right_bars + 1,
            settings.internal_left_bars + settings.internal_right_bars + 1,
        )

    def _pivot_snapshots(self, state: _TimeframeState) -> tuple[StructurePivotState, ...]:
        return tuple(
            StructurePivotState(item.pivot, item.broken)
            for layer in (state.swing, state.internal)
            for item in layer.pivots
        )

    @staticmethod
    def _layer_snapshot(state: _LayerState) -> StructureLayerSnapshot:
        return StructureLayerSnapshot(
            layer=state.layer,
            direction=state.direction,
            direction_name=_direction_name(state.direction),
            protected_high=state.protected_high,
            protected_low=state.protected_low,
            latest_event=state.latest_event,
        )


def _pivot_to_dict(pivot: StructurePivot) -> dict[str, Any]:
    return {
        "pivot_id": pivot.pivot_id,
        "symbol": pivot.symbol,
        "timeframe": pivot.timeframe,
        "layer": pivot.layer,
        "kind": pivot.kind,
        "price": _decimal_text(pivot.price),
        "source_open_time_ms": pivot.source_open_time_ms,
        "confirmation_close_time_ms": pivot.confirmation_close_time_ms,
        "source_index": pivot.source_index,
        "confirmation_index": pivot.confirmation_index,
    }


def _event_to_dict(event: StructureEvent) -> dict[str, Any]:
    return {
        "event_id": event.event_id,
        "symbol": event.symbol,
        "timeframe": event.timeframe,
        "layer": event.layer,
        "event_type": event.event_type,
        "direction": event.direction_name,
        "broken_level": _decimal_text(event.broken_level),
        "pivot_id": event.pivot_id,
        "pivot_price": _decimal_text(event.pivot_price),
        "pivot_source_open_time_ms": event.pivot_source_open_time_ms,
        "pivot_confirmation_close_time_ms": event.pivot_confirmation_close_time_ms,
        "break_bar_open_time_ms": event.break_bar_open_time_ms,
        "confirmation_time_ms": event.confirmation_time_ms,
        "previous_close": _decimal_text(event.previous_close),
        "confirmation_close": _decimal_text(event.confirmation_close),
        "protected_pivot_id": event.protected_pivot_id,
        "protected_price": _decimal_text(event.protected_price),
        "protected_kind": event.protected_kind,
    }


def _layer_to_dict(layer: StructureLayerSnapshot) -> dict[str, Any]:
    return {
        "layer": layer.layer,
        "direction": layer.direction_name,
        "protected_high": None if layer.protected_high is None else _pivot_to_dict(layer.protected_high),
        "protected_low": None if layer.protected_low is None else _pivot_to_dict(layer.protected_low),
        "latest_event": None if layer.latest_event is None else _event_to_dict(layer.latest_event),
    }
