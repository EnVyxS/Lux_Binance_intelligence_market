"""SMC V2 liquidity and Fair Value Gap evidence engine.

Stage 5 emits optional, immutable evidence from confirmed Stage-2 pivots and
closed Binance USD-M klines. It does not qualify OBs, score setups, or create
entries. M1/M5 are independent; M15 is advisory-only.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal
import hashlib
import json
from typing import Any, Literal

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataInputError,
    ScalpingMarketDataView,
)
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureResult,
    StructurePivot,
    StructurePivotState,
    StructureTimeframeResult,
)

_SETUP_TIMEFRAMES = ("1m", "5m")
_ALL_TIMEFRAMES = ("1m", "5m", "15m")
LiquidityKind = Literal["SWING_HIGH", "SWING_LOW", "LOCAL_HIGH", "LOCAL_LOW", "EQUAL_HIGH", "EQUAL_LOW"]
SweepOutcome = Literal["WICK_BREACH", "CLOSE_THROUGH", "CLOSE_BACK"]
FVGStatus = Literal["ACTIVE", "TOUCHED", "PARTIALLY_FILLED", "FILLED"]


class ScalpingLiquidityFVGError(ValueError):
    """Base Stage-5 error."""


class ScalpingLiquidityFVGInputError(ScalpingLiquidityFVGError):
    """Invalid Stage-5 input or conflicting identity."""


class ScalpingLiquidityFVGContinuityError(ScalpingLiquidityFVGError):
    """A gap, revision or missing overlap prevents causal replay."""


class ScalpingLiquidityFVGCapacityError(ScalpingLiquidityFVGError):
    """Configured bounded evidence capacity has been reached."""


def _decimal_text(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


def _hash_id(*parts: object) -> str:
    payload = "|".join(str(part) for part in parts).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def _fingerprint(candle: Kline) -> tuple[object, ...]:
    return (
        candle.open_time_ms, candle.close_time_ms, candle.open, candle.high,
        candle.low, candle.close, candle.volume, candle.quote_asset_volume,
        candle.trade_count, candle.taker_buy_base_volume, candle.taker_buy_quote_volume,
    )


@dataclass(frozen=True, slots=True)
class ScalpingLiquidityFVGConfig:
    """Bounded evidence settings; equal-level tolerance is provisional."""

    equal_level_tolerance_ticks: int = 2
    require_sweep_close_back: bool = True
    include_internal_pivots: bool = True
    max_symbols: int = 16
    max_references_per_timeframe: int = 512
    max_sweeps_per_timeframe: int = 1024
    max_fvgs_per_timeframe: int = 512
    max_traces_per_timeframe: int = 4096
    max_candle_fingerprints_per_timeframe: int = 2048

    def __post_init__(self) -> None:
        if isinstance(self.equal_level_tolerance_ticks, bool) or not isinstance(
            self.equal_level_tolerance_ticks, int
        ) or not 0 <= self.equal_level_tolerance_ticks <= 1000:
            raise ValueError("equal_level_tolerance_ticks must be an integer from 0 to 1000")
        if not isinstance(self.require_sweep_close_back, bool):
            raise ValueError("require_sweep_close_back must be boolean")
        if not isinstance(self.include_internal_pivots, bool):
            raise ValueError("include_internal_pivots must be boolean")
        for name, low, high in (
            ("max_symbols", 1, 32),
            ("max_references_per_timeframe", 8, 4096),
            ("max_sweeps_per_timeframe", 8, 8192),
            ("max_fvgs_per_timeframe", 8, 4096),
            ("max_traces_per_timeframe", 16, 16384),
            ("max_candle_fingerprints_per_timeframe", 16, 8192),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise ValueError(f"{name} must be between {low} and {high}")


@dataclass(frozen=True, slots=True)
class LiquidityReference:
    reference_id: str
    symbol: str
    timeframe: str
    kind: LiquidityKind
    price: Decimal
    pivot_ids: tuple[str, ...]
    source_open_times_ms: tuple[int, ...]
    confirmation_time_ms: int
    tolerance_ticks: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "LIQUIDITY_REFERENCE",
            "reference_id": self.reference_id, "symbol": self.symbol,
            "timeframe": self.timeframe, "kind": self.kind,
            "price": _decimal_text(self.price), "pivot_ids": list(self.pivot_ids),
            "source_open_times_ms": list(self.source_open_times_ms),
            "confirmation_time_ms": self.confirmation_time_ms,
            "tolerance_ticks": self.tolerance_ticks,
        }


@dataclass(frozen=True, slots=True)
class LiquiditySweepEvidence:
    evidence_id: str
    reference_id: str
    symbol: str
    timeframe: str
    direction: int
    reference_price: Decimal
    bar_open_time_ms: int
    confirmation_time_ms: int
    wick_price: Decimal
    close_price: Decimal
    wick_breach: bool
    close_through: bool
    close_back: bool
    qualifies_as_sweep: bool

    @property
    def outcome(self) -> SweepOutcome:
        if self.close_back:
            return "CLOSE_BACK"
        if self.close_through:
            return "CLOSE_THROUGH"
        return "WICK_BREACH"

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "LIQUIDITY_SWEEP",
            "evidence_id": self.evidence_id, "reference_id": self.reference_id,
            "symbol": self.symbol, "timeframe": self.timeframe,
            "direction": self.direction, "reference_price": _decimal_text(self.reference_price),
            "bar_open_time_ms": self.bar_open_time_ms,
            "confirmation_time_ms": self.confirmation_time_ms,
            "wick_price": _decimal_text(self.wick_price),
            "close_price": _decimal_text(self.close_price),
            "wick_breach": self.wick_breach, "close_through": self.close_through,
            "close_back": self.close_back, "qualifies_as_sweep": self.qualifies_as_sweep,
            "outcome": self.outcome,
        }


@dataclass(frozen=True, slots=True)
class FairValueGap:
    fvg_id: str
    symbol: str
    timeframe: str
    direction: int
    zone_top: Decimal
    zone_bottom: Decimal
    first_bar_open_time_ms: int
    middle_bar_open_time_ms: int
    confirmation_bar_open_time_ms: int
    confirmation_time_ms: int
    status: FVGStatus
    maximum_fill_ratio: Decimal
    first_touch_time_ms: int | None
    fill_time_ms: int | None
    last_observed_bar_open_time_ms: int

    @property
    def is_terminal(self) -> bool:
        return self.status == "FILLED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "FVG",
            "fvg_id": self.fvg_id, "symbol": self.symbol,
            "timeframe": self.timeframe, "direction": self.direction,
            "zone_top": _decimal_text(self.zone_top),
            "zone_bottom": _decimal_text(self.zone_bottom),
            "first_bar_open_time_ms": self.first_bar_open_time_ms,
            "middle_bar_open_time_ms": self.middle_bar_open_time_ms,
            "confirmation_bar_open_time_ms": self.confirmation_bar_open_time_ms,
            "confirmation_time_ms": self.confirmation_time_ms,
            "status": self.status,
            "maximum_fill_ratio": _decimal_text(self.maximum_fill_ratio),
            "first_touch_time_ms": self.first_touch_time_ms,
            "fill_time_ms": self.fill_time_ms,
            "last_observed_bar_open_time_ms": self.last_observed_bar_open_time_ms,
        }


@dataclass(frozen=True, slots=True)
class LiquidityFVGTrace:
    event_id: str
    symbol: str
    timeframe: str
    event_type: str
    observed_time_ms: int
    bar_open_time_ms: int
    reference_id: str | None
    fvg_id: str | None
    reason_code: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "LIQUIDITY_FVG_TRACE",
            "event_id": self.event_id, "symbol": self.symbol,
            "timeframe": self.timeframe, "event_type": self.event_type,
            "observed_time_ms": self.observed_time_ms,
            "bar_open_time_ms": self.bar_open_time_ms,
            "reference_id": self.reference_id, "fvg_id": self.fvg_id,
            "reason_code": self.reason_code,
        }


@dataclass(frozen=True, slots=True)
class LiquidityFVGTimeframeResult:
    symbol: str
    timeframe: str
    status: str
    reason_codes: tuple[str, ...]
    references: tuple[LiquidityReference, ...]
    sweeps: tuple[LiquiditySweepEvidence, ...]
    fvgs: tuple[FairValueGap, ...]
    traces: tuple[LiquidityFVGTrace, ...]
    processed_candle_count: int


@dataclass(frozen=True, slots=True)
class ScalpingLiquidityFVGResult:
    symbol: str
    captured_at_ms: int
    timeframes: tuple[LiquidityFVGTimeframeResult, ...]

    def timeframe(self, interval: str) -> LiquidityFVGTimeframeResult | None:
        return next((item for item in self.timeframes if item.timeframe == interval), None)

    @property
    def sweeps(self) -> tuple[LiquiditySweepEvidence, ...]:
        return tuple(item for tf in self.timeframes for item in tf.sweeps)

    @property
    def fvgs(self) -> tuple[FairValueGap, ...]:
        return tuple(item for tf in self.timeframes for item in tf.fvgs)

    def to_jsonl(self) -> str:
        rows: list[dict[str, Any]] = []
        for tf in self.timeframes:
            rows.extend(item.to_dict() for item in tf.traces)
            rows.extend(item.to_dict() for item in tf.references)
            rows.extend(item.to_dict() for item in tf.sweeps)
            rows.extend(item.to_dict() for item in tf.fvgs)
        return "\n".join(
            json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for row in rows
        )


@dataclass(slots=True)
class _MutableFVG:
    fvg_id: str
    symbol: str
    timeframe: str
    direction: int
    zone_top: Decimal
    zone_bottom: Decimal
    first_bar_open_time_ms: int
    middle_bar_open_time_ms: int
    confirmation_bar_open_time_ms: int
    confirmation_time_ms: int
    status: FVGStatus = "ACTIVE"
    maximum_fill_ratio: Decimal = Decimal("0")
    first_touch_time_ms: int | None = None
    fill_time_ms: int | None = None
    last_observed_bar_open_time_ms: int = 0

    def snapshot(self) -> FairValueGap:
        return FairValueGap(
            self.fvg_id, self.symbol, self.timeframe, self.direction,
            self.zone_top, self.zone_bottom, self.first_bar_open_time_ms,
            self.middle_bar_open_time_ms, self.confirmation_bar_open_time_ms,
            self.confirmation_time_ms, self.status, self.maximum_fill_ratio,
            self.first_touch_time_ms, self.fill_time_ms, self.last_observed_bar_open_time_ms,
        )


@dataclass(slots=True)
class _TimeframeState:
    last_candle: Kline | None = None
    recent_candles: list[Kline] = field(default_factory=list)
    fingerprints: dict[int, tuple[object, ...]] = field(default_factory=dict)
    references: dict[str, LiquidityReference] = field(default_factory=dict)
    consumed_pivot_ids: dict[str, None] = field(default_factory=dict)
    sweeps: list[LiquiditySweepEvidence] = field(default_factory=list)
    fvgs: dict[str, _MutableFVG] = field(default_factory=dict)
    traces: list[LiquidityFVGTrace] = field(default_factory=list)
    processed_count: int = 0


class ScalpingLiquidityFVGEngine:
    """Independent, bounded Stage-5 liquidity/FVG evidence replay."""

    def __init__(self, *, config: ScalpingLiquidityFVGConfig | None = None) -> None:
        self.config = config or ScalpingLiquidityFVGConfig()
        self._states: dict[tuple[str, str], _TimeframeState] = {}

    def reset(self, *, symbol: str | None = None, timeframe: str | None = None) -> None:
        if timeframe is not None and timeframe not in _ALL_TIMEFRAMES:
            raise ValueError("timeframe must be 1m, 5m or 15m")
        if symbol is None and timeframe is not None:
            raise ValueError("symbol is required when resetting one timeframe")
        if symbol is None:
            self._states.clear()
            return
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized:
            raise ValueError("symbol must be a non-empty string")
        for key in tuple(self._states):
            if key[0] == normalized and (timeframe is None or key[1] == timeframe):
                del self._states[key]

    def process(
        self,
        structure: ScalpingMarketStructureResult,
        view: ScalpingMarketDataView,
    ) -> ScalpingLiquidityFVGResult:
        if not isinstance(structure, ScalpingMarketStructureResult):
            raise ScalpingLiquidityFVGInputError("structure must be a Stage-2 result")
        if not isinstance(view, ScalpingMarketDataView):
            raise ScalpingLiquidityFVGInputError("view must be a ScalpingMarketDataView")
        if structure.symbol != view.symbol or structure.captured_at_ms != view.captured_at_ms:
            raise ScalpingLiquidityFVGInputError("structure and market-data capture identity mismatch")
        known_symbols = {key[0] for key in self._states}
        if view.symbol not in known_symbols and len(known_symbols) >= self.config.max_symbols:
            raise ScalpingLiquidityFVGCapacityError("liquidity/FVG symbol cap reached")

        prepared: dict[str, tuple[tuple[Kline, ...], StructureTimeframeResult, tuple[Kline, ...]]] = {}
        for tf in _SETUP_TIMEFRAMES:
            snapshot = view.kline(tf)
            structure_tf = structure.timeframe(tf)
            setup_ready = view.readiness.m1_setup_ready if tf == "1m" else view.readiness.m5_setup_ready
            if (
                snapshot is None or not snapshot.ready or structure_tf is None
                or not setup_ready or structure_tf.status not in ("READY", "WARMING_UP")
            ):
                continue
            if not view.readiness.instrument_price_grid_ready:
                raise ScalpingLiquidityFVGInputError("instrument price grid is not ready")
            candles = tuple(snapshot.candles)
            self._validate_candles(view, tf, candles)
            state = self._states.get((view.symbol, tf), _TimeframeState())
            new_candles = self._new_candles(state, candles, tf)
            self._validate_pivots(structure_tf, view, tf, candles)
            prepared[tf] = (candles, structure_tf, new_candles)

        staged: dict[str, _TimeframeState] = {}
        statuses: dict[str, tuple[str, tuple[str, ...]]] = {}
        for tf in _SETUP_TIMEFRAMES:
            if tf not in prepared:
                statuses[tf] = ("UNAVAILABLE", ("TIMEFRAME_OR_STRUCTURE_NOT_READY",))
                continue
            candles, structure_tf, new_candles = prepared[tf]
            existing = self._states.get((view.symbol, tf), _TimeframeState())
            # Evidence records/Klines are immutable; only _MutableFVG entries
            # require per-item copies for atomic M1/M5 commit semantics.
            state = _TimeframeState(
                last_candle=existing.last_candle,
                recent_candles=list(existing.recent_candles),
                fingerprints=dict(existing.fingerprints),
                references=dict(existing.references),
                consumed_pivot_ids=dict(existing.consumed_pivot_ids),
                sweeps=list(existing.sweeps),
                fvgs={key: replace(item) for key, item in existing.fvgs.items()},
                traces=list(existing.traces),
                processed_count=existing.processed_count,
            )
            self._advance(state, candles, structure_tf, new_candles, tf, view)
            staged[tf] = state
            statuses[tf] = (
                "READY" if structure_tf.status == "READY" else "WARMING_UP", ()
            )

        # Atomic M1/M5 commit after both partitions have passed preflight/replay.
        for tf, state in staged.items():
            self._states[(view.symbol, tf)] = state

        output: list[LiquidityFVGTimeframeResult] = []
        for tf in _ALL_TIMEFRAMES:
            if tf == "15m":
                m15 = view.m15
                output.append(LiquidityFVGTimeframeResult(
                    view.symbol, tf,
                    "ADVISORY_ONLY" if m15.ready else "CONTEXT_UNAVAILABLE",
                    ("M15_IS_ADVISORY_ONLY",) if not m15.ready else (),
                    (), (), (), (), 0,
                ))
                continue
            status, reasons = statuses.get(tf, ("UNAVAILABLE", ("TIMEFRAME_OR_STRUCTURE_NOT_READY",)))
            state = self._states.get((view.symbol, tf), _TimeframeState())
            output.append(LiquidityFVGTimeframeResult(
                view.symbol, tf, status, reasons,
                tuple(state.references.values()), tuple(state.sweeps),
                tuple(item.snapshot() for item in state.fvgs.values()),
                tuple(state.traces), state.processed_count,
            ))
        return ScalpingLiquidityFVGResult(view.symbol, view.captured_at_ms, tuple(output))

    def _validate_candles(
        self, view: ScalpingMarketDataView, timeframe: str, candles: tuple[Kline, ...]
    ) -> None:
        snapshot = view.kline(timeframe)
        if snapshot is None or snapshot.symbol != view.symbol or snapshot.interval != timeframe:
            raise ScalpingLiquidityFVGInputError("Kline snapshot identity mismatch")
        previous: Kline | None = None
        interval_ms = INTERVAL_MILLISECONDS[timeframe]
        for candle in candles:
            if not isinstance(candle, Kline):
                raise ScalpingLiquidityFVGInputError("closed candle series must contain Kline values")
            if candle.exchange != "BINANCE_UM" or candle.symbol != view.symbol or candle.interval != timeframe:
                raise ScalpingLiquidityFVGInputError("candle exchange/symbol/timeframe identity mismatch")
            if candle.close_time_ms != candle.open_time_ms + interval_ms - 1:
                raise ScalpingLiquidityFVGInputError("candle close-time boundary is invalid")
            if candle.close_time_ms >= view.captured_at_ms:
                raise ScalpingLiquidityFVGInputError("forming or unclosed candle cannot enter Stage 5")
            if min(candle.open, candle.high, candle.low, candle.close) <= 0:
                raise ScalpingLiquidityFVGInputError("candle OHLC prices must be positive")
            if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(
                candle.open, candle.high, candle.close
            ):
                raise ScalpingLiquidityFVGInputError("candle OHLC range is inconsistent")
            for price in (candle.open, candle.high, candle.low, candle.close):
                try:
                    view.instrument.require_price_on_tick(price)
                except ScalpingMarketDataInputError as exc:
                    raise ScalpingLiquidityFVGInputError(str(exc)) from exc
            if previous is not None and candle.open_time_ms != previous.open_time_ms + interval_ms:
                raise ScalpingLiquidityFVGContinuityError("closed candle sequence contains a gap or duplicate")
            previous = candle

    def _new_candles(
        self, state: _TimeframeState, candles: tuple[Kline, ...], timeframe: str
    ) -> tuple[Kline, ...]:
        if not candles:
            return ()
        if state.last_candle is None:
            return candles
        index = next((i for i, item in enumerate(candles) if item.open_time_ms == state.last_candle.open_time_ms), None)
        if index is None:
            raise ScalpingLiquidityFVGContinuityError(
                "snapshot no longer overlaps last processed candle; reset and replay required"
            )
        for candle in candles:
            known = state.fingerprints.get(candle.open_time_ms)
            if known is not None and known != _fingerprint(candle):
                raise ScalpingLiquidityFVGContinuityError(
                    "previously processed overlapping candle revised; reset required"
                )
        if _fingerprint(candles[index]) != _fingerprint(state.last_candle):
            raise ScalpingLiquidityFVGContinuityError("previously processed candle revised; reset required")
        new = candles[index + 1:]
        if new and new[0].open_time_ms != state.last_candle.open_time_ms + INTERVAL_MILLISECONDS[timeframe]:
            raise ScalpingLiquidityFVGContinuityError("incremental candle append is not contiguous")
        return new

    def _validate_pivots(
        self, structure_tf: StructureTimeframeResult, view: ScalpingMarketDataView,
        timeframe: str, candles: tuple[Kline, ...],
    ) -> None:
        if structure_tf.symbol != view.symbol or structure_tf.timeframe != timeframe:
            raise ScalpingLiquidityFVGInputError("structure timeframe identity mismatch")
        seen_pivots: dict[str, StructurePivot] = {}
        # Resolve provenance against indexed candle maps. The previous repeated
        # linear scans were O(pivots × candles) at every capture.
        candle_by_open = {candle.open_time_ms: candle for candle in candles}
        candle_by_close = {candle.close_time_ms: candle for candle in candles}
        for item in structure_tf.pivots:
            if not isinstance(item, StructurePivotState):
                raise ScalpingLiquidityFVGInputError("structure pivot states must be typed Stage-2 values")
            if not isinstance(item.broken, bool):
                raise ScalpingLiquidityFVGInputError("pivot broken state must be boolean")
            pivot = item.pivot
            if not isinstance(pivot, StructurePivot):
                raise ScalpingLiquidityFVGInputError("structure pivots must be typed Stage-2 pivots")
            previous = seen_pivots.get(pivot.pivot_id)
            if previous is not None and previous != pivot:
                raise ScalpingLiquidityFVGInputError("conflicting reuse of pivot identity")
            seen_pivots[pivot.pivot_id] = pivot
            if pivot.symbol != view.symbol or pivot.timeframe != timeframe:
                raise ScalpingLiquidityFVGInputError("pivot symbol/timeframe provenance mismatch")
            if pivot.kind not in ("HIGH", "LOW") or pivot.layer not in ("SWING", "INTERNAL"):
                raise ScalpingLiquidityFVGInputError("pivot kind/layer is invalid")
            if (
                not isinstance(pivot.pivot_id, str) or not pivot.pivot_id
                or isinstance(pivot.source_open_time_ms, bool)
                or not isinstance(pivot.source_open_time_ms, int) or pivot.source_open_time_ms < 0
                or isinstance(pivot.confirmation_close_time_ms, bool)
                or not isinstance(pivot.confirmation_close_time_ms, int)
                or pivot.confirmation_close_time_ms <= pivot.source_open_time_ms
                or isinstance(pivot.source_index, bool) or not isinstance(pivot.source_index, int)
                or pivot.source_index < 0
                or isinstance(pivot.confirmation_index, bool)
                or not isinstance(pivot.confirmation_index, int)
                or pivot.confirmation_index <= pivot.source_index
            ):
                raise ScalpingLiquidityFVGInputError("pivot identity/index/timestamp provenance is invalid")
            source_candle = candle_by_open.get(pivot.source_open_time_ms)
            confirmation_candle = candle_by_close.get(pivot.confirmation_close_time_ms)
            if not isinstance(pivot.price, Decimal) or not pivot.price.is_finite() or pivot.price <= 0:
                raise ScalpingLiquidityFVGInputError("pivot price must be a positive finite Decimal")
            try:
                view.instrument.require_price_on_tick(pivot.price)
            except ScalpingMarketDataInputError as exc:
                raise ScalpingLiquidityFVGInputError("pivot price is off the exact Binance tick grid") from exc
            if source_candle is not None:
                expected_price = source_candle.high if pivot.kind == "HIGH" else source_candle.low
                if pivot.price != expected_price:
                    raise ScalpingLiquidityFVGInputError("pivot price does not match its source candle")
                if pivot.confirmation_close_time_ms <= source_candle.close_time_ms:
                    raise ScalpingLiquidityFVGInputError("pivot confirmation must follow its source candle")
            elif confirmation_candle is None and pivot.confirmation_close_time_ms >= (
                candles[0].close_time_ms if candles else 0
            ):
                raise ScalpingLiquidityFVGInputError("recent pivot source is outside same-capture Klines")
            if confirmation_candle is not None and confirmation_candle.close_time_ms <= pivot.source_open_time_ms:
                raise ScalpingLiquidityFVGInputError("pivot confirmation must follow its source candle")

    def _advance(
        self, state: _TimeframeState, candles: tuple[Kline, ...],
        structure_tf: StructureTimeframeResult, new_candles: tuple[Kline, ...],
        timeframe: str, view: ScalpingMarketDataView,
    ) -> None:
        if not new_candles:
            return
        tick = view.instrument.tick_size
        assert tick is not None
        pivot_states = {
            item.pivot.pivot_id: item for item in structure_tf.pivots
            if self.config.include_internal_pivots or item.pivot.layer == "SWING"
        }
        pivots = tuple(sorted(
            (item.pivot for item in pivot_states.values()),
            key=lambda p: (p.confirmation_close_time_ms, p.source_open_time_ms, p.pivot_id),
        ))
        events_by_pivot: dict[str, list[int]] = {}
        for event in structure_tf.events:
            events_by_pivot.setdefault(event.pivot_id, []).append(event.confirmation_time_ms)
        for candle in new_candles:
            eligible = tuple(
                pivot for pivot in pivots
                if pivot.confirmation_close_time_ms < candle.open_time_ms
                and pivot.pivot_id not in state.consumed_pivot_ids
                and not any(
                    broken_time < candle.open_time_ms
                    for broken_time in events_by_pivot.get(pivot.pivot_id, ())
                )
                and not (
                    pivot_states[pivot.pivot_id].broken
                    and not events_by_pivot.get(pivot.pivot_id)
                )
            )
            references = self._references_for(eligible, timeframe, view.symbol, tick)
            state.references = {ref.reference_id: ref for ref in references}
            self._trim_dict(state.references, self.config.max_references_per_timeframe)

            self._detect_sweeps(state, candle, references, timeframe)
            self._update_fvgs(state, candle, timeframe)
            if len(state.recent_candles) >= 2:
                first, middle = state.recent_candles[-2], state.recent_candles[-1]
                self._detect_fvg(state, first, middle, candle, timeframe)
            state.recent_candles.append(candle)
            state.recent_candles = state.recent_candles[-2:]
            state.last_candle = candle
            state.processed_count += 1
            state.fingerprints[candle.open_time_ms] = _fingerprint(candle)
            while len(state.fingerprints) > self.config.max_candle_fingerprints_per_timeframe:
                del state.fingerprints[min(state.fingerprints)]
        # Keep only references/sweeps/FVG records within configured budgets.
        if len(state.sweeps) > self.config.max_sweeps_per_timeframe:
            del state.sweeps[:len(state.sweeps) - self.config.max_sweeps_per_timeframe]
        self._trim_dict(state.fvgs, self.config.max_fvgs_per_timeframe, terminal_only=True)
        if len(state.traces) > self.config.max_traces_per_timeframe:
            del state.traces[:len(state.traces) - self.config.max_traces_per_timeframe]

    def _references_for(
        self, pivots: tuple[StructurePivot, ...], timeframe: str,
        symbol: str, tick: Decimal,
    ) -> tuple[LiquidityReference, ...]:
        grouped: list[tuple[StructurePivot, ...]] = []
        for kind in ("HIGH", "LOW"):
            items = sorted(
                (p for p in pivots if p.kind == kind),
                key=lambda p: (p.price, p.confirmation_close_time_ms, p.pivot_id),
            )
            clusters: list[list[StructurePivot]] = []
            tolerance = tick * self.config.equal_level_tolerance_ticks
            for pivot in items:
                if clusters and abs(pivot.price - clusters[-1][0].price) <= tolerance:
                    clusters[-1].append(pivot)
                else:
                    clusters.append([pivot])
            grouped.extend(tuple(cluster) for cluster in clusters)

        result: list[LiquidityReference] = []
        for cluster in grouped:
            first = cluster[0]
            kind = first.kind
            if len(cluster) >= 2:
                # Use the earliest pivot's exact tick-aligned price as the canonical level.
                ref_kind: LiquidityKind = "EQUAL_HIGH" if kind == "HIGH" else "EQUAL_LOW"
                ids = tuple(sorted(p.pivot_id for p in cluster))
                ref_id = _hash_id("LIQ", symbol, timeframe, ref_kind, *ids)
                price = first.price
            else:
                ref_kind = (
                    "SWING_HIGH" if kind == "HIGH" else "SWING_LOW"
                ) if first.layer == "SWING" else (
                    "LOCAL_HIGH" if kind == "HIGH" else "LOCAL_LOW"
                )
                ids = (first.pivot_id,)
                ref_id = _hash_id("LIQ", symbol, timeframe, ref_kind, first.pivot_id)
                price = first.price
            result.append(LiquidityReference(
                ref_id, symbol, timeframe, ref_kind, price, ids,
                tuple(p.source_open_time_ms for p in cluster),
                max(p.confirmation_close_time_ms for p in cluster),
                self.config.equal_level_tolerance_ticks if len(cluster) >= 2 else 0,
            ))
        return tuple(sorted(result, key=lambda r: (r.confirmation_time_ms, r.reference_id)))

    def _detect_sweeps(
        self, state: _TimeframeState, candle: Kline,
        references: tuple[LiquidityReference, ...], timeframe: str,
    ) -> None:
        for ref in references:
            high_level = ref.kind in ("SWING_HIGH", "LOCAL_HIGH", "EQUAL_HIGH")
            if high_level:
                wick = candle.high > ref.price
                close_through = candle.close > ref.price
                close_back = wick and candle.close < ref.price
                wick_price = candle.high
                direction = -1
            else:
                wick = candle.low < ref.price
                close_through = candle.close < ref.price
                close_back = wick and candle.close > ref.price
                wick_price = candle.low
                direction = 1
            if not wick:
                continue
            qualifies = close_back or not self.config.require_sweep_close_back
            evidence_id = _hash_id(
                "SWEEP", ref.reference_id, candle.open_time_ms, wick_price, candle.close
            )
            if any(item.evidence_id == evidence_id for item in state.sweeps):
                continue
            evidence = LiquiditySweepEvidence(
                evidence_id, ref.reference_id, candle.symbol, timeframe, direction,
                ref.price, candle.open_time_ms, candle.close_time_ms,
                wick_price, candle.close, wick, close_through, close_back, qualifies,
            )
            state.sweeps.append(evidence)
            if qualifies:
                for pivot_id in ref.pivot_ids:
                    state.consumed_pivot_ids[pivot_id] = None
                consumed_limit = self.config.max_references_per_timeframe * 2
                while len(state.consumed_pivot_ids) > consumed_limit:
                    del state.consumed_pivot_ids[next(iter(state.consumed_pivot_ids))]
            reason = "SWEEP_CLOSE_BACK" if close_back else (
                "SWEEP_CLOSE_THROUGH" if close_through else "SWEEP_WICK_BREACH"
            )
            self._trace(state, candle, timeframe, "SWEEP_EVIDENCE", ref.reference_id, None, reason)

    def _detect_fvg(
        self, state: _TimeframeState, first: Kline, middle: Kline,
        third: Kline, timeframe: str,
    ) -> None:
        direction = 0
        top = bottom = None
        if third.low > first.high:
            direction, top, bottom = 1, third.low, first.high
        elif third.high < first.low:
            direction, top, bottom = -1, first.low, third.high
        if direction == 0 or top is None or bottom is None or top <= bottom:
            return
        fvg_id = _hash_id(
            "FVG", third.symbol, timeframe, direction,
            first.open_time_ms, middle.open_time_ms, third.open_time_ms, top, bottom,
        )
        if fvg_id in state.fvgs:
            return
        item = _MutableFVG(
            fvg_id, third.symbol, timeframe, direction, top, bottom,
            first.open_time_ms, middle.open_time_ms, third.open_time_ms,
            third.close_time_ms, "ACTIVE", Decimal("0"), None, None, third.open_time_ms,
        )
        state.fvgs[fvg_id] = item
        self._trace(state, third, timeframe, "FVG_FORMED", None, fvg_id, "THREE_CANDLE_GAP_CONFIRMED")

    def _update_fvgs(self, state: _TimeframeState, candle: Kline, timeframe: str) -> None:
        for item in state.fvgs.values():
            if item.status == "FILLED" or candle.open_time_ms <= item.confirmation_bar_open_time_ms:
                continue
            overlaps = candle.low <= item.zone_top and candle.high >= item.zone_bottom
            if not overlaps:
                item.last_observed_bar_open_time_ms = candle.open_time_ms
                continue
            if item.first_touch_time_ms is None:
                item.first_touch_time_ms = candle.close_time_ms
            height = item.zone_top - item.zone_bottom
            if item.direction == 1:
                penetration = item.zone_top - candle.low
                fully_filled = candle.low <= item.zone_bottom
            else:
                penetration = candle.high - item.zone_bottom
                fully_filled = candle.high >= item.zone_top
            ratio = max(Decimal("0"), min(Decimal("1"), penetration / height))
            if ratio > item.maximum_fill_ratio:
                item.maximum_fill_ratio = ratio
            old = item.status
            if fully_filled:
                item.status = "FILLED"
                item.fill_time_ms = candle.close_time_ms
            elif ratio > 0:
                item.status = "PARTIALLY_FILLED"
            else:
                item.status = "TOUCHED"
            item.last_observed_bar_open_time_ms = candle.open_time_ms
            if item.status != old:
                reason = "FVG_FULLY_FILLED" if item.status == "FILLED" else (
                    "FVG_PARTIAL_FILL" if item.status == "PARTIALLY_FILLED" else "FVG_EDGE_TOUCH"
                )
                self._trace(state, candle, timeframe, "FVG_STATE_CHANGED", None, item.fvg_id, reason)

    def _trace(
        self, state: _TimeframeState, candle: Kline, timeframe: str,
        event_type: str, reference_id: str | None, fvg_id: str | None, reason: str,
    ) -> None:
        event_id = _hash_id(
            "TRACE", candle.symbol, timeframe, event_type, candle.open_time_ms,
            reference_id or "", fvg_id or "", reason,
        )
        if any(item.event_id == event_id for item in state.traces):
            return
        state.traces.append(LiquidityFVGTrace(
            event_id, candle.symbol, timeframe, event_type, candle.close_time_ms,
            candle.open_time_ms, reference_id, fvg_id, reason,
        ))

    @staticmethod
    def _trim_dict(mapping: dict, limit: int, *, terminal_only: bool = False) -> None:
        if len(mapping) <= limit:
            return
        removable = []
        for key, value in mapping.items():
            if terminal_only:
                if isinstance(value, _MutableFVG) and value.status == "FILLED":
                    removable.append(key)
            else:
                removable.append(key)
        while len(mapping) > limit and removable:
            del mapping[removable.pop(0)]
        if len(mapping) > limit:
            raise ScalpingLiquidityFVGCapacityError("nonterminal FVG capacity exhausted")
