"""SMC V2 Order Block validation and lifecycle.

Consumes immutable Stage-3 candidates and closed Binance candles. It records
zone touch, penetration depth, invalidation and source-timeframe expiry only;
it does not infer fills, consume OBs, qualify retests, or create trades.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal
import hashlib
import json
from typing import Any, Literal

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataInputError,
    ScalpingMarketDataView,
)
from divatrading.strategy.scalping_order_block_formation import (
    OrderBlockCandidate,
    ScalpingOrderBlockFormationResult,
)

_SETUP_TIMEFRAMES = ("1m", "5m")
_ALL_TIMEFRAMES = ("1m", "5m", "15m")
LifecycleStatus = Literal[
    "CANDIDATE", "ACTIVE_FRESH", "TOUCHED", "MITIGATED", "INVALIDATED", "EXPIRED"
]
InvalidationMode = Literal["WICK", "CLOSE"]
BoundaryMode = Literal["STRICT", "INCLUSIVE"]
_TERMINAL = {"INVALIDATED", "EXPIRED"}


class ScalpingOrderBlockLifecycleError(ValueError):
    """Base error for Stage-4 OB lifecycle."""


class ScalpingOrderBlockLifecycleInputError(ScalpingOrderBlockLifecycleError):
    """Raised for malformed or conflicting candidate/candle input."""


class ScalpingOrderBlockLifecycleContinuityError(ScalpingOrderBlockLifecycleError):
    """Raised when gaps, late candidates or revised candles prevent safe replay."""


class ScalpingOrderBlockLifecycleCapacityError(ScalpingOrderBlockLifecycleError):
    """Raised when a configured bounded state capacity is exceeded."""


def _decimal_text(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


def _hash_payload(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _candidate_fingerprint(candidate: OrderBlockCandidate) -> str:
    return _hash_payload(candidate.to_dict())


def _candle_fingerprint(candle: Kline) -> str:
    return _hash_payload({
        "exchange": candle.exchange, "symbol": candle.symbol, "interval": candle.interval,
        "open_time_ms": candle.open_time_ms, "close_time_ms": candle.close_time_ms,
        "open": _decimal_text(candle.open), "high": _decimal_text(candle.high),
        "low": _decimal_text(candle.low), "close": _decimal_text(candle.close),
        "volume": _decimal_text(candle.volume),
        "quote_asset_volume": _decimal_text(candle.quote_asset_volume),
        "trade_count": candle.trade_count,
        "taker_buy_base_volume": _decimal_text(candle.taker_buy_base_volume),
        "taker_buy_quote_volume": _decimal_text(candle.taker_buy_quote_volume),
    })


@dataclass(frozen=True, slots=True)
class ScalpingOrderBlockLifecycleConfig:
    """Explicit lifecycle policy; age default is provisional pending replay."""

    invalidation_mode: InvalidationMode = "WICK"
    invalidation_boundary: BoundaryMode = "STRICT"
    max_age_bars: int = 300
    max_symbols: int = 16
    max_order_blocks_per_timeframe: int = 512
    max_traces_per_timeframe: int = 4096
    max_candle_fingerprints_per_timeframe: int = 2048

    def __post_init__(self) -> None:
        if self.invalidation_mode not in ("WICK", "CLOSE"):
            raise ValueError("invalidation_mode must be WICK or CLOSE")
        if self.invalidation_boundary not in ("STRICT", "INCLUSIVE"):
            raise ValueError("invalidation_boundary must be STRICT or INCLUSIVE")
        for name, low, high in (
            ("max_age_bars", 1, 100_000),
            ("max_symbols", 1, 32),
            ("max_order_blocks_per_timeframe", 8, 4096),
            ("max_traces_per_timeframe", 16, 16384),
            ("max_candle_fingerprints_per_timeframe", 16, 8192),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise ValueError(f"{name} must be between {low} and {high}")


@dataclass(frozen=True, slots=True)
class OrderBlockLifecycleSnapshot:
    candidate: OrderBlockCandidate
    status: LifecycleStatus
    age_bars: int
    first_touch_time_ms: int | None
    first_touch_bar_open_time_ms: int | None
    maximum_mitigation_depth_ratio: Decimal
    maximum_mitigation_price: Decimal | None
    mitigation_time_ms: int | None
    invalidation_time_ms: int | None
    invalidation_bar_open_time_ms: int | None
    invalidation_price: Decimal | None
    invalidation_reason: str | None
    expiry_time_ms: int | None
    expiry_reason: str | None
    last_processed_bar_open_time_ms: int | None

    @property
    def is_terminal(self) -> bool:
        return self.status in _TERMINAL

    @property
    def is_filled(self) -> bool:
        """Always false: a zone interaction is not an exchange fill."""
        return False

    @property
    def is_consumed(self) -> bool:
        """Always false: consumption belongs to a later setup/execution layer."""
        return False

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "ORDER_BLOCK_LIFECYCLE",
            "candidate": self.candidate.to_dict(),
            "status": self.status,
            "age_bars": self.age_bars,
            "first_touch_time_ms": self.first_touch_time_ms,
            "first_touch_bar_open_time_ms": self.first_touch_bar_open_time_ms,
            "maximum_mitigation_depth_ratio": _decimal_text(self.maximum_mitigation_depth_ratio),
            "maximum_mitigation_price": _decimal_text(self.maximum_mitigation_price),
            "mitigation_time_ms": self.mitigation_time_ms,
            "invalidation_time_ms": self.invalidation_time_ms,
            "invalidation_bar_open_time_ms": self.invalidation_bar_open_time_ms,
            "invalidation_price": _decimal_text(self.invalidation_price),
            "invalidation_reason": self.invalidation_reason,
            "expiry_time_ms": self.expiry_time_ms,
            "expiry_reason": self.expiry_reason,
            "last_processed_bar_open_time_ms": self.last_processed_bar_open_time_ms,
            "filled": False,
            "consumed": False,
        }


@dataclass(frozen=True, slots=True)
class OrderBlockLifecycleTrace:
    candidate_id: str
    event_id: str
    symbol: str
    timeframe: str
    transition: str
    from_status: str | None
    to_status: str
    observed_time_ms: int
    bar_open_time_ms: int | None
    age_bars: int
    observed_price: Decimal | None
    mitigation_depth_ratio: Decimal | None
    reason_code: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "OB_LIFECYCLE_TRACE",
            "candidate_id": self.candidate_id,
            "event_id": self.event_id,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "transition": self.transition,
            "from_status": self.from_status,
            "to_status": self.to_status,
            "observed_time_ms": self.observed_time_ms,
            "bar_open_time_ms": self.bar_open_time_ms,
            "age_bars": self.age_bars,
            "observed_price": _decimal_text(self.observed_price),
            "mitigation_depth_ratio": _decimal_text(self.mitigation_depth_ratio),
            "reason_code": self.reason_code,
        }


@dataclass(frozen=True, slots=True)
class OrderBlockLifecycleTimeframeResult:
    symbol: str
    timeframe: str
    status: str
    reason_codes: tuple[str, ...]
    order_blocks: tuple[OrderBlockLifecycleSnapshot, ...]
    traces: tuple[OrderBlockLifecycleTrace, ...]
    processed_candle_count: int


@dataclass(frozen=True, slots=True)
class ScalpingOrderBlockLifecycleResult:
    symbol: str
    captured_at_ms: int
    timeframes: tuple[OrderBlockLifecycleTimeframeResult, ...]

    def timeframe(self, interval: str) -> OrderBlockLifecycleTimeframeResult | None:
        return next((item for item in self.timeframes if item.timeframe == interval), None)

    @property
    def order_blocks(self) -> tuple[OrderBlockLifecycleSnapshot, ...]:
        return tuple(item for tf in self.timeframes for item in tf.order_blocks)

    def to_jsonl(self) -> str:
        rows: list[dict[str, Any]] = []
        for timeframe in self.timeframes:
            rows.extend(trace.to_dict() for trace in timeframe.traces)
            rows.extend(item.to_dict() for item in timeframe.order_blocks)
        return "\n".join(
            json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for row in rows
        )


@dataclass(slots=True)
class _MutableLifecycle:
    candidate: OrderBlockCandidate
    fingerprint: str
    status: LifecycleStatus = "CANDIDATE"
    age_bars: int = 0
    first_touch_time_ms: int | None = None
    first_touch_bar_open_time_ms: int | None = None
    maximum_mitigation_depth_ratio: Decimal = Decimal("0")
    maximum_mitigation_price: Decimal | None = None
    mitigation_time_ms: int | None = None
    invalidation_time_ms: int | None = None
    invalidation_bar_open_time_ms: int | None = None
    invalidation_price: Decimal | None = None
    invalidation_reason: str | None = None
    expiry_time_ms: int | None = None
    expiry_reason: str | None = None
    last_processed_bar_open_time_ms: int | None = None

    def snapshot(self) -> OrderBlockLifecycleSnapshot:
        return OrderBlockLifecycleSnapshot(
            candidate=self.candidate, status=self.status, age_bars=self.age_bars,
            first_touch_time_ms=self.first_touch_time_ms,
            first_touch_bar_open_time_ms=self.first_touch_bar_open_time_ms,
            maximum_mitigation_depth_ratio=self.maximum_mitigation_depth_ratio,
            maximum_mitigation_price=self.maximum_mitigation_price,
            mitigation_time_ms=self.mitigation_time_ms,
            invalidation_time_ms=self.invalidation_time_ms,
            invalidation_bar_open_time_ms=self.invalidation_bar_open_time_ms,
            invalidation_price=self.invalidation_price,
            invalidation_reason=self.invalidation_reason,
            expiry_time_ms=self.expiry_time_ms, expiry_reason=self.expiry_reason,
            last_processed_bar_open_time_ms=self.last_processed_bar_open_time_ms,
        )


@dataclass(slots=True)
class _TimeframeState:
    order_blocks: dict[str, _MutableLifecycle] = field(default_factory=dict)
    traces: list[OrderBlockLifecycleTrace] = field(default_factory=list)
    processed_candidate_fingerprints: dict[str, str] = field(default_factory=dict)
    candle_fingerprints: dict[int, str] = field(default_factory=dict)
    last_processed_bar_open_time_ms: int | None = None


class ScalpingOrderBlockLifecycleEngine:
    """Bounded, deterministic lifecycle replay for M1/M5 OB candidates."""

    def __init__(self, *, config: ScalpingOrderBlockLifecycleConfig | None = None) -> None:
        self.config = config or ScalpingOrderBlockLifecycleConfig()
        self._states: dict[tuple[str, str], _TimeframeState] = {}

    def reset(self, *, symbol: str | None = None, timeframe: str | None = None) -> None:
        if timeframe is not None and timeframe not in _ALL_TIMEFRAMES:
            raise ValueError("timeframe must be 1m, 5m or 15m")
        if symbol is None and timeframe is not None:
            raise ValueError("symbol is required when resetting one timeframe")
        if symbol is None and timeframe is None:
            self._states.clear()
            return
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized:
            raise ValueError("symbol must be a non-empty string")
        for key in tuple(self._states):
            if key[0] == normalized and (timeframe is None or key[1] == timeframe):
                del self._states[key]

    def process(
        self,
        formation: ScalpingOrderBlockFormationResult,
        view: ScalpingMarketDataView,
    ) -> ScalpingOrderBlockLifecycleResult:
        if not isinstance(formation, ScalpingOrderBlockFormationResult):
            raise ScalpingOrderBlockLifecycleInputError("formation must be a Stage-3 result")
        if not isinstance(view, ScalpingMarketDataView):
            raise ScalpingOrderBlockLifecycleInputError("view must be a ScalpingMarketDataView")
        if formation.symbol != view.symbol or formation.captured_at_ms != view.captured_at_ms:
            raise ScalpingOrderBlockLifecycleInputError("formation and market-data capture identity mismatch")
        known_symbols = {key[0] for key in self._states}
        if formation.symbol not in known_symbols and len(known_symbols) >= self.config.max_symbols:
            raise ScalpingOrderBlockLifecycleCapacityError("lifecycle symbol cap reached")

        candidates_by_tf: dict[str, list[OrderBlockCandidate]] = {tf: [] for tf in _SETUP_TIMEFRAMES}
        for candidate in formation.candidates:
            if not isinstance(candidate, OrderBlockCandidate) or candidate.timeframe not in _SETUP_TIMEFRAMES:
                self._validate_candidate(candidate, formation.symbol, view)
            existing_state = self._states.get((formation.symbol, candidate.timeframe), _TimeframeState())
            fingerprint = _candidate_fingerprint(candidate)
            previous_fingerprint = existing_state.processed_candidate_fingerprints.get(candidate.candidate_id)
            if previous_fingerprint is not None:
                if previous_fingerprint != fingerprint:
                    raise ScalpingOrderBlockLifecycleInputError(
                        "candidate ID reused with conflicting payload"
                    )
                # This exact immutable candidate was fully validated before.
                continue
            existing_lifecycle = existing_state.order_blocks.get(candidate.candidate_id)
            if existing_lifecycle is not None:
                if existing_lifecycle.fingerprint != fingerprint:
                    raise ScalpingOrderBlockLifecycleInputError(
                        "candidate ID reused with conflicting lifecycle payload"
                    )
                continue
            self._validate_candidate(candidate, formation.symbol, view)
            candidates_by_tf[candidate.timeframe].append(candidate)

        # Work on copies so an M5 continuity error cannot partially commit M1.
        staged: dict[str, _TimeframeState] = {}
        timeframe_status: dict[str, tuple[str, tuple[str, ...]]] = {}
        for timeframe in _SETUP_TIMEFRAMES:
            source = view.kline(timeframe)
            existing = self._states.get((formation.symbol, timeframe), _TimeframeState())
            # All values except _MutableLifecycle are immutable evidence objects.
            # Clone mutable containers and lifecycle records explicitly instead of
            # recursively deep-copying the full state on every capture.
            state = _TimeframeState(
                order_blocks={key: replace(item) for key, item in existing.order_blocks.items()},
                traces=list(existing.traces),
                processed_candidate_fingerprints=dict(existing.processed_candidate_fingerprints),
                candle_fingerprints=dict(existing.candle_fingerprints),
                last_processed_bar_open_time_ms=existing.last_processed_bar_open_time_ms,
            )
            staged[timeframe] = state
            if source is None or not source.ready:
                timeframe_status[timeframe] = ("UNAVAILABLE", ("SOURCE_KLINE_NOT_READY",))
                continue
            self._validate_candle_series(source.candles, formation.symbol, timeframe, view)
            self._advance_timeframe(
                state, candidates_by_tf[timeframe], source.candles, timeframe, view
            )
            timeframe_status[timeframe] = ("READY", ())

        for timeframe, state in staged.items():
            if state.order_blocks or state.traces or state.last_processed_bar_open_time_ms is not None:
                self._states[(formation.symbol, timeframe)] = state

        results: list[OrderBlockLifecycleTimeframeResult] = []
        for timeframe in _ALL_TIMEFRAMES:
            if timeframe == "15m":
                m15 = view.m15
                results.append(OrderBlockLifecycleTimeframeResult(
                    symbol=formation.symbol, timeframe=timeframe,
                    status="ADVISORY_ONLY" if m15.ready else "CONTEXT_UNAVAILABLE",
                    reason_codes=() if m15.ready else ("M15_IS_ADVISORY_ONLY",),
                    order_blocks=(), traces=(), processed_candle_count=0,
                ))
                continue
            status, reasons = timeframe_status[timeframe]
            state = self._states.get((formation.symbol, timeframe), _TimeframeState())
            results.append(OrderBlockLifecycleTimeframeResult(
                symbol=formation.symbol, timeframe=timeframe, status=status,
                reason_codes=reasons,
                order_blocks=tuple(item.snapshot() for item in state.order_blocks.values()),
                traces=tuple(state.traces),
                processed_candle_count=len(state.candle_fingerprints),
            ))
        return ScalpingOrderBlockLifecycleResult(formation.symbol, view.captured_at_ms, tuple(results))

    def _validate_candidate(
        self, candidate: OrderBlockCandidate, symbol: str, view: ScalpingMarketDataView
    ) -> None:
        if not isinstance(candidate, OrderBlockCandidate):
            raise ScalpingOrderBlockLifecycleInputError("formation candidates must be OrderBlockCandidate values")
        if candidate.symbol != symbol or candidate.timeframe not in _SETUP_TIMEFRAMES:
            raise ScalpingOrderBlockLifecycleInputError("candidate symbol/timeframe is invalid for lifecycle")
        if isinstance(candidate.direction, bool) or candidate.direction not in (-1, 1):
            raise ScalpingOrderBlockLifecycleInputError("candidate direction must be -1 or 1")
        if not candidate.candidate_id or not candidate.event_id:
            raise ScalpingOrderBlockLifecycleInputError("candidate/event identity is required")
        if candidate.zone_top <= candidate.zone_bottom or candidate.zone_bottom <= 0:
            raise ScalpingOrderBlockLifecycleInputError("candidate OB zone boundaries are invalid")
        if candidate.break_bar_open_time_ms >= view.captured_at_ms:
            raise ScalpingOrderBlockLifecycleInputError("candidate break candle is not closed at capture time")
        interval_ms = INTERVAL_MILLISECONDS[candidate.timeframe]
        if candidate.break_confirmation_time_ms != candidate.break_bar_open_time_ms + interval_ms - 1:
            raise ScalpingOrderBlockLifecycleInputError("candidate break confirmation boundary is invalid")
        if (
            isinstance(candidate.source_open_time_ms, bool)
            or isinstance(candidate.break_bar_open_time_ms, bool)
            or candidate.source_open_time_ms % interval_ms
            or candidate.break_bar_open_time_ms % interval_ms
            or candidate.source_confirmation_time_ms != candidate.source_open_time_ms + interval_ms - 1
            or candidate.source_open_time_ms >= candidate.break_bar_open_time_ms
        ):
            raise ScalpingOrderBlockLifecycleInputError("candidate source-candle time provenance is invalid")
        if candidate.direction > 0 and candidate.source_close >= candidate.source_open:
            raise ScalpingOrderBlockLifecycleInputError("bullish OB source candle must be bearish")
        if candidate.direction < 0 and candidate.source_close <= candidate.source_open:
            raise ScalpingOrderBlockLifecycleInputError("bearish OB source candle must be bullish")
        if candidate.direction > 0 and candidate.break_close <= candidate.broken_structure_level:
            raise ScalpingOrderBlockLifecycleInputError("bullish break close must exceed broken structure")
        if candidate.direction < 0 and candidate.break_close >= candidate.broken_structure_level:
            raise ScalpingOrderBlockLifecycleInputError("bearish break close must be below broken structure")
        for price in (
            candidate.source_open, candidate.source_high, candidate.source_low, candidate.source_close,
            candidate.zone_top, candidate.zone_bottom, candidate.broken_structure_level,
            candidate.break_open, candidate.break_high, candidate.break_low, candidate.break_close,
        ):
            try:
                view.instrument.require_price_on_tick(price)
            except ScalpingMarketDataInputError as exc:
                raise ScalpingOrderBlockLifecycleInputError(str(exc)) from exc
        if candidate.source_high < max(candidate.source_open, candidate.source_low, candidate.source_close):
            raise ScalpingOrderBlockLifecycleInputError("candidate source OHLC is inconsistent")
        if candidate.source_low > min(candidate.source_open, candidate.source_high, candidate.source_close):
            raise ScalpingOrderBlockLifecycleInputError("candidate source OHLC is inconsistent")
        if candidate.zone_top != candidate.source_high or candidate.zone_bottom != candidate.source_low:
            raise ScalpingOrderBlockLifecycleInputError("Stage-3 candidate does not use full source-candle wick")

    @staticmethod
    def _validate_candle_series(
        candles: tuple[Kline, ...], symbol: str, timeframe: str, view: ScalpingMarketDataView
    ) -> None:
        if not candles:
            raise ScalpingOrderBlockLifecycleContinuityError("closed candle history is empty")
        interval_ms = INTERVAL_MILLISECONDS[timeframe]
        previous: Kline | None = None
        for candle in candles:
            if candle.exchange != "BINANCE_UM" or candle.symbol != symbol or candle.interval != timeframe:
                raise ScalpingOrderBlockLifecycleInputError("lifecycle candle identity mismatch")
            if candle.close_time_ms != candle.open_time_ms + interval_ms - 1:
                raise ScalpingOrderBlockLifecycleInputError("lifecycle candle close boundary is invalid")
            if candle.close_time_ms >= view.captured_at_ms:
                raise ScalpingOrderBlockLifecycleInputError("lifecycle input includes an unclosed candle")
            if previous is not None and candle.open_time_ms != previous.open_time_ms + interval_ms:
                raise ScalpingOrderBlockLifecycleContinuityError("Kline gap detected; lifecycle cannot infer traversal")
            for price in (candle.open, candle.high, candle.low, candle.close):
                try:
                    view.instrument.require_price_on_tick(price)
                except ScalpingMarketDataInputError as exc:
                    raise ScalpingOrderBlockLifecycleInputError(str(exc)) from exc
            previous = candle

    def _advance_timeframe(
        self,
        state: _TimeframeState,
        candidates: list[OrderBlockCandidate],
        candles: tuple[Kline, ...],
        timeframe: str,
        view: ScalpingMarketDataView,
    ) -> None:
        interval_ms = INTERVAL_MILLISECONDS[timeframe]
        candle_by_open = {item.open_time_ms: item for item in candles}
        new_candidates: list[OrderBlockCandidate] = []
        for candidate in candidates:
            fingerprint = _candidate_fingerprint(candidate)
            old = state.processed_candidate_fingerprints.get(candidate.candidate_id)
            if old is not None:
                if old != fingerprint:
                    raise ScalpingOrderBlockLifecycleInputError("candidate ID reused with conflicting payload")
                continue
            if candidate.candidate_id in state.order_blocks:
                if state.order_blocks[candidate.candidate_id].fingerprint != fingerprint:
                    raise ScalpingOrderBlockLifecycleInputError("candidate ID reused with conflicting lifecycle payload")
                continue
            if candidate.break_bar_open_time_ms not in candle_by_open:
                raise ScalpingOrderBlockLifecycleContinuityError(
                    "new candidate break candle is outside available history; refusing inferred lifecycle"
                )
            break_candle = candle_by_open[candidate.break_bar_open_time_ms]
            if (break_candle.open, break_candle.high, break_candle.low, break_candle.close) != (
                candidate.break_open, candidate.break_high, candidate.break_low, candidate.break_close
            ):
                raise ScalpingOrderBlockLifecycleContinuityError("candidate break candle was revised or mismatched")
            source_candle = candle_by_open.get(candidate.source_open_time_ms)
            if source_candle is None:
                raise ScalpingOrderBlockLifecycleContinuityError("candidate source candle is outside retained history")
            if (source_candle.open, source_candle.high, source_candle.low, source_candle.close) != (
                candidate.source_open, candidate.source_high, candidate.source_low, candidate.source_close
            ):
                raise ScalpingOrderBlockLifecycleContinuityError("candidate source candle was revised or mismatched")
            if state.last_processed_bar_open_time_ms is not None and candidate.break_bar_open_time_ms <= state.last_processed_bar_open_time_ms:
                raise ScalpingOrderBlockLifecycleContinuityError("late OB candidate predates already processed lifecycle bars")
            new_candidates.append(candidate)

        for open_time, fingerprint in state.candle_fingerprints.items():
            current = candle_by_open.get(open_time)
            if current is not None and _candle_fingerprint(current) != fingerprint:
                raise ScalpingOrderBlockLifecycleContinuityError("previously processed Kline was revised")

        if state.last_processed_bar_open_time_ms is not None:
            expected_next = state.last_processed_bar_open_time_ms + interval_ms
            new_candles = tuple(c for c in candles if c.open_time_ms > state.last_processed_bar_open_time_ms)
            if new_candles and new_candles[0].open_time_ms != expected_next:
                raise ScalpingOrderBlockLifecycleContinuityError("incremental lifecycle candle gap detected")
            if not new_candles and candles[-1].open_time_ms > state.last_processed_bar_open_time_ms:
                raise ScalpingOrderBlockLifecycleContinuityError("incremental lifecycle history is discontinuous")
            if not new_candles:
                return
        else:
            if new_candidates:
                first_break = min(item.break_bar_open_time_ms for item in new_candidates)
                if first_break < candles[0].open_time_ms:
                    raise ScalpingOrderBlockLifecycleContinuityError("candidate predates retained candle history")
                start_open = first_break
            else:
                start_open = candles[-1].open_time_ms
            new_candles = tuple(c for c in candles if c.open_time_ms >= start_open)

        candidate_by_break: dict[int, list[OrderBlockCandidate]] = {}
        for candidate in new_candidates:
            candidate_by_break.setdefault(candidate.break_bar_open_time_ms, []).append(candidate)

        for candle in new_candles:
            for candidate in candidate_by_break.get(candle.open_time_ms, ()):
                while len(state.order_blocks) >= self.config.max_order_blocks_per_timeframe:
                    terminal_id = next(
                        (candidate_id for candidate_id, item in state.order_blocks.items()
                         if item.status in _TERMINAL),
                        None,
                    )
                    if terminal_id is None:
                        raise ScalpingOrderBlockLifecycleCapacityError(
                            "per-timeframe OB lifecycle capacity reached with no terminal record eligible for eviction"
                        )
                    del state.order_blocks[terminal_id]
                fingerprint = _candidate_fingerprint(candidate)
                lifecycle = _MutableLifecycle(candidate=candidate, fingerprint=fingerprint)
                state.order_blocks[candidate.candidate_id] = lifecycle
                state.processed_candidate_fingerprints[candidate.candidate_id] = fingerprint
                self._trace(state, lifecycle, transition="CANDIDATE_CREATED", from_status=None,
                            to_status="CANDIDATE", observed_time_ms=candle.close_time_ms,
                            bar_open_time_ms=candle.open_time_ms, price=None, depth=None,
                            reason="STAGE3_OB_CANDIDATE_ACCEPTED")

            for lifecycle in state.order_blocks.values():
                if lifecycle.status in _TERMINAL or lifecycle.candidate.break_bar_open_time_ms >= candle.open_time_ms:
                    continue
                self._process_candle(state, lifecycle, candle, interval_ms)

            state.candle_fingerprints[candle.open_time_ms] = _candle_fingerprint(candle)
            state.last_processed_bar_open_time_ms = candle.open_time_ms

        for mapping, maximum in (
            (state.candle_fingerprints, self.config.max_candle_fingerprints_per_timeframe),
            (state.processed_candidate_fingerprints, self.config.max_order_blocks_per_timeframe * 2),
        ):
            while len(mapping) > maximum:
                mapping.pop(next(iter(mapping)))
        if len(state.traces) > self.config.max_traces_per_timeframe:
            del state.traces[: len(state.traces) - self.config.max_traces_per_timeframe]

    def _process_candle(
        self, state: _TimeframeState, lifecycle: _MutableLifecycle, candle: Kline, interval_ms: int
    ) -> None:
        candidate = lifecycle.candidate
        age = (candle.open_time_ms - candidate.break_bar_open_time_ms) // interval_ms
        if age <= 0 or candle.open_time_ms != candidate.break_bar_open_time_ms + age * interval_ms:
            raise ScalpingOrderBlockLifecycleContinuityError("OB age is not aligned to source timeframe bars")
        lifecycle.age_bars = age
        lifecycle.last_processed_bar_open_time_ms = candle.open_time_ms

        if age > self.config.max_age_bars:
            previous = lifecycle.status
            lifecycle.status = "EXPIRED"
            lifecycle.expiry_time_ms = candle.close_time_ms
            lifecycle.expiry_reason = "SOURCE_TIMEFRAME_AGE_EXCEEDED"
            self._trace(state, lifecycle, transition="EXPIRED", from_status=previous,
                        to_status="EXPIRED", observed_time_ms=candle.close_time_ms,
                        bar_open_time_ms=candle.open_time_ms, price=candle.close,
                        depth=lifecycle.maximum_mitigation_depth_ratio,
                        reason="SOURCE_TIMEFRAME_AGE_EXCEEDED")
            return

        if lifecycle.status == "CANDIDATE":
            lifecycle.status = "ACTIVE_FRESH"
            self._trace(state, lifecycle, transition="ACTIVATED", from_status="CANDIDATE",
                        to_status="ACTIVE_FRESH", observed_time_ms=candle.close_time_ms,
                        bar_open_time_ms=candle.open_time_ms, price=None, depth=None,
                        reason="FIRST_POST_BREAK_CLOSED_CANDLE")

        top, bottom = candidate.zone_top, candidate.zone_bottom
        touched = candle.low <= top and candle.high >= bottom
        if touched and lifecycle.first_touch_time_ms is None:
            lifecycle.first_touch_time_ms = candle.close_time_ms
            lifecycle.first_touch_bar_open_time_ms = candle.open_time_ms
            if lifecycle.status == "ACTIVE_FRESH":
                previous = lifecycle.status
                lifecycle.status = "TOUCHED"
                self._trace(state, lifecycle, transition="FIRST_ZONE_TOUCH", from_status=previous,
                            to_status="TOUCHED", observed_time_ms=candle.close_time_ms,
                            bar_open_time_ms=candle.open_time_ms, price=(candle.low if candidate.direction > 0 else candle.high),
                            depth=Decimal("0"), reason="CANDLE_RANGE_INTERSECTS_OB_ZONE")

        depth, depth_price = self._mitigation_depth(candidate, candle)
        if depth > lifecycle.maximum_mitigation_depth_ratio:
            previous_depth = lifecycle.maximum_mitigation_depth_ratio
            lifecycle.maximum_mitigation_depth_ratio = depth
            lifecycle.maximum_mitigation_price = depth_price
            if depth > 0 and lifecycle.mitigation_time_ms is None:
                lifecycle.mitigation_time_ms = candle.close_time_ms
                if lifecycle.status in ("ACTIVE_FRESH", "TOUCHED"):
                    previous = lifecycle.status
                    lifecycle.status = "MITIGATED"
                    self._trace(state, lifecycle, transition="MITIGATION_STARTED", from_status=previous,
                                to_status="MITIGATED", observed_time_ms=candle.close_time_ms,
                                bar_open_time_ms=candle.open_time_ms, price=depth_price, depth=depth,
                                reason="PRICE_PENETRATED_OB_ENTRY_SIDE")
            elif depth > previous_depth:
                self._trace(state, lifecycle, transition="MITIGATION_DEPTH_INCREASED",
                            from_status=lifecycle.status, to_status=lifecycle.status,
                            observed_time_ms=candle.close_time_ms, bar_open_time_ms=candle.open_time_ms,
                            price=depth_price, depth=depth, reason="MAXIMUM_PENETRATION_DEPTH_UPDATED")

        invalidated, invalidation_price, reason = self._is_invalidated(candidate, candle)
        if invalidated:
            previous = lifecycle.status
            lifecycle.status = "INVALIDATED"
            lifecycle.invalidation_time_ms = candle.close_time_ms
            lifecycle.invalidation_bar_open_time_ms = candle.open_time_ms
            lifecycle.invalidation_price = invalidation_price
            lifecycle.invalidation_reason = reason
            self._trace(state, lifecycle, transition="INVALIDATED", from_status=previous,
                        to_status="INVALIDATED", observed_time_ms=candle.close_time_ms,
                        bar_open_time_ms=candle.open_time_ms, price=invalidation_price,
                        depth=lifecycle.maximum_mitigation_depth_ratio, reason=reason)

    @staticmethod
    def _mitigation_depth(candidate: OrderBlockCandidate, candle: Kline) -> tuple[Decimal, Decimal | None]:
        # A candle entirely beyond the distal edge may indicate invalidation,
        # but it does not prove a traded range intersection with the zone.
        if candle.low > candidate.zone_top or candle.high < candidate.zone_bottom:
            return Decimal("0"), None
        height = candidate.zone_top - candidate.zone_bottom
        if candidate.direction > 0:
            if candle.low > candidate.zone_top:
                return Decimal("0"), None
            price = min(candle.low, candidate.zone_top)
            depth = (candidate.zone_top - price) / height
        else:
            if candle.high < candidate.zone_bottom:
                return Decimal("0"), None
            price = max(candle.high, candidate.zone_bottom)
            depth = (price - candidate.zone_bottom) / height
        return min(Decimal("1"), max(Decimal("0"), depth)), price

    def _is_invalidated(self, candidate: OrderBlockCandidate, candle: Kline) -> tuple[bool, Decimal | None, str]:
        if self.config.invalidation_mode == "WICK":
            observed = candle.low if candidate.direction > 0 else candle.high
            boundary = candidate.zone_bottom if candidate.direction > 0 else candidate.zone_top
            reason_prefix = "WICK"
        else:
            observed = candle.close
            boundary = candidate.zone_bottom if candidate.direction > 0 else candidate.zone_top
            reason_prefix = "CLOSE"
        if candidate.direction > 0:
            invalidated = observed <= boundary if self.config.invalidation_boundary == "INCLUSIVE" else observed < boundary
        else:
            invalidated = observed >= boundary if self.config.invalidation_boundary == "INCLUSIVE" else observed > boundary
        return invalidated, observed if invalidated else None, f"{reason_prefix}_BEYOND_DISTAL_OB_BOUNDARY" if invalidated else ""

    @staticmethod
    def _trace(
        state: _TimeframeState,
        lifecycle: _MutableLifecycle,
        *,
        transition: str,
        from_status: str | None,
        to_status: str,
        observed_time_ms: int,
        bar_open_time_ms: int | None,
        price: Decimal | None,
        depth: Decimal | None,
        reason: str,
    ) -> None:
        candidate = lifecycle.candidate
        state.traces.append(OrderBlockLifecycleTrace(
            candidate_id=candidate.candidate_id, event_id=candidate.event_id,
            symbol=candidate.symbol, timeframe=candidate.timeframe,
            transition=transition, from_status=from_status, to_status=to_status,
            observed_time_ms=observed_time_ms, bar_open_time_ms=bar_open_time_ms,
            age_bars=lifecycle.age_bars, observed_price=price,
            mitigation_depth_ratio=depth, reason_code=reason,
        ))
