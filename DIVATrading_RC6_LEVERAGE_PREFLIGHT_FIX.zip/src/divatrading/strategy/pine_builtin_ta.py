"""Pine v6 built-in TA series used by the audited SMC indicator.

The engine intentionally maintains these series over the entire loaded source
history. They are independent from the SMC ``warmupBars`` state reset.

Only the built-ins used by the audited source in Unit 05D Stage 4 are covered:
ATR(14), RSI(14), SMA(volume, 20), and DMI(14, 14). This is not a general TA
library and deliberately exposes unavailable values as ``None`` (JSON null).
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math

from divatrading.market_data.klines import Kline


@dataclass(frozen=True, slots=True)
class PineBuiltinTAValues:
    """Raw Pine built-in outputs for one source candle."""

    atr_fast_now: float | None
    rsi_now: float | None
    volume_avg_now: float | None
    di_plus_now: float | None
    di_minus_now: float | None
    adx_now: float | None


@dataclass(slots=True)
class _PineRMA:
    """ta.rma seed (SMA of N observations), then Wilder recurrence."""

    length: int
    seed_sum: float = 0.0
    seed_count: int = 0
    value: float | None = None

    def update(self, source: float | None) -> float | None:
        # Pine TA functions ignore na source observations. The audited candle
        # feeds have no interior gaps; None occurs only at the leading edge.
        if source is None:
            return None
        if not math.isfinite(source):
            raise ValueError("Pine RMA source must be finite or unavailable")
        if self.value is None:
            self.seed_sum += source
            self.seed_count += 1
            if self.seed_count < self.length:
                return None
            self.value = self.seed_sum / self.length
            return self.value
        alpha = 1.0 / self.length
        self.value = alpha * source + (1.0 - alpha) * self.value
        return self.value


@dataclass(slots=True)
class PineBuiltinTAEngine:
    """Streaming implementation of the four Pine TA calls in the source."""

    atr_rma: _PineRMA = field(init=False)
    rsi_gain_rma: _PineRMA = field(init=False)
    rsi_loss_rma: _PineRMA = field(init=False)
    dmi_tr_rma: _PineRMA = field(init=False)
    dmi_plus_rma: _PineRMA = field(init=False)
    dmi_minus_rma: _PineRMA = field(init=False)
    adx_rma: _PineRMA = field(init=False)
    volumes: deque[float] = field(init=False)
    volume_sum: float = 0.0
    previous_close: float | None = None
    previous_high: float | None = None
    previous_low: float | None = None
    last_di_plus: float | None = None
    last_di_minus: float | None = None

    def __post_init__(self) -> None:
        self.atr_rma = _PineRMA(14)
        self.rsi_gain_rma = _PineRMA(14)
        self.rsi_loss_rma = _PineRMA(14)
        self.dmi_tr_rma = _PineRMA(14)
        self.dmi_plus_rma = _PineRMA(14)
        self.dmi_minus_rma = _PineRMA(14)
        self.adx_rma = _PineRMA(14)
        self.volumes = deque()

    def update(self, candle: Kline) -> PineBuiltinTAValues:
        """Advance all built-ins by one contiguous source bar."""

        high = float(candle.high)
        low = float(candle.low)
        close = float(candle.close)
        volume = float(candle.volume)
        if not all(math.isfinite(value) for value in (high, low, close, volume)):
            raise ValueError("Pine built-in TA inputs must be finite")

        # ta.atr(14) uses ta.tr(true): the first bar falls back to high-low.
        true_range_atr = high - low
        if self.previous_close is not None:
            true_range_atr = max(
                true_range_atr,
                abs(high - self.previous_close),
                abs(low - self.previous_close),
            )
        atr_fast = self.atr_rma.update(true_range_atr)

        # ta.rsi(close, 14) is equivalent to the Pine expression
        # `change = change(close); gain = change >= 0 ? change : 0.0;
        # loss = change < 0 ? -change : 0.0`. On source bar zero change is na;
        # Pine v6 comparisons involving na return false, so both ternaries take
        # their 0.0 branches. Those zeros are part of the initial 14-value RMA
        # seed; the first RSI can therefore appear on source bar index 13.
        change = None if self.previous_close is None else close - self.previous_close
        gain = 0.0 if change is None else max(change, 0.0)
        loss = 0.0 if change is None else max(-change, 0.0)
        average_gain = self.rsi_gain_rma.update(gain)
        average_loss = self.rsi_loss_rma.update(loss)
        rsi: float | None = None
        if average_gain is not None and average_loss is not None:
            if average_loss == 0.0:
                # The Pine ratio is +inf for positive gain / zero loss and na
                # for the flat 0/0 case.
                rsi = 100.0 if average_gain > 0.0 else None
            elif average_gain == 0.0:
                rsi = 0.0
            else:
                relative_strength = average_gain / average_loss
                rsi = 100.0 - (100.0 / (1.0 + relative_strength))

        # ta.sma(volume, 20): na until 20 source volumes are available.
        self.volumes.append(volume)
        self.volume_sum += volume
        if len(self.volumes) > 20:
            self.volume_sum -= self.volumes.popleft()
        volume_average = self.volume_sum / 20.0 if len(self.volumes) == 20 else None

        # ta.dmi(14, 14) follows the Wilder directional-movement sequence.
        # The `ta.tr` series (not ta.tr(true)) is na on the first bar.
        if self.previous_close is None:
            dmi_true_range = None
            plus_dm = None
            minus_dm = None
        else:
            dmi_true_range = true_range_atr
            up_move = high - (self.previous_high if self.previous_high is not None else high)
            down_move = (self.previous_low if self.previous_low is not None else low) - low
            plus_dm = up_move if up_move > down_move and up_move > 0.0 else 0.0
            minus_dm = down_move if down_move > up_move and down_move > 0.0 else 0.0

        smoothed_tr = self.dmi_tr_rma.update(dmi_true_range)
        smoothed_plus = self.dmi_plus_rma.update(plus_dm)
        smoothed_minus = self.dmi_minus_rma.update(minus_dm)

        di_plus_candidate: float | None = None
        di_minus_candidate: float | None = None
        if smoothed_tr is not None and smoothed_plus is not None:
            if smoothed_tr != 0.0:
                di_plus_candidate = 100.0 * smoothed_plus / smoothed_tr
        if smoothed_tr is not None and smoothed_minus is not None:
            if smoothed_tr != 0.0:
                di_minus_candidate = 100.0 * smoothed_minus / smoothed_tr

        # Pine's standard DMI implementation applies fixnan() to each DI line.
        # Before a valid value exists, it remains unavailable; later na values
        # carry the most recent valid DI forward.
        if di_plus_candidate is not None:
            self.last_di_plus = di_plus_candidate
        if di_minus_candidate is not None:
            self.last_di_minus = di_minus_candidate
        di_plus = self.last_di_plus
        di_minus = self.last_di_minus

        dx: float | None = None
        if di_plus is not None and di_minus is not None:
            di_sum = di_plus + di_minus
            denominator = 1.0 if di_sum == 0.0 else di_sum
            dx = abs(di_plus - di_minus) / denominator
        smoothed_dx = self.adx_rma.update(dx)
        adx = None if smoothed_dx is None else 100.0 * smoothed_dx

        self.previous_close = close
        self.previous_high = high
        self.previous_low = low
        return PineBuiltinTAValues(
            atr_fast_now=atr_fast,
            rsi_now=rsi,
            volume_avg_now=volume_average,
            di_plus_now=di_plus,
            di_minus_now=di_minus,
            adx_now=adx,
        )
