"""Deterministic replay of source-derived Pine SMC structure state.

This module implements audited Pine source behavior for warmup reset, custom
ATR(200), parsed candle extremes, swing/internal pivot legs, structure events,
the active OB/FVG lifecycle, Pine built-in TA/regime pre-roll, read-only
ordered OB eligibility, trigger/sweep qualification, OB scoring / ideal entry
bands, and local Pine entry/SL/TP proxy geometry. The one-source-bar confirmed
output shift and chart-level MTF arbitration remain out of scope.

Pine ``float`` calculations use IEEE-754 binary64. Market-data Kline values are
retained as Decimal in the existing data layer and converted to Python ``float``
only at this Pine calculation boundary.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import math
from decimal import Decimal
from typing import Iterable, Sequence

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy.pine_builtin_ta import PineBuiltinTAEngine, PineBuiltinTAValues


class PineSmcReplayError(ValueError):
    """Raised when a replay input cannot reproduce a valid Pine source series."""


@dataclass(frozen=True, slots=True)
class PineSmcStructureConfig:
    """Effective Pine inputs required by the implemented structure slices."""

    symbol: str
    timeframe: str
    warmup_bars: int = 1500
    swing_len: int = 50
    internal_len: int = 5
    confluence_filter: bool = False
    fvg_min_atr: float = 0.10
    mitigate_close: bool = False
    use_volatility_regime: bool = True
    low_vol_ratio: float = 0.70
    high_vol_ratio: float = 1.60
    extreme_vol_ratio: float = 2.40
    choppy_adx_max: float = 16.0
    max_age_m15: int = 150
    max_age_m5: int = 300
    fresh_only: bool = True
    use_trend_filter: bool = True
    use_pd_filter: bool = True
    require_fvg: bool = False
    trigger_mode: str = "Either"
    struct_allow_bos: bool = True
    min_wick_pct: float = 20.0
    require_sweep: bool = False
    sweep_lookback: int = 20
    sweep_window: int = 5
    # syminfo.mintick is exchange-symbol metadata, not inferable from OHLCV.
    # Keep it optional so the earlier source-derived stages remain usable; Stage
    # 7 scoring and Stage 8 level geometry fail closed until exact tick metadata
    # for the same Binance USD-M instrument is supplied.
    tick_size: float | Decimal | None = None
    entry_depth_near: float = 0.50
    entry_depth_deep: float = 0.80
    # Pine baseline level geometry inputs (not exchange execution settings).
    sl_buffer_atr: float = 0.10
    sl_spread_mult: float = 2.0
    max_sl_atr: float = 3.0
    max_spread_sl_pct: float = 20.0
    high_vol_sl_mult: float = 1.50
    tp_mode: str = "Fixed RR"
    rr: float = 2.0
    min_rr: float = 1.5
    spread_estimate_ticks: float = 0.0
    min_stop_ticks: float = 1.0
    consume_ob_on_signal: bool = True

    def __post_init__(self) -> None:
        normalized_symbol = self.symbol.strip().upper() if isinstance(self.symbol, str) else ""
        if not normalized_symbol:
            raise PineSmcReplayError("symbol is required")
        object.__setattr__(self, "symbol", normalized_symbol)
        if self.timeframe not in INTERVAL_MILLISECONDS:
            raise PineSmcReplayError("timeframe must be one of: 1m, 5m, 15m")
        if isinstance(self.warmup_bars, bool) or not isinstance(self.warmup_bars, int):
            raise PineSmcReplayError("warmup_bars must be an integer")
        if not 300 <= self.warmup_bars <= 2500:
            raise PineSmcReplayError("warmup_bars must be between 300 and 2500 (Pine input range)")
        if isinstance(self.swing_len, bool) or not isinstance(self.swing_len, int):
            raise PineSmcReplayError("swing_len must be an integer")
        if not 2 <= self.swing_len <= 100:
            raise PineSmcReplayError("swing_len must be between 2 and 100 (Pine input range)")
        if isinstance(self.internal_len, bool) or not isinstance(self.internal_len, int):
            raise PineSmcReplayError("internal_len must be an integer")
        if not 1 <= self.internal_len <= 25:
            raise PineSmcReplayError("internal_len must be between 1 and 25 (Pine input range)")
        if not isinstance(self.confluence_filter, bool):
            raise PineSmcReplayError("confluence_filter must be a bool")
        if isinstance(self.fvg_min_atr, bool) or not isinstance(self.fvg_min_atr, (int, float)):
            raise PineSmcReplayError("fvg_min_atr must be a finite non-negative number")
        normalized_fvg_min_atr = float(self.fvg_min_atr)
        if not math.isfinite(normalized_fvg_min_atr) or normalized_fvg_min_atr < 0:
            raise PineSmcReplayError("fvg_min_atr must be a finite non-negative number")
        object.__setattr__(self, "fvg_min_atr", normalized_fvg_min_atr)
        if not isinstance(self.mitigate_close, bool):
            raise PineSmcReplayError("mitigate_close must be a bool")
        if not isinstance(self.use_volatility_regime, bool):
            raise PineSmcReplayError("use_volatility_regime must be a bool")
        regime_ranges = (
            ("low_vol_ratio", self.low_vol_ratio, 0.1, 2.0),
            ("high_vol_ratio", self.high_vol_ratio, 0.5, 4.0),
            ("extreme_vol_ratio", self.extreme_vol_ratio, 0.8, 6.0),
            ("choppy_adx_max", self.choppy_adx_max, 5.0, 40.0),
        )
        for name, raw_value, lower, upper in regime_ranges:
            if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
                raise PineSmcReplayError(f"{name} must be a finite number in [{lower}, {upper}]")
            value = float(raw_value)
            if not math.isfinite(value) or not lower <= value <= upper:
                raise PineSmcReplayError(f"{name} must be a finite number in [{lower}, {upper}]")
            object.__setattr__(self, name, value)
        for name in ("max_age_m15", "max_age_m5"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise PineSmcReplayError(f"{name} must be an integer >= 1")
        for name in ("fresh_only", "use_trend_filter", "use_pd_filter", "require_fvg"):
            if not isinstance(getattr(self, name), bool):
                raise PineSmcReplayError(f"{name} must be a bool")
        if self.trigger_mode not in ("Rejection", "Structure", "Either"):
            raise PineSmcReplayError("trigger_mode must be Rejection, Structure or Either")
        if not isinstance(self.struct_allow_bos, bool):
            raise PineSmcReplayError("struct_allow_bos must be a bool")
        if isinstance(self.min_wick_pct, bool) or not isinstance(self.min_wick_pct, (int, float)):
            raise PineSmcReplayError("min_wick_pct must be a finite number in [0, 100]")
        normalized_min_wick_pct = float(self.min_wick_pct)
        if not math.isfinite(normalized_min_wick_pct) or not 0.0 <= normalized_min_wick_pct <= 100.0:
            raise PineSmcReplayError("min_wick_pct must be a finite number in [0, 100]")
        object.__setattr__(self, "min_wick_pct", normalized_min_wick_pct)
        if not isinstance(self.require_sweep, bool):
            raise PineSmcReplayError("require_sweep must be a bool")
        if (
            isinstance(self.sweep_lookback, bool)
            or not isinstance(self.sweep_lookback, int)
            or not 2 <= self.sweep_lookback <= 100
        ):
            raise PineSmcReplayError("sweep_lookback must be an integer in [2, 100]")
        if (
            isinstance(self.sweep_window, bool)
            or not isinstance(self.sweep_window, int)
            or not 1 <= self.sweep_window <= 20
        ):
            raise PineSmcReplayError("sweep_window must be an integer in [1, 20]")
        if self.tick_size is not None:
            if isinstance(self.tick_size, bool) or not isinstance(self.tick_size, (int, float, Decimal)):
                raise PineSmcReplayError("tick_size must be a finite positive number or None")
            normalized_tick_size = float(self.tick_size)
            if not math.isfinite(normalized_tick_size) or normalized_tick_size <= 0.0:
                raise PineSmcReplayError("tick_size must be a finite positive number or None")
            object.__setattr__(self, "tick_size", normalized_tick_size)
        for name, raw_value, lower, upper in (
            ("entry_depth_near", self.entry_depth_near, 0.20, 0.75),
            ("entry_depth_deep", self.entry_depth_deep, 0.25, 0.95),
            ("sl_buffer_atr", self.sl_buffer_atr, 0.0, math.inf),
            ("sl_spread_mult", self.sl_spread_mult, 0.0, math.inf),
            ("max_sl_atr", self.max_sl_atr, 0.5, math.inf),
            ("max_spread_sl_pct", self.max_spread_sl_pct, 0.0, math.inf),
            ("high_vol_sl_mult", self.high_vol_sl_mult, 1.0, 3.0),
            ("rr", self.rr, 0.25, math.inf),
            ("min_rr", self.min_rr, 0.25, math.inf),
            ("spread_estimate_ticks", self.spread_estimate_ticks, 0.0, math.inf),
            ("min_stop_ticks", self.min_stop_ticks, 0.0, math.inf),
        ):
            if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
                raise PineSmcReplayError(f"{name} must be a finite number in [{lower}, {upper}]")
            value = float(raw_value)
            if not math.isfinite(value) or not lower <= value <= upper:
                raise PineSmcReplayError(f"{name} must be a finite number in [{lower}, {upper}]")
            if not math.isfinite(value):
                raise PineSmcReplayError(f"{name} must be a finite number in [{lower}, {upper}]")
            object.__setattr__(self, name, value)
        if self.tp_mode not in ("Fixed RR", "Structure", "Hybrid OB/Liquidity"):
            raise PineSmcReplayError(
                "tp_mode must be Fixed RR, Structure or Hybrid OB/Liquidity"
            )
        if not isinstance(self.consume_ob_on_signal, bool):
            raise PineSmcReplayError("consume_ob_on_signal must be a bool")


@dataclass(frozen=True, slots=True)
class ParsedCandleExtremes:
    """Pine parsed candle result; high/low inversion in high-volatility bars is intentional."""

    high_volatility: bool
    parsed_high: float
    parsed_low: float


def parse_candle_extremes(*, high: float, low: float, atr200: float) -> ParsedCandleExtremes:
    """Apply Pine lines 368–370 exactly, including the intentional swapped extremes."""

    if not all(math.isfinite(value) for value in (high, low, atr200)):
        raise PineSmcReplayError("high, low and atr200 must be finite")
    if high < low:
        raise PineSmcReplayError("high cannot be below low")
    if atr200 < 0:
        raise PineSmcReplayError("atr200 cannot be negative")
    high_volatility = (high - low) >= 2.0 * atr200
    if high_volatility:
        return ParsedCandleExtremes(True, low, high)
    return ParsedCandleExtremes(False, high, low)


@dataclass(frozen=True, slots=True)
class PinePivotPointTrace:
    """Observable state for one Pine swing/internal high or low pivot."""

    current: float
    previous: float
    crossed: bool
    valid: bool
    local_index: int
    source_time_ms: int | None


@dataclass(frozen=True, slots=True)
class PineSmcOrderBlockTrace:
    """Immutable source-derived active order-block record."""

    top: float
    bottom: float
    bar_local_index: int
    break_local_index: int
    source_time_ms: int
    break_time_ms: int
    bias: int
    has_fvg: bool
    used: bool


@dataclass(frozen=True, slots=True)
class PineSmcObLifecycleEvents:
    """OB collection mutations performed on one source candle."""

    created: tuple[PineSmcOrderBlockTrace, ...] = ()
    mitigated: tuple[PineSmcOrderBlockTrace, ...] = ()
    evicted: tuple[PineSmcOrderBlockTrace, ...] = ()


@dataclass(frozen=True, slots=True)
class PineSmcObCandidateEvaluation:
    """One OB's ordered eligibility result from Pine ``FindSignal`` gates."""

    active_array_index: int
    order_block: PineSmcOrderBlockTrace
    eligible: bool
    rejection_reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PineSmcObEligibilityTrace:
    """Immutable newest-to-oldest OB eligibility scan for one source candle."""

    max_age: int
    scanned_newest_to_oldest: tuple[PineSmcObCandidateEvaluation, ...] = ()
    eligible_candidates: tuple[PineSmcObCandidateEvaluation, ...] = ()


@dataclass(frozen=True, slots=True)
class PineSmcObTriggerEvaluation:
    """Trigger and sweep result for one Stage-5-eligible OB candidate.

    ``trigger_code`` follows Pine's integer encoding: 0 = no trigger,
    1 = rejection, 2 = structure. ``accepted`` means only that the trigger is
    non-zero and the optional sweep gate passed; it is not a final signal.
    """

    active_array_index: int
    order_block: PineSmcOrderBlockTrace
    rejection_trigger: bool
    structure_trigger: bool
    trigger_code: int
    sweep_passed: bool
    accepted: bool


@dataclass(frozen=True, slots=True)
class PineSmcTriggerSweepTrace:
    """Ordered Stage-6 trigger/sweep scan and first accepted candidate."""

    trigger_mode: str
    require_sweep: bool
    scanned_candidates: tuple[PineSmcObTriggerEvaluation, ...] = ()
    chosen_active_array_index: int | None = None
    chosen_trigger_code: int = 0


@dataclass(frozen=True, slots=True)
class PineSmcObScoreTrace:
    """Pine ``f_scoreOB`` output for one active OB, without candidate mutation."""

    active_array_index: int
    order_block: PineSmcOrderBlockTrace
    age: int
    entry_band_low: float
    entry_band_high: float
    ob_quality_score: float
    timing_score: float
    setup_score: float
    volatility_score: float
    displacement_score: float
    source_candle_score: float
    rsi_score: float
    trend_score: float
    fvg_score: float
    volume_score: float
    freshness_score: float
    current_candle_score: float
    proximity_score: float
    sweep_score: float
    swept_current_candle: bool


@dataclass(frozen=True, slots=True)
class PineSmcObScoringTrace:
    """Read-only Stage-7 scoring for active OBs and the Stage-6 chosen candidate.

    Active scores preserve the Pine diagnostic CSV's oldest-to-newest array
    order. ``chosen_score`` is a reference to the already-selected Stage-6
    candidate's score; scoring never changes candidate selection.
    """

    available: bool
    unavailable_reason: str | None
    tick_size: float | None
    max_age: int
    near_depth: float
    deep_depth: float
    prior_lowest_sweep: float | None
    prior_highest_sweep: float | None
    active_order_block_scores: tuple[PineSmcObScoreTrace, ...] = ()
    chosen_active_array_index: int | None = None
    chosen_score: PineSmcObScoreTrace | None = None


@dataclass(frozen=True, slots=True)
class PineSmcSignalProxy:
    """Unshifted local Pine signal/level record; entry is a close proxy, not a fill."""

    source_time_ms: int
    direction: int
    trigger_code: int
    active_array_index: int
    order_block: PineSmcOrderBlockTrace
    entry_proxy: float
    stop_loss_proxy: float
    take_profit_proxy: float
    spread_price: float
    stop_buffer: float
    stop_distance: float
    minimum_stop_distance: float
    structural_target: float | None
    opposing_ob_target: float | None
    target_source: str
    final_reward: float
    risk_reward: float
    setup_score: float
    quality_score: float
    timing_score: float
    entry_band_low: float
    entry_band_high: float
    ob_consumed_by_signal_proxy: bool


@dataclass(frozen=True, slots=True)
class PineSmcLevelEvaluationTrace:
    """Pine's local level validation result before the later one-bar output shift."""

    attempted: bool
    available: bool
    accepted: bool
    unavailable_reason: str | None
    rejection_reasons: tuple[str, ...] = ()
    chosen_active_array_index: int | None = None
    chosen_trigger_code: int = 0
    entry_proxy: float | None = None
    spread_price: float | None = None
    stop_buffer: float | None = None
    stop_loss_proxy: float | None = None
    stop_distance: float | None = None
    minimum_stop_distance: float | None = None
    structural_target: float | None = None
    opposing_ob_target: float | None = None
    target_source: str | None = None
    take_profit_proxy: float | None = None
    final_reward: float | None = None
    risk_reward: float | None = None
    ob_consumed_by_signal_proxy: bool = False
    signal: PineSmcSignalProxy | None = None


@dataclass(frozen=True, slots=True)
class PineSmcIndicatorTrace:
    """Pine built-in TA and volatility-regime values for one active SMC bar.

    Optional numeric fields are ``None`` when the corresponding Pine series is
    still ``na`` during full-history pre-roll. ``atr200_ratio_base`` records the
    ATR(200) value visible to Pine before this bar's in-warmup update.
    """

    atr_fast_now: float | None
    rsi_now: float | None
    volume_avg_now: float | None
    di_plus_now: float | None
    di_minus_now: float | None
    adx_now: float | None
    atr200_ratio_base: float
    atr_ratio_now: float | None
    volatility_extreme: bool
    volatility_choppy: bool


@dataclass(frozen=True, slots=True)
class PineSmcBarTrace:
    """Deterministic per-source-bar trace for structure and OB lifecycle slices."""

    symbol: str
    timeframe: str
    source_bar_index: int
    local_index: int
    source_time_ms: int
    reset_start_index: int
    true_range: float
    tr_sum: float
    atr200: float
    indicators: PineSmcIndicatorTrace
    high_volatility: bool
    parsed_high: float
    parsed_low: float
    swing_leg: int
    internal_leg: int
    swing_high: PinePivotPointTrace
    swing_low: PinePivotPointTrace
    internal_high: PinePivotPointTrace
    internal_low: PinePivotPointTrace
    swing_trend: int
    internal_trend: int
    structure_events: "PineSmcStructureEvents"
    ob_lifecycle: PineSmcObLifecycleEvents
    active_order_blocks: tuple[PineSmcOrderBlockTrace, ...]
    ob_eligibility: PineSmcObEligibilityTrace
    trigger_sweep: PineSmcTriggerSweepTrace
    ob_scoring: PineSmcObScoringTrace
    level_evaluation: PineSmcLevelEvaluationTrace
    range_top: float
    range_top_valid: bool
    range_bottom: float
    range_bottom_valid: bool

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-compatible representation with stable field names."""

        return asdict(self)


@dataclass(frozen=True, slots=True)
class PineSmcStructureEvents:
    """Pine internal-structure events and event-extreme observation for one bar."""

    bullish_bar: bool
    bearish_bar: bool
    bull_choch: bool
    bear_choch: bool
    bull_bos: bool
    bear_bos: bool
    extreme: float
    extreme_local_index: int
    extreme_source_time_ms: int | None


@dataclass(frozen=True, slots=True)
class PineSmcStructureReplayResult:
    """Replay metadata and traces for one independent Pine timeframe context."""

    symbol: str
    timeframe: str
    warmup_bars: int
    swing_len: int
    internal_len: int
    confluence_filter: bool
    fvg_min_atr: float
    mitigate_close: bool
    use_volatility_regime: bool
    low_vol_ratio: float
    high_vol_ratio: float
    extreme_vol_ratio: float
    choppy_adx_max: float
    max_age_m15: int
    max_age_m5: int
    fresh_only: bool
    use_trend_filter: bool
    use_pd_filter: bool
    require_fvg: bool
    trigger_mode: str
    struct_allow_bos: bool
    min_wick_pct: float
    require_sweep: bool
    sweep_lookback: int
    sweep_window: int
    tick_size: float | None
    entry_depth_near: float
    entry_depth_deep: float
    sl_buffer_atr: float
    sl_spread_mult: float
    max_sl_atr: float
    max_spread_sl_pct: float
    high_vol_sl_mult: float
    tp_mode: str
    rr: float
    min_rr: float
    spread_estimate_ticks: float
    min_stop_ticks: float
    consume_ob_on_signal: bool
    source_bar_count: int
    last_bar_index: int
    reset_start_index: int
    trace: tuple[PineSmcBarTrace, ...]

    @property
    def processed_bar_count(self) -> int:
        return len(self.trace)

    def to_jsonl(self) -> str:
        """Serialize traces deterministically; one sorted-key JSON object per line."""

        return "".join(
            json.dumps(row.to_dict(), sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
            for row in self.trace
        )


@dataclass(slots=True)
class _PivotPointState:
    current: float = 0.0
    previous: float = 0.0
    crossed: bool = False
    valid: bool = False
    local_index: int = -1
    source_time_ms: int | None = None

    def update(self, value: float, *, local_index: int, source_time_ms: int) -> None:
        self.previous = self.current
        self.current = value
        self.crossed = False
        self.valid = True
        self.local_index = local_index
        self.source_time_ms = source_time_ms

    def snapshot(self) -> PinePivotPointTrace:
        return PinePivotPointTrace(
            current=self.current,
            previous=self.previous,
            crossed=self.crossed,
            valid=self.valid,
            local_index=self.local_index,
            source_time_ms=self.source_time_ms,
        )


@dataclass(slots=True)
class _PineOrderBlockState:
    top: float
    bottom: float
    bar_local_index: int
    break_local_index: int
    source_time_ms: int
    break_time_ms: int
    bias: int
    has_fvg: bool
    used: bool = False

    def snapshot(self) -> PineSmcOrderBlockTrace:
        return PineSmcOrderBlockTrace(
            top=self.top,
            bottom=self.bottom,
            bar_local_index=self.bar_local_index,
            break_local_index=self.break_local_index,
            source_time_ms=self.source_time_ms,
            break_time_ms=self.break_time_ms,
            bias=self.bias,
            has_fvg=self.has_fvg,
            used=self.used,
        )


@dataclass(slots=True)
class _PineSmcState:
    local_index: int = -1
    atr200: float = 0.0
    tr_sum: float = 0.0
    true_range: float = 0.0
    parsed_high: float | None = None
    parsed_low: float | None = None
    swing_high: _PivotPointState = field(default_factory=_PivotPointState)
    swing_low: _PivotPointState = field(default_factory=_PivotPointState)
    internal_high: _PivotPointState = field(default_factory=_PivotPointState)
    internal_low: _PivotPointState = field(default_factory=_PivotPointState)
    swing_leg: int = 0
    internal_leg: int = 0
    swing_trend: int = 0
    internal_trend: int = 0
    range_top: float = 0.0
    range_top_valid: bool = False
    range_bottom: float = 0.0
    range_bottom_valid: bool = False
    active_order_blocks: list[_PineOrderBlockState] = field(default_factory=list)

    def reset(self) -> None:
        self.local_index = -1
        self.atr200 = 0.0
        self.tr_sum = 0.0
        self.true_range = 0.0
        self.parsed_high = None
        self.parsed_low = None
        self.swing_high = _PivotPointState()
        self.swing_low = _PivotPointState()
        self.internal_high = _PivotPointState()
        self.internal_low = _PivotPointState()
        self.swing_leg = 0
        self.internal_leg = 0
        self.swing_trend = 0
        self.internal_trend = 0
        self.range_top = 0.0
        self.range_top_valid = False
        self.range_bottom = 0.0
        self.range_bottom_valid = False
        self.active_order_blocks.clear()


class PineSmcStructureEngine:
    """Replay source-derived Pine SMC structure state for one timeframe.

    Each instance represents one ``request.security`` source timeframe. Create
    separate instances for 1m, 5m and 15m; the replay API computes the reset index
    from the loaded history length of that timeframe independently.
    """

    def __init__(self, config: PineSmcStructureConfig) -> None:
        self.config = config

    def replay(self, candles: Sequence[Kline] | Iterable[Kline]) -> PineSmcStructureReplayResult:
        """Replay a complete, contiguous loaded-history prefix for this timeframe."""

        rows = tuple(candles)
        self._validate_candles(rows)
        last_bar_index = len(rows) - 1
        reset_start_index = max(0, last_bar_index - self.config.warmup_bars + 1)

        state = _PineSmcState()
        # Built-in TA calls are evaluated on every source bar, before the SMC
        # warmup conditional. Stream over the complete loaded prefix and retain
        # only active-window traces; this keeps memory bounded by warmupBars.
        builtin_ta = PineBuiltinTAEngine()
        # Pine event-extreme scans may reach from the most recent internal pivot
        # to the current bar, which can be much wider than either pivot length.
        # The SMC warmup is capped by the Pine input at 2,500 bars, so a list of
        # in-window Klines is both faithful and strictly memory-bounded.
        history: list[Kline] = []
        parsed_history: list[ParsedCandleExtremes] = []
        trace: list[PineSmcBarTrace] = []

        for source_bar_index, candle in enumerate(rows):
            ta_values = builtin_ta.update(candle)
            if source_bar_index == reset_start_index:
                state.reset()
                history.clear()
                parsed_history.clear()
            if source_bar_index < reset_start_index:
                continue

            # atrRatioNow is evaluated before the current bar's custom ATR(200)
            # update in Pine. On the reset bar its value is therefore 0.0 and
            # the source's ternary fallback makes the ratio exactly 1.0.
            indicators = self._build_indicator_trace(ta_values, state.atr200)
            history.append(candle)
            previous_close = (
                float(rows[source_bar_index - 1].close) if state.local_index >= 0 else None
            )
            events, ob_lifecycle = self._process_bar(
                state,
                history,
                parsed_history,
                candle,
                previous_close=previous_close,
            )
            ob_eligibility = self._evaluate_ob_eligibility(state, indicators)
            trigger_sweep = self._evaluate_trigger_sweep(
                history=history,
                candle=candle,
                structure_events=events,
                eligibility=ob_eligibility,
                local_index=state.local_index,
            )
            # Pine evaluates priorLowestSweep/priorHighestSweep from the full
            # loaded prefix (`low[1]` / `high[1]`), independently of the SMC
            # warmup reset and independently of Stage-6's nested sweep gate.
            prior_slice = rows[max(0, source_bar_index - self.config.sweep_lookback):source_bar_index]
            prior_lowest = (
                min(float(row.low) for row in prior_slice) if prior_slice else None
            )
            prior_highest = (
                max(float(row.high) for row in prior_slice) if prior_slice else None
            )
            ob_scoring = self._evaluate_ob_scoring(
                state=state,
                history=history,
                candle=candle,
                indicators=indicators,
                trigger_sweep=trigger_sweep,
                prior_lowest_sweep=prior_lowest,
                prior_highest_sweep=prior_highest,
            )
            level_evaluation = self._evaluate_signal_levels(
                state=state,
                candle=candle,
                indicators=indicators,
                trigger_sweep=trigger_sweep,
                ob_scoring=ob_scoring,
            )
            trace.append(
                self._build_trace(
                    state,
                    candle,
                    source_bar_index=source_bar_index,
                    reset_start_index=reset_start_index,
                    structure_events=events,
                    ob_lifecycle=ob_lifecycle,
                    ob_eligibility=ob_eligibility,
                    trigger_sweep=trigger_sweep,
                    ob_scoring=ob_scoring,
                    level_evaluation=level_evaluation,
                    indicators=indicators,
                )
            )

        return PineSmcStructureReplayResult(
            symbol=self.config.symbol,
            timeframe=self.config.timeframe,
            warmup_bars=self.config.warmup_bars,
            swing_len=self.config.swing_len,
            internal_len=self.config.internal_len,
            confluence_filter=self.config.confluence_filter,
            fvg_min_atr=self.config.fvg_min_atr,
            mitigate_close=self.config.mitigate_close,
            use_volatility_regime=self.config.use_volatility_regime,
            low_vol_ratio=self.config.low_vol_ratio,
            high_vol_ratio=self.config.high_vol_ratio,
            extreme_vol_ratio=self.config.extreme_vol_ratio,
            choppy_adx_max=self.config.choppy_adx_max,
            max_age_m15=self.config.max_age_m15,
            max_age_m5=self.config.max_age_m5,
            fresh_only=self.config.fresh_only,
            use_trend_filter=self.config.use_trend_filter,
            use_pd_filter=self.config.use_pd_filter,
            require_fvg=self.config.require_fvg,
            trigger_mode=self.config.trigger_mode,
            struct_allow_bos=self.config.struct_allow_bos,
            min_wick_pct=self.config.min_wick_pct,
            require_sweep=self.config.require_sweep,
            sweep_lookback=self.config.sweep_lookback,
            sweep_window=self.config.sweep_window,
            tick_size=self.config.tick_size,
            entry_depth_near=self.config.entry_depth_near,
            entry_depth_deep=self.config.entry_depth_deep,
            sl_buffer_atr=self.config.sl_buffer_atr,
            sl_spread_mult=self.config.sl_spread_mult,
            max_sl_atr=self.config.max_sl_atr,
            max_spread_sl_pct=self.config.max_spread_sl_pct,
            high_vol_sl_mult=self.config.high_vol_sl_mult,
            tp_mode=self.config.tp_mode,
            rr=self.config.rr,
            min_rr=self.config.min_rr,
            spread_estimate_ticks=self.config.spread_estimate_ticks,
            min_stop_ticks=self.config.min_stop_ticks,
            consume_ob_on_signal=self.config.consume_ob_on_signal,
            source_bar_count=len(rows),
            last_bar_index=last_bar_index,
            reset_start_index=reset_start_index,
            trace=tuple(trace),
        )

    def _max_age_for_timeframe(self) -> int:
        """Mirror the source request.security arguments for maxAge.

        Pine passes ``maxAgeM5`` into both the 1-minute and 5-minute
        ``f_smc`` calls; only the 15-minute context receives ``maxAgeM15``.
        """

        return self.config.max_age_m15 if self.config.timeframe == "15m" else self.config.max_age_m5

    def _evaluate_ob_eligibility(
        self,
        state: _PineSmcState,
        indicators: PineSmcIndicatorTrace,
    ) -> PineSmcObEligibilityTrace:
        """Apply only the ordered Pine ``FindSignal`` eligibility gates.

        The active OB list remains oldest-to-newest, like Pine's parallel
        arrays. This scan deliberately traverses it in reverse and returns all
        eligible records in that order. It never changes ``used`` or reorders
        the backing collection; trigger selection later consumes this ordered
        candidate view.
        """

        max_age = self._max_age_for_timeframe()
        evaluations: list[PineSmcObCandidateEvaluation] = []
        active = state.active_order_blocks

        for active_index in range(len(active) - 1, -1, -1):
            ob = active[active_index]
            snapshot = ob.snapshot()
            rejection_reasons: list[str] = []

            # Keep the same condition order as Pine FindSignal() lines 555–570.
            if self.config.fresh_only and ob.used:
                rejection_reasons.append("fresh_only_used")

            if (
                state.local_index <= ob.break_local_index
                or state.local_index - ob.break_local_index > max_age
            ):
                rejection_reasons.append("age_window")

            if self.config.use_trend_filter and (
                (ob.bias == 1 and state.swing_trend != 1)
                or (ob.bias == -1 and state.swing_trend != -1)
            ):
                rejection_reasons.append("swing_trend_mismatch")

            if (
                self.config.use_pd_filter
                and state.range_top_valid
                and state.range_bottom_valid
                and state.range_top > state.range_bottom
            ):
                equilibrium = (state.range_top + state.range_bottom) / 2.0
                ob_midpoint = (ob.top + ob.bottom) / 2.0
                if (
                    (ob.bias == 1 and ob_midpoint > equilibrium)
                    or (ob.bias == -1 and ob_midpoint < equilibrium)
                ):
                    rejection_reasons.append("premium_discount_mismatch")

            if self.config.require_fvg and not ob.has_fvg:
                rejection_reasons.append("fvg_required_missing")

            if indicators.volatility_extreme:
                rejection_reasons.append("volatility_extreme")
            if indicators.volatility_choppy:
                rejection_reasons.append("volatility_choppy")

            evaluations.append(
                PineSmcObCandidateEvaluation(
                    active_array_index=active_index,
                    order_block=snapshot,
                    eligible=not rejection_reasons,
                    rejection_reasons=tuple(rejection_reasons),
                )
            )

        ordered = tuple(evaluations)
        return PineSmcObEligibilityTrace(
            max_age=max_age,
            scanned_newest_to_oldest=ordered,
            eligible_candidates=tuple(row for row in ordered if row.eligible),
        )

    def _evaluate_ob_scoring(
        self,
        *,
        state: _PineSmcState,
        history: list[Kline],
        candle: Kline,
        indicators: PineSmcIndicatorTrace,
        trigger_sweep: PineSmcTriggerSweepTrace,
        prior_lowest_sweep: float | None,
        prior_highest_sweep: float | None,
    ) -> PineSmcObScoringTrace:
        """Mirror Pine ``f_scoreOB`` for each active OB without changing order.

        Pine calls the score function once for the selected candidate and then
        for every active OB while building its diagnostic CSV. We score the
        active list oldest-to-newest (the original array order), then expose the
        Stage-6 chosen candidate's matching score by original array index.
        """

        max_age = self._max_age_for_timeframe()
        chosen_index = trigger_sweep.chosen_active_array_index
        tick_size = self.config.tick_size
        if tick_size is None:
            return PineSmcObScoringTrace(
                available=False,
                unavailable_reason=(
                    "exact_tick_size_required_for_syminfo_mintick; "
                    "supply Binance USD-M PRICE_FILTER.tickSize for this symbol"
                ),
                tick_size=None,
                max_age=max_age,
                near_depth=self.config.entry_depth_near,
                deep_depth=self.config.entry_depth_deep,
                prior_lowest_sweep=prior_lowest_sweep,
                prior_highest_sweep=prior_highest_sweep,
                chosen_active_array_index=chosen_index,
            )

        if len(history) != state.local_index + 1 or history[-1] is not candle:
            raise PineSmcReplayError("OB scoring history is not aligned to the current source candle")

        active_scores: list[PineSmcObScoreTrace] = []
        for active_index, ob in enumerate(state.active_order_blocks):
            active_scores.append(
                self._score_order_block(
                    active_array_index=active_index,
                    ob=ob,
                    history=history,
                    current=candle,
                    local_index=state.local_index,
                    max_age=max_age,
                    swing_trend=state.swing_trend,
                    internal_trend=state.internal_trend,
                    atr_slow=state.atr200,
                    atr_fast=indicators.atr_fast_now,
                    rsi_now=indicators.rsi_now,
                    volume_average=indicators.volume_avg_now,
                    prior_lowest_sweep=prior_lowest_sweep,
                    prior_highest_sweep=prior_highest_sweep,
                    tick_size=tick_size,
                )
            )

        chosen_score = None
        if chosen_index is not None:
            if not 0 <= chosen_index < len(active_scores):
                raise PineSmcReplayError("Stage-6 chosen OB index is outside the active array")
            chosen_score = active_scores[chosen_index]

        return PineSmcObScoringTrace(
            available=True,
            unavailable_reason=None,
            tick_size=tick_size,
            max_age=max_age,
            near_depth=self.config.entry_depth_near,
            deep_depth=self.config.entry_depth_deep,
            prior_lowest_sweep=prior_lowest_sweep,
            prior_highest_sweep=prior_highest_sweep,
            active_order_block_scores=tuple(active_scores),
            chosen_active_array_index=chosen_index,
            chosen_score=chosen_score,
        )

    def _evaluate_signal_levels(
        self,
        *,
        state: _PineSmcState,
        candle: Kline,
        indicators: PineSmcIndicatorTrace,
        trigger_sweep: PineSmcTriggerSweepTrace,
        ob_scoring: PineSmcObScoringTrace,
    ) -> PineSmcLevelEvaluationTrace:
        """Mirror Pine's unshifted local entry/SL/TP proxy and levelsOK gate.

        This runs only for the first Stage-6 chosen candidate. If its levels fail,
        Pine does not retry a later OB. `consumeOBOnSignal` mutates only the
        indicator's OB-used proxy after every level gate passes; it is not an
        exchange fill or position-management state.
        """

        chosen_index = trigger_sweep.chosen_active_array_index
        trigger_code = trigger_sweep.chosen_trigger_code
        if chosen_index is None:
            return PineSmcLevelEvaluationTrace(
                attempted=False,
                available=True,
                accepted=False,
                unavailable_reason=None,
            )

        if not 0 <= chosen_index < len(state.active_order_blocks):
            raise PineSmcReplayError("Stage-6 chosen OB index is outside the active array")
        if trigger_code not in (1, 2):
            raise PineSmcReplayError("Stage-6 chosen candidate has an invalid trigger code")
        if not ob_scoring.available or ob_scoring.chosen_score is None:
            return PineSmcLevelEvaluationTrace(
                attempted=True,
                available=False,
                accepted=False,
                unavailable_reason=(
                    ob_scoring.unavailable_reason
                    or "chosen_ob_score_unavailable; exact tick size is required"
                ),
                chosen_active_array_index=chosen_index,
                chosen_trigger_code=trigger_code,
            )

        ob = state.active_order_blocks[chosen_index]
        selected_ob_snapshot = ob.snapshot()
        score = ob_scoring.chosen_score
        if (
            ob_scoring.chosen_active_array_index != chosen_index
            or score.active_array_index != chosen_index
            or score.order_block.top != selected_ob_snapshot.top
            or score.order_block.bottom != selected_ob_snapshot.bottom
            or score.order_block.bias != selected_ob_snapshot.bias
            or score.order_block.source_time_ms != selected_ob_snapshot.source_time_ms
        ):
            raise PineSmcReplayError(
                "Stage-7 chosen score does not match the Stage-6 selected OB snapshot"
            )
        tick_size = self.config.tick_size
        if tick_size is None:
            return PineSmcLevelEvaluationTrace(
                attempted=True,
                available=False,
                accepted=False,
                unavailable_reason="exact_tick_size_required_for_syminfo_mintick",
                chosen_active_array_index=chosen_index,
                chosen_trigger_code=trigger_code,
            )
        atr_fast = indicators.atr_fast_now
        if atr_fast is None or not math.isfinite(atr_fast):
            return PineSmcLevelEvaluationTrace(
                attempted=True,
                available=False,
                accepted=False,
                unavailable_reason="pine_atr_14_unavailable_for_sl_buffer",
                chosen_active_array_index=chosen_index,
                chosen_trigger_code=trigger_code,
            )

        direction = ob.bias
        entry = float(candle.close)  # Pine indicator proxy; not Binance fill/Ask/Bid.
        spread_price = self.config.spread_estimate_ticks * tick_size
        atr_ratio = indicators.atr_ratio_now
        high_volatility = (
            self.config.use_volatility_regime
            and atr_ratio is not None
            and atr_ratio >= self.config.high_vol_ratio
        )
        regime_buffer_multiplier = self.config.high_vol_sl_mult if high_volatility else 1.0
        buffer = max(
            spread_price * self.config.sl_spread_mult,
            atr_fast * self.config.sl_buffer_atr,
        ) * regime_buffer_multiplier
        stop = ob.bottom - buffer if direction == 1 else ob.top + buffer
        stop_distance = entry - stop if direction == 1 else stop - entry
        minimum_stop_distance = self.config.min_stop_ticks * tick_size

        if stop_distance <= 0.0:
            return PineSmcLevelEvaluationTrace(
                attempted=True,
                available=True,
                accepted=False,
                unavailable_reason=None,
                rejection_reasons=("stop_distance_non_positive",),
                chosen_active_array_index=chosen_index,
                chosen_trigger_code=trigger_code,
                entry_proxy=entry,
                spread_price=spread_price,
                stop_buffer=buffer,
                stop_loss_proxy=stop,
                stop_distance=stop_distance,
                minimum_stop_distance=minimum_stop_distance,
            )

        if stop_distance < minimum_stop_distance:
            stop_distance = minimum_stop_distance
            stop = entry - stop_distance if direction == 1 else entry + stop_distance

        rejection_reasons: list[str] = []
        # Pine's `levelsOK` begins with these two strict checks, after min-stop adjustment.
        if state.atr200 > 0.0 and stop_distance > self.config.max_sl_atr * state.atr200:
            rejection_reasons.append("max_sl_atr_exceeded")
        if spread_price > stop_distance * self.config.max_spread_sl_pct / 100.0:
            rejection_reasons.append("spread_to_stop_pct_exceeded")

        structural_target: float | None = None
        if direction == 1 and state.range_top_valid and state.range_top > entry:
            structural_target = state.range_top
        elif direction == -1 and state.range_bottom_valid and state.range_bottom < entry:
            structural_target = state.range_bottom

        opposing_ob_target: float | None = None
        if self.config.tp_mode == "Hybrid OB/Liquidity":
            # Pine scans the full active arrays oldest-to-newest and retains the
            # nearest opposing OB boundary beyond entry; used flags are irrelevant.
            for active_ob in state.active_order_blocks:
                if direction == 1 and active_ob.bias == -1 and active_ob.bottom > entry:
                    opposing_ob_target = (
                        active_ob.bottom
                        if opposing_ob_target is None
                        else min(opposing_ob_target, active_ob.bottom)
                    )
                elif direction == -1 and active_ob.bias == 1 and active_ob.top < entry:
                    opposing_ob_target = (
                        active_ob.top
                        if opposing_ob_target is None
                        else max(opposing_ob_target, active_ob.top)
                    )

        target: float | None
        target_source: str
        if self.config.tp_mode == "Structure":
            target = structural_target
            target_source = "structural_liquidity"
        elif self.config.tp_mode == "Hybrid OB/Liquidity":
            if opposing_ob_target is not None:
                target = opposing_ob_target
                target_source = "opposing_ob"
            else:
                target = structural_target
                target_source = "structural_liquidity"
            hybrid_reward = (
                None
                if target is None
                else (target - entry if direction == 1 else entry - target)
            )
            if (
                target is None
                or hybrid_reward is None
                or hybrid_reward <= 0.0
                or hybrid_reward / stop_distance < self.config.min_rr
            ):
                target = (
                    entry + stop_distance * self.config.rr
                    if direction == 1
                    else entry - stop_distance * self.config.rr
                )
                target_source = "fixed_rr_fallback"
                # Never allow RR fallback to pass through a known opposing OB.
                obstacle = opposing_ob_target is not None and (
                    opposing_ob_target < target
                    if direction == 1
                    else opposing_ob_target > target
                )
                if obstacle:
                    rejection_reasons.append("opposing_ob_blocks_rr_fallback")
        else:
            target = (
                entry + stop_distance * self.config.rr
                if direction == 1
                else entry - stop_distance * self.config.rr
            )
            target_source = "fixed_rr"

        final_reward = (
            None
            if target is None
            else (target - entry if direction == 1 else entry - target)
        )
        if target is None:
            rejection_reasons.append("take_profit_unavailable")
        elif final_reward is None or final_reward <= 0.0:
            rejection_reasons.append("take_profit_not_directional")
        risk_reward = (
            None
            if final_reward is None or stop_distance <= 0.0
            else final_reward / stop_distance
        )
        if (
            self.config.tp_mode == "Structure"
            and risk_reward is not None
            and risk_reward < self.config.min_rr
        ):
            rejection_reasons.append("structure_target_below_min_rr")

        accepted = not rejection_reasons
        consumed = False
        signal: PineSmcSignalProxy | None = None
        if accepted:
            if target is None or final_reward is None or risk_reward is None:
                raise PineSmcReplayError("accepted Pine level evaluation is missing target values")
            # Pine sets obUsedFlags[chosen] only after `levelsOK` becomes true.
            if self.config.consume_ob_on_signal:
                ob.used = True
                consumed = True
            signal = PineSmcSignalProxy(
                source_time_ms=candle.open_time_ms,
                direction=direction,
                trigger_code=trigger_code,
                active_array_index=chosen_index,
                order_block=selected_ob_snapshot,
                entry_proxy=entry,
                stop_loss_proxy=stop,
                take_profit_proxy=target,
                spread_price=spread_price,
                stop_buffer=buffer,
                stop_distance=stop_distance,
                minimum_stop_distance=minimum_stop_distance,
                structural_target=structural_target,
                opposing_ob_target=opposing_ob_target,
                target_source=target_source,
                final_reward=final_reward,
                risk_reward=risk_reward,
                setup_score=score.setup_score,
                quality_score=score.ob_quality_score,
                timing_score=score.timing_score,
                entry_band_low=score.entry_band_low,
                entry_band_high=score.entry_band_high,
                ob_consumed_by_signal_proxy=consumed,
            )

        return PineSmcLevelEvaluationTrace(
            attempted=True,
            available=True,
            accepted=accepted,
            unavailable_reason=None,
            rejection_reasons=tuple(rejection_reasons),
            chosen_active_array_index=chosen_index,
            chosen_trigger_code=trigger_code,
            entry_proxy=entry,
            spread_price=spread_price,
            stop_buffer=buffer,
            stop_loss_proxy=stop,
            stop_distance=stop_distance,
            minimum_stop_distance=minimum_stop_distance,
            structural_target=structural_target,
            opposing_ob_target=opposing_ob_target,
            target_source=target_source,
            take_profit_proxy=target,
            final_reward=final_reward,
            risk_reward=risk_reward,
            ob_consumed_by_signal_proxy=consumed,
            signal=signal,
        )

    def _score_order_block(
        self,
        *,
        active_array_index: int,
        ob: _PineOrderBlockState,
        history: list[Kline],
        current: Kline,
        local_index: int,
        max_age: int,
        swing_trend: int,
        internal_trend: int,
        atr_slow: float,
        atr_fast: float | None,
        rsi_now: float | None,
        volume_average: float | None,
        prior_lowest_sweep: float | None,
        prior_highest_sweep: float | None,
        tick_size: float,
    ) -> PineSmcObScoreTrace:
        """Exact source-derived 16-field Pine ``f_scoreOB`` calculation."""

        source_offset = local_index - ob.bar_local_index
        break_offset = local_index - ob.break_local_index
        if not 0 <= source_offset < len(history) or not 0 <= break_offset < len(history):
            raise PineSmcReplayError("OB source/break offsets are outside retained Pine history")
        source = history[ob.bar_local_index]
        break_candle = history[ob.break_local_index]

        zone_range = max(ob.top - ob.bottom, tick_size)
        near_depth = self.config.entry_depth_near
        deep_depth = self.config.entry_depth_deep
        effective_deep = (
            min(0.95, near_depth + 0.10) if deep_depth <= near_depth else deep_depth
        )
        entry_low = (
            ob.top - zone_range * effective_deep
            if ob.bias == 1
            else ob.bottom + zone_range * near_depth
        )
        entry_high = (
            ob.top - zone_range * near_depth
            if ob.bias == 1
            else ob.bottom + zone_range * effective_deep
        )

        atr_ratio = (
            atr_fast / atr_slow
            if atr_slow > 0.0 and atr_fast is not None
            else 1.0
        )
        volatility_score = self._clamp_score(
            100.0 - abs(atr_ratio - 1.0) * 55.0
        )

        displacement_atr = (
            ((float(break_candle.close) - ob.top) / atr_slow)
            if ob.bias == 1 and atr_slow > 0.0
            else ((ob.bottom - float(break_candle.close)) / atr_slow)
            if ob.bias == -1 and atr_slow > 0.0
            else 0.0
        )
        displacement_score = self._clamp_score(displacement_atr / 2.0 * 100.0)

        source_open = float(source.open)
        source_high = float(source.high)
        source_low = float(source.low)
        source_close = float(source.close)
        source_range = max(source_high - source_low, tick_size)
        body_pct = abs(source_close - source_open) / source_range * 100.0
        rejection_wick_pct = (
            (min(source_open, source_close) - source_low) / source_range * 100.0
            if ob.bias == 1
            else (source_high - max(source_open, source_close)) / source_range * 100.0
        )
        expected_source_color = (
            source_close < source_open if ob.bias == 1 else source_close > source_open
        )
        source_candle_score = self._clamp_score(
            (body_pct * 0.70 + rejection_wick_pct * 0.30)
            * (1.0 if expected_source_color else 0.65)
        )

        rsi_score = (
            50.0
            if rsi_now is None
            else self._clamp_score(
                100.0 - abs(rsi_now - (58.0 if ob.bias == 1 else 42.0)) * 2.2
            )
        )
        swing_part = 100.0 if swing_trend == ob.bias else 45.0 if swing_trend == 0 else 0.0
        internal_part = (
            100.0 if internal_trend == ob.bias else 45.0 if internal_trend == 0 else 0.0
        )
        trend_score = swing_part * 0.55 + internal_part * 0.45
        fvg_score = 100.0 if ob.has_fvg else 40.0

        volume_now = float(current.volume)
        volume_score = (
            50.0
            if volume_average is None or volume_average <= 0.0
            else self._clamp_score(
                50.0 + (volume_now / volume_average - 1.0) * 40.0
            )
        )
        age = local_index - ob.break_local_index
        freshness_score = (
            self._clamp_score(100.0 - 70.0 * age / max_age, lower=20.0, upper=100.0)
            if max_age > 0
            else 20.0
        )

        current_open = float(current.open)
        current_high = float(current.high)
        current_low = float(current.low)
        current_close = float(current.close)
        swept = (
            prior_lowest_sweep is not None
            and current_low < prior_lowest_sweep
            and current_close > prior_lowest_sweep
            if ob.bias == 1
            else prior_highest_sweep is not None
            and current_high > prior_highest_sweep
            and current_close < prior_highest_sweep
        )
        sweep_score = 100.0 if swept else 45.0

        current_range = max(current_high - current_low, tick_size)
        close_position = self._clamp_unit((current_close - current_low) / current_range)
        current_candle_score = (
            50.0 * close_position + (50.0 if current_close > current_open else 0.0)
            if ob.bias == 1
            else 50.0 * (1.0 - close_position)
            + (50.0 if current_close < current_open else 0.0)
        )
        distance_to_band = (
            current_close - entry_high
            if current_close > entry_high
            else entry_low - current_close
            if current_close < entry_low
            else 0.0
        )
        proximity_score = (
            self._clamp_score(100.0 - distance_to_band / atr_fast * 100.0)
            if atr_fast is not None and atr_fast > 0.0
            else (100.0 if distance_to_band == 0.0 else 0.0)
        )

        quality_score = (
            displacement_score * 16.0
            + source_candle_score * 12.0
            + volatility_score * 10.0
            + rsi_score * 12.0
            + trend_score * 12.0
            + fvg_score * 8.0
            + volume_score * 6.0
            + freshness_score * 6.0
            + sweep_score * 8.0
        ) / 90.0
        timing_score = current_candle_score * 0.45 + proximity_score * 0.55
        setup_score = self._clamp_score(quality_score * 0.80 + timing_score * 0.20)

        return PineSmcObScoreTrace(
            active_array_index=active_array_index,
            order_block=ob.snapshot(),
            age=age,
            entry_band_low=entry_low,
            entry_band_high=entry_high,
            ob_quality_score=quality_score,
            timing_score=timing_score,
            setup_score=setup_score,
            volatility_score=volatility_score,
            displacement_score=displacement_score,
            source_candle_score=source_candle_score,
            rsi_score=rsi_score,
            trend_score=trend_score,
            fvg_score=fvg_score,
            volume_score=volume_score,
            freshness_score=freshness_score,
            current_candle_score=current_candle_score,
            proximity_score=proximity_score,
            sweep_score=sweep_score,
            swept_current_candle=bool(swept),
        )

    @staticmethod
    def _clamp_score(value: float, *, lower: float = 0.0, upper: float = 100.0) -> float:
        return max(lower, min(upper, value))

    @staticmethod
    def _clamp_unit(value: float) -> float:
        return max(0.0, min(1.0, value))

    def _evaluate_trigger_sweep(
        self,
        *,
        history: list[Kline],
        candle: Kline,
        structure_events: PineSmcStructureEvents,
        eligibility: PineSmcObEligibilityTrace,
        local_index: int,
    ) -> PineSmcTriggerSweepTrace:
        """Mirror Pine FindSignal trigger/sweep loops over Stage-5 candidates.

        Stage 5 already provides the eligible OBs in newest-to-oldest order.
        The scan stops on the first candidate with a non-zero prioritized
        trigger and a passing sweep gate, matching Pine's ``while ... chosen
        == -1`` behavior. No OB state is mutated here.
        """

        if local_index < 0 or local_index >= len(history):
            raise PineSmcReplayError("trigger/sweep evaluation exceeds retained source history")
        if history[local_index] is not candle:
            # Kline is immutable, but identity is intentionally required here:
            # this protects the local-history offsets used by Pine's [n] series.
            raise PineSmcReplayError("current candle does not match retained local history")

        open_price = float(candle.open)
        high = float(candle.high)
        low = float(candle.low)
        close = float(candle.close)
        candle_range = high - low
        evaluations: list[PineSmcObTriggerEvaluation] = []
        chosen_index: int | None = None
        chosen_trigger = 0

        for candidate in eligibility.eligible_candidates:
            ob = candidate.order_block
            rejection = False
            structure = False
            ob_midpoint = (ob.top + ob.bottom) / 2.0

            # Pine lines 576–580: exact direction, touch, midpoint and wick math.
            if self.config.trigger_mode != "Structure" and candle_range > 0.0:
                if ob.bias == 1:
                    rejection = (
                        low <= ob.top
                        and close > open_price
                        and close > ob_midpoint
                        and (min(open_price, close) - low) / candle_range * 100.0
                        >= self.config.min_wick_pct
                    )
                else:
                    rejection = (
                        high >= ob.bottom
                        and close < open_price
                        and close < ob_midpoint
                        and (high - max(open_price, close)) / candle_range * 100.0
                        >= self.config.min_wick_pct
                    )

            # Pine lines 581–588: the event must post-date the candidate OB break.
            if (
                self.config.trigger_mode != "Rejection"
                and structure_events.extreme_local_index >= 0
                and structure_events.extreme_local_index > ob.break_local_index
            ):
                if ob.bias == 1:
                    bull_structure_event = structure_events.bull_choch or (
                        self.config.struct_allow_bos and structure_events.bull_bos
                    )
                    structure = bull_structure_event and structure_events.extreme <= ob.top
                else:
                    bear_structure_event = structure_events.bear_choch or (
                        self.config.struct_allow_bos and structure_events.bear_bos
                    )
                    structure = bear_structure_event and structure_events.extreme >= ob.bottom

            # Pine line 588: rejection takes precedence when both are true.
            trigger_code = 1 if rejection else 2 if structure else 0

            # Pine lines 590–607 calculate the sweep gate per candidate, even
            # when its trigger is zero. The exact historical offsets are kept.
            sweep_passed = (
                True
                if not self.config.require_sweep
                else self._has_directional_sweep(
                    history=history,
                    local_index=local_index,
                    bias=ob.bias,
                )
            )
            accepted = trigger_code != 0 and sweep_passed
            evaluation = PineSmcObTriggerEvaluation(
                active_array_index=candidate.active_array_index,
                order_block=ob,
                rejection_trigger=rejection,
                structure_trigger=structure,
                trigger_code=trigger_code,
                sweep_passed=sweep_passed,
                accepted=accepted,
            )
            evaluations.append(evaluation)

            if accepted:
                chosen_index = candidate.active_array_index
                chosen_trigger = trigger_code
                break

        return PineSmcTriggerSweepTrace(
            trigger_mode=self.config.trigger_mode,
            require_sweep=self.config.require_sweep,
            scanned_candidates=tuple(evaluations),
            chosen_active_array_index=chosen_index,
            chosen_trigger_code=chosen_trigger,
        )

    def _has_directional_sweep(
        self,
        *,
        history: list[Kline],
        local_index: int,
        bias: int,
    ) -> bool:
        """Mirror Pine's nested sweepWindow/sweepLookback historical loops."""

        if local_index < 0 or local_index >= len(history):
            raise PineSmcReplayError("sweep evaluation exceeds retained source history")
        sweep_ok = False
        for sweep_offset in range(self.config.sweep_window):
            if local_index - sweep_offset > self.config.sweep_lookback:
                sweep_index = local_index - sweep_offset
                if bias == 1:
                    range_low = float(history[sweep_index - 1].low)
                    for lookback_offset in range(1, self.config.sweep_lookback + 1):
                        range_low = min(
                            range_low,
                            float(history[sweep_index - lookback_offset].low),
                        )
                    if (
                        float(history[sweep_index].low) < range_low
                        and float(history[sweep_index].close) > range_low
                    ):
                        sweep_ok = True
                else:
                    range_high = float(history[sweep_index - 1].high)
                    for lookback_offset in range(1, self.config.sweep_lookback + 1):
                        range_high = max(
                            range_high,
                            float(history[sweep_index - lookback_offset].high),
                        )
                    if (
                        float(history[sweep_index].high) > range_high
                        and float(history[sweep_index].close) < range_high
                    ):
                        sweep_ok = True
        return sweep_ok

    def _build_indicator_trace(
        self,
        values: PineBuiltinTAValues,
        atr200_before_current_update: float,
    ) -> PineSmcIndicatorTrace:
        if atr200_before_current_update > 0.0:
            atr_ratio = (
                None
                if values.atr_fast_now is None
                else values.atr_fast_now / atr200_before_current_update
            )
        else:
            # Exact source fallback: atr200 > 0 ? atrFastNow / atr200 : 1.0.
            atr_ratio = 1.0

        extreme = bool(
            self.config.use_volatility_regime
            and atr_ratio is not None
            and atr_ratio >= self.config.extreme_vol_ratio
        )
        choppy = bool(
            self.config.use_volatility_regime
            and atr_ratio is not None
            and values.adx_now is not None
            and atr_ratio > self.config.low_vol_ratio
            and atr_ratio < self.config.high_vol_ratio
            and values.adx_now < self.config.choppy_adx_max
        )
        return PineSmcIndicatorTrace(
            atr_fast_now=values.atr_fast_now,
            rsi_now=values.rsi_now,
            volume_avg_now=values.volume_avg_now,
            di_plus_now=values.di_plus_now,
            di_minus_now=values.di_minus_now,
            adx_now=values.adx_now,
            atr200_ratio_base=atr200_before_current_update,
            atr_ratio_now=atr_ratio,
            volatility_extreme=extreme,
            volatility_choppy=choppy,
        )

    def _validate_candles(self, candles: tuple[Kline, ...]) -> None:
        if not candles:
            raise PineSmcReplayError("at least one loaded-history candle is required")
        expected_interval_ms = INTERVAL_MILLISECONDS[self.config.timeframe]
        previous_open_time: int | None = None
        for index, candle in enumerate(candles):
            if not isinstance(candle, Kline):
                raise PineSmcReplayError(f"candle at index {index} is not a Kline")
            if candle.exchange != "BINANCE_UM":
                raise PineSmcReplayError("all candles must originate from Binance USD-M Futures")
            if candle.symbol != self.config.symbol:
                raise PineSmcReplayError("candle symbol does not match replay configuration")
            if candle.interval != self.config.timeframe:
                raise PineSmcReplayError("candle timeframe does not match replay configuration")
            if (
                isinstance(candle.open_time_ms, bool)
                or not isinstance(candle.open_time_ms, int)
                or candle.open_time_ms < 0
                or candle.open_time_ms % expected_interval_ms
            ):
                raise PineSmcReplayError(f"candle at index {index} has an invalid open timestamp")
            if candle.close_time_ms != candle.open_time_ms + expected_interval_ms - 1:
                raise PineSmcReplayError(f"candle at index {index} has an invalid close timestamp")
            expected_open_time = (
                None if previous_open_time is None else previous_open_time + expected_interval_ms
            )
            if expected_open_time is not None and candle.open_time_ms != expected_open_time:
                raise PineSmcReplayError("loaded-history candle series must be strictly contiguous")
            ohlc_values = (candle.open, candle.high, candle.low, candle.close)
            if not all(isinstance(value, Decimal) and value.is_finite() for value in ohlc_values):
                raise PineSmcReplayError(
                    f"candle at index {index} OHLC values must be finite Decimals"
                )
            if min(ohlc_values) <= 0:
                raise PineSmcReplayError(f"candle at index {index} has non-positive OHLC values")
            if candle.high < max(candle.open, candle.close, candle.low) or candle.low > min(
                candle.open, candle.close, candle.high
            ):
                raise PineSmcReplayError(f"candle at index {index} has inconsistent OHLC values")
            if (
                not isinstance(candle.volume, Decimal)
                or not candle.volume.is_finite()
                or candle.volume < 0
            ):
                raise PineSmcReplayError(f"candle at index {index} has invalid volume")
            try:
                numeric_values = tuple(float(value) for value in ohlc_values)
            except (OverflowError, TypeError, ValueError) as exc:
                raise PineSmcReplayError(
                    f"candle at index {index} cannot be converted to Pine float"
                ) from exc
            if not all(math.isfinite(value) for value in numeric_values):
                raise PineSmcReplayError(f"candle at index {index} exceeds finite Pine float range")
            previous_open_time = candle.open_time_ms

    def _process_bar(
        self,
        state: _PineSmcState,
        history: list[Kline],
        parsed_history: list[ParsedCandleExtremes],
        candle: Kline,
        *,
        previous_close: float | None,
    ) -> tuple[PineSmcStructureEvents, PineSmcObLifecycleEvents]:
        state.local_index += 1
        high = float(candle.high)
        low = float(candle.low)

        # Pine lines 358–366: first local TR is high-low, then use close[1].
        true_range = high - low
        if state.local_index > 0:
            if previous_close is None:
                raise PineSmcReplayError("previous close is required after local index zero")
            close_gap_high = abs(high - previous_close)
            close_gap_low = abs(low - previous_close)
            true_range = max(true_range, max(close_gap_high, close_gap_low))
        state.true_range = true_range

        if state.local_index < 200:
            state.tr_sum += true_range
            state.atr200 = state.tr_sum / (state.local_index + 1)
        else:
            state.atr200 = (state.atr200 * 199.0 + true_range) / 200.0

        parsed = parse_candle_extremes(high=high, low=low, atr200=state.atr200)
        state.parsed_high = parsed.parsed_high
        state.parsed_low = parsed.parsed_low
        parsed_history.append(parsed)

        # Pine updates established range boundaries before evaluating new pivots.
        if state.range_top_valid and high > state.range_top:
            state.range_top = high
        if state.range_bottom_valid and low < state.range_bottom:
            state.range_bottom = low

        self._update_pivot_leg(
            state=state,
            history=history,
            length=self.config.swing_len,
            is_swing=True,
        )
        self._update_pivot_leg(
            state=state,
            history=history,
            length=self.config.internal_len,
            is_swing=False,
        )

        return self._update_structure_events(
            state=state,
            history=history,
            parsed_history=parsed_history,
            candle=candle,
            previous_close=previous_close,
        )

    @staticmethod
    def _update_pivot_leg(
        *,
        state: _PineSmcState,
        history: list[Kline],
        length: int,
        is_swing: bool,
    ) -> None:
        if state.local_index < length:
            return
        if len(history) < length + 1:
            raise PineSmcReplayError(
                "pivot history is shorter than the Pine delayed candidate window"
            )

        candidate = history[-(length + 1)]
        recent = tuple(reversed(history[-length:]))  # Pine [0] first, then [1] ... [length-1].
        candidate_high = float(candidate.high)
        candidate_low = float(candidate.low)
        new_leg_high = True
        new_leg_low = True
        for recent_bar in recent:
            if float(recent_bar.high) >= candidate_high:
                new_leg_high = False
            if float(recent_bar.low) <= candidate_low:
                new_leg_low = False

        current_leg = state.swing_leg if is_swing else state.internal_leg
        new_leg = current_leg
        if new_leg_high:
            new_leg = 0
        elif new_leg_low:
            new_leg = 1
        change = new_leg - current_leg
        if is_swing:
            state.swing_leg = new_leg
        else:
            state.internal_leg = new_leg

        if change == 0:
            return

        pivot_local_index = state.local_index - length
        pivot_time_ms = candidate.open_time_ms
        if change == 1:
            if is_swing:
                state.swing_low.update(
                    candidate_low,
                    local_index=pivot_local_index,
                    source_time_ms=pivot_time_ms,
                )
                state.range_bottom = candidate_low
                state.range_bottom_valid = True
            else:
                state.internal_low.update(
                    candidate_low,
                    local_index=pivot_local_index,
                    source_time_ms=pivot_time_ms,
                )
        else:
            if is_swing:
                state.swing_high.update(
                    candidate_high,
                    local_index=pivot_local_index,
                    source_time_ms=pivot_time_ms,
                )
                state.range_top = candidate_high
                state.range_top_valid = True
            else:
                state.internal_high.update(
                    candidate_high,
                    local_index=pivot_local_index,
                    source_time_ms=pivot_time_ms,
                )

    def _update_structure_events(
        self,
        *,
        state: _PineSmcState,
        history: list[Kline],
        parsed_history: list[ParsedCandleExtremes],
        candle: Kline,
        previous_close: float | None,
    ) -> tuple[PineSmcStructureEvents, PineSmcObLifecycleEvents]:
        """Apply Pine structure, OB creation and mitigation in source order."""

        high = float(candle.high)
        low = float(candle.low)
        open_price = float(candle.open)
        close = float(candle.close)

        bullish_bar = True
        bearish_bar = True
        if self.config.confluence_filter:
            # Preserve the exact Pine/EA expression. In particular, the second
            # expression is min(close, open-low), not min(open, close)-low.
            a = high - max(close, open_price)
            b = min(close, open_price - low)
            bullish_bar = a > b
            bearish_bar = a < b

        bull_choch = False
        bear_choch = False
        bull_bos = False
        bear_bos = False
        event_extreme = 0.0
        event_extreme_local_index = -1
        event_extreme_source_time_ms: int | None = None
        created_obs: list[PineSmcOrderBlockTrace] = []
        evicted_obs: list[PineSmcOrderBlockTrace] = []

        if state.local_index >= 1:
            if previous_close is None:
                raise PineSmcReplayError("previous close is required for structure-break checks")

            # Pine DisplayStructure(true): internal bullish is evaluated first.
            extra_bull = (
                (not state.swing_high.valid or state.internal_high.current != state.swing_high.current)
                and bullish_bar
            )
            if (
                state.internal_high.valid
                and not state.internal_high.crossed
                and extra_bull
                and close > state.internal_high.current
                and previous_close <= state.internal_high.current
            ):
                was_bearish = state.internal_trend == -1
                state.internal_high.crossed = True
                state.internal_trend = 1
                if was_bearish:
                    bull_choch = True
                else:
                    bull_bos = True
                (
                    event_extreme,
                    event_extreme_local_index,
                    event_extreme_source_time_ms,
                ) = self._scan_event_extreme(
                    history=history,
                    local_index=state.local_index,
                    pivot_local_index=state.internal_high.local_index,
                    find_low=True,
                )
                created, evicted = self._create_order_block(
                    state=state,
                    history=history,
                    parsed_history=parsed_history,
                    pivot_local_index=state.internal_high.local_index,
                    bias=1,
                    break_time_ms=candle.open_time_ms,
                )
                if created is not None:
                    created_obs.append(created.snapshot())
                if evicted is not None:
                    evicted_obs.append(evicted.snapshot())

            # Pine evaluates internal bearish after bullish. If both conditions
            # are somehow true on one bar, classification sees the updated trend.
            extra_bear = (
                (not state.swing_low.valid or state.internal_low.current != state.swing_low.current)
                and bearish_bar
            )
            if (
                state.internal_low.valid
                and not state.internal_low.crossed
                and extra_bear
                and close < state.internal_low.current
                and previous_close >= state.internal_low.current
            ):
                was_bullish = state.internal_trend == 1
                state.internal_low.crossed = True
                state.internal_trend = -1
                if was_bullish:
                    bear_choch = True
                else:
                    bear_bos = True
                (
                    event_extreme,
                    event_extreme_local_index,
                    event_extreme_source_time_ms,
                ) = self._scan_event_extreme(
                    history=history,
                    local_index=state.local_index,
                    pivot_local_index=state.internal_low.local_index,
                    find_low=False,
                )
                created, evicted = self._create_order_block(
                    state=state,
                    history=history,
                    parsed_history=parsed_history,
                    pivot_local_index=state.internal_low.local_index,
                    bias=-1,
                    break_time_ms=candle.open_time_ms,
                )
                if created is not None:
                    created_obs.append(created.snapshot())
                if evicted is not None:
                    evicted_obs.append(evicted.snapshot())

            # Pine DisplayStructure(false): swing breaks update the swing trend
            # only, after both internal checks; they do not produce OB events.
            if (
                state.swing_high.valid
                and not state.swing_high.crossed
                and close > state.swing_high.current
                and previous_close <= state.swing_high.current
            ):
                state.swing_high.crossed = True
                state.swing_trend = 1

            if (
                state.swing_low.valid
                and not state.swing_low.crossed
                and close < state.swing_low.current
                and previous_close >= state.swing_low.current
            ):
                state.swing_low.crossed = True
                state.swing_trend = -1

        # Pine DeleteMitigated() runs after both internal-event branches and
        # swing-break checks. Reverse-index deletion preserves array indices.
        mitigated_obs = self._mitigate_order_blocks(
            state.active_order_blocks,
            high=high,
            low=low,
            close=close,
            mitigate_close=self.config.mitigate_close,
        )

        structure_events = PineSmcStructureEvents(
            bullish_bar=bullish_bar,
            bearish_bar=bearish_bar,
            bull_choch=bull_choch,
            bear_choch=bear_choch,
            bull_bos=bull_bos,
            bear_bos=bear_bos,
            extreme=event_extreme,
            extreme_local_index=event_extreme_local_index,
            extreme_source_time_ms=event_extreme_source_time_ms,
        )
        lifecycle = PineSmcObLifecycleEvents(
            created=tuple(created_obs),
            mitigated=tuple(mitigated_obs),
            evicted=tuple(evicted_obs),
        )
        return structure_events, lifecycle

    def _create_order_block(
        self,
        *,
        state: _PineSmcState,
        history: list[Kline],
        parsed_history: list[ParsedCandleExtremes],
        pivot_local_index: int,
        bias: int,
        break_time_ms: int,
    ) -> tuple[_PineOrderBlockState | None, _PineOrderBlockState | None]:
        """Mirror Pine internal-event OB source selection and FVG scan."""

        if bias not in (-1, 1):
            raise PineSmcReplayError("order-block bias must be -1 or 1")
        local_index = state.local_index
        span = max(0, local_index - pivot_local_index)
        if span < 1:
            return None, None
        if len(history) != local_index + 1 or len(parsed_history) != local_index + 1:
            raise PineSmcReplayError("OB scan history does not match the reset-local candle index")

        # Pine's `for step = 1 to span - 1` automatically counts downward when
        # span == 1. Preserve that source behavior for parsed-candle selection.
        best_offset = span
        seed = parsed_history[local_index - best_offset]
        best_value = seed.parsed_low if bias == 1 else seed.parsed_high
        for step in self._pine_loop_range(1, span - 1):
            offset = span - step
            candidate = parsed_history[local_index - offset]
            candidate_value = candidate.parsed_low if bias == 1 else candidate.parsed_high
            is_better = candidate_value < best_value if bias == 1 else candidate_value > best_value
            if is_better:
                best_value = candidate_value
                best_offset = offset

        source_local_index = local_index - best_offset
        source_parsed = parsed_history[source_local_index]
        top = max(source_parsed.parsed_high, source_parsed.parsed_low)
        bottom = min(source_parsed.parsed_high, source_parsed.parsed_low)
        has_fvg = self._has_directional_fvg(
            history=history,
            local_index=local_index,
            span=span,
            bias=bias,
            atr_threshold=self.config.fvg_min_atr * state.atr200,
        )
        new_ob = _PineOrderBlockState(
            top=top,
            bottom=bottom,
            bar_local_index=source_local_index,
            break_local_index=local_index,
            source_time_ms=history[source_local_index].open_time_ms,
            break_time_ms=break_time_ms,
            bias=bias,
            has_fvg=has_fvg,
            used=False,
        )
        evicted = self._push_order_block(state.active_order_blocks, new_ob)
        return new_ob, evicted

    @classmethod
    def _has_directional_fvg(
        cls,
        *,
        history: list[Kline],
        local_index: int,
        span: int,
        bias: int,
        atr_threshold: float,
    ) -> bool:
        """Check the source's directional three-candle gap offsets."""

        if bias not in (-1, 1):
            raise PineSmcReplayError("FVG bias must be -1 or 1")
        if not math.isfinite(atr_threshold) or atr_threshold < 0:
            raise PineSmcReplayError("FVG ATR threshold must be finite and non-negative")
        for offset in cls._pine_loop_range(1, span - 1):
            if bias == 1:
                low_index = local_index - (offset - 1)
                high_index = local_index - (offset + 1)
            else:
                low_index = local_index - (offset + 1)
                high_index = local_index - (offset - 1)
            # Pine history references beyond the current bar are unavailable.
            # In particular, span==1 makes the source loop descend through
            # offset 0, which requests [-1]; it cannot establish a valid gap.
            if not (0 <= low_index <= local_index and 0 <= high_index <= local_index):
                continue
            gap = float(history[low_index].low) - float(history[high_index].high)
            if gap > 0 and gap >= atr_threshold:
                return True
        return False

    @staticmethod
    def _pine_loop_range(start: int, end: int) -> range:
        """Inclusive Pine `for` range; counter direction follows endpoint order."""

        if start <= end:
            return range(start, end + 1)
        return range(start, end - 1, -1)

    @staticmethod
    def _push_order_block(
        active_order_blocks: list[_PineOrderBlockState],
        new_ob: _PineOrderBlockState,
    ) -> _PineOrderBlockState | None:
        """Mirror f_pushOB: oldest-first FIFO at a hard capacity of 100."""

        evicted: _PineOrderBlockState | None = None
        if len(active_order_blocks) >= 100:
            evicted = active_order_blocks.pop(0)
        active_order_blocks.append(new_ob)
        return evicted

    @staticmethod
    def _mitigate_order_blocks(
        active_order_blocks: list[_PineOrderBlockState],
        *,
        high: float,
        low: float,
        close: float,
        mitigate_close: bool,
    ) -> tuple[PineSmcOrderBlockTrace, ...]:
        """Mirror DeleteMitigated with strict tests and reverse-index removal."""

        bear_source = close if mitigate_close else high
        bull_source = close if mitigate_close else low
        mitigated: list[PineSmcOrderBlockTrace] = []
        for index in range(len(active_order_blocks) - 1, -1, -1):
            active = active_order_blocks[index]
            is_mitigated = (
                active.bias == -1 and bear_source > active.top
            ) or (
                active.bias == 1 and bull_source < active.bottom
            )
            if is_mitigated:
                mitigated.append(active.snapshot())
                del active_order_blocks[index]
        return tuple(mitigated)

    @staticmethod
    def _scan_event_extreme(
        *,
        history: list[Kline],
        local_index: int,
        pivot_local_index: int,
        find_low: bool,
    ) -> tuple[float, int, int]:
        """Mirror Pine's strict event-extreme scan, retaining the oldest tie."""

        span = max(0, local_index - pivot_local_index)
        start_index = local_index - span
        if start_index < 0 or local_index >= len(history):
            raise PineSmcReplayError("event-extreme scan exceeds retained source history")

        first = history[start_index]
        extreme = float(first.low if find_low else first.high)
        extreme_index = start_index
        for index in range(start_index + 1, local_index + 1):
            value = float(history[index].low if find_low else history[index].high)
            is_better = value < extreme if find_low else value > extreme
            if is_better:
                extreme = value
                extreme_index = index
        return extreme, extreme_index, history[extreme_index].open_time_ms

    def _build_trace(
        self,
        state: _PineSmcState,
        candle: Kline,
        *,
        source_bar_index: int,
        reset_start_index: int,
        structure_events: PineSmcStructureEvents,
        ob_lifecycle: PineSmcObLifecycleEvents,
        ob_eligibility: PineSmcObEligibilityTrace,
        trigger_sweep: PineSmcTriggerSweepTrace,
        ob_scoring: PineSmcObScoringTrace,
        level_evaluation: PineSmcLevelEvaluationTrace,
        indicators: PineSmcIndicatorTrace,
    ) -> PineSmcBarTrace:
        if state.parsed_high is None or state.parsed_low is None:
            raise PineSmcReplayError("parsed candle values were not initialized")
        return PineSmcBarTrace(
            symbol=self.config.symbol,
            timeframe=self.config.timeframe,
            source_bar_index=source_bar_index,
            local_index=state.local_index,
            source_time_ms=candle.open_time_ms,
            reset_start_index=reset_start_index,
            true_range=state.true_range,
            tr_sum=state.tr_sum,
            atr200=state.atr200,
            indicators=indicators,
            high_volatility=(float(candle.high) - float(candle.low)) >= 2.0 * state.atr200,
            parsed_high=state.parsed_high,
            parsed_low=state.parsed_low,
            swing_leg=state.swing_leg,
            internal_leg=state.internal_leg,
            swing_high=state.swing_high.snapshot(),
            swing_low=state.swing_low.snapshot(),
            internal_high=state.internal_high.snapshot(),
            internal_low=state.internal_low.snapshot(),
            swing_trend=state.swing_trend,
            internal_trend=state.internal_trend,
            structure_events=structure_events,
            ob_lifecycle=ob_lifecycle,
            active_order_blocks=tuple(ob.snapshot() for ob in state.active_order_blocks),
            ob_eligibility=ob_eligibility,
            trigger_sweep=trigger_sweep,
            ob_scoring=ob_scoring,
            level_evaluation=level_evaluation,
            range_top=state.range_top,
            range_top_valid=state.range_top_valid,
            range_bottom=state.range_bottom,
            range_bottom_valid=state.range_bottom_valid,
        )

