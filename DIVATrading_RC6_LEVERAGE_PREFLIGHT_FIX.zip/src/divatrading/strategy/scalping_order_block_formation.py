"""SMC V2 displacement qualification and initial OB formation.

This stage consumes confirmed Stage-2 structure events. It emits immutable,
traceable initial OB candidates only; it does not manage mitigation, retests,
entries, scoring, risk, or execution.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
import hashlib
import json
from typing import Any, Literal

from divatrading.market_data.klines import INTERVAL_MILLISECONDS
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataInputError,
    ScalpingMarketDataView,
)
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureResult,
    StructureBarTrace,
    StructureEvent,
    StructureTimeframeResult,
)

_SETUP_TIMEFRAMES = ("1m", "5m")
_ALL_TIMEFRAMES = ("1m", "5m", "15m")
_Outcome = Literal["CREATED", "REJECTED"]


class ScalpingOrderBlockFormationError(ValueError):
    """Base error for displacement and initial OB formation."""


class ScalpingOrderBlockFormationInputError(ScalpingOrderBlockFormationError):
    """Raised for mismatched or malformed source-event provenance."""


class ScalpingOrderBlockFormationCapacityError(ScalpingOrderBlockFormationError):
    """Raised when the configured per-symbol or per-timeframe budget is exceeded."""


def _hash_id(*parts: object) -> str:
    payload = "|".join(str(part) for part in parts).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def _decimal_text(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


def _valid_optional_ratio(value: Decimal | None, field_name: str) -> None:
    if value is not None and (
        not isinstance(value, Decimal) or not value.is_finite() or value < 0 or value > 1
    ):
        raise ValueError(f"{field_name} must be a Decimal between 0 and 1 or None")


def _valid_optional_non_negative(value: Decimal | None, field_name: str) -> None:
    if value is not None and (
        not isinstance(value, Decimal) or not value.is_finite() or value < 0
    ):
        raise ValueError(f"{field_name} must be a non-negative finite Decimal or None")


@dataclass(frozen=True, slots=True)
class ScalpingOrderBlockFormationConfig:
    """Bounded OB formation policy.

    Numeric displacement cutoffs default to ``None`` (disabled) until Binance
    historical replay calibrates them. This intentionally avoids inventing
    profitability-based thresholds. A confirmed structure break, a directional
    displacement candle/leg, an opposing source candle, and a valid tick-aligned
    wick zone remain hard source-definition requirements.
    """

    min_break_body_range_ratio: Decimal | None = None
    min_leg_body_range_ratio: Decimal | None = None
    min_close_extension_ticks: Decimal | None = None
    min_directional_leg_candles: int = 1
    max_displacement_leg_candles: int = 8
    ob_source_lookback_bars: int = 20
    max_symbols: int = 16
    max_candidates_per_timeframe: int = 512
    max_processed_events_per_timeframe: int = 2048
    max_traces_per_timeframe: int = 1024

    def __post_init__(self) -> None:
        _valid_optional_ratio(self.min_break_body_range_ratio, "min_break_body_range_ratio")
        _valid_optional_ratio(self.min_leg_body_range_ratio, "min_leg_body_range_ratio")
        _valid_optional_non_negative(self.min_close_extension_ticks, "min_close_extension_ticks")
        for name, low, high in (
            ("min_directional_leg_candles", 1, 50),
            ("max_displacement_leg_candles", 1, 50),
            ("ob_source_lookback_bars", 1, 200),
            ("max_symbols", 1, 32),
            ("max_candidates_per_timeframe", 8, 2048),
            ("max_processed_events_per_timeframe", 8, 8192),
            ("max_traces_per_timeframe", 8, 4096),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise ValueError(f"{name} must be between {low} and {high}")
        if self.min_directional_leg_candles > self.max_displacement_leg_candles:
            raise ValueError("min_directional_leg_candles cannot exceed max_displacement_leg_candles")
        if self.max_processed_events_per_timeframe < self.max_candidates_per_timeframe:
            raise ValueError("processed-event budget must be at least the candidate budget")


@dataclass(frozen=True, slots=True)
class DisplacementMeasurements:
    break_body: Decimal
    break_full_range: Decimal
    break_body_range_ratio: Decimal
    close_extension: Decimal
    close_extension_ticks: Decimal
    directional_leg_start_index: int
    directional_leg_start_open_time_ms: int
    directional_leg_candle_count: int
    leg_body_sum: Decimal
    leg_full_range_sum: Decimal
    leg_body_range_ratio: Decimal
    fvg_evidence_present: bool | None = None
    fvg_evidence_status: str = "NOT_EVALUATED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "break_body": _decimal_text(self.break_body),
            "break_full_range": _decimal_text(self.break_full_range),
            "break_body_range_ratio": _decimal_text(self.break_body_range_ratio),
            "close_extension": _decimal_text(self.close_extension),
            "close_extension_ticks": _decimal_text(self.close_extension_ticks),
            "directional_leg_start_index": self.directional_leg_start_index,
            "directional_leg_start_open_time_ms": self.directional_leg_start_open_time_ms,
            "directional_leg_candle_count": self.directional_leg_candle_count,
            "leg_body_sum": _decimal_text(self.leg_body_sum),
            "leg_full_range_sum": _decimal_text(self.leg_full_range_sum),
            "leg_body_range_ratio": _decimal_text(self.leg_body_range_ratio),
            "fvg_evidence_present": self.fvg_evidence_present,
            "fvg_evidence_status": self.fvg_evidence_status,
        }


@dataclass(frozen=True, slots=True)
class OrderBlockCandidate:
    candidate_id: str
    event_id: str
    symbol: str
    timeframe: str
    structure_layer: str
    structure_event_type: str
    direction: int
    source_bar_index: int
    source_open_time_ms: int
    source_confirmation_time_ms: int
    source_open: Decimal
    source_high: Decimal
    source_low: Decimal
    source_close: Decimal
    zone_top: Decimal
    zone_bottom: Decimal
    zone_boundary_convention: str
    broken_structure_level: Decimal
    break_bar_index: int
    break_bar_open_time_ms: int
    break_confirmation_time_ms: int
    break_open: Decimal
    break_high: Decimal
    break_low: Decimal
    break_close: Decimal
    displacement_leg_id: str
    displacement: DisplacementMeasurements
    reason_codes: tuple[str, ...]

    @property
    def direction_name(self) -> str:
        return "BULLISH" if self.direction > 0 else "BEARISH"

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "ORDER_BLOCK_CANDIDATE",
            "candidate_id": self.candidate_id,
            "event_id": self.event_id,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "structure_layer": self.structure_layer,
            "structure_event_type": self.structure_event_type,
            "direction": self.direction_name,
            "source": {
                "bar_index": self.source_bar_index,
                "open_time_ms": self.source_open_time_ms,
                "confirmation_time_ms": self.source_confirmation_time_ms,
                "open": _decimal_text(self.source_open),
                "high": _decimal_text(self.source_high),
                "low": _decimal_text(self.source_low),
                "close": _decimal_text(self.source_close),
            },
            "zone": {
                "top": _decimal_text(self.zone_top),
                "bottom": _decimal_text(self.zone_bottom),
                "boundary_convention": self.zone_boundary_convention,
            },
            "break": {
                "broken_structure_level": _decimal_text(self.broken_structure_level),
                "bar_index": self.break_bar_index,
                "bar_open_time_ms": self.break_bar_open_time_ms,
                "confirmation_time_ms": self.break_confirmation_time_ms,
                "open": _decimal_text(self.break_open),
                "high": _decimal_text(self.break_high),
                "low": _decimal_text(self.break_low),
                "close": _decimal_text(self.break_close),
            },
            "displacement_leg_id": self.displacement_leg_id,
            "displacement": self.displacement.to_dict(),
            "reason_codes": list(self.reason_codes),
        }


@dataclass(frozen=True, slots=True)
class OrderBlockFormationTrace:
    event_id: str
    symbol: str
    timeframe: str
    outcome: _Outcome
    reason_codes: tuple[str, ...]
    candidate_id: str | None
    break_bar_index: int | None
    displacement_leg_start_index: int | None
    source_bar_index: int | None
    displacement: DisplacementMeasurements | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_type": "OB_FORMATION_TRACE",
            "event_id": self.event_id,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "outcome": self.outcome,
            "reason_codes": list(self.reason_codes),
            "candidate_id": self.candidate_id,
            "break_bar_index": self.break_bar_index,
            "displacement_leg_start_index": self.displacement_leg_start_index,
            "source_bar_index": self.source_bar_index,
            "displacement": None if self.displacement is None else self.displacement.to_dict(),
        }


@dataclass(frozen=True, slots=True)
class OrderBlockTimeframeResult:
    symbol: str
    timeframe: str
    status: str
    reason_codes: tuple[str, ...]
    candidates: tuple[OrderBlockCandidate, ...]
    traces: tuple[OrderBlockFormationTrace, ...]
    processed_event_count: int


@dataclass(frozen=True, slots=True)
class ScalpingOrderBlockFormationResult:
    symbol: str
    captured_at_ms: int
    timeframes: tuple[OrderBlockTimeframeResult, ...]

    def timeframe(self, interval: str) -> OrderBlockTimeframeResult | None:
        return next((item for item in self.timeframes if item.timeframe == interval), None)

    @property
    def candidates(self) -> tuple[OrderBlockCandidate, ...]:
        return tuple(candidate for item in self.timeframes for candidate in item.candidates)

    def to_jsonl(self) -> str:
        rows: list[dict[str, Any]] = []
        for item in self.timeframes:
            rows.extend(trace.to_dict() for trace in item.traces)
            rows.extend(candidate.to_dict() for candidate in item.candidates)
        return "\n".join(
            json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            for item in rows
        )


@dataclass(slots=True)
class _TimeframeOBState:
    candidates: list[OrderBlockCandidate] = field(default_factory=list)
    traces: list[OrderBlockFormationTrace] = field(default_factory=list)
    processed_event_fingerprints: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class _PreparedEvent:
    event: StructureEvent
    trace: StructureBarTrace | None
    fingerprint: str
    formation_trace: OrderBlockFormationTrace
    candidate: OrderBlockCandidate | None


class ScalpingOrderBlockFormationEngine:
    """Form initial OB candidates from exact confirmed Stage-2 break events."""

    def __init__(self, *, config: ScalpingOrderBlockFormationConfig | None = None) -> None:
        self.config = config or ScalpingOrderBlockFormationConfig()
        self._states: dict[tuple[str, str], _TimeframeOBState] = {}

    def reset(self, *, symbol: str | None = None, timeframe: str | None = None) -> None:
        if timeframe is not None and timeframe not in _ALL_TIMEFRAMES:
            raise ValueError("timeframe must be 1m, 5m or 15m")
        if symbol is None and timeframe is not None:
            raise ValueError("symbol is required when resetting one timeframe")
        if symbol is None and timeframe is None:
            self._states.clear()
            return
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized:
            raise ValueError("symbol must be a non-empty string")
        for key in tuple(self._states):
            if key[0] == normalized and (timeframe is None or key[1] == timeframe):
                del self._states[key]

    def process(
        self,
        structure: ScalpingMarketStructureResult,
        view: ScalpingMarketDataView,
    ) -> ScalpingOrderBlockFormationResult:
        """Consume a same-capture Stage-2 result and exact Binance instrument view.

        The method performs a full preflight/prepare pass for M1 and M5 before
        committing either timeframe, preserving atomicity on malformed inputs.
        M15 is represented as advisory context only and never forms/suppresses OBs.
        """
        if not isinstance(structure, ScalpingMarketStructureResult):
            raise ScalpingOrderBlockFormationInputError("structure must be a ScalpingMarketStructureResult")
        if not isinstance(view, ScalpingMarketDataView):
            raise ScalpingOrderBlockFormationInputError("view must be a ScalpingMarketDataView")
        if structure.symbol != view.symbol or structure.captured_at_ms != view.captured_at_ms:
            raise ScalpingOrderBlockFormationInputError("structure result and market-data view capture identity mismatch")
        if not view.readiness.instrument_price_grid_ready or view.instrument.tick_size is None:
            return self._unavailable_result(structure, "INSTRUMENT_PRICE_GRID_NOT_READY")

        known_symbols = {key[0] for key in self._states}
        if structure.symbol not in known_symbols and len(known_symbols) >= self.config.max_symbols:
            raise ScalpingOrderBlockFormationCapacityError(
                f"OB formation symbol cap reached ({self.config.max_symbols})"
            )

        by_tf: dict[str, StructureTimeframeResult] = {}
        for item in structure.timeframes:
            if item.timeframe not in _ALL_TIMEFRAMES or item.symbol != structure.symbol:
                raise ScalpingOrderBlockFormationInputError("structure timeframe identity mismatch")
            if item.timeframe in by_tf:
                raise ScalpingOrderBlockFormationInputError("duplicate timeframe result")
            by_tf[item.timeframe] = item

        prepared: dict[str, list[_PreparedEvent]] = {}
        for timeframe in _SETUP_TIMEFRAMES:
            tf_result = by_tf.get(timeframe)
            if tf_result is None:
                prepared[timeframe] = []
                continue
            if tf_result.status not in ("READY", "WARMING_UP", "UNAVAILABLE"):
                raise ScalpingOrderBlockFormationInputError("structure timeframe status is invalid")
            if tf_result.status == "UNAVAILABLE":
                prepared[timeframe] = []
                continue
            if len(tf_result.events) > self.config.max_processed_events_per_timeframe:
                raise ScalpingOrderBlockFormationCapacityError(
                    "incoming structure event batch exceeds the configured per-timeframe bound"
                )
            trace_map = self._validate_trace_set(tf_result, view)
            state = self._states.get((structure.symbol, timeframe), _TimeframeOBState())
            seen_in_batch: dict[str, str] = {}
            rows: list[_PreparedEvent] = []
            for event in tf_result.events:
                self._validate_event(event, structure.symbol, timeframe)
                try:
                    view.instrument.require_price_on_tick(event.broken_level)
                    view.instrument.require_price_on_tick(event.pivot_price)
                    view.instrument.require_price_on_tick(event.previous_close)
                    view.instrument.require_price_on_tick(event.confirmation_close)
                except ScalpingMarketDataInputError as exc:
                    raise ScalpingOrderBlockFormationInputError(str(exc)) from exc
                fingerprint = self._event_fingerprint(event)
                existing = state.processed_event_fingerprints.get(event.event_id)
                if existing is not None:
                    if existing != fingerprint:
                        raise ScalpingOrderBlockFormationInputError(
                            "structure event ID was reused with different event content"
                        )
                    continue
                batch_existing = seen_in_batch.get(event.event_id)
                if batch_existing is not None:
                    if batch_existing != fingerprint:
                        raise ScalpingOrderBlockFormationInputError(
                            "duplicate structure event ID has conflicting content"
                        )
                    continue
                seen_in_batch[event.event_id] = fingerprint
                break_trace = self._find_event_trace(event, trace_map)
                formation_trace, candidate = self._evaluate_event(
                    event, break_trace, trace_map, view.instrument.tick_size
                )
                rows.append(_PreparedEvent(event, break_trace, fingerprint, formation_trace, candidate))
            prepared[timeframe] = rows

        # Commit only after every M1/M5 event has been validated and evaluated.
        for timeframe in _SETUP_TIMEFRAMES:
            rows = prepared[timeframe]
            if not rows:
                continue
            state = self._states.setdefault((structure.symbol, timeframe), _TimeframeOBState())
            for item in rows:
                state.processed_event_fingerprints[item.event.event_id] = item.fingerprint
                if item.candidate is not None:
                    state.candidates.append(item.candidate)
                state.traces.append(item.formation_trace)
            if len(state.candidates) > self.config.max_candidates_per_timeframe:
                del state.candidates[: len(state.candidates) - self.config.max_candidates_per_timeframe]
            if len(state.traces) > self.config.max_traces_per_timeframe:
                del state.traces[: len(state.traces) - self.config.max_traces_per_timeframe]
            while len(state.processed_event_fingerprints) > self.config.max_processed_events_per_timeframe:
                oldest = next(iter(state.processed_event_fingerprints))
                del state.processed_event_fingerprints[oldest]

        results: list[OrderBlockTimeframeResult] = []
        for timeframe in _ALL_TIMEFRAMES:
            if timeframe == "15m":
                tf_result = by_tf.get(timeframe)
                results.append(OrderBlockTimeframeResult(
                    symbol=structure.symbol,
                    timeframe=timeframe,
                    status="ADVISORY_ONLY" if tf_result is not None and tf_result.ready else "CONTEXT_UNAVAILABLE",
                    reason_codes=() if tf_result is not None and tf_result.ready else ("M15_IS_ADVISORY_ONLY",),
                    candidates=(),
                    traces=(),
                    processed_event_count=0,
                ))
                continue
            state = self._states.get((structure.symbol, timeframe), _TimeframeOBState())
            tf_result = by_tf.get(timeframe)
            status = "READY" if tf_result is not None and tf_result.ready else (
                "WARMING_UP" if tf_result is not None and tf_result.status == "WARMING_UP" else "UNAVAILABLE"
            )
            results.append(OrderBlockTimeframeResult(
                symbol=structure.symbol,
                timeframe=timeframe,
                status=status,
                reason_codes=() if status == "READY" else ("TIMEFRAME_SETUP_NOT_READY",),
                candidates=tuple(state.candidates),
                traces=tuple(state.traces),
                processed_event_count=len(state.processed_event_fingerprints),
            ))
        return ScalpingOrderBlockFormationResult(structure.symbol, structure.captured_at_ms, tuple(results))

    def _unavailable_result(
        self, structure: ScalpingMarketStructureResult, reason: str
    ) -> ScalpingOrderBlockFormationResult:
        return ScalpingOrderBlockFormationResult(
            structure.symbol,
            structure.captured_at_ms,
            tuple(OrderBlockTimeframeResult(
                symbol=structure.symbol, timeframe=tf, status="UNAVAILABLE", reason_codes=(reason,),
                candidates=tuple(self._states.get((structure.symbol, tf), _TimeframeOBState()).candidates),
                traces=tuple(self._states.get((structure.symbol, tf), _TimeframeOBState()).traces),
                processed_event_count=len(self._states.get((structure.symbol, tf), _TimeframeOBState()).processed_event_fingerprints),
            ) for tf in _ALL_TIMEFRAMES),
        )

    @staticmethod
    def _validate_event(event: StructureEvent, symbol: str, timeframe: str) -> None:
        if not isinstance(event, StructureEvent):
            raise ScalpingOrderBlockFormationInputError("timeframe events must be StructureEvent values")
        if event.symbol != symbol or event.timeframe != timeframe:
            raise ScalpingOrderBlockFormationInputError("structure event symbol/timeframe identity mismatch")
        if (
            isinstance(event.direction, bool)
            or not isinstance(event.direction, int)
            or event.direction not in (-1, 1)
            or event.layer not in ("SWING", "INTERNAL")
        ):
            raise ScalpingOrderBlockFormationInputError("structure event direction/layer is invalid")
        if event.event_type not in ("BOS", "CHoCH"):
            raise ScalpingOrderBlockFormationInputError("structure event type is invalid")
        interval_ms = INTERVAL_MILLISECONDS[timeframe]
        time_values = (
            event.pivot_source_open_time_ms, event.pivot_confirmation_close_time_ms,
            event.break_bar_open_time_ms, event.confirmation_time_ms,
        )
        if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in time_values):
            raise ScalpingOrderBlockFormationInputError("structure event timestamps are invalid")
        if (
            event.pivot_source_open_time_ms >= event.break_bar_open_time_ms
            or event.pivot_confirmation_close_time_ms >= event.break_bar_open_time_ms
            or event.confirmation_time_ms != event.break_bar_open_time_ms + interval_ms - 1
            or event.pivot_price != event.broken_level
        ):
            raise ScalpingOrderBlockFormationInputError("structure event time or pivot provenance is invalid")
        crossed = (
            event.previous_close <= event.broken_level < event.confirmation_close
            if event.direction > 0
            else event.previous_close >= event.broken_level > event.confirmation_close
        )
        if not crossed:
            raise ScalpingOrderBlockFormationInputError("structure event does not satisfy confirmed close-cross semantics")
        if not event.event_id or not event.pivot_id:
            raise ScalpingOrderBlockFormationInputError("structure event/pivot identity is required")

    @staticmethod
    def _event_fingerprint(event: StructureEvent) -> str:
        payload = {
            "event_id": event.event_id,
            "symbol": event.symbol,
            "timeframe": event.timeframe,
            "layer": event.layer,
            "event_type": event.event_type,
            "direction": event.direction,
            "broken_level": _decimal_text(event.broken_level),
            "pivot_id": event.pivot_id,
            "pivot_price": _decimal_text(event.pivot_price),
            "pivot_source_open_time_ms": event.pivot_source_open_time_ms,
            "pivot_confirmation_close_time_ms": event.pivot_confirmation_close_time_ms,
            "break_bar_open_time_ms": event.break_bar_open_time_ms,
            "confirmation_time_ms": event.confirmation_time_ms,
            "previous_close": _decimal_text(event.previous_close),
            "confirmation_close": _decimal_text(event.confirmation_close),
            "protected_pivot_id": event.protected_pivot_id,
            "protected_price": _decimal_text(event.protected_price),
            "protected_kind": event.protected_kind,
        }
        text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def _validate_trace_set(
        self, result: StructureTimeframeResult, view: ScalpingMarketDataView
    ) -> dict[int, StructureBarTrace]:
        trace_map: dict[int, StructureBarTrace] = {}
        interval_ms = INTERVAL_MILLISECONDS[result.timeframe]
        if len(result.bar_traces) > 5000:
            raise ScalpingOrderBlockFormationCapacityError(
                "incoming structure bar trace set exceeds the hard 5,000-record bound"
            )
        for trace in result.bar_traces:
            if trace.symbol != result.symbol or trace.timeframe != result.timeframe:
                raise ScalpingOrderBlockFormationInputError("structure bar trace identity mismatch")
            if isinstance(trace.bar_index, bool) or not isinstance(trace.bar_index, int) or trace.bar_index < 0:
                raise ScalpingOrderBlockFormationInputError("structure trace bar index is invalid")
            if trace.bar_index in trace_map:
                raise ScalpingOrderBlockFormationInputError("duplicate structure bar index")
            if (
                isinstance(trace.bar_open_time_ms, bool) or not isinstance(trace.bar_open_time_ms, int)
                or isinstance(trace.confirmation_time_ms, bool) or not isinstance(trace.confirmation_time_ms, int)
                or trace.bar_open_time_ms < 0
                or trace.confirmation_time_ms != trace.bar_open_time_ms + interval_ms - 1
            ):
                raise ScalpingOrderBlockFormationInputError("structure trace confirmation boundary is invalid")
            if trace.confirmation_time_ms >= view.captured_at_ms:
                raise ScalpingOrderBlockFormationInputError("structure trace is not a closed candle at capture time")
            prices = (trace.open, trace.high, trace.low, trace.close)
            if any(not isinstance(value, Decimal) or not value.is_finite() or value <= 0 for value in prices):
                raise ScalpingOrderBlockFormationInputError("structure trace contains invalid OHLC prices")
            if trace.high < max(trace.open, trace.low, trace.close) or trace.low > min(trace.open, trace.high, trace.close):
                raise ScalpingOrderBlockFormationInputError("structure trace OHLC range is inconsistent")
            for price in prices:
                try:
                    view.instrument.require_price_on_tick(price)
                except ScalpingMarketDataInputError as exc:
                    raise ScalpingOrderBlockFormationInputError(str(exc)) from exc
            if not isinstance(trace.events, tuple) or not isinstance(trace.new_pivots, tuple):
                raise ScalpingOrderBlockFormationInputError("structure trace event/pivot collections must be immutable tuples")
            trace_map[trace.bar_index] = trace
        ordered = sorted(trace_map.values(), key=lambda item: item.bar_index)
        for previous, current in zip(ordered, ordered[1:]):
            expected_open = previous.bar_open_time_ms + (current.bar_index - previous.bar_index) * interval_ms
            if current.bar_open_time_ms != expected_open:
                raise ScalpingOrderBlockFormationInputError("structure trace index/time continuity is invalid")

        snapshot = view.kline(result.timeframe)
        if snapshot is not None:
            candle_by_time = {item.open_time_ms: item for item in snapshot.candles}
            for trace in ordered:
                candle = candle_by_time.get(trace.bar_open_time_ms)
                if candle is None:
                    continue  # older replay bars may be outside the current bounded market-data window
                if (
                    trace.open != candle.open or trace.high != candle.high
                    or trace.low != candle.low or trace.close != candle.close
                    or trace.confirmation_time_ms != candle.close_time_ms
                ):
                    raise ScalpingOrderBlockFormationInputError(
                        "structure trace OHLC does not match the same-capture Binance Kline"
                    )
        return trace_map

    def _find_event_trace(
        self, event: StructureEvent, trace_map: dict[int, StructureBarTrace]
    ) -> StructureBarTrace | None:
        matches = [
            trace for trace in trace_map.values()
            if any(item.event_id == event.event_id for item in trace.events)
        ]
        if len(matches) > 1:
            raise ScalpingOrderBlockFormationInputError("structure event appears in multiple bar traces")
        if not matches:
            return None
        trace = matches[0]
        trace_events = [item for item in trace.events if item.event_id == event.event_id]
        if len(trace_events) != 1 or trace_events[0] != event:
            raise ScalpingOrderBlockFormationInputError(
                "structure event content does not match its immutable break-bar trace"
            )
        if (
            trace.bar_open_time_ms != event.break_bar_open_time_ms
            or trace.confirmation_time_ms != event.confirmation_time_ms
            or trace.close != event.confirmation_close
        ):
            raise ScalpingOrderBlockFormationInputError("structure event and break-bar trace provenance disagree")
        return trace

    def _evaluate_event(
        self,
        event: StructureEvent,
        break_trace: StructureBarTrace | None,
        trace_map: dict[int, StructureBarTrace],
        tick_size: Decimal,
    ) -> tuple[OrderBlockFormationTrace, OrderBlockCandidate | None]:
        if break_trace is None:
            return self._reject(event, "STRUCTURE_EVENT_TRACE_MISSING")
        break_index = break_trace.bar_index
        previous_trace = trace_map.get(break_index - 1)
        if previous_trace is None:
            return self._reject(event, "STRUCTURE_EVENT_PREVIOUS_BAR_TRACE_MISSING", break_bar_index=break_index)
        if previous_trace.close != event.previous_close:
            raise ScalpingOrderBlockFormationInputError(
                "structure event previous close does not match its previous bar trace"
            )
        expected_directional = break_trace.close > break_trace.open if event.direction > 0 else break_trace.close < break_trace.open
        if not expected_directional:
            return self._reject(event, "BREAK_BAR_DIRECTION_MISMATCH", break_bar_index=break_index)

        leg: list[StructureBarTrace] = []
        for offset in range(self.config.max_displacement_leg_candles):
            index = break_index - offset
            trace = trace_map.get(index)
            if trace is None:
                if offset == 0:
                    return self._reject(event, "BREAK_BAR_TRACE_MISSING", break_bar_index=break_index)
                break
            directional = trace.close > trace.open if event.direction > 0 else trace.close < trace.open
            if not directional:
                break
            leg.append(trace)
        if len(leg) < self.config.min_directional_leg_candles:
            return self._reject(event, "DIRECTIONAL_LEG_TOO_SHORT", break_bar_index=break_index)
        leg_start = leg[-1]
        prior_to_leg = trace_map.get(leg_start.bar_index - 1)
        if len(leg) == self.config.max_displacement_leg_candles and prior_to_leg is not None:
            prior_directional = (
                prior_to_leg.close > prior_to_leg.open if event.direction > 0
                else prior_to_leg.close < prior_to_leg.open
            )
            if prior_directional:
                return self._reject(event, "DISPLACEMENT_LEG_LOOKBACK_EXCEEDED", break_bar_index=break_index, leg_start_index=leg_start.bar_index)
        if prior_to_leg is None and leg_start.bar_index > 0:
            return self._reject(event, "DISPLACEMENT_LEG_HISTORY_INSUFFICIENT", break_bar_index=break_index, leg_start_index=leg_start.bar_index)

        leg_body_sum = sum((abs(item.close - item.open) for item in leg), Decimal("0"))
        leg_range_sum = sum((item.high - item.low for item in leg), Decimal("0"))
        if leg_range_sum <= 0:
            return self._reject(event, "DISPLACEMENT_LEG_RANGE_INVALID", break_bar_index=break_index, leg_start_index=leg_start.bar_index)
        leg_ratio = leg_body_sum / leg_range_sum

        break_body = abs(break_trace.close - break_trace.open)
        break_range = break_trace.high - break_trace.low
        if break_range <= 0:
            return self._reject(event, "BREAK_CANDLE_RANGE_INVALID", break_bar_index=break_index, leg_start_index=leg_start.bar_index)
        break_ratio = break_body / break_range
        extension = (break_trace.close - event.broken_level) * Decimal(event.direction)
        if extension <= 0:
            return self._reject(event, "CLOSE_NOT_BEYOND_BROKEN_LEVEL", break_bar_index=break_index, leg_start_index=leg_start.bar_index)
        extension_ticks = extension / tick_size
        metrics = DisplacementMeasurements(
            break_body=break_body,
            break_full_range=break_range,
            break_body_range_ratio=break_ratio,
            close_extension=extension,
            close_extension_ticks=extension_ticks,
            directional_leg_start_index=leg_start.bar_index,
            directional_leg_start_open_time_ms=leg_start.bar_open_time_ms,
            directional_leg_candle_count=len(leg),
            leg_body_sum=leg_body_sum,
            leg_full_range_sum=leg_range_sum,
            leg_body_range_ratio=leg_ratio,
        )

        threshold_reasons: list[str] = []
        if (
            self.config.min_break_body_range_ratio is not None
            and break_ratio < self.config.min_break_body_range_ratio
        ):
            threshold_reasons.append("BREAK_BODY_RANGE_RATIO_BELOW_MINIMUM")
        if (
            self.config.min_leg_body_range_ratio is not None
            and leg_ratio < self.config.min_leg_body_range_ratio
        ):
            threshold_reasons.append("LEG_BODY_RANGE_RATIO_BELOW_MINIMUM")
        if (
            self.config.min_close_extension_ticks is not None
            and extension_ticks < self.config.min_close_extension_ticks
        ):
            threshold_reasons.append("CLOSE_EXTENSION_TICKS_BELOW_MINIMUM")
        if threshold_reasons:
            return self._reject(event, tuple(threshold_reasons), break_bar_index=break_index, leg_start_index=leg_start.bar_index, displacement=metrics)

        source_start = max(0, leg_start.bar_index - self.config.ob_source_lookback_bars)
        source: StructureBarTrace | None = None
        # Search nearest-to-farthest and stop at the first opposing candle.
        # Older bars beyond that candle are irrelevant to identifying the last
        # opposing source; a missing bar before it is an integrity failure.
        for index in range(leg_start.bar_index - 1, source_start - 1, -1):
            trace = trace_map.get(index)
            if trace is None:
                return self._reject(
                    event, "OB_SOURCE_HISTORY_INSUFFICIENT",
                    break_bar_index=break_index, leg_start_index=leg_start.bar_index,
                    displacement=metrics,
                )
            if event.direction > 0 and trace.close < trace.open:
                source = trace
                break
            if event.direction < 0 and trace.close > trace.open:
                source = trace
                break
        if source is None:
            return self._reject(event, "LAST_OPPOSING_SOURCE_CANDLE_NOT_FOUND", break_bar_index=break_index, leg_start_index=leg_start.bar_index, displacement=metrics)

        zone_top = source.high
        zone_bottom = source.low
        if zone_top <= 0 or zone_bottom <= 0 or zone_top <= zone_bottom:
            return self._reject(event, "OB_ZONE_BOUNDARIES_INVALID", break_bar_index=break_index, leg_start_index=leg_start.bar_index, source_bar_index=source.bar_index, displacement=metrics)
        # Full source-candle wick is the V2 baseline zone convention. Both
        # endpoints must already be on tick; never quantize a source price.
        if zone_top % tick_size != 0 or zone_bottom % tick_size != 0:
            return self._reject(event, "OB_ZONE_TICK_GRID_INVALID", break_bar_index=break_index, leg_start_index=leg_start.bar_index, source_bar_index=source.bar_index, displacement=metrics)

        displacement_leg_id = _hash_id(
            event.symbol, event.timeframe, event.direction, leg_start.bar_open_time_ms,
            break_trace.bar_open_time_ms, event.event_id,
        )
        candidate_id = _hash_id(event.event_id, source.bar_open_time_ms, zone_top, zone_bottom)
        candidate = OrderBlockCandidate(
            candidate_id=candidate_id,
            event_id=event.event_id,
            symbol=event.symbol,
            timeframe=event.timeframe,
            structure_layer=event.layer,
            structure_event_type=event.event_type,
            direction=event.direction,
            source_bar_index=source.bar_index,
            source_open_time_ms=source.bar_open_time_ms,
            source_confirmation_time_ms=source.confirmation_time_ms,
            source_open=source.open,
            source_high=source.high,
            source_low=source.low,
            source_close=source.close,
            zone_top=zone_top,
            zone_bottom=zone_bottom,
            zone_boundary_convention="FULL_SOURCE_CANDLE_WICK",
            broken_structure_level=event.broken_level,
            break_bar_index=break_trace.bar_index,
            break_bar_open_time_ms=event.break_bar_open_time_ms,
            break_confirmation_time_ms=event.confirmation_time_ms,
            break_open=break_trace.open,
            break_high=break_trace.high,
            break_low=break_trace.low,
            break_close=break_trace.close,
            displacement_leg_id=displacement_leg_id,
            displacement=metrics,
            reason_codes=("CONFIRMED_STRUCTURE_BREAK", "DIRECTIONAL_DISPLACEMENT_VALID", "LAST_OPPOSING_CANDLE_SELECTED", "FULL_WICK_ZONE"),
        )
        trace = OrderBlockFormationTrace(
            event_id=event.event_id, symbol=event.symbol, timeframe=event.timeframe,
            outcome="CREATED", reason_codes=("OB_CANDIDATE_CREATED",), candidate_id=candidate_id,
            break_bar_index=break_index, displacement_leg_start_index=leg_start.bar_index,
            source_bar_index=source.bar_index, displacement=metrics,
        )
        return trace, candidate

    @staticmethod
    def _reject(
        event: StructureEvent,
        reason_codes: str | tuple[str, ...],
        *,
        break_bar_index: int | None = None,
        leg_start_index: int | None = None,
        source_bar_index: int | None = None,
        displacement: DisplacementMeasurements | None = None,
    ) -> tuple[OrderBlockFormationTrace, None]:
        codes = (reason_codes,) if isinstance(reason_codes, str) else tuple(reason_codes)
        trace = OrderBlockFormationTrace(
            event_id=event.event_id,
            symbol=event.symbol,
            timeframe=event.timeframe,
            outcome="REJECTED",
            reason_codes=codes or ("OB_CANDIDATE_REJECTED",),
            candidate_id=None,
            break_bar_index=break_bar_index,
            displacement_leg_start_index=leg_start_index,
            source_bar_index=source_bar_index,
            displacement=displacement,
        )
        return trace, None
