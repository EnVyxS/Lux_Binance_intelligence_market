"""SMC V2 scalping data contracts and readiness adapter.

This module reuses already validated Binance market-data models. It is a
read-only adapter: it performs no I/O, does not calculate SMC signals, and
never treats optional confluence data as a structural-data veto.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal
import re
from typing import Iterable

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.absorption import AbsorptionEvidence
from divatrading.market_data.klines import Kline
from divatrading.market_data.mark_price import MarkPriceEvent
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot
from divatrading.market_data.orchestrator import MarketDataReadiness
from divatrading.market_data.strategy_snapshot import (
    KlineIntervalSnapshot,
    KlineSeriesInput,
    StrategyComponentReadiness,
    StrategyMarketDataAdapter,
    StrategyMarketDataConfig,
    StrategyMarketDataInputError,
)

_SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,30}$")
_REQUIRED_SETUP_INTERVALS = ("1m", "5m")
_ALL_INTERVALS = ("1m", "5m", "15m")


class ScalpingMarketDataError(ValueError):
    """Base error for SMC V2 scalping market-data contracts."""


class ScalpingMarketDataInputError(ScalpingMarketDataError):
    """Raised when an input does not match the typed Binance contract."""


def _optional_positive_decimal(value: Decimal | None, field_name: str) -> Decimal | None:
    if value is None:
        return None
    if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
        raise ScalpingMarketDataInputError(f"{field_name} must be a positive finite Decimal or None")
    return value


def _optional_non_negative_decimal(value: Decimal | None, field_name: str) -> Decimal | None:
    if value is None:
        return None
    if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
        raise ScalpingMarketDataInputError(f"{field_name} must be a non-negative finite Decimal or None")
    return value


@dataclass(frozen=True, slots=True)
class InstrumentSpec:
    """Exact instrument filters derived from one Binance USD-M SymbolInfo.

    ``tick_size`` is sourced only from PRICE_FILTER.tickSize. Price precision
    must never be substituted for tick size. Missing optional quantity filters
    do not invalidate structure analysis, but their readiness is exposed.
    """

    symbol: str
    base_asset: str
    quote_asset: str
    margin_asset: str | None
    contract_type: str
    status: str
    tick_size: Decimal | None
    min_price: Decimal | None
    max_price: Decimal | None
    lot_step_size: Decimal | None
    min_qty: Decimal | None
    max_qty: Decimal | None
    market_lot_step_size: Decimal | None
    market_min_qty: Decimal | None
    market_max_qty: Decimal | None
    min_notional: Decimal | None
    order_types: tuple[str, ...]
    time_in_force: tuple[str, ...]
    price_precision: int | None
    quantity_precision: int | None
    source: str = "BINANCE_USDM_EXCHANGE_INFO"
    max_notional: Decimal | None = None

    def __post_init__(self) -> None:
        for field_name in ("symbol", "base_asset", "quote_asset", "contract_type", "status"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ScalpingMarketDataInputError(f"InstrumentSpec.{field_name} is required")
            object.__setattr__(self, field_name, value.strip().upper())
        if not _SYMBOL_RE.fullmatch(self.symbol):
            raise ScalpingMarketDataInputError("InstrumentSpec.symbol is not an exact contract symbol")
        if self.margin_asset is not None:
            if not isinstance(self.margin_asset, str) or not self.margin_asset.strip():
                raise ScalpingMarketDataInputError("margin_asset must be a non-empty string or None")
            object.__setattr__(self, "margin_asset", self.margin_asset.strip().upper())
        for field_name in (
            "tick_size", "lot_step_size", "market_lot_step_size", "min_notional", "max_notional"
        ):
            _optional_positive_decimal(getattr(self, field_name), field_name)
        for field_name in (
            "min_price", "max_price", "min_qty", "max_qty", "market_min_qty", "market_max_qty"
        ):
            _optional_non_negative_decimal(getattr(self, field_name), field_name)
        for field_name in ("order_types", "time_in_force"):
            values = tuple(getattr(self, field_name))
            if any(not isinstance(value, str) or not value.strip() for value in values):
                raise ScalpingMarketDataInputError(f"{field_name} must contain non-empty strings")
            object.__setattr__(self, field_name, tuple(value.strip().upper() for value in values))
        for field_name in ("price_precision", "quantity_precision"):
            value = getattr(self, field_name)
            if value is not None and (
                isinstance(value, bool) or not isinstance(value, int) or value < 0
            ):
                raise ScalpingMarketDataInputError(f"{field_name} must be a non-negative integer or None")

    @classmethod
    def from_symbol_info(cls, info: SymbolInfo) -> "InstrumentSpec":
        """Build an exact spec from Binance's parsed Exchange Information row."""
        if not isinstance(info, SymbolInfo):
            raise ScalpingMarketDataInputError("info must be a Binance SymbolInfo")
        price_filter = info.price_filter
        lot_filter = info.lot_size
        market_lot_filter = info.market_lot_size
        primary_notional = info.notional_filter
        fallback_notional = info.min_notional_filter
        min_notional = (
            primary_notional.min_notional
            if primary_notional is not None and primary_notional.min_notional is not None
            else (fallback_notional.min_notional if fallback_notional is not None else None)
        )
        max_notional = (
            primary_notional.max_notional
            if primary_notional is not None and primary_notional.max_notional is not None
            else (fallback_notional.max_notional if fallback_notional is not None else None)
        )
        return cls(
            symbol=info.symbol,
            base_asset=info.base_asset,
            quote_asset=info.quote_asset,
            margin_asset=info.margin_asset,
            contract_type=info.contract_type,
            status=info.status,
            tick_size=None if price_filter is None else price_filter.tick_size,
            min_price=None if price_filter is None else price_filter.min_price,
            max_price=None if price_filter is None else price_filter.max_price,
            lot_step_size=None if lot_filter is None else lot_filter.step_size,
            min_qty=None if lot_filter is None else lot_filter.min_qty,
            max_qty=None if lot_filter is None else lot_filter.max_qty,
            market_lot_step_size=None if market_lot_filter is None else market_lot_filter.step_size,
            market_min_qty=None if market_lot_filter is None else market_lot_filter.min_qty,
            market_max_qty=None if market_lot_filter is None else market_lot_filter.max_qty,
            min_notional=min_notional,
            order_types=info.order_types,
            time_in_force=info.time_in_force,
            price_precision=info.price_precision,
            quantity_precision=info.quantity_precision,
            max_notional=max_notional,
        )

    @property
    def is_usdt_perpetual(self) -> bool:
        return (
            self.contract_type == "PERPETUAL"
            and self.quote_asset == "USDT"
            and self.margin_asset == "USDT"
        )

    @property
    def is_trading(self) -> bool:
        return self.status == "TRADING"

    @property
    def price_grid_ready(self) -> bool:
        return self.is_usdt_perpetual and self.is_trading and self.tick_size is not None

    @property
    def quantity_grid_ready(self) -> bool:
        return self.price_grid_ready and self.lot_step_size is not None

    @property
    def market_quantity_grid_ready(self) -> bool:
        return self.price_grid_ready and self.market_lot_step_size is not None

    def is_price_on_tick(self, price: Decimal) -> bool:
        """Return whether price is a positive exact multiple of PRICE_FILTER.tickSize."""
        if not isinstance(price, Decimal) or not price.is_finite() or price <= 0:
            raise ScalpingMarketDataInputError("price must be a positive finite Decimal")
        if self.tick_size is None:
            return False
        return price % self.tick_size == 0

    def require_price_on_tick(self, price: Decimal) -> None:
        """Fail closed when tick size is unavailable or price is off-grid."""
        if self.tick_size is None:
            raise ScalpingMarketDataError("Exact Binance PRICE_FILTER.tickSize is unavailable")
        if not self.is_price_on_tick(price):
            raise ScalpingMarketDataInputError(
                f"Price {price} is not aligned to tick size {self.tick_size} for {self.symbol}"
            )


@dataclass(frozen=True, slots=True)
class ScalpingMarketDataConfig:
    """Bounded validation policy for the V2 strategy input view."""

    max_candles_per_interval: int = 1000
    max_kline_age_intervals: int = 2
    max_mark_price_age_ms: int = 10_000
    max_flow_age_ms: int = 10_000
    max_depth_age_ms: int = 5_000
    max_orchestrator_age_ms: int = 1_000
    max_future_skew_ms: int = 5_000

    def __post_init__(self) -> None:
        if (
            isinstance(self.max_candles_per_interval, bool)
            or not isinstance(self.max_candles_per_interval, int)
            or not 2 <= self.max_candles_per_interval <= 2000
        ):
            raise ValueError("max_candles_per_interval must be between 2 and 2000")
        if (
            isinstance(self.max_kline_age_intervals, bool)
            or not isinstance(self.max_kline_age_intervals, int)
            or not 1 <= self.max_kline_age_intervals <= 10
        ):
            raise ValueError("max_kline_age_intervals must be between 1 and 10")
        for field_name in (
            "max_mark_price_age_ms", "max_flow_age_ms", "max_depth_age_ms", "max_orchestrator_age_ms"
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{field_name} must be a positive integer")
        if (
            isinstance(self.max_future_skew_ms, bool)
            or not isinstance(self.max_future_skew_ms, int)
            or self.max_future_skew_ms < 0
        ):
            raise ValueError("max_future_skew_ms must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class ScalpingComponentReadiness:
    """Readiness for one structural, contextual, flow or execution component."""

    component: str
    status: str
    ready: bool
    required_for: tuple[str, ...]
    age_ms: int | None
    reason_codes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ScalpingReadiness:
    """Separate permission flags so one timeframe/source cannot veto another."""

    instrument_price_grid_ready: bool
    instrument_quantity_grid_ready: bool
    m1_setup_ready: bool
    m5_setup_ready: bool
    m5_m1_confirmation_ready: bool
    m15_context_available: bool
    entry_quote_ready: bool
    mark_price_available: bool
    delta_cvd_available: bool
    depth_confluence_available: bool
    absorption_available: bool

    @property
    def can_scan_setups(self) -> bool:
        return self.instrument_price_grid_ready and (self.m1_setup_ready or self.m5_setup_ready)


@dataclass(frozen=True, slots=True)
class ScalpingMarketDataView:
    """Immutable SMC V2 view with independent per-timeframe readiness."""

    symbol: str
    captured_at_ms: int
    instrument: InstrumentSpec
    m1: KlineIntervalSnapshot
    m5: KlineIntervalSnapshot
    m15: KlineIntervalSnapshot
    mark_price: MarkPriceEvent | None
    flow: OrderFlowSnapshot | None
    order_book_health: OrderBookSymbolHealth | None
    order_book_metrics: OrderBookMetrics | None
    absorption: AbsorptionEvidence | None
    orchestrator_readiness: MarketDataReadiness | None
    readiness: ScalpingReadiness
    components: tuple[ScalpingComponentReadiness, ...]
    status: str
    reason_codes: tuple[str, ...]

    def kline(self, interval: str) -> KlineIntervalSnapshot | None:
        return {"1m": self.m1, "5m": self.m5, "15m": self.m15}.get(interval)

    def component(self, name: str) -> ScalpingComponentReadiness | None:
        return next((item for item in self.components if item.component == name), None)


class ScalpingMarketDataAdapter:
    """Build the SMC V2 view from the existing validated Binance market-data APIs."""

    def __init__(self, *, config: ScalpingMarketDataConfig | None = None) -> None:
        self.config = config or ScalpingMarketDataConfig()
        self._source_adapter = StrategyMarketDataAdapter(
            config=StrategyMarketDataConfig(
                required_intervals=_ALL_INTERVALS,
                max_candles_per_interval=self.config.max_candles_per_interval,
                max_kline_age_intervals=self.config.max_kline_age_intervals,
                max_mark_price_age_ms=self.config.max_mark_price_age_ms,
                max_flow_age_ms=self.config.max_flow_age_ms,
                max_depth_age_ms=self.config.max_depth_age_ms,
                max_orchestrator_age_ms=self.config.max_orchestrator_age_ms,
                max_future_skew_ms=self.config.max_future_skew_ms,
            )
        )

    def build_view(
        self,
        *,
        symbol: str,
        now_ms: int,
        symbol_info: SymbolInfo,
        kline_series: Iterable[KlineSeriesInput],
        mark_price: MarkPriceEvent | None = None,
        mark_price_connected: bool = False,
        readiness: MarketDataReadiness | None = None,
        order_book_metrics: OrderBookMetrics | None = None,
    ) -> ScalpingMarketDataView:
        normalized = self._symbol(symbol)
        self._timestamp(now_ms, "now_ms")
        if not isinstance(symbol_info, SymbolInfo):
            raise ScalpingMarketDataInputError("symbol_info must be a parsed Binance SymbolInfo")
        if symbol_info.symbol != normalized:
            raise ScalpingMarketDataInputError("Instrument metadata symbol does not match requested symbol")
        if not isinstance(mark_price_connected, bool):
            raise ScalpingMarketDataInputError("mark_price_connected must be boolean")
        try:
            instrument = InstrumentSpec.from_symbol_info(symbol_info)
        except ScalpingMarketDataInputError:
            raise

        try:
            series_items = tuple(kline_series)
        except TypeError as exc:
            raise ScalpingMarketDataInputError("kline_series must be iterable") from exc
        if len(series_items) > len(_ALL_INTERVALS):
            raise ScalpingMarketDataInputError("kline_series exceeds M1/M5/M15 capacity")
        supplied_intervals = [item.interval for item in series_items if isinstance(item, KlineSeriesInput)]
        if len(supplied_intervals) != len(series_items):
            raise ScalpingMarketDataInputError("kline_series must contain KlineSeriesInput items")
        if len(set(supplied_intervals)) != len(supplied_intervals):
            raise ScalpingMarketDataInputError("kline_series contains duplicate intervals")

        # The legacy adapter remains the single validation implementation for
        # Binance candles/flow/depth. Its all-components readiness flag is
        # deliberately ignored; V2 composes readiness per use-case below.
        source = self._source_adapter.build_snapshot(
            symbol=normalized,
            now_ms=now_ms,
            kline_series=series_items,
            mark_price=mark_price,
            mark_price_connected=mark_price_connected,
            readiness=readiness,
            order_book_metrics=order_book_metrics,
        )
        m1 = source.kline("1m")
        m5 = source.kline("5m")
        m15 = source.kline("15m")
        assert m1 is not None and m5 is not None and m15 is not None

        instrument_reasons: list[str] = []
        if not instrument.is_usdt_perpetual:
            instrument_reasons.append("INSTRUMENT_NOT_USDT_PERPETUAL")
        if not instrument.is_trading:
            instrument_reasons.append("INSTRUMENT_NOT_TRADING")
        if instrument.tick_size is None:
            instrument_reasons.append("PRICE_FILTER_TICK_SIZE_MISSING")
        instrument_ready = not instrument_reasons

        # Exchange Kline prices and executable book quotes must respect the
        # exact symbol tick grid. We never round source prices into compliance.
        def enforce_candle_tick_grid(snapshot: KlineIntervalSnapshot) -> KlineIntervalSnapshot:
            if instrument.tick_size is None:
                return snapshot
            candles = snapshot.candles + (() if snapshot.forming_candle is None else (snapshot.forming_candle,))
            for candle in candles:
                if any(
                    not instrument.is_price_on_tick(value)
                    for value in (candle.open, candle.high, candle.low, candle.close)
                ):
                    return replace(
                        snapshot,
                        ready=False,
                        reason_codes=tuple(dict.fromkeys(snapshot.reason_codes + ("KLINE_PRICE_OFF_TICK_GRID",))),
                    )
            return snapshot

        m1 = enforce_candle_tick_grid(m1)
        m5 = enforce_candle_tick_grid(m5)
        m15 = enforce_candle_tick_grid(m15)

        component_map = {item.component: item for item in source.components}

        def add_component(
            name: str,
            ready: bool,
            required_for: tuple[str, ...],
            age_ms: int | None,
            reasons: tuple[str, ...],
            *,
            has_input: bool,
            status_override: str | None = None,
        ) -> ScalpingComponentReadiness:
            status = status_override or ("READY" if ready else ("DEGRADED" if has_input else "UNAVAILABLE"))
            return ScalpingComponentReadiness(
                component=name,
                status=status,
                ready=ready,
                required_for=required_for,
                age_ms=age_ms,
                reason_codes=tuple(dict.fromkeys(reasons)),
            )

        components: list[ScalpingComponentReadiness] = []
        components.append(
            add_component(
                "INSTRUMENT_PRICE_GRID", instrument_ready, ("SETUP", "ENTRY"), None,
                tuple(instrument_reasons), has_input=True,
            )
        )
        components.append(
            add_component(
                "INSTRUMENT_QUANTITY_GRID", instrument.quantity_grid_ready, ("ORDER_QUANTITY",), None,
                () if instrument.quantity_grid_ready else ("LOT_SIZE_STEP_MISSING",), has_input=True,
            )
        )
        for name, interval, required_for in (
            ("KLINE_M1", m1, ("M1_SETUP", "M5_CONFIRMATION")),
            ("KLINE_M5", m5, ("M5_SETUP", "M5_CONFIRMATION")),
            ("KLINE_M15", m15, ("CONTEXT",)),
        ):
            components.append(
                add_component(
                    name, interval.ready, required_for, interval.age_ms,
                    interval.reason_codes, has_input=bool(interval.candles),
                )
            )

        depth_source_component = component_map["DEPTH"]
        depth_reasons = list(depth_source_component.reason_codes)
        depth_ready = depth_source_component.ready
        if readiness is not None and not readiness.order_book_ready:
            depth_ready = False
            depth_reasons.append("DEPTH_ORCHESTRATOR_GATE_CLOSED")
        if depth_ready and instrument.tick_size is None:
            depth_ready = False
            depth_reasons.append("DEPTH_TICK_SIZE_UNAVAILABLE")
        if depth_ready and order_book_metrics is not None and instrument.tick_size is not None:
            if not instrument.is_price_on_tick(order_book_metrics.best_bid) or not instrument.is_price_on_tick(
                order_book_metrics.best_ask
            ):
                depth_ready = False
                depth_reasons.append("DEPTH_QUOTE_OFF_TICK_GRID")
        effective_depth_component = replace(
            depth_source_component,
            status="READY" if depth_ready else ("DEGRADED" if depth_reasons else "UNAVAILABLE"),
            ready=depth_ready,
            reason_codes=tuple(dict.fromkeys(depth_reasons)),
        )
        component_map["DEPTH"] = effective_depth_component

        for source_name, view_name, required_for in (
            ("MARK_PRICE", "MARK_PRICE", ("MARK_CONTEXT",)),
            ("DELTA_CVD", "DELTA_CVD", ("FLOW_CONFLUENCE",)),
            ("DEPTH", "DEPTH", ("DEPTH_CONFLUENCE", "ENTRY_QUOTE")),
            ("ABSORPTION", "ABSORPTION", ("ABSORPTION_CONFLUENCE",)),
            ("ORCHESTRATOR", "ORCHESTRATOR", ("LIVE_SOURCE_HEALTH",)),
        ):
            item = component_map[source_name]
            has_input = {
                "MARK_PRICE": mark_price is not None,
                "DELTA_CVD": source.flow is not None,
                "DEPTH": source.order_book_health is not None or source.order_book_metrics is not None,
                "ABSORPTION": source.absorption is not None,
                "ORCHESTRATOR": readiness is not None,
            }[source_name]
            components.append(
                add_component(
                    view_name, item.ready, required_for, item.age_ms,
                    item.reason_codes, has_input=has_input,
                    status_override=(item.status if source_name == "ABSORPTION" and item.ready else None),
                )
            )

        m1_ready = instrument_ready and m1.ready
        m5_ready = instrument_ready and m5.ready
        depth_component = component_map["DEPTH"]
        flow_component = component_map["DELTA_CVD"]
        absorption_component = component_map["ABSORPTION"]
        mark_component = component_map["MARK_PRICE"]
        readiness_view = ScalpingReadiness(
            instrument_price_grid_ready=instrument_ready,
            instrument_quantity_grid_ready=instrument.quantity_grid_ready,
            m1_setup_ready=m1_ready,
            m5_setup_ready=m5_ready,
            m5_m1_confirmation_ready=m5_ready and m1_ready,
            m15_context_available=m15.ready,
            entry_quote_ready=depth_component.ready,
            mark_price_available=mark_component.ready,
            delta_cvd_available=flow_component.ready,
            depth_confluence_available=depth_component.ready,
            absorption_available=absorption_component.ready,
        )
        can_scan = readiness_view.can_scan_setups
        hard_reasons: list[str] = []
        if not instrument_ready:
            hard_reasons.extend(instrument_reasons)
        if not m1_ready and not m5_ready:
            hard_reasons.append("NO_VALID_SETUP_TIMEFRAME")
        status = "READY" if can_scan else "DEGRADED"
        return ScalpingMarketDataView(
            symbol=normalized,
            captured_at_ms=now_ms,
            instrument=instrument,
            m1=m1,
            m5=m5,
            m15=m15,
            mark_price=source.mark_price,
            flow=source.flow,
            order_book_health=source.order_book_health,
            order_book_metrics=source.order_book_metrics,
            absorption=source.absorption,
            orchestrator_readiness=source.orchestrator_readiness,
            readiness=readiness_view,
            components=tuple(components),
            status=status,
            reason_codes=tuple(dict.fromkeys(hard_reasons)),
        )

    @staticmethod
    def _symbol(value: str) -> str:
        if not isinstance(value, str):
            raise ScalpingMarketDataInputError("symbol must be a string")
        normalized = value.strip().upper()
        if not _SYMBOL_RE.fullmatch(normalized):
            raise ScalpingMarketDataInputError("symbol must be an exact Binance contract symbol")
        return normalized

    @staticmethod
    def _timestamp(value: int, name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ScalpingMarketDataInputError(f"{name} must be a non-negative integer")
