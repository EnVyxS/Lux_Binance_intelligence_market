"""Deterministic, strategy-agnostic records and diffing for Pine parity audits.

This module does not calculate SMC signals. It only validates normalized reference
records and compares records produced elsewhere against trusted Pine observations.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from decimal import Decimal
from typing import Literal


_SUPPORTED_TIMEFRAMES = frozenset({"1m", "5m", "15m"})
_SUPPORTED_DIRECTIONS = frozenset({"BUY", "SELL"})
_SUPPORTED_TRIGGERS = frozenset({"REJECTION", "STRUCTURE"})
_PRICE_FIELDS = (
    "entry_proxy",
    "stop_loss",
    "take_profit",
    "ob_top",
    "ob_bottom",
    "entry_band_low",
    "entry_band_high",
)
_SCORE_FIELDS = ("setup_score", "ob_quality_score", "timing_score")


class ParityContractError(ValueError):
    """Raised when a parity record or comparison request is invalid."""


def _require_decimal(value: Decimal, field_name: str) -> None:
    if not isinstance(value, Decimal):
        raise ParityContractError(f"{field_name} must be Decimal")
    if not value.is_finite():
        raise ParityContractError(f"{field_name} must be finite")


@dataclass(frozen=True, slots=True)
class ParitySignal:
    """Normalized signal observation; values must come from an identified source."""

    symbol: str
    timeframe: str
    event_time_ms: int
    evaluation_time_ms: int
    direction: str
    trigger: str
    ob_source_time_ms: int
    entry_proxy: Decimal
    stop_loss: Decimal
    take_profit: Decimal
    ob_top: Decimal
    ob_bottom: Decimal
    entry_band_low: Decimal
    entry_band_high: Decimal
    setup_score: Decimal
    ob_quality_score: Decimal
    timing_score: Decimal

    def __post_init__(self) -> None:
        if not self.symbol or not self.symbol.isalnum() or self.symbol != self.symbol.upper():
            raise ParityContractError("symbol must be non-empty uppercase alphanumeric exchange symbol")
        if self.timeframe not in _SUPPORTED_TIMEFRAMES:
            raise ParityContractError("timeframe must be one of 1m, 5m or 15m")
        if isinstance(self.event_time_ms, bool) or not isinstance(self.event_time_ms, int) or self.event_time_ms <= 0:
            raise ParityContractError("event_time_ms must be a positive integer")
        if isinstance(self.evaluation_time_ms, bool) or not isinstance(self.evaluation_time_ms, int) or self.evaluation_time_ms <= 0:
            raise ParityContractError("evaluation_time_ms must be a positive integer")
        if self.evaluation_time_ms < self.event_time_ms:
            raise ParityContractError("evaluation time cannot precede the source event time")
        if isinstance(self.ob_source_time_ms, bool) or not isinstance(self.ob_source_time_ms, int) or self.ob_source_time_ms <= 0:
            raise ParityContractError("ob_source_time_ms must be a positive integer")
        if self.ob_source_time_ms > self.event_time_ms:
            raise ParityContractError("OB source time cannot be later than signal event time")
        if self.direction not in _SUPPORTED_DIRECTIONS:
            raise ParityContractError("direction must be BUY or SELL")
        if self.trigger not in _SUPPORTED_TRIGGERS:
            raise ParityContractError("trigger must be REJECTION or STRUCTURE")

        for field_name in (*_PRICE_FIELDS, *_SCORE_FIELDS):
            value = getattr(self, field_name)
            _require_decimal(value, field_name)
            if field_name in _PRICE_FIELDS and value <= 0:
                raise ParityContractError(f"{field_name} must be positive")
            if field_name in _SCORE_FIELDS and not Decimal("0") <= value <= Decimal("100"):
                raise ParityContractError(f"{field_name} must be between 0 and 100")

        if self.ob_bottom >= self.ob_top:
            raise ParityContractError("OB bottom must be below OB top")
        if self.entry_band_low >= self.entry_band_high:
            raise ParityContractError("entry band low must be below entry band high")
        if self.direction == "BUY":
            if not self.stop_loss < self.entry_proxy < self.take_profit:
                raise ParityContractError("BUY levels must satisfy SL < entry < TP")
        elif not self.take_profit < self.entry_proxy < self.stop_loss:
            raise ParityContractError("SELL levels must satisfy TP < entry < SL")

    @property
    def key(self) -> tuple[str, str, int, str]:
        """Stable signal identity used by deterministic parity comparison."""
        return (self.symbol, self.timeframe, self.event_time_ms, self.direction)


@dataclass(frozen=True, slots=True)
class ParityMismatch:
    """One stable, machine-readable signal or field difference."""

    kind: Literal["MISSING", "UNEXPECTED", "FIELD"]
    key: tuple[str, str, int, str]
    field_name: str | None = None
    expected_value: str | None = None
    actual_value: str | None = None
    absolute_delta: str | None = None


@dataclass(frozen=True, slots=True)
class ParityDiffReport:
    """Deterministic comparison summary; `passed` means there are no mismatches."""

    expected_count: int
    actual_count: int
    matched_count: int
    mismatches: tuple[ParityMismatch, ...]

    @property
    def passed(self) -> bool:
        return not self.mismatches


def _index_signals(signals: Iterable[ParitySignal], label: str) -> dict[tuple[str, str, int, str], ParitySignal]:
    indexed: dict[tuple[str, str, int, str], ParitySignal] = {}
    for signal in signals:
        if not isinstance(signal, ParitySignal):
            raise ParityContractError(f"{label} entries must be ParitySignal records")
        if signal.key in indexed:
            raise ParityContractError(f"duplicate {label} signal key: {signal.key!r}")
        indexed[signal.key] = signal
    return indexed


def _validate_tolerance(value: Decimal, field_name: str) -> None:
    _require_decimal(value, field_name)
    if value < 0:
        raise ParityContractError(f"{field_name} cannot be negative")


def compare_signal_sets(
    expected: Iterable[ParitySignal],
    actual: Iterable[ParitySignal],
    *,
    price_tolerance: Decimal = Decimal("0"),
    score_tolerance: Decimal = Decimal("0"),
) -> ParityDiffReport:
    """Compare two normalized signal sets without performing any strategy logic.

    Price and score tolerances are explicit inputs. No implicit tick rounding or
    score rounding is applied; callers must set tolerances to match reference export
    precision. Signal identity, trigger and OB source timestamp are exact matches.
    """

    _validate_tolerance(price_tolerance, "price_tolerance")
    _validate_tolerance(score_tolerance, "score_tolerance")

    expected_by_key = _index_signals(expected, "expected")
    actual_by_key = _index_signals(actual, "actual")
    mismatches: list[ParityMismatch] = []
    matched_count = 0

    for key in sorted(set(expected_by_key) | set(actual_by_key)):
        expected_signal = expected_by_key.get(key)
        actual_signal = actual_by_key.get(key)
        if expected_signal is None:
            mismatches.append(ParityMismatch(kind="UNEXPECTED", key=key))
            continue
        if actual_signal is None:
            mismatches.append(ParityMismatch(kind="MISSING", key=key))
            continue

        before = len(mismatches)
        if expected_signal.trigger != actual_signal.trigger:
            mismatches.append(
                ParityMismatch(
                    kind="FIELD",
                    key=key,
                    field_name="trigger",
                    expected_value=expected_signal.trigger,
                    actual_value=actual_signal.trigger,
                )
            )
        if expected_signal.evaluation_time_ms != actual_signal.evaluation_time_ms:
            mismatches.append(
                ParityMismatch(
                    kind="FIELD",
                    key=key,
                    field_name="evaluation_time_ms",
                    expected_value=str(expected_signal.evaluation_time_ms),
                    actual_value=str(actual_signal.evaluation_time_ms),
                )
            )
        if expected_signal.ob_source_time_ms != actual_signal.ob_source_time_ms:
            mismatches.append(
                ParityMismatch(
                    kind="FIELD",
                    key=key,
                    field_name="ob_source_time_ms",
                    expected_value=str(expected_signal.ob_source_time_ms),
                    actual_value=str(actual_signal.ob_source_time_ms),
                )
            )

        for field_name in (*_PRICE_FIELDS, *_SCORE_FIELDS):
            expected_value = getattr(expected_signal, field_name)
            actual_value = getattr(actual_signal, field_name)
            tolerance = price_tolerance if field_name in _PRICE_FIELDS else score_tolerance
            delta = abs(actual_value - expected_value)
            if delta > tolerance:
                mismatches.append(
                    ParityMismatch(
                        kind="FIELD",
                        key=key,
                        field_name=field_name,
                        expected_value=str(expected_value),
                        actual_value=str(actual_value),
                        absolute_delta=str(delta),
                    )
                )

        if len(mismatches) == before:
            matched_count += 1

    return ParityDiffReport(
        expected_count=len(expected_by_key),
        actual_count=len(actual_by_key),
        matched_count=matched_count,
        mismatches=tuple(mismatches),
    )
