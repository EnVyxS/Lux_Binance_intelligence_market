"""Stateful SMC V2 Stage 2–5 evidence pipeline for independent multi-symbol processing."""
from __future__ import annotations

from dataclasses import dataclass
from threading import RLock

from divatrading.strategy.scalping_market_data import ScalpingMarketDataView
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig, ScalpingMarketStructureEngine,
    ScalpingMarketStructureResult,
)
from divatrading.strategy.scalping_order_block_formation import (
    ScalpingOrderBlockFormationConfig, ScalpingOrderBlockFormationEngine,
    ScalpingOrderBlockFormationResult,
)
from divatrading.strategy.scalping_order_block_lifecycle import (
    ScalpingOrderBlockLifecycleConfig, ScalpingOrderBlockLifecycleEngine,
    ScalpingOrderBlockLifecycleResult,
)
from divatrading.strategy.scalping_liquidity_fvg import (
    ScalpingLiquidityFVGConfig, ScalpingLiquidityFVGEngine,
    ScalpingLiquidityFVGResult,
)


@dataclass(frozen=True, slots=True)
class SMCV2EvidenceSnapshot:
    symbol: str
    captured_at_ms: int
    structure: ScalpingMarketStructureResult
    ob_formation: ScalpingOrderBlockFormationResult
    ob_lifecycle: ScalpingOrderBlockLifecycleResult
    liquidity_fvg: ScalpingLiquidityFVGResult
    market_view: ScalpingMarketDataView

    @property
    def active_fresh_order_blocks(self):
        return tuple(item for item in self.ob_lifecycle.order_blocks if item.status == "ACTIVE_FRESH")

    @property
    def touched_order_blocks(self):
        return tuple(item for item in self.ob_lifecycle.order_blocks if item.status == "TOUCHED")


class SMCV2EvidencePipeline:
    """Run the existing Stage 2→3→4 and Stage 2→5 engines on one validated capture.

    Every underlying engine already keys state by (symbol,timeframe). A shared
    pipeline permits multiple symbols without introducing cross-pair MTF priority.
    M15 remains advisory in the underlying engines.
    """
    def __init__(self, *, max_symbols: int = 24,
                 structure_engine: ScalpingMarketStructureEngine | None = None,
                 formation_engine: ScalpingOrderBlockFormationEngine | None = None,
                 lifecycle_engine: ScalpingOrderBlockLifecycleEngine | None = None,
                 liquidity_engine: ScalpingLiquidityFVGEngine | None = None) -> None:
        if isinstance(max_symbols, bool) or not 1 <= max_symbols <= 32:
            raise ValueError("max_symbols must be between 1 and 32")
        self.structure_engine = structure_engine or ScalpingMarketStructureEngine(
            config=ScalpingMarketStructureConfig(max_symbols=max_symbols)
        )
        self.formation_engine = formation_engine or ScalpingOrderBlockFormationEngine(
            config=ScalpingOrderBlockFormationConfig(max_symbols=max_symbols)
        )
        self.lifecycle_engine = lifecycle_engine or ScalpingOrderBlockLifecycleEngine(
            config=ScalpingOrderBlockLifecycleConfig(max_symbols=max_symbols)
        )
        self.liquidity_engine = liquidity_engine or ScalpingLiquidityFVGEngine(
            config=ScalpingLiquidityFVGConfig(max_symbols=max_symbols)
        )
        self.max_symbols = max_symbols
        self._lock = RLock()
        self._symbols: set[str] = set()

    def process(self, view: ScalpingMarketDataView) -> SMCV2EvidenceSnapshot:
        if not isinstance(view, ScalpingMarketDataView):
            raise TypeError("view must be ScalpingMarketDataView")
        with self._lock:
            if view.symbol not in self._symbols and len(self._symbols) >= self.max_symbols:
                raise RuntimeError(f"SMC V2 multi-symbol capacity reached ({self.max_symbols})")
            structure = self.structure_engine.process(view)
            formation = self.formation_engine.process(structure, view)
            lifecycle = self.lifecycle_engine.process(formation, view)
            liquidity = self.liquidity_engine.process(structure, view)
            self._symbols.add(view.symbol)
            return SMCV2EvidenceSnapshot(
                view.symbol, view.captured_at_ms, structure, formation, lifecycle, liquidity, view
            )

    def reset_symbol(self, symbol: str) -> None:
        normalized = symbol.strip().upper()
        if not normalized:
            raise ValueError("symbol must be non-empty")
        with self._lock:
            self.structure_engine.reset(symbol=normalized)
            self.formation_engine.reset(symbol=normalized)
            self.lifecycle_engine.reset(symbol=normalized)
            self.liquidity_engine.reset(symbol=normalized)
            self._symbols.discard(normalized)

    @property
    def active_symbols(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._symbols))
