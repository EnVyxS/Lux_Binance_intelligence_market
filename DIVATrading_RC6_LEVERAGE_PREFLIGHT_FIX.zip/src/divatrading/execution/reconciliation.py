"""Exchange-truth reconciliation and non-PAPER entry readiness gate."""
from __future__ import annotations

import time
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Callable

from .account_state import AccountSnapshot, BinanceAccountStateService
from .ledger import ExecutionLedger
from .protection import is_quantity_scoped_order_valid
from divatrading.core.reliability import classify_discrepancy


def _decimal(value: Any, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError(f"Invalid reconciliation numeric field {field}") from exc
    if not result.is_finite():
        raise ValueError(f"Non-finite reconciliation numeric field {field}")
    return result


@dataclass(frozen=True, slots=True)
class ReconciliationReport:
    ready: bool
    status: str
    captured_at_ms: int
    exchange_position_count: int
    local_position_count: int
    open_standard_order_count: int
    open_algo_order_count: int
    discrepancies: tuple[dict[str, Any], ...]
    snapshot: AccountSnapshot | None = None


class AccountReconciliationService:
    """Compare exchange account, positions, orders and local execution ledger.

    The comparison itself never cancels orders or silently repairs a mismatch. When an
    ExecutionService is supplied, pending-entry recovery may cancel an unfilled entry
    remainder and place missing protective STOP/TP orders for an exchange-confirmed fill.
    Any unresolved mismatch halts new entries.
    """
    def __init__(self, *, account_state: BinanceAccountStateService, ledger: ExecutionLedger,
                 execution_service: Any | None = None, trade_backfill_service: Any | None = None,
                 income_backfill_service: Any | None = None,
                 trade_risk_reconciler: Any | None = None,
                 trade_backfill_interval_ms: int = 60_000,
                 clock_ms: Callable[[], int] | None = None) -> None:
        self.account_state = account_state
        self.ledger = ledger
        self.execution_service = execution_service
        if isinstance(trade_backfill_interval_ms, bool) or trade_backfill_interval_ms < 1_000:
            raise ValueError("trade_backfill_interval_ms must be >= 1000")
        self.trade_backfill_service = trade_backfill_service
        self.income_backfill_service = income_backfill_service
        self.trade_risk_reconciler = trade_risk_reconciler
        self.trade_backfill_interval_ms = trade_backfill_interval_ms
        self._last_trade_backfill_at_ms: int | None = None
        self._last_income_backfill_at_ms: int | None = None
        self._force_trade_backfill = False
        self._trade_backfill_failure_halt_owned = False
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)

    def request_trade_backfill(self) -> None:
        """Require userTrades recovery before the next account snapshot.

        A reconnect can occur inside the ordinary periodic backfill interval. The
        interval is useful during a healthy stream, but it must not suppress recovery
        of fills that may have been missed while the private stream was disconnected.
        This request is latched until every symbol backfill completes successfully.
        """
        if self.trade_backfill_service is not None:
            self._force_trade_backfill = True

    @staticmethod
    def _position_side(position: Any) -> str:
        side = str(position.position_side).upper()
        if side in {"LONG", "SHORT"}:
            return side
        return "LONG" if position.quantity > 0 else "SHORT"

    @staticmethod
    def _has_protection(
        orders: tuple[dict[str, Any], ...],
        *,
        symbol: str,
        position_side: str,
        position_direction: str,
        role: str,
        expected_quantity: Decimal,
        client_algo_id: str,
        dual_side_position: bool,
        allow_legacy_close_position: bool,
        expected_trigger_price: Decimal,
    ) -> bool:
        expected_type = "STOP_MARKET" if role == "STOP_LOSS" else "TAKE_PROFIT_MARKET"
        expected_order_side = "SELL" if position_direction.upper() == "LONG" else "BUY"
        for order in orders:
            if str(order.get("symbol", "")).upper() != symbol.upper():
                continue
            order_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
            status = str(order.get("algoStatus", order.get("status", "NEW"))).upper()
            if status not in {"NEW", "PENDING_NEW", "WORKING", "PENDING", "PARTIALLY_FILLED"}:
                continue
            if str(order.get("positionSide", "BOTH")).upper() != position_side.upper():
                continue
            if str(order.get("side", "")).upper() != expected_order_side:
                continue
            if str(order.get("type", order.get("orderType", ""))).upper() != expected_type:
                continue

            close_position = order.get("closePosition", False)
            close_position = close_position is True or str(close_position).strip().lower() in {"true", "1"}
            if close_position:
                # Existing v0.51-and-earlier single-lot orders remain accepted during
                # migration only. They must not be treated as per-lot coverage when a
                # symbol/side has more than one local allocation.
                if allow_legacy_close_position and order_id in {"", client_algo_id}:
                    try:
                        trigger = _decimal(
                            order.get("triggerPrice", order.get("stopPrice")),
                            "legacy protection trigger price",
                        )
                    except ValueError:
                        continue
                    if trigger == expected_trigger_price:
                        return True
                continue
            if order_id != client_algo_id:
                continue
            if is_quantity_scoped_order_valid(
                order,
                expected_quantity=expected_quantity,
                dual_side_position=dual_side_position,
                expected_position_side=position_side,
                expected_order_side=expected_order_side,
                expected_type=expected_type,
                expected_symbol=symbol,
                expected_client_algo_id=client_algo_id,
                expected_trigger_price=expected_trigger_price,
            ):
                return True
        return False

    def reconcile(self) -> ReconciliationReport:
        now = self.clock_ms()
        discrepancies: list[dict[str, Any]] = []
        event_during_snapshot = False
        transient_backfill_halt = False
        backfill_failure_reason: str | None = None
        backfill_failure_code: str | None = None
        stream = self.ledger.get_user_stream_state()
        if stream.get("status") != "CONNECTED":
            discrepancies.append({"code": "USER_STREAM_NOT_CONNECTED",
                                   "status": stream.get("status", "UNKNOWN")})
        try:
            if (self.trade_backfill_service is not None and
                    (self._force_trade_backfill or self._last_trade_backfill_at_ms is None or
                     now - self._last_trade_backfill_at_ms >= self.trade_backfill_interval_ms)):
                was_halted, previous_halt_reason = self.ledger.entries_halted()
                recovered_owned_failure_halt = (
                    was_halted and self._trade_backfill_failure_halt_owned
                    and previous_halt_reason in {"TRADE_HISTORY_BACKFILL_FAILED", "INCOME_HISTORY_BACKFILL_FAILED"}
                )
                if not was_halted:
                    self.ledger.set_entries_halted(True, "TRADE_HISTORY_BACKFILL_IN_PROGRESS")
                    transient_backfill_halt = True
                elif recovered_owned_failure_halt:
                    # This exact halt was created by this reconciler after an earlier
                    # userTrades failure. It is not an operator kill switch; keep it
                    # latched during the retry and clear only after the subsequent
                    # complete account snapshot has no discrepancies.
                    transient_backfill_halt = True
                    self.ledger.set_entries_halted(True, "TRADE_HISTORY_BACKFILL_IN_PROGRESS")
                try:
                    for trade_symbol in self.ledger.list_trade_history_symbols():
                        self.trade_backfill_service.backfill_symbol(trade_symbol)
                except Exception as exc:
                    backfill_failure_reason = f"{type(exc).__name__}: {exc}"[:500]
                    backfill_failure_code = "TRADE_HISTORY_BACKFILL_FAILED"
                    raise
                self._last_trade_backfill_at_ms = self.clock_ms()
                if (self.income_backfill_service is not None and
                        (self._last_income_backfill_at_ms is None or
                         now - self._last_income_backfill_at_ms >= self.trade_backfill_interval_ms)):
                    try:
                        self.income_backfill_service.backfill()
                    except Exception as exc:
                        backfill_failure_reason = f"{type(exc).__name__}: {exc}"[:500]
                        backfill_failure_code = "INCOME_HISTORY_BACKFILL_FAILED"
                        raise
                    self._last_income_backfill_at_ms = self.clock_ms()
                self._force_trade_backfill = False
                self._trade_backfill_failure_halt_owned = False
                # Preserve any new halt installed *during* the backfill.
                # Blindly restoring previous_halt_reason can overwrite a newer
                # risk/protection/kill-switch latch.
                if was_halted:
                    current_halted, current_reason = self.ledger.entries_halted()
                    if not current_halted:
                        self.ledger.set_entries_halted(True, "BACKFILL_HALT_STATE_CHANGED_UNEXPECTEDLY")
                    elif current_reason == previous_halt_reason:
                        pass  # Pre-existing manual/safety halt already preserved.
                    elif recovered_owned_failure_halt and current_reason == "TRADE_HISTORY_BACKFILL_IN_PROGRESS":
                        pass  # Reconciler owns this transient halt until final validation.
                    else:
                        pass  # A new safety halt takes priority over the former halt.
            if self.execution_service is not None:
                # Resolve any pending/ambiguous entry by deterministic client order ID
                # before comparing exchange state. This function never blindly resubmits.
                self.execution_service.reconcile_pending_entries()
            # Capture a stream watermark around the sequential REST snapshot. If a
            # balance/order/position event races the REST calls, this attempt cannot
            # declare READY; the account runtime will retry on its next cycle.
            stream_before_snapshot = self.ledger.get_user_stream_state()
            event_watermark = int(stream_before_snapshot.get("last_event_at_ms") or 0)
            snapshot = self.account_state.capture()
            now = self.clock_ms()
            stream_after_snapshot = self.ledger.get_user_stream_state()
            if int(stream_after_snapshot.get("last_event_at_ms") or 0) != event_watermark:
                event_during_snapshot = True
        except Exception as exc:
            failure_code = backfill_failure_code or ("ACCOUNT_HISTORY_BACKFILL_FAILED" if backfill_failure_reason else "ACCOUNT_SNAPSHOT_FAILED")
            failure_text = backfill_failure_reason or f"{type(exc).__name__}: {exc}"[:500]
            detail = {"code": failure_code, "error": failure_text}
            discrepancies.append(detail)
            already_halted, _ = self.ledger.entries_halted()
            if transient_backfill_halt or not already_halted:
                self.ledger.set_entries_halted(True, failure_code)
            if backfill_failure_reason and (transient_backfill_halt or not already_halted):
                self._trade_backfill_failure_halt_owned = True
            failure_status = failure_code if backfill_failure_reason else "CAPTURE_FAILED"
            if self.trade_risk_reconciler is not None:
                self.trade_risk_reconciler.risk_ledger.set_reconciliation(False, failure_code)
            self.ledger.set_reconciliation_state(
                False, status=failure_status, captured_at_ms=now, detail={"discrepancies": discrepancies},
            )
            return ReconciliationReport(False, failure_status, now, 0, 0, 0, 0,
                                        tuple(discrepancies), None)

        exchange_positions: dict[tuple[str, str], Decimal] = {}
        for position in snapshot.positions:
            key = (position.symbol.upper(), self._position_side(position))
            exchange_positions[key] = exchange_positions.get(key, Decimal("0")) + abs(position.quantity)
        local_rows = self.ledger.list_managed_positions(status="OPEN")
        local_positions: dict[tuple[str, str], Decimal] = {}
        local_by_key: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for row in local_rows:
            symbol = str(row["symbol"]).upper()
            side = str(row.get("signal_side") or row.get("position_side") or "BOTH").upper()
            if side == "BOTH":
                side = "LONG" if _decimal(row["quantity"], "local quantity") >= 0 else "SHORT"
            key = (symbol, side)
            local_positions[key] = local_positions.get(key, Decimal("0")) + abs(
                _decimal(row["quantity"], "local quantity")
            )
            local_by_key.setdefault(key, []).append(row)

        for key in sorted(set(exchange_positions) | set(local_positions)):
            exchange_qty = exchange_positions.get(key, Decimal("0"))
            local_qty = local_positions.get(key, Decimal("0"))
            if exchange_qty == 0:
                discrepancies.append({"code": "LOCAL_POSITION_NOT_ON_EXCHANGE",
                                       "symbol": key[0], "side": key[1],
                                       "local_quantity": str(local_qty)})
            elif local_qty == 0:
                discrepancies.append({"code": "UNMANAGED_EXCHANGE_POSITION",
                                       "symbol": key[0], "side": key[1],
                                       "exchange_quantity": str(exchange_qty)})
            elif abs(exchange_qty - local_qty) > Decimal("1e-12"):
                discrepancies.append({"code": "POSITION_QUANTITY_MISMATCH",
                                       "symbol": key[0], "side": key[1],
                                       "exchange_quantity": str(exchange_qty),
                                       "local_quantity": str(local_qty)})

        for position in snapshot.positions:
            side = self._position_side(position)
            key = (position.symbol.upper(), side)
            allocations = local_by_key.get(key, [])
            protective_orders = snapshot.open_algo_orders + snapshot.open_standard_orders
            if not allocations:
                # An unmanaged exchange position still needs operator-visible
                # protection diagnostics even though there is no signal allocation.
                direction = side
                for role in ("STOP_LOSS", "TAKE_PROFIT"):
                    expected_type = "STOP_MARKET" if role == "STOP_LOSS" else "TAKE_PROFIT_MARKET"
                    expected_side = "SELL" if direction == "LONG" else "BUY"
                    found = any(
                        str(order.get("symbol", "")).upper() == position.symbol.upper()
                        and str(order.get("positionSide", "BOTH")).upper() == str(position.position_side).upper()
                        and str(order.get("side", "")).upper() == expected_side
                        and str(order.get("type", order.get("orderType", ""))).upper() == expected_type
                        and str(order.get("algoStatus", order.get("status", "NEW"))).upper()
                            in {"NEW", "PENDING_NEW", "WORKING", "PENDING", "PARTIALLY_FILLED"}
                        for order in protective_orders
                    )
                    if not found:
                        discrepancies.append({"code": "POSITION_MISSING_PROTECTION",
                                               "symbol": position.symbol, "side": side, "role": role})
                continue
            # Validate protection against every durable signal allocation, not merely
            # the existence of any STOP/TP on the exchange for the aggregate side.
            for allocation in allocations:
                signal_id = str(allocation["signal_id"])
                state_row = self.ledger.get_position_management_state(signal_id)
                state = state_row.get("state", {}) if state_row else {}
                dual_side = str(allocation.get("position_side", "BOTH")).upper() in {"LONG", "SHORT"}
                for role in ("STOP_LOSS", "TAKE_PROFIT"):
                    if role == "STOP_LOSS":
                        algo_client_id = str(
                            state.get("stop_algo_client_id")
                            or self.ledger.deterministic_client_id(signal_id, role)
                        )
                    else:
                        algo_client_id = str(
                            state.get("take_profit_algo_client_id")
                            or self.ledger.deterministic_client_id(signal_id, role)
                        )
                    expected_trigger = _decimal(
                        (state.get("current_stop") if role == "STOP_LOSS" else allocation.get("take_profit"))
                        or (allocation.get("stop_loss") if role == "STOP_LOSS" else allocation.get("take_profit")),
                        f"{role.lower()}_trigger_price",
                    )
                    if not self._has_protection(
                        protective_orders,
                        symbol=position.symbol.upper(),
                        position_side=str(allocation.get("position_side", "BOTH")).upper(),
                        position_direction=str(allocation.get("signal_side", side)).upper(),
                        role=role,
                        expected_quantity=_decimal(allocation["quantity"], "local protection quantity"),
                        client_algo_id=algo_client_id,
                        dual_side_position=dual_side,
                        allow_legacy_close_position=len(allocations) == 1,
                        expected_trigger_price=expected_trigger,
                    ):
                        discrepancies.append({"code": "POSITION_MISSING_PROTECTION",
                                               "symbol": position.symbol, "side": side,
                                               "signal_id": signal_id, "role": role})

        # Open exchange orders without local intent IDs are retained as discrepancies
        # only when they appear to be DIVATrading-owned orders; manual discretionary
        # orders are reported separately by downstream monitoring, not auto-cancelled.
        intents = self.ledger.list_all_intents()
        known_client_ids = {str(row["client_order_id"]) for row in intents}
        known_algo_ids = {
            self.ledger.deterministic_client_id(row["signal_id"], role)
            for row in intents for role in ("STOP_LOSS", "TAKE_PROFIT")
        }
        # Trailing-stop and Stage D recovery identifiers replace the original
        # deterministic entry protection IDs; the durable state/action ledger owns them.
        for row in self.ledger.list_managed_positions(status=None):
            state_row = self.ledger.get_position_management_state(str(row["signal_id"]))
            if state_row is not None:
                for field in ("stop_algo_client_id", "take_profit_algo_client_id"):
                    value = state_row["state"].get(field)
                    if value:
                        known_algo_ids.add(str(value))
        for action in self.ledger.list_position_management_actions():
            payload = action.get("payload", {})
            for field in ("source_client_algo_id", "replacement_client_algo_id",
                          "client_algo_id", "old_client_algo_id", "new_stop_client_algo_id",
                          "new_take_client_algo_id", "old_stop_client_algo_id", "old_take_client_algo_id"):
                value = payload.get(field)
                if value:
                    known_algo_ids.add(str(value))
        for order in snapshot.open_standard_orders:
            client_id = str(order.get("clientOrderId", ""))
            if client_id.startswith("DIVA") and client_id not in known_client_ids:
                discrepancies.append({"code": "ORPHAN_DIVA_ORDER", "symbol": order.get("symbol"),
                                      "client_order_id": client_id})
        for order in snapshot.open_algo_orders:
            client_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
            if client_id.startswith(("DIVASL", "DIVATP")) and client_id not in known_algo_ids:
                discrepancies.append({"code": "ORPHAN_DIVA_ALGO_ORDER", "symbol": order.get("symbol"),
                                      "client_algo_id": client_id})

        open_orders_by_client_id = {
            str(order.get("clientOrderId", "")) for order in snapshot.open_standard_orders
        }
        for intent in intents:
            if intent["status"] in {"ENTRY_PENDING", "SUBMISSION_UNKNOWN"}:
                if intent["client_order_id"] not in open_orders_by_client_id:
                    discrepancies.append({"code": "PENDING_ENTRY_ORDER_NOT_FOUND",
                                          "symbol": intent["symbol"],
                                          "signal_id": intent["signal_id"],
                                          "status": intent["status"]})
            elif intent["status"] == "PROTECTION_INCOMPLETE":
                discrepancies.append({"code": "LOCAL_INTENT_UNPROTECTED",
                                      "symbol": intent["symbol"],
                                      "signal_id": intent["signal_id"]})
        known_intent_ids = {row["signal_id"] for row in intents}
        for reservation in self.ledger.active_risk_reservations():
            if reservation["signal_id"] not in known_intent_ids:
                discrepancies.append({"code": "ORPHAN_ACTIVE_RISK_RESERVATION",
                                      "signal_id": reservation["signal_id"],
                                      "symbol": reservation["symbol"]})

        if self.trade_risk_reconciler is not None:
            if discrepancies or event_during_snapshot:
                self.trade_risk_reconciler.risk_ledger.set_reconciliation(
                    False, "ACCOUNT_RECONCILIATION_NOT_CLEAN_OR_STREAM_EVENT_RACE",
                )
            else:
                risk_ready, risk_reason = self.trade_risk_reconciler.reconcile()
                if not risk_ready:
                    discrepancies.append({"code": "TRADE_RISK_LEDGER_NOT_READY",
                                          "reason": risk_reason or "UNKNOWN"})

        classified_discrepancies = [
            {**item, "policy": classify_discrepancy(str(item.get("code", "UNKNOWN"))).category,
             "halt_management": classify_discrepancy(str(item.get("code", "UNKNOWN"))).halt_management,
             "operator_action_required": classify_discrepancy(str(item.get("code", "UNKNOWN"))).operator_action_required}
            for item in discrepancies
        ]
        if event_during_snapshot:
            classified_discrepancies.append({"code": "EVENT_DURING_SNAPSHOT",
                                             "policy": "RECOVERABLE",
                                             "halt_management": False,
                                             "operator_action_required": False})
        if discrepancies:
            self.ledger.set_entries_halted(True, "ACCOUNT_RECONCILIATION_MISMATCH")
            status = "BLOCKED_MISMATCH"
            ready = False
        elif transient_backfill_halt:
            # Clear only the temporary halt introduced by this successful backfill.
            # Existing operator/safety halts are never cleared by reconciliation.
            transient_cleared = self.ledger.clear_entries_halt_if_reason(
                "TRADE_HISTORY_BACKFILL_IN_PROGRESS"
            )
            if not transient_cleared:
                # Another safety/kill-switch halt was installed while REST
                # snapshot I/O ran. Never declare readiness or clear that halt.
                status = "ENTRIES_HALTED_DURING_BACKFILL"
                ready = False
            elif event_during_snapshot:
                status = "EVENT_DURING_RECONCILIATION"
                ready = False
            else:
                status = "READY"
                ready = True
        elif event_during_snapshot:
            # A racing event invalidates this sequential snapshot but is transient;
            # keep the existing entry-halt control unchanged and retry next cycle.
            status = "EVENT_DURING_RECONCILIATION"
            ready = False
        else:
            halted, _ = self.ledger.entries_halted()
            ready = not halted and not event_during_snapshot
            if event_during_snapshot:
                status = "EVENT_DURING_RECONCILIATION"
            else:
                status = "READY" if ready else "ENTRIES_HALTED"
        self.ledger.set_reconciliation_state(
            ready, status=status, captured_at_ms=now,
            detail={"discrepancies": classified_discrepancies,
                    "exchange_position_count": len(exchange_positions),
                    "local_position_count": len(local_positions),
                    "open_standard_order_count": len(snapshot.open_standard_orders),
                    "open_algo_order_count": len(snapshot.open_algo_orders),
                    "snapshot_is_sequential_rest": True,
                    "event_during_snapshot": event_during_snapshot,
                    "stream_event_watermark_ms": event_watermark},
            stream_event_watermark_ms=event_watermark,
        )
        persisted = self.ledger.get_reconciliation_state()
        ready = bool(persisted.get("ready"))
        status = str(persisted.get("status", status))
        return ReconciliationReport(
            ready, status, now, len(exchange_positions), len(local_positions),
            len(snapshot.open_standard_orders), len(snapshot.open_algo_orders),
            tuple(discrepancies), snapshot,
        )
