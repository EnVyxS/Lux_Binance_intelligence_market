"""Exchange-truth USD-M Futures account and portfolio snapshots."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Protocol


class AccountClient(Protocol):
    def get_exchange_account(self) -> dict[str, Any]: ...
    def get_position_risk(self, symbol: str | None = None) -> list[dict[str, Any]]: ...
    def get_open_orders(self, symbol: str | None = None) -> list[dict[str, Any]]: ...
    def get_open_algo_orders(self, symbol: str | None = None) -> list[dict[str, Any]]: ...


def _d(value: Any, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError(f"Invalid Binance numeric field: {field}") from exc
    if not result.is_finite():
        raise ValueError(f"Non-finite Binance numeric field: {field}")
    return result


@dataclass(frozen=True, slots=True)
class PositionSnapshot:
    symbol: str
    position_side: str
    quantity: Decimal
    entry_price: Decimal
    mark_price: Decimal
    unrealized_pnl: Decimal
    notional: Decimal
    isolated: bool


@dataclass(frozen=True, slots=True)
class AccountSnapshot:
    wallet_balance: Decimal
    equity: Decimal
    available_balance: Decimal
    margin_balance: Decimal
    open_risk_usdt: Decimal
    positions: tuple[PositionSnapshot, ...]
    open_standard_orders: tuple[dict[str, Any], ...]
    open_algo_orders: tuple[dict[str, Any], ...]

    @property
    def active_position_count(self) -> int:
        return sum(1 for p in self.positions if p.quantity != 0)

    def symbol_notional(self, symbol: str) -> Decimal:
        return sum((abs(p.notional) for p in self.positions if p.symbol == symbol), Decimal("0"))


class BinanceAccountStateService:
    """Fetches one exchange-truth snapshot; partial fetches fail closed."""
    def __init__(self, client: AccountClient) -> None:
        self.client = client

    def capture(self) -> AccountSnapshot:
        account = self.client.get_exchange_account()
        raw_positions = self.client.get_position_risk()
        standard = self.client.get_open_orders()
        algo = self.client.get_open_algo_orders()
        positions: list[PositionSnapshot] = []
        for row in raw_positions:
            qty = _d(row.get("positionAmt", "0"), "positionAmt")
            if qty == 0:
                continue
            positions.append(PositionSnapshot(
                symbol=str(row["symbol"]),
                position_side=str(row.get("positionSide", "BOTH")),
                quantity=qty,
                entry_price=_d(row.get("entryPrice", "0"), "entryPrice"),
                mark_price=_d(row.get("markPrice", "0"), "markPrice"),
                unrealized_pnl=_d(row.get("unRealizedProfit", "0"), "unRealizedProfit"),
                notional=_d(row.get("notional", "0"), "notional"),
                isolated=str(row.get("isolated", "false")).lower() == "true",
            ))
        # Binance account response exposes wallet, margin and available balances.
        wallet = _d(account.get("totalWalletBalance"), "totalWalletBalance")
        margin = _d(account.get("totalMarginBalance"), "totalMarginBalance")
        available = _d(account.get("availableBalance"), "availableBalance")
        # Exchange position risk provides unrealized PnL and notional, not a guaranteed
        # stop-loss risk. Until every position has a verified protective stop, fail closed
        # by treating its absolute notional as the conservative open-risk reservation.
        open_risk = sum((abs(p.notional) for p in positions), Decimal("0"))
        return AccountSnapshot(wallet, margin, available, margin, open_risk,
                               tuple(positions), tuple(standard), tuple(algo))
