"""Reconcile completed managed lifecycles and account income into risk controls."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any
from zoneinfo import ZoneInfo

from .ledger import ExecutionLedger
from .trade_risk_ledger import CompletedTradeRiskLedger

JAKARTA = ZoneInfo("Asia/Jakarta")
_USDT_PNL_TYPES = {"REALIZED_PNL", "COMMISSION", "FUNDING_FEE"}
_SUPPORTED_INCOME_TYPES = _USDT_PNL_TYPES | {"TRANSFER"}


def _decimal(value: Any, label: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise RuntimeError(f"{label}_INVALID") from exc
    if not result.is_finite():
        raise RuntimeError(f"{label}_NON_FINITE")
    return result


def _aware(value: Any, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label}_TIMESTAMP_INVALID") from exc
    if parsed.tzinfo is None:
        raise RuntimeError(f"{label}_TIMESTAMP_NAIVE")
    return parsed.astimezone(UTC)


def derive_day_start_equity(*, flow_neutral_current_equity: Decimal,
                            daily_realized_net_pnl: Decimal,
                            current_floating_pnl: Decimal) -> Decimal:
    """Reconstruct Jakarta day-start equity when runtime starts mid-session.

    Current margin balance includes current floating PnL and account income already
    realized during the trading day. Cash transfers are removed separately by the
    caller. Unknown income types must be rejected before using this estimate.
    """
    values = (flow_neutral_current_equity, daily_realized_net_pnl, current_floating_pnl)
    if any(not value.is_finite() for value in values):
        raise ValueError("day-start equity inputs must be finite")
    result = flow_neutral_current_equity - daily_realized_net_pnl - current_floating_pnl
    if result <= 0:
        raise RuntimeError("DAY_START_EQUITY_RECONSTRUCTION_NON_POSITIVE")
    return result


class CompletedTradeRiskReconciler:
    """Build idempotent closed-trade results from attributed fills and funding rows.

    Funding is allocated to active managed lots proportionally to their open notional
    at the funding timestamp. If an event cannot be uniquely reconciled (unowned fill,
    multiple hedge sides, unknown commission asset, missing lifecycle fill history),
    risk-ledger readiness remains false and new entries must stay blocked.
    """
    def __init__(self, *, execution_ledger: ExecutionLedger,
                 risk_ledger: CompletedTradeRiskLedger) -> None:
        self.execution_ledger = execution_ledger
        self.risk_ledger = risk_ledger

    @staticmethod
    def _funding_allocations(positions: list[dict[str, Any]], fills_by_signal: dict[str, list[dict[str, Any]]],
                             income_rows: list[dict[str, Any]]) -> dict[str, Decimal]:
        allocated: dict[str, Decimal] = {}
        for row in income_rows:
            if str(row.get("income_type", "")).upper() != "FUNDING_FEE":
                continue
            if str(row.get("asset", "")).upper() != "USDT":
                raise RuntimeError("FUNDING_ASSET_NOT_USDT_REQUIRES_CONVERSION")
            amount = _decimal(row.get("income"), "FUNDING_INCOME")
            symbol = str(row.get("symbol", "")).upper()
            stamp = int(row.get("time_ms", 0))
            active: list[tuple[str, Decimal]] = []
            active_sides: set[str] = set()
            for position in positions:
                if str(position.get("symbol", "")).upper() != symbol:
                    continue
                opened = _aware(position.get("opened_at_utc"), "POSITION_OPENED_AT")
                closed = _aware(position.get("updated_at_utc"), "POSITION_UPDATED_AT")
                opened_ms = int(opened.timestamp() * 1000)
                closed_ms = int(closed.timestamp() * 1000) if str(position.get("status", "")).upper() == "CLOSED" else 2**63 - 1
                if not opened_ms <= stamp <= closed_ms:
                    continue
                signal_id = str(position["signal_id"])
                fills = fills_by_signal.get(signal_id, [])
                qty = Decimal("0")
                entry_qty = Decimal("0")
                for fill in fills:
                    if int(fill.get("event_time_ms", 0)) > stamp:
                        continue
                    q = _decimal(fill.get("quantity"), "FUNDING_FILL_QTY")
                    price = _decimal(fill.get("price"), "FUNDING_FILL_PRICE")
                    effect = str(fill.get("effect", "")).upper()
                    if effect == "OPEN":
                        qty += q
                        entry_qty += q
                    elif effect == "CLOSE":
                        qty -= q
                    else:
                        raise RuntimeError("FUNDING_FILL_EFFECT_UNKNOWN")
                    if qty < Decimal("-1e-12"):
                        raise RuntimeError("FUNDING_FILL_SEQUENCE_NEGATIVE")
                if qty > Decimal("1e-12") and entry_qty > 0:
                    # Contract quantity is used for allocation: every lot in the same
                    # symbol/position side shares the same funding mark-price factor.
                    active.append((signal_id, qty))
                    active_sides.add(str(position.get("position_side", "BOTH")).upper())
            if not active:
                raise RuntimeError(f"FUNDING_EVENT_WITHOUT_ATTRIBUTED_POSITION:{symbol}:{stamp}")
            if len(active_sides) != 1:
                raise RuntimeError(f"FUNDING_EVENT_HEDGE_SIDE_AMBIGUOUS:{symbol}:{stamp}")
            total = sum((notional for _, notional in active), Decimal("0"))
            if total <= 0:
                raise RuntimeError("FUNDING_ACTIVE_NOTIONAL_INVALID")
            remaining = amount
            for index, (signal_id, notional) in enumerate(active):
                piece = remaining if index == len(active) - 1 else amount * notional / total
                allocated[signal_id] = allocated.get(signal_id, Decimal("0")) + piece
                remaining -= piece
        return allocated

    def reconcile(self, *, now: datetime | None = None) -> tuple[bool, str | None]:
        current = now or datetime.now(UTC)
        if current.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        try:
            projections = self.execution_ledger.apply_position_fill_allocations()
            del projections
            counts = self.execution_ledger.position_fill_allocation_counts()
            if counts.get("UNATTRIBUTED", 0) or counts.get("EXTERNAL", 0):
                raise RuntimeError("UNATTRIBUTED_OR_EXTERNAL_FILL_PRESENT")
            positions = self.execution_ledger.list_managed_positions(status=None)
            for position in positions:
                if str(position.get("status", "")).upper() not in {"OPEN", "CLOSED"}:
                    raise RuntimeError(f"MANAGED_POSITION_STATUS_UNSUPPORTED:{position.get('signal_id')}:{position.get('status')}")
            fills = self.execution_ledger.list_position_fill_allocations(allocation_status="ATTRIBUTED")
            fills_by_signal: dict[str, list[dict[str, Any]]] = {}
            for fill in fills:
                fills_by_signal.setdefault(str(fill["signal_id"]), []).append(fill)
            income_rows = self.execution_ledger.list_income_rows()
            funding = self._funding_allocations(positions, fills_by_signal, income_rows)
            for position in positions:
                if str(position.get("status", "")).upper() != "CLOSED":
                    continue
                signal_id = str(position["signal_id"])
                if self.risk_ledger.has_lifecycle(signal_id):
                    continue
                projection = self.execution_ledger.get_position_fill_projection(signal_id)
                if projection is None:
                    raise RuntimeError(f"CLOSED_POSITION_FILL_PROJECTION_MISSING:{signal_id}")
                if abs(_decimal(projection.get("net_quantity"), "NET_QUANTITY")) > Decimal("1e-12"):
                    raise RuntimeError(f"CLOSED_POSITION_FILL_QUANTITY_NOT_FLAT:{signal_id}")
                commissions = projection.get("commissions", {})
                non_usdt = {asset: amount for asset, amount in commissions.items()
                            if str(asset).upper() != "USDT" and _decimal(amount, "COMMISSION") != 0}
                if non_usdt:
                    raise RuntimeError(f"NON_USDT_COMMISSION_REQUIRES_CONVERSION:{signal_id}")
                realized = projection.get("realized_pnl", {})
                realized_usdt = _decimal(realized.get("USDT", "0"), "REALIZED_PNL")
                fee_usdt = _decimal(commissions.get("USDT", "0"), "COMMISSION")
                if fee_usdt < 0:
                    raise RuntimeError(f"COMMISSION_SIGN_INVALID:{signal_id}")
                closed_at = _aware(position.get("updated_at_utc"), "POSITION_CLOSED_AT")
                self.risk_ledger.record_completed_lifecycle(
                    lifecycle_id=signal_id,
                    symbol=str(position["symbol"]),
                    closed_at=closed_at,
                    realized_pnl=realized_usdt,
                    commission=fee_usdt,
                    funding=funding.get(signal_id, Decimal("0")),
                )
            # Daily realized results are sourced from the exchange income ledger.
            # Any unsupported fee/funding asset prevents claiming a complete USDT PnL.
            for item in income_rows:
                kind = str(item.get("income_type", "")).upper()
                amount = _decimal(item.get("income", "0"), "INCOME")
                asset = str(item.get("asset", "")).upper()
                if amount == 0:
                    continue
                if kind not in _SUPPORTED_INCOME_TYPES:
                    raise RuntimeError(f"UNSUPPORTED_NONZERO_INCOME_TYPE:{kind}")
                if asset != "USDT":
                    raise RuntimeError(f"NON_USDT_INCOME_REQUIRES_CONVERSION:{kind}:{asset}")
            self.risk_ledger.set_reconciliation(True)
            return True, None
        except Exception as exc:
            reason = f"{type(exc).__name__}:{exc}"[:500]
            self.risk_ledger.set_reconciliation(False, reason)
            return False, reason

    def daily_realized_net_pnl(self, now: datetime | None = None) -> Decimal:
        current = now or datetime.now(UTC)
        if current.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        local_start = current.astimezone(JAKARTA).replace(hour=0, minute=0, second=0, microsecond=0)
        start_ms = int(local_start.astimezone(UTC).timestamp() * 1000)
        end_ms = int(current.astimezone(UTC).timestamp() * 1000)
        rows = self.execution_ledger.list_income_rows(start_time_ms=start_ms, end_time_ms=end_ms)
        total = Decimal("0")
        for item in rows:
            if str(item.get("income_type", "")).upper() not in _USDT_PNL_TYPES:
                continue
            if str(item.get("asset", "")).upper() != "USDT":
                if _decimal(item.get("income", "0"), "INCOME") != 0:
                    raise RuntimeError("DAILY_PNL_NON_USDT_ASSET_REQUIRES_CONVERSION")
                continue
            total += _decimal(item.get("income"), "DAILY_INCOME")
        return total

    def transfer_adjustment_usdt(self) -> Decimal:
        total = Decimal("0")
        for item in self.execution_ledger.list_income_rows():
            if str(item.get("income_type", "")).upper() == "TRANSFER" and str(item.get("asset", "")).upper() == "USDT":
                total += _decimal(item.get("income"), "TRANSFER_INCOME")
        return total
