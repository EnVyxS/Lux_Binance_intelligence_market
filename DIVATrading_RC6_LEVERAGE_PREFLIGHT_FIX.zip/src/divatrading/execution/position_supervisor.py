"""Continuous, multi-symbol managed-position supervisor.

The supervisor consumes validated Binance Mark Price events, evaluates durable
position state, and delegates every exchange mutation to the fail-closed lifecycle
execution adapter. Feed and exchange I/O are isolated per symbol; the SQLite ledger
remains authoritative across reconnects and process restarts.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import time
from dataclasses import asdict, dataclass, fields, replace
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
from typing import Any, Callable, Mapping

from divatrading.execution.near_tp_protection import NearTakeProfitProtection
from divatrading.execution.position_lifecycle import (
    LifecycleAction,
    ManagedPositionState,
    PositionLifecycleEngine,
)
from divatrading.execution.position_accounting import build_position_groups
from divatrading.strategy.scalping_market_data import ScalpingMarketDataView


@dataclass(frozen=True, slots=True)
class PositionSupervisorConfig:
    refresh_interval_seconds: float = 2.0
    worker_restart_seconds: float = 3.0
    event_poll_seconds: float = 0.5
    max_mark_age_ms: int = 5_000
    max_active_symbols: int = 16
    early_exit_protection: bool = False

    def __post_init__(self) -> None:
        for name in ("refresh_interval_seconds", "worker_restart_seconds", "event_poll_seconds"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                raise ValueError(f"{name} must be positive")
        if isinstance(self.max_mark_age_ms, bool) or self.max_mark_age_ms < 1_000:
            raise ValueError("max_mark_age_ms must be >= 1000")
        if not 1 <= self.max_active_symbols <= 24:
            raise ValueError("max_active_symbols must be between 1 and 24")
        if not isinstance(self.early_exit_protection, bool):
            raise ValueError("early_exit_protection must be boolean")


@dataclass(frozen=True, slots=True)
class PositionSupervisorSymbolStatus:
    symbol: str
    status: str
    event_count: int
    last_event_at_ms: int | None
    last_error: str | None


class ManagedPositionSupervisor:
    """Run one bounded Mark Price worker per symbol with durable action dispatch."""

    PENDING_ACTION_STATUSES = (
        "PLANNED", "SUBMITTING", "SUBMITTED", "SUBMISSION_UNKNOWN",
        "PARTIALLY_FILLED", "REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
        "STOP_TRIGGERED_PENDING_RECONCILIATION", "STOP_TRIGGERED_POSITION_NOT_FLAT",
        "STOP_REPLACEMENT_POSITION_MISMATCH", "PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
        "LOT_FINALIZATION_PENDING", "EXIT_PENDING",
    )

    def __init__(
        self,
        *,
        ledger: Any,
        adapter: Any,
        filter_provider: Callable[[str], Mapping[str, Decimal]],
        feed_factory: Callable[[str], Any],
        engine: PositionLifecycleEngine | None = None,
        config: PositionSupervisorConfig | None = None,
        clock_ms: Callable[[], int] | None = None,
    ) -> None:
        self.ledger = ledger
        self.adapter = adapter
        self.filter_provider = filter_provider
        self.feed_factory = feed_factory
        self.engine = engine or PositionLifecycleEngine()
        self.config = config or PositionSupervisorConfig()
        self._clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._near_target = NearTakeProfitProtection() if self.config.early_exit_protection else None
        self._workers: dict[str, asyncio.Task[None]] = {}
        self._worker_started: dict[str, float] = {}
        self._busy_symbols: set[str] = set()
        self._statuses: dict[str, PositionSupervisorSymbolStatus] = {}
        self._stop = asyncio.Event()
        self._running = False

    @property
    def snapshot(self) -> tuple[PositionSupervisorSymbolStatus, ...]:
        return tuple(self._statuses[key] for key in sorted(self._statuses))

    def observe_market(self, view: ScalpingMarketDataView) -> None:
        """Cache public evidence; exchange actions are owned by the Mark worker."""
        if self._near_target is not None:
            self._near_target.observe(view, int(self._clock_ms()))

    @staticmethod
    def _serialize_state(state: ManagedPositionState) -> dict[str, Any]:
        result = asdict(state)
        for item in fields(state):
            value = result[item.name]
            if isinstance(value, Decimal):
                result[item.name] = str(value)
        return result

    @staticmethod
    def _round_stop(price: Decimal, tick: Decimal, side: str) -> Decimal:
        if tick <= 0:
            raise ValueError("tick_size must be positive")
        rounding = ROUND_DOWN if side == "LONG" else ROUND_UP
        return (price / tick).to_integral_value(rounding=rounding) * tick

    def _halt(self, symbol: str, reason: str) -> None:
        detail = reason[:500]
        self.ledger.set_entries_halted(True, f"POSITION_SUPERVISOR:{symbol}:{detail}")
        self.ledger.record_event(
            "POSITION_SUPERVISOR_SAFETY_HALT", symbol=symbol,
            detail={"reason": detail},
        )

    def _active_symbols(self) -> tuple[str, ...]:
        rows = self.ledger.list_managed_positions(status="OPEN")
        symbols = sorted({str(row["symbol"]).upper() for row in rows})
        if len(symbols) > self.config.max_active_symbols:
            self._halt("GLOBAL", f"Active managed symbols {len(symbols)} exceed supervisor cap {self.config.max_active_symbols}")
            return tuple(symbols[:self.config.max_active_symbols])
        # Multiple independently managed lots may share a symbol/positionSide.
        # Validate the group before starting its worker; inconsistent directions,
        # quantities or identity fail closed rather than being treated as scale-in.
        try:
            build_position_groups(rows)
        except Exception as exc:
            self._halt("GLOBAL", f"INVALID_MANAGED_POSITION_GROUP:{type(exc).__name__}:{exc}")
            invalid_symbols = {str(row["symbol"]).upper() for row in rows}
            symbols = [item for item in symbols if item not in invalid_symbols]
        return tuple(symbols)

    async def _refresh_workers(self) -> None:
        symbols = set(await asyncio.to_thread(self._active_symbols))
        for symbol in tuple(self._workers):
            if symbol not in symbols and symbol not in self._busy_symbols:
                task = self._workers.pop(symbol)
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
                prior = self._statuses.get(symbol)
                if prior is not None:
                    self._set_status(symbol, "STOPPED", prior.event_count,
                                     prior.last_event_at_ms, prior.last_error)
                self._worker_started.pop(symbol, None)
        for symbol in sorted(symbols):
            if symbol not in self._workers:
                self._set_status(symbol, "STARTING", 0, None, None)
                self._worker_started[symbol] = time.monotonic()
                self._workers[symbol] = asyncio.create_task(
                    self._symbol_worker(symbol), name=f"diva:position:{symbol}"
                )

    async def run(self, stop_event: asyncio.Event | None = None) -> None:
        if self._running:
            raise RuntimeError("managed-position supervisor is already running")

        self._running = True
        external = stop_event or asyncio.Event()

        try:
            while not external.is_set() and not self._stop.is_set():
                await self._refresh_workers()

                try:
                    await asyncio.wait_for(
                        external.wait(),
                        timeout=self.config.refresh_interval_seconds,
                    )
                except asyncio.TimeoutError:
                    pass
        finally:
            # Request graceful shutdown. Workers finish any in-flight
            # asyncio.to_thread processing before leaving their event loops.
            self._stop.set()

            tasks = tuple(self._workers.values())

            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

            self._workers.clear()
            self._running = False

    async def stop(self) -> None:
        self._stop.set()

        tasks = tuple(self._workers.values())

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        self._workers.clear()

    async def _symbol_worker(self, symbol: str) -> None:
        events = 0
        last_event: int | None = None
        last_monotonic: float | None = None
        last_error: str | None = None
        while not self._stop.is_set():
            local_stop = asyncio.Event()
            feed_task: asyncio.Task[Any] | None = None
            feed_started_monotonic = time.monotonic()
            last_monotonic = None
            try:
                feed = self.feed_factory(symbol)
                if inspect.isawaitable(feed):
                    feed = await feed
                if not callable(getattr(feed, "run", None)) or not callable(getattr(feed, "get_event", None)):
                    raise TypeError("Mark Price feed must expose run(stop_event) and get_event()")
                feed_task = asyncio.create_task(feed.run(local_stop), name=f"diva:mark:{symbol}")
                self._set_status(symbol, "RUNNING", events, last_event, None)
                while not self._stop.is_set():
                    if feed_task.done():
                        error = feed_task.exception()
                        if error is not None:
                            raise RuntimeError(f"Mark Price feed terminated: {error}") from error
                        raise RuntimeError("Mark Price feed stopped unexpectedly")
                    try:
                        event = await asyncio.wait_for(
                            feed.get_event(), timeout=self.config.event_poll_seconds
                        )
                    except asyncio.TimeoutError:
                        if (last_monotonic is None and
                                time.monotonic() - feed_started_monotonic > self.config.max_mark_age_ms / 1000):
                            raise RuntimeError("MARK_PRICE_NOT_RECEIVED_WITHIN_FRESHNESS_WINDOW")
                        if (last_monotonic is not None and
                                time.monotonic() - last_monotonic > self.config.max_mark_age_ms / 1000):
                            raise RuntimeError("MARK_PRICE_STALE: no fresh update within configured window")
                        continue
                    received_now = int(self._clock_ms())
                    event_symbol = str(getattr(event, "symbol", "")).upper()
                    event_time = getattr(event, "event_time_ms", None)
                    mark = getattr(event, "mark_price", None)
                    if event_symbol != symbol or not isinstance(event_time, int) or mark is None:
                        raise ValueError("Malformed or cross-symbol Mark Price event")
                    age = received_now - event_time
                    if age < -2_000 or age > self.config.max_mark_age_ms:
                        raise RuntimeError(f"MARK_PRICE_STALE_OR_FUTURE:event_age_ms={age}")
                    self._busy_symbols.add(symbol)
                    try:
                        await asyncio.to_thread(self._process_mark_event, event)
                    finally:
                        self._busy_symbols.discard(symbol)
                    events += 1
                    last_event = event_time
                    last_monotonic = time.monotonic()
                    self._set_status(symbol, "RUNNING", events, last_event, None)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"[:500]
                self._halt(symbol, last_error)
                self._set_status(symbol, "DEGRADED", events, last_event, last_error)
            finally:
                local_stop.set()
                if feed_task is not None:
                    try:
                        await feed_task
                    except asyncio.CancelledError:
                        pass
                    except Exception:
                        pass
            if not self._stop.is_set():
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=self.config.worker_restart_seconds)
                except asyncio.TimeoutError:
                    self._worker_started[symbol] = time.monotonic()
                    continue
        self._set_status(symbol, "STOPPED", events, last_event, last_error)

    def _set_status(self, symbol: str, status: str, events: int,
                    last_event_at_ms: int | None, error: str | None) -> None:
        self._statuses[symbol] = PositionSupervisorSymbolStatus(
            symbol, status, events, last_event_at_ms, error
        )

    def _process_mark_event(self, event: Any) -> list[dict[str, Any]]:
        symbol = str(event.symbol).upper()
        rows = [row for row in self.ledger.list_managed_positions(status="OPEN")
                if str(row["symbol"]).upper() == symbol]
        by_position: dict[str, list[dict[str, Any]]] = {}
        for row in rows:
            by_position.setdefault(str(row["position_side"]).upper(), []).append(row)
        results: list[dict[str, Any]] = []
        for position_side, managed_rows in by_position.items():
            try:
                group = build_position_groups(managed_rows)
            except Exception as exc:
                self._halt(symbol, f"INVALID_MANAGED_POSITION_GROUP:{position_side}:{exc}")
                results.append({"position_side": position_side, "status": "INVALID_POSITION_GROUP"})
                continue
            ordered_rows = sorted(
                managed_rows,
                key=lambda item: (str(item.get("opened_at_utc", "")), str(item["signal_id"])),
            )
            # A symbol/positionSide has one exchange quantity. Serialize lifecycle
            # mutations across all its lots; if any action is pending, reconcile it
            # before evaluating another lot on this event.
            group_pending: list[dict[str, Any]] = []
            for lot_row in ordered_rows:
                group_pending.extend(self.ledger.list_position_management_actions(
                    signal_id=str(lot_row["signal_id"]), statuses=self.PENDING_ACTION_STATUSES,
                ))
            if group_pending:
                action = sorted(group_pending, key=lambda item: (item["created_at_utc"], item["action_id"]))[0]
                try:
                    reconciled = self.adapter.reconcile_action(action["action_id"])
                except Exception as exc:
                    self._halt(symbol, f"PENDING_GROUP_ACTION_RECONCILIATION_FAILED:{action['action_id']}:{exc}")
                    results.append({"position_side": position_side, "action_id": action["action_id"],
                                    "status": "PENDING_ACTION_ERROR"})
                else:
                    results.append({"signal_id": action["signal_id"], "action_id": action["action_id"],
                                    **reconciled})
                # Never evaluate/dispatch a new action during the same event as a
                # pending or just-reconciled aggregate-position action.
                continue
            for row in ordered_rows:
                signal_id = str(row["signal_id"])
                # Re-read each lot just before evaluation because an earlier lot's
                # confirmed action can change aggregate exchange quantity.
                fresh_row = next((item for item in self.ledger.list_managed_positions(status="OPEN")
                                  if str(item["signal_id"]) == signal_id), None)
                if fresh_row is None:
                    continue
                reservation = self.ledger.get_risk_reservation(signal_id)
                if reservation is None or reservation.get("status") != "ACTIVE":
                    self._halt(symbol, f"MANAGED_POSITION_WITHOUT_ACTIVE_RISK_RESERVATION:{signal_id}")
                    results.append({"signal_id": signal_id, "status": "RESERVATION_NOT_ACTIVE"})
                    break
                state_row = self.ledger.get_position_management_state(signal_id)
                if state_row is None:
                    self._halt(symbol, f"MISSING_POSITION_MANAGEMENT_STATE:{signal_id}")
                    results.append({"signal_id": signal_id, "status": "STATE_MISSING"})
                    break
                if state_row["state"].get("closed"):
                    continue
                state = self.adapter.load_state(signal_id)
                decision = self.engine.evaluate(state, event.mark_price)
                updated = dict(state_row["state"])
                updated.update(self._serialize_state(decision.proposed_state))
                try:
                    self.ledger.save_position_management_state(
                        signal_id=signal_id, symbol=symbol, state=updated,
                        expected_version=int(state_row["version"]),
                    )
                except Exception as exc:
                    self._halt(symbol, f"POSITION_STATE_CAS_CONFLICT:{signal_id}:{exc}")
                    results.append({"signal_id": signal_id, "status": "STATE_CONFLICT"})
                    break
                actions = decision.actions
                if not actions:
                    early_exit = self._near_target_exit(state, fresh_row, event)
                    if early_exit is not None:
                        actions = (early_exit,)
                for action in actions:
                    try:
                        current_state = self.adapter.load_state(signal_id)
                        if action.kind == "PARTIAL_TP":
                            rules = self._rules(symbol)
                            submitted = self.adapter.submit_partial_take_profit(
                                action, current_state,
                                market_step_size=rules["market_step_size"],
                                market_min_qty=rules["market_min_qty"],
                            )
                            if submitted.get("status") == "SUBMITTED":
                                outcome = self.adapter.confirm_partial_take_profit(action.action_id)
                            else:
                                outcome = submitted
                        elif action.kind == "MOVE_STOP":
                            rules = self._rules(symbol)
                            stop_price = self._round_stop(
                                action.stop_price, rules["tick_size"], action.side
                            )
                            improves = (stop_price > current_state.current_stop if action.side == "LONG"
                                        else stop_price < current_state.current_stop)
                            if not improves:
                                self.ledger.record_event(
                                    "POSITION_LIFECYCLE_STOP_ROUNDED_NO_IMPROVEMENT",
                                    signal_id=signal_id, symbol=symbol,
                                    detail={"requested_stop": str(action.stop_price),
                                            "rounded_stop": str(stop_price)},
                                )
                                continue
                            aligned_action = replace(action, stop_price=stop_price)
                            outcome = self.adapter.replace_stop(
                                aligned_action, current_state,
                                tick_size=rules["tick_size"], mark_price=event.mark_price,
                                old_client_algo_id=str(self.ledger.get_position_management_state(signal_id)["state"].get("stop_algo_client_id", "")) or None,
                            )
                        elif action.kind in {"STRUCTURAL_EXIT", "EMERGENCY_CLOSE"}:
                            rules = self._rules(symbol)
                            submitted = self.adapter.submit_market_exit(
                                action, current_state,
                                market_step_size=rules["market_step_size"],
                                market_min_qty=rules["market_min_qty"],
                            )
                            if submitted.get("status") == "SUBMITTED":
                                outcome = self.adapter.confirm_market_exit(action.action_id)
                            else:
                                outcome = submitted
                        else:
                            raise ValueError(f"Unsupported lifecycle action kind: {action.kind}")
                        results.append({"signal_id": signal_id, "action_id": action.action_id, **outcome})
                        if outcome.get("status") not in {"CONFIRMED", "CLOSED_CONFIRMED"}:
                            # An unresolved action owns the aggregate side until REST
                            # reconciliation completes; do not dispatch another lot.
                            return results
                    except Exception as exc:
                        self._halt(symbol, f"ACTION_DISPATCH_FAILED:{action.action_id}:{type(exc).__name__}:{exc}")
                        results.append({"signal_id": signal_id, "action_id": action.action_id,
                                        "status": "DISPATCH_ERROR", "error": str(exc)[:300]})
                        return results
        return results

    def _near_target_exit(
        self, state: ManagedPositionState, managed_row: Mapping[str, Any], event: Any,
    ) -> LifecycleAction | None:
        if self._near_target is None or not state.partial_tp_done:
            return None
        # The signal is for the remaining lot after confirmed partial TP.
        # Existing structural, breakeven, trailing and pending actions have priority.
        mark_at = getattr(event, "event_time_ms", None)
        if not isinstance(mark_at, int):
            return None
        try:
            target = Decimal(str(managed_row["take_profit"]))
            opened_at = datetime.fromisoformat(str(managed_row["opened_at_utc"]))
            mark = Decimal(str(event.mark_price))
        except (InvalidOperation, KeyError, ValueError):
            return None
        if not target.is_finite() or target <= 0 or opened_at.tzinfo is None or not mark.is_finite():
            return None
        direction = 1 if state.side == "LONG" else -1
        if direction * (mark - state.current_stop) <= 0 or direction * (target - mark) <= 0:
            return None
        if not self._near_target.reversal(
            symbol=state.symbol, side=state.side, opened_at=int(opened_at.timestamp() * 1_000),
            entry=state.entry_price, stop=state.current_stop, target=target,
            mark_at=mark_at, now=int(self._clock_ms()),
        ):
            return None
        action_id = "DIVAM" + hashlib.sha256(
            f"{state.signal_id}|NEAR_TP_ORDER_FLOW_EXIT".encode("utf-8")
        ).hexdigest()[:24].upper()
        if self.ledger.get_position_management_action(action_id) is not None:
            return None
        return LifecycleAction(
            action_id=action_id, kind="STRUCTURAL_EXIT", signal_id=state.signal_id,
            symbol=state.symbol, side=state.side, reason="Near-TP order-flow reversal after partial take profit",
        )

    def _rules(self, symbol: str) -> dict[str, Decimal]:
        raw = self.filter_provider(symbol)
        required = ("market_step_size", "market_min_qty", "tick_size")
        result: dict[str, Decimal] = {}
        for field in required:
            if field not in raw:
                raise ValueError(f"Exchange metadata missing {field} for {symbol}")
            value = raw[field] if isinstance(raw[field], Decimal) else Decimal(str(raw[field]))
            if not value.is_finite() or value <= 0:
                raise ValueError(f"Exchange metadata has invalid {field} for {symbol}")
            result[field] = value
        return result

    def emergency_close(self, signal_id: str, *, reason: str) -> dict[str, Any]:
        """Operator-callable explicit emergency close; never invoked by entry halt."""
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("emergency close reason must be non-empty")
        state = self.adapter.load_state(signal_id)
        action_id = "DIVAEM" + hashlib.sha256(
            f"{signal_id}|EMERGENCY_CLOSE|{reason.strip()}".encode("utf-8")
        ).hexdigest()[:24].upper()
        action = LifecycleAction(
            action_id=action_id, kind="EMERGENCY_CLOSE", signal_id=signal_id,
            symbol=state.symbol, side=state.side, reason=reason.strip(),
        )
        rules = self._rules(state.symbol)
        submitted = self.adapter.submit_market_exit(
            action, state, market_step_size=rules["market_step_size"],
            market_min_qty=rules["market_min_qty"],
        )
        if submitted.get("status") == "SUBMITTED":
            return self.adapter.confirm_market_exit(action_id)
        return submitted

