"""Opt-in near-target reversal proxy from RC6's paired market snapshots."""

from __future__ import annotations

from collections import OrderedDict, deque
from dataclasses import dataclass
from decimal import Decimal
from threading import Lock

from divatrading.strategy.scalping_market_data import ScalpingMarketDataView


_WINDOW_MS = 5_000
_MAX_SAMPLE_GAP_MS = 2_000
_MAX_SOURCE_AGE_MS = 2_000
_MAX_SOURCE_SKEW_MS = 1_000
_HISTORY_MS = 3 * _WINDOW_MS + 3 * _MAX_SAMPLE_GAP_MS
_NEAR_TARGET_FRACTION = Decimal("0.8")
_MIN_NET_AGGRESSION = Decimal("1000")
_MIN_TRADES = 3


@dataclass(frozen=True, slots=True)
class MarketObservation:
    received_at: int
    trade_at: int
    book_at: int
    trade_id: int
    book_id: int
    generation: tuple[int, int]
    cvd: Decimal
    bid: Decimal
    ask: Decimal
    tick: Decimal

    @classmethod
    def from_view(cls, view: ScalpingMarketDataView, now: int) -> MarketObservation | None:
        health = view.order_book_health
        book = view.order_book_metrics
        flow = view.flow
        source = view.orchestrator_readiness
        tick = view.instrument.tick_size
        if (
            book is None or flow is None or health is None or source is None
            or tick is None or not tick.is_finite() or tick <= 0
            or view.symbol != book.symbol or view.symbol != flow.symbol
            or view.symbol != source.symbol or view.symbol != health.symbol
            or source.status != "READY" or not source.ready or not source.queues_healthy
            or not source.aggregate_trade_connected or not source.aggregate_trade_continuity
            or not source.delta_cvd_ready or not source.order_book_ready
            or not (health.ready and health.sequence_integrity and health.event_fresh and health.queue_healthy)
            or not book.synchronized or health.update_id != book.update_id
            or flow.status != "HEALTHY" or not flow.continuity_valid or not flow.is_fresh
            or flow.trade_count <= 0 or flow.last_trade_time_ms is None
            or not flow.cvd_quote.is_finite() or not book.best_bid.is_finite() or not book.best_ask.is_finite()
            or not 0 < book.best_bid < book.best_ask
        ):
            return None
        trade_at = flow.last_trade_time_ms
        book_at = book.last_event_time_ms
        if (
            any(not 0 <= now - stamp <= _MAX_SOURCE_AGE_MS
                for stamp in (trade_at, book_at, view.captured_at_ms))
            or abs(trade_at - book_at) > _MAX_SOURCE_SKEW_MS
        ):
            return None
        return cls(
            now, trade_at, book_at, flow.last_processed_aggregate_trade_id, book.update_id,
            (source.aggregate_trade_reconnect_generation, source.depth_reconnect_generation),
            flow.cvd_quote, book.best_bid, book.best_ask, tick,
        )


class NearTakeProfitProtection:
    """Keep bounded, immutable-at-read observation history for the Mark worker."""

    def __init__(self) -> None:
        self._history: OrderedDict[str, deque[MarketObservation]] = OrderedDict()
        self._lock = Lock()

    def observe(self, view: ScalpingMarketDataView, now: int) -> None:
        observation = MarketObservation.from_view(view, now)
        with self._lock:
            if observation is None:
                self._history.pop(view.symbol, None)
                return
            history = self._history.setdefault(view.symbol, deque(maxlen=128))
            if history:
                previous = history[-1]
                if (
                    observation.generation != previous.generation
                    or observation.tick != previous.tick
                    or not 0 <= observation.received_at - previous.received_at <= _MAX_SAMPLE_GAP_MS
                    or observation.book_at < previous.book_at or observation.trade_at < previous.trade_at
                    or observation.book_id < previous.book_id or observation.trade_id < previous.trade_id
                ):
                    history.clear()
                elif (
                    observation.received_at == previous.received_at
                    or (observation.book_id, observation.trade_id) == (previous.book_id, previous.trade_id)
                ):
                    return
            history.append(observation)
            cutoff = now - _HISTORY_MS
            while history[0].received_at < cutoff:
                history.popleft()
            self._history.move_to_end(view.symbol)
            if len(self._history) > 32:
                self._history.popitem(last=False)

    def reversal(
        self, *, symbol: str, side: str, opened_at: int, entry: Decimal,
        stop: Decimal, target: Decimal, mark_at: int, now: int,
    ) -> bool:
        with self._lock:
            observations = tuple(self._history.get(symbol, ()))
        if not observations:
            return False
        latest = observations[-1]
        if (
            any(not 0 <= now - stamp <= _MAX_SOURCE_AGE_MS
                for stamp in (latest.received_at, latest.book_at, latest.trade_at, mark_at))
            or abs(latest.book_at - mark_at) > _MAX_SOURCE_AGE_MS
        ):
            return False
        direction = 1 if side == "LONG" else -1
        return _sampled_reversal(
            tuple(item for item in observations if item.received_at >= opened_at
                  and item.trade_at >= opened_at and item.book_at >= opened_at),
            direction=direction, entry=entry, stop=stop, target=target,
        )


def _sampled_reversal(
    observations: tuple[MarketObservation, ...], *, direction: int,
    entry: Decimal, stop: Decimal, target: Decimal,
) -> bool:
    """Test two completed windows using CVD/cursor changes between boundaries.

    Extrema use the observed BBO snapshots. RC6 does not expose every quote
    between snapshots, so the result represents the observed price path.
    """
    span = direction * (target - entry)
    if span <= 0:
        return False
    activation = direction * entry + span * _NEAR_TARGET_FRACTION
    if not observations:
        return False
    latest = observations[-1]
    latest_price = direction * (latest.bid if direction > 0 else latest.ask)
    if not direction * stop < latest_price < direction * target:
        return False
    window: list[MarketObservation] = []
    stalled: list[MarketObservation] = []
    armed_at: int | None = None
    lows: tuple[Decimal, Decimal] | None = None
    best = None
    reversal = False
    for sample in observations:
        executable = direction * (sample.bid if direction > 0 else sample.ask)
        opposing = direction * (sample.ask if direction > 0 else sample.bid)
        if executable >= direction * target:
            return False
        if armed_at is not None:
            assert best is not None and lows is not None
            if sample.received_at - armed_at < _WINDOW_MS and executable - best < sample.tick:
                reversal = executable > direction * entry and executable < lows[0] and opposing < lows[1]
                continue
            armed_at = None
            best = None
            lows = None
            stalled.clear()
            window.clear()
            reversal = False
        if executable < activation:
            stalled.clear()
            window.clear()
            continue
        window.append(sample)
        start = window[0]
        if min(
            sample.received_at - start.received_at,
            sample.trade_at - start.trade_at,
            sample.book_at - start.book_at,
        ) < _WINDOW_MS:
            continue
        # Use both independent clocks. Observations are accepted only with
        # fresh, ordered trade and depth timestamps and matching book state.
        quote_prices = [direction * (item.bid if direction > 0 else item.ask) for item in window]
        if (
            sample.trade_id - start.trade_id >= _MIN_TRADES
            and sample.book_id > start.book_id
            and direction * (sample.cvd - start.cvd) >= _MIN_NET_AGGRESSION
            and max(quote_prices) - quote_prices[0] < sample.tick
        ):
            if stalled:
                combined = stalled + window[1:]
                bid_low = min(direction * item.bid for item in combined)
                ask_low = min(direction * item.ask for item in combined)
                lows = (bid_low, ask_low) if direction > 0 else (ask_low, bid_low)
                best = max(direction * (item.bid if direction > 0 else item.ask) for item in combined)
                armed_at = sample.received_at
            else:
                stalled = window
        else:
            stalled.clear()
        # The shared boundary carries a cumulative CVD value; subtracting it
        # in the next window counts each trade in only one window.
        window = [sample]
    return reversal
