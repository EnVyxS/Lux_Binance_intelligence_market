"""Binance USDⓈ-M User Data Stream supervisor and durable event projection."""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Protocol
from urllib.parse import quote

from websockets.asyncio.client import connect as websocket_connect

from .binance_private import LIVE_USER_STREAM_BASE_URL, TESTNET_USER_STREAM_BASE_URL

# Subscribe only to events consumed by DIVA's account, fill and protection lifecycle.
# Binance's current USD-M private stream uses a listenKey + slash-delimited events query.
USER_DATA_STREAM_EVENTS = (
    "ORDER_TRADE_UPDATE",
    "ACCOUNT_UPDATE",
    "ALGO_UPDATE",
    "TRADE_LITE",
    "ACCOUNT_CONFIG_UPDATE",
    "MARGIN_CALL",
    "listenKeyExpired",
)


class UserDataStreamRestClient(Protocol):
    environment: str

    def start_user_data_stream(self) -> str: ...
    def keepalive_user_data_stream(self, listen_key: str) -> dict[str, Any]: ...
    def close_user_data_stream(self, listen_key: str) -> dict[str, Any]: ...


class UserDataStreamLedger(Protocol):
    def record_user_stream_event(self, payload: dict[str, Any], *, received_at_ms: int) -> tuple[str, bool]: ...
    def set_user_stream_state(self, status: str, *, listen_key_fingerprint: str | None = None,
                              connected_at_ms: int | None = None, last_error: str | None = None,
                              updated_at_ms: int) -> None: ...


@dataclass(frozen=True, slots=True)
class UserDataStreamConfig:
    keepalive_interval_seconds: float = 25 * 60
    max_connection_seconds: float = 23 * 60 * 60
    reconnect_initial_seconds: float = 1.0
    reconnect_max_seconds: float = 30.0
    ping_interval_seconds: float = 180.0
    ping_timeout_seconds: float = 600.0
    receive_poll_seconds: float = 1.0
    live_ws_base_url: str = LIVE_USER_STREAM_BASE_URL
    testnet_ws_base_url: str = TESTNET_USER_STREAM_BASE_URL

    def __post_init__(self) -> None:
        for field in ("keepalive_interval_seconds", "max_connection_seconds",
                      "reconnect_initial_seconds", "reconnect_max_seconds",
                      "ping_interval_seconds", "ping_timeout_seconds", "receive_poll_seconds"):
            value = getattr(self, field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                raise ValueError(f"{field} must be positive")
        if self.reconnect_max_seconds < self.reconnect_initial_seconds:
            raise ValueError("reconnect_max_seconds must be >= reconnect_initial_seconds")
        if not self.live_ws_base_url.startswith("wss://") or not self.testnet_ws_base_url.startswith("wss://"):
            raise ValueError("User Data Stream websocket endpoints must use wss://")


@dataclass(frozen=True, slots=True)
class UserDataStreamEvent:
    event_id: str
    event_type: str
    event_time_ms: int
    transaction_time_ms: int
    symbol: str
    payload: dict[str, Any]
    duplicate: bool


class UserDataStreamProcessor:
    """Validates, hashes, persists and projects incoming account events."""
    def __init__(self, ledger: UserDataStreamLedger, *, clock_ms: Callable[[], int] | None = None) -> None:
        self.ledger = ledger
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)

    def process(self, payload: dict[str, Any]) -> UserDataStreamEvent:
        if not isinstance(payload, dict):
            raise TypeError("Binance User Data Stream event must be a JSON object")
        event_type = payload.get("e")
        if not isinstance(event_type, str) or not event_type:
            raise ValueError("Binance User Data Stream event is missing event type")
        event_time = payload.get("E", payload.get("T", self.clock_ms()))
        transaction_time = payload.get("T", event_time)
        if isinstance(event_time, bool) or not isinstance(event_time, (int, float)):
            raise ValueError("Binance User Data Stream event E/T must be numeric")
        if isinstance(transaction_time, bool) or not isinstance(transaction_time, (int, float)):
            raise ValueError("Binance User Data Stream transaction time must be numeric")
        event_time = int(event_time)
        transaction_time = int(transaction_time)
        body = payload.get("o") or payload.get("or") or {}
        account = payload.get("a") or {}
        symbol = str(body.get("s") or payload.get("s") or account.get("S") or "").upper()
        received = self.clock_ms()
        event_id, inserted = self.ledger.record_user_stream_event(payload, received_at_ms=received)
        if inserted and event_type in {"ORDER_TRADE_UPDATE", "TRADE_LITE"}:
            # The applier is a transactionally rebuilt projection over immutable
            # exchange trade IDs. It never mutates REST-backed position quantities.
            self.ledger.apply_position_fill_allocations()
        return UserDataStreamEvent(event_id, event_type, event_time, transaction_time,
                                   symbol, payload, not inserted)


EventCallback = Callable[[UserDataStreamEvent], Any | Awaitable[Any]]
Connector = Callable[..., Any]


class BinanceUserDataStreamSupervisor:
    """Maintains listenKey and WebSocket lifecycle; never submits or cancels orders."""
    def __init__(self, *, client: UserDataStreamRestClient, ledger: UserDataStreamLedger,
                 config: UserDataStreamConfig | None = None,
                 on_event: EventCallback | None = None,
                 connector: Connector | None = None,
                 clock_ms: Callable[[], int] | None = None) -> None:
        self.client = client
        self.ledger = ledger
        self.config = config or UserDataStreamConfig()
        self.on_event = on_event
        self.connector = connector or websocket_connect
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self.processor = UserDataStreamProcessor(ledger, clock_ms=self.clock_ms)

    def websocket_url(self, listen_key: str) -> str:
        if not listen_key:
            raise ValueError("listen_key must be non-empty")
        if self.client.environment == "LIVE":
            base = self.config.live_ws_base_url.rstrip("/")
        elif self.client.environment == "TESTNET":
            base = self.config.testnet_ws_base_url.rstrip("/")
        else:
            raise ValueError("User Data Stream environment must be LIVE or TESTNET")
        encoded_key = quote(listen_key, safe="")
        encoded_events = quote("/".join(USER_DATA_STREAM_EVENTS), safe="/")
        return f"{base}/ws?listenKey={encoded_key}&events={encoded_events}"

    async def run(self, stop_event: asyncio.Event) -> None:
        backoff = self.config.reconnect_initial_seconds
        while not stop_event.is_set():
            listen_key = ""
            expired = False
            try:
                self.ledger.set_user_stream_state("CONNECTING", updated_at_ms=self.clock_ms())
                listen_key = await asyncio.to_thread(self.client.start_user_data_stream)
                fingerprint = hashlib.sha256(listen_key.encode("utf-8")).hexdigest()[:16]
                uri = self.websocket_url(listen_key)
                started = asyncio.get_running_loop().time()
                last_keepalive = started
                async with self.connector(
                    uri,
                    ping_interval=self.config.ping_interval_seconds,
                    ping_timeout=self.config.ping_timeout_seconds,
                    close_timeout=10,
                ) as websocket:
                    self.ledger.set_user_stream_state(
                        "CONNECTED", listen_key_fingerprint=fingerprint,
                        connected_at_ms=self.clock_ms(), updated_at_ms=self.clock_ms(),
                    )
                    backoff = self.config.reconnect_initial_seconds
                    while not stop_event.is_set():
                        elapsed = asyncio.get_running_loop().time() - started
                        if elapsed >= self.config.max_connection_seconds:
                            break
                        try:
                            raw = await asyncio.wait_for(
                                websocket.recv(), timeout=self.config.receive_poll_seconds,
                            )
                        except asyncio.TimeoutError:
                            raw = None
                        now = asyncio.get_running_loop().time()
                        if raw is not None:
                            try:
                                payload = json.loads(raw)
                            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                                raise ValueError(f"Invalid JSON from Binance User Data Stream: {exc}") from exc
                            event = self.processor.process(payload)
                            if self.on_event is not None:
                                result = self.on_event(event)
                                if inspect.isawaitable(result):
                                    await result
                            if event.event_type == "listenKeyExpired":
                                expired = True
                                break
                        if now - last_keepalive >= self.config.keepalive_interval_seconds:
                            response = await asyncio.to_thread(self.client.keepalive_user_data_stream, listen_key)
                            refreshed_key = response.get("listenKey")
                            if refreshed_key and refreshed_key != listen_key:
                                # Key rotation is not an in-place subscription update; reconnect below.
                                expired = True
                                break
                            last_keepalive = now
                if stop_event.is_set():
                    if listen_key:
                        await asyncio.to_thread(self.client.close_user_data_stream, listen_key)
                    break
                self.ledger.set_user_stream_state(
                    "EXPIRED" if expired else "DISCONNECTED",
                    updated_at_ms=self.clock_ms(),
                )
                # Every new connection receives a fresh key. Close the prior key on
                # both expiry and transport disconnect to avoid orphaned listenKeys.
                if listen_key:
                    try:
                        await asyncio.to_thread(self.client.close_user_data_stream, listen_key)
                    except Exception:
                        pass
            except asyncio.CancelledError:
                if listen_key:
                    try:
                        await asyncio.to_thread(self.client.close_user_data_stream, listen_key)
                    except Exception:
                        pass
                self.ledger.set_user_stream_state("STOPPED", updated_at_ms=self.clock_ms())
                raise
            except Exception as exc:
                self.ledger.set_user_stream_state(
                    "DISCONNECTED", last_error=f"{type(exc).__name__}: {exc}"[:500],
                    updated_at_ms=self.clock_ms(),
                )
                if listen_key:
                    try:
                        await asyncio.to_thread(self.client.close_user_data_stream, listen_key)
                    except Exception:
                        pass
            if not stop_event.is_set():
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=backoff)
                except asyncio.TimeoutError:
                    pass
                backoff = min(backoff * 2, self.config.reconnect_max_seconds)
        self.ledger.set_user_stream_state("STOPPED", updated_at_ms=self.clock_ms())
