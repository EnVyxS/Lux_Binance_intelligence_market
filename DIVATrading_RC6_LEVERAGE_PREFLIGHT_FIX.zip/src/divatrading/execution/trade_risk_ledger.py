"""Durable completed-lifecycle PnL and loss-streak ledger.

Partial fills/exits are accumulated by the execution lifecycle and must be
submitted once as a completed lifecycle. Unique lifecycle IDs make replay safe.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo
from typing import Any
from divatrading.core.database import Database

TZ = ZoneInfo("Asia/Jakarta")


def _d(v: Any, field: str) -> Decimal:
    try: x = Decimal(str(v))
    except (InvalidOperation, ValueError, TypeError) as exc: raise ValueError(f"invalid {field}") from exc
    if not x.is_finite(): raise ValueError(f"invalid {field}")
    return x


@dataclass(frozen=True, slots=True)
class LedgerSnapshot:
    day_key: str
    daily_net_pnl: Decimal
    consecutive_losses: int
    completed_trades: int
    reconciliation_ready: bool
    block_reason: str | None


class CompletedTradeRiskLedger:
    def __init__(self, database: Database) -> None:
        self.db = database
        self.db.initialize()
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS completed_trade_risk (
                lifecycle_id TEXT PRIMARY KEY, symbol TEXT NOT NULL, closed_at_utc TEXT NOT NULL,
                jakarta_day TEXT NOT NULL, realized_pnl TEXT NOT NULL, commission TEXT NOT NULL,
                funding TEXT NOT NULL, net_pnl TEXT NOT NULL)""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_completed_trade_day ON completed_trade_risk(jakarta_day)")
            c.execute("""CREATE TABLE IF NOT EXISTS trade_risk_reconciliation (
                singleton INTEGER PRIMARY KEY CHECK(singleton=1), ready INTEGER NOT NULL,
                reason TEXT, updated_at_utc TEXT NOT NULL)""")
            c.execute("INSERT OR IGNORE INTO trade_risk_reconciliation VALUES(1,0,'INITIAL_RECONCILIATION_REQUIRED',?)",
                      (datetime.now(UTC).isoformat(),))

    @staticmethod
    def jakarta_day(timestamp: datetime) -> str:
        if timestamp.tzinfo is None: raise ValueError("closed_at must be timezone-aware")
        return timestamp.astimezone(TZ).date().isoformat()

    def record_completed_lifecycle(self, *, lifecycle_id: str, symbol: str,
            closed_at: datetime, realized_pnl: Any, commission: Any,
            funding: Any = "0") -> bool:
        if not lifecycle_id.strip() or not symbol.strip(): raise ValueError("lifecycle_id and symbol required")
        rp, fee, fund = _d(realized_pnl, "realized_pnl"), _d(commission, "commission"), _d(funding, "funding")
        if fee < 0: raise ValueError("commission must be non-negative")
        net = rp - fee + fund
        with self.db.transaction() as c:
            cur = c.execute("""INSERT OR IGNORE INTO completed_trade_risk
                (lifecycle_id,symbol,closed_at_utc,jakarta_day,realized_pnl,commission,funding,net_pnl)
                VALUES(?,?,?,?,?,?,?,?)""", (lifecycle_id, symbol.upper(), closed_at.isoformat(),
                self.jakarta_day(closed_at), str(rp), str(fee), str(fund), str(net)))
        return cur.rowcount == 1

    def has_lifecycle(self, lifecycle_id: str) -> bool:
        with self.db.transaction() as c:
            row = c.execute("SELECT 1 FROM completed_trade_risk WHERE lifecycle_id=?", (lifecycle_id,)).fetchone()
        return row is not None

    def set_reconciliation(self, ready: bool, reason: str | None = None) -> None:
        with self.db.transaction() as c:
            c.execute("UPDATE trade_risk_reconciliation SET ready=?,reason=?,updated_at_utc=? WHERE singleton=1",
                      (1 if ready else 0, None if ready else (reason or "RECONCILIATION_INCOMPLETE"), datetime.now(UTC).isoformat()))

    def snapshot(self, now: datetime) -> LedgerSnapshot:
        if now.tzinfo is None: raise ValueError("now must be timezone-aware")
        day = self.jakarta_day(now)
        with self.db.transaction() as c:
            rows = c.execute("SELECT net_pnl FROM completed_trade_risk ORDER BY closed_at_utc,lifecycle_id").fetchall()
            today_rows = c.execute("SELECT net_pnl FROM completed_trade_risk WHERE jakarta_day=?", (day,)).fetchall()
            rec = c.execute("SELECT ready,reason FROM trade_risk_reconciliation WHERE singleton=1").fetchone()
        streak = 0
        for row in reversed(rows):
            pnl = Decimal(row[0])
            if pnl < 0: streak += 1
            elif pnl > 0: break
            else: break
        daily_net = sum((Decimal(r[0]) for r in today_rows), Decimal("0"))
        return LedgerSnapshot(day, daily_net, streak, len(today_rows),
                              bool(rec[0]), None if rec[0] else str(rec[1] or "RECONCILIATION_INCOMPLETE"))


def entry_reconciliation_gate(snapshot: LedgerSnapshot) -> tuple[bool, tuple[str, ...]]:
    """Fail-closed gate: no new entries until the account trade history is reconciled."""
    if snapshot.reconciliation_ready:
        return True, ()
    return False, (snapshot.block_reason or "TRADE_LEDGER_RECONCILIATION_REQUIRED",)
