"""Read-only Binance USDⓈ-M Demo Trading preflight for v0.57 qualification.

This module performs NO order, leverage, margin-mode, cancellation, or account-setting
writes. It validates endpoint isolation, public API reachability, signed account access,
position mode, contract filters, and account cleanliness before later order tests.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Protocol
from urllib.parse import urlsplit

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.strategy.scalping_market_data import InstrumentSpec
from .binance_private import TESTNET_BASE_URL, TESTNET_USER_STREAM_BASE_URL


class TestnetPreflightClient(Protocol):
    environment: str
    base_url: str
    last_time_sync_rtt_ms: int
    last_server_time_ms: int

    def sync_server_time(self) -> int: ...
    def ping(self) -> dict[str, Any]: ...
    def get_exchange_info(self) -> dict[str, Any]: ...
    def get_exchange_account(self) -> dict[str, Any]: ...
    def get_account_config(self) -> dict[str, Any]: ...
    def get_position_mode(self) -> dict[str, Any]: ...
    def get_position_risk(self, symbol: str | None = None) -> list[dict[str, Any]]: ...
    def get_open_orders(self, symbol: str | None = None) -> list[dict[str, Any]]: ...
    def get_open_algo_orders(self, symbol: str | None = None) -> list[dict[str, Any]]: ...


@dataclass(frozen=True, slots=True)
class PreflightCheck:
    code: str
    status: str
    detail: str


@dataclass(frozen=True, slots=True)
class TestnetPreflightReport:
    status: str
    environment: str
    rest_host: str
    websocket_host: str
    account_position_mode: str | None
    can_trade: bool | None
    multi_assets_mode: bool | None
    wallet_balance_usdt: str | None
    available_balance_usdt: str | None
    active_positions: int | None
    open_standard_orders: int | None
    open_algo_orders: int | None
    symbols: tuple[str, ...]
    checks: tuple[PreflightCheck, ...]
    order_submission_performed: bool = False

    @property
    def ready_for_test_order(self) -> bool:
        return self.status == "READY_FOR_TEST_ORDER_VALIDATION"

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "environment": self.environment,
            "rest_host": self.rest_host,
            "websocket_host": self.websocket_host,
            "account_position_mode": self.account_position_mode,
            "can_trade": self.can_trade,
            "multi_assets_mode": self.multi_assets_mode,
            "wallet_balance_usdt": self.wallet_balance_usdt,
            "available_balance_usdt": self.available_balance_usdt,
            "active_positions": self.active_positions,
            "open_standard_orders": self.open_standard_orders,
            "open_algo_orders": self.open_algo_orders,
            "symbols": list(self.symbols),
            "checks": [asdict(item) for item in self.checks],
            "order_submission_performed": self.order_submission_performed,
        }


class BinanceTestnetPreflight:
    """Run a bounded, strictly read-only preflight against Binance Demo Futures."""

    def __init__(
        self,
        client: TestnetPreflightClient,
        *,
        symbols: tuple[str, ...] = ("BTCUSDT",),
        max_time_sync_rtt_ms: int = 2_000,
    ) -> None:
        if not symbols:
            raise ValueError("At least one symbol is required for TESTNET preflight")
        normalized = tuple(dict.fromkeys(str(s).strip().upper() for s in symbols))
        if any(not s or not s.isalnum() for s in normalized):
            raise ValueError("Symbols must be non-empty alphanumeric Binance symbols")
        if isinstance(max_time_sync_rtt_ms, bool) or max_time_sync_rtt_ms < 1:
            raise ValueError("max_time_sync_rtt_ms must be positive")
        self.client = client
        self.symbols = normalized
        self.max_time_sync_rtt_ms = max_time_sync_rtt_ms
        self.checks: list[PreflightCheck] = []

    def _add(self, code: str, status: str, detail: str) -> None:
        self.checks.append(PreflightCheck(code, status, detail))

    @staticmethod
    def _decimal(value: Any, field: str) -> Decimal:
        try:
            parsed = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise ValueError(f"Invalid account numeric field: {field}") from exc
        if not parsed.is_finite():
            raise ValueError(f"Non-finite account numeric field: {field}")
        return parsed

    @staticmethod
    def _optional_bool(value: Any) -> bool | None:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, str)):
            normalized = str(value).strip().lower()
            if normalized in {"1", "true", "yes"}:
                return True
            if normalized in {"0", "false", "no"}:
                return False
        return None

    @staticmethod
    def _rows(value: Any, field: str) -> list[dict[str, Any]]:
        if not isinstance(value, list) or any(not isinstance(row, dict) for row in value):
            raise ValueError(f"Binance {field} response must be an array of objects")
        return value

    def run(self) -> TestnetPreflightReport:
        position_mode: str | None = None
        can_trade: bool | None = None
        multi_assets: bool | None = None
        wallet: str | None = None
        available: str | None = None
        active_positions: int | None = None
        standard_count: int | None = None
        algo_count: int | None = None
        parsed_symbols: list[str] = []

        # Endpoint pinning is checked before making any request. A TESTNET client
        # pointed at LIVE (or an arbitrary host) is rejected without network I/O.
        host = urlsplit(self.client.base_url).hostname or ""
        if self.client.environment != "TESTNET" or self.client.base_url.rstrip("/") != TESTNET_BASE_URL:
            self._add("ENDPOINT_ISOLATION", "FAIL", "Client is not pinned to the approved USDⓈ-M Demo REST endpoint")
            return self._report("BLOCKED_ENDPOINT_ISOLATION", None, None, None, None,
                                None, None, None, None, None)
        self._add("ENDPOINT_ISOLATION", "PASS", "REST client is pinned to Binance Demo USDⓈ-M Futures")

        # Public endpoint reachability and server clock alignment.
        try:
            self.client.ping()
            self._add("REST_PING", "PASS", "Public REST ping succeeded")
        except Exception as exc:
            self._add("REST_PING", "FAIL", f"Public REST ping failed: {type(exc).__name__}")

        try:
            offset = self.client.sync_server_time()
            rtt = int(getattr(self.client, "last_time_sync_rtt_ms", 0))
            if rtt > self.max_time_sync_rtt_ms:
                self._add("SERVER_TIME_SYNC", "FAIL", f"Time sync round-trip {rtt} ms exceeds {self.max_time_sync_rtt_ms} ms")
            else:
                severity = "WARN" if abs(offset) > 1_000 else "PASS"
                self._add("SERVER_TIME_SYNC", severity,
                          f"Clock offset corrected by {offset} ms; round-trip {rtt} ms")
        except Exception as exc:
            self._add("SERVER_TIME_SYNC", "FAIL", f"Server-time synchronization failed: {type(exc).__name__}")

        exchange_info: dict[str, Any] | None = None
        try:
            exchange_info = self.client.get_exchange_info()
            snapshot = parse_exchange_info(exchange_info, source_endpoint=f"{TESTNET_BASE_URL}/fapi/v1/exchangeInfo")
            missing: list[str] = []
            for symbol in self.symbols:
                info = snapshot.get_symbol(symbol)
                if info is None:
                    missing.append(f"{symbol}:NOT_LISTED")
                    continue
                instrument = InstrumentSpec.from_symbol_info(info)
                if not info.is_tradable_usdt_perpetual:
                    missing.append(f"{symbol}:NOT_ACTIVE_USDT_PERPETUAL")
                elif (not instrument.price_grid_ready or not instrument.quantity_grid_ready
                      or instrument.min_notional is None or instrument.min_notional <= 0):
                    missing.append(f"{symbol}:REQUIRED_FILTERS_INCOMPLETE")
                else:
                    parsed_symbols.append(symbol)
            if missing:
                self._add("SYMBOL_METADATA", "FAIL", ";".join(missing))
            else:
                self._add("SYMBOL_METADATA", "PASS",
                          f"{len(parsed_symbols)} selected symbol(s) are active USDT perpetuals with price/quantity/notional filters")
        except Exception as exc:
            self._add("SYMBOL_METADATA", "FAIL", f"Exchange metadata validation failed: {type(exc).__name__}")

        # Account Information V3 supplies wallet/available-balance values. Binance
        # removed account-configuration fields from this response; canTrade and
        # multiAssetsMargin must be queried separately from /fapi/v1/accountConfig.
        try:
            account = self.client.get_exchange_account()
            if not isinstance(account, dict):
                raise ValueError("Account response must be a JSON object")
            wallet_value = self._decimal(account.get("totalWalletBalance"), "totalWalletBalance")
            available_value = self._decimal(account.get("availableBalance"), "availableBalance")
            wallet = str(wallet_value)
            available = str(available_value)
            if available_value <= 0:
                self._add("TEST_USDT_BALANCE", "FAIL", "Available USDT balance is not positive; fund the Demo Futures wallet before order qualification")
            else:
                self._add("TEST_USDT_BALANCE", "PASS", f"Available balance is positive ({available_value} USDT)")
        except Exception as exc:
            self._add("SIGNED_ACCOUNT_AUTH", "FAIL", f"Signed account-information request failed: {type(exc).__name__}")

        try:
            account_config = self.client.get_account_config()
            if not isinstance(account_config, dict):
                raise ValueError("Account configuration response must be a JSON object")
            can_trade = self._optional_bool(account_config.get("canTrade"))
            multi_assets = self._optional_bool(account_config.get("multiAssetsMargin"))
            if can_trade is False:
                self._add("ACCOUNT_TRADING_STATUS", "FAIL", "Exchange account reports canTrade=false")
            elif can_trade is True:
                self._add("ACCOUNT_TRADING_STATUS", "PASS", "Exchange account reports canTrade=true")
            else:
                self._add("ACCOUNT_TRADING_STATUS", "FAIL", "Account configuration response did not expose canTrade; account trading status cannot be established")
            if multi_assets is True:
                self._add("MARGIN_MODE", "FAIL", "Multi-Assets Mode is enabled but this qualification profile expects single-asset USDT collateral")
            elif multi_assets is False:
                self._add("MARGIN_MODE", "PASS", "Single-asset margin mode confirmed")
            else:
                self._add("MARGIN_MODE", "FAIL", "Account configuration response did not expose multiAssetsMargin; collateral mode cannot be established")
        except Exception as exc:
            detail = f"Signed account-configuration request failed: {type(exc).__name__}"
            self._add("ACCOUNT_CONFIG", "FAIL", detail)
            self._add("ACCOUNT_TRADING_STATUS", "FAIL", "Unable to establish canTrade because account configuration could not be read")
            self._add("MARGIN_MODE", "FAIL", "Unable to establish multiAssetsMargin because account configuration could not be read")

        try:
            mode = self.client.get_position_mode()
            dual = self._optional_bool(mode.get("dualSidePosition") if isinstance(mode, dict) else None)
            if dual is None:
                self._add("POSITION_MODE", "FAIL", "Position mode response is missing a valid dualSidePosition value")
            else:
                position_mode = "HEDGE" if dual else "ONE_WAY"
                self._add("POSITION_MODE", "PASS", f"Exchange position mode confirmed: {position_mode}")
        except Exception as exc:
            self._add("POSITION_MODE", "FAIL", f"Position mode query failed: {type(exc).__name__}")

        try:
            raw_positions = self._rows(self.client.get_position_risk(), "positionRisk")
            active_positions = sum(
                1 for row in raw_positions
                if self._decimal(row.get("positionAmt", "0"), "positionAmt") != 0
            )
            if active_positions:
                self._add("ACCOUNT_POSITIONS", "FAIL", f"Account has {active_positions} non-flat position row(s); clean account required for first qualification")
            else:
                self._add("ACCOUNT_POSITIONS", "PASS", "No open positions detected")
        except Exception as exc:
            self._add("ACCOUNT_POSITIONS", "FAIL", f"Position-risk query failed: {type(exc).__name__}")

        try:
            standard = self._rows(self.client.get_open_orders(), "openOrders")
            standard_count = len(standard)
            if standard_count:
                self._add("OPEN_STANDARD_ORDERS", "FAIL", f"Account has {standard_count} open standard order(s); clean account required")
            else:
                self._add("OPEN_STANDARD_ORDERS", "PASS", "No open standard orders detected")
        except Exception as exc:
            self._add("OPEN_STANDARD_ORDERS", "FAIL", f"Open standard-order query failed: {type(exc).__name__}")

        try:
            algo = self._rows(self.client.get_open_algo_orders(), "openAlgoOrders")
            algo_count = len(algo)
            if algo_count:
                self._add("OPEN_ALGO_ORDERS", "FAIL", f"Account has {algo_count} open Algo order(s); clean account required")
            else:
                self._add("OPEN_ALGO_ORDERS", "PASS", "No open Algo orders detected")
        except Exception as exc:
            self._add("OPEN_ALGO_ORDERS", "FAIL", f"Open Algo-order query failed: {type(exc).__name__}")

        failures = any(check.status == "FAIL" for check in self.checks)
        status = "BLOCKED_PREFLIGHT" if failures else "READY_FOR_TEST_ORDER_VALIDATION"
        # A read-only check cannot confirm that the API key has TRADE permission.
        # That is deliberately deferred to a signed /order/test check in Stage B.
        if not failures and not any(c.code == "TRADE_PERMISSION" for c in self.checks):
            self._add("TRADE_PERMISSION", "WARN", "Not tested in Stage A; Stage B must validate POST /fapi/v1/order/test")
        return TestnetPreflightReport(
            status=status,
            environment="TESTNET",
            rest_host=host,
            websocket_host=urlsplit(TESTNET_USER_STREAM_BASE_URL).hostname or "",
            account_position_mode=position_mode,
            can_trade=can_trade,
            multi_assets_mode=multi_assets,
            wallet_balance_usdt=wallet,
            available_balance_usdt=available,
            active_positions=active_positions,
            open_standard_orders=standard_count,
            open_algo_orders=algo_count,
            symbols=tuple(parsed_symbols),
            checks=tuple(self.checks),
        )

    def _report(
        self, status: str, position_mode: str | None, can_trade: bool | None,
        multi_assets: bool | None, wallet: str | None, available: str | None,
        active_positions: int | None, standard_count: int | None, algo_count: int | None,
        symbols: tuple[str, ...] | None,
    ) -> TestnetPreflightReport:
        return TestnetPreflightReport(
            status=status, environment="TESTNET", rest_host=urlsplit(self.client.base_url).hostname or "",
            websocket_host=urlsplit(TESTNET_USER_STREAM_BASE_URL).hostname or "", account_position_mode=position_mode,
            can_trade=can_trade, multi_assets_mode=multi_assets, wallet_balance_usdt=wallet,
            available_balance_usdt=available, active_positions=active_positions,
            open_standard_orders=standard_count, open_algo_orders=algo_count,
            symbols=symbols or (), checks=tuple(self.checks),
        )
