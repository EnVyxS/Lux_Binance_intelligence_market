"""Fail-closed execution adapter for managed-position lifecycle actions.

This adapter submits one deterministic exchange request per claimed action. It never
interprets a POST acknowledgement as a fill. All effective state transitions require
subsequent REST verification and, in normal operation, arrive through the account
User Data Stream event reducer below.
"""
from __future__ import annotations

import hashlib
import json
import time
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from typing import Any

from .binance_private import (
    BinancePrivateApiError,
    BinancePrivateRestClient,
    BinancePrivateTransportError,
)
from .ledger import ExecutionLedger
from .position_lifecycle import LifecycleAction, ManagedPositionState
from .protection import (build_quantity_scoped_protection_params,
                         is_quantity_scoped_order_valid)


TERMINAL_ORDER_STATES = {"FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED"}
ACTIVE_ALGO_STATES = {"NEW", "PENDING_NEW"}
IOC_INITIAL_STOP_REJECTED = "IOC_INITIAL_STOP_REJECTED"


def _decimal(value: Any, field: str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be Decimal-compatible") from exc
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


def _bool(value: Any) -> bool:
    return value is True or str(value).strip().lower() in {"true", "1", "yes"}


def _client_id(prefix: str, action_id: str) -> str:
    """Stable Binance-compatible identifier (<=36 chars) for an action."""
    return prefix + hashlib.sha256(action_id.encode("utf-8")).hexdigest()[:24].upper()


def _floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError("quantity step must be positive")
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step


class PositionLifecycleExecutionAdapter:
    """Executes partial closes and stop replacements for an existing managed position.

    The adapter requires TESTNET/LIVE private clients. PAPER continues to use the
    decision engine only and cannot instantiate this exchange mutation adapter.
    """
    def __init__(self, *, client: BinancePrivateRestClient, ledger: ExecutionLedger,
                 working_type: str = "MARK_PRICE", price_protect: bool = True,
                 max_account_snapshot_age_ms: int = 30_000,
                 clock_ms: Any | None = None) -> None:
        if getattr(client, "environment", "") not in {"TESTNET", "LIVE"}:
            raise ValueError("Lifecycle execution requires a TESTNET or LIVE private client")
        if working_type not in {"MARK_PRICE", "CONTRACT_PRICE"}:
            raise ValueError("working_type must be MARK_PRICE or CONTRACT_PRICE")
        if isinstance(max_account_snapshot_age_ms, bool) or max_account_snapshot_age_ms < 1000:
            raise ValueError("max_account_snapshot_age_ms must be >= 1000")
        self.client = client
        self.ledger = ledger
        self.working_type = working_type
        self.price_protect = bool(price_protect)
        self.max_account_snapshot_age_ms = max_account_snapshot_age_ms
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)

    def load_state(self, signal_id: str) -> ManagedPositionState:
        """Hydrate the immutable lifecycle model from durable ledger state."""
        row = self.ledger.get_position_management_state(signal_id)
        if row is None:
            raise KeyError(f"No persisted managed-position state for {signal_id}")
        raw = dict(row["state"])
        if "initial_quantity" not in raw or "partial_tp_filled_quantity" not in raw:
            # Recover the pre-v0.49 partial-fill basis from durable action payloads.
            # This avoids redefining the 50% target against an already reduced quantity.
            prior_partial_actions = [
                item for item in self.ledger.list_position_management_actions(signal_id=signal_id)
                if item.get("action_kind") == "PARTIAL_TP"
                and item.get("status") in {"CONFIRMED", "PARTIAL_FILL_TERMINAL"}
            ]
            original_sizes = [
                _decimal(item.get("payload", {}).get("state_quantity"), "state_quantity")
                for item in prior_partial_actions
                if item.get("payload", {}).get("state_quantity") is not None
            ]
            raw.setdefault("initial_quantity", str(original_sizes[0] if original_sizes else raw.get("quantity")))
            prior_targets = [
                item.get("payload", {}).get("partial_tp_target_quantity")
                for item in prior_partial_actions
                if item.get("payload", {}).get("partial_tp_target_quantity") is not None
            ]
            if prior_targets:
                raw.setdefault("partial_tp_target_quantity", str(prior_targets[-1]))
            raw.setdefault("partial_tp_filled_quantity", str(sum((
                _decimal(item.get("payload", {}).get("executed_quantity", "0"), "executed_quantity")
                for item in prior_partial_actions
            ), Decimal("0"))))
        decimal_fields = ("quantity", "entry_price", "initial_stop", "current_stop",
                          "initial_risk_per_unit", "partial_tp_fraction",
                          "initial_quantity", "partial_tp_filled_quantity")
        for field in decimal_fields:
            if field not in raw:
                raise RuntimeError(f"Persisted lifecycle state missing {field}")
            raw[field] = _decimal(raw[field], field)
        for field in ("favorable_extreme", "last_mark_price", "structural_invalidation_price",
                      "partial_tp_target_quantity"):
            if raw.get(field) is not None:
                raw[field] = _decimal(raw[field], field)
        # Backfill existing managed positions from their approved TradePlan stop.
        # This is the only structural invalidation boundary persisted before v0.49.
        if "structural_invalidation_price" not in raw:
            raw["structural_invalidation_price"] = raw.get("initial_stop")
            raw["structural_invalidation_reason"] = "Backfilled approved SMC TradePlan stop/invalidation boundary"
        return ManagedPositionState(**{
            key: raw[key] for key in (
                "signal_id", "symbol", "side", "quantity", "entry_price", "initial_stop",
                "current_stop", "initial_risk_per_unit", "partial_tp_fraction",
                "partial_tp_done", "breakeven_done", "trailing_active",
                "favorable_extreme", "last_mark_price", "structural_invalidation_price",
                "structural_invalidation_reason", "initial_quantity",
                "partial_tp_target_quantity", "partial_tp_filled_quantity", "closed",
            ) if key in raw
        })

    def _halt(self, reason: str) -> None:
        self.ledger.set_entries_halted(True, reason[:500])
        self.ledger.record_event("POSITION_LIFECYCLE_SAFETY_HALT", detail={"reason": reason[:500]})

    def _assert_observation_ready(self) -> None:
        ready, reasons = self.ledger.account_observation_readiness(
            now_ms=int(self.clock_ms()),
            max_reconciliation_age_ms=self.max_account_snapshot_age_ms,
        )
        if not ready:
            raise RuntimeError("ACCOUNT_OBSERVATION_NOT_READY: " + ",".join(reasons))

    def _dual_side(self) -> bool:
        mode = self.client.get_position_mode()
        if not isinstance(mode, dict) or "dualSidePosition" not in mode:
            raise RuntimeError("Unable to determine Binance position mode")
        return _bool(mode["dualSidePosition"])

    def _position_quantity(self, symbol: str, side: str, dual_side: bool) -> Decimal:
        rows = self.client.get_position_risk(symbol)
        if isinstance(rows, dict):
            rows = [rows]
        if not isinstance(rows, list):
            raise RuntimeError("Malformed Binance positionRisk response")
        matches: list[Decimal] = []
        for row in rows:
            if not isinstance(row, dict):
                raise RuntimeError("Malformed position row")
            row_symbol = str(row.get("symbol", "")).upper()
            position_side = str(row.get("positionSide", "BOTH")).upper()
            amount = _decimal(row.get("positionAmt"), "positionAmt")
            if row_symbol != symbol.upper() or amount == 0:
                continue
            if dual_side:
                if position_side != side:
                    continue
            else:
                if position_side != "BOTH":
                    continue
                if side == "LONG" and amount <= 0:
                    continue
                if side == "SHORT" and amount >= 0:
                    continue
            matches.append(abs(amount))
        if len(matches) > 1:
            raise RuntimeError(f"AMBIGUOUS_EXCHANGE_POSITION:{symbol}:{side}")
        return matches[0] if matches else Decimal("0")

    def _position_side_param(self, side: str, dual_side: bool) -> str:
        return side if dual_side else "BOTH"

    def _managed_group_rows(self, symbol: str, side: str, dual_side: bool) -> list[dict[str, Any]]:
        """Return the durable open lots backing one exchange position side."""
        position_side = self._position_side_param(side, dual_side)
        rows = [
            row for row in self.ledger.list_managed_positions(status="OPEN")
            if str(row.get("symbol", "")).upper() == symbol.upper()
            and str(row.get("position_side", "BOTH")).upper() == position_side
        ]
        for row in rows:
            row_side = str(row.get("signal_side", "")).upper()
            if row_side != side.upper():
                raise RuntimeError(
                    f"MANAGED_GROUP_DIRECTION_MISMATCH:{symbol}:{position_side}:{row.get('signal_id')}"
                )
        return rows

    def _managed_group_quantity(self, symbol: str, side: str, dual_side: bool) -> Decimal:
        rows = self._managed_group_rows(symbol, side, dual_side)
        total = sum((_decimal(row.get("quantity"), "managed_group.quantity") for row in rows), Decimal("0"))
        if total < 0:
            raise RuntimeError("MANAGED_GROUP_QUANTITY_NEGATIVE")
        return total

    def _assert_group_projection(self, symbol: str, side: str, dual_side: bool,
                                 exchange_quantity: Decimal | None = None) -> Decimal:
        """Verify each open lot projection and its aggregate against exchange truth."""
        rows = self._managed_group_rows(symbol, side, dual_side)
        if not rows:
            if exchange_quantity not in (None, Decimal("0")):
                raise RuntimeError("EXCHANGE_POSITION_WITHOUT_MANAGED_LOTS")
            return Decimal("0")
        total = Decimal("0")
        for row in rows:
            signal_id = str(row["signal_id"])
            reservation = self.ledger.get_risk_reservation(signal_id)
            if reservation is None or reservation.get("status") != "ACTIVE":
                raise RuntimeError(f"MANAGED_LOT_RESERVATION_NOT_ACTIVE:{signal_id}")
            state_row = self.ledger.get_position_management_state(signal_id)
            if state_row is None or state_row["state"].get("closed"):
                raise RuntimeError(f"MANAGED_LOT_STATE_MISSING_OR_CLOSED:{signal_id}")
            managed_quantity = _decimal(row.get("quantity"), "managed.quantity")
            state_quantity = _decimal(state_row["state"].get("quantity"), "state.quantity")
            if abs(managed_quantity - state_quantity) > Decimal("1e-10"):
                raise RuntimeError(f"MANAGED_LOT_QUANTITY_PROJECTION_MISMATCH:{signal_id}")
            total += managed_quantity
        if exchange_quantity is not None and abs(total - exchange_quantity) > Decimal("1e-9"):
            raise RuntimeError(
                f"AGGREGATE_POSITION_QUANTITY_MISMATCH:local={total}:exchange={exchange_quantity}"
            )
        return total

    def _assert_persisted_state_matches(self, state: ManagedPositionState, *,
                                        require_partial_pending: bool = False) -> dict[str, Any]:
        row = self.ledger.get_position_management_state(state.signal_id)
        if row is None:
            raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        raw = row["state"]
        if str(raw.get("symbol", "")).upper() != state.symbol.upper() or str(
            raw.get("side", "")).upper() != state.side:
            raise RuntimeError("PERSISTED_POSITION_MANAGEMENT_IDENTITY_MISMATCH")
        comparisons = (
            ("quantity", state.quantity), ("entry_price", state.entry_price),
            ("current_stop", state.current_stop),
            ("initial_risk_per_unit", state.initial_risk_per_unit),
        )
        for field, expected in comparisons:
            if field not in raw or abs(_decimal(raw[field], field) - expected) > Decimal("1e-10"):
                raise RuntimeError(f"STALE_POSITION_MANAGEMENT_STATE:{field}")
        if raw.get("closed"):
            raise RuntimeError("MANAGED_POSITION_ALREADY_CLOSED")
        if require_partial_pending and raw.get("partial_tp_done"):
            raise RuntimeError("PARTIAL_TAKE_PROFIT_ALREADY_CONFIRMED")
        return row

    def _assert_state_matches_exchange(self, state: ManagedPositionState,
                                       *, dual_side: bool, tolerance: Decimal = Decimal("1e-10")) -> Decimal:
        exchange_qty = self._position_quantity(state.symbol, state.side, dual_side)
        if exchange_qty <= 0:
            raise RuntimeError("MANAGED_POSITION_NOT_OPEN_ON_EXCHANGE")
        group_qty = self._assert_group_projection(state.symbol, state.side, dual_side)
        if abs(exchange_qty - group_qty) > tolerance:
            raise RuntimeError(
                f"AGGREGATE_POSITION_QUANTITY_MISMATCH:local={group_qty}:exchange={exchange_qty}"
            )
        # The individual state still owns only its own lot, not the aggregate.
        if state.quantity <= 0 or state.quantity > group_qty + tolerance:
            raise RuntimeError("MANAGED_LOT_QUANTITY_OUTSIDE_AGGREGATE")
        return exchange_qty

    _RECOVERY_TERMINAL_NO_FILL = {"CANCELED", "CANCELLED", "EXPIRED", "REJECTED"}
    _RECOVERY_TRIGGERED = {"TRIGGERED", "FINISHED", "EXECUTED", "FILLED"}

    @staticmethod
    def _normalize_algo_update(order: dict[str, Any]) -> dict[str, Any]:
        """Normalize REST Algo and ALGO_UPDATE stream field names to one shape."""
        return {
            "algoId": order.get("algoId", order.get("aid")),
            "clientAlgoId": order.get("clientAlgoId", order.get("clientAlgoID", order.get("caid", ""))),
            "symbol": order.get("symbol", order.get("s", "")),
            "side": order.get("side", order.get("S", "")),
            "positionSide": order.get("positionSide", order.get("ps", "BOTH")),
            "type": order.get("type", order.get("orderType", order.get("o", ""))),
            "algoStatus": order.get("algoStatus", order.get("X", order.get("status", ""))),
            "quantity": order.get("quantity", order.get("origQty", order.get("totalQty", order.get("q")))),
            "triggerPrice": order.get("triggerPrice", order.get("stopPrice", order.get("tp"))),
            "executedQty": order.get("executedQty", order.get("executed_quantity", order.get("aq", "0"))),
            "actualOrderId": order.get("actualOrderId", order.get("ai", "")),
            "reduceOnly": order.get("reduceOnly", order.get("R", False)),
            "closePosition": order.get("closePosition", order.get("cp", False)),
            "workingType": order.get("workingType", order.get("wt", "")),
            "priceProtect": order.get("priceProtect", order.get("priceProtected", order.get("pP"))),
        }

    def _algo_stream_evidence(self, *, symbol: str, client_algo_id: str) -> dict[str, Any] | None:
        """Return the latest durable ALGO_UPDATE body for an exact DIVA client ID."""
        matches: list[tuple[int, dict[str, Any]]] = []
        for row in self.ledger.user_stream_orders():
            if str(row.get("order_kind", "")).upper() != "ALGO":
                continue
            if str(row.get("symbol", "")).upper() != symbol.upper():
                continue
            try:
                raw = json.loads(row.get("payload_json") or "{}")
            except (TypeError, ValueError):
                continue
            if not isinstance(raw, dict):
                continue
            normalized = self._normalize_algo_update(raw)
            if str(normalized.get("clientAlgoId", "")) != client_algo_id:
                continue
            if str(normalized.get("symbol", "")).upper() != symbol.upper():
                continue
            matches.append((int(row.get("event_time_ms") or 0), normalized))
        if not matches:
            return None
        return max(matches, key=lambda item: item[0])[1]

    def _load_protection_source(self, *, symbol: str, client_algo_id: str) -> tuple[dict[str, Any], str]:
        """Query terminal/active source protection; stream evidence is fallback only for -2013."""
        try:
            result = self.client.get_algo_order(client_algo_id=client_algo_id)
            if not isinstance(result, dict):
                raise RuntimeError("Malformed Algo order query response")
            return self._normalize_algo_update(result), "REST_QUERY"
        except BinancePrivateApiError as exc:
            if exc.code != -2013:
                raise
            # A not-found response is not itself proof of cancellation or flatness.
            open_orders = self.client.get_open_algo_orders(symbol)
            if any(
                str(item.get("clientAlgoId", item.get("clientAlgoID", ""))) == client_algo_id
                for item in open_orders
            ):
                raise RuntimeError("ALGO_QUERY_NOT_FOUND_BUT_ORDER_APPEARS_OPEN") from exc
            event = self._algo_stream_evidence(symbol=symbol, client_algo_id=client_algo_id)
            if event is None:
                raise RuntimeError("PROTECTION_TERMINAL_STATE_UNPROVEN") from exc
            return event, "USER_DATA_STREAM_TERMINAL_EVENT"

    def _assert_recovery_observation(
        self, *, symbol: str, side: str, rows: list[dict[str, Any]],
        flat: bool = False,
    ) -> set[tuple[str, str]]:
        """Require connected stream, fresh sequential REST snapshot and only known protection/flat gaps."""
        stream = self.ledger.get_user_stream_state()
        if stream.get("status") != "CONNECTED":
            raise RuntimeError("PROTECTION_RECOVERY_USER_STREAM_NOT_CONNECTED")
        reconciliation = self.ledger.get_reconciliation_state()
        captured = reconciliation.get("captured_at_ms")
        now = int(self.clock_ms())
        if (not isinstance(captured, int) or captured > now
                or now - captured > self.max_account_snapshot_age_ms):
            raise RuntimeError("PROTECTION_RECOVERY_RECONCILIATION_STALE")
        try:
            detail = json.loads(reconciliation.get("detail_json") or "{}")
        except (TypeError, ValueError):
            raise RuntimeError("PROTECTION_RECOVERY_RECONCILIATION_DETAIL_INVALID")
        if not isinstance(detail, dict) or detail.get("event_during_snapshot") is True:
            raise RuntimeError("PROTECTION_RECOVERY_RECONCILIATION_NOT_SEQUENTIAL")
        if detail.get("snapshot_is_sequential_rest") is not True:
            raise RuntimeError("PROTECTION_RECOVERY_REQUIRES_SEQUENTIAL_REST_SNAPSHOT")
        watermark = detail.get("stream_event_watermark_ms")
        last_event = int(stream.get("last_event_at_ms") or 0)
        if not isinstance(watermark, int) or watermark != last_event:
            raise RuntimeError("PROTECTION_RECOVERY_STREAM_EVENT_NOT_RECONCILED")

        allowed_signal_ids = {str(row["signal_id"]) for row in rows}
        gaps: set[tuple[str, str]] = set()
        discrepancies = detail.get("discrepancies", [])
        if not isinstance(discrepancies, list):
            raise RuntimeError("PROTECTION_RECOVERY_DISCREPANCIES_INVALID")
        for item in discrepancies:
            if not isinstance(item, dict):
                raise RuntimeError("PROTECTION_RECOVERY_DISCREPANCY_INVALID")
            code = str(item.get("code", ""))
            item_symbol = str(item.get("symbol", "")).upper()
            item_side = str(item.get("side", "")).upper()
            if code == "POSITION_MISSING_PROTECTION":
                role = str(item.get("role", "")).upper()
                signal_id = str(item.get("signal_id", ""))
                if (item_symbol != symbol.upper() or item_side != side.upper()
                        or signal_id not in allowed_signal_ids
                        or role not in {"STOP_LOSS", "TAKE_PROFIT"}):
                    raise RuntimeError("PROTECTION_RECOVERY_HAS_UNRELATED_ACCOUNT_DISCREPANCY")
                gaps.add((signal_id, role))
            elif flat and code == "LOCAL_POSITION_NOT_ON_EXCHANGE":
                signal_id = str(item.get("signal_id", ""))
                if (item_symbol != symbol.upper() or item_side != side.upper()
                        or signal_id not in allowed_signal_ids):
                    raise RuntimeError("PROTECTION_RECOVERY_FLAT_DISCREPANCY_IDENTITY_MISMATCH")
            else:
                raise RuntimeError(f"PROTECTION_RECOVERY_BLOCKED_BY_{code or 'UNKNOWN_DISCREPANCY'}")
        return gaps

    def _protection_expected_fields(
        self, *, signal_id: str, role: str, state: dict[str, Any], managed: dict[str, Any],
        dual: bool,
    ) -> dict[str, Any]:
        symbol = str(managed.get("symbol", state.get("symbol", ""))).upper()
        side = str(state.get("side", managed.get("signal_side", ""))).upper()
        position_side = self._position_side_param(side, dual)
        quantity = _decimal(state.get("quantity"), "managed state quantity")
        trigger = _decimal(
            state.get("current_stop") if role == "STOP_LOSS" else managed.get("take_profit"),
            f"{role.lower()} trigger",
        )
        pointer = "stop_algo_client_id" if role == "STOP_LOSS" else "take_profit_algo_client_id"
        client_id = str(state.get(pointer) or self.ledger.deterministic_client_id(signal_id, role))
        return {
            "signal_id": signal_id, "symbol": symbol, "side": side,
            "position_side": position_side, "dual_side_position": dual,
            "quantity": quantity, "trigger_price": trigger,
            "client_algo_id": client_id,
            "order_type": "STOP_MARKET" if role == "STOP_LOSS" else "TAKE_PROFIT_MARKET",
            "order_side": "SELL" if side == "LONG" else "BUY",
            "role": role,
        }

    def _validate_recovery_algo_identity(self, order: dict[str, Any], expected: dict[str, Any]) -> bool:
        """Validate both active and terminal Algo records against an exact managed allocation."""
        try:
            normalized = self._normalize_algo_update(order)
            quantity = _decimal(normalized.get("quantity"), "algo quantity")
            trigger = _decimal(normalized.get("triggerPrice"), "algo triggerPrice")
        except (ValueError, TypeError):
            return False
        if (str(normalized.get("symbol", "")).upper() != expected["symbol"]
                or str(normalized.get("clientAlgoId", "")) != expected["client_algo_id"]
                or str(normalized.get("side", "")).upper() != expected["order_side"]
                or str(normalized.get("positionSide", "BOTH")).upper() != expected["position_side"]
                or str(normalized.get("type", "")).upper() != expected["order_type"]
                or quantity != expected["quantity"] or trigger != expected["trigger_price"]):
            return False
        if _bool(normalized.get("closePosition", False)):
            return False
        reduce_only = _bool(normalized.get("reduceOnly", False))
        if reduce_only != (not expected["dual_side_position"]):
            return False
        working = str(normalized.get("workingType", "") or "").upper()
        if not working or working != self.working_type:
            return False
        price_protect = normalized.get("priceProtect")
        if price_protect in (None, "") or _bool(price_protect) != self.price_protect:
            return False
        return True

    def _verify_group_protections_except(
        self, *, rows: list[dict[str, Any]], dual: bool,
        allowed_gaps: set[tuple[str, str]], target: tuple[str, str],
    ) -> None:
        """Verify every non-target sibling leg; only proven terminal no-fill gaps may be skipped."""
        for row in rows:
            signal_id = str(row["signal_id"])
            state_row = self.ledger.get_position_management_state(signal_id)
            if state_row is None:
                raise RuntimeError(f"PROTECTION_RECOVERY_SIBLING_STATE_MISSING:{signal_id}")
            state = state_row["state"]
            for role in ("STOP_LOSS", "TAKE_PROFIT"):
                if (signal_id, role) == target:
                    continue
                expected = self._protection_expected_fields(
                    signal_id=signal_id, role=role, state=state, managed=row, dual=dual,
                )
                try:
                    order = self.client.get_algo_order(client_algo_id=expected["client_algo_id"])
                except BinancePrivateApiError as exc:
                    if exc.code != -2013:
                        raise
                    order = None
                if order is not None:
                    if (self._validate_recovery_algo_identity(order, expected)
                            and is_quantity_scoped_order_valid(
                                order, expected_quantity=expected["quantity"], dual_side_position=dual,
                                expected_position_side=expected["position_side"],
                                expected_order_side=expected["order_side"], expected_type=expected["order_type"],
                                expected_symbol=expected["symbol"],
                                expected_client_algo_id=expected["client_algo_id"],
                                expected_trigger_price=expected["trigger_price"],
                            )):
                        continue
                    normalized = self._normalize_algo_update(order)
                    status = str(normalized.get("algoStatus", "")).upper()
                    executed = _decimal(normalized.get("executedQty", "0") or "0", "sibling executedQty")
                    if ((signal_id, role) in allowed_gaps
                            and status in self._RECOVERY_TERMINAL_NO_FILL
                            and executed == 0 and not normalized.get("actualOrderId")):
                        continue
                    if status in self._RECOVERY_TRIGGERED or normalized.get("actualOrderId") or executed > 0:
                        raise RuntimeError(f"PROTECTION_RECOVERY_SIBLING_TRIGGERED:{signal_id}:{role}")
                    raise RuntimeError(f"PROTECTION_RECOVERY_SIBLING_PROTECTION_INVALID:{signal_id}:{role}")
                # REST -2013 alone is not proof of a sibling's cancellation. Require
                # the exact gap in the captured reconciliation and durable stream evidence.
                if (signal_id, role) not in allowed_gaps:
                    raise RuntimeError(f"PROTECTION_RECOVERY_UNEXPECTED_SIBLING_GAP:{signal_id}:{role}")
                stream_source = self._algo_stream_evidence(
                    symbol=expected["symbol"], client_algo_id=expected["client_algo_id"],
                )
                if (stream_source is None or not self._validate_recovery_algo_identity(stream_source, expected)
                        or str(stream_source.get("algoStatus", "")).upper() not in self._RECOVERY_TERMINAL_NO_FILL
                        or _decimal(stream_source.get("executedQty", "0") or "0", "sibling stream executedQty") != 0
                        or stream_source.get("actualOrderId")):
                    raise RuntimeError(f"PROTECTION_RECOVERY_SIBLING_GAP_UNPROVEN:{signal_id}:{role}")

    def recover_terminal_protection(self, signal_id: str, role: str) -> dict[str, Any]:
        """Recover one missing STOP/TP only after terminal no-fill proof and exact position reconciliation.

        Triggered Algo orders are deliberately routed to the existing fill reducer; this
        method never replaces a triggered or partially filled protective order.
        """
        role = str(role).upper()
        if role not in {"STOP_LOSS", "TAKE_PROFIT"}:
            raise ValueError("role must be STOP_LOSS or TAKE_PROFIT")
        managed_rows = [row for row in self.ledger.list_managed_positions(status="OPEN")
                        if str(row.get("signal_id")) == signal_id]
        state_row = self.ledger.get_position_management_state(signal_id)
        reservation = self.ledger.get_risk_reservation(signal_id)
        if len(managed_rows) != 1 or state_row is None or reservation is None or reservation.get("status") != "ACTIVE":
            self._halt(f"PROTECTION_RECOVERY_MANAGED_ALLOCATION_INVALID:{signal_id}")
            raise RuntimeError("PROTECTION_RECOVERY_MANAGED_ALLOCATION_INVALID")
        managed = managed_rows[0]
        state = state_row["state"]
        symbol = str(managed["symbol"]).upper()
        side = str(managed.get("signal_side", "")).upper()
        position_side = str(managed.get("position_side", "BOTH")).upper()
        if state.get("closed") or side not in {"LONG", "SHORT"}:
            raise RuntimeError("PROTECTION_RECOVERY_POSITION_NOT_OPEN")
        self.client.sync_server_time()
        dual = self._dual_side()
        if position_side != self._position_side_param(side, dual):
            self._halt(f"PROTECTION_RECOVERY_POSITION_MODE_MISMATCH:{symbol}")
            raise RuntimeError("PROTECTION_RECOVERY_POSITION_MODE_MISMATCH")
        rows = self._managed_group_rows(symbol, side, dual)
        target = (signal_id, role)
        expected = self._protection_expected_fields(
            signal_id=signal_id, role=role, state=state, managed=managed, dual=dual,
        )
        exchange_quantity = self._position_quantity(symbol, side, dual)
        allowed_gaps = self._assert_recovery_observation(
            symbol=symbol, side=side, rows=rows, flat=(exchange_quantity == 0),
        )
        if exchange_quantity == 0:
            # No replacement is appropriate for a flat exchange position. Existing
            # finalization code cleans only this DIVA group's linked orders/reservations.
            finalized = self.finalize_if_flat(signal_id)
            return {"status": "POSITION_FLAT_FINALIZED" if finalized else "POSITION_FLAT_FINALIZATION_PENDING",
                    "signal_id": signal_id, "role": role, "replacement_submitted": False}
        # A prior successful recovery can race the next account snapshot. Check the
        # current persisted pointer first so a fresh active exact order is an idempotent
        # no-op even if the old missing-protection discrepancy has not yet been cleared.
        try:
            existing = self.client.get_algo_order(client_algo_id=expected["client_algo_id"])
        except BinancePrivateApiError as exc:
            if exc.code != -2013:
                raise
            existing = None
        if (existing is not None and self._validate_recovery_algo_identity(existing, expected)
                and is_quantity_scoped_order_valid(
                    existing, expected_quantity=expected["quantity"], dual_side_position=dual,
                    expected_position_side=expected["position_side"],
                    expected_order_side=expected["order_side"], expected_type=expected["order_type"],
                    expected_symbol=symbol, expected_client_algo_id=expected["client_algo_id"],
                    expected_trigger_price=expected["trigger_price"],
                )):
            self.ledger.record_order(
                client_id=expected["client_algo_id"], signal_id=signal_id, symbol=symbol,
                role=role, order_kind="ALGO", status=str(existing.get("algoStatus", "NEW")),
                exchange_order_id=existing.get("algoId"), payload=dict(existing),
            )
            return {"status": "ALREADY_PROTECTED", "signal_id": signal_id, "role": role}
        if target not in allowed_gaps:
            self._halt(f"PROTECTION_RECOVERY_GAP_NOT_IN_FRESH_RECONCILIATION:{signal_id}:{role}")
            raise RuntimeError("PROTECTION_RECOVERY_GAP_NOT_IN_FRESH_RECONCILIATION")

        try:
            source, evidence_source = self._load_protection_source(
                symbol=symbol, client_algo_id=expected["client_algo_id"],
            )
        except Exception as exc:
            self._halt(f"PROTECTION_RECOVERY_SOURCE_UNVERIFIED:{signal_id}:{role}:{exc}")
            raise
        if not self._validate_recovery_algo_identity(source, expected):
            self._halt(f"PROTECTION_RECOVERY_SOURCE_IDENTITY_MISMATCH:{signal_id}:{role}")
            raise RuntimeError("PROTECTION_RECOVERY_SOURCE_IDENTITY_MISMATCH")
        source_status = str(source.get("algoStatus", "")).upper()
        executed = _decimal(source.get("executedQty", "0") or "0", "source executedQty")
        actual_order_id = str(source.get("actualOrderId") or "")
        if source_status in self._RECOVERY_TRIGGERED or actual_order_id or executed > 0:
            self._halt(f"PROTECTIVE_ORDER_TRIGGER_REQUIRES_FILL_RECONCILIATION:{signal_id}:{role}")
            self.ledger.record_event(
                "PROTECTIVE_RECOVERY_TRIGGERED_ORDER_DEFERRED", signal_id=signal_id, symbol=symbol,
                detail={"role": role, "client_algo_id": expected["client_algo_id"],
                        "algo_status": source_status, "actual_order_id_present": bool(actual_order_id),
                        "executed_quantity": str(executed),
                        "recovery": "DEFER_TO_PROTECTIVE_TRIGGER_FILL_REDUCER"},
            )
            return {"status": "TRIGGERED_REQUIRES_FILL_RECONCILIATION", "signal_id": signal_id,
                    "role": role, "replacement_submitted": False}
        if source_status not in self._RECOVERY_TERMINAL_NO_FILL:
            self._halt(f"PROTECTION_RECOVERY_SOURCE_NOT_TERMINAL:{signal_id}:{role}:{source_status}")
            raise RuntimeError("PROTECTION_RECOVERY_SOURCE_NOT_TERMINAL")
        self._assert_group_projection(symbol, side, dual, exchange_quantity=exchange_quantity)
        self._verify_group_protections_except(
            rows=rows, dual=dual, allowed_gaps=allowed_gaps, target=target,
        )

        action_id = "protection-recovery:" + hashlib.sha256(
            f"{signal_id}|{role}|{expected['client_algo_id']}".encode("utf-8")
        ).hexdigest()[:32]
        new_prefix = "DIVASL" if role == "STOP_LOSS" else "DIVATP"
        new_client_id = _client_id(new_prefix, action_id)
        evidence_json = json.dumps(source, sort_keys=True, separators=(",", ":"))
        payload = {
            "symbol": symbol, "side": side, "position_side": position_side,
            "dual_side_position": dual, "signal_id": signal_id, "role": role,
            "order_type": expected["order_type"], "order_side": expected["order_side"],
            "quantity": str(expected["quantity"]), "trigger_price": str(expected["trigger_price"]),
            "source_client_algo_id": expected["client_algo_id"],
            "source_algo_id": str(source.get("algoId") or ""),
            "source_status": source_status, "source_evidence_source": evidence_source,
            "source_evidence": source,
            "source_evidence_sha256": hashlib.sha256(evidence_json.encode("utf-8")).hexdigest(),
            "replacement_client_algo_id": new_client_id,
            "allowed_group_gaps": [
                {"signal_id": gap_signal, "role": gap_role}
                for gap_signal, gap_role in sorted(allowed_gaps)
            ],
            "post_attempted": False,
        }
        claimed = self.ledger.claim_position_management_action(
            action_id=action_id, signal_id=signal_id,
            action_kind="PROTECTIVE_ORDER_RECOVERY", payload=payload,
        )
        if not claimed:
            existing_action = self.ledger.get_position_management_action(action_id)
            if existing_action is None or existing_action.get("action_kind") != "PROTECTIVE_ORDER_RECOVERY":
                self._halt(f"PROTECTION_RECOVERY_GROUP_LOCKED:{symbol}:{position_side}")
                raise RuntimeError("PROTECTION_RECOVERY_GROUP_LOCKED")
        return self.reconcile_protective_order_recovery(action_id)

    def _recovery_source_evidence(self, action: dict[str, Any]) -> dict[str, Any]:
        payload = action["payload"]
        symbol = str(payload["symbol"]).upper()
        source_id = str(payload["source_client_algo_id"])
        try:
            source = self._normalize_algo_update(self.client.get_algo_order(client_algo_id=source_id))
        except BinancePrivateApiError as exc:
            if exc.code != -2013:
                raise
            # Prefer the latest durable stream observation when REST history no
            # longer retains the terminal order. This prevents stale persisted
            # CANCELED evidence from overriding a later TRIGGERED/fill event.
            latest_stream = self._algo_stream_evidence(symbol=symbol, client_algo_id=source_id)
            if latest_stream is not None:
                source = dict(latest_stream)
            else:
                source = dict(payload.get("source_evidence") or {})
                raw = json.dumps(source, sort_keys=True, separators=(",", ":"))
                digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
                if digest != str(payload.get("source_evidence_sha256", "")):
                    raise RuntimeError("PROTECTION_RECOVERY_DURABLE_SOURCE_EVIDENCE_HASH_MISMATCH") from exc
        if not self._validate_recovery_algo_identity(source, {
            "symbol": symbol, "client_algo_id": source_id,
            "side": str(payload["side"]).upper(),
            "position_side": str(payload["position_side"]).upper(),
            "order_type": str(payload["order_type"]).upper(),
            "order_side": str(payload["order_side"]).upper(),
            "quantity": _decimal(payload["quantity"], "recovery quantity"),
            "trigger_price": _decimal(payload["trigger_price"], "recovery trigger"),
            "dual_side_position": _bool(payload["dual_side_position"]),
        }):
            raise RuntimeError("PROTECTION_RECOVERY_DURABLE_SOURCE_IDENTITY_MISMATCH")
        status = str(source.get("algoStatus", "")).upper()
        executed = _decimal(source.get("executedQty", "0") or "0", "source executedQty")
        if status not in self._RECOVERY_TERMINAL_NO_FILL or executed != 0 or source.get("actualOrderId"):
            raise RuntimeError("PROTECTION_RECOVERY_SOURCE_NO_LONGER_TERMINAL_NO_FILL")
        return source

    def reconcile_protective_order_recovery(self, action_id: str) -> dict[str, Any]:
        """Query-first, deterministic, one-POST recovery for one terminal no-fill protective leg."""
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action.get("action_kind") != "PROTECTIVE_ORDER_RECOVERY":
            raise KeyError(action_id)
        if action.get("status") == "CONFIRMED":
            return {"status": "CONFIRMED", "duplicate": True, "payload": action["payload"]}
        payload = action["payload"]
        signal_id = str(action["signal_id"])
        symbol = str(payload["symbol"]).upper()
        side = str(payload["side"]).upper()
        role = str(payload["role"]).upper()
        dual = _bool(payload["dual_side_position"])
        quantity = _decimal(payload["quantity"], "recovery quantity")
        trigger = _decimal(payload["trigger_price"], "recovery trigger")
        replacement_id = str(payload["replacement_client_algo_id"])
        expected = {
            "symbol": symbol, "side": side,
            "position_side": str(payload["position_side"]).upper(),
            "dual_side_position": dual, "quantity": quantity,
            "trigger_price": trigger, "client_algo_id": replacement_id,
            "order_type": str(payload["order_type"]).upper(),
            "order_side": str(payload["order_side"]).upper(), "role": role,
        }
        try:
            self._recovery_source_evidence(action)
            if self.ledger.get_user_stream_state().get("status") != "CONNECTED":
                raise RuntimeError("PROTECTION_RECOVERY_USER_STREAM_NOT_CONNECTED")
            current_exchange_qty = self._position_quantity(symbol, side, dual)
            if current_exchange_qty == 0:
                finalized = self.finalize_if_flat(signal_id)
                self.ledger.update_position_management_action(
                    action_id=action_id, status="CONFIRMED",
                    payload_update={"result": "POSITION_FLAT_FINALIZED" if finalized else "POSITION_FLAT_FINALIZATION_PENDING",
                                    "replacement_submitted": False},
                )
                return {"status": "POSITION_FLAT_FINALIZED" if finalized else "POSITION_FLAT_FINALIZATION_PENDING",
                        "duplicate": False, "replacement_submitted": False}
            group_rows = self._managed_group_rows(symbol, side, dual)
            self._assert_group_projection(symbol, side, dual, exchange_quantity=current_exchange_qty)
            current_managed = next((row for row in group_rows if str(row["signal_id"]) == signal_id), None)
            current_state_row = self.ledger.get_position_management_state(signal_id)
            if current_managed is None or current_state_row is None:
                raise RuntimeError("PROTECTION_RECOVERY_MANAGED_ALLOCATION_DISAPPEARED")
            current_state = current_state_row["state"]
            current_expected = self._protection_expected_fields(
                signal_id=signal_id, role=role, state=current_state,
                managed=current_managed, dual=dual,
            )
            if (current_expected["quantity"] != quantity
                    or current_expected["trigger_price"] != trigger
                    or current_expected["client_algo_id"] not in {
                        str(payload["source_client_algo_id"]), replacement_id,
                    }):
                # The replacement pointer may already be persisted if the process
                # crashed between the state commit and marking the action CONFIRMED.
                # Accept either known ID, but never a third allocation.
                raise RuntimeError("PROTECTION_RECOVERY_ALLOCATION_CHANGED")
            stored_gaps = payload.get("allowed_group_gaps", [])
            if not isinstance(stored_gaps, list):
                raise RuntimeError("PROTECTION_RECOVERY_ALLOWED_GAPS_INVALID")
            allowed_group_gaps: set[tuple[str, str]] = set()
            for gap in stored_gaps:
                if not isinstance(gap, dict):
                    raise RuntimeError("PROTECTION_RECOVERY_ALLOWED_GAPS_INVALID")
                gap_signal = str(gap.get("signal_id", ""))
                gap_role = str(gap.get("role", "")).upper()
                if gap_signal not in {str(row["signal_id"]) for row in group_rows} or gap_role not in {"STOP_LOSS", "TAKE_PROFIT"}:
                    raise RuntimeError("PROTECTION_RECOVERY_ALLOWED_GAPS_OUTSIDE_GROUP")
                allowed_group_gaps.add((gap_signal, gap_role))
            allowed_group_gaps.add((signal_id, role))
            self._verify_group_protections_except(
                rows=group_rows, dual=dual,
                allowed_gaps=allowed_group_gaps, target=(signal_id, role),
            )

            try:
                found = self.client.get_algo_order(client_algo_id=replacement_id)
            except BinancePrivateApiError as exc:
                if exc.code != -2013:
                    if _bool(payload.get("post_attempted", False)):
                        self.ledger.update_position_management_action(
                            action_id=action_id, status="SUBMISSION_UNKNOWN",
                            payload_update={"last_query_error_type": type(exc).__name__,
                                            "last_query_error_code": exc.code},
                        )
                        self._halt(f"PROTECTION_RECOVERY_QUERY_AMBIGUOUS:{symbol}:{signal_id}:{role}")
                        return {"status": "SUBMISSION_UNKNOWN", "duplicate": True,
                                "replacement_client_algo_id": replacement_id,
                                "automatic_retry": False}
                    raise
                found = None
            except Exception as exc:
                if _bool(payload.get("post_attempted", False)):
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={"last_query_error_type": type(exc).__name__},
                    )
                    self._halt(f"PROTECTION_RECOVERY_QUERY_AMBIGUOUS:{symbol}:{signal_id}:{role}")
                    return {"status": "SUBMISSION_UNKNOWN", "duplicate": True,
                            "replacement_client_algo_id": replacement_id,
                            "automatic_retry": False}
                raise
            if found is not None:
                if (not self._validate_recovery_algo_identity(found, expected)
                        or not is_quantity_scoped_order_valid(
                            found, expected_quantity=quantity, dual_side_position=dual,
                            expected_position_side=expected["position_side"],
                            expected_order_side=expected["order_side"], expected_type=expected["order_type"],
                            expected_symbol=symbol, expected_client_algo_id=replacement_id,
                            expected_trigger_price=trigger,
                        )):
                    raise RuntimeError("PROTECTION_RECOVERY_REPLACEMENT_ORDER_MISMATCH")
                verified = found
            else:
                if _bool(payload.get("post_attempted", False)):
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={"last_query_result": "REPLACEMENT_NOT_FOUND_AFTER_POST_ATTEMPT"},
                    )
                    self._halt(f"PROTECTION_RECOVERY_AMBIGUOUS_POST:{symbol}:{signal_id}:{role}")
                    return {"status": "SUBMISSION_UNKNOWN", "duplicate": True,
                            "replacement_client_algo_id": replacement_id,
                            "automatic_retry": False}
                # A not-yet-attempted action needs a fresh, event-consistent gap snapshot.
                fresh_rows = self._managed_group_rows(symbol, side, dual)
                fresh_gaps = self._assert_recovery_observation(
                    symbol=symbol, side=side, rows=fresh_rows,
                )
                if (signal_id, role) not in fresh_gaps:
                    raise RuntimeError("PROTECTION_RECOVERY_GAP_NO_LONGER_RECONCILED")
                self._assert_group_projection(symbol, side, dual, exchange_quantity=current_exchange_qty)
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMITTING",
                    payload_update={"post_attempted": True, "post_attempted_at_ms": int(self.clock_ms())},
                )
                params = build_quantity_scoped_protection_params(
                    symbol=symbol, position_direction=side,
                    position_side=expected["position_side"], dual_side_position=dual,
                    order_type=expected["order_type"], quantity=quantity,
                    trigger_price=trigger, working_type=self.working_type,
                    price_protect=self.price_protect, client_algo_id=replacement_id,
                )
                try:
                    post_response = self.client.new_algo_order(**params)
                except BinancePrivateApiError as exc:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_FAILED",
                        payload_update={"post_error_type": type(exc).__name__, "post_error_code": exc.code},
                    )
                    self._halt(f"PROTECTION_RECOVERY_POST_REJECTED:{symbol}:{signal_id}:{role}:{exc.code}")
                    return {"status": "SUBMISSION_FAILED", "automatic_retry": False}
                except Exception as exc:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={"post_error_type": type(exc).__name__},
                    )
                    self._halt(f"PROTECTION_RECOVERY_POST_AMBIGUOUS:{symbol}:{signal_id}:{role}")
                    return {"status": "SUBMISSION_UNKNOWN", "automatic_retry": False}
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMITTED",
                    payload_update={"post_acknowledgement_received": isinstance(post_response, dict)},
                )
                # A POST acknowledgement is not proof. Query the exact deterministic ID.
                try:
                    verified = self.client.get_algo_order(client_algo_id=replacement_id)
                except Exception as exc:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={"post_query_error_type": type(exc).__name__},
                    )
                    self._halt(f"PROTECTION_RECOVERY_POST_UNVERIFIED:{symbol}:{signal_id}:{role}")
                    return {"status": "SUBMISSION_UNKNOWN", "automatic_retry": False}
                if (not self._validate_recovery_algo_identity(verified, expected)
                        or not is_quantity_scoped_order_valid(
                            verified, expected_quantity=quantity, dual_side_position=dual,
                            expected_position_side=expected["position_side"],
                            expected_order_side=expected["order_side"], expected_type=expected["order_type"],
                            expected_symbol=symbol, expected_client_algo_id=replacement_id,
                            expected_trigger_price=trigger,
                        )):
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={"post_query_verification": "MISMATCH"},
                    )
                    self._halt(f"PROTECTION_RECOVERY_POST_MISMATCH:{symbol}:{signal_id}:{role}")
                    return {"status": "SUBMISSION_UNKNOWN", "automatic_retry": False}

            # A second REST position read after query-after-POST prevents accepting a
            # protection sized for a position that changed during the recovery window.
            final_exchange_qty = self._position_quantity(symbol, side, dual)
            final_group_qty = self._assert_group_projection(symbol, side, dual)
            if abs(final_exchange_qty - final_group_qty) > Decimal("1e-10"):
                raise RuntimeError("PROTECTION_RECOVERY_POST_POSITION_CHANGED")
            state_row = self.ledger.get_position_management_state(signal_id)
            if state_row is None:
                raise RuntimeError("PROTECTION_RECOVERY_STATE_DISAPPEARED_AFTER_POST")
            new_state = dict(state_row["state"])
            pointer = "stop_algo_client_id" if role == "STOP_LOSS" else "take_profit_algo_client_id"
            new_state[pointer] = replacement_id
            self.ledger.save_position_management_state(
                signal_id=signal_id, symbol=symbol, state=new_state,
                expected_version=int(state_row["version"]),
            )
            self.ledger.record_order(
                client_id=replacement_id, signal_id=signal_id, symbol=symbol,
                role=role, order_kind="ALGO",
                status=str(verified.get("algoStatus", "NEW")),
                exchange_order_id=verified.get("algoId"), payload=dict(verified),
            )
            self.ledger.update_position_management_action(
                action_id=action_id, status="CONFIRMED",
                payload_update={"verified_quantity": str(quantity),
                                "verified_trigger_price": str(trigger),
                                "replacement_client_algo_id": replacement_id,
                                "replacement_exchange_algo_id": verified.get("algoId"),
                                "source_terminal_status": payload.get("source_status"),
                                "post_query_verified": True},
            )
            self.ledger.record_event(
                "PROTECTIVE_ORDER_RECOVERY_CONFIRMED", signal_id=signal_id, symbol=symbol,
                detail={"role": role, "source_client_algo_id": payload["source_client_algo_id"],
                        "replacement_client_algo_id": replacement_id,
                        "quantity": str(quantity), "trigger_price": str(trigger),
                        "entry_halt_preserved": True},
            )
            return {"status": "CONFIRMED", "duplicate": False,
                    "signal_id": signal_id, "role": role,
                    "replacement_client_algo_id": replacement_id,
                    "quantity": str(quantity), "trigger_price": str(trigger)}
        except Exception as exc:
            self._halt(f"PROTECTION_RECOVERY_FAILED:{symbol}:{signal_id}:{role}:{type(exc).__name__}:{exc}")
            raise

    def recover_missing_protections(self) -> list[dict[str, Any]]:
        """Recover only gaps isolated by the latest fresh reconciliation; never clear entry halt."""
        state = self.ledger.get_reconciliation_state()
        try:
            detail = json.loads(state.get("detail_json") or "{}")
        except (TypeError, ValueError):
            return [{"status": "BLOCKED_RECONCILIATION_DETAIL_INVALID"}]
        discrepancies = detail.get("discrepancies", []) if isinstance(detail, dict) else []
        if (not isinstance(discrepancies, list) or not discrepancies
                or any(not isinstance(item, dict) or item.get("code") != "POSITION_MISSING_PROTECTION"
                       for item in discrepancies)):
            return []
        # Recover one role per reconciliation snapshot. A POST can generate a new
        # ALGO_UPDATE event or otherwise change exchange state; the next role must be
        # evaluated against a new sequential REST snapshot, never this stale list.
        item = discrepancies[0]
        signal_id = str(item.get("signal_id", ""))
        role = str(item.get("role", "")).upper()
        if not signal_id or role not in {"STOP_LOSS", "TAKE_PROFIT"}:
            return [{"status": "BLOCKED_PROTECTION_GAP_IDENTITY_INVALID"}]
        try:
            return [self.recover_terminal_protection(signal_id, role)]
        except Exception as exc:
            return [{"signal_id": signal_id, "role": role,
                     "status": "RECOVERY_ERROR", "error": str(exc)[:300]}]

    def submit_partial_take_profit(
        self,
        action: LifecycleAction,
        state: ManagedPositionState,
        *,
        market_step_size: Decimal,
        market_min_qty: Decimal,
    ) -> dict[str, Any]:
        """Submit a deterministic market reduce-only partial close exactly once.

        In one-way mode the request uses reduceOnly=true. In Hedge Mode that field is
        omitted and positionSide=LONG/SHORT is used, as Binance rejects reduceOnly in
        Hedge Mode. The fresh position amount is checked immediately before POST.
        """
        if action.kind != "PARTIAL_TP" or action.quantity is None:
            raise ValueError("action must be a PARTIAL_TP with quantity")
        if action.signal_id != state.signal_id or action.symbol.upper() != state.symbol.upper() or action.side != state.side:
            raise ValueError("lifecycle action and managed state do not match")
        step = _decimal(market_step_size, "market_step_size")
        minimum = _decimal(market_min_qty, "market_min_qty")
        if step <= 0 or minimum <= 0:
            raise ValueError("market lot size filters must be positive")
        prior_action = self.ledger.get_position_management_action(action.action_id)
        if prior_action is not None:
            return {"status": prior_action["status"], "duplicate": True,
                    "payload": prior_action["payload"]}
        self._assert_persisted_state_matches(state, require_partial_pending=True)
        self._assert_observation_ready()
        self.client.sync_server_time()
        dual = self._dual_side()
        live_group_qty = self._assert_state_matches_exchange(state, dual_side=dual)
        live_lot_qty = state.quantity
        initial_quantity = _decimal(state.initial_quantity, "initial_quantity")
        target_quantity = _floor_step(
            initial_quantity * state.partial_tp_fraction, step
        )
        if target_quantity < minimum:
            raise ValueError("PARTIAL_TP_TARGET_BELOW_MARKET_MIN_QTY")
        already_filled = _decimal(
            state.partial_tp_filled_quantity, "partial_tp_filled_quantity"
        )
        remaining_target = target_quantity - already_filled
        quantity = _floor_step(_decimal(action.quantity, "action.quantity"), step)
        # The lifecycle engine may still be running from an older state without a
        # snapped target. Prefer the exchange-step-aligned outstanding target.
        if state.partial_tp_target_quantity is not None:
            quantity = _floor_step(remaining_target, step)
        elif quantity > remaining_target:
            quantity = _floor_step(remaining_target, step)
        if quantity < minimum:
            raise ValueError("PARTIAL_CLOSE_BELOW_MARKET_MIN_QTY")
        if quantity >= live_lot_qty:
            raise ValueError("PARTIAL_CLOSE_MUST_LEAVE_A_NONZERO_MANAGED_LOT")
        if quantity > live_group_qty or quantity > live_lot_qty:
            raise ValueError("PARTIAL_CLOSE_EXCEEDS_MANAGED_LOT_OR_EXCHANGE_POSITION")

        client_order_id = _client_id("DIVAPC", action.action_id)
        payload = {
            "client_order_id": client_order_id,
            "requested_quantity": str(quantity),
            "market_step_size": str(step),
            "market_min_qty": str(minimum),
            "state_quantity": str(state.quantity),
            "group_quantity_before": str(live_group_qty),
            "initial_quantity": str(initial_quantity),
            "partial_tp_target_quantity": str(target_quantity),
            "partial_tp_filled_quantity": str(state.partial_tp_filled_quantity),
            "position_side": self._position_side_param(state.side, dual),
            "dual_side_position": dual,
            "side": state.side,
            "symbol": state.symbol,
            "reason": action.reason,
        }
        created = self.ledger.claim_position_management_action(
            action_id=action.action_id, signal_id=action.signal_id,
            action_kind=action.kind, payload=payload,
        )
        if not created:
            existing = self.ledger.get_position_management_action(action.action_id)
            if existing is None:
                self._halt(f"Concurrent lifecycle action blocked for {state.symbol}/{state.signal_id}")
                raise RuntimeError("LIFECYCLE_ACTION_ALREADY_PENDING")
            return {"status": existing["status"], "duplicate": True,
                    "payload": existing["payload"]}

        self.ledger.update_position_management_action(
            action_id=action.action_id, status="SUBMITTING",
        )
        try:
            # Re-read the durable state, stream/reconciliation gate, and exchange
            # quantity after preparation; another worker may have acted meanwhile.
            self._assert_persisted_state_matches(state, require_partial_pending=True)
            self._assert_observation_ready()
            self._assert_state_matches_exchange(state, dual_side=dual)
            params: dict[str, Any] = {
                "symbol": state.symbol,
                "side": "SELL" if state.side == "LONG" else "BUY",
                "type": "MARKET",
                "quantity": quantity,
                "newClientOrderId": client_order_id,
                "newOrderRespType": "RESULT",
                "positionSide": self._position_side_param(state.side, dual),
            }
            if not dual:
                params["reduceOnly"] = True
            response = self.client.new_order(**params)
            if not isinstance(response, dict):
                raise RuntimeError("Malformed Binance partial-close order response")
        except BinancePrivateTransportError as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Ambiguous partial-close POST for {state.symbol}: {exc}")
            raise
        except BinancePrivateApiError as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_FAILED",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Partial-close order rejected for {state.symbol}: {exc}")
            raise
        except Exception as exc:
            # Unknown errors are treated as ambiguous; no duplicate POST is attempted.
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Partial-close order outcome unknown for {state.symbol}: {exc}")
            raise
        self.ledger.update_position_management_action(
            action_id=action.action_id, status="SUBMITTED",
            payload_update={"submit_response": response},
        )
        self.ledger.record_event(
            "PARTIAL_TP_ORDER_SUBMITTED", signal_id=state.signal_id, symbol=state.symbol,
            detail={"client_order_id": client_order_id, "quantity": str(quantity),
                    "exchange_order_id": response.get("orderId")},
        )
        return {"status": "SUBMITTED", "duplicate": False, "response": response,
                "client_order_id": client_order_id, "quantity": str(quantity)}

    def confirm_partial_take_profit(self, action_id: str) -> dict[str, Any]:
        """Confirm a partial close from REST order status plus live position quantity."""
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action["action_kind"] != "PARTIAL_TP":
            raise KeyError(f"Unknown PARTIAL_TP action: {action_id}")
        payload = action["payload"]
        client_order_id = str(payload.get("client_order_id", ""))
        symbol = str(payload.get("symbol", "")).upper()
        side = str(payload.get("side", "")).upper()
        if not client_order_id or not symbol or side not in {"LONG", "SHORT"}:
            self._halt("Partial-close action is missing durable exchange identifiers")
            raise RuntimeError("PARTIAL_CLOSE_ACTION_PAYLOAD_INCOMPLETE")
        self.client.sync_server_time()
        try:
            order = self.client.get_order(symbol, client_order_id=client_order_id)
        except BinancePrivateApiError as exc:
            if exc.code == -2013:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMISSION_UNKNOWN",
                    payload_update={"last_reconcile_error": "ORDER_NOT_FOUND"},
                )
                self._halt(f"Partial-close order not found for {symbol}; POST outcome unresolved")
                return {"status": "SUBMISSION_UNKNOWN", "order": None}
            raise
        status = str(order.get("status", "UNKNOWN")).upper()
        executed = _decimal(order.get("executedQty", "0"), "executedQty")
        requested = _decimal(payload.get("requested_quantity"), "requested_quantity")
        if executed < 0 or executed > requested + Decimal("1e-10"):
            self._halt(f"Invalid partial-close fill quantity for {symbol}")
            raise RuntimeError("PARTIAL_CLOSE_FILL_QUANTITY_INVALID")

        if status in {"NEW", "PARTIALLY_FILLED"}:
            # Market orders should not remain resting. Cancel any remainder and verify
            # the resulting terminal status before using the cumulative fill quantity.
            try:
                self.client.cancel_order(symbol, client_order_id=client_order_id)
            except BinancePrivateApiError as exc:
                if exc.code not in {-2011, -2013}:
                    raise
            order = self.client.get_order(symbol, client_order_id=client_order_id)
            status = str(order.get("status", "UNKNOWN")).upper()
            executed = _decimal(order.get("executedQty", "0"), "executedQty")
            if status not in TERMINAL_ORDER_STATES:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="PARTIALLY_FILLED",
                    payload_update={"last_order_status": status, "last_executed_quantity": str(executed)},
                )
                self._halt(f"Partial-close order remains nonterminal for {symbol}")
                return {"status": "PARTIALLY_FILLED", "order": order}

        if status not in TERMINAL_ORDER_STATES:
            self.ledger.update_position_management_action(
                action_id=action_id, status="SUBMITTED",
                payload_update={"last_order_status": status},
            )
            return {"status": "SUBMITTED", "order": order}

        if status == "FILLED" and abs(executed - requested) > Decimal("1e-10"):
            self._halt(f"Filled partial-close quantity differs from request for {symbol}")
            raise RuntimeError("PARTIAL_CLOSE_FILLED_QUANTITY_MISMATCH")
        if executed == 0:
            final_status = "REJECTED" if status == "REJECTED" else "TERMINAL_NO_FILL"
            self.ledger.update_position_management_action(
                action_id=action_id, status=final_status,
                payload_update={"final_order_status": status, "executed_quantity": "0"},
            )
            self._halt(f"Partial-close order terminal without fill for {symbol}: {status}")
            return {"status": final_status, "order": order}

        dual = _bool(payload.get("dual_side_position"))
        exchange_qty = self._position_quantity(symbol, side, dual)
        original_qty = _decimal(payload.get("state_quantity"), "state_quantity")
        group_before = _decimal(payload.get("group_quantity_before", original_qty), "group_quantity_before")
        expected_group_qty = group_before - executed
        lot_residual_qty = original_qty - executed
        if (expected_group_qty < 0 or lot_residual_qty <= 0
                or abs(exchange_qty - expected_group_qty) > Decimal("1e-9")):
            self._halt(
                f"Partial-close fill/aggregate mismatch for {symbol}: "
                f"expected_group={expected_group_qty} exchange={exchange_qty}"
            )
            raise RuntimeError("PARTIAL_CLOSE_POSITION_RECONCILIATION_MISMATCH")

        state_row = self.ledger.get_position_management_state(action["signal_id"])
        if state_row is None:
            self._halt(f"Missing persisted lifecycle state for {symbol}")
            raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        state = dict(state_row["state"])
        state["quantity"] = str(lot_residual_qty)
        initial_quantity = _decimal(
            payload.get("initial_quantity", state.get("initial_quantity", original_qty)),
            "initial_quantity",
        )
        cumulative_before = _decimal(
            state.get("partial_tp_filled_quantity", payload.get("partial_tp_filled_quantity", "0")),
            "partial_tp_filled_quantity",
        )
        cumulative_filled = cumulative_before + executed
        target_quantity = initial_quantity * _decimal(
            state.get("partial_tp_fraction", "0.5"), "partial_tp_fraction"
        )
        partial_target_quantity = _decimal(
            payload.get("partial_tp_target_quantity", target_quantity),
            "partial_tp_target_quantity",
        )
        state["initial_quantity"] = str(initial_quantity)
        state["partial_tp_target_quantity"] = str(partial_target_quantity)
        state["partial_tp_filled_quantity"] = str(cumulative_filled)
        target_complete = cumulative_filled + Decimal("1e-10") >= partial_target_quantity
        state["partial_tp_done"] = bool(target_complete)
        state["last_partial_close_order_id"] = client_order_id
        self.ledger.save_position_management_state(
            signal_id=action["signal_id"], symbol=symbol, state=state,
            expected_version=int(state_row["version"]),
        )
        position_side = str(payload.get("position_side", "BOTH"))
        self.ledger.update_managed_position(
            signal_id=action["signal_id"], symbol=symbol, position_side=position_side,
            quantity=str(lot_residual_qty),
        )
        final_status = "CONFIRMED" if target_complete else "PARTIAL_FILL_TERMINAL"
        self.ledger.update_position_management_action(
            action_id=action_id, status=final_status,
            payload_update={"final_order_status": status, "executed_quantity": str(executed),
                            "exchange_position_quantity": str(exchange_qty),
                            "managed_lot_remaining_quantity": str(lot_residual_qty)},
        )
        self.ledger.record_event(
            "PARTIAL_TP_FILL_CONFIRMED", signal_id=action["signal_id"], symbol=symbol,
            detail={"client_order_id": client_order_id, "executed_quantity": str(executed),
                    "remaining_position_quantity": str(lot_residual_qty),
                    "aggregate_exchange_position_quantity": str(exchange_qty),
                    "cumulative_partial_tp_filled": str(cumulative_filled),
                    "partial_tp_target_quantity": str(partial_target_quantity),
                    "partial_tp_done": target_complete},
        )
        protection = self.resize_protection_quantity(
            action["signal_id"], lot_residual_qty, source_action_id=action_id,
        )
        return {"status": final_status, "order": order, "executed_quantity": str(executed),
                "remaining_position_quantity": str(lot_residual_qty),
                "aggregate_exchange_position_quantity": str(exchange_qty),
                "partial_tp_target_complete": target_complete,
                "protection_resize": protection}

    def resize_protection_quantity(
        self, signal_id: str, quantity: Decimal | str, *, source_action_id: str,
        parent_action_id: str | None = None,
    ) -> dict[str, Any]:
        """Resize a managed lot's STOP and TP as one idempotent paired action."""
        qty = _decimal(quantity, "quantity")
        state_row = self.ledger.get_position_management_state(signal_id)
        managed = [row for row in self.ledger.list_managed_positions(status=None)
                   if row.get("signal_id") == signal_id]
        if qty <= 0 or state_row is None or len(managed) != 1:
            self._halt(f"Cannot resize protections for incomplete managed lot {signal_id}")
            raise RuntimeError("PROTECTION_RESIZE_POSITION_INVALID")
        state = dict(state_row["state"])
        symbol = str(state.get("symbol", "")).upper()
        side = str(state.get("side", "")).upper()
        if side not in {"LONG", "SHORT"} or abs(_decimal(state.get("quantity"), "quantity") - qty) > Decimal("1e-10"):
            self._halt(f"Local quantity mismatch during protection resize for {signal_id}")
            raise RuntimeError("PROTECTION_RESIZE_LOCAL_QUANTITY_MISMATCH")

        action_id = f"resize-protection:{signal_id}:{source_action_id}"
        prior = self.ledger.get_position_management_action(action_id)
        if prior is not None:
            if prior["status"] == "CONFIRMED":
                return {"status": "CONFIRMED", "duplicate": True, "payload": prior["payload"]}
            return self.reconcile_protection_resize(action_id)

        self.client.sync_server_time()
        dual = self._dual_side()
        position_side = self._position_side_param(side, dual)
        if str(managed[0].get("position_side", "BOTH")).upper() != position_side:
            self._halt(f"Position mode mismatch during protection resize for {symbol}")
            raise RuntimeError("PROTECTION_RESIZE_POSITION_MODE_MISMATCH")
        exchange_group_qty = self._position_quantity(symbol, side, dual)
        try:
            local_group_qty = self._assert_group_projection(symbol, side, dual)
        except Exception as exc:
            self._halt(f"Managed group projection mismatch during protection resize for {symbol}: {exc}")
            raise
        if abs(exchange_group_qty - local_group_qty) > Decimal("1e-10"):
            self._halt(f"Aggregate exchange quantity mismatch during protection resize for {symbol}")
            raise RuntimeError("PROTECTION_RESIZE_AGGREGATE_QUANTITY_MISMATCH")

        stop_price = _decimal(state.get("current_stop"), "current_stop")
        take_price = _decimal(managed[0].get("take_profit"), "take_profit")
        old_stop = str(state.get("stop_algo_client_id") or
                       self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"))
        old_take = str(state.get("take_profit_algo_client_id") or
                       self.ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"))
        new_stop = _client_id("DIVASL", action_id + ":STOP")
        new_take = _client_id("DIVATP", action_id + ":TAKE")
        payload = {
            "symbol": symbol, "side": side, "quantity": str(qty),
            "position_side": position_side, "dual_side_position": dual,
            "stop_trigger_price": str(stop_price), "take_profit_trigger_price": str(take_price),
            "old_stop_client_algo_id": old_stop, "old_take_client_algo_id": old_take,
            "new_stop_client_algo_id": new_stop, "new_take_client_algo_id": new_take,
        }
        if parent_action_id:
            payload["parent_action_id"] = parent_action_id
        claimed = self.ledger.claim_position_management_action(
            action_id=action_id, signal_id=signal_id,
            action_kind="RESIZE_PROTECTION", payload=payload,
        )
        if not claimed:
            prior = self.ledger.get_position_management_action(action_id)
            if prior is None:
                self._halt(f"Another lifecycle action blocks protection resize for {symbol}")
                raise RuntimeError("PROTECTION_RESIZE_ACTION_BLOCKED")
            if prior["status"] == "CONFIRMED":
                return {"status": "CONFIRMED", "duplicate": True, "payload": prior["payload"]}
        return self.reconcile_protection_resize(action_id)

    def reconcile_protection_resize(self, action_id: str) -> dict[str, Any]:
        """Query-first recovery for paired quantity-scoped protection replacements."""
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action.get("action_kind") != "RESIZE_PROTECTION":
            raise KeyError(action_id)
        if action["status"] == "CONFIRMED":
            return {"status": "CONFIRMED", "duplicate": True, "payload": action["payload"]}
        payload = action["payload"]
        symbol, side = str(payload["symbol"]).upper(), str(payload["side"]).upper()
        qty = _decimal(payload["quantity"], "quantity")
        dual = _bool(payload["dual_side_position"])
        position_side = str(payload["position_side"]).upper()
        if self._dual_side() != dual or position_side != self._position_side_param(side, dual):
            self._halt(f"Position mode changed during protection resize for {symbol}")
            raise RuntimeError("PROTECTION_RESIZE_POSITION_MODE_CHANGED")
        exchange_group_qty = self._position_quantity(symbol, side, dual)
        try:
            local_group_qty = self._assert_group_projection(symbol, side, dual)
        except Exception as exc:
            self._halt(f"Managed group projection changed during protection resize for {symbol}: {exc}")
            raise
        if abs(exchange_group_qty - local_group_qty) > Decimal("1e-10"):
            self._halt(f"Aggregate exchange position changed during protection resize for {symbol}")
            raise RuntimeError("PROTECTION_RESIZE_AGGREGATE_QUANTITY_MISMATCH")
        state_row = self.ledger.get_position_management_state(action["signal_id"])
        if state_row is None or abs(_decimal(state_row["state"].get("quantity"), "state.quantity") - qty) > Decimal("1e-10"):
            self._halt(f"Lifecycle state changed during protection resize for {symbol}")
            raise RuntimeError("PROTECTION_RESIZE_STATE_MISMATCH")

        specs = (
            ("STOP_LOSS", "STOP_MARKET", "stop_trigger_price", "new_stop_client_algo_id"),
            ("TAKE_PROFIT", "TAKE_PROFIT_MARKET", "take_profit_trigger_price", "new_take_client_algo_id"),
        )
        self.ledger.update_position_management_action(action_id=action_id, status="SUBMITTING")
        for role, order_type, trigger_key, id_key in specs:
            client_id = str(payload[id_key])
            try:
                order = self.client.get_algo_order(client_algo_id=client_id)
            except BinancePrivateApiError as exc:
                if exc.code != -2013:
                    self._halt(f"REST query for resized {role} failed: {exc}")
                    raise
                params = build_quantity_scoped_protection_params(
                    symbol=symbol, position_direction=side, position_side=position_side,
                    dual_side_position=dual, order_type=order_type, quantity=qty,
                    trigger_price=_decimal(payload[trigger_key], trigger_key),
                    working_type=self.working_type, price_protect=self.price_protect,
                    client_algo_id=client_id,
                )
                try:
                    self.client.new_algo_order(**params)
                except Exception as exc:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={f"{role.lower()}_submit_error": str(exc)},
                    )
                    self._halt(f"Ambiguous resized {role} submission for {symbol}: {exc}")
                    raise
                try:
                    order = self.client.get_algo_order(client_algo_id=client_id)
                except Exception as exc:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="SUBMISSION_UNKNOWN",
                        payload_update={f"{role.lower()}_query_error": str(exc)},
                    )
                    self._halt(f"Cannot verify resized {role} for {symbol}: {exc}")
                    raise
            except Exception as exc:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMISSION_UNKNOWN",
                    payload_update={f"{role.lower()}_query_error": str(exc)},
                )
                self._halt(f"Cannot query resized {role} for {symbol}: {exc}")
                raise
            if not is_quantity_scoped_order_valid(
                order, expected_quantity=qty, dual_side_position=dual,
                expected_position_side=position_side,
                expected_order_side="SELL" if side == "LONG" else "BUY",
                expected_type=order_type,
                expected_symbol=symbol,
                expected_client_algo_id=client_id,
                expected_trigger_price=_decimal(payload[trigger_key], trigger_key),
            ):
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMISSION_UNKNOWN",
                    payload_update={f"{role.lower()}_verification": "ORDER_FIELDS_MISMATCH"},
                )
                self._halt(f"Resized {role} failed exact REST verification for {symbol}")
                raise RuntimeError("PROTECTION_RESIZE_ORDER_VERIFICATION_FAILED")
            self.ledger.record_order(
                client_id=client_id, signal_id=action["signal_id"], symbol=symbol,
                role=role, order_kind="ALGO", status=str(order.get("algoStatus", "NEW")),
                exchange_order_id=order.get("algoId"), payload=dict(order),
            )

        # Do not cancel either old protection until both replacement orders are live.
        open_orders = self.client.get_open_algo_orders(symbol)
        old_pairs = (
            ("STOP_MARKET", payload["old_stop_client_algo_id"]),
            ("TAKE_PROFIT_MARKET", payload["old_take_client_algo_id"]),
        )
        for order_type, old_id in old_pairs:
            old = next((row for row in open_orders
                        if str(row.get("clientAlgoId", "")) == str(old_id)), None)
            if old is None:
                continue
            if (str(old.get("symbol", "")).upper() != symbol
                    or str(old.get("side", "")).upper() != ("SELL" if side == "LONG" else "BUY")
                    or str(old.get("positionSide", "BOTH")).upper() != position_side
                    or str(old.get("type", old.get("orderType", ""))).upper() != order_type):
                self._halt(f"Old protection identity mismatch; refusing cancellation for {symbol}")
                raise RuntimeError("PROTECTION_RESIZE_OLD_ORDER_IDENTITY_MISMATCH")
            try:
                self.client.cancel_algo_order(client_algo_id=str(old_id))
            except BinancePrivateApiError as exc:
                if exc.code not in {-2011, -2013}:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
                        payload_update={"old_cancel_error": str(exc)},
                    )
                    self._halt(f"Old protection cancellation unresolved for {symbol}: {exc}")
                    raise
        remaining_old = {str(row.get("clientAlgoId", "")) for row in self.client.get_open_algo_orders(symbol)}
        still_active = {str(payload["old_stop_client_algo_id"]),
                        str(payload["old_take_client_algo_id"])} & remaining_old
        if still_active:
            self.ledger.update_position_management_action(
                action_id=action_id, status="REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
                payload_update={"old_orders_still_active": sorted(still_active)},
            )
            self._halt(f"Old protections remain active for {symbol}: {sorted(still_active)}")
            return {"status": "REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING", "active_old_ids": sorted(still_active)}

        state_row = self.ledger.get_position_management_state(action["signal_id"])
        updated_state = dict(state_row["state"])
        updated_state["stop_algo_client_id"] = payload["new_stop_client_algo_id"]
        updated_state["take_profit_algo_client_id"] = payload["new_take_client_algo_id"]
        self.ledger.save_position_management_state(
            signal_id=action["signal_id"], symbol=symbol, state=updated_state,
            expected_version=int(state_row["version"]),
        )
        self.ledger.update_position_management_action(
            action_id=action_id, status="CONFIRMED",
            payload_update={"verified_quantity": str(qty), "old_orders_cancelled": True},
        )
        self.ledger.record_event(
            "POSITION_PROTECTION_RESIZED", signal_id=action["signal_id"], symbol=symbol,
            detail={"quantity": str(qty), "stop_client_algo_id": payload["new_stop_client_algo_id"],
                    "take_profit_client_algo_id": payload["new_take_client_algo_id"]},
        )
        return {"status": "CONFIRMED", "duplicate": False, "quantity": str(qty),
                "stop_client_algo_id": payload["new_stop_client_algo_id"],
                "take_profit_client_algo_id": payload["new_take_client_algo_id"]}

    def replace_stop(
        self,
        action: LifecycleAction,
        state: ManagedPositionState,
        *,
        tick_size: Decimal,
        mark_price: Decimal,
        old_client_algo_id: str | None = None,
    ) -> dict[str, Any]:
        """Create-and-verify a tighter quantity-scoped STOP before cancelling the prior STOP.

        The replacement is sized to the exact managed-lot quantity. It is confirmed
        active before the previous STOP is cancelled; unresolved cancellation halts
        new entries and preserves both orders for reconciliation.
        """
        if action.kind != "MOVE_STOP" or action.stop_price is None:
            raise ValueError("action must be MOVE_STOP with stop_price")
        if action.signal_id != state.signal_id or action.symbol.upper() != state.symbol.upper() or action.side != state.side:
            raise ValueError("lifecycle action and managed state do not match")
        prior_action = self.ledger.get_position_management_action(action.action_id)
        if prior_action is not None:
            if prior_action["status"] in {"CONFIRMED", "REPLACEMENT_NOT_ACTIVE",
                                          "STOP_TRIGGERED_PENDING_RECONCILIATION",
                                          "STOP_TRIGGERED_POSITION_NOT_FLAT",
                                          "STOP_TRIGGERED_POSITION_FLAT"}:
                return {"status": prior_action["status"], "duplicate": True,
                        "payload": prior_action.get("payload", {})}
            return self.reconcile_stop_replacement(action.action_id)
        self._assert_persisted_state_matches(state)
        tick = _decimal(tick_size, "tick_size")
        trigger = _decimal(action.stop_price, "stop_price")
        mark = _decimal(mark_price, "mark_price")
        if tick <= 0 or mark <= 0 or trigger <= 0 or trigger % tick != 0:
            raise ValueError("stop trigger, mark, and tick size must be positive and trigger tick-aligned")
        if state.side == "LONG":
            if trigger <= state.current_stop or trigger >= mark:
                raise ValueError("LONG stop replacement must tighten the stop below current mark")
        else:
            if trigger >= state.current_stop or trigger <= mark:
                raise ValueError("SHORT stop replacement must tighten the stop above current mark")
        self._assert_observation_ready()
        self.client.sync_server_time()
        dual = self._dual_side()
        self._assert_state_matches_exchange(state, dual_side=dual)
        persisted = self.ledger.get_position_management_state(state.signal_id)
        persisted_state = persisted.get("state", {}) if persisted else {}
        current_stop_id = str(
            persisted_state.get("stop_algo_client_id")
            or self.ledger.deterministic_client_id(state.signal_id, "STOP_LOSS")
        )
        # A caller may request replacement of the most recent managed stop, but must
        # never be able to cancel an unrelated/manual algo order on the same symbol.
        known_stop_ids = {current_stop_id, self.ledger.deterministic_client_id(state.signal_id, "STOP_LOSS")}
        for prior in self.ledger.list_position_management_actions(signal_id=state.signal_id):
            prior_payload = prior.get("payload", {})
            prior_stop_id = prior_payload.get("client_algo_id")
            if prior_stop_id:
                known_stop_ids.add(str(prior_stop_id))
        old_id = str(old_client_algo_id) if old_client_algo_id is not None else current_stop_id
        if old_id not in known_stop_ids:
            raise ValueError("old_client_algo_id is not a DIVA-managed stop for this signal")
        new_id = _client_id("DIVASL", action.action_id)
        payload = {
            "client_algo_id": new_id,
            "old_client_algo_id": old_id,
            "trigger_price": str(trigger),
            "tick_size": str(tick),
            "mark_price_at_submission": str(mark),
            "position_side": self._position_side_param(state.side, dual),
            "dual_side_position": dual,
            "quantity": str(state.quantity),
            "side": state.side,
            "symbol": state.symbol,
            "reason": action.reason,
        }
        created = self.ledger.claim_position_management_action(
            action_id=action.action_id, signal_id=action.signal_id,
            action_kind=action.kind, payload=payload,
        )
        if not created:
            existing = self.ledger.get_position_management_action(action.action_id)
            if existing is None:
                self._halt(f"Concurrent lifecycle action blocked for {state.symbol}/{state.signal_id}")
                raise RuntimeError("LIFECYCLE_ACTION_ALREADY_PENDING")
            # Duplicate requests never POST again. A completed action is immutable here;
            # a triggered protection is handled by account reconciliation/finalization.
            if existing["status"] in {"CONFIRMED", "REPLACEMENT_NOT_ACTIVE",
                                      "STOP_TRIGGERED_PENDING_RECONCILIATION",
                                      "STOP_TRIGGERED_POSITION_FLAT"}:
                return {"status": existing["status"], "duplicate": True,
                        "payload": existing.get("payload", {})}
            return self.reconcile_stop_replacement(action.action_id)

        self.ledger.update_position_management_action(action_id=action.action_id, status="SUBMITTING")
        try:
            # The account observation and live position are refreshed immediately before
            # the mutation; stale stream/reconciliation state blocks stop replacement.
            self._assert_observation_ready()
            self._assert_persisted_state_matches(state)
            self._assert_state_matches_exchange(state, dual_side=dual)
            params = build_quantity_scoped_protection_params(
                symbol=state.symbol,
                position_direction=state.side,
                position_side=self._position_side_param(state.side, dual),
                dual_side_position=dual,
                order_type="STOP_MARKET",
                quantity=state.quantity,
                trigger_price=trigger,
                working_type=self.working_type,
                price_protect=self.price_protect,
                client_algo_id=new_id,
            )
            response = self.client.new_algo_order(**params)
        except BinancePrivateTransportError as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Ambiguous stop replacement POST for {state.symbol}: {exc}")
            raise
        except BinancePrivateApiError as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_FAILED",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Stop replacement rejected for {state.symbol}: {exc}")
            raise
        except Exception as exc:
            # Unknown local/transport errors are conservative: Binance may have accepted POST.
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Stop replacement outcome unknown for {state.symbol}: {exc}")
            raise
        self.ledger.update_position_management_action(
            action_id=action.action_id, status="SUBMITTED",
            payload_update={"submit_response": response},
        )
        try:
            return self.reconcile_stop_replacement(action.action_id)
        except Exception as exc:
            # POST succeeded. Keep SUBMITTED so restart recovery queries the durable
            # clientAlgoId instead of misclassifying or resubmitting this order.
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMITTED",
                payload_update={"last_reconcile_error": str(exc)},
            )
            self._halt(f"Stop replacement reconciliation failed for {state.symbol}: {exc}")
            raise

    def reconcile_stop_replacement(self, action_id: str) -> dict[str, Any]:
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action["action_kind"] != "MOVE_STOP":
            raise KeyError(f"Unknown MOVE_STOP action: {action_id}")
        payload = action["payload"]
        symbol = str(payload.get("symbol", "")).upper()
        new_id = str(payload.get("client_algo_id", ""))
        old_id = str(payload.get("old_client_algo_id", ""))
        if not symbol or not new_id or not old_id:
            self._halt("Stop-replacement action is missing durable algo identifiers")
            raise RuntimeError("STOP_REPLACEMENT_PAYLOAD_INCOMPLETE")
        self.client.sync_server_time()
        try:
            new_order = self.client.get_algo_order(client_algo_id=new_id)
        except BinancePrivateApiError as exc:
            if exc.code == -2013:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMISSION_UNKNOWN",
                    payload_update={"last_reconcile_error": "NEW_STOP_NOT_FOUND"},
                )
                self._halt(f"Replacement STOP not found for {symbol}; previous STOP preserved")
                return {"status": "SUBMISSION_UNKNOWN", "new_order": None}
            raise
        new_status = str(new_order.get("algoStatus", "UNKNOWN")).upper()
        if new_status not in ACTIVE_ALGO_STATES:
            triggered = new_status in {"TRIGGERED", "FINISHED", "EXECUTED"}
            if triggered:
                dual = _bool(payload.get("dual_side_position"))
                live_qty = self._position_quantity(symbol, str(payload.get("side", "")).upper(), dual)
                self.ledger.update_position_management_action(
                    action_id=action_id, status="STOP_TRIGGERED_PENDING_RECONCILIATION",
                    payload_update={"new_algo_status": new_status,
                                    "position_quantity_after_trigger": str(live_qty)},
                )
                if live_qty == 0:
                    finalized = self.finalize_if_flat(action["signal_id"])
                    if finalized:
                        self.ledger.update_position_management_action(
                            action_id=action_id, status="STOP_TRIGGERED_POSITION_FLAT",
                            payload_update={"flat_finalization_confirmed": True},
                        )
                    return {"status": "STOP_TRIGGERED_POSITION_FLAT", "new_order": new_order,
                            "finalized": finalized}
                self._halt(f"Replacement STOP triggered but {symbol} is not flat; exchange reconciliation required")
                return {"status": "STOP_TRIGGERED_POSITION_NOT_FLAT", "new_order": new_order,
                        "position_quantity": str(live_qty)}
            self.ledger.update_position_management_action(
                action_id=action_id, status="REPLACEMENT_NOT_ACTIVE",
                payload_update={"new_algo_status": new_status},
            )
            self._halt(f"Replacement STOP is not active for {symbol}: {new_status}")
            return {"status": "REPLACEMENT_NOT_ACTIVE", "new_order": new_order}

        # The exchange acknowledgement is not sufficient: verify exact quantity,
        # side, positionSide and mode-specific reduce semantics before considering
        # this order to protect the managed lot.
        dual = _bool(payload.get("dual_side_position"))
        side = str(payload.get("side", "")).upper()
        expected_position_side = str(payload.get("position_side", "BOTH")).upper()
        expected_order_side = "SELL" if side == "LONG" else "BUY"
        expected_quantity = _decimal(payload.get("quantity"), "replacement_quantity")
        if new_status in ACTIVE_ALGO_STATES and not is_quantity_scoped_order_valid(
            new_order,
            expected_quantity=expected_quantity,
            dual_side_position=dual,
            expected_position_side=expected_position_side,
            expected_order_side=expected_order_side,
            expected_type="STOP_MARKET",
            expected_symbol=symbol,
            expected_client_algo_id=new_id,
            expected_trigger_price=_decimal(payload.get("trigger_price"), "trigger_price"),
        ):
            self.ledger.update_position_management_action(
                action_id=action_id, status="REPLACEMENT_NOT_ACTIVE",
                payload_update={"new_algo_status": new_status, "protection_validation": "MISMATCH"},
            )
            self._halt(f"Replacement STOP payload does not match managed quantity for {symbol}")
            return {"status": "REPLACEMENT_NOT_ACTIVE", "new_order": new_order,
                    "reason": "PROTECTION_ORDER_MISMATCH"}

        # Recheck the exchange position after the new Algo STOP is confirmed active.
        # The prior STOP may have triggered between preflight and POST; in that race,
        # finalize the now-flat managed position instead of leaving a dangling STOP.
        exchange_quantity = self._position_quantity(symbol, side, dual)
        expected_quantity = self._managed_group_quantity(symbol, side, dual)
        if exchange_quantity == 0:
            self.ledger.update_position_management_action(
                action_id=action_id, status="STOP_TRIGGERED_PENDING_RECONCILIATION",
                payload_update={"new_algo_status": new_status,
                                "position_quantity_after_trigger": "0",
                                "flat_detected_after_stop_submission": True},
            )
            finalized = self.finalize_if_flat(action["signal_id"])
            if finalized:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="STOP_TRIGGERED_POSITION_FLAT",
                    payload_update={"flat_finalization_confirmed": True},
                )
            return {"status": "STOP_TRIGGERED_POSITION_FLAT", "new_order": new_order,
                    "finalized": finalized}
        if abs(exchange_quantity - expected_quantity) > Decimal("1e-10"):
            self.ledger.update_position_management_action(
                action_id=action_id, status="STOP_REPLACEMENT_POSITION_MISMATCH",
                payload_update={"new_algo_status": new_status,
                                "expected_position_quantity": str(expected_quantity),
                                "exchange_position_quantity": str(exchange_quantity)},
            )
            self._halt(f"Position quantity changed during STOP replacement for {symbol}; both protections preserved")
            return {"status": "STOP_REPLACEMENT_POSITION_MISMATCH",
                    "new_order": new_order, "position_quantity": str(exchange_quantity)}

        # Cancel only the prior stop after the new stop is confirmed active and the
        # managed position still matches the expected exchange quantity.
        open_orders = self.client.get_open_algo_orders(symbol)
        open_ids = {
            str(row.get("clientAlgoId", row.get("clientAlgoID", "")))
            for row in open_orders if isinstance(row, dict)
        }
        if old_id in open_ids:
            try:
                self.client.cancel_algo_order(client_algo_id=old_id)
            except BinancePrivateApiError as exc:
                if exc.code not in {-2011, -2013}:
                    raise
            open_orders = self.client.get_open_algo_orders(symbol)
            open_ids = {
                str(row.get("clientAlgoId", row.get("clientAlgoID", "")))
                for row in open_orders if isinstance(row, dict)
            }
        if old_id in open_ids:
            self.ledger.update_position_management_action(
                action_id=action_id, status="REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
                payload_update={"new_algo_status": new_status, "old_stop_still_open": True},
            )
            self._halt(f"New STOP active but previous STOP cancellation is unresolved for {symbol}")
            return {"status": "REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING", "new_order": new_order}

        state_row = self.ledger.get_position_management_state(action["signal_id"])
        if state_row is None:
            self._halt(f"Missing lifecycle state after STOP replacement for {symbol}")
            raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        state = dict(state_row["state"])
        trigger = _decimal(payload.get("trigger_price"), "trigger_price")
        state["current_stop"] = str(trigger)
        state["stop_algo_client_id"] = new_id
        reason = str(payload.get("reason", "")).lower()
        if "breakeven" in reason:
            state["breakeven_done"] = True
        if "trailing" in reason:
            state["trailing_active"] = True
        self.ledger.save_position_management_state(
            signal_id=action["signal_id"], symbol=symbol, state=state,
            expected_version=int(state_row["version"]),
        )
        position_side = str(payload.get("position_side", "BOTH"))
        self.ledger.update_managed_position(
            signal_id=action["signal_id"], symbol=symbol, position_side=position_side,
            stop_loss=str(trigger),
        )
        self.ledger.update_position_management_action(
            action_id=action_id, status="CONFIRMED",
            payload_update={"new_algo_status": new_status, "old_stop_open": False},
        )
        self.ledger.record_event(
            "STOP_REPLACEMENT_CONFIRMED", signal_id=action["signal_id"], symbol=symbol,
            detail={"new_client_algo_id": new_id, "old_client_algo_id": old_id,
                    "trigger_price": str(trigger)},
        )
        return {"status": "CONFIRMED", "new_order": new_order,
                "client_algo_id": new_id, "old_client_algo_id": old_id}

    def submit_market_exit(
        self,
        action: LifecycleAction,
        state: ManagedPositionState,
        *,
        market_step_size: Decimal,
        market_min_qty: Decimal,
        from_rejected_ioc_stop: bool = False,
    ) -> dict[str, Any]:
        """Submit one fail-closed, full managed-position MARKET exit.

        The close quantity must exactly match the exchange position after market-lot
        flooring. One-way mode uses reduceOnly; Hedge Mode uses the explicit
        positionSide without reduceOnly. Existing protective stops remain in place
        until REST confirms the account is flat.
        """
        if action.kind not in {"STRUCTURAL_EXIT", "EMERGENCY_CLOSE"}:
            raise ValueError("action must be STRUCTURAL_EXIT or EMERGENCY_CLOSE")
        if (action.signal_id != state.signal_id or action.symbol.upper() != state.symbol.upper()
                or action.side != state.side):
            raise ValueError("lifecycle action and managed state do not match")
        if not action.reason.strip():
            raise ValueError("market exit requires a non-empty reason")
        if from_rejected_ioc_stop:
            intent = self.ledger.get_intent(state.signal_id)
            if (action.kind != "EMERGENCY_CLOSE" or action.reason != IOC_INITIAL_STOP_REJECTED
                    or intent is None or intent["status"] != "PROTECTION_INCOMPLETE"
                    or intent["last_error"] != IOC_INITIAL_STOP_REJECTED
                    or json.loads(intent["payload_json"])["signal"].get("entry_type") != "LIMIT_IOC"):
                raise RuntimeError("IOC_EMERGENCY_CLOSE_INTENT_NOT_VERIFIED")
        existing = self.ledger.get_position_management_action(action.action_id)
        if existing is not None:
            return {"status": existing["status"], "duplicate": True,
                    "payload": existing.get("payload", {})}
        step = _decimal(market_step_size, "market_step_size")
        minimum = _decimal(market_min_qty, "market_min_qty")
        if step <= 0 or minimum <= 0:
            raise ValueError("market lot size filters must be positive")
        self._assert_persisted_state_matches(state)
        # The very fill being contained invalidates the prior account snapshot.
        # This one-way recovery instead requires fresh exact REST lot evidence
        # before claim and again immediately before the reduce-only POST.
        if not from_rejected_ioc_stop:
            self._assert_observation_ready()
        self.client.sync_server_time()
        dual = self._dual_side()
        if from_rejected_ioc_stop and dual:
            raise RuntimeError("IOC_EMERGENCY_CLOSE_REQUIRES_ONE_WAY_MODE")
        live_group_qty = self._assert_state_matches_exchange(state, dual_side=dual)
        # A lifecycle exit owns one signal allocation only. Never flatten the
        # aggregate symbol/side position when sibling lots remain active.
        live_lot_qty = state.quantity
        quantity = _floor_step(live_lot_qty, step)
        if quantity < minimum:
            raise ValueError("FULL_EXIT_BELOW_MARKET_MIN_QTY")
        if quantity != live_lot_qty:
            self._halt(
                f"Managed lot quantity is not exactly market-lot aligned for {state.symbol}: "
                f"lot={live_lot_qty}, rounded={quantity}; emergency exit blocked"
            )
            raise RuntimeError("FULL_EXIT_QUANTITY_NOT_MARKET_LOT_ALIGNED")
        if quantity > live_group_qty:
            raise RuntimeError("FULL_EXIT_LOT_EXCEEDS_AGGREGATE_POSITION")

        client_order_id = _client_id("DIVAX", action.action_id)
        payload = {
            "client_order_id": client_order_id, "requested_quantity": str(quantity),
            "state_quantity": str(state.quantity), "market_step_size": str(step),
            "group_quantity_before": str(live_group_qty),
            "market_min_qty": str(minimum), "position_side": self._position_side_param(state.side, dual),
            "dual_side_position": dual, "side": state.side, "symbol": state.symbol,
            "reason": action.reason,
            **({"from_rejected_ioc_stop": True} if from_rejected_ioc_stop else {}),
        }
        created = self.ledger.claim_position_management_action(
            action_id=action.action_id, signal_id=action.signal_id,
            action_kind=action.kind, payload=payload,
        )
        if not created:
            existing = self.ledger.get_position_management_action(action.action_id)
            if existing is None:
                self._halt(f"Concurrent full-exit action blocked for {state.symbol}/{state.signal_id}")
                raise RuntimeError("LIFECYCLE_ACTION_ALREADY_PENDING")
            return {"status": existing["status"], "duplicate": True,
                    "payload": existing.get("payload", {})}

        self.ledger.update_position_management_action(
            action_id=action.action_id, status="SUBMITTING",
        )
        try:
            # Final fail-closed preflight immediately before the only POST.
            if not from_rejected_ioc_stop:
                self._assert_observation_ready()
            elif self._dual_side():
                raise RuntimeError("IOC_EMERGENCY_CLOSE_REQUIRES_ONE_WAY_MODE")
            self._assert_persisted_state_matches(state)
            self._assert_state_matches_exchange(state, dual_side=dual)
            params: dict[str, Any] = {
                "symbol": state.symbol,
                "side": "SELL" if state.side == "LONG" else "BUY",
                "type": "MARKET", "quantity": quantity,
                "newClientOrderId": client_order_id, "newOrderRespType": "RESULT",
                "positionSide": self._position_side_param(state.side, dual),
            }
            if not dual:
                params["reduceOnly"] = True
            response = self.client.new_order(**params)
            if not isinstance(response, dict):
                raise RuntimeError("Malformed Binance full-exit order response")
        except BinancePrivateTransportError as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Ambiguous full-exit POST for {state.symbol}: {exc}")
            raise
        except BinancePrivateApiError as exc:
            ambiguous = from_rejected_ioc_stop and (exc.status_code >= 500 or exc.code in {-1000, -1006, -1007})
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN" if ambiguous else "SUBMISSION_FAILED",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Full-exit order rejected for {state.symbol}: {exc}")
            raise
        except Exception as exc:
            self.ledger.update_position_management_action(
                action_id=action.action_id, status="SUBMISSION_UNKNOWN",
                payload_update={"submit_error": str(exc)},
            )
            self._halt(f"Full-exit order outcome unknown for {state.symbol}: {exc}")
            raise
        self.ledger.update_position_management_action(
            action_id=action.action_id, status="SUBMITTED",
            payload_update={"submit_response": response},
        )
        self.ledger.record_event(
            "MANAGED_POSITION_FULL_EXIT_SUBMITTED", signal_id=state.signal_id,
            symbol=state.symbol, detail={"client_order_id": client_order_id,
                                         "quantity": str(quantity), "reason": action.reason},
        )
        return {"status": "SUBMITTED", "duplicate": False, "response": response,
                "client_order_id": client_order_id, "quantity": str(quantity)}

    def confirm_market_exit(self, action_id: str) -> dict[str, Any]:
        """Confirm a full-exit MARKET order; keep protection/risk until verified flat."""
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action["action_kind"] not in {"STRUCTURAL_EXIT", "EMERGENCY_CLOSE"}:
            raise KeyError(f"Unknown full-exit action: {action_id}")
        if action["status"] in {"CLOSED_CONFIRMED", "CONFIRMED"}:
            return {"status": action["status"], "duplicate": True, "payload": action["payload"]}
        payload = action["payload"]
        symbol = str(payload.get("symbol", "")).upper()
        side = str(payload.get("side", "")).upper()
        client_order_id = str(payload.get("client_order_id", ""))
        if not symbol or side not in {"LONG", "SHORT"} or not client_order_id:
            self._halt("Full-exit action is missing durable exchange identifiers")
            raise RuntimeError("FULL_EXIT_ACTION_PAYLOAD_INCOMPLETE")
        self.client.sync_server_time()
        try:
            order = self.client.get_order(symbol, client_order_id=client_order_id)
        except BinancePrivateApiError as exc:
            if exc.code == -2013:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="SUBMISSION_UNKNOWN",
                    payload_update={"last_reconcile_error": "EXIT_ORDER_NOT_FOUND"},
                )
                self._halt(f"Full-exit order not found for {symbol}; POST outcome unresolved")
                return {"status": "SUBMISSION_UNKNOWN", "order": None}
            raise
        status = str(order.get("status", "UNKNOWN")).upper()
        if payload.get("from_rejected_ioc_stop") and (
            order.get("symbol") != symbol or order.get("clientOrderId") != client_order_id
            or order.get("positionSide") != "BOTH" or order.get("type") != "MARKET"
            or order.get("side") != ("SELL" if side == "LONG" else "BUY")
            or not _bool(order.get("reduceOnly"))
        ):
            self._halt(f"Unverified IOC emergency close response for {symbol}")
            raise RuntimeError("IOC_EMERGENCY_CLOSE_ORDER_IDENTITY_MISMATCH")
        executed = _decimal(order.get("executedQty", "0"), "executedQty")
        requested = _decimal(payload.get("requested_quantity"), "requested_quantity")
        if executed < 0 or executed > requested + Decimal("1e-10"):
            self._halt(f"Invalid full-exit fill quantity for {symbol}")
            raise RuntimeError("FULL_EXIT_FILL_QUANTITY_INVALID")
        if status in {"NEW", "PARTIALLY_FILLED"}:
            try:
                self.client.cancel_order(symbol, client_order_id=client_order_id)
            except BinancePrivateApiError as exc:
                if exc.code not in {-2011, -2013}:
                    raise
            order = self.client.get_order(symbol, client_order_id=client_order_id)
            status = str(order.get("status", "UNKNOWN")).upper()
            executed = _decimal(order.get("executedQty", "0"), "executedQty")
            if status not in TERMINAL_ORDER_STATES:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="EXIT_PENDING",
                    payload_update={"last_order_status": status, "last_executed_quantity": str(executed)},
                )
                self._halt(f"Full-exit order remains nonterminal for {symbol}")
                return {"status": "EXIT_PENDING", "order": order}
        if status not in TERMINAL_ORDER_STATES:
            self.ledger.update_position_management_action(
                action_id=action_id, status="EXIT_PENDING",
                payload_update={"last_order_status": status},
            )
            return {"status": "EXIT_PENDING", "order": order}
        if executed == 0:
            self.ledger.update_position_management_action(
                action_id=action_id, status="EXIT_TERMINAL_NO_FILL",
                payload_update={"final_order_status": status, "executed_quantity": "0"},
            )
            self._halt(f"Full-exit order terminal without fill for {symbol}: {status}")
            return {"status": "EXIT_TERMINAL_NO_FILL", "order": order}

        dual = _bool(payload.get("dual_side_position"))
        remaining = self._position_quantity(symbol, side, dual)
        original = _decimal(payload.get("state_quantity"), "state_quantity")
        group_before = _decimal(payload.get("group_quantity_before", original), "group_quantity_before")
        expected_group_remaining = group_before - executed
        lot_remaining = original - executed
        if (lot_remaining < 0 or expected_group_remaining < 0
                or abs(remaining - expected_group_remaining) > Decimal("1e-9")):
            self._halt(
                f"Full-exit aggregate quantity mismatch for {symbol}: "
                f"expected={expected_group_remaining} exchange={remaining}"
            )
            raise RuntimeError("FULL_EXIT_AGGREGATE_POSITION_MISMATCH")
        if lot_remaining == 0:
            finalized = self.finalize_managed_lot(
                action["signal_id"], expected_group_quantity=expected_group_remaining,
            )
            final_status = "CLOSED_CONFIRMED" if finalized else "LOT_FINALIZATION_PENDING"
            self.ledger.update_position_management_action(
                action_id=action_id, status=final_status,
                payload_update={"final_order_status": status, "executed_quantity": str(executed),
                                "exchange_position_quantity": str(remaining),
                                "aggregate_position_quantity": str(remaining),
                                "flat_finalization_confirmed": finalized},
            )
            if not finalized:
                self._halt(f"Managed lot closed but finalization is pending for {symbol}/{action['signal_id']}")
            return {"status": final_status, "order": order, "finalized": finalized,
                    "aggregate_position_quantity": str(remaining)}

        # Partial execution is not success. Update the remaining quantity only from
        # exchange truth, retain protective orders and reservation, and halt entries.
        state_row = self.ledger.get_position_management_state(action["signal_id"])
        if state_row is None:
            self._halt(f"Missing lifecycle state after partial full-exit for {symbol}")
            raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        state = dict(state_row["state"])
        state["quantity"] = str(lot_remaining)
        self.ledger.save_position_management_state(
            signal_id=action["signal_id"], symbol=symbol, state=state,
            expected_version=int(state_row["version"]),
        )
        intent = self.ledger.get_intent(action["signal_id"])
        managed_rows = [row for row in self.ledger.list_managed_positions(status=None)
                        if row["signal_id"] == action["signal_id"]]
        if intent is None or len(managed_rows) != 1:
            self._halt(f"Managed record mismatch after partial full-exit for {symbol}")
            raise RuntimeError("MANAGED_POSITION_RECORD_NOT_UNIQUE")
        self.ledger.update_managed_position(
            signal_id=action["signal_id"], symbol=symbol,
            position_side=str(managed_rows[0]["position_side"]), quantity=str(lot_remaining),
        )
        self.ledger.update_position_management_action(
            action_id=action_id, status="PARTIAL_EXIT_REMAINS",
            payload_update={"final_order_status": status, "executed_quantity": str(executed),
                            "exchange_position_quantity": str(remaining)},
        )
        protection = self.resize_protection_quantity(
            action["signal_id"], lot_remaining, source_action_id=action_id,
        )
        self._halt(
            f"Full-exit partially filled; lot {action['signal_id']} remains open at {lot_remaining}; "
            f"aggregate position is {remaining}; protections resized"
        )
        return {"status": "PARTIAL_EXIT_REMAINS", "order": order,
                "executed_quantity": str(executed), "remaining_quantity": str(lot_remaining),
                "aggregate_position_quantity": str(remaining),
                "protection_resize": protection}

    def reconcile_protective_trigger(self, action_id: str) -> dict[str, Any]:
        """Reconcile a triggered Algo from final REST fill truth, including cancel races.

        ALGO_UPDATE and the first matching-engine order response are observations, not
        final fill authority. If the triggered market order is still active, cancel its
        unfilled remainder and re-query it. The post-cancel cumulative executedQty is
        the only quantity used for local residual accounting.
        """
        action = self.ledger.get_position_management_action(action_id)
        if action is None or action.get("action_kind") != "PROTECTIVE_TRIGGER_RECONCILIATION":
            raise KeyError(action_id)
        if action["status"] == "CONFIRMED":
            if action["payload"].get("no_fill_reprotected"):
                duplicate_status = "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTED"
            else:
                duplicate_status = ("PROTECTIVE_LOT_CLOSED" if action["payload"].get("lot_closed")
                                    else "PROTECTIVE_PARTIAL_FILL_RESIZED")
            return {"signal_id": action["signal_id"], "status": duplicate_status,
                    "duplicate": True, **action["payload"]}

        payload = action["payload"]
        signal_id = str(action["signal_id"])
        symbol = str(payload["symbol"]).upper()
        side = str(payload["side"]).upper()
        position_side = str(payload["position_side"]).upper()
        dual = _bool(payload["dual_side_position"])
        original_qty = _decimal(payload["original_quantity"], "original_quantity")
        group_qty_before = _decimal(
            payload.get("group_quantity_before", original_qty), "group_quantity_before",
        )
        actual_order_id = str(payload["actual_order_id"])
        algo_client_id = str(payload["algo_client_id"])
        expected_role = str(payload["order_role"]).upper()
        observed_executed = _decimal(
            payload.get("observed_executed_quantity", payload.get("executed_quantity", "0")),
            "observed_executed_quantity",
        )
        if (side not in {"LONG", "SHORT"} or expected_role not in {"STOP_LOSS", "TAKE_PROFIT"}
                or original_qty <= 0 or observed_executed < 0
                or observed_executed > original_qty or group_qty_before < original_qty
                or group_qty_before < observed_executed):
            self._halt(f"Protective trigger action contains invalid quantities: {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_ACTION_QUANTITY_INVALID")
        if self._dual_side() != dual or self._position_side_param(side, dual) != position_side:
            self._halt(f"Position mode changed during protective trigger recovery for {symbol}")
            raise RuntimeError("PROTECTIVE_TRIGGER_POSITION_MODE_CHANGED")

        # Re-query the source Algo and the matching-engine child before mutation.
        algo = self.client.get_algo_order(client_algo_id=algo_client_id)
        algo_status = str(algo.get("algoStatus", algo.get("status", ""))).upper()
        algo_actual_id = str(algo.get("actualOrderId", "") or "")
        if algo_status not in {"TRIGGERED", "FINISHED", "EXECUTED", "FILLED"} or algo_actual_id != actual_order_id:
            self._halt(f"Triggered Algo identity/status changed during recovery for {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_ALGO_REST_MISMATCH")

        lookup_id: int | str = int(actual_order_id) if actual_order_id.isdigit() else actual_order_id
        expected_order_side = "SELL" if side == "LONG" else "BUY"

        def query_and_validate_actual_order() -> dict[str, Any]:
            order = self.client.get_order(symbol, order_id=lookup_id)
            order_symbol = str(order.get("symbol", "")).upper()
            order_id_value = str(order.get("orderId", order.get("order_id", "")))
            order_side = str(order.get("side", "")).upper()
            actual_position_side = str(order.get("positionSide", "")).upper()
            order_type = str(order.get("type", "")).upper()
            original_order_qty = _decimal(order.get("origQty"), "actual_order.origQty")
            current_executed = _decimal(order.get("executedQty", "0"), "actual_order.executedQty")
            if (order_symbol != symbol or order_id_value != actual_order_id
                    or order_side != expected_order_side or actual_position_side != position_side
                    or order_type != "MARKET"):
                self._halt(f"Triggered matching-engine order identity/type mismatch for {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_MATCHING_ORDER_IDENTITY_MISMATCH")
            if (abs(original_order_qty - original_qty) > Decimal("1e-10")
                    or current_executed < 0 or current_executed > original_qty + Decimal("1e-10")):
                self._halt(f"Triggered matching-engine order quantities invalid for {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_MATCHING_ORDER_QUANTITY_INVALID")
            if dual:
                if _bool(order.get("reduceOnly", False)) or _bool(order.get("closePosition", False)):
                    self._halt(f"Hedge-mode triggered order has incompatible close flags for {signal_id}")
                    raise RuntimeError("PROTECTIVE_TRIGGER_HEDGE_CLOSE_FLAGS_INVALID")
            else:
                if not _bool(order.get("reduceOnly", False)) or _bool(order.get("closePosition", False)):
                    self._halt(f"One-way triggered order is not reduce-only for {signal_id}")
                    raise RuntimeError("PROTECTIVE_TRIGGER_ONEWAY_CLOSE_FLAGS_INVALID")
            return order

        actual = query_and_validate_actual_order()
        # The triggered child MARKET order uses an exchange order ID distinct from
        # the parent conditional Algo ID. Persist this exact REST-verified ownership
        # edge before cancel/fill reduction so delayed stream or REST userTrades
        # records can be attributed to the correct signal lot after a restart.
        self.ledger.link_exchange_order_to_signal(
            symbol=symbol,
            exchange_order_id=actual_order_id,
            client_order_id=algo_client_id,
            signal_id=signal_id,
            position_side=position_side,
            role=expected_role,
        )
        initial_status = str(actual.get("status", "UNKNOWN")).upper()
        initial_executed = _decimal(actual.get("executedQty", "0"), "actual_order.executedQty")
        if initial_executed < observed_executed:
            self._halt(f"Triggered order REST executedQty regressed for {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_EXECUTED_QUANTITY_REGRESSION")

        if initial_status in {"NEW", "PARTIALLY_FILLED"}:
            self.ledger.update_position_management_action(
                action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
                payload_update={"initial_actual_order_status": initial_status,
                                "initial_actual_executed_quantity": str(initial_executed),
                                "remainder_cancel_attempted": True},
            )
            try:
                self.client.cancel_order(symbol, order_id=lookup_id)
            except BinancePrivateApiError as exc:
                if exc.code not in {-2011, -2013}:
                    self.ledger.update_position_management_action(
                        action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
                        payload_update={"remainder_cancel_error": str(exc)},
                    )
                    self._halt(f"Cannot cancel triggered order remainder for {signal_id}: {exc}")
                    raise
            except Exception as exc:
                self.ledger.update_position_management_action(
                    action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
                    payload_update={"remainder_cancel_error": str(exc)},
                )
                self._halt(f"Triggered order cancellation is ambiguous for {signal_id}: {exc}")
                raise
            # A fill can race the cancel request. Always use this final GET result.
            actual = query_and_validate_actual_order()
            order_status = str(actual.get("status", "UNKNOWN")).upper()
            final_executed = _decimal(actual.get("executedQty", "0"), "actual_order.executedQty")
            if final_executed < initial_executed:
                self._halt(f"Triggered order REST executedQty regressed after cancel for {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_EXECUTED_QUANTITY_REGRESSION")
        else:
            order_status = initial_status
            final_executed = initial_executed

        if order_status not in TERMINAL_ORDER_STATES:
            self.ledger.update_position_management_action(
                action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
                payload_update={"last_order_status": order_status,
                                "last_executed_quantity": str(final_executed)},
            )
            self._halt(f"Triggered matching-engine order is not terminal for {signal_id}: {order_status}")
            self.ledger.record_event(
                "PROTECTIVE_TRIGGER_ORDER_STILL_ACTIVE", signal_id=signal_id, symbol=symbol,
                detail={"actual_order_id": actual_order_id, "status": order_status,
                        "executed_quantity": str(final_executed)},
            )
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_ORDER_PENDING",
                    "actual_order_id": actual_order_id, "exchange_status": order_status,
                    "executed_quantity": str(final_executed)}

        if order_status == "FILLED" and abs(final_executed - original_qty) > Decimal("1e-10"):
            self._halt(f"Triggered order reports FILLED with incomplete executedQty for {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_FILLED_QUANTITY_INCOMPLETE")
        if final_executed == 0 and order_status not in self._RECOVERY_TERMINAL_NO_FILL:
            self._halt(f"Triggered order has zero fill but non-no-fill terminal status for {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_ZERO_FILL_STATUS_INVALID")

        residual_qty = original_qty - final_executed
        expected_group_remaining = group_qty_before - final_executed
        self.ledger.update_position_management_action(
            action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
            payload_update={
                "final_actual_order_status": order_status,
                "initial_actual_executed_quantity": str(initial_executed),
                "final_executed_quantity": str(final_executed),
                "executed_quantity": str(final_executed),
                "residual_quantity": str(residual_qty),
                "expected_group_remaining": str(expected_group_remaining),
                "remainder_cancel_confirmed": order_status not in {"NEW", "PARTIALLY_FILLED"},
            },
        )

        exchange_qty = self._position_quantity(symbol, side, dual)
        if abs(exchange_qty - expected_group_remaining) > Decimal("1e-10"):
            self._halt(f"Triggered order aggregate residual does not match REST position for {signal_id}")
            self.ledger.record_event(
                "PROTECTIVE_TRIGGER_RESIDUAL_MISMATCH", signal_id=signal_id, symbol=symbol,
                detail={"actual_order_id": actual_order_id, "executed_quantity": str(final_executed),
                        "expected_lot_residual": str(residual_qty),
                        "group_quantity_before": str(group_qty_before),
                        "expected_group_residual": str(expected_group_remaining),
                        "exchange_residual": str(exchange_qty)},
            )
            raise RuntimeError("PROTECTIVE_TRIGGER_RESIDUAL_QUANTITY_MISMATCH")
        try:
            # Local allocation still represents the pre-trigger lots until the
            # atomic residual transaction below. Compare it to the captured group
            # quantity before comparing the new exchange residual.
            local_group_before = self._assert_group_projection(symbol, side, dual)
        except Exception as exc:
            self._halt(f"Triggered order local group projection mismatch for {signal_id}: {exc}")
            raise
        if abs(local_group_before - group_qty_before) > Decimal("1e-10"):
            self._halt(f"Triggered order local group changed during reconciliation for {signal_id}")
            raise RuntimeError("PROTECTIVE_TRIGGER_LOCAL_GROUP_PROJECTION_MISMATCH")

        actual_client_id = str(actual.get("clientOrderId", actual.get("origClientOrderId", "")) or "")
        if not actual_client_id:
            actual_client_id = _client_id("DIVATRG", f"{signal_id}:{actual_order_id}")
        self.ledger.record_order(
            client_id=actual_client_id, signal_id=signal_id, symbol=symbol,
            role=expected_role, order_kind="STANDARD", status=order_status,
            exchange_order_id=actual_order_id, payload=dict(actual),
        )

        if final_executed == 0:
            # Zero-fill re-protection is a recovery mutation. It remains disabled
            # unless the explicit DIVA_ENABLE_PROTECTION_RECOVERY opt-in is set.
            if not bool(getattr(self, "enable_zero_fill_reprotection", False)):
                self.ledger.update_position_management_action(
                    action_id=action_id, status="PROTECTIVE_TRIGGER_RECONCILIATION_PENDING",
                    payload_update={"zero_fill_reprotection": "DISABLED_BY_POLICY"},
                )
                self._halt(
                    f"Triggered Algo had zero fill for {symbol}/{signal_id}; automatic re-protection is disabled"
                )
                self.ledger.record_event(
                    "PROTECTIVE_ALGO_ZERO_FILL_RECOVERY_DISABLED",
                    signal_id=signal_id, symbol=symbol,
                    detail={"actual_order_id": actual_order_id, "order_role": expected_role},
                )
                return {"signal_id": signal_id,
                        "status": "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTION_DISABLED",
                        "actual_order_id": actual_order_id, "exchange_status": order_status,
                        "residual_quantity": str(original_qty), "automatic_recovery": False}

            # Triggered Algo created a matching-engine order but no contract filled.
            # Re-protect the unchanged, REST-confirmed position with a fresh pair.
            protection = self.resize_protection_quantity(
                signal_id, original_qty, source_action_id=action_id, parent_action_id=action_id,
            )
            if protection.get("status") != "CONFIRMED":
                self._halt(f"No-fill triggered protection could not be re-established: {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_NO_FILL_REPROTECTION_NOT_CONFIRMED")
            result_payload = {
                "actual_order_id": actual_order_id, "actual_client_order_id": actual_client_id,
                "executed_quantity": "0", "residual_quantity": str(original_qty),
                "group_quantity_before": str(group_qty_before),
                "aggregate_position_quantity": str(exchange_qty),
                "lot_closed": False, "no_fill_reprotected": True,
                "lot_finalization_confirmed": False, "order_role": expected_role,
                "protection_resize": protection,
            }
            self.ledger.update_position_management_action(
                action_id=action_id, status="CONFIRMED", payload_update=result_payload,
            )
            self.ledger.record_event(
                "PROTECTIVE_ALGO_TRIGGERED_ZERO_FILL_REPROTECTED",
                signal_id=signal_id, symbol=symbol, detail=result_payload,
            )
            self._halt(
                f"Protective Algo triggered without fill for {symbol}/{signal_id}; replacement pair verified"
            )
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTED",
                    **result_payload}

        # Atomic ledger projection update makes restart/replay safe even if the process
        # stops between lifecycle state persistence and position-row persistence.
        self.ledger.apply_protective_trigger_residual(
            action_id=action_id, signal_id=signal_id, symbol=symbol,
            position_side=position_side, original_quantity=str(original_qty),
            residual_quantity=str(residual_qty),
        )
        if residual_qty == 0:
            finalized = self.finalize_managed_lot(
                signal_id, expected_group_quantity=expected_group_remaining,
            )
            if not finalized:
                self._halt(f"Protective trigger closed lot but finalization is pending: {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_LOT_FINALIZATION_PENDING")
            protection: dict[str, Any] = {"status": "NOT_REQUIRED_LOT_CLOSED"}
            final_status = "PROTECTIVE_LOT_CLOSED"
        else:
            protection = self.resize_protection_quantity(
                signal_id, residual_qty, source_action_id=action_id, parent_action_id=action_id,
            )
            if protection.get("status") != "CONFIRMED":
                self._halt(f"Replacement protections are not confirmed after protective partial fill: {signal_id}")
                raise RuntimeError("PROTECTIVE_TRIGGER_RESIZE_NOT_CONFIRMED")
            finalized = False
            final_status = "PROTECTIVE_PARTIAL_FILL_RESIZED"
        result_payload = {
            "actual_order_id": actual_order_id, "actual_client_order_id": actual_client_id,
            "executed_quantity": str(final_executed), "residual_quantity": str(residual_qty),
            "group_quantity_before": str(group_qty_before),
            "aggregate_position_quantity": str(expected_group_remaining),
            "lot_closed": residual_qty == 0, "lot_finalization_confirmed": finalized,
            "order_role": expected_role, "protection_resize": protection,
        }
        self.ledger.update_position_management_action(
            action_id=action_id, status="CONFIRMED", payload_update=result_payload,
        )
        self.ledger.record_event(
            "PROTECTIVE_ALGO_FILL_RECONCILED", signal_id=signal_id, symbol=symbol,
            detail=result_payload,
        )
        self._halt(
            f"Protective fill reconciled for {symbol}/{signal_id}; account reconciliation required before new entries"
        )
        return {"signal_id": signal_id, "status": final_status, **result_payload}

    def reconcile_action(self, action_id: str) -> dict[str, Any]:
        action = self.ledger.get_position_management_action(action_id)
        if action is None:
            raise KeyError(action_id)
        if action["action_kind"] == "PARTIAL_TP":
            return self.confirm_partial_take_profit(action_id)
        if action["action_kind"] == "MOVE_STOP":
            return self.reconcile_stop_replacement(action_id)
        if action["action_kind"] == "RESIZE_PROTECTION":
            return self.reconcile_protection_resize(action_id)
        if action["action_kind"] == "PROTECTIVE_TRIGGER_RECONCILIATION":
            return self.reconcile_protective_trigger(action_id)
        if action["action_kind"] == "PROTECTIVE_ORDER_RECOVERY":
            return self.reconcile_protective_order_recovery(action_id)
        if action["action_kind"] in {"STRUCTURAL_EXIT", "EMERGENCY_CLOSE"}:
            return self.confirm_market_exit(action_id)
        raise ValueError(f"Unsupported lifecycle action kind: {action['action_kind']}")

    def recover_pending_actions(self) -> list[dict[str, Any]]:
        """Restart recovery: query durable exchange IDs; never re-POST an old action."""
        pending = self.ledger.list_position_management_actions(
            statuses=("PLANNED", "SUBMITTING", "SUBMITTED", "SUBMISSION_UNKNOWN",
                      "PARTIALLY_FILLED", "REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
                      "STOP_TRIGGERED_PENDING_RECONCILIATION",
                      "STOP_REPLACEMENT_POSITION_MISMATCH", "EXIT_PENDING",
                      "PROTECTIVE_TRIGGER_RECONCILIATION_PENDING"),
        )
        results: list[dict[str, Any]] = []
        for action in pending:
            try:
                result = self.reconcile_action(action["action_id"])
            except Exception as exc:
                self._halt(f"Lifecycle restart recovery failed for {action['action_id']}: {exc}")
                results.append({"action_id": action["action_id"], "status": "RECOVERY_ERROR",
                                "error": str(exc)})
            else:
                results.append({"action_id": action["action_id"], **result})
        return results

    def recover_on_startup(self) -> dict[str, Any]:
        """Rebuild fill projections, recover pending actions and verify flat records.

        This is called once after each successful User Data Stream connection. It
        deliberately does not clear the global entry halt; an operator/reconciliation
        policy must decide when new entries may resume.
        """
        fill_projections = self.ledger.apply_position_fill_allocations()
        action_results = self.recover_pending_actions()
        position_results: list[dict[str, Any]] = []
        for row in self.ledger.list_managed_positions(status=None):
            signal_id = str(row["signal_id"])
            reservation = self.ledger.get_risk_reservation(signal_id)
            if reservation is None or reservation.get("status") == "RELEASED":
                continue
            position_side = str(row.get("position_side", "BOTH")).upper()
            dual = position_side in {"LONG", "SHORT"}
            try:
                quantity = self._position_quantity(
                    str(row["symbol"]).upper(), str(row.get("signal_side", "")).upper(), dual,
                )
                if quantity == 0:
                    finalized = self.finalize_if_flat(signal_id)
                    position_results.append({
                        "signal_id": signal_id,
                        "status": "CLOSED_CONFIRMED" if finalized else "FINALIZATION_PENDING",
                    })
            except Exception as exc:
                self._halt(f"Managed-position startup recovery failed for {signal_id}: {exc}")
                position_results.append({"signal_id": signal_id, "status": "RECOVERY_ERROR",
                                         "error": str(exc)})
        return {"fill_projections": fill_projections, "actions": action_results,
                "positions": position_results}

    def _signal_related_order_ids(self, signal_id: str) -> tuple[set[str], set[str]]:
        intent = self.ledger.get_intent(signal_id)
        if intent is None:
            raise KeyError(signal_id)
        related_algo_ids = {
            self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"),
            self.ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"),
        }
        related_standard_ids = {str(intent["client_order_id"])}
        state_row = self.ledger.get_position_management_state(signal_id)
        if state_row is not None:
            for field in ("stop_algo_client_id", "take_profit_algo_client_id"):
                if state_row["state"].get(field):
                    related_algo_ids.add(str(state_row["state"][field]))
        for action in self.ledger.list_position_management_actions(signal_id=signal_id):
            payload = action.get("payload", {})
            for key in (
                "client_algo_id", "old_client_algo_id", "old_stop_client_algo_id",
                "old_take_client_algo_id", "new_stop_client_algo_id", "new_take_client_algo_id",
                "source_client_algo_id", "replacement_client_algo_id",
            ):
                if payload.get(key):
                    related_algo_ids.add(str(payload[key]))
            if payload.get("client_order_id"):
                related_standard_ids.add(str(payload["client_order_id"]))
        return related_standard_ids, related_algo_ids

    def finalize_managed_lot(
        self, signal_id: str, *, expected_group_quantity: Decimal | str,
    ) -> bool:
        """Close one signal allocation while preserving sibling lots on the same side."""
        intent = self.ledger.get_intent(signal_id)
        state_row = self.ledger.get_position_management_state(signal_id)
        managed = [row for row in self.ledger.list_managed_positions(status=None)
                   if str(row.get("signal_id")) == signal_id]
        if intent is None or state_row is None or len(managed) != 1:
            self._halt(f"Managed lot finalization identity is incomplete for {signal_id}")
            return False
        row = managed[0]
        symbol = str(intent["symbol"]).upper()
        side = str(intent["side"]).upper()
        position_side = str(row.get("position_side", "BOTH")).upper()
        dual = position_side in {"LONG", "SHORT"}
        try:
            expected_group = (expected_group_quantity if isinstance(expected_group_quantity, Decimal)
                              else Decimal(str(expected_group_quantity)))
        except Exception as exc:
            raise ValueError("expected_group_quantity must be Decimal-compatible") from exc
        if not expected_group.is_finite() or expected_group < 0:
            raise ValueError("expected_group_quantity must be finite and non-negative")
        other_rows = [
            item for item in self.ledger.list_managed_positions(status="OPEN")
            if str(item.get("symbol", "")).upper() == symbol
            and str(item.get("position_side", "BOTH")).upper() == position_side
            and str(item.get("signal_id")) != signal_id
        ]
        other_quantity = sum((_decimal(item.get("quantity"), "other_lot.quantity")
                              for item in other_rows), Decimal("0"))
        try:
            self.client.sync_server_time()
            exchange_quantity = self._position_quantity(symbol, side, dual)
        except Exception as exc:
            self._halt(f"Managed lot finalization position query failed for {symbol}/{signal_id}: {exc}")
            raise
        if (abs(exchange_quantity - expected_group) > Decimal("1e-9")
                or abs(other_quantity - expected_group) > Decimal("1e-9")):
            self._halt(
                f"Managed lot close does not reconcile with sibling aggregate for {symbol}/{signal_id}: "
                f"exchange={exchange_quantity}, expected={expected_group}, siblings={other_quantity}"
            )
            return False

        related_standard_ids, related_algo_ids = self._signal_related_order_ids(signal_id)
        try:
            for order in self.client.get_open_orders(symbol):
                client_id = str(order.get("clientOrderId", ""))
                if client_id in related_standard_ids:
                    try:
                        self.client.cancel_order(symbol, client_order_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
            for order in self.client.get_open_algo_orders(symbol):
                client_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
                if client_id in related_algo_ids:
                    try:
                        self.client.cancel_algo_order(client_algo_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
            remaining_standard = {
                str(item.get("clientOrderId", "")) for item in self.client.get_open_orders(symbol)
            }
            remaining_algo = {
                str(item.get("clientAlgoId", item.get("clientAlgoID", "")))
                for item in self.client.get_open_algo_orders(symbol)
            }
            exchange_after_cleanup = self._position_quantity(symbol, side, dual)
        except Exception as exc:
            self._halt(f"Managed lot related-order cleanup failed for {symbol}/{signal_id}: {exc}")
            raise
        if ((related_standard_ids & remaining_standard) or (related_algo_ids & remaining_algo)
                or abs(exchange_after_cleanup - expected_group) > Decimal("1e-9")):
            self._halt(f"Managed lot cleanup remains unresolved for {symbol}/{signal_id}")
            return False

        state = dict(state_row["state"])
        state["quantity"] = "0"
        state["closed"] = True
        if (state_row["state"].get("closed") is not True
                or str(state_row["state"].get("quantity")) != "0"):
            self.ledger.save_position_management_state(
                signal_id=signal_id, symbol=symbol, state=state,
                expected_version=int(state_row["version"]),
            )
        self.ledger.update_managed_position(
            signal_id=signal_id, symbol=symbol, position_side=position_side,
            quantity="0", status="CLOSED",
        )
        self.ledger.update_intent(signal_id, "CLOSED")
        reservation = self.ledger.get_risk_reservation(signal_id)
        if reservation is not None and reservation.get("status") != "RELEASED":
            self.ledger.release_risk_reservation(
                signal_id, "LOT_EXCHANGE_REDUCED_AND_OWN_ORDERS_TERMINAL",
            )
        verified = self.ledger.get_risk_reservation(signal_id)
        if verified is not None and verified.get("status") != "RELEASED":
            self._halt(f"Managed lot risk reservation release failed for {symbol}/{signal_id}")
            raise RuntimeError("MANAGED_LOT_RISK_RELEASE_NOT_CONFIRMED")
        self.ledger.record_event(
            "MANAGED_LOT_CLOSED_CONFIRMED", signal_id=signal_id, symbol=symbol,
            detail={"aggregate_exchange_quantity": str(exchange_after_cleanup),
                    "sibling_quantity": str(other_quantity), "own_orders_terminal": True,
                    "risk_reservation_released": True},
        )
        return True

    def _finalize_flat_group(self, *, symbol: str, side: str, position_side: str,
                             rows: list[dict[str, Any]]) -> bool:
        """Atomically-in-sequence finalize every owned lot after aggregate REST flatness.

        A shared exchange (symbol, positionSide) has one net position quantity. When
        that quantity is zero, all local lots in that group must close together; a
        single-lot finalizer would otherwise leave sibling reservations permanently
        active and block recovery.
        """
        normalized_symbol = symbol.upper()
        normalized_position_side = position_side.upper()
        dual = normalized_position_side in {"LONG", "SHORT"}
        signal_ids = [str(row["signal_id"]) for row in rows]
        if len(signal_ids) < 2 or len(set(signal_ids)) != len(signal_ids):
            raise ValueError("FLAT_GROUP_REQUIRES_MULTIPLE_UNIQUE_LOTS")
        standard_ids: set[str] = set()
        algo_ids: set[str] = set()
        for lot_signal_id in signal_ids:
            standard, algo = self._signal_related_order_ids(lot_signal_id)
            standard_ids.update(standard)
            algo_ids.update(algo)
            state_row = self.ledger.get_position_management_state(lot_signal_id)
            if state_row is None:
                self._halt(f"Missing lifecycle state during flat-group finalization: {lot_signal_id}")
                raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        try:
            self.client.sync_server_time()
            if self._position_quantity(normalized_symbol, side, dual) != 0:
                return False
            for order in self.client.get_open_orders(normalized_symbol):
                client_id = str(order.get("clientOrderId", ""))
                if client_id in standard_ids:
                    try:
                        self.client.cancel_order(normalized_symbol, client_order_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
            for order in self.client.get_open_algo_orders(normalized_symbol):
                client_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
                if client_id in algo_ids:
                    try:
                        self.client.cancel_algo_order(client_algo_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
            remaining_standard = {
                str(item.get("clientOrderId", ""))
                for item in self.client.get_open_orders(normalized_symbol)
            }
            remaining_algo = {
                str(item.get("clientAlgoId", item.get("clientAlgoID", "")))
                for item in self.client.get_open_algo_orders(normalized_symbol)
            }
            exchange_after_cleanup = self._position_quantity(normalized_symbol, side, dual)
        except Exception as exc:
            self._halt(f"Aggregate flat-group cleanup failed for {normalized_symbol}/{normalized_position_side}: {exc}")
            raise
        if ((standard_ids & remaining_standard) or (algo_ids & remaining_algo)
                or exchange_after_cleanup != 0):
            self._halt(
                f"Aggregate flat-group cleanup remains unresolved for {normalized_symbol}/{normalized_position_side}"
            )
            return False

        for lot_signal_id in signal_ids:
            intent = self.ledger.get_intent(lot_signal_id)
            state_row = self.ledger.get_position_management_state(lot_signal_id)
            if intent is None or state_row is None:
                self._halt(f"Managed lot identity disappeared during flat-group finalization: {lot_signal_id}")
                raise RuntimeError("FLAT_GROUP_LOT_IDENTITY_MISSING")
            state = dict(state_row["state"])
            if state.get("closed") is not True or str(state.get("quantity")) != "0":
                state["quantity"] = "0"
                state["closed"] = True
                self.ledger.save_position_management_state(
                    signal_id=lot_signal_id, symbol=normalized_symbol, state=state,
                    expected_version=int(state_row["version"]),
                )
            self.ledger.update_managed_position(
                signal_id=lot_signal_id, symbol=normalized_symbol,
                position_side=normalized_position_side, quantity="0", status="CLOSED",
            )
            self.ledger.update_intent(lot_signal_id, "CLOSED")
            reservation = self.ledger.get_risk_reservation(lot_signal_id)
            if reservation is not None and reservation.get("status") != "RELEASED":
                self.ledger.release_risk_reservation(
                    lot_signal_id, "AGGREGATE_EXCHANGE_CONFIRMED_FLAT_AND_ORDERS_TERMINAL",
                )
            verified = self.ledger.get_risk_reservation(lot_signal_id)
            if verified is None or verified.get("status") != "RELEASED":
                self._halt(f"Flat-group reservation release failed for {normalized_symbol}/{lot_signal_id}")
                raise RuntimeError("RISK_RESERVATION_RELEASE_NOT_CONFIRMED")
            self.ledger.record_event(
                "MANAGED_POSITION_CLOSED_CONFIRMED", signal_id=lot_signal_id,
                symbol=normalized_symbol,
                detail={"position_side": normalized_position_side,
                        "aggregate_position_quantity": "0", "related_orders_terminal": True,
                        "risk_reservation_released": True, "aggregate_flat_group": True},
            )
        self.ledger.record_event(
            "MANAGED_POSITION_GROUP_CLOSED_CONFIRMED", symbol=normalized_symbol,
            detail={"position_side": normalized_position_side, "signal_ids": signal_ids,
                    "aggregate_position_quantity": "0", "related_orders_terminal": True},
        )
        return True

    def finalize_if_flat(self, signal_id: str) -> bool:
        """Release reservation only after exchange confirms flat and linked orders terminal."""
        intent = self.ledger.get_intent(signal_id)
        if intent is None:
            raise KeyError(signal_id)
        state_row = self.ledger.get_position_management_state(signal_id)
        if state_row is None:
            raise RuntimeError("POSITION_MANAGEMENT_STATE_MISSING")
        state = state_row["state"]
        symbol = str(intent["symbol"]).upper()
        side = str(intent["side"]).upper()
        managed_rows = [row for row in self.ledger.list_managed_positions(status=None)
                        if row["signal_id"] == signal_id]
        if len(managed_rows) != 1:
            raise RuntimeError("MANAGED_POSITION_RECORD_NOT_UNIQUE")
        position_side = str(managed_rows[0]["position_side"])
        dual = position_side in {"LONG", "SHORT"}
        if (str(managed_rows[0].get("status", "")).upper() == "CLOSED"
                and state.get("closed") is True and str(state.get("quantity")) == "0"):
            reservation = self.ledger.get_risk_reservation(signal_id)
            if reservation is not None and reservation.get("status") == "RELEASED":
                return True
            # Recover the crash window where local state was closed before the
            # reservation was released; continue through REST/order verification.
        try:
            self.client.sync_server_time()
            if self._position_quantity(symbol, side, dual) != 0:
                return False
        except Exception as exc:
            self._halt(f"Initial flat-position verification failed for {symbol}/{signal_id}: {exc}")
            raise

        open_group_rows = [
            row for row in self.ledger.list_managed_positions(status="OPEN")
            if str(row.get("symbol", "")).upper() == symbol
            and str(row.get("position_side", "BOTH")).upper() == position_side.upper()
        ]
        if len(open_group_rows) > 1:
            return self._finalize_flat_group(
                symbol=symbol, side=side, position_side=position_side, rows=open_group_rows,
            )

        # Do not globally halt the portfolio for an ordinary position close. Only an
        # unresolved cleanup/reconciliation condition should stop new entries.
        related_algo_ids = {
            self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"),
            self.ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"),
        }
        related_standard_ids = {str(intent["client_order_id"])}
        for action in self.ledger.list_position_management_actions(signal_id=signal_id):
            payload = action.get("payload", {})
            for key in ("client_algo_id", "old_client_algo_id"):
                if payload.get(key):
                    related_algo_ids.add(str(payload[key]))
            if payload.get("client_order_id"):
                related_standard_ids.add(str(payload["client_order_id"]))

        try:
            open_standard = self.client.get_open_orders(symbol)
            for order in open_standard:
                client_id = str(order.get("clientOrderId", ""))
                if client_id in related_standard_ids:
                    try:
                        self.client.cancel_order(symbol, client_order_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
            open_algo = self.client.get_open_algo_orders(symbol)
            for order in open_algo:
                client_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
                if client_id in related_algo_ids:
                    try:
                        self.client.cancel_algo_order(client_algo_id=client_id)
                    except BinancePrivateApiError as exc:
                        if exc.code not in {-2011, -2013}:
                            raise
        except Exception as exc:
            self._halt(f"Related order cleanup failed for {symbol}/{signal_id}: {exc}")
            raise

        # Verify both conditions again after cancellation requests. Query failures are
        # not equivalent to an empty order list: fail closed and retain the reservation.
        try:
            remaining_standard = {
                str(row.get("clientOrderId", "")) for row in self.client.get_open_orders(symbol)
            }
            remaining_algo = {
                str(row.get("clientAlgoId", row.get("clientAlgoID", "")))
                for row in self.client.get_open_algo_orders(symbol)
            }
            still_open_position = self._position_quantity(symbol, side, dual) != 0
        except Exception as exc:
            self._halt(f"Post-cleanup verification failed for {symbol}/{signal_id}: {exc}")
            raise
        if (related_standard_ids & remaining_standard) or (related_algo_ids & remaining_algo):
            self._halt(f"Related orders remain open after flat-position cleanup for {symbol}")
            return False
        if still_open_position:
            self._halt(f"Position quantity changed during finalization for {symbol}")
            return False

        state = dict(state)
        state["quantity"] = "0"
        state["closed"] = True
        self.ledger.save_position_management_state(
            signal_id=signal_id, symbol=symbol, state=state,
            expected_version=int(state_row["version"]),
        )
        self.ledger.update_managed_position(
            signal_id=signal_id, symbol=symbol, position_side=position_side,
            quantity="0", status="CLOSED",
        )
        self.ledger.update_intent(signal_id, "CLOSED")
        self.ledger.release_risk_reservation(
            signal_id, "EXCHANGE_CONFIRMED_FLAT_AND_RELATED_ORDERS_TERMINAL",
        )
        reservation = self.ledger.get_risk_reservation(signal_id)
        if reservation is None or reservation.get("status") != "RELEASED":
            self._halt(f"Risk reservation could not be verified RELEASED for {symbol}/{signal_id}")
            raise RuntimeError("RISK_RESERVATION_RELEASE_NOT_CONFIRMED")
        self.ledger.record_event(
            "MANAGED_POSITION_CLOSED_CONFIRMED", signal_id=signal_id, symbol=symbol,
            detail={"position_quantity": "0", "related_orders_terminal": True,
                    "risk_reservation_released": True},
        )
        return True


class PositionLifecycleFillReducer:
    """Bridge User Data Stream updates to REST-confirmed position lifecycle reducers.

    WebSocket events are triggers only. The adapter checks Binance REST positions and
    order states before changing local position state or releasing risk. Zero-fill
    triggered-order re-protection is separately opt-in for TESTNET/LIVE via the
    account runtime's DIVA_ENABLE_PROTECTION_RECOVERY policy.
    """
    def __init__(self, *, adapter: PositionLifecycleExecutionAdapter,
                 ledger: ExecutionLedger, enable_zero_fill_reprotection: bool = False) -> None:
        if not isinstance(enable_zero_fill_reprotection, bool):
            raise ValueError("enable_zero_fill_reprotection must be boolean")
        self.adapter = adapter
        self.ledger = ledger
        self.enable_zero_fill_reprotection = enable_zero_fill_reprotection
        # The durable action may be resumed by the adapter during startup recovery.
        self.adapter.enable_zero_fill_reprotection = enable_zero_fill_reprotection

    def _finalize_flat_records(self, *, symbol: str, position_side: str | None = None) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for row in self.ledger.list_managed_positions(status="OPEN"):
            if str(row["symbol"]).upper() != symbol.upper():
                continue
            if position_side and position_side != "BOTH" and str(row["position_side"]).upper() != position_side:
                continue
            finalized = self.adapter.finalize_if_flat(str(row["signal_id"]))
            results.append({"signal_id": row["signal_id"],
                            "status": "CLOSED_CONFIRMED" if finalized else "POSITION_NOT_FLAT"})
            if not finalized:
                self.adapter._halt(
                    f"Account stream reported flat but REST position is not flat for {symbol}/{row['signal_id']}"
                )
        return results

    def _handle_protective_algo_trigger(
        self, row: dict[str, Any], client_id: str, exchange_order: dict[str, Any],
    ) -> dict[str, Any]:
        """Claim or resume one triggered protective Algo using REST child-order identity."""
        signal_id = str(row["signal_id"])
        symbol = str(row["symbol"]).upper()
        trigger_statuses = {"TRIGGERED", "FINISHED", "EXECUTED", "FILLED"}
        rest_status = str(exchange_order.get("algoStatus", exchange_order.get("status", ""))).upper()
        if rest_status not in trigger_statuses:
            return {"signal_id": signal_id, "status": "PROTECTION_TRIGGER_NOT_CONFIRMED",
                    "exchange_status": rest_status}

        trigger_action_id = f"protective-trigger:{signal_id}:{client_id}"
        prior_trigger_action = self.ledger.get_position_management_action(trigger_action_id)
        if prior_trigger_action is not None:
            return self.adapter.reconcile_protective_trigger(trigger_action_id)

        # A flat exchange position is finalized by the existing close path. For a
        # non-flat position, actualOrderId is required to attribute the child order.
        try:
            finalized = self.adapter.finalize_if_flat(signal_id)
        except Exception as exc:
            self.adapter._halt(f"Triggered protection flat-position check failed for {signal_id}: {exc}")
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_POSITION_UNVERIFIED"}
        if finalized:
            return {"signal_id": signal_id, "status": "CLOSED_CONFIRMED"}

        actual_order_id = str(exchange_order.get("actualOrderId", "") or "")
        if not actual_order_id:
            self.adapter._halt(
                f"Protective Algo triggered but REST position remains open without actualOrderId: {signal_id}"
            )
            self.ledger.record_event(
                "PROTECTIVE_ALGO_TRIGGERED_POSITION_REMAINS",
                signal_id=signal_id, symbol=symbol,
                detail={"client_algo_id": client_id, "exchange_status": rest_status},
            )
            return {"signal_id": signal_id, "status": "PROTECTION_EVENT_POSITION_NOT_FLAT"}

        state_row = self.ledger.get_position_management_state(signal_id)
        state = state_row.get("state", {}) if state_row else {}
        try:
            original_qty = _decimal(state.get("quantity"), "state.quantity")
            managed_qty = _decimal(row.get("quantity"), "managed.quantity")
            lookup_id: int | str = int(actual_order_id) if actual_order_id.isdigit() else actual_order_id
            actual = self.adapter.client.get_order(symbol, order_id=lookup_id)
            executed_qty = _decimal(actual.get("executedQty", "0"), "actual_order.executedQty")
            actual_original_qty = _decimal(actual.get("origQty"), "actual_order.origQty")
        except Exception as exc:
            self.adapter._halt(
                f"Triggered Algo underlying order cannot be inspected for {signal_id}: {exc}"
            )
            self.ledger.record_event(
                "PROTECTIVE_TRIGGER_ACTUAL_ORDER_UNVERIFIED",
                signal_id=signal_id, symbol=symbol,
                detail={"client_algo_id": client_id, "actual_order_id": actual_order_id,
                        "error": str(exc)[:300]},
            )
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_ACTUAL_ORDER_UNVERIFIED"}

        if (original_qty <= 0 or abs(original_qty - managed_qty) > Decimal("1e-10")
                or abs(actual_original_qty - original_qty) > Decimal("1e-10")
                or executed_qty < 0 or executed_qty > original_qty):
            self.adapter._halt(f"Triggered Algo local/actual order quantity mismatch for {signal_id}")
            self.ledger.record_event(
                "PROTECTIVE_TRIGGER_EXECUTED_QUANTITY_INVALID", signal_id=signal_id,
                symbol=symbol,
                detail={"actual_order_id": actual_order_id,
                        "original_quantity": str(original_qty),
                        "actual_order_original_quantity": str(actual_original_qty),
                        "observed_executed_quantity": str(executed_qty)},
            )
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_EXECUTED_QUANTITY_INVALID"}

        position_side = str(row.get("position_side", "BOTH")).upper()
        try:
            group_quantity_before = self.adapter._assert_group_projection(
                symbol, str(row.get("signal_side", "")).upper(),
                position_side in {"LONG", "SHORT"},
            )
        except Exception as exc:
            self.adapter._halt(f"Managed group projection is invalid for {signal_id}: {exc}")
            return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_GROUP_INVALID"}

        order_role = (
            "STOP_LOSS" if client_id == str(state.get(
                "stop_algo_client_id", self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"),
            )) else "TAKE_PROFIT"
        )
        trigger_payload = {
            "symbol": symbol,
            "side": str(row.get("signal_side", "")).upper(),
            "position_side": position_side,
            "dual_side_position": position_side in {"LONG", "SHORT"},
            "original_quantity": str(original_qty),
            # This is only the first REST observation. reconcile_protective_trigger
            # re-queries after cancel and overwrites it with final cumulative executedQty.
            "observed_executed_quantity": str(executed_qty),
            "executed_quantity": str(executed_qty),
            "residual_quantity": str(original_qty - executed_qty),
            "group_quantity_before": str(group_quantity_before),
            "actual_order_id": actual_order_id,
            "algo_client_id": client_id,
            "order_role": order_role,
            "initial_actual_order_status": str(actual.get("status", "UNKNOWN")).upper(),
        }
        claimed = self.ledger.claim_position_management_action(
            action_id=trigger_action_id, signal_id=signal_id,
            action_kind="PROTECTIVE_TRIGGER_RECONCILIATION", payload=trigger_payload,
        )
        if not claimed:
            prior = self.ledger.get_position_management_action(trigger_action_id)
            if prior is None or prior.get("action_kind") != "PROTECTIVE_TRIGGER_RECONCILIATION":
                self.adapter._halt(
                    f"Another lifecycle action blocks protective trigger reconciliation for {signal_id}"
                )
                return {"signal_id": signal_id, "status": "PROTECTIVE_TRIGGER_ACTION_BLOCKED"}
        return self.adapter.reconcile_protective_trigger(trigger_action_id)

    def recover_triggered_protections_from_rest(self) -> list[dict[str, Any]]:
        """Backfill triggered STOP/TP events after a User Data Stream gap or restart.

        The REST query is authoritative. A missing historical Algo record is not treated
        as proof of cancellation; the adapter requires exact durable stream evidence or
        reports an unverified source and keeps the account halted.
        """
        results: list[dict[str, Any]] = []
        for row in self.ledger.list_managed_positions(status="OPEN"):
            signal_id = str(row["signal_id"])
            state_row = self.ledger.get_position_management_state(signal_id)
            if state_row is None:
                self.adapter._halt(f"Cannot backfill protective triggers without state for {signal_id}")
                results.append({"signal_id": signal_id, "status": "PROTECTIVE_SOURCE_STATE_MISSING"})
                continue
            state = state_row["state"]
            protection_ids = (
                ("STOP_LOSS", str(state.get("stop_algo_client_id") or
                                   self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"))),
                ("TAKE_PROFIT", str(state.get("take_profit_algo_client_id") or
                                      self.ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"))),
            )
            for role, client_id in protection_ids:
                try:
                    source, evidence = self.adapter._load_protection_source(
                        symbol=str(row["symbol"]).upper(), client_algo_id=client_id,
                    )
                except Exception as exc:
                    self.adapter._halt(
                        f"Protective trigger REST backfill could not verify {role} for {signal_id}: {exc}"
                    )
                    results.append({"signal_id": signal_id, "role": role,
                                    "status": "PROTECTIVE_SOURCE_UNVERIFIED",
                                    "evidence": "UNAVAILABLE", "error": str(exc)[:300]})
                    continue
                source_status = str(source.get("algoStatus", "")).upper()
                if source_status not in {"TRIGGERED", "FINISHED", "EXECUTED", "FILLED"}:
                    continue
                try:
                    result = self._handle_protective_algo_trigger(row, client_id, source)
                    results.append({"signal_id": signal_id, "role": role,
                                    "evidence": evidence, **result})
                except Exception as exc:
                    self.adapter._halt(
                        f"Protective trigger REST backfill failed for {signal_id}/{role}: {exc}"
                    )
                    results.append({"signal_id": signal_id, "role": role,
                                    "status": "PROTECTIVE_TRIGGER_BACKFILL_ERROR",
                                    "evidence": evidence, "error": str(exc)[:300]})
        return results

    def handle(self, event: Any) -> dict[str, Any] | list[dict[str, Any]] | None:
        payload = event.payload if hasattr(event, "payload") else event
        if not isinstance(payload, dict):
            return None
        event_type = str(payload.get("e", getattr(event, "event_type", "")))
        if event_type == "ACCOUNT_UPDATE":
            account = payload.get("a") or {}
            positions = account.get("P", []) if isinstance(account, dict) else []
            results: list[dict[str, Any]] = []
            if not isinstance(positions, list):
                return None
            for position in positions:
                if not isinstance(position, dict):
                    continue
                try:
                    amount = _decimal(position.get("pa"), "account.positionAmt")
                except ValueError:
                    self.adapter._halt("Malformed position quantity in ACCOUNT_UPDATE")
                    raise
                if amount != 0:
                    continue
                symbol = str(position.get("s", "")).upper()
                if not symbol:
                    continue
                side = str(position.get("ps", "BOTH")).upper()
                results.extend(self._finalize_flat_records(symbol=symbol, position_side=side))
            return results or None

        if event_type not in {"ORDER_TRADE_UPDATE", "ALGO_UPDATE", "TRADE_LITE"}:
            return None
        body = payload.get("o") or payload.get("or") or payload.get("a") or {}
        if not isinstance(body, dict):
            return None
        if event_type == "ALGO_UPDATE":
            client_id = str(body.get("caid", body.get("clientAlgoId", body.get("clientAlgoID", ""))))
        else:
            client_id = str(body.get("c", body.get("clientOrderId", "")))
        if not client_id:
            return None

        action = self.ledger.find_position_management_action_by_client_id(client_id)
        if action is not None:
            # WebSocket payload only wakes the reducer; REST state remains authoritative.
            return self.adapter.reconcile_action(action["action_id"])

        if event_type == "ALGO_UPDATE":
            event_status = str(body.get("algoStatus", body.get("X", body.get("status", "")))).upper()
            if event_status not in {"TRIGGERED", "FINISHED", "EXECUTED", "FILLED"}:
                return None
            for row in self.ledger.list_managed_positions(status="OPEN"):
                signal_id = str(row["signal_id"])
                state_row = self.ledger.get_position_management_state(signal_id)
                state = state_row.get("state", {}) if state_row else {}
                protection_ids = {
                    str(state.get("stop_algo_client_id", self.ledger.deterministic_client_id(signal_id, "STOP_LOSS"))),
                    str(state.get("take_profit_algo_client_id", self.ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"))),
                }
                prior_action = self.ledger.get_position_management_action(
                    f"protective-trigger:{signal_id}:{client_id}"
                )
                if client_id not in protection_ids and prior_action is None:
                    continue
                try:
                    exchange_order = self.adapter.client.get_algo_order(client_algo_id=client_id)
                except Exception as exc:
                    self.adapter._halt(
                        f"Protective Algo trigger cannot be REST-verified for {signal_id}: {exc}"
                    )
                    return {"signal_id": signal_id, "status": "PROTECTION_TRIGGER_UNVERIFIED"}
                return self._handle_protective_algo_trigger(row, client_id, exchange_order)
        return None
