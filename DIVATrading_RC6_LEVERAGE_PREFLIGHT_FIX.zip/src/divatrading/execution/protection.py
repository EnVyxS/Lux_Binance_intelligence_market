"""Quantity-scoped Binance USDⓈ-M Futures conditional protection helpers.

The builder intentionally never emits ``closePosition``. Quantity-scoped
protection uses reduceOnly in One-way Mode and explicit positionSide in Hedge
Mode, matching Binance's mutually-exclusive parameter rules.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any


PROTECTIVE_TYPES = {"STOP_MARKET", "TAKE_PROFIT_MARKET"}


def _decimal(value: Any, field: str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be Decimal-compatible") from exc
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


def build_quantity_scoped_protection_params(
    *,
    symbol: str,
    position_direction: str,
    position_side: str,
    dual_side_position: bool,
    order_type: str,
    quantity: Decimal | str,
    trigger_price: Decimal | str,
    working_type: str,
    price_protect: bool,
    client_algo_id: str,
) -> dict[str, Any]:
    """Build a fail-closed STOP/TP Algo payload for exactly one managed lot."""
    symbol = str(symbol).strip().upper()
    direction = str(position_direction).strip().upper()
    position_side = str(position_side).strip().upper()
    order_type = str(order_type).strip().upper()
    working_type = str(working_type).strip().upper()
    client_algo_id = str(client_algo_id).strip()
    qty = _decimal(quantity, "quantity")
    trigger = _decimal(trigger_price, "trigger_price")

    if not symbol or any(ch.isspace() for ch in symbol):
        raise ValueError("symbol must be a non-empty exchange symbol")
    if direction not in {"LONG", "SHORT"}:
        raise ValueError("position_direction must be LONG or SHORT")
    if order_type not in PROTECTIVE_TYPES:
        raise ValueError("order_type must be STOP_MARKET or TAKE_PROFIT_MARKET")
    if working_type not in {"MARK_PRICE", "CONTRACT_PRICE"}:
        raise ValueError("working_type must be MARK_PRICE or CONTRACT_PRICE")
    if qty <= 0 or trigger <= 0:
        raise ValueError("quantity and trigger_price must be positive")
    if not client_algo_id or len(client_algo_id) > 36:
        raise ValueError("client_algo_id must contain 1..36 characters")

    expected_position_side = direction if dual_side_position else "BOTH"
    if position_side != expected_position_side:
        raise ValueError(
            f"position_side {position_side} conflicts with mode/direction; expected {expected_position_side}"
        )

    payload: dict[str, Any] = {
        "symbol": symbol,
        "side": "SELL" if direction == "LONG" else "BUY",
        "type": order_type,
        "quantity": qty,
        "triggerPrice": trigger,
        "workingType": working_type,
        "priceProtect": bool(price_protect),
        "positionSide": position_side,
        "clientAlgoId": client_algo_id,
    }
    if not dual_side_position:
        payload["reduceOnly"] = True
    # Do not add closePosition: Binance disallows it alongside quantity.
    return payload


def is_active_algo_order(order: dict[str, Any]) -> bool:
    status = str(order.get("algoStatus", order.get("status", ""))).upper()
    return status in {"NEW", "PENDING_NEW", "WORKING", "PENDING", "PARTIALLY_FILLED"}


def _matches_optional_order_identity(
    order: dict[str, Any],
    *,
    expected_symbol: str | None = None,
    expected_client_algo_id: str | None = None,
    expected_trigger_price: Decimal | str | None = None,
) -> bool:
    """Verify exchange identity fields that are available on Algo Order responses."""
    if expected_symbol is not None:
        if str(order.get("symbol", "")).upper() != expected_symbol.upper():
            return False
    if expected_client_algo_id is not None:
        actual_id = str(order.get("clientAlgoId", order.get("clientAlgoID", "")))
        if actual_id != expected_client_algo_id:
            return False
    if expected_trigger_price is not None:
        try:
            actual_trigger = _decimal(
                order.get("triggerPrice", order.get("stopPrice")), "order.triggerPrice"
            )
            expected_trigger = _decimal(expected_trigger_price, "expected_trigger_price")
        except ValueError:
            return False
        if actual_trigger != expected_trigger:
            return False
    return True


def is_quantity_scoped_order_valid(
    order: dict[str, Any],
    *,
    expected_quantity: Decimal | str,
    dual_side_position: bool,
    expected_position_side: str,
    expected_order_side: str,
    expected_type: str,
    expected_symbol: str | None = None,
    expected_client_algo_id: str | None = None,
    expected_trigger_price: Decimal | str | None = None,
) -> bool:
    """Check active order identity, quantity, trigger and mode-specific reduce semantics.

    The optional identity arguments let callers bind an exchange response to the exact
    managed symbol/clientAlgoId/trigger. They are deliberately optional for older call
    sites, but all entry, resize, stop-replacement and reconciliation paths supply them.
    """
    if not is_active_algo_order(order):
        return False
    if not _matches_optional_order_identity(
        order, expected_symbol=expected_symbol,
        expected_client_algo_id=expected_client_algo_id,
        expected_trigger_price=expected_trigger_price,
    ):
        return False
    if str(order.get("type", order.get("orderType", ""))).upper() != expected_type.upper():
        return False
    if str(order.get("side", "")).upper() != expected_order_side.upper():
        return False
    if str(order.get("positionSide", "BOTH")).upper() != expected_position_side.upper():
        return False
    close_position = order.get("closePosition", False)
    close_position = close_position is True or str(close_position).strip().lower() in {"true", "1"}
    if close_position:
        return False
    try:
        actual = _decimal(order.get("quantity", order.get("origQty")), "order.quantity")
        expected = _decimal(expected_quantity, "expected_quantity")
    except ValueError:
        return False
    if actual != expected:
        return False
    reduce_only = order.get("reduceOnly", False)
    reduce_only = reduce_only is True or str(reduce_only).strip().lower() in {"true", "1"}
    return reduce_only if not dual_side_position else not reduce_only


def is_legacy_close_position_order_valid(
    order: dict[str, Any],
    *,
    expected_position_side: str,
    expected_order_side: str,
    expected_type: str,
    expected_symbol: str | None = None,
    expected_client_algo_id: str | None = None,
    expected_trigger_price: Decimal | str | None = None,
) -> bool:
    """Recognize an existing pre-v0.52 close-all order for migration only."""
    if not is_active_algo_order(order):
        return False
    if not _matches_optional_order_identity(
        order, expected_symbol=expected_symbol,
        expected_client_algo_id=expected_client_algo_id,
        expected_trigger_price=expected_trigger_price,
    ):
        return False
    if str(order.get("type", order.get("orderType", ""))).upper() != expected_type.upper():
        return False
    if str(order.get("side", "")).upper() != expected_order_side.upper():
        return False
    if str(order.get("positionSide", "BOTH")).upper() != expected_position_side.upper():
        return False
    close_position = order.get("closePosition", False)
    close_position = close_position is True or str(close_position).strip().lower() in {"true", "1"}
    reduce_only = order.get("reduceOnly", False)
    reduce_only = reduce_only is True or str(reduce_only).strip().lower() in {"true", "1"}
    return close_position and not reduce_only and order.get("quantity") is None and order.get("origQty") is None
