"""Deterministic accounting primitives for aggregated Binance position sides.

The accounting layer groups independent signal lots without changing the exchange
position or enabling concurrent same-side execution. Exchange fills must be
attributed to their originating client order whenever possible; FIFO is an
explicit fallback policy for externally attributed aggregate reductions only.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Iterable, Mapping


_ZERO = Decimal("0")


def _decimal(value: Any, field: str, *, allow_zero: bool = False) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except Exception as exc:
        raise ValueError(f"{field} must be a decimal value") from exc
    if not result.is_finite() or result < 0 or (result == 0 and not allow_zero):
        qualifier = "finite and non-negative" if allow_zero else "finite and positive"
        raise ValueError(f"{field} must be {qualifier}")
    return result


@dataclass(frozen=True, slots=True)
class PositionLot:
    signal_id: str
    symbol: str
    position_side: str
    side: str
    quantity: Decimal
    entry_price: Decimal
    stop_loss: Decimal
    take_profit: Decimal
    opened_at_utc: str = ""


@dataclass(frozen=True, slots=True)
class PositionProtectionAllocation:
    signal_id: str
    quantity: Decimal
    stop_loss: Decimal
    take_profit: Decimal


@dataclass(frozen=True, slots=True)
class FillAllocation:
    signal_id: str
    quantity: Decimal


@dataclass(frozen=True, slots=True)
class PositionGroup:
    symbol: str
    position_side: str
    side: str
    quantity: Decimal
    weighted_entry_price: Decimal
    lots: tuple[PositionLot, ...]

    @property
    def notional(self) -> Decimal:
        return self.quantity * self.weighted_entry_price

    @property
    def protection_allocations(self) -> tuple[PositionProtectionAllocation, ...]:
        """Desired per-signal coverage; this is a plan, not proof of live orders."""
        return tuple(
            PositionProtectionAllocation(
                signal_id=lot.signal_id,
                quantity=lot.quantity,
                stop_loss=lot.stop_loss,
                take_profit=lot.take_profit,
            )
            for lot in self.lots
        )

    @property
    def planned_stop_coverage(self) -> Decimal:
        return sum((item.quantity for item in self.protection_allocations), _ZERO)

    @property
    def planned_take_profit_coverage(self) -> Decimal:
        return sum((item.quantity for item in self.protection_allocations), _ZERO)

    def as_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "position_side": self.position_side,
            "side": self.side,
            "quantity": str(self.quantity),
            "weighted_entry_price": str(self.weighted_entry_price),
            "notional": str(self.notional),
            "allocation_count": len(self.lots),
            "planned_stop_coverage": str(self.planned_stop_coverage),
            "planned_take_profit_coverage": str(self.planned_take_profit_coverage),
            "protection_is_exchange_verified": False,
            "allocations": [
                {
                    "signal_id": lot.signal_id,
                    "quantity": str(lot.quantity),
                    "entry_price": str(lot.entry_price),
                    "stop_loss": str(lot.stop_loss),
                    "take_profit": str(lot.take_profit),
                    "opened_at_utc": lot.opened_at_utc,
                }
                for lot in self.lots
            ],
        }


def _lot_from_row(row: Mapping[str, Any]) -> PositionLot:
    signal_id = str(row.get("signal_id", "")).strip()
    symbol = str(row.get("symbol", "")).strip().upper()
    position_side = str(row.get("position_side", "")).strip().upper()
    signal_side = str(row.get("signal_side", "")).strip().upper()
    if not signal_id or not symbol:
        raise ValueError("managed position requires signal_id and symbol")
    if position_side not in {"BOTH", "LONG", "SHORT"}:
        raise ValueError(f"unsupported position_side: {position_side}")
    side = signal_side if position_side == "BOTH" else position_side
    if side not in {"LONG", "SHORT"}:
        raise ValueError("managed position cannot resolve LONG/SHORT direction")
    if signal_side in {"LONG", "SHORT"} and signal_side != side:
        raise ValueError(f"signal direction conflicts with position_side for {signal_id}")
    quantity = _decimal(row.get("quantity"), f"{signal_id}.quantity")
    entry = _decimal(row.get("entry_price"), f"{signal_id}.entry_price")
    stop = _decimal(row.get("stop_loss"), f"{signal_id}.stop_loss")
    take = _decimal(row.get("take_profit"), f"{signal_id}.take_profit")
    opened_at = str(row.get("opened_at_utc") or row.get("created_at_utc") or row.get("updated_at_utc") or "")
    return PositionLot(signal_id, symbol, position_side, side, quantity, entry, stop, take, opened_at)


def build_position_groups(rows: Iterable[Mapping[str, Any]]) -> tuple[PositionGroup, ...]:
    """Aggregate open managed lots by (symbol, positionSide) using exact decimals."""
    grouped: dict[tuple[str, str], list[PositionLot]] = {}
    for row in rows:
        if str(row.get("status", "OPEN")).upper() != "OPEN":
            continue
        lot = _lot_from_row(row)
        grouped.setdefault((lot.symbol, lot.position_side), []).append(lot)

    result: list[PositionGroup] = []
    for (symbol, position_side), lots in sorted(grouped.items()):
        directions = {lot.side for lot in lots}
        if len(directions) != 1:
            raise ValueError(f"conflicting directions in position group {symbol}/{position_side}")
        # FIFO order is stable across processes and restarts. signal_id resolves
        # identical/missing timestamps deterministically.
        ordered = tuple(sorted(lots, key=lambda lot: (lot.opened_at_utc, lot.signal_id)))
        quantity = sum((lot.quantity for lot in ordered), _ZERO)
        weighted_notional = sum((lot.quantity * lot.entry_price for lot in ordered), _ZERO)
        result.append(PositionGroup(
            symbol=symbol,
            position_side=position_side,
            side=next(iter(directions)),
            quantity=quantity,
            weighted_entry_price=weighted_notional / quantity,
            lots=ordered,
        ))
    return tuple(result)


def allocate_close_fill(
    group: PositionGroup,
    quantity: Decimal | str,
    *,
    signal_id: str | None = None,
) -> tuple[FillAllocation, ...]:
    """Allocate a close fill to a signal lot, or by deterministic FIFO if untagged.

    Live DIVATrading order fills should carry a known signal_id from the client
    order mapping. FIFO is intended only for reductions whose originating order
    is known to be external/manual and must never silently resolve an unknown
    DIVATrading-owned client order.
    """
    remaining = _decimal(quantity, "fill quantity")
    if remaining > group.quantity:
        raise ValueError("close fill exceeds aggregate managed quantity")
    if signal_id is not None:
        matches = [lot for lot in group.lots if lot.signal_id == signal_id]
        if len(matches) != 1:
            raise ValueError(f"signal_id is not present in position group: {signal_id}")
        lot = matches[0]
        if remaining > lot.quantity:
            raise ValueError("signal-attributed close fill exceeds that signal allocation")
        return (FillAllocation(lot.signal_id, remaining),)

    allocations: list[FillAllocation] = []
    for lot in group.lots:
        if remaining <= 0:
            break
        assigned = min(remaining, lot.quantity)
        if assigned > 0:
            allocations.append(FillAllocation(lot.signal_id, assigned))
            remaining -= assigned
    if remaining != 0:
        raise RuntimeError("FIFO close allocation did not consume the requested quantity")
    return tuple(allocations)


def validate_protection_coverage(
    group: PositionGroup,
    *,
    stop_quantity_by_signal: Mapping[str, Decimal | str],
    take_profit_quantity_by_signal: Mapping[str, Decimal | str],
) -> tuple[bool, tuple[str, ...]]:
    """Validate quantity-scoped stop and TP coverage for every managed lot."""
    reasons: list[str] = []
    expected = {lot.signal_id: lot.quantity for lot in group.lots}
    for label, supplied in (
        ("STOP_LOSS", stop_quantity_by_signal),
        ("TAKE_PROFIT", take_profit_quantity_by_signal),
    ):
        if set(supplied) != set(expected):
            reasons.append(f"{label}_ALLOCATION_SET_MISMATCH")
        for signal_id, quantity in expected.items():
            try:
                actual = _decimal(supplied.get(signal_id, "0"), f"{label}.{signal_id}", allow_zero=True)
            except ValueError:
                reasons.append(f"{label}_INVALID_QUANTITY:{signal_id}")
                continue
            if actual != quantity:
                reasons.append(f"{label}_QUANTITY_MISMATCH:{signal_id}")
    return not reasons, tuple(reasons)
