"""Durable SQLite execution ledger for idempotent intent and order lifecycle."""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from decimal import Decimal
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from divatrading.execution.position_accounting import build_position_groups


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


@dataclass(frozen=True, slots=True)
class RiskReservationResult:
    accepted: bool
    reason: str
    reserved_risk_usdt: Decimal
    active_reserved_risk_usdt: Decimal
    active_reservation_count: int
    active_reserved_symbol_notional_usdt: Decimal = Decimal("0")
    duplicate: bool = False


class ExecutionLedger:
    """SQLite ledger. A signal ID can be claimed only once, even across restarts."""
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path).expanduser().resolve()
        self._initialize()

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA busy_timeout=15000")
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
        finally:
            db.close()

    def _initialize(self) -> None:
        with self._connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS trade_intents (
                    signal_id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL CHECK(side IN ('LONG','SHORT')),
                    client_order_id TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL,
                    last_error TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_trade_intents_symbol_status
                    ON trade_intents(symbol,status);
                CREATE TABLE IF NOT EXISTS signal_dispatches (
                    signal_id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL CHECK(side IN ('LONG','SHORT')),
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    result_json TEXT NOT NULL DEFAULT '{}',
                    last_error TEXT,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_signal_dispatches_symbol_status
                    ON signal_dispatches(symbol,status);
                CREATE TABLE IF NOT EXISTS execution_orders (
                    client_id TEXT PRIMARY KEY,
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    symbol TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('ENTRY','STOP_LOSS','TAKE_PROFIT')),
                    order_kind TEXT NOT NULL CHECK(order_kind IN ('STANDARD','ALGO')),
                    exchange_order_id TEXT,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_execution_orders_signal
                    ON execution_orders(signal_id,role);
                CREATE TABLE IF NOT EXISTS execution_client_order_links (
                    client_order_id TEXT PRIMARY KEY,
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    symbol TEXT NOT NULL,
                    position_side TEXT NOT NULL DEFAULT 'BOTH',
                    role TEXT NOT NULL,
                    effect TEXT NOT NULL CHECK(effect IN ('OPEN','CLOSE','UNKNOWN')),
                    created_at_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS execution_exchange_order_links (
                    symbol TEXT NOT NULL,
                    exchange_order_id TEXT NOT NULL,
                    client_order_id TEXT NOT NULL,
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    position_side TEXT NOT NULL DEFAULT 'BOTH',
                    role TEXT NOT NULL,
                    effect TEXT NOT NULL CHECK(effect IN ('OPEN','CLOSE','UNKNOWN')),
                    created_at_utc TEXT NOT NULL,
                    PRIMARY KEY(symbol, exchange_order_id)
                );
                CREATE TABLE IF NOT EXISTS position_fill_allocations (
                    fill_key TEXT PRIMARY KEY,
                    event_id TEXT NOT NULL,
                    client_order_id TEXT NOT NULL,
                    signal_id TEXT REFERENCES trade_intents(signal_id),
                    symbol TEXT NOT NULL,
                    position_side TEXT NOT NULL,
                    order_role TEXT NOT NULL,
                    effect TEXT NOT NULL CHECK(effect IN ('OPEN','CLOSE','UNKNOWN')),
                    quantity TEXT NOT NULL,
                    price TEXT NOT NULL,
                    trade_id TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL,
                    allocation_status TEXT NOT NULL CHECK(allocation_status IN ('ATTRIBUTED','UNATTRIBUTED','EXTERNAL')),
                    payload_json TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_position_fill_signal_time
                    ON position_fill_allocations(signal_id,event_time_ms);
                CREATE INDEX IF NOT EXISTS idx_position_fill_symbol_side
                    ON position_fill_allocations(symbol,position_side,event_time_ms);
                CREATE TABLE IF NOT EXISTS position_fill_applications (
                    fill_key TEXT PRIMARY KEY REFERENCES position_fill_allocations(fill_key),
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    effect TEXT NOT NULL CHECK(effect IN ('OPEN','CLOSE')),
                    quantity TEXT NOT NULL,
                    price TEXT NOT NULL,
                    commission TEXT NOT NULL DEFAULT '0',
                    commission_asset TEXT NOT NULL DEFAULT '',
                    realized_pnl TEXT NOT NULL DEFAULT '0',
                    applied_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_fill_applications_signal
                    ON position_fill_applications(signal_id, applied_at_utc);
                CREATE TABLE IF NOT EXISTS position_fill_projections (
                    signal_id TEXT PRIMARY KEY REFERENCES trade_intents(signal_id),
                    symbol TEXT NOT NULL,
                    position_side TEXT NOT NULL,
                    entry_quantity TEXT NOT NULL,
                    entry_notional TEXT NOT NULL,
                    close_quantity TEXT NOT NULL,
                    net_quantity TEXT NOT NULL,
                    weighted_entry_price TEXT NOT NULL,
                    commissions_json TEXT NOT NULL,
                    realized_pnl_json TEXT NOT NULL,
                    fill_count INTEGER NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS managed_positions (
                    symbol TEXT NOT NULL,
                    position_side TEXT NOT NULL,
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    quantity TEXT NOT NULL,
                    entry_price TEXT NOT NULL,
                    stop_loss TEXT NOT NULL,
                    take_profit TEXT NOT NULL,
                    status TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL,
                    opened_at_utc TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY(symbol,position_side,signal_id)
                );
                CREATE TABLE IF NOT EXISTS execution_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signal_id TEXT,
                    symbol TEXT,
                    event_type TEXT NOT NULL,
                    detail_json TEXT NOT NULL,
                    occurred_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_execution_events_time
                    ON execution_events(occurred_at_utc DESC);
                CREATE TABLE IF NOT EXISTS execution_control (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    entries_halted INTEGER NOT NULL CHECK(entries_halted IN (0,1)),
                    halt_reason TEXT,
                    updated_at_utc TEXT NOT NULL
                );
                INSERT OR IGNORE INTO execution_control(id,entries_halted,halt_reason,updated_at_utc)
                    VALUES(1,0,NULL,'1970-01-01T00:00:00Z');
                CREATE TABLE IF NOT EXISTS income_history (
                    income_type TEXT NOT NULL,
                    tran_id TEXT NOT NULL,
                    symbol TEXT NOT NULL DEFAULT '',
                    income TEXT NOT NULL,
                    asset TEXT NOT NULL,
                    time_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY(income_type,tran_id)
                );
                CREATE TABLE IF NOT EXISTS income_backfill_state (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    watermark_ms INTEGER NOT NULL DEFAULT 0,
                    updated_at_utc TEXT NOT NULL,
                    last_error TEXT
                );
                INSERT OR IGNORE INTO income_backfill_state(id,watermark_ms,updated_at_utc,last_error)
                    VALUES(1,0,'1970-01-01T00:00:00Z',NULL);
                CREATE TABLE IF NOT EXISTS income_cashflow_adjustment (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    net_transfer_usdt TEXT NOT NULL DEFAULT '0',
                    updated_at_utc TEXT NOT NULL
                );
                INSERT OR IGNORE INTO income_cashflow_adjustment(id,net_transfer_usdt,updated_at_utc)
                    VALUES(1,'0','1970-01-01T00:00:00Z');
                CREATE TABLE IF NOT EXISTS risk_reservations (
                    signal_id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    risk_usdt TEXT NOT NULL,
                    notional_usdt TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('ACTIVE','RELEASED')),
                    release_reason TEXT,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_risk_reservations_status
                    ON risk_reservations(status,created_at_utc);
                CREATE TABLE IF NOT EXISTS user_stream_events (
                    event_id TEXT PRIMARY KEY,
                    event_type TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL,
                    transaction_time_ms INTEGER NOT NULL,
                    symbol TEXT NOT NULL DEFAULT '',
                    payload_json TEXT NOT NULL,
                    received_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_user_stream_events_time
                    ON user_stream_events(event_time_ms DESC);
                CREATE TABLE IF NOT EXISTS user_stream_balances (
                    asset TEXT PRIMARY KEY,
                    wallet_balance TEXT NOT NULL,
                    cross_wallet_balance TEXT NOT NULL,
                    balance_change TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS user_stream_positions (
                    symbol TEXT NOT NULL,
                    position_side TEXT NOT NULL,
                    quantity TEXT NOT NULL,
                    entry_price TEXT NOT NULL,
                    break_even_price TEXT NOT NULL,
                    unrealized_pnl TEXT NOT NULL,
                    margin_type TEXT NOT NULL,
                    isolated_wallet TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY(symbol,position_side)
                );
                CREATE TABLE IF NOT EXISTS user_stream_orders (
                    order_key TEXT PRIMARY KEY,
                    order_kind TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    status TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS user_stream_control (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    status TEXT NOT NULL,
                    listen_key_fingerprint TEXT,
                    connected_at_ms INTEGER,
                    last_event_at_ms INTEGER,
                    updated_at_ms INTEGER NOT NULL,
                    last_error TEXT
                );
                INSERT OR IGNORE INTO user_stream_control
                    (id,status,listen_key_fingerprint,connected_at_ms,last_event_at_ms,updated_at_ms,last_error)
                    VALUES(1,'DISCONNECTED',NULL,NULL,NULL,0,NULL);
                CREATE TABLE IF NOT EXISTS position_management_state (
                    signal_id TEXT PRIMARY KEY REFERENCES trade_intents(signal_id),
                    symbol TEXT NOT NULL,
                    state_json TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS position_management_actions (
                    action_id TEXT PRIMARY KEY,
                    signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                    action_kind TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_position_management_actions_signal
                    ON position_management_actions(signal_id,status);
                CREATE TABLE IF NOT EXISTS trade_backfill_watermarks (
                    symbol TEXT PRIMARY KEY,
                    last_trade_id INTEGER NOT NULL DEFAULT -1,
                    last_trade_time_ms INTEGER NOT NULL DEFAULT 0,
                    completed_through_ms INTEGER NOT NULL DEFAULT 0,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS trade_backfill_runs (
                    run_id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    range_start_ms INTEGER NOT NULL,
                    range_end_ms INTEGER NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('RUNNING','COMPLETE','FAILED')) ,
                    page_count INTEGER NOT NULL DEFAULT 0,
                    trade_count INTEGER NOT NULL DEFAULT 0,
                    max_trade_id INTEGER NOT NULL DEFAULT -1,
                    max_trade_time_ms INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT,
                    started_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_trade_backfill_runs_symbol
                    ON trade_backfill_runs(symbol,started_at_utc);
                CREATE TABLE IF NOT EXISTS reconciliation_state (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    ready INTEGER NOT NULL CHECK(ready IN (0,1)),
                    status TEXT NOT NULL,
                    captured_at_ms INTEGER,
                    detail_json TEXT NOT NULL,
                    updated_at_ms INTEGER NOT NULL
                );
                INSERT OR IGNORE INTO reconciliation_state
                    (id,ready,status,captured_at_ms,detail_json,updated_at_ms)
                    VALUES(1,0,'NOT_RECONCILED',NULL,'{}',0);
            """)
            columns = {str(row["name"]) for row in db.execute("PRAGMA table_info(managed_positions)")}
            if "opened_at_utc" not in columns:
                db.execute("ALTER TABLE managed_positions ADD COLUMN opened_at_utc TEXT NOT NULL DEFAULT ''")
            db.execute("UPDATE managed_positions SET opened_at_utc=updated_at_utc WHERE opened_at_utc='' ")
            fill_columns = {str(row["name"]) for row in db.execute("PRAGMA table_info(position_fill_allocations)")}
            for name, definition in (
                ("exchange_order_id", "TEXT NOT NULL DEFAULT ''"),
                ("order_side", "TEXT NOT NULL DEFAULT ''"),
                ("commission", "TEXT NOT NULL DEFAULT '0'"),
                ("commission_asset", "TEXT NOT NULL DEFAULT ''"),
                ("realized_pnl", "TEXT NOT NULL DEFAULT '0'"),
                ("is_maker", "INTEGER"),
                ("source", "TEXT NOT NULL DEFAULT 'USER_STREAM'"),
            ):
                if name not in fill_columns:
                    db.execute(f"ALTER TABLE position_fill_allocations ADD COLUMN {name} {definition}")

    @staticmethod
    def deterministic_client_id(signal_id: str, role: str = "ENTRY") -> str:
        digest = hashlib.sha256(f"{signal_id}|{role}".encode("utf-8")).hexdigest()[:24].upper()
        prefix = {"ENTRY": "DIVA", "STOP_LOSS": "DIVASL", "TAKE_PROFIT": "DIVATP"}.get(role, "DIVA")
        return f"{prefix}{digest}"[:36]

    def claim_intent(self, *, signal_id: str, symbol: str, side: str, client_order_id: str,
                     payload: dict[str, Any]) -> bool:
        now = _now()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                cursor = db.execute("""INSERT OR IGNORE INTO trade_intents
                    (signal_id,symbol,side,client_order_id,status,payload_json,created_at_utc,updated_at_utc)
                    VALUES (?,?,?,?,?,?,?,?)""",
                    (signal_id, symbol, side, client_order_id, "CLAIMED", _json(payload), now, now))
                created = cursor.rowcount == 1
                db.commit()
                return created
            except Exception:
                db.rollback()
                raise

    def update_intent(self, signal_id: str, status: str, *, error: str | None = None) -> None:
        with self._connection() as db:
            db.execute("UPDATE trade_intents SET status=?,last_error=?,updated_at_utc=? WHERE signal_id=?",
                       (status, error, _now(), signal_id))

    def claim_signal_dispatch(self, *, signal_id: str, symbol: str, side: str,
                              payload: dict[str, Any]) -> bool:
        """Durably claim a qualified SMC signal before any account/exchange I/O.

        The unique signal_id is the at-most-once boundary across workers and restarts.
        A claimed dispatch is never automatically reclaimed after a crash: operators
        must reconcile its status before an explicit retry/new signal is considered.
        """
        if not signal_id or not signal_id.strip():
            raise ValueError("signal_id must be non-empty")
        normalized_symbol = symbol.strip().upper()
        normalized_side = side.strip().upper()
        if not normalized_symbol or normalized_side not in {"LONG", "SHORT"}:
            raise ValueError("dispatch symbol/side is invalid")
        now = _now()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                cursor = db.execute("""INSERT OR IGNORE INTO signal_dispatches
                    (signal_id,symbol,side,status,payload_json,result_json,last_error,created_at_utc,updated_at_utc)
                    VALUES(?,?,?,?,?,'{}',NULL,?,?)""",
                    (signal_id, normalized_symbol, normalized_side, "CLAIMED",
                     _json(payload), now, now))
                created = cursor.rowcount == 1
                db.commit()
                return created
            except Exception:
                db.rollback()
                raise

    def update_signal_dispatch(self, signal_id: str, status: str, *,
                               result: dict[str, Any] | None = None,
                               error: str | None = None) -> None:
        if not status or not status.strip():
            raise ValueError("dispatch status must be non-empty")
        with self._connection() as db:
            cursor = db.execute("""UPDATE signal_dispatches SET status=?,result_json=?,
                last_error=?,updated_at_utc=? WHERE signal_id=?""",
                (status.strip().upper(), _json(result or {}), error, _now(), signal_id))
            if cursor.rowcount != 1:
                raise KeyError(f"Unknown durable signal dispatch: {signal_id}")

    def get_signal_dispatch(self, signal_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute("SELECT * FROM signal_dispatches WHERE signal_id=?", (signal_id,)).fetchone()
            if row is None:
                return None
            result = dict(row)
            result["payload"] = json.loads(result.pop("payload_json"))
            result["result"] = json.loads(result.pop("result_json"))
            return result

    def list_signal_dispatches(self, *, statuses: tuple[str, ...] | None = None,
                               limit: int = 100) -> list[dict[str, Any]]:
        if isinstance(limit, bool) or not 1 <= limit <= 10000:
            raise ValueError("limit must be between 1 and 10000")
        with self._connection() as db:
            if statuses:
                placeholders = ",".join("?" for _ in statuses)
                rows = db.execute(
                    f"SELECT * FROM signal_dispatches WHERE status IN ({placeholders}) ORDER BY created_at_utc LIMIT ?",
                    (*tuple(statuses), limit),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT * FROM signal_dispatches ORDER BY created_at_utc LIMIT ?", (limit,),
                ).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                item["payload"] = json.loads(item.pop("payload_json"))
                item["result"] = json.loads(item.pop("result_json"))
                result.append(item)
            return result

    @staticmethod
    def _fill_effect(role: str) -> str:
        normalized = str(role).upper()
        if normalized == "ENTRY":
            return "OPEN"
        if normalized in {"STOP_LOSS", "TAKE_PROFIT", "PARTIAL_TP", "STRUCTURAL_EXIT",
                          "EMERGENCY_CLOSE", "MARKET_EXIT", "EXIT"}:
            return "CLOSE"
        return "UNKNOWN"

    @staticmethod
    def _register_client_order_link(
        db: sqlite3.Connection, *, client_order_id: str, signal_id: str,
        symbol: str, position_side: str, role: str, effect: str,
    ) -> None:
        if not client_order_id:
            return
        existing = db.execute(
            "SELECT signal_id,symbol,position_side,role,effect FROM execution_client_order_links WHERE client_order_id=?",
            (client_order_id,),
        ).fetchone()
        if existing is not None:
            if (existing["signal_id"] != signal_id or existing["symbol"].upper() != symbol.upper()
                    or existing["position_side"].upper() != position_side.upper()
                    or existing["role"] != role.upper() or existing["effect"] != effect):
                raise RuntimeError(f"CLIENT_ORDER_ID_OWNERSHIP_CONFLICT:{client_order_id}")
            return
        db.execute("""INSERT INTO execution_client_order_links
            (client_order_id,signal_id,symbol,position_side,role,effect,created_at_utc)
            VALUES(?,?,?,?,?,?,?)""",
            (client_order_id, signal_id, symbol.upper(), position_side.upper(), role.upper(), effect, _now()))
        # A user-stream fill can race the REST response persistence. Once the
        # durable owner is known, backfill its previously unattributed evidence.
        db.execute("""UPDATE position_fill_allocations
            SET signal_id=?,position_side=?,order_role=?,effect=?,allocation_status='ATTRIBUTED'
            WHERE client_order_id=? AND signal_id IS NULL
              AND allocation_status IN ('UNATTRIBUTED','EXTERNAL')""",
            (signal_id, position_side.upper(), role.upper(), effect, client_order_id))

    def record_order(self, *, client_id: str, signal_id: str, symbol: str, role: str,
                     order_kind: str, status: str, exchange_order_id: str | int | None,
                     payload: dict[str, Any]) -> None:
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("""INSERT INTO execution_orders
                    (client_id,signal_id,symbol,role,order_kind,exchange_order_id,status,payload_json,updated_at_utc)
                    VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(client_id) DO UPDATE SET exchange_order_id=excluded.exchange_order_id,
                    status=excluded.status,payload_json=excluded.payload_json,updated_at_utc=excluded.updated_at_utc""",
                    (client_id, signal_id, symbol, role, order_kind,
                     None if exchange_order_id is None else str(exchange_order_id), status,
                     _json(payload), _now()))
                inferred_side = str(payload.get("positionSide") or "BOTH").upper()
                self._register_client_order_link(
                    db, client_order_id=client_id, signal_id=signal_id, symbol=symbol,
                    position_side=inferred_side, role=role, effect=self._fill_effect(role),
                )
                # Algo IDs and matching-engine order IDs are separate Binance ID
                # namespaces. Only standard order IDs can resolve ORDER_TRADE_UPDATE.i.
                if order_kind.upper() == "STANDARD" and exchange_order_id not in (None, ""):
                    self._register_exchange_order_link(
                        db, symbol=symbol, exchange_order_id=str(exchange_order_id),
                        client_order_id=client_id, signal_id=signal_id,
                        position_side=inferred_side, role=role,
                        effect=self._fill_effect(role),
                    )
                db.commit()
            except Exception:
                db.rollback()
                raise
        # A stream fill may have arrived before the REST acknowledgement supplied
        # its owner mapping. Rebuild the immutable-fill projection after commit.
        self.apply_position_fill_allocations(signal_id=signal_id)

    @staticmethod
    def _register_exchange_order_link(
        db: sqlite3.Connection, *, symbol: str, exchange_order_id: str,
        client_order_id: str, signal_id: str, position_side: str,
        role: str, effect: str,
    ) -> None:
        """Persist matching-engine order ownership, including triggered Algo orders."""
        normalized_symbol = symbol.upper()
        existing = db.execute(
            "SELECT client_order_id,signal_id,position_side,role,effect "
            "FROM execution_exchange_order_links WHERE symbol=? AND exchange_order_id=?",
            (normalized_symbol, exchange_order_id),
        ).fetchone()
        if existing is not None:
            if (existing["signal_id"] != signal_id
                    or existing["position_side"].upper() != position_side.upper()
                    or existing["role"] != role.upper()
                    or existing["effect"] != effect):
                raise RuntimeError(f"EXCHANGE_ORDER_ID_OWNERSHIP_CONFLICT:{normalized_symbol}:{exchange_order_id}")
            return
        db.execute(
            "INSERT INTO execution_exchange_order_links "
            "(symbol,exchange_order_id,client_order_id,signal_id,position_side,role,effect,created_at_utc) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (normalized_symbol, exchange_order_id, client_order_id, signal_id,
             position_side.upper(), role.upper(), effect, _now()),
        )
        conflicting_fill = db.execute(
            "SELECT fill_key,signal_id FROM position_fill_allocations "
            "WHERE symbol=? AND exchange_order_id=? AND signal_id IS NOT NULL AND signal_id<>? LIMIT 1",
            (normalized_symbol, exchange_order_id, signal_id),
        ).fetchone()
        if conflicting_fill is not None:
            raise RuntimeError(
                f"EXCHANGE_ORDER_FILL_OWNERSHIP_CONFLICT:{normalized_symbol}:{exchange_order_id}:{conflicting_fill['fill_key']}"
            )
        # REST userTrades can be recovered before the local order acknowledgement
        # has persisted its exchange order link. Re-attribute that exact order's
        # previously external/unattributed fills once durable ownership is known.
        db.execute("""UPDATE position_fill_allocations SET
            signal_id=?,position_side=?,order_role=?,effect=?,allocation_status='ATTRIBUTED',
            client_order_id=?
            WHERE symbol=? AND exchange_order_id=? AND signal_id IS NULL
              AND allocation_status IN ('UNATTRIBUTED','EXTERNAL')""",
            (signal_id, position_side.upper(), role.upper(), effect, client_order_id,
             normalized_symbol, exchange_order_id))
    def link_exchange_order_to_signal(
        self, *, symbol: str, exchange_order_id: str | int,
        client_order_id: str, signal_id: str, position_side: str, role: str,
    ) -> None:
        """Link a verified matching-engine child order to its protective signal lot.

        Binance conditional Algo IDs and the triggered child MARKET order IDs belong
        to different namespaces. Once the child is verified by REST, this mapping lets
        late ORDER_TRADE_UPDATE and `/fapi/v1/userTrades` fills resolve by the child
        exchange order ID even when its generated clientOrderId is not DIVA-owned.
        """
        normalized_symbol = str(symbol).strip().upper()
        normalized_order_id = str(exchange_order_id).strip()
        normalized_client_id = str(client_order_id).strip()
        normalized_signal_id = str(signal_id).strip()
        normalized_position_side = str(position_side).strip().upper()
        normalized_role = str(role).strip().upper()
        if not normalized_symbol or not normalized_order_id or not normalized_client_id or not normalized_signal_id:
            raise ValueError("protective child-order link identity must be non-empty")
        if not normalized_order_id.isdigit() or int(normalized_order_id) <= 0:
            raise ValueError("protective child exchange order ID must be a positive integer")
        if normalized_position_side not in {"BOTH", "LONG", "SHORT"}:
            raise ValueError("protective child positionSide is invalid")
        if normalized_role not in {"STOP_LOSS", "TAKE_PROFIT"}:
            raise ValueError("only protective STOP/TP child orders can be linked by this method")

        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                intent = db.execute(
                    "SELECT symbol FROM trade_intents WHERE signal_id=?",
                    (normalized_signal_id,),
                ).fetchone()
                if intent is None:
                    raise RuntimeError(f"PROTECTIVE_CHILD_SIGNAL_INTENT_MISSING:{normalized_signal_id}")
                if str(intent["symbol"]).upper() != normalized_symbol:
                    raise RuntimeError("PROTECTIVE_CHILD_SIGNAL_SYMBOL_MISMATCH")
                self._register_exchange_order_link(
                    db, symbol=normalized_symbol, exchange_order_id=normalized_order_id,
                    client_order_id=normalized_client_id, signal_id=normalized_signal_id,
                    position_side=normalized_position_side, role=normalized_role,
                    effect="CLOSE",
                )
                db.commit()
            except Exception:
                db.rollback()
                raise

        # A REST fill may have been stored as EXTERNAL before this exact ownership
        # mapping became available. Recompute the immutable fill projection now.
        self.apply_position_fill_allocations(signal_id=normalized_signal_id)

    def get_exchange_order_link(
        self, *, symbol: str, exchange_order_id: str | int,
    ) -> dict[str, Any] | None:
        """Return the durable owner/role mapping for one matching-engine order."""
        normalized_symbol = str(symbol).strip().upper()
        normalized_order_id = str(exchange_order_id).strip()
        if not normalized_symbol or not normalized_order_id:
            raise ValueError("exchange order lookup identity must be non-empty")
        with self._connection() as db:
            row = db.execute(
                "SELECT * FROM execution_exchange_order_links WHERE symbol=? AND exchange_order_id=?",
                (normalized_symbol, normalized_order_id),
            ).fetchone()
            return None if row is None else dict(row)

    def has_order_role(self, signal_id: str, role: str) -> bool:
        with self._connection() as db:
            row = db.execute("SELECT 1 FROM execution_orders WHERE signal_id=? AND role=? LIMIT 1",
                             (signal_id, role)).fetchone()
            return row is not None

    def get_intent(self, signal_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute("SELECT * FROM trade_intents WHERE signal_id=?", (signal_id,)).fetchone()
            return None if row is None else dict(row)

    def record_position(self, *, symbol: str, position_side: str, signal_id: str,
                        quantity: str, entry_price: str, stop_loss: str, take_profit: str,
                        status: str = "OPEN") -> None:
        now = _now()
        with self._connection() as db:
            db.execute("""INSERT INTO managed_positions
                (symbol,position_side,signal_id,quantity,entry_price,stop_loss,take_profit,status,updated_at_utc,opened_at_utc)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(symbol,position_side,signal_id) DO UPDATE SET
                quantity=excluded.quantity,entry_price=excluded.entry_price,
                stop_loss=excluded.stop_loss,take_profit=excluded.take_profit,
                status=excluded.status,updated_at_utc=excluded.updated_at_utc""",
                (symbol, position_side, signal_id, quantity, entry_price, stop_loss,
                 take_profit, status, now, now))

    def record_event(self, event_type: str, *, signal_id: str | None = None,
                     symbol: str | None = None, detail: dict[str, Any] | None = None) -> None:
        with self._connection() as db:
            db.execute("INSERT INTO execution_events(signal_id,symbol,event_type,detail_json,occurred_at_utc) VALUES(?,?,?,?,?)",
                       (signal_id, symbol, event_type, _json(detail or {}), _now()))


    @staticmethod
    def _positive_decimal(value: Decimal, field: str, *, allow_zero: bool = False) -> Decimal:
        if not isinstance(value, Decimal) or not value.is_finite():
            raise ValueError(f"{field} must be a finite Decimal")
        if value < 0 or (value == 0 and not allow_zero):
            qualifier = "non-negative" if allow_zero else "positive"
            raise ValueError(f"{field} must be {qualifier}")
        return value

    def reserve_portfolio_risk(
        self,
        *,
        signal_id: str,
        symbol: str,
        risk_usdt: Decimal,
        notional_usdt: Decimal,
        equity_usdt: Decimal,
        exchange_open_risk_usdt: Decimal,
        exchange_active_position_count: int,
        max_positions: int,
        max_portfolio_open_risk_pct: Decimal,
        exchange_symbol_notional_usdt: Decimal,
        max_symbol_notional_usdt: Decimal,
    ) -> RiskReservationResult:
        """Atomically reserve risk against exchange state plus all local active reservations.

        BEGIN IMMEDIATE serializes competing processes sharing this SQLite ledger. Exchange
        state is an external snapshot; local reservations close the same-process and
        cross-process race between independent symbol workers.
        """
        self._positive_decimal(risk_usdt, "risk_usdt")
        self._positive_decimal(notional_usdt, "notional_usdt")
        self._positive_decimal(equity_usdt, "equity_usdt")
        self._positive_decimal(exchange_open_risk_usdt, "exchange_open_risk_usdt", allow_zero=True)
        self._positive_decimal(max_portfolio_open_risk_pct, "max_portfolio_open_risk_pct")
        self._positive_decimal(exchange_symbol_notional_usdt, "exchange_symbol_notional_usdt", allow_zero=True)
        self._positive_decimal(max_symbol_notional_usdt, "max_symbol_notional_usdt")
        if not signal_id or not signal_id.strip():
            raise ValueError("signal_id must be non-empty")
        if not symbol or not symbol.strip():
            raise ValueError("symbol must be non-empty")
        if (
            isinstance(exchange_active_position_count, bool)
            or not isinstance(exchange_active_position_count, int)
            or exchange_active_position_count < 0
        ):
            raise ValueError("exchange_active_position_count must be a non-negative integer")
        if isinstance(max_positions, bool) or not isinstance(max_positions, int) or max_positions < 1:
            raise ValueError("max_positions must be a positive integer")

        now = _now()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                existing = db.execute(
                    "SELECT risk_usdt,notional_usdt,status FROM risk_reservations WHERE signal_id=?",
                    (signal_id,),
                ).fetchone()
                if existing is not None:
                    active_rows = db.execute(
                        "SELECT risk_usdt,notional_usdt,symbol FROM risk_reservations WHERE status='ACTIVE'"
                    ).fetchall()
                    total = sum((Decimal(row["risk_usdt"]) for row in active_rows), Decimal("0"))
                    count = len(active_rows)
                    existing_risk = Decimal(existing["risk_usdt"])
                    active_symbol_notional = sum(
                        (Decimal(row["notional_usdt"]) for row in active_rows
                         if row["symbol"] == symbol.strip().upper()), Decimal("0")
                    )
                    if existing["status"] == "ACTIVE":
                        db.commit()
                        return RiskReservationResult(True, "RISK_ALREADY_RESERVED", existing_risk,
                                                     total, count, active_symbol_notional, duplicate=True)
                    db.commit()
                    return RiskReservationResult(False, "SIGNAL_RESERVATION_ALREADY_RELEASED",
                                                 existing_risk, total, count, active_symbol_notional,
                                                 duplicate=True)

                active_rows = db.execute(
                    "SELECT risk_usdt,notional_usdt,symbol FROM risk_reservations WHERE status='ACTIVE'"
                ).fetchall()
                active_reserved = sum(
                    (Decimal(row["risk_usdt"]) for row in active_rows), Decimal("0")
                )
                active_count = len(active_rows)
                active_symbol_notional = sum(
                    (Decimal(row["notional_usdt"]) for row in active_rows
                     if row["symbol"] == symbol.strip().upper()), Decimal("0")
                )
                cap = equity_usdt * max_portfolio_open_risk_pct / Decimal("100")
                combined_risk = exchange_open_risk_usdt + active_reserved + risk_usdt
                if exchange_active_position_count + active_count >= max_positions:
                    db.commit()
                    return RiskReservationResult(
                        False, "MAX_OPEN_POSITIONS_RESERVED", risk_usdt,
                        active_reserved, active_count,
                    )
                if combined_risk > cap:
                    db.commit()
                    return RiskReservationResult(
                        False, "PORTFOLIO_RISK_RESERVATION_EXCEEDS_CAP", risk_usdt,
                        active_reserved, active_count, active_symbol_notional,
                    )
                combined_symbol_notional = (
                    exchange_symbol_notional_usdt + active_symbol_notional + notional_usdt
                )
                if combined_symbol_notional > max_symbol_notional_usdt:
                    db.commit()
                    return RiskReservationResult(
                        False, "SYMBOL_NOTIONAL_RESERVATION_EXCEEDS_CAP", risk_usdt,
                        active_reserved, active_count, active_symbol_notional,
                    )
                db.execute(
                    "INSERT INTO risk_reservations "
                    "(signal_id,symbol,risk_usdt,notional_usdt,status,release_reason,created_at_utc,updated_at_utc) "
                    "VALUES(?,?,?,?, 'ACTIVE',NULL,?,?)",
                    (signal_id, symbol.strip().upper(), str(risk_usdt), str(notional_usdt), now, now),
                )
                db.commit()
                return RiskReservationResult(True, "RISK_RESERVED", risk_usdt,
                                             active_reserved + risk_usdt, active_count + 1,
                                             active_symbol_notional + notional_usdt)
            except Exception:
                db.rollback()
                raise

    def release_risk_reservation(self, signal_id: str, reason: str) -> bool:
        """Release an active reservation after a confirmed terminal/no-position outcome."""
        if not signal_id or not signal_id.strip():
            raise ValueError("signal_id must be non-empty")
        if not reason or not reason.strip():
            raise ValueError("reason must be non-empty")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                cursor = db.execute(
                    "UPDATE risk_reservations SET status='RELEASED',release_reason=?,updated_at_utc=? "
                    "WHERE signal_id=? AND status='ACTIVE'",
                    (reason.strip(), _now(), signal_id),
                )
                db.commit()
                return cursor.rowcount == 1
            except Exception:
                db.rollback()
                raise

    def get_risk_reservation(self, signal_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute(
                "SELECT * FROM risk_reservations WHERE signal_id=?", (signal_id,)
            ).fetchone()
            return None if row is None else dict(row)

    def active_risk_reservations(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            rows = db.execute(
                "SELECT * FROM risk_reservations WHERE status='ACTIVE' ORDER BY created_at_utc"
            ).fetchall()
            return [dict(row) for row in rows]

    def active_reserved_risk_usdt(self) -> Decimal:
        rows = self.active_risk_reservations()
        return sum((Decimal(row["risk_usdt"]) for row in rows), Decimal("0"))

    def record_user_stream_event(self, payload: dict[str, Any], *, received_at_ms: int) -> tuple[str, bool]:
        """Persist a stream event once and update partial account/order projections atomically."""
        if not isinstance(payload, dict):
            raise TypeError("user stream payload must be a JSON object")
        event_type = str(payload.get("e", "")).strip()
        if not event_type:
            raise ValueError("user stream payload is missing event type 'e'")
        event_time = payload.get("E", payload.get("T", received_at_ms))
        transaction_time = payload.get("T", event_time)
        if isinstance(event_time, bool) or not isinstance(event_time, (int, float)):
            raise ValueError("user stream event time must be numeric")
        if isinstance(transaction_time, bool) or not isinstance(transaction_time, (int, float)):
            raise ValueError("user stream transaction time must be numeric")
        event_time = int(event_time)
        transaction_time = int(transaction_time)
        if event_time < 0 or transaction_time < 0 or received_at_ms <= 0:
            raise ValueError("user stream event timestamps must be non-negative and receive time positive")
        body = payload.get("o") or payload.get("or") or (payload if event_type == "TRADE_LITE" else {})
        account = payload.get("a") or {}
        symbol = str(body.get("s") or payload.get("s") or account.get("S") or "").upper()
        canonical = _json(payload)
        event_id = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                cursor = db.execute(
                    "INSERT OR IGNORE INTO user_stream_events "
                    "(event_id,event_type,event_time_ms,transaction_time_ms,symbol,payload_json,received_at_utc) "
                    "VALUES(?,?,?,?,?,?,?)",
                    (event_id, event_type, event_time, transaction_time, symbol, canonical, _now()),
                )
                inserted = cursor.rowcount == 1
                if not inserted:
                    db.commit()
                    return event_id, False
                if event_type == "ACCOUNT_UPDATE":
                    for row in account.get("B", []) or []:
                        asset = str(row.get("a", "")).upper()
                        if not asset:
                            continue
                        old = db.execute("SELECT event_time_ms FROM user_stream_balances WHERE asset=?", (asset,)).fetchone()
                        if old is None or event_time >= old["event_time_ms"]:
                            db.execute("""INSERT INTO user_stream_balances
                                (asset,wallet_balance,cross_wallet_balance,balance_change,event_time_ms,payload_json)
                                VALUES(?,?,?,?,?,?) ON CONFLICT(asset) DO UPDATE SET
                                wallet_balance=excluded.wallet_balance,
                                cross_wallet_balance=excluded.cross_wallet_balance,
                                balance_change=excluded.balance_change,event_time_ms=excluded.event_time_ms,
                                payload_json=excluded.payload_json""",
                                (asset, str(row.get("wb", "0")), str(row.get("cw", "0")),
                                 str(row.get("bc", "0")), event_time, _json(row)))
                    for row in account.get("P", []) or []:
                        pos_symbol = str(row.get("s", "")).upper()
                        side = str(row.get("ps", "BOTH")).upper()
                        if not pos_symbol:
                            continue
                        old = db.execute(
                            "SELECT event_time_ms FROM user_stream_positions WHERE symbol=? AND position_side=?",
                            (pos_symbol, side),
                        ).fetchone()
                        if old is None or event_time >= old["event_time_ms"]:
                            db.execute("""INSERT INTO user_stream_positions
                                (symbol,position_side,quantity,entry_price,break_even_price,unrealized_pnl,
                                 margin_type,isolated_wallet,event_time_ms,payload_json)
                                VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(symbol,position_side) DO UPDATE SET
                                quantity=excluded.quantity,entry_price=excluded.entry_price,
                                break_even_price=excluded.break_even_price,unrealized_pnl=excluded.unrealized_pnl,
                                margin_type=excluded.margin_type,isolated_wallet=excluded.isolated_wallet,
                                event_time_ms=excluded.event_time_ms,payload_json=excluded.payload_json""",
                                (pos_symbol, side, str(row.get("pa", "0")), str(row.get("ep", "0")),
                                 str(row.get("bep", row.get("ep", "0"))), str(row.get("up", "0")),
                                 str(row.get("mt", "")), str(row.get("iw", "0")), event_time, _json(row)))
                elif event_type in {"ORDER_TRADE_UPDATE", "ALGO_UPDATE"}:
                    order = body if isinstance(body, dict) else {}
                    order_symbol = str(order.get("s", symbol)).upper()
                    kind = "ALGO" if event_type == "ALGO_UPDATE" else "STANDARD"
                    exchange_id = order.get("aid", order.get("algoId")) if kind == "ALGO" else order.get("i", order.get("orderId"))
                    client_id = order.get("caid", order.get("clientAlgoId")) if kind == "ALGO" else order.get("c", order.get("clientOrderId"))
                    key_part = str(exchange_id if exchange_id is not None else client_id or event_id)
                    order_key = f"{kind}:{order_symbol}:{key_part}"
                    order_status = str(order.get("X", order.get("algoStatus", order.get("status", "UNKNOWN"))))
                    old = db.execute("SELECT event_time_ms FROM user_stream_orders WHERE order_key=?", (order_key,)).fetchone()
                    if old is None or event_time >= old["event_time_ms"]:
                        db.execute("""INSERT INTO user_stream_orders
                            (order_key,order_kind,symbol,status,event_time_ms,payload_json)
                            VALUES(?,?,?,?,?,?) ON CONFLICT(order_key) DO UPDATE SET
                            status=excluded.status,event_time_ms=excluded.event_time_ms,
                            payload_json=excluded.payload_json""",
                            (order_key, kind, order_symbol, order_status, event_time, _json(order)))
                if event_type in {"ORDER_TRADE_UPDATE", "TRADE_LITE"}:
                    self._record_stream_fill_db(
                        db, event_id=event_id, event_type=event_type,
                        event_time_ms=event_time, body=body if isinstance(body, dict) else {},
                        raw_payload=payload,
                    )
                # Exchange account/order changes invalidate the prior REST snapshot.
                # Keep this in the same transaction as event persistence so an
                # execution-readiness check cannot observe the event but stale READY.
                if event_type in {"ACCOUNT_UPDATE", "ORDER_TRADE_UPDATE", "ALGO_UPDATE", "TRADE_LITE"}:
                    db.execute(
                        "UPDATE reconciliation_state SET ready=0,"
                        "status='ACCOUNT_EVENT_PENDING_RECONCILIATION',detail_json='{}',updated_at_ms=? WHERE id=1",
                        (received_at_ms,),
                    )
                db.execute("""UPDATE user_stream_control SET last_event_at_ms=?,updated_at_ms=? WHERE id=1""",
                           (received_at_ms, received_at_ms))
                db.commit()
                return event_id, True
            except Exception:
                db.rollback()
                raise

    def list_trade_history_symbols(self) -> list[str]:
        """Symbols with local execution intent or previously observed fills."""
        with self._connection() as db:
            rows = db.execute(
                "SELECT symbol FROM trade_intents UNION SELECT symbol FROM position_fill_allocations ORDER BY symbol"
            ).fetchall()
            return [str(row["symbol"]).upper() for row in rows if str(row["symbol"] or "").strip()]

    def get_trade_backfill_watermark(self, symbol: str) -> dict[str, Any] | None:
        normalized = symbol.strip().upper()
        with self._connection() as db:
            row = db.execute("SELECT * FROM trade_backfill_watermarks WHERE symbol=?", (normalized,)).fetchone()
            return None if row is None else dict(row)

    def begin_trade_backfill_run(self, *, run_id: str, symbol: str,
                                 range_start_ms: int, range_end_ms: int) -> None:
        now = _now(); normalized = symbol.strip().upper()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("""INSERT INTO trade_backfill_runs
                    (run_id,symbol,range_start_ms,range_end_ms,status,started_at_utc,updated_at_utc)
                    VALUES(?,?,?,?,?,?,?) ON CONFLICT(run_id) DO UPDATE SET
                    status='RUNNING',last_error=NULL,updated_at_utc=excluded.updated_at_utc""",
                    (run_id, normalized, range_start_ms, range_end_ms, "RUNNING", now, now))
                db.commit()
            except Exception:
                db.rollback(); raise

    def record_rest_user_trades_page(self, *, run_id: str, symbol: str,
                                     trades: list[dict[str, Any]]) -> dict[str, int]:
        """Durably merge a REST page by (symbol, tradeId); replay is idempotent."""
        normalized = symbol.strip().upper(); inserted = 0; max_id = -1; max_time = 0
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                run = db.execute("SELECT * FROM trade_backfill_runs WHERE run_id=?", (run_id,)).fetchone()
                if run is None or str(run["symbol"]) != normalized or run["status"] != "RUNNING":
                    raise RuntimeError("TRADE_BACKFILL_RUN_NOT_ACTIVE")
                for trade in trades:
                    if str(trade.get("symbol", "")).upper() != normalized:
                        raise RuntimeError("REST_TRADE_SYMBOL_MISMATCH")
                    trade_id = trade.get("id")
                    event_time = trade.get("time")
                    if isinstance(trade_id, bool) or not isinstance(trade_id, int) or trade_id < 0:
                        raise RuntimeError("REST_TRADE_ID_INVALID")
                    if isinstance(event_time, bool) or not isinstance(event_time, int) or event_time <= 0:
                        raise RuntimeError("REST_TRADE_TIME_INVALID")
                    qty = Decimal(str(trade.get("qty", "0"))); price = Decimal(str(trade.get("price", "0")))
                    if not qty.is_finite() or qty <= 0 or not price.is_finite() or price <= 0:
                        raise RuntimeError("REST_TRADE_QUANTITY_OR_PRICE_INVALID")
                    body = {
                        "x": "TRADE", "c": "", "s": normalized, "t": trade_id,
                        "i": trade.get("orderId"), "ps": trade.get("positionSide", "BOTH"),
                        "l": str(qty), "L": str(price), "n": str(trade.get("commission", "0")),
                        "N": str(trade.get("commissionAsset", "")),
                        "rp": str(trade.get("realizedPnl", "0")),
                        "S": str(trade.get("side", "")), "m": trade.get("maker"),
                    }
                    fill_key = f"{normalized}:{trade_id}"
                    before = db.execute("SELECT 1 FROM position_fill_allocations WHERE fill_key=?", (fill_key,)).fetchone()
                    self._record_stream_fill_db(
                        db, event_id=f"REST:{fill_key}", event_type="ORDER_TRADE_UPDATE",
                        event_time_ms=event_time, body=body, raw_payload={"source": "REST_USER_TRADES", "trade": trade},
                        source="REST_USER_TRADES",
                    )
                    if before is None:
                        inserted += 1
                    max_id = max(max_id, trade_id); max_time = max(max_time, event_time)
                db.execute("""UPDATE trade_backfill_runs SET page_count=page_count+1,
                    trade_count=trade_count+?,max_trade_id=MAX(max_trade_id,?),
                    max_trade_time_ms=MAX(max_trade_time_ms,?),updated_at_utc=? WHERE run_id=?""",
                    (inserted, max_id, max_time, _now(), run_id))
                db.commit()
            except Exception:
                db.rollback(); raise
        self.apply_position_fill_allocations()
        return {"inserted": inserted, "max_trade_id": max_id, "max_trade_time_ms": max_time}

    def complete_trade_backfill_run(self, *, run_id: str) -> dict[str, Any]:
        now = _now()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                run = db.execute("SELECT * FROM trade_backfill_runs WHERE run_id=?", (run_id,)).fetchone()
                if run is None or run["status"] != "RUNNING":
                    raise RuntimeError("TRADE_BACKFILL_RUN_NOT_ACTIVE")
                previous = db.execute("SELECT * FROM trade_backfill_watermarks WHERE symbol=?", (run["symbol"],)).fetchone()
                new_id = max(int(run["max_trade_id"]), int(previous["last_trade_id"]) if previous else -1)
                new_time = max(int(run["max_trade_time_ms"]), int(previous["last_trade_time_ms"]) if previous else 0)
                through = max(int(run["range_end_ms"]), int(previous["completed_through_ms"]) if previous else 0)
                db.execute("""INSERT INTO trade_backfill_watermarks
                    (symbol,last_trade_id,last_trade_time_ms,completed_through_ms,updated_at_utc)
                    VALUES(?,?,?,?,?) ON CONFLICT(symbol) DO UPDATE SET
                    last_trade_id=excluded.last_trade_id,last_trade_time_ms=excluded.last_trade_time_ms,
                    completed_through_ms=excluded.completed_through_ms,updated_at_utc=excluded.updated_at_utc""",
                    (run["symbol"], new_id, new_time, through, now))
                db.execute("UPDATE trade_backfill_runs SET status='COMPLETE',updated_at_utc=? WHERE run_id=?", (now, run_id))
                db.commit()
                return dict(db.execute("SELECT * FROM trade_backfill_watermarks WHERE symbol=?", (run["symbol"],)).fetchone())
            except Exception:
                db.rollback(); raise

    def fail_trade_backfill_run(self, *, run_id: str, error: str) -> None:
        with self._connection() as db:
            db.execute("UPDATE trade_backfill_runs SET status='FAILED',last_error=?,updated_at_utc=? WHERE run_id=? AND status='RUNNING'",
                       (str(error)[:500], _now(), run_id))

    def _record_stream_fill_db(
        self, db: sqlite3.Connection, *, event_id: str, event_type: str,
        event_time_ms: int, body: dict[str, Any], raw_payload: dict[str, Any],
        source: str = "USER_STREAM",
    ) -> None:
        execution_type = str(body.get("x", "TRADE" if event_type == "TRADE_LITE" else "")).upper()
        if execution_type not in {"TRADE", "TRADE_LITE"}:
            return
        client_id = str(body.get("c", body.get("clientOrderId", "")) or "")
        symbol = str(body.get("s", "") or "").upper()
        trade_id_raw = body.get("t", body.get("tradeId"))
        exchange_order_id_raw = body.get("i", body.get("orderId"))
        exchange_order_id = "" if exchange_order_id_raw in (None, "") else str(exchange_order_id_raw)
        if (not symbol or trade_id_raw in (None, "", 0, "0")
                or (not client_id and not exchange_order_id)):
            return
        try:
            quantity = Decimal(str(body.get("l", body.get("lastFilledQty", "0"))))
            price = Decimal(str(body.get("L", body.get("lastFilledPrice", "0"))))
        except Exception:
            return
        if not quantity.is_finite() or quantity <= 0 or not price.is_finite() or price <= 0:
            return
        trade_id = str(trade_id_raw)
        fill_key = f"{symbol}:{trade_id}"
        link = db.execute(
            "SELECT signal_id,position_side,role,effect,symbol FROM execution_client_order_links WHERE client_order_id=?",
            (client_id,),
        ).fetchone() if client_id else None
        if link is None and exchange_order_id:
            link = db.execute(
                "SELECT signal_id,position_side,role,effect,symbol FROM execution_exchange_order_links "
                "WHERE symbol=? AND exchange_order_id=?",
                (symbol, exchange_order_id),
            ).fetchone()
        order_side_raw = body.get("ps", body.get("positionSide"))
        order_side = str(order_side_raw or "BOTH").upper()
        if link is not None:
            if str(link["symbol"]).upper() != symbol:
                # Preserve the evidence as unallocated rather than attributing a
                # malformed or cross-symbol order update to the wrong signal.
                signal_id = None
                role, effect, status = "UNKNOWN", "UNKNOWN", "UNATTRIBUTED"
            else:
                signal_id = str(link["signal_id"])
                role, effect, status = str(link["role"]), str(link["effect"]), "ATTRIBUTED"
                order_side = str(link["position_side"]) if order_side_raw in (None, "") else order_side
        else:
            signal_id = None
            role, effect = "UNKNOWN", "UNKNOWN"
            status = "UNATTRIBUTED" if client_id.upper().startswith(("DIVA", "DIVASL", "DIVATP")) else "EXTERNAL"
        commission_raw = body.get("n", body.get("commission", "0"))
        realized_raw = body.get("rp", body.get("realizedPnl", "0"))
        try:
            commission = Decimal(str(commission_raw or "0"))
            realized_pnl = Decimal(str(realized_raw or "0"))
        except Exception:
            commission = Decimal("0")
            realized_pnl = Decimal("0")
        if not commission.is_finite() or not realized_pnl.is_finite():
            raise ValueError("non-finite commission or realized PnL in trade fill")
        commission_asset = str(body.get("N", body.get("commissionAsset", "")) or "").upper()
        order_side_value = str(body.get("S", body.get("side", "")) or "").upper()
        maker_raw = body.get("m", body.get("isMaker"))
        is_maker = None if maker_raw is None else (1 if maker_raw is True or str(maker_raw).lower() == "true" else 0)
        existing_fill = db.execute(
            "SELECT client_order_id,signal_id,quantity,price,exchange_order_id,order_side,position_side "
            "FROM position_fill_allocations WHERE fill_key=?",
            (fill_key,),
        ).fetchone()
        if existing_fill is not None:
            if Decimal(str(existing_fill["quantity"])) != quantity or Decimal(str(existing_fill["price"])) != price:
                raise RuntimeError(f"EXCHANGE_TRADE_ID_CONTRADICTORY_QUANTITY_OR_PRICE:{fill_key}")
            old_exchange_order_id = str(existing_fill["exchange_order_id"] or "")
            if old_exchange_order_id and exchange_order_id and old_exchange_order_id != exchange_order_id:
                raise RuntimeError(f"EXCHANGE_TRADE_ID_ORDER_CONFLICT:{fill_key}")
            old_order_side = str(existing_fill["order_side"] or "").upper()
            if old_order_side and order_side_value and old_order_side != order_side_value:
                raise RuntimeError(f"EXCHANGE_TRADE_ID_SIDE_CONFLICT:{fill_key}")
            old_position_side = str(existing_fill["position_side"] or "").upper()
            if old_position_side not in {"", "BOTH"} and order_side not in {"", "BOTH", old_position_side}:
                raise RuntimeError(f"EXCHANGE_TRADE_ID_POSITION_SIDE_CONFLICT:{fill_key}")
            # TRADE_LITE may arrive before ORDER_TRADE_UPDATE. Keep its low-latency
            # evidence, then enrich the same exchange trade ID when commission and
            # realized-PnL fields become available on the full event.
            old_client = str(existing_fill["client_order_id"] or "")
            old_signal = existing_fill["signal_id"]
            if old_client and client_id and old_client != client_id and old_signal and signal_id and old_signal != signal_id:
                raise RuntimeError(f"EXCHANGE_TRADE_ID_OWNERSHIP_CONFLICT:{fill_key}")
            db.execute("""UPDATE position_fill_allocations SET
                commission=CASE WHEN ?<>'0' OR commission_asset='' THEN ? ELSE commission END,
                commission_asset=CASE WHEN ?<>'' THEN ? ELSE commission_asset END,
                realized_pnl=CASE WHEN ?<>'0' THEN ? ELSE realized_pnl END,
                exchange_order_id=CASE WHEN ?<>'' THEN ? ELSE exchange_order_id END,
                order_side=CASE WHEN ?<>'' THEN ? ELSE order_side END,
                is_maker=COALESCE(?,is_maker),
                source=CASE WHEN source<>? THEN 'REST+USER_STREAM' ELSE source END,
                payload_json=?
                WHERE fill_key=?""",
                (str(commission), str(commission), commission_asset, commission_asset,
                 str(realized_pnl), str(realized_pnl), exchange_order_id, exchange_order_id,
                 order_side_value, order_side_value, is_maker, source, _json(raw_payload), fill_key))
            # If the later full event identifies an order that was not mapped when
            # TRADE_LITE arrived, backfill ownership before the fill applier runs.
            if status == "ATTRIBUTED" and old_signal in (None, signal_id):
                db.execute("""UPDATE position_fill_allocations SET signal_id=?,position_side=?,
                    order_role=?,effect=?,allocation_status='ATTRIBUTED',
                    client_order_id=CASE WHEN ?<>'' THEN ? ELSE client_order_id END
                    WHERE fill_key=?""",
                    (signal_id, order_side, role, effect, client_id, client_id, fill_key))
            return
        db.execute("""INSERT INTO position_fill_allocations
            (fill_key,event_id,client_order_id,signal_id,symbol,position_side,order_role,effect,
             quantity,price,trade_id,event_time_ms,allocation_status,payload_json,created_at_utc,
             exchange_order_id,order_side,commission,commission_asset,realized_pnl,is_maker,source)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (fill_key, event_id, client_id, signal_id, symbol, order_side, role, effect,
             str(quantity), str(price), trade_id, event_time_ms, status, _json(raw_payload), _now(),
             exchange_order_id, order_side_value, str(commission), commission_asset,
             str(realized_pnl), is_maker, source))
        if status == "UNATTRIBUTED":
            db.execute("""UPDATE execution_control SET entries_halted=1,
                halt_reason=?,updated_at_utc=? WHERE id=1""",
                (f"UNATTRIBUTED_DIVATRADING_FILL:{client_id}"[:500], _now()))

    def list_position_fill_allocations(
        self, *, signal_id: str | None = None, allocation_status: str | None = None,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM position_fill_allocations"
        clauses: list[str] = []
        params: list[Any] = []
        if signal_id is not None:
            clauses.append("signal_id=?")
            params.append(signal_id)
        if allocation_status is not None:
            clauses.append("allocation_status=?")
            params.append(allocation_status.upper())
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY event_time_ms,fill_key"
        with self._connection() as db:
            return [dict(row) for row in db.execute(query, params).fetchall()]

    def position_fill_allocation_counts(self) -> dict[str, int]:
        with self._connection() as db:
            rows = db.execute(
                "SELECT allocation_status,COUNT(*) AS count FROM position_fill_allocations GROUP BY allocation_status"
            ).fetchall()
        counts = {"ATTRIBUTED": 0, "UNATTRIBUTED": 0, "EXTERNAL": 0}
        counts.update({str(row["allocation_status"]): int(row["count"]) for row in rows})
        return counts

    @staticmethod
    def _fill_decimal(value: Any, field: str, *, allow_zero: bool = False) -> Decimal:
        try:
            result = Decimal(str(value))
        except Exception as exc:
            raise ValueError(f"Invalid fill projection field: {field}") from exc
        if not result.is_finite() or result < 0 or (result == 0 and not allow_zero):
            raise ValueError(f"Invalid fill projection field: {field}")
        return result

    def apply_position_fill_allocations(self, *, signal_id: str | None = None) -> list[dict[str, Any]]:
        """Atomically apply attributed trade evidence to per-signal accounting projections.

        This deliberately does not mutate the exchange-backed managed-position quantity.
        It builds a separate immutable-fill projection, so reconciliation can compare
        executed trade evidence with the REST position without double-applying fills that
        the lifecycle adapter has already reflected locally.
        """
        results: list[dict[str, Any]] = []
        try:
            with self._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                try:
                    if signal_id is None:
                        rows = db.execute(
                            "SELECT DISTINCT signal_id FROM position_fill_allocations "
                            "WHERE allocation_status='ATTRIBUTED' AND signal_id IS NOT NULL ORDER BY signal_id"
                        ).fetchall()
                        signal_ids = [str(row["signal_id"]) for row in rows]
                    else:
                        signal_ids = [str(signal_id)]
                    for current_signal_id in signal_ids:
                        fills = db.execute(
                            "SELECT * FROM position_fill_allocations WHERE signal_id=? "
                            "AND allocation_status='ATTRIBUTED' ORDER BY event_time_ms,CAST(trade_id AS INTEGER),fill_key",
                            (current_signal_id,),
                        ).fetchall()
                        if not fills:
                            continue
                        intent = db.execute(
                            "SELECT symbol,side FROM trade_intents WHERE signal_id=?",
                            (current_signal_id,),
                        ).fetchone()
                        if intent is None:
                            raise RuntimeError(f"FILL_OWNER_INTENT_MISSING:{current_signal_id}")

                        entry_qty = Decimal("0")
                        entry_notional = Decimal("0")
                        close_qty = Decimal("0")
                        commissions: dict[str, Decimal] = {}
                        realized: dict[str, Decimal] = {}
                        for fill in fills:
                            effect = str(fill["effect"]).upper()
                            if effect not in {"OPEN", "CLOSE"}:
                                raise RuntimeError(
                                    f"FILL_EFFECT_UNKNOWN:{current_signal_id}:{fill['fill_key']}"
                                )
                            quantity = self._fill_decimal(fill["quantity"], "quantity")
                            price = self._fill_decimal(fill["price"], "price")
                            commission = Decimal(str(fill["commission"]))
                            realized_pnl = Decimal(str(fill["realized_pnl"]))
                            if not commission.is_finite():
                                raise RuntimeError(f"FILL_COMMISSION_INVALID:{fill['fill_key']}")
                            if not realized_pnl.is_finite():
                                raise RuntimeError(f"FILL_REALIZED_PNL_INVALID:{fill['fill_key']}")
                            if effect == "OPEN":
                                entry_qty += quantity
                                entry_notional += quantity * price
                            else:
                                close_qty += quantity
                                if close_qty > entry_qty:
                                    raise RuntimeError(
                                        f"FILL_CLOSE_EXCEEDS_OPEN:{current_signal_id}:{fill['fill_key']}"
                                    )
                            asset = str(fill["commission_asset"] or "UNKNOWN").upper()
                            commissions[asset] = commissions.get(asset, Decimal("0")) + commission
                            # DIVATrading currently trades USDT-margined perpetuals;
                            # commission asset can differ (e.g. BNB fee discount), but
                            # realized PnL is denominated in the contract quote asset.
                            realized["USDT"] = realized.get("USDT", Decimal("0")) + realized_pnl
                            db.execute(
                                """INSERT INTO position_fill_applications
                                (fill_key,signal_id,effect,quantity,price,commission,commission_asset,
                                 realized_pnl,applied_at_utc)
                                VALUES(?,?,?,?,?,?,?,?,?)
                                ON CONFLICT(fill_key) DO UPDATE SET
                                    signal_id=excluded.signal_id,effect=excluded.effect,
                                    quantity=excluded.quantity,price=excluded.price,
                                    commission=excluded.commission,commission_asset=excluded.commission_asset,
                                    realized_pnl=excluded.realized_pnl,applied_at_utc=excluded.applied_at_utc""",
                                (fill["fill_key"], current_signal_id, effect, str(quantity), str(price),
                                 str(commission), asset, str(realized_pnl), _now()),
                            )

                        net_qty = entry_qty - close_qty
                        weighted_entry = entry_notional / entry_qty if entry_qty else Decimal("0")
                        first = fills[0]
                        projection = {
                            "signal_id": current_signal_id,
                            "symbol": str(intent["symbol"]).upper(),
                            "position_side": str(first["position_side"]).upper(),
                            "entry_quantity": str(entry_qty),
                            "entry_notional": str(entry_notional),
                            "close_quantity": str(close_qty),
                            "net_quantity": str(net_qty),
                            "weighted_entry_price": str(weighted_entry),
                            "commissions": {key: str(value) for key, value in sorted(commissions.items())},
                            "realized_pnl": {key: str(value) for key, value in sorted(realized.items())},
                            "fill_count": len(fills),
                        }
                        db.execute(
                            """INSERT INTO position_fill_projections
                            (signal_id,symbol,position_side,entry_quantity,entry_notional,close_quantity,
                             net_quantity,weighted_entry_price,commissions_json,realized_pnl_json,
                             fill_count,updated_at_utc)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                            ON CONFLICT(signal_id) DO UPDATE SET
                                symbol=excluded.symbol,position_side=excluded.position_side,
                                entry_quantity=excluded.entry_quantity,entry_notional=excluded.entry_notional,
                                close_quantity=excluded.close_quantity,net_quantity=excluded.net_quantity,
                                weighted_entry_price=excluded.weighted_entry_price,
                                commissions_json=excluded.commissions_json,
                                realized_pnl_json=excluded.realized_pnl_json,
                                fill_count=excluded.fill_count,updated_at_utc=excluded.updated_at_utc""",
                            (current_signal_id, projection["symbol"], projection["position_side"],
                             projection["entry_quantity"], projection["entry_notional"],
                             projection["close_quantity"], projection["net_quantity"],
                             projection["weighted_entry_price"], _json(projection["commissions"]),
                             _json(projection["realized_pnl"]), len(fills), _now()),
                        )
                        results.append(projection)
                    db.commit()
                except Exception:
                    db.rollback()
                    raise
        except Exception as exc:
            self.set_entries_halted(True, f"POSITION_FILL_APPLIER_FAILED:{type(exc).__name__}:{exc}"[:500])
            self.record_event("POSITION_FILL_APPLIER_FAILED", signal_id=signal_id,
                              detail={"error": f"{type(exc).__name__}: {exc}"[:500]})
            raise
        return results

    def get_position_fill_projection(self, signal_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute(
                "SELECT * FROM position_fill_projections WHERE signal_id=?", (signal_id,)
            ).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["commissions"] = json.loads(result.pop("commissions_json"))
        result["realized_pnl"] = json.loads(result.pop("realized_pnl_json"))
        return result

    def list_position_fill_projections(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            ids = [str(row["signal_id"]) for row in db.execute(
                "SELECT signal_id FROM position_fill_projections ORDER BY symbol,signal_id"
            ).fetchall()]
        return [projection for item in ids
                if (projection := self.get_position_fill_projection(item)) is not None]

    def set_user_stream_state(self, status: str, *, listen_key_fingerprint: str | None = None,
                              connected_at_ms: int | None = None, last_error: str | None = None,
                              updated_at_ms: int) -> None:
        allowed = {"DISCONNECTED", "CONNECTING", "CONNECTED", "STALE", "EXPIRED", "STOPPED"}
        if status not in allowed:
            raise ValueError(f"Unsupported user stream state: {status}")
        with self._connection() as db:
            db.execute("""UPDATE user_stream_control SET status=?,
                listen_key_fingerprint=COALESCE(?,listen_key_fingerprint),
                connected_at_ms=CASE WHEN ? IS NOT NULL THEN ? ELSE connected_at_ms END,
                updated_at_ms=?,last_error=? WHERE id=1""",
                (status, listen_key_fingerprint, connected_at_ms, connected_at_ms,
                 updated_at_ms, last_error))
            db.execute("UPDATE reconciliation_state SET ready=0,status='STREAM_STATE_CHANGED',"
                       "detail_json='{}',updated_at_ms=? WHERE id=1", (updated_at_ms,))

    def get_user_stream_state(self) -> dict[str, Any]:
        with self._connection() as db:
            row = db.execute("SELECT * FROM user_stream_control WHERE id=1").fetchone()
            return {} if row is None else dict(row)

    def user_stream_balances(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            return [dict(row) for row in db.execute("SELECT * FROM user_stream_balances ORDER BY asset").fetchall()]

    def user_stream_positions(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            return [dict(row) for row in db.execute(
                "SELECT * FROM user_stream_positions ORDER BY symbol,position_side").fetchall()]

    def user_stream_orders(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            return [dict(row) for row in db.execute(
                "SELECT * FROM user_stream_orders ORDER BY symbol,order_key").fetchall()]

    def set_reconciliation_state(self, ready: bool, *, status: str, captured_at_ms: int,
                                 detail: dict[str, Any] | None = None,
                                 stream_event_watermark_ms: int | None = None) -> None:
        if not status or captured_at_ms <= 0:
            raise ValueError("status and positive captured_at_ms are required")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                current = db.execute(
                    "SELECT status,last_event_at_ms FROM user_stream_control WHERE id=1"
                ).fetchone()
                current_watermark = int(current["last_event_at_ms"] or 0) if current else 0
                effective_ready = bool(ready)
                effective_status = status
                effective_detail = dict(detail or {})
                if effective_ready and (current is None or current["status"] != "CONNECTED"):
                    effective_ready = False
                    effective_status = "USER_STREAM_NOT_CONNECTED_AT_COMMIT"
                    effective_detail["stream_status_at_commit"] = current["status"] if current else "MISSING"
                if stream_event_watermark_ms is not None:
                    effective_detail["stream_event_watermark_ms"] = stream_event_watermark_ms
                    if effective_ready and current_watermark != stream_event_watermark_ms:
                        effective_ready = False
                        effective_status = "EVENT_DURING_RECONCILIATION"
                        effective_detail["current_stream_event_watermark_ms"] = current_watermark
                db.execute("""UPDATE reconciliation_state SET ready=?,status=?,captured_at_ms=?,
                    detail_json=?,updated_at_ms=? WHERE id=1""",
                    (1 if effective_ready else 0, effective_status, captured_at_ms,
                     _json(effective_detail), captured_at_ms))
                db.commit()
            except Exception:
                db.rollback()
                raise

    def get_reconciliation_state(self) -> dict[str, Any]:
        with self._connection() as db:
            row = db.execute("SELECT * FROM reconciliation_state WHERE id=1").fetchone()
            return {} if row is None else dict(row)

    def execution_readiness(self, *, now_ms: int, max_reconciliation_age_ms: int = 30_000) -> tuple[bool, tuple[str, ...]]:
        """Readiness gate for non-PAPER entries; does not clear the manual kill switch."""
        reasons: list[str] = []
        # Read all readiness inputs from one SQLite snapshot to avoid mixing an old
        # stream watermark with a newer reconciliation state (or vice versa).
        with self._connection() as db:
            db.execute("BEGIN")
            control = db.execute("SELECT entries_halted,halt_reason FROM execution_control WHERE id=1").fetchone()
            stream = db.execute("SELECT * FROM user_stream_control WHERE id=1").fetchone()
            reconcile = db.execute("SELECT * FROM reconciliation_state WHERE id=1").fetchone()
            if control and control["entries_halted"]:
                reasons.append(f"ENTRIES_HALTED:{control['halt_reason'] or 'MANUAL_OR_SAFETY_HALT'}")
            stream_status = stream["status"] if stream else "UNKNOWN"
            if stream_status != "CONNECTED":
                reasons.append(f"USER_STREAM_{stream_status}")
            if not reconcile or not reconcile["ready"]:
                reconcile_status = reconcile["status"] if reconcile else "NOT_RECONCILED"
                reasons.append(f"ACCOUNT_{reconcile_status}")
            captured = reconcile["captured_at_ms"] if reconcile else None
            if not isinstance(captured, int) or now_ms - captured > max_reconciliation_age_ms or captured > now_ms:
                reasons.append("ACCOUNT_RECONCILIATION_STALE")
            if stream and reconcile and reconcile["ready"]:
                try:
                    detail = json.loads(reconcile["detail_json"] or "{}")
                except (TypeError, ValueError):
                    detail = {}
                watermark = detail.get("stream_event_watermark_ms")
                last_event = int(stream["last_event_at_ms"] or 0)
                if not isinstance(watermark, int) or watermark != last_event:
                    reasons.append("ACCOUNT_EVENT_NOT_RECONCILED")
            db.commit()
        return not reasons, tuple(reasons)

    def list_managed_positions(self, *, status: str | None = "OPEN") -> list[dict[str, Any]]:
        """List managed positions; pass status=None to include closed records for recovery."""
        query = "SELECT m.*,t.side AS signal_side FROM managed_positions m JOIN trade_intents t ON t.signal_id=m.signal_id"
        params: tuple[Any, ...] = ()
        if status is not None:
            query += " WHERE m.status=?"
            params = (status,)
        query += " ORDER BY m.symbol,m.position_side,m.signal_id"
        with self._connection() as db:
            rows = db.execute(query, params).fetchall()
            return [dict(row) for row in rows]

    def list_managed_position_groups(self) -> list[dict[str, Any]]:
        """Read-only aggregate view; does not imply multi-signal execution is enabled."""
        groups = build_position_groups(self.list_managed_positions(status="OPEN"))
        return [group.as_dict() for group in groups]

    def list_all_intents(self) -> list[dict[str, Any]]:
        with self._connection() as db:
            rows = db.execute("SELECT * FROM trade_intents ORDER BY created_at_utc").fetchall()
            return [dict(row) for row in rows]

    def update_managed_position_status(self, *, symbol: str, position_side: str,
                                       signal_id: str, status: str) -> bool:
        with self._connection() as db:
            cursor = db.execute("""UPDATE managed_positions SET status=?,updated_at_utc=?
                WHERE symbol=? AND position_side=? AND signal_id=?""",
                (status, _now(), symbol, position_side, signal_id))
            return cursor.rowcount == 1

    def save_position_management_state(self, *, signal_id: str, symbol: str,
                                       state: dict[str, Any], expected_version: int | None = None) -> int:
        """Persist lifecycle state with optional compare-and-swap version control."""
        now = _now()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                row = db.execute("SELECT version FROM position_management_state WHERE signal_id=?",
                                 (signal_id,)).fetchone()
                if row is None:
                    if expected_version not in (None, 0):
                        raise RuntimeError("POSITION_STATE_VERSION_CONFLICT")
                    db.execute("INSERT INTO position_management_state(signal_id,symbol,state_json,version,updated_at_utc) VALUES(?,?,?,?,?)",
                               (signal_id, symbol, _json(state), 1, now))
                    version = 1
                else:
                    current = int(row["version"])
                    if expected_version is not None and expected_version != current:
                        raise RuntimeError("POSITION_STATE_VERSION_CONFLICT")
                    version = current + 1
                    db.execute("UPDATE position_management_state SET symbol=?,state_json=?,version=?,updated_at_utc=? WHERE signal_id=?",
                               (symbol, _json(state), version, now, signal_id))
                db.commit()
                return version
            except Exception:
                db.rollback()
                raise

    def apply_protective_trigger_residual(
        self, *, action_id: str, signal_id: str, symbol: str, position_side: str,
        original_quantity: str, residual_quantity: str,
    ) -> dict[str, Any]:
        """Atomically align lifecycle state and managed quantity to a REST-confirmed residual.

        A protective trigger is an exchange-side close, not a new local trade. This
        transaction makes the per-signal residual durable in both local projections
        before replacement protection is submitted. Replays accept only the original
        or already-applied quantity, never an arbitrary intermediate value.
        """
        original = Decimal(str(original_quantity))
        residual = Decimal(str(residual_quantity))
        if (not original.is_finite() or not residual.is_finite()
                or original <= 0 or residual < 0 or residual >= original):
            raise ValueError("PROTECTIVE_TRIGGER_RESIDUAL_INVALID")
        normalized_symbol = symbol.upper()
        normalized_side = position_side.upper()
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                action = db.execute(
                    "SELECT signal_id,action_kind,status FROM position_management_actions WHERE action_id=?",
                    (action_id,),
                ).fetchone()
                if (action is None or action["signal_id"] != signal_id
                        or action["action_kind"] != "PROTECTIVE_TRIGGER_RECONCILIATION"):
                    raise RuntimeError("PROTECTIVE_TRIGGER_ACTION_IDENTITY_MISMATCH")
                state_row = db.execute(
                    "SELECT state_json,version,symbol FROM position_management_state WHERE signal_id=?",
                    (signal_id,),
                ).fetchone()
                managed = db.execute(
                    "SELECT quantity,status FROM managed_positions WHERE signal_id=? AND symbol=? AND position_side=?",
                    (signal_id, normalized_symbol, normalized_side),
                ).fetchone()
                if state_row is None or managed is None:
                    raise RuntimeError("PROTECTIVE_TRIGGER_MANAGED_POSITION_MISSING")
                if str(state_row["symbol"]).upper() != normalized_symbol:
                    raise RuntimeError("PROTECTIVE_TRIGGER_POSITION_IDENTITY_OR_STATUS_MISMATCH")
                state = json.loads(state_row["state_json"] or "{}")
                state_qty = Decimal(str(state.get("quantity", "NaN")))
                managed_qty = Decimal(str(managed["quantity"]))
                allowed = (original, residual)
                already_applied_closed = (
                    residual == 0 and managed["status"] == "CLOSED"
                    and state.get("closed") is True
                    and state_qty.is_finite() and managed_qty.is_finite()
                    and abs(state_qty) <= Decimal("1e-10")
                    and abs(managed_qty) <= Decimal("1e-10")
                    and state.get("last_protective_trigger_action_id") == action_id
                )
                if (not already_applied_closed and managed["status"] != "OPEN"):
                    raise RuntimeError("PROTECTIVE_TRIGGER_POSITION_IDENTITY_OR_STATUS_MISMATCH")
                if (not state_qty.is_finite() or not managed_qty.is_finite()
                        or (not already_applied_closed and (
                            all(abs(state_qty - value) > Decimal("1e-10") for value in allowed)
                            or all(abs(managed_qty - value) > Decimal("1e-10") for value in allowed)
                        ))):
                    raise RuntimeError("PROTECTIVE_TRIGGER_LOCAL_QUANTITY_CONFLICT")
                if already_applied_closed:
                    db.commit()
                    return {"state": state, "version": int(state_row["version"]), "quantity": "0",
                            "previous_state_quantity": "0", "previous_managed_quantity": "0",
                            "duplicate": True}
                state["quantity"] = str(residual)
                if residual == 0:
                    state["closed"] = True
                state["last_protective_trigger_action_id"] = action_id
                next_version = int(state_row["version"]) + 1
                db.execute(
                    "UPDATE position_management_state SET state_json=?,version=?,updated_at_utc=? WHERE signal_id=?",
                    (_json(state), next_version, _now(), signal_id),
                )
                db.execute(
                    "UPDATE managed_positions SET quantity=?,status=?,updated_at_utc=? "
                    "WHERE signal_id=? AND symbol=? AND position_side=?",
                    (str(residual), "CLOSED" if residual == 0 else "OPEN", _now(),
                     signal_id, normalized_symbol, normalized_side),
                )
                db.commit()
                return {"state": state, "version": next_version, "quantity": str(residual),
                        "previous_state_quantity": str(state_qty),
                        "previous_managed_quantity": str(managed_qty)}
            except Exception:
                db.rollback()
                raise

    def get_position_management_state(self, signal_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute("SELECT * FROM position_management_state WHERE signal_id=?", (signal_id,)).fetchone()
            if row is None:
                return None
            result = dict(row)
            result["state"] = json.loads(result.pop("state_json"))
            return result

    def claim_position_management_action(self, *, action_id: str, signal_id: str,
                                         action_kind: str, payload: dict[str, Any]) -> bool:
        """Claim one in-flight action per signal and aggregate position side.

        Multiple lots may share an exchange (symbol, positionSide), so concurrent
        closes/protection replacement across sibling signals must be serialized.
        The transaction-level group lock prevents two processes from reducing the
        same exchange quantity on stale snapshots.
        """
        now = _now()
        pending_statuses = (
            "PLANNED", "SUBMITTING", "SUBMITTED", "SUBMISSION_UNKNOWN",
            "PARTIALLY_FILLED", "REPLACEMENT_ACTIVE_OLD_CANCEL_PENDING",
            "STOP_TRIGGERED_PENDING_RECONCILIATION", "STOP_TRIGGERED_POSITION_NOT_FLAT",
            "STOP_REPLACEMENT_POSITION_MISMATCH", "EXIT_PENDING",
            "PROTECTIVE_TRIGGER_RECONCILIATION_PENDING", "LOT_FINALIZATION_PENDING",
        )
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                placeholders = ",".join("?" for _ in pending_statuses)
                pending_rows = db.execute(
                    f"SELECT action_id FROM position_management_actions "
                    f"WHERE signal_id=? AND status IN ({placeholders})",
                    (signal_id, *pending_statuses),
                ).fetchall()
                parent_action_id = str(payload.get("parent_action_id", ""))
                conflicting = [
                    row["action_id"] for row in pending_rows
                    if row["action_id"] not in {action_id, parent_action_id}
                ]
                if conflicting:
                    db.commit()
                    return False
                target_group = db.execute(
                    "SELECT symbol,position_side FROM managed_positions "
                    "WHERE signal_id=? AND status='OPEN' LIMIT 1",
                    (signal_id,),
                ).fetchone()
                if target_group is not None:
                    group_pending = db.execute(
                        f"SELECT a.action_id,a.signal_id FROM position_management_actions a "
                        "JOIN managed_positions m ON m.signal_id=a.signal_id "
                        "WHERE m.symbol=? AND m.position_side=? AND m.status='OPEN' "
                        f"AND a.status IN ({placeholders})",
                        (target_group["symbol"], target_group["position_side"], *pending_statuses),
                    ).fetchall()
                    group_conflicts = [
                        row["action_id"] for row in group_pending
                        if row["action_id"] not in {action_id, parent_action_id}
                    ]
                    if group_conflicts:
                        db.commit()
                        return False
                cursor = db.execute("INSERT OR IGNORE INTO position_management_actions"
                    "(action_id,signal_id,action_kind,status,payload_json,created_at_utc,updated_at_utc)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (action_id, signal_id, action_kind, "PLANNED", _json(payload), now, now))
                client_order_id = str(payload.get("client_order_id", ""))
                if cursor.rowcount == 1 and client_order_id:
                    intent = db.execute("SELECT symbol,side FROM trade_intents WHERE signal_id=?", (signal_id,)).fetchone()
                    symbol = str(payload.get("symbol") or (intent["symbol"] if intent else "")).upper()
                    side = str(payload.get("position_side") or (intent["side"] if intent else "BOTH")).upper()
                    self._register_client_order_link(
                        db, client_order_id=client_order_id, signal_id=signal_id,
                        symbol=symbol, position_side=side, role=action_kind,
                        effect=self._fill_effect(action_kind) if self._fill_effect(action_kind) != "UNKNOWN" else "CLOSE",
                    )
                db.commit()
                return cursor.rowcount == 1
            except Exception:
                db.rollback()
                raise

    def update_position_management_action(self, *, action_id: str, status: str,
                                           payload_update: dict[str, Any] | None = None) -> bool:
        """Update an action state and merge durable exchange identifiers/results."""
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                row = db.execute("SELECT payload_json FROM position_management_actions WHERE action_id=?",
                                 (action_id,)).fetchone()
                if row is None:
                    db.rollback()
                    return False
                payload = json.loads(row["payload_json"] or "{}")
                if payload_update:
                    payload.update(payload_update)
                cursor = db.execute(
                    "UPDATE position_management_actions SET status=?,payload_json=?,updated_at_utc=? WHERE action_id=?",
                    (status, _json(payload), _now(), action_id),
                )
                db.commit()
                return cursor.rowcount == 1
            except Exception:
                db.rollback()
                raise

    def get_position_management_action(self, action_id: str) -> dict[str, Any] | None:
        with self._connection() as db:
            row = db.execute("SELECT * FROM position_management_actions WHERE action_id=?", (action_id,)).fetchone()
            if row is None:
                return None
            result = dict(row)
            result["payload"] = json.loads(result.pop("payload_json"))
            return result

    def list_position_management_actions(self, signal_id: str | None = None,
                                         statuses: tuple[str, ...] | None = None) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if signal_id is not None:
            clauses.append("signal_id=?")
            params.append(signal_id)
        if statuses:
            clauses.append("status IN (" + ",".join("?" for _ in statuses) + ")")
            params.extend(statuses)
        query = "SELECT * FROM position_management_actions"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY created_at_utc,action_id"
        with self._connection() as db:
            rows = db.execute(query, params).fetchall()
            results = []
            for row in rows:
                item = dict(row)
                item["payload"] = json.loads(item.pop("payload_json"))
                results.append(item)
            return results

    def find_position_management_action_by_client_id(self, client_id: str) -> dict[str, Any] | None:
        if not client_id:
            return None
        for action in self.list_position_management_actions():
            payload = action.get("payload", {})
            linked_ids = {
                payload.get("client_order_id"), payload.get("client_algo_id"),
                payload.get("algo_client_id"), payload.get("old_client_algo_id"),
                payload.get("new_stop_client_algo_id"), payload.get("new_take_client_algo_id"),
                payload.get("source_client_algo_id"), payload.get("replacement_client_algo_id"),
            }
            if client_id in linked_ids:
                return action
        return None

    def update_managed_position(self, *, signal_id: str, symbol: str,
                                position_side: str, quantity: str | None = None,
                                stop_loss: str | None = None, status: str | None = None) -> bool:
        """Update only supplied managed-position fields; used after exchange confirmation."""
        assignments: list[str] = []
        values: list[Any] = []
        for column, value in (("quantity", quantity), ("stop_loss", stop_loss), ("status", status)):
            if value is not None:
                assignments.append(f"{column}=?")
                values.append(value)
        if not assignments:
            return False
        assignments.append("updated_at_utc=?")
        values.append(_now())
        values.extend((symbol, position_side, signal_id))
        with self._connection() as db:
            cursor = db.execute(
                "UPDATE managed_positions SET " + ",".join(assignments) +
                " WHERE symbol=? AND position_side=? AND signal_id=?", values,
            )
            return cursor.rowcount == 1

    def account_observation_readiness(self, *, now_ms: int,
                                      max_reconciliation_age_ms: int = 30_000) -> tuple[bool, tuple[str, ...]]:
        """Stream/reconciliation readiness for managing existing positions.

        Unlike entry readiness, this intentionally ignores the new-entry kill switch:
        existing positions must remain manageable while new entries are halted.
        """
        reasons: list[str] = []
        with self._connection() as db:
            db.execute("BEGIN")
            stream = db.execute("SELECT * FROM user_stream_control WHERE id=1").fetchone()
            reconcile = db.execute("SELECT * FROM reconciliation_state WHERE id=1").fetchone()
            if stream is None or stream["status"] != "CONNECTED":
                reasons.append("USER_STREAM_NOT_CONNECTED")
            observation_reconciled = False
            if reconcile is not None:
                # An entry kill-switch must not disable management of an already-open
                # position. ENTRIES_HALTED is an acceptable observation state only
                # when the latest REST reconciliation itself has no discrepancies;
                # BLOCKED_MISMATCH / CAPTURE_FAILED remain fail-closed.
                reconciliation_status = str(reconcile["status"] or "")
                try:
                    reconciliation_detail = json.loads(reconcile["detail_json"] or "{}")
                except (TypeError, ValueError):
                    reconciliation_detail = {}
                discrepancies = reconciliation_detail.get("discrepancies", [])
                observation_reconciled = bool(
                    reconcile["ready"]
                    or (reconciliation_status == "ENTRIES_HALTED"
                        and isinstance(discrepancies, list) and not discrepancies)
                )
            if not observation_reconciled:
                reasons.append("ACCOUNT_NOT_RECONCILED")
            captured = reconcile["captured_at_ms"] if reconcile else None
            if (not isinstance(captured, int) or captured > now_ms
                    or now_ms - captured > max_reconciliation_age_ms):
                reasons.append("ACCOUNT_RECONCILIATION_STALE")
            if stream and reconcile and reconcile["ready"]:
                try:
                    detail = json.loads(reconcile["detail_json"] or "{}")
                except (TypeError, ValueError):
                    detail = {}
                watermark = detail.get("stream_event_watermark_ms")
                last_event = int(stream["last_event_at_ms"] or 0)
                if not isinstance(watermark, int) or watermark != last_event:
                    reasons.append("ACCOUNT_EVENT_NOT_RECONCILED")
            db.commit()
        return not reasons, tuple(reasons)

    def store_income_rows(self, rows: list[dict[str, Any]]) -> int:
        saved = 0
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                for row in rows:
                    income_type = str(row.get("incomeType", "UNKNOWN"))
                    tran_id = str(row.get("tranId", ""))
                    if not tran_id:
                        continue
                    income_value = Decimal(str(row.get("income", "0")))
                    if not income_value.is_finite():
                        raise ValueError("income history contains non-finite income")
                    asset = str(row.get("asset", "")).upper()
                    cursor = db.execute("""INSERT OR IGNORE INTO income_history
                        (income_type,tran_id,symbol,income,asset,time_ms,payload_json)
                        VALUES(?,?,?,?,?,?,?)""",
                        (income_type, tran_id, str(row.get("symbol", "")), str(income_value),
                         asset, int(row.get("time", 0)), _json(row)))
                    saved += cursor.rowcount
                    if cursor.rowcount == 1 and income_type == "TRANSFER" and asset == "USDT":
                        adjustment_row = db.execute(
                            "SELECT net_transfer_usdt FROM income_cashflow_adjustment WHERE id=1"
                        ).fetchone()
                        adjustment = Decimal(str(adjustment_row[0] if adjustment_row else "0")) + income_value
                        db.execute("UPDATE income_cashflow_adjustment SET net_transfer_usdt=?,updated_at_utc=? WHERE id=1",
                                   (str(adjustment), _now()))
                db.commit()
            except Exception:
                db.rollback()
                raise
        return saved

    def list_income_rows(self, *, start_time_ms: int | None = None,
                         end_time_ms: int | None = None) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if start_time_ms is not None:
            clauses.append("time_ms>=?"); params.append(int(start_time_ms))
        if end_time_ms is not None:
            clauses.append("time_ms<=?"); params.append(int(end_time_ms))
        sql = "SELECT * FROM income_history"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY time_ms,income_type,tran_id"
        with self._connection() as db:
            rows = db.execute(sql, tuple(params)).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["payload"] = json.loads(item.pop("payload_json"))
            result.append(item)
        return result

    def income_cashflow_adjustment_usdt(self) -> Decimal:
        with self._connection() as db:
            row = db.execute("SELECT net_transfer_usdt FROM income_cashflow_adjustment WHERE id=1").fetchone()
        return Decimal(str(row[0])) if row is not None else Decimal("0")

    def get_income_backfill_state(self) -> dict[str, Any]:
        with self._connection() as db:
            row = db.execute("SELECT * FROM income_backfill_state WHERE id=1").fetchone()
        return {} if row is None else dict(row)

    def set_income_backfill_state(self, *, watermark_ms: int | None = None,
                                  last_error: str | None = None) -> None:
        with self._connection() as db:
            if watermark_ms is None:
                db.execute("UPDATE income_backfill_state SET last_error=?,updated_at_utc=? WHERE id=1",
                           (None if last_error is None else str(last_error)[:500], _now()))
            else:
                db.execute("UPDATE income_backfill_state SET watermark_ms=?,last_error=NULL,updated_at_utc=? WHERE id=1",
                           (int(watermark_ms), _now()))

    def set_entries_halted(self, halted: bool, reason: str | None = None) -> None:
        with self._connection() as db:
            db.execute("UPDATE execution_control SET entries_halted=?,halt_reason=?,updated_at_utc=? WHERE id=1",
                       (1 if halted else 0, reason, _now()))

    def clear_entries_halt_if_reason(self, expected_reason: str) -> bool:
        """Atomically clear only a transient halt that this worker still owns.

        A concurrent safety latch or operator kill switch must never be erased
        by a previously started backfill/reconciliation completion callback.
        """
        if not expected_reason or not isinstance(expected_reason, str):
            raise ValueError("expected_reason must be a non-empty string")
        with self._connection() as db:
            result = db.execute(
                "UPDATE execution_control SET entries_halted=0,halt_reason=NULL,updated_at_utc=? "
                "WHERE id=1 AND entries_halted=1 AND halt_reason=?",
                (_now(), expected_reason),
            )
            return result.rowcount == 1

    def entries_halted(self) -> tuple[bool, str | None]:
        with self._connection() as db:
            row = db.execute("SELECT entries_halted,halt_reason FROM execution_control WHERE id=1").fetchone()
            return bool(row["entries_halted"]), row["halt_reason"]

    def list_intents(self, statuses: tuple[str, ...]) -> list[dict[str, Any]]:
        if not statuses:
            return []
        placeholders = ",".join("?" for _ in statuses)
        with self._connection() as db:
            rows = db.execute(f"SELECT * FROM trade_intents WHERE status IN ({placeholders}) ORDER BY created_at_utc",
                              statuses).fetchall()
            return [dict(row) for row in rows]

    def list_orders(self, signal_id: str) -> list[dict[str, Any]]:
        with self._connection() as db:
            rows = db.execute("SELECT * FROM execution_orders WHERE signal_id=? ORDER BY role",
                              (signal_id,)).fetchall()
            return [dict(row) for row in rows]

    def list_all_execution_orders(self) -> list[dict[str, Any]]:
        """Return all locally owned orders for exchange snapshot attribution."""
        with self._connection() as db:
            rows = db.execute("SELECT * FROM execution_orders ORDER BY updated_at_utc,client_id").fetchall()
            result = []
            for row in rows:
                item = dict(row)
                try:
                    item["payload"] = json.loads(item.pop("payload_json"))
                except (TypeError, ValueError):
                    item["payload"] = {}
                result.append(item)
            return result

    def list_risk_reservations(self, *, status: str | None = None) -> list[dict[str, Any]]:
        """Return risk reservations for read-only operator visibility."""
        query = "SELECT * FROM risk_reservations"
        params: tuple[Any, ...] = ()
        if status is not None:
            query += " WHERE status=?"
            params = (status.upper(),)
        query += " ORDER BY created_at_utc,signal_id"
        with self._connection() as db:
            return [dict(row) for row in db.execute(query, params).fetchall()]
