"""Deterministic, restart-safe position lifecycle decision engine.

This module plans management actions only. Exchange mutations must be performed by
an execution adapter and confirmed through User Data Stream/reconciliation before
advancing the persisted lifecycle state.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from decimal import Decimal
from typing import Literal

Side = Literal["LONG", "SHORT"]


def _d(value: Decimal | str | int, field: str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except Exception as exc:
        raise ValueError(f"{field} must be Decimal-compatible") from exc
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


@dataclass(frozen=True, slots=True)
class ManagedPositionState:
    signal_id: str
    symbol: str
    side: Side
    quantity: Decimal
    entry_price: Decimal
    initial_stop: Decimal
    current_stop: Decimal
    initial_risk_per_unit: Decimal
    partial_tp_fraction: Decimal = Decimal("0.5")
    partial_tp_done: bool = False
    breakeven_done: bool = False
    trailing_active: bool = False
    favorable_extreme: Decimal | None = None
    last_mark_price: Decimal | None = None
    structural_invalidation_price: Decimal | None = None
    structural_invalidation_reason: str = "SMC structural invalidation"
    initial_quantity: Decimal | None = None
    partial_tp_target_quantity: Decimal | None = None
    partial_tp_filled_quantity: Decimal = Decimal("0")
    closed: bool = False

    def __post_init__(self) -> None:
        if self.side not in ("LONG", "SHORT"):
            raise ValueError("side must be LONG or SHORT")
        for name in ("quantity", "entry_price", "initial_risk_per_unit", "partial_tp_fraction"):
            value = _d(getattr(self, name), name)
            if value <= 0:
                raise ValueError(f"{name} must be positive")
        if self.partial_tp_fraction >= 1:
            raise ValueError("partial_tp_fraction must be below 1")
        initial_quantity = self.quantity if self.initial_quantity is None else _d(
            self.initial_quantity, "initial_quantity"
        )
        target_quantity = (None if self.partial_tp_target_quantity is None else
                           _d(self.partial_tp_target_quantity, "partial_tp_target_quantity"))
        partial_filled = _d(self.partial_tp_filled_quantity, "partial_tp_filled_quantity")
        if initial_quantity <= 0 or initial_quantity < self.quantity:
            raise ValueError("initial_quantity must be positive and >= current quantity")
        if target_quantity is not None and (target_quantity <= 0 or target_quantity >= initial_quantity):
            raise ValueError("partial_tp_target_quantity must be positive and below initial quantity")
        if partial_filled < 0 or partial_filled >= initial_quantity:
            raise ValueError("partial_tp_filled_quantity must be non-negative and below initial quantity")
        object.__setattr__(self, "initial_quantity", initial_quantity)
        object.__setattr__(self, "partial_tp_target_quantity", target_quantity)
        object.__setattr__(self, "partial_tp_filled_quantity", partial_filled)
        if self.initial_risk_per_unit != abs(self.entry_price - self.initial_stop):
            raise ValueError("initial_risk_per_unit must equal entry-to-initial-stop distance")
        if self.side == "LONG" and self.initial_stop >= self.entry_price:
            raise ValueError("LONG initial stop must be below entry")
        if self.side == "SHORT" and self.initial_stop <= self.entry_price:
            raise ValueError("SHORT initial stop must be above entry")
        if self.structural_invalidation_price is not None:
            invalidation = _d(self.structural_invalidation_price, "structural_invalidation_price")
            if invalidation <= 0:
                raise ValueError("structural_invalidation_price must be positive")
            if self.side == "LONG" and invalidation >= self.entry_price:
                raise ValueError("LONG structural invalidation must be below entry")
            if self.side == "SHORT" and invalidation <= self.entry_price:
                raise ValueError("SHORT structural invalidation must be above entry")
        if not isinstance(self.structural_invalidation_reason, str) or not self.structural_invalidation_reason.strip():
            raise ValueError("structural_invalidation_reason must be non-empty")


@dataclass(frozen=True, slots=True)
class LifecycleAction:
    action_id: str
    kind: str
    signal_id: str
    symbol: str
    side: Side
    quantity: Decimal | None = None
    stop_price: Decimal | None = None
    reason: str = ""


@dataclass(frozen=True, slots=True)
class LifecycleDecision:
    actions: tuple[LifecycleAction, ...]
    proposed_state: ManagedPositionState
    current_r: Decimal


class PositionLifecycleEngine:
    """Plans partial TP at 1R, BE after confirmed partial, then 1R trailing."""

    def __init__(self, *, partial_tp_r: Decimal = Decimal("1"), trailing_activation_r: Decimal = Decimal("1.5"), trailing_distance_r: Decimal = Decimal("1")) -> None:
        self.partial_tp_r = _d(partial_tp_r, "partial_tp_r")
        self.trailing_activation_r = _d(trailing_activation_r, "trailing_activation_r")
        self.trailing_distance_r = _d(trailing_distance_r, "trailing_distance_r")
        if min(self.partial_tp_r, self.trailing_activation_r, self.trailing_distance_r) <= 0:
            raise ValueError("R thresholds must be positive")

    @staticmethod
    def _id(signal_id: str, kind: str, value: str = "") -> str:
        return "DIVAM" + hashlib.sha256(f"{signal_id}|{kind}|{value}".encode()).hexdigest()[:24].upper()

    def evaluate(self, state: ManagedPositionState, mark_price: Decimal | str) -> LifecycleDecision:
        mark = _d(mark_price, "mark_price")
        if mark <= 0:
            raise ValueError("mark_price must be positive")
        if state.closed:
            return LifecycleDecision((), state, Decimal("0"))
        direction = Decimal("1") if state.side == "LONG" else Decimal("-1")
        favorable = (mark - state.entry_price) * direction
        r = favorable / state.initial_risk_per_unit
        extreme = state.favorable_extreme
        if extreme is None or (mark > extreme if state.side == "LONG" else mark < extreme):
            extreme = mark
        actions: list[LifecycleAction] = []
        next_state = state
        invalidation = state.structural_invalidation_price
        invalidated = (invalidation is not None and
                       (mark <= invalidation if state.side == "LONG" else mark >= invalidation))
        if invalidated:
            action = LifecycleAction(
                self._id(state.signal_id, "STRUCTURAL_EXIT", str(invalidation)),
                "STRUCTURAL_EXIT", state.signal_id, state.symbol, state.side,
                reason=state.structural_invalidation_reason,
            )
            next_state = ManagedPositionState(
                signal_id=state.signal_id, symbol=state.symbol, side=state.side,
                quantity=state.quantity, entry_price=state.entry_price, initial_stop=state.initial_stop,
                current_stop=state.current_stop, initial_risk_per_unit=state.initial_risk_per_unit,
                partial_tp_fraction=state.partial_tp_fraction, partial_tp_done=state.partial_tp_done,
                breakeven_done=state.breakeven_done, trailing_active=state.trailing_active,
                favorable_extreme=extreme, last_mark_price=mark,
                structural_invalidation_price=state.structural_invalidation_price,
                structural_invalidation_reason=state.structural_invalidation_reason,
                initial_quantity=state.initial_quantity,
                partial_tp_target_quantity=state.partial_tp_target_quantity,
                partial_tp_filled_quantity=state.partial_tp_filled_quantity, closed=False,
            )
            return LifecycleDecision((action,), next_state, r)
        partial_target = (state.partial_tp_target_quantity
                          if state.partial_tp_target_quantity is not None
                          else state.initial_quantity * state.partial_tp_fraction)
        partial_remaining = partial_target - state.partial_tp_filled_quantity
        if r >= self.partial_tp_r and not state.partial_tp_done and partial_remaining > Decimal("1e-10"):
            if partial_remaining >= state.quantity:
                raise ValueError("PARTIAL_TP_TARGET_EXCEEDS_REMAINING_POSITION")
            actions.append(LifecycleAction(
                self._id(state.signal_id, "PARTIAL_TP", str(partial_remaining)),
                "PARTIAL_TP", state.signal_id, state.symbol, state.side,
                quantity=partial_remaining, reason=f"Reached {self.partial_tp_r}R; complete original partial target",
            ))
        # BE is emitted only after the caller records confirmed partial fill.
        stop_candidate: Decimal | None = None
        stop_reason = ""
        if state.partial_tp_done and not state.breakeven_done:
            be = state.entry_price
            improves = be > state.current_stop if state.side == "LONG" else be < state.current_stop
            if improves:
                stop_candidate, stop_reason = be, "Partial TP confirmed; move stop to breakeven"
        if r >= self.trailing_activation_r:
            distance = self.trailing_distance_r * state.initial_risk_per_unit
            candidate = extreme - distance if state.side == "LONG" else extreme + distance
            baseline = stop_candidate if stop_candidate is not None else state.current_stop
            improves = candidate > baseline if state.side == "LONG" else candidate < baseline
            if improves:
                stop_candidate, stop_reason = candidate, "Favorable excursion trailing stop"
        if stop_candidate is not None:
            kind = "TRAIL" if "trailing" in stop_reason.lower() else "MOVE_STOP_BE"
            actions.append(LifecycleAction(self._id(state.signal_id, kind, str(stop_candidate)), "MOVE_STOP", state.signal_id, state.symbol, state.side, stop_price=stop_candidate, reason=stop_reason))
        next_state = ManagedPositionState(
            signal_id=state.signal_id, symbol=state.symbol, side=state.side,
            quantity=state.quantity, entry_price=state.entry_price, initial_stop=state.initial_stop,
            current_stop=state.current_stop, initial_risk_per_unit=state.initial_risk_per_unit,
            partial_tp_fraction=state.partial_tp_fraction, partial_tp_done=state.partial_tp_done,
            breakeven_done=state.breakeven_done, trailing_active=state.trailing_active or r >= self.trailing_activation_r,
            favorable_extreme=extreme, last_mark_price=mark,
            structural_invalidation_price=state.structural_invalidation_price,
            structural_invalidation_reason=state.structural_invalidation_reason,
            initial_quantity=state.initial_quantity,
            partial_tp_target_quantity=state.partial_tp_target_quantity,
            partial_tp_filled_quantity=state.partial_tp_filled_quantity, closed=state.closed,
        )
        return LifecycleDecision(tuple(actions), next_state, r)
