"""Bounded, restart-safe USD-M income history backfill."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from .ledger import ExecutionLedger

SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000
NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000
OVERLAP_MS = 60_000


@dataclass(frozen=True, slots=True)
class IncomeBackfillResult:
    range_start_ms: int
    range_end_ms: int
    requests: int
    received_rows: int
    inserted_rows: int
    watermark_ms: int


class BinanceIncomeHistoryBackfillService:
    """Fetch all account income rows with small time windows and idempotent persistence.

    The income endpoint is time-window paged rather than cursor paged. A full page is
    recursively split so dense windows cannot silently lose records at the API cap.
    Watermarks advance only after every sub-window has been stored successfully.
    """
    def __init__(self, *, client: Any, ledger: ExecutionLedger,
                 clock_ms: Callable[[], int] | None = None,
                 sleep: Callable[[float], None] = time.sleep,
                 request_pause_seconds: float = 0.15,
                 page_limit: int = 1000, max_requests_per_run: int = 2000) -> None:
        if not 1 <= page_limit <= 1000:
            raise ValueError("page_limit must be in [1, 1000]")
        if not 1 <= max_requests_per_run <= 10000:
            raise ValueError("max_requests_per_run must be in [1, 10000]")
        if not 0 <= request_pause_seconds <= 5:
            raise ValueError("request_pause_seconds must be in [0, 5]")
        self.client, self.ledger = client, ledger
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self.sleep, self.pause = sleep, request_pause_seconds
        self.page_limit, self.max_requests = page_limit, max_requests_per_run
        self._requests = 0

    def _fetch(self, start: int, end: int) -> list[dict[str, Any]]:
        self._requests += 1
        if self._requests > self.max_requests:
            raise RuntimeError("INCOME_BACKFILL_REQUEST_BUDGET_EXCEEDED")
        if self.pause:
            self.sleep(self.pause)
        rows = self.client.get_income_history(start_time_ms=start, end_time_ms=end,
                                              limit=self.page_limit)
        if not isinstance(rows, list):
            raise RuntimeError("INCOME_HISTORY_RESPONSE_NOT_LIST")
        return sorted(rows, key=lambda row: (int(row.get("time", 0)), str(row.get("tranId", ""))))

    def backfill(self, *, start_time_ms: int | None = None,
                 end_time_ms: int | None = None) -> IncomeBackfillResult:
        now = int(self.clock_ms())
        end = now if end_time_ms is None else int(end_time_ms)
        if end <= 0 or end > now + 60_000:
            raise ValueError("end_time_ms outside safe range")
        state = self.ledger.get_income_backfill_state()
        watermark = int(state.get("watermark_ms") or 0)
        if start_time_ms is not None:
            start = int(start_time_ms)
        elif watermark:
            start = max(0, watermark - OVERLAP_MS)
        else:
            start = max(0, end - NINETY_DAYS_MS)
        if start < 0 or start > end or end - start > NINETY_DAYS_MS:
            raise ValueError("income backfill window must be within the last 90 days")
        self._requests = received = inserted = 0
        try:
            def fetch_window(left: int, right: int, depth: int = 0) -> None:
                nonlocal received, inserted
                rows = self._fetch(left, right)
                if len(rows) >= self.page_limit:
                    if right <= left or depth >= 32:
                        raise RuntimeError("INCOME_BACKFILL_DENSE_MILLISECOND_WINDOW_EXCEEDS_LIMIT")
                    midpoint = (left + right) // 2
                    fetch_window(left, midpoint, depth + 1)
                    fetch_window(midpoint + 1, right, depth + 1)
                    return
                received += len(rows)
                inserted += self.ledger.store_income_rows(rows)

            cursor = start
            while cursor <= end:
                window_end = min(end, cursor + SEVEN_DAYS_MS - 1)
                fetch_window(cursor, window_end)
                cursor = window_end + 1
            self.ledger.set_income_backfill_state(watermark_ms=end)
            return IncomeBackfillResult(start, end, self._requests, received, inserted, end)
        except Exception as exc:
            self.ledger.set_income_backfill_state(last_error=f"{type(exc).__name__}: {exc}")
            raise
