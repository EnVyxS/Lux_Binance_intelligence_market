"""Idempotent multi-symbol execution lifecycle with protected-position gating."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from contextlib import nullcontext
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import Enum
from threading import RLock
from typing import Any, Mapping

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.trading.exchange_feasibility import SymbolConfiguration, SymbolMetadataError
from divatrading.trading.models import TradePlan
from divatrading.trading.post_fill_risk import assess_post_fill_risk
from divatrading.trading.entry_quote_guard import EntryQuoteGuardConfig, check_entry_quote
from .binance_private import BinancePrivateApiError, BinancePrivateRestClient
from .ledger import ExecutionLedger
from .position_lifecycle import LifecycleAction
from .position_lifecycle_execution import IOC_INITIAL_STOP_REJECTED, PositionLifecycleExecutionAdapter
from .protection import (build_quantity_scoped_protection_params,
                         is_legacy_close_position_order_valid,
                         is_quantity_scoped_order_valid)


_IOC_ZERO_FILL_TERMINAL = {"CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"}
_IOC_TERMINAL = {"FILLED", *_IOC_ZERO_FILL_TERMINAL}
_DEFINITIVE_STOP_REJECTION_CODES = {-1111, -2021, -2022, -4004, -4014, -4023, -4061, -4120}


class _InitialIocStopRejected(RuntimeError):
    """An initial STOP submission was explicitly rejected by Binance."""


class ExecutionMode(str, Enum):
    PAPER = "PAPER"
    TESTNET = "TESTNET"
    LIVE = "LIVE"


@dataclass(frozen=True, slots=True)
class ExecutionConfig:
    mode: ExecutionMode = ExecutionMode.PAPER
    enable_testnet_orders: bool = False
    enable_testnet_stage_c: bool = False
    enable_protection_recovery: bool = False
    enable_live_trading: bool = False
    live_confirmation: str = ""
    working_type: str = "MARK_PRICE"
    price_protect: bool = True
    require_account_readiness: bool = True
    max_account_snapshot_age_ms: int = 30_000
    paper_simulate_fills: bool = False
    enforce_entry_quote_guard: bool = False
    max_entry_spread_bps: Decimal = Decimal("20")
    max_market_slippage_bps: Decimal = Decimal("20")

    def __post_init__(self) -> None:
        if not isinstance(self.paper_simulate_fills, bool):
            raise ValueError("paper_simulate_fills must be boolean")
        if not isinstance(self.enable_protection_recovery, bool):
            raise ValueError("enable_protection_recovery must be boolean")
        if not isinstance(self.enforce_entry_quote_guard, bool):
            raise ValueError("enforce_entry_quote_guard must be boolean")
        EntryQuoteGuardConfig(max_spread_bps=self.max_entry_spread_bps,
                              max_market_slippage_bps=self.max_market_slippage_bps)
        if self.enable_protection_recovery and self.mode == ExecutionMode.PAPER:
            raise ValueError("automatic protective recovery is only for TESTNET/LIVE")
        if self.working_type not in {"MARK_PRICE", "CONTRACT_PRICE"}:
            raise ValueError("working_type must be MARK_PRICE or CONTRACT_PRICE")
        if (isinstance(self.max_account_snapshot_age_ms, bool)
                or not isinstance(self.max_account_snapshot_age_ms, int)
                or self.max_account_snapshot_age_ms < 1000):
            raise ValueError("max_account_snapshot_age_ms must be >= 1000")
        if self.mode != ExecutionMode.PAPER and not self.require_account_readiness:
            raise ValueError("TESTNET/LIVE cannot disable the account stream and reconciliation readiness gate")
        if self.mode == ExecutionMode.TESTNET and not self.enable_testnet_orders:
            raise ValueError("TESTNET order placement requires enable_testnet_orders=True")
        if self.mode == ExecutionMode.TESTNET and not self.enable_testnet_stage_c:
            raise ValueError("TESTNET Stage C execution requires enable_testnet_stage_c=True")
        if self.mode == ExecutionMode.LIVE:
            if not self.enable_live_trading:
                raise ValueError("LIVE mode requires enable_live_trading=True")
            if self.live_confirmation != "I_ACCEPT_REAL_MONEY_RISK":
                raise ValueError("LIVE mode requires live_confirmation=I_ACCEPT_REAL_MONEY_RISK")
            if not self.enforce_entry_quote_guard:
                raise ValueError("LIVE requires executable bid/ask quote guard")

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "ExecutionConfig":
        if environ is None:
            from divatrading.core.config import _parse_env_file
            env = _parse_env_file(Path.cwd() / ".env")
            env.update(dict(os.environ))
        else:
            env = dict(environ)
        mode = ExecutionMode(env.get("DIVA_EXECUTION_MODE", "PAPER").strip().upper())
        return cls(
            mode=mode,
            enable_testnet_orders=env.get("DIVA_ENABLE_TESTNET_ORDERS", "false").lower() in {"1", "true", "yes"},
            enable_testnet_stage_c=env.get("DIVA_ENABLE_TESTNET_STAGE_C", "false").lower() in {"1", "true", "yes"},
            enable_protection_recovery=env.get("DIVA_ENABLE_PROTECTION_RECOVERY", "false").strip().lower() in {"1", "true", "yes"},
            enable_live_trading=env.get("DIVA_LIVE_TRADING_ENABLED", "false").lower() in {"1", "true", "yes"},
            live_confirmation=env.get("DIVA_LIVE_CONFIRMATION", ""),
            working_type=env.get("DIVA_PROTECTION_WORKING_TYPE", "MARK_PRICE").upper(),
            price_protect=env.get("DIVA_PRICE_PROTECT", "true").lower() in {"1", "true", "yes"},
            require_account_readiness=env.get("DIVA_REQUIRE_ACCOUNT_READINESS", "true").lower() in {"1", "true", "yes"},
            max_account_snapshot_age_ms=int(env.get("DIVA_MAX_ACCOUNT_SNAPSHOT_AGE_MS", "30000")),
            paper_simulate_fills=env.get("DIVA_PAPER_SIMULATE_FILLS", "true").lower() in {"1", "true", "yes"},
            enforce_entry_quote_guard=env.get("DIVA_ENFORCE_ENTRY_QUOTE_GUARD", "false").lower() in {"1", "true", "yes"},
            max_entry_spread_bps=Decimal(env.get("DIVA_MAX_ENTRY_SPREAD_BPS", "20")),
            max_market_slippage_bps=Decimal(env.get("DIVA_MAX_MARKET_SLIPPAGE_BPS", "20")),
        )


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    signal_id: str
    status: str
    entry_order: dict[str, Any] | None
    stop_order: dict[str, Any] | None = None
    take_profit_order: dict[str, Any] | None = None
    duplicate: bool = False
    detail: str = ""


class ExecutionService:
    """Submit entries once, protect every observed fill, and halt on unsafe states.

    The service supports one-way and hedge positionSide fields. All state changes
    are persisted before/after network operations so ambiguous POST results can be
    reconciled by the deterministic Binance client ID; they are never blindly retried.
    """
    @classmethod
    def from_environment(cls, ledger_path: Path | str, *,
                         environ: Mapping[str, str] | None = None) -> "ExecutionService":
        """Build a local service from .env/process env; PAPER never loads a private client."""
        if environ is None:
            from divatrading.core.config import _parse_env_file
            values = _parse_env_file(Path.cwd() / ".env")
            values.update(dict(os.environ))
        else:
            values = dict(environ)
        config = ExecutionConfig.from_env(values)
        client = None
        if config.mode != ExecutionMode.PAPER:
            api_key = values.get("BINANCE_API_KEY", "")
            api_secret = values.get("BINANCE_API_SECRET", "")
            if not api_key or not api_secret:
                raise ValueError("TESTNET/LIVE requires BINANCE_API_KEY and BINANCE_API_SECRET")
            client = BinancePrivateRestClient(api_key, api_secret, environment=config.mode.value)
        return cls(ExecutionLedger(ledger_path), config=config, client=client)

    def __init__(self, ledger: ExecutionLedger, *, config: ExecutionConfig | None = None,
                 client: BinancePrivateRestClient | None = None) -> None:
        self.ledger = ledger
        self.config = config or ExecutionConfig()
        self.client = client
        self._ioc_lock = RLock()
        if self.config.mode == ExecutionMode.PAPER:
            if client is not None:
                raise ValueError("PAPER mode must not receive a private exchange client")
        else:
            if client is None:
                raise ValueError("TESTNET/LIVE mode requires BinancePrivateRestClient")
            if client.environment != self.config.mode.value:
                raise ValueError("Execution mode and signed client environment do not match")

    @staticmethod
    def _order_side(side: str) -> str:
        return "BUY" if side == "LONG" else "SELL"

    @staticmethod
    def _position_side(side: str, dual_side: bool) -> str:
        return side if dual_side else "BOTH"

    def _existing_entry_conflict(self, *, symbol: str, position_side: str,
                                 signal_id: str) -> str | None:
        """Second-line execution gate against unqualified same-side scale-in.

        One-way positions are netted, so any existing managed position for the
        symbol blocks another entry. Hedge Mode permits the opposite leg, but a
        second signal on the same positionSide remains disabled pending TESTNET
        qualification. Ambiguous/pending entries block all new entries for symbol.
        """
        normalized = symbol.upper()
        for row in self.ledger.list_managed_positions(status="OPEN"):
            if str(row.get("symbol", "")).upper() != normalized:
                continue
            existing_side = str(row.get("position_side", "")).upper()
            if existing_side == "BOTH":
                return "ONE_WAY_SYMBOL_POSITION_ALREADY_OPEN"
            if existing_side == position_side.upper():
                return "SAME_SIDE_SCALE_IN_DISABLED_PENDING_TESTNET_QUALIFICATION"

        for intent in self.ledger.list_intents((
            "CLAIMED", "ENTRY_PENDING", "SUBMISSION_UNKNOWN",
            "ENTRY_PARTIALLY_OR_FULLY_FILLED",
        )):
            if (str(intent.get("symbol", "")).upper() == normalized
                    and str(intent.get("signal_id", "")) != signal_id):
                return "SYMBOL_ENTRY_REQUIRES_RECONCILIATION"
        return None

    @staticmethod
    def _payload(plan: TradePlan) -> dict[str, Any]:
        s = plan.signal
        return {
            "signal": {
                "signal_id": s.signal_id, "symbol": s.symbol, "side": s.side,
                "entry_type": s.entry_type, "entry_price": str(s.entry_price),
                "stop_loss": str(s.stop_loss), "take_profit": str(s.take_profit),
                "timeframe": s.timeframe, "strategy_id": s.strategy_id,
                "created_at_ms": s.created_at_ms, "reason_codes": list(s.reason_codes),
                **({"minimum_net_rr": str(s.minimum_net_rr)} if s.minimum_net_rr is not None else {}),
            },
            "quantity": str(plan.quantity), "notional_usdt": str(plan.notional_usdt),
            "risk_usdt": str(plan.risk_usdt), "margin_estimate_usdt": str(plan.margin_estimate_usdt),
            "leverage": plan.leverage, "client_order_id": plan.client_order_id,
            "margin_mode": plan.margin_mode,
            "fee_reserve_usdt": str(plan.fee_reserve_usdt),
            "slippage_reserve_usdt": str(plan.slippage_reserve_usdt),
            "funding_reserve_usdt": str(plan.funding_reserve_usdt),
            "maintenance_margin_estimate_usdt": str(plan.maintenance_margin_estimate_usdt),
        }

    def _initialize_position_management_state(
        self, plan: TradePlan, *, quantity: Decimal, entry_price: Decimal,
    ) -> None:
        """Create restart-safe lifecycle state after a protected exchange fill.

        Existing state is never overwritten: it may already contain confirmed partial
        TP, breakeven, or trailing progress from a previous process.
        """
        s = plan.signal
        if quantity <= 0 or entry_price <= 0:
            raise ValueError("managed position quantity and entry price must be positive")
        existing = self.ledger.get_position_management_state(s.signal_id)
        if existing is not None:
            stored = existing.get("state", {})
            if str(stored.get("symbol", s.symbol)).upper() != s.symbol.upper() or str(
                stored.get("side", s.side)
            ).upper() != s.side:
                raise RuntimeError("PERSISTED_POSITION_MANAGEMENT_IDENTITY_MISMATCH")
            return
        initial_risk = abs(entry_price - s.stop_loss)
        if initial_risk <= 0:
            raise ValueError("entry price and stop loss must define positive initial risk")
        state = {
            "signal_id": s.signal_id, "symbol": s.symbol.upper(), "side": s.side,
            "quantity": str(quantity), "initial_quantity": str(quantity),
            "partial_tp_target_quantity": None,
            "partial_tp_filled_quantity": "0", "entry_price": str(entry_price),
            "initial_stop": str(s.stop_loss), "current_stop": str(s.stop_loss),
            "initial_risk_per_unit": str(initial_risk),
            "partial_tp_fraction": "0.5", "partial_tp_done": False,
            "breakeven_done": False, "trailing_active": False,
            "favorable_extreme": None, "last_mark_price": None,
            "structural_invalidation_price": str(s.stop_loss),
            "structural_invalidation_reason": "Approved SMC TradePlan stop/invalidation boundary",
            "closed": False,
            "stop_algo_client_id": self.ledger.deterministic_client_id(s.signal_id, "STOP_LOSS"),
            "take_profit_algo_client_id": self.ledger.deterministic_client_id(s.signal_id, "TAKE_PROFIT"),
        }
        self.ledger.save_position_management_state(
            signal_id=s.signal_id, symbol=s.symbol.upper(), state=state, expected_version=0,
        )
        self.ledger.record_event(
            "POSITION_MANAGEMENT_INITIALIZED", signal_id=s.signal_id, symbol=s.symbol,
            detail={"quantity": str(quantity), "entry_price": str(entry_price),
                    "initial_risk_per_unit": str(initial_risk)},
        )

    def _simulate_paper_fill(self, plan: TradePlan) -> ExecutionResult:
        """Create a deterministic local fill and quantity-scoped virtual protection.

        This records a simulated position in the same managed-position ledger used by
        the supervisor. No exchange client, websocket, HTTP call or real order is used.
        Fill price equals the approved plan entry price; this is deliberately not a
        slippage/queue-position model and must not be presented as execution evidence.
        """
        signal = plan.signal
        quantity = plan.quantity
        entry_price = signal.entry_price
        position_side = "BOTH"
        entry_payload = {
            "symbol": signal.symbol, "status": "FILLED", "side": self._order_side(signal.side),
            "type": signal.entry_type, "executedQty": str(quantity),
            "origQty": str(quantity), "avgPrice": str(entry_price),
            "clientOrderId": plan.client_order_id, "positionSide": position_side,
            "paper": True, "simulation_model": "PLAN_PRICE_FULL_FILL_NO_SLIPPAGE",
        }
        if signal.entry_type == "LIMIT_IOC":
            entry_payload.update({
                "type": "LIMIT", "timeInForce": "IOC", "price": str(entry_price),
                "entry_liquidity_model": "TAKER", "round_trip_fee_reserve_usdt": str(plan.fee_reserve_usdt),
            })
        self.ledger.record_order(
            client_id=plan.client_order_id, signal_id=signal.signal_id, symbol=signal.symbol,
            role="ENTRY", order_kind="STANDARD", status="PAPER_FILLED",
            exchange_order_id=None, payload=entry_payload,
        )
        stop_id = self.ledger.deterministic_client_id(signal.signal_id, "STOP_LOSS")
        take_id = self.ledger.deterministic_client_id(signal.signal_id, "TAKE_PROFIT")
        exit_side = "SELL" if signal.side == "LONG" else "BUY"
        stop_payload = {
            "symbol": signal.symbol, "algoStatus": "NEW", "side": exit_side,
            "type": "STOP_MARKET", "quantity": str(quantity),
            "triggerPrice": str(signal.stop_loss), "positionSide": position_side,
            "clientAlgoId": stop_id, "closePosition": False, "paper": True,
        }
        take_payload = {
            "symbol": signal.symbol, "algoStatus": "NEW", "side": exit_side,
            "type": "TAKE_PROFIT_MARKET", "quantity": str(quantity),
            "triggerPrice": str(signal.take_profit), "positionSide": position_side,
            "clientAlgoId": take_id, "closePosition": False, "paper": True,
        }
        self.ledger.record_order(
            client_id=stop_id, signal_id=signal.signal_id, symbol=signal.symbol,
            role="STOP_LOSS", order_kind="ALGO", status="PAPER_NEW",
            exchange_order_id=None, payload=stop_payload,
        )
        self.ledger.record_order(
            client_id=take_id, signal_id=signal.signal_id, symbol=signal.symbol,
            role="TAKE_PROFIT", order_kind="ALGO", status="PAPER_NEW",
            exchange_order_id=None, payload=take_payload,
        )
        self.ledger.record_position(
            symbol=signal.symbol, position_side=position_side, signal_id=signal.signal_id,
            quantity=str(quantity), entry_price=str(entry_price),
            stop_loss=str(signal.stop_loss), take_profit=str(signal.take_profit),
        )
        self._initialize_position_management_state(
            plan, quantity=quantity, entry_price=entry_price,
        )
        self.ledger.update_intent(signal.signal_id, "PAPER_PROTECTED")
        self.ledger.record_event(
            "PAPER_SIMULATED_FILL_PROTECTED", signal_id=signal.signal_id, symbol=signal.symbol,
            detail={"quantity": str(quantity), "entry_price": str(entry_price),
                    "stop_loss": str(signal.stop_loss), "take_profit": str(signal.take_profit),
                    "execution_model": "FULL_FILL_AT_PLAN_PRICE_NO_SLIPPAGE"},
        )
        return ExecutionResult(
            signal.signal_id, "PAPER_PROTECTED", entry_payload, stop_payload, take_payload,
            detail="Deterministic local paper fill and virtual protection; no exchange order was sent",
        )

    @staticmethod
    def _local_entry_price(order: Mapping[str, Any], plan: TradePlan) -> Decimal:
        """Nonzero storage fallback, never treated as exchange fill evidence.

        Some RESULT/FILLED responses carry avgPrice="0". A provisional
        managed-state price must be positive so protectors can be retained;
        _audit_confirmed_fill independently halts until execution price is
        verified from authoritative exchange order/trades.
        """
        raw = order.get("avgPrice")
        try:
            actual = Decimal(str(raw))
        except Exception:
            actual = Decimal("0")
        if not actual.is_finite() or actual <= 0:
            return plan.signal.entry_price
        return actual

    def _audit_confirmed_fill(self, plan: TradePlan, *, quantity: Decimal,
                              order: Mapping[str, Any]) -> None:
        """Record exchange-price risk; halt *new* entries if the budget is not proven.

        Called after both conditional protectors have been verified.  It never
        cancels an existing protector and never posts an unconfirmed second entry.
        """
        if self.config.mode == ExecutionMode.PAPER:
            return
        audit = assess_post_fill_risk(
            plan, executed_quantity=quantity, avg_fill_price=order.get("avgPrice"),
        )
        details = {
            "status": audit.status,
            "executed_quantity": str(audit.executed_quantity),
            "avg_fill_price": None if audit.fill_price is None else str(audit.fill_price),
            "actual_risk_usdt": None if audit.actual_risk_usdt is None else str(audit.actual_risk_usdt),
            "allocated_risk_usdt": str(audit.allocated_risk_usdt),
            "protectors_verified_before_check": True,
        }
        self.ledger.record_event(
            "POST_FILL_RISK_CHECK", signal_id=plan.signal.signal_id,
            symbol=plan.signal.symbol, detail=details,
        )
        if not audit.safe_for_new_entries:
            self.ledger.set_entries_halted(
                True, f"POST_FILL_RISK:{plan.signal.symbol}:{audit.status}",
            )
            self.ledger.record_event(
                "POST_FILL_RISK_HALT", signal_id=plan.signal.signal_id,
                symbol=plan.signal.symbol, detail=details,
            )

    def _prepare_symbol_settings(self, *, symbol: str, leverage: int, margin_mode: str) -> None:
        """Apply/verify per-symbol margin settings only while the symbol is flat and order-free.

        The production private client exposes all read-back methods. Minimal test doubles
        from legacy tests may expose only set_leverage; production never takes that path.
        """
        assert self.client is not None
        required = ("get_position_risk", "get_open_orders", "get_open_algo_orders",
                    "get_symbol_config", "change_margin_type", "set_leverage")
        if not all(callable(getattr(self.client, name, None)) for name in required):
            # Compatibility for older injected adapters; real BinancePrivateRestClient
            # always exposes the full read-before-write contract.
            self.client.set_leverage(symbol, leverage)
            return

        positions = self.client.get_position_risk(symbol)
        if any(Decimal(str(row.get("positionAmt", "0"))) != 0 for row in positions):
            raise RuntimeError(f"SYMBOL_SETTINGS_MUTATION_BLOCKED_OPEN_POSITION:{symbol}")
        standard_orders = self.client.get_open_orders(symbol)
        algo_orders = self.client.get_open_algo_orders(symbol)
        if standard_orders or algo_orders:
            raise RuntimeError(f"SYMBOL_SETTINGS_MUTATION_BLOCKED_OPEN_ORDERS:{symbol}")

        try:
            current = SymbolConfiguration.from_binance(self.client.get_symbol_config(symbol), symbol)
        except SymbolMetadataError as exc:
            raise RuntimeError(f"SYMBOL_CONFIG_INVALID:{symbol}:{exc}") from exc

        if current.margin_type != margin_mode:
            try:
                self.client.change_margin_type(symbol, margin_mode)
            except BinancePrivateApiError as exc:
                if exc.code != -4046:  # Binance: already configured to requested margin type
                    raise
        if current.leverage != leverage:
            response = self.client.set_leverage(symbol, leverage)
            if isinstance(response, dict) and response.get("leverage") not in (None, ""):
                if int(response["leverage"]) != leverage:
                    raise RuntimeError(f"EXCHANGE_LEVERAGE_ACK_MISMATCH:{symbol}")

        try:
            verified = SymbolConfiguration.from_binance(self.client.get_symbol_config(symbol), symbol)
        except SymbolMetadataError as exc:
            raise RuntimeError(f"SYMBOL_CONFIG_READBACK_INVALID:{symbol}:{exc}") from exc
        if verified.margin_type != margin_mode or verified.leverage != leverage:
            raise RuntimeError(
                f"SYMBOL_CONFIG_READBACK_MISMATCH:{symbol}:"
                f"margin={verified.margin_type},leverage={verified.leverage}"
            )
        self.ledger.record_event(
            "SYMBOL_SETTINGS_VERIFIED", symbol=symbol,
            detail={"margin_mode": verified.margin_type, "leverage": verified.leverage},
        )

    def submit(self, plan: TradePlan) -> ExecutionResult:
        # IOC attempts are durably staged before POST. Prevent the concurrent
        # reconciler from querying their IDs while this process submits them.
        with self._ioc_lock if plan.signal.entry_type == "LIMIT_IOC" else nullcontext():
            return self._submit(plan)

    def _submit(self, plan: TradePlan) -> ExecutionResult:
        halted, reason = self.ledger.entries_halted()
        if halted:
            raise RuntimeError(f"New entries are halted: {reason or 'unspecified'}")
        payload = self._payload(plan)
        s = plan.signal
        ioc = s.entry_type == "LIMIT_IOC"
        if self.config.mode != ExecutionMode.PAPER:
            reservation = self.ledger.get_risk_reservation(s.signal_id)
            if reservation is None or reservation.get("status") != "ACTIVE":
                raise RuntimeError(
                    "TESTNET/LIVE execution requires an active coordinator portfolio-risk reservation"
                )
            if (
                reservation.get("symbol") != s.symbol
                or Decimal(str(reservation.get("risk_usdt"))) != plan.risk_usdt
                or Decimal(str(reservation.get("notional_usdt"))) != plan.notional_usdt
            ):
                raise RuntimeError(
                    "Active portfolio-risk reservation does not match this TradePlan; execution blocked"
                )
            if self.config.require_account_readiness:
                ready, reasons = self.ledger.execution_readiness(
                    now_ms=time.time_ns() // 1_000_000,
                    max_reconciliation_age_ms=self.config.max_account_snapshot_age_ms,
                )
                if not ready:
                    raise RuntimeError("ACCOUNT_NOT_READY: " + ",".join(reasons))
        created = self.ledger.claim_intent(
            signal_id=s.signal_id, symbol=s.symbol, side=s.side,
            client_order_id=plan.client_order_id, payload=payload,
        )
        if not created:
            existing = self.ledger.get_intent(s.signal_id) or {}
            return ExecutionResult(s.signal_id, str(existing.get("status", "DUPLICATE")), None,
                                   duplicate=True, detail="Signal ID already claimed; no new order sent")
        self.ledger.record_event("INTENT_ACCEPTED", signal_id=s.signal_id, symbol=s.symbol,
                                 detail={"mode": self.config.mode.value, "client_order_id": plan.client_order_id})
        if self.config.mode == ExecutionMode.PAPER:
            if self.config.paper_simulate_fills:
                return self._simulate_paper_fill(plan)
            self.ledger.update_intent(s.signal_id, "PAPER_ACCEPTED")
            return ExecutionResult(s.signal_id, "PAPER_ACCEPTED", None, detail="No exchange order was sent")

        assert self.client is not None
        try:
            self.client.sync_server_time()
            mode = self.client.get_position_mode()
            dual_value = mode.get("dualSidePosition", False)
            dual_side = dual_value is True or str(dual_value).strip().lower() == "true"
            position_side = self._position_side(s.side, dual_side)
            conflict = self._existing_entry_conflict(
                symbol=s.symbol, position_side=position_side, signal_id=s.signal_id,
            )
            if conflict:
                self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_EXISTING_POSITION", error=conflict)
                self.ledger.release_risk_reservation(s.signal_id, conflict)
                self.ledger.record_event(
                    "ENTRY_BLOCKED_EXISTING_POSITION", signal_id=s.signal_id, symbol=s.symbol,
                    detail={"reason": conflict, "position_side": position_side},
                )
                return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_EXISTING_POSITION", None, detail=conflict)
            self._prepare_symbol_settings(
                symbol=s.symbol, leverage=plan.leverage, margin_mode=plan.margin_mode,
            )
            params: dict[str, Any] = {
                "symbol": s.symbol, "side": self._order_side(s.side),
                "type": "LIMIT" if ioc else s.entry_type, "quantity": plan.quantity,
                "newClientOrderId": plan.client_order_id,
                "newOrderRespType": "RESULT", "positionSide": position_side,
            }
            if s.entry_type in {"LIMIT", "LIMIT_IOC"}:
                params.update({"timeInForce": "IOC" if ioc else "GTC", "price": s.entry_price})
            # Re-check immediately before the order POST. Account state may have
            # changed while time sync, position-mode lookup or leverage setup ran.
            if self.config.require_account_readiness:
                ready, reasons = self.ledger.execution_readiness(
                    now_ms=time.time_ns() // 1_000_000,
                    max_reconciliation_age_ms=self.config.max_account_snapshot_age_ms,
                )
                if not ready:
                    detail = "ACCOUNT_NOT_READY_BEFORE_ORDER_POST:" + ",".join(reasons)
                    self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_ACCOUNT_NOT_READY", error=detail)
                    self.ledger.release_risk_reservation(s.signal_id, "ACCOUNT_NOT_READY_BEFORE_ORDER_POST")
                    self.ledger.record_event("ENTRY_BLOCKED_ACCOUNT_NOT_READY", signal_id=s.signal_id,
                                             symbol=s.symbol, detail={"reasons": list(reasons)})
                    return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_ACCOUNT_NOT_READY", None, detail=detail)
            # Account supervision or an operator can halt entries while slow
            # synchronous REST preflight calls are in flight. Re-read the
            # durable latch at the final boundary before issuing any POST.
            halted_before_post, halt_reason = self.ledger.entries_halted()
            if halted_before_post:
                detail = "ENTRIES_HALTED_BEFORE_ORDER_POST:" + (halt_reason or "UNSPECIFIED")
                self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_HALTED_BEFORE_POST", error=detail)
                self.ledger.release_risk_reservation(s.signal_id, "ENTRIES_HALTED_BEFORE_ORDER_POST")
                self.ledger.record_event("ENTRY_BLOCKED_HALTED_BEFORE_POST", signal_id=s.signal_id,
                                         symbol=s.symbol, detail={"reason": halt_reason or "UNSPECIFIED"})
                return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_HALTED_BEFORE_POST", None, detail=detail)
            if self.config.enforce_entry_quote_guard or ioc:
                try:
                    book = self.client.get_order_book_top(s.symbol)
                    verdict = check_entry_quote(
                        plan, book, now_exchange_ms=self.client.exchange_now_ms(),
                        config=EntryQuoteGuardConfig(
                            max_spread_bps=self.config.max_entry_spread_bps,
                            max_market_slippage_bps=self.config.max_market_slippage_bps,
                        ),
                    )
                except Exception as quote_exc:
                    # No entry POST has occurred. Never leave this as an
                    # ambiguous exchange submission or retry a write.
                    quote_reason = "QUOTE_GUARD_READ_FAILED:" + type(quote_exc).__name__
                else:
                    quote_reason = None if verdict.allowed else verdict.reason
                if quote_reason is not None:
                    self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_EXECUTABLE_QUOTE", error=quote_reason)
                    self.ledger.release_risk_reservation(s.signal_id, quote_reason)
                    self.ledger.record_event(
                        "ENTRY_BLOCKED_EXECUTABLE_QUOTE", signal_id=s.signal_id,
                        symbol=s.symbol, detail={"reason": quote_reason},
                    )
                    return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_EXECUTABLE_QUOTE", None,
                                           detail=quote_reason)
                # Account supervisor may go stale while the quote GET is in
                # flight; check that account reconciliation is still fresh.
                if self.config.require_account_readiness:
                    quote_ready, reasons = self.ledger.execution_readiness(
                        now_ms=time.time_ns() // 1_000_000,
                        max_reconciliation_age_ms=self.config.max_account_snapshot_age_ms,
                    )
                    if not quote_ready:
                        detail = "ACCOUNT_NOT_READY_AFTER_QUOTE:" + ",".join(reasons)
                        self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_ACCOUNT_NOT_READY", error=detail)
                        self.ledger.release_risk_reservation(s.signal_id, "ACCOUNT_NOT_READY_AFTER_QUOTE")
                        return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_ACCOUNT_NOT_READY", None,
                                               detail=detail)
                # The book can change between this GET and the next POST. It
                # only provides rejection evidence, not a fill-price guarantee.
                halted_before_post, halt_reason = self.ledger.entries_halted()
                if halted_before_post:
                    self.ledger.update_intent(s.signal_id, "ENTRY_BLOCKED_HALTED_BEFORE_POST",
                                              error=halt_reason)
                    self.ledger.release_risk_reservation(s.signal_id, "ENTRIES_HALTED_AFTER_QUOTE")
                    return ExecutionResult(s.signal_id, "ENTRY_BLOCKED_HALTED_BEFORE_POST", None,
                                           detail=halt_reason or "UNSPECIFIED")
            if ioc:
                self.ledger.update_intent(s.signal_id, "SUBMISSION_UNKNOWN")
            entry = self.client.new_order(**params)
            if ioc:
                executed, order_status = self._ioc_fill_state(entry, s.symbol, plan.client_order_id, plan.quantity)
            else:
                executed = Decimal(str(entry.get("executedQty", "0")))
                order_status = str(entry.get("status", "UNKNOWN")).upper()
            self.ledger.record_order(
                client_id=plan.client_order_id, signal_id=s.signal_id, symbol=s.symbol,
                role="ENTRY", order_kind="STANDARD", status=str(entry.get("status", "UNKNOWN")),
                exchange_order_id=entry.get("orderId"), payload=entry,
            )
            if executed > 0:
                if order_status != "FILLED" and not (ioc and order_status in _IOC_TERMINAL):
                    entry = self._cancel_unfilled_remainder(
                        s.symbol, plan.client_order_id, s.signal_id,
                        observed_quantity=executed, maximum_quantity=plan.quantity,
                    )
                    executed = Decimal(str(entry["executedQty"]))
                self.ledger.update_intent(s.signal_id, "ENTRY_PARTIALLY_OR_FULLY_FILLED")
                return self._complete_filled_entry(plan, position_side, executed, entry)
            if order_status in {"NEW", "PARTIALLY_FILLED"}:
                self.ledger.update_intent(s.signal_id, "ENTRY_PENDING")
                return ExecutionResult(s.signal_id, "ENTRY_PENDING", entry,
                                       detail="Protection will be attached as soon as reconciliation observes a fill")
            self.ledger.update_intent(s.signal_id, f"ENTRY_{order_status}")
            if ioc:
                self.ledger.release_risk_reservation(s.signal_id, f"IOC_TERMINAL_WITHOUT_FILL:{order_status}")
            return ExecutionResult(s.signal_id, f"ENTRY_{order_status}", entry)
        except Exception as exc:
            # A POST may have reached Binance despite a transport timeout. Never
            # issue a second order automatically; reconcile by client ID first.
            intent = self.ledger.get_intent(s.signal_id)
            if intent is None or intent["status"] != "PROTECTION_INCOMPLETE":
                self.ledger.update_intent(s.signal_id, "SUBMISSION_UNKNOWN", error=str(exc))
            self.ledger.set_entries_halted(True, f"Ambiguous/failed execution for {s.symbol}: {exc}")
            self.ledger.record_event("EXECUTION_HALTED", signal_id=s.signal_id, symbol=s.symbol,
                                     detail={"error": str(exc)})
            raise

    def _complete_filled_entry(self, plan: TradePlan, position_side: str,
                               quantity: Decimal, order: dict[str, Any]) -> ExecutionResult:
        signal = plan.signal
        try:
            stop, take = self._ensure_protection(plan, position_side, quantity=quantity)
        except _InitialIocStopRejected as exc:
            self.ledger.set_entries_halted(True, f"{IOC_INITIAL_STOP_REJECTED}:{signal.symbol}")
            self.ledger.update_intent(signal.signal_id, "PROTECTION_INCOMPLETE", error=IOC_INITIAL_STOP_REJECTED)
            self.ledger.record_event(IOC_INITIAL_STOP_REJECTED, signal_id=signal.signal_id,
                                     symbol=signal.symbol, detail={"error": str(exc)})
            return self._recover_rejected_ioc_stop(plan, position_side, quantity, order)

        self._record_managed_fill(plan, position_side, quantity, order)
        self._audit_confirmed_fill(plan, quantity=quantity, order=order)
        self.ledger.update_intent(signal.signal_id, "PROTECTED")
        return ExecutionResult(signal.signal_id, "PROTECTED", order, stop, take)

    def _record_managed_fill(self, plan: TradePlan, position_side: str,
                             quantity: Decimal, order: Mapping[str, Any]) -> None:
        signal = plan.signal
        entry_price = self._local_entry_price(order, plan)
        self.ledger.record_position(
            symbol=signal.symbol, position_side=position_side, signal_id=signal.signal_id,
            quantity=str(quantity), entry_price=str(entry_price),
            stop_loss=str(signal.stop_loss), take_profit=str(signal.take_profit),
        )
        self._initialize_position_management_state(plan, quantity=quantity, entry_price=entry_price)

    def _recover_rejected_ioc_stop(self, plan: TradePlan, position_side: str,
                                   quantity: Decimal, order: dict[str, Any]) -> ExecutionResult:
        """Contain one verified one-way IOC lot with one durable reduce-only close."""
        assert self.client is not None
        signal = plan.signal
        opened, status = self._ioc_fill_state(order, signal.symbol, plan.client_order_id, plan.quantity)
        if status not in _IOC_TERMINAL or opened != quantity or opened <= 0 or position_side != "BOTH":
            return ExecutionResult(signal.signal_id, "PROTECTION_INCOMPLETE", order,
                                   detail="IOC_EMERGENCY_CLOSE_OWNERSHIP_UNVERIFIED")
        adapter = PositionLifecycleExecutionAdapter(
            client=self.client, ledger=self.ledger, working_type=self.config.working_type,
            price_protect=self.config.price_protect,
            max_account_snapshot_age_ms=self.config.max_account_snapshot_age_ms,
        )
        action_id = self.ledger.deterministic_client_id(signal.signal_id, IOC_INITIAL_STOP_REJECTED)
        existing = self.ledger.get_position_management_action(action_id)
        if existing is None:
            # A terminal entry confirms the fill but positionRisk may still
            # be stale. Never project/close a lot until both sources agree.
            rows = self.client.get_position_risk(signal.symbol)
            expected = quantity if signal.side == "LONG" else -quantity
            matches = [row for row in rows if row.get("symbol") == signal.symbol
                       and row.get("positionSide") == "BOTH"]
            if len(matches) != 1 or Decimal(str(matches[0].get("positionAmt"))) != expected:
                return ExecutionResult(signal.signal_id, "PROTECTION_INCOMPLETE", order,
                                       detail="IOC_EMERGENCY_CLOSE_POSITION_NOT_CONFIRMED")
            info = parse_exchange_info(self.client.get_exchange_info(), source_endpoint="exchangeInfo")
            instrument = info.get_symbol(signal.symbol)
            market = instrument.market_lot_size if instrument is not None else None
            if (market is None or market.step_size is None or market.min_qty is None or market.max_qty is None
                    or not market.min_qty <= quantity <= market.max_qty):
                return ExecutionResult(signal.signal_id, "PROTECTION_INCOMPLETE", order,
                                       detail="IOC_EMERGENCY_CLOSE_FILTERS_UNAVAILABLE")
            self._record_managed_fill(plan, position_side, quantity, order)
            state = adapter.load_state(signal.signal_id)
            action = LifecycleAction(
                action_id=action_id, kind="EMERGENCY_CLOSE", signal_id=signal.signal_id,
                symbol=signal.symbol, side=signal.side, reason=IOC_INITIAL_STOP_REJECTED,
            )
            adapter.submit_market_exit(action, state, market_step_size=market.step_size,
                                       market_min_qty=market.min_qty, from_rejected_ioc_stop=True)
        elif existing["status"] in {"EXIT_TERMINAL_NO_FILL", "PARTIAL_EXIT_REMAINS", "SUBMISSION_FAILED"}:
            return ExecutionResult(signal.signal_id, "PROTECTION_INCOMPLETE", order,
                                   detail=f"IOC_EMERGENCY_CLOSE:{existing['status']}")
        confirmed = adapter.confirm_market_exit(action_id)
        recovery_status = confirmed["status"]
        return ExecutionResult(signal.signal_id,
                               "IOC_EMERGENCY_CLOSED" if recovery_status == "CLOSED_CONFIRMED" else "PROTECTION_INCOMPLETE",
                               order, detail=f"IOC_EMERGENCY_CLOSE:{recovery_status}")

    @staticmethod
    def _ioc_fill_state(order: Mapping[str, Any], symbol: str, client_id: str,
                        quantity: Decimal) -> tuple[Decimal, str]:
        if (not isinstance(order, Mapping) or order.get("symbol") != symbol
                or order.get("clientOrderId") != client_id or order.get("type", "LIMIT") != "LIMIT"
                or order.get("timeInForce", "IOC") != "IOC"):
            raise RuntimeError("IOC_RESULT_ORDER_IDENTITY_MISMATCH")
        status = str(order.get("status", "")).upper()
        try:
            executed = Decimal(str(order.get("executedQty")))
        except InvalidOperation as exc:
            raise RuntimeError("IOC_RESULT_FILL_STATE_INVALID") from exc
        if (status not in {*_IOC_TERMINAL, "NEW", "PARTIALLY_FILLED"}
                or not executed.is_finite() or not 0 <= executed <= quantity
                or (status == "FILLED" and executed != quantity)
                or (status == "REJECTED" and executed != 0)):
            raise RuntimeError("IOC_RESULT_FILL_STATE_INVALID")
        return executed, status

    def _cancel_unfilled_remainder(
        self, symbol: str, client_order_id: str, signal_id: str, *,
        observed_quantity: Decimal, maximum_quantity: Decimal,
    ) -> dict[str, Any]:
        """Return terminal exchange truth, including fills that raced cancellation."""
        assert self.client is not None
        try:
            self.client.cancel_order(symbol, client_order_id=client_order_id)
        except BinancePrivateApiError as exc:
            if exc.code not in {-2011, -2013}:
                raise
        # A cancel acknowledgement is not the fill authority. Query the original
        # deterministic ID even if cancel raced a full fill or a prior cancellation.
        response = self.client.get_order(symbol, client_order_id=client_order_id)
        if (response.get("symbol") != symbol
                or response.get("clientOrderId") != client_order_id):
            raise RuntimeError("ENTRY_CANCEL_ORDER_IDENTITY_MISMATCH")
        if str(response.get("status", "")).upper() not in {
            "FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED",
        }:
            raise RuntimeError("ENTRY_REMAINDER_NOT_CONFIRMED_TERMINAL")
        quantity = Decimal(str(response.get("executedQty", "NaN")))
        average = Decimal(str(response.get("avgPrice", "NaN")))
        if (not quantity.is_finite() or not observed_quantity <= quantity <= maximum_quantity
                or not average.is_finite() or average <= 0):
            raise RuntimeError("ENTRY_CANCEL_FILL_STATE_INVALID")
        self.ledger.record_order(
            client_id=client_order_id, signal_id=signal_id, symbol=symbol, role="ENTRY",
            order_kind="STANDARD", status=str(response.get("status", "CANCEL_REQUESTED")),
            exchange_order_id=response.get("orderId"), payload=response,
        )
        self.ledger.record_event("ENTRY_REMAINDER_CANCELLED", signal_id=signal_id,
                                 symbol=symbol, detail={"status": response.get("status")})
        return response

    def _ensure_protection(self, plan: TradePlan, position_side: str, *, quantity: Decimal) -> tuple[dict[str, Any], dict[str, Any]]:
        """Query-first, exchange-verified STOP/TP attachment for an observed fill.

        A local ledger record is not proof that an Algo order remains active. Every
        role is queried by deterministic clientAlgoId and the exchange response is
        checked against the exact symbol, client ID, type, side, positionSide,
        quantity and trigger price. Existing-but-missing or mismatched protection
        halts entries; it is never blindly reposted or treated as protected.
        """
        assert self.client is not None
        s = plan.signal
        quantity = Decimal(str(quantity))
        if not quantity.is_finite() or quantity <= 0:
            raise ValueError("protection quantity must be finite and positive")
        mode = self.client.get_position_mode()
        if not isinstance(mode, dict) or "dualSidePosition" not in mode:
            raise RuntimeError("Unable to determine Binance position mode for protection")
        dual_side = mode["dualSidePosition"] is True or str(mode["dualSidePosition"]).strip().lower() in {"true", "1"}
        expected_position_side = self._position_side(s.side, dual_side)
        if str(position_side).upper() != expected_position_side:
            raise RuntimeError("POSITION_MODE_CHANGED_BEFORE_PROTECTION")
        ids = {
            "STOP_LOSS": self.ledger.deterministic_client_id(s.signal_id, "STOP_LOSS"),
            "TAKE_PROFIT": self.ledger.deterministic_client_id(s.signal_id, "TAKE_PROFIT"),
        }
        responses: dict[str, dict[str, Any]] = {}
        for role, order_type, trigger in (
            ("STOP_LOSS", "STOP_MARKET", s.stop_loss),
            ("TAKE_PROFIT", "TAKE_PROFIT_MARKET", s.take_profit),
        ):
            had_local_record = self.ledger.has_order_role(s.signal_id, role)
            try:
                found = self.client.get_algo_order(client_algo_id=ids[role])
            except BinancePrivateApiError as exc:
                if exc.code != -2013:
                    raise
                if had_local_record:
                    reason = f"PROTECTION_ORDER_MISSING:{s.symbol}:{role}:{ids[role]}"
                    self.ledger.set_entries_halted(True, reason)
                    self.ledger.record_event(
                        "PROTECTION_ORDER_MISSING", signal_id=s.signal_id, symbol=s.symbol,
                        detail={"role": role, "client_algo_id": ids[role],
                                "recovery": "BLOCKED_NO_BLIND_REPOST"},
                    )
                    raise RuntimeError("PROTECTION_ORDER_MISSING_REQUIRES_POSITION_RECONCILIATION") from exc
                found = None

            if found is None:
                params = build_quantity_scoped_protection_params(
                    symbol=s.symbol, position_direction=s.side,
                    position_side=position_side, dual_side_position=dual_side,
                    order_type=order_type, quantity=quantity, trigger_price=trigger,
                    working_type=self.config.working_type,
                    price_protect=self.config.price_protect,
                    client_algo_id=ids[role],
                )
                # The POST response is only an acknowledgement. A fresh GET by the
                # deterministic ID is required before this order can protect a lot.
                if s.entry_type == "LIMIT_IOC":
                    self.ledger.record_order(
                        client_id=ids[role], signal_id=s.signal_id, symbol=s.symbol, role=role,
                        order_kind="ALGO", status="SUBMISSION_UNKNOWN", exchange_order_id=None,
                        payload=params,
                    )
                try:
                    self.client.new_algo_order(**params)
                except BinancePrivateApiError as exc:
                    if (s.entry_type == "LIMIT_IOC" and role == "STOP_LOSS" and exc.status_code == 400
                            and exc.code in _DEFINITIVE_STOP_REJECTION_CODES):
                        raise _InitialIocStopRejected(str(exc)) from exc
                    raise
                try:
                    found = self.client.get_algo_order(client_algo_id=ids[role])
                except Exception as exc:
                    self.ledger.set_entries_halted(
                        True, f"PROTECTION_ORDER_POST_UNVERIFIED:{s.symbol}:{role}"
                    )
                    self.ledger.record_event(
                        "PROTECTION_ORDER_POST_UNVERIFIED", signal_id=s.signal_id,
                        symbol=s.symbol,
                        detail={"role": role, "client_algo_id": ids[role],
                                "error_type": type(exc).__name__},
                    )
                    raise RuntimeError("PROTECTION_ORDER_POST_UNVERIFIED") from exc

            expected_type = order_type
            expected_side = "SELL" if s.side == "LONG" else "BUY"
            is_legacy = is_legacy_close_position_order_valid(
                found,
                expected_position_side=position_side,
                expected_order_side=expected_side,
                expected_type=expected_type,
                expected_symbol=s.symbol,
                expected_client_algo_id=ids[role],
                expected_trigger_price=trigger,
            )
            is_scoped = is_quantity_scoped_order_valid(
                found,
                expected_quantity=quantity,
                dual_side_position=dual_side,
                expected_position_side=position_side,
                expected_order_side=expected_side,
                expected_type=expected_type,
                expected_symbol=s.symbol,
                expected_client_algo_id=ids[role],
                expected_trigger_price=trigger,
            )
            if not (is_legacy or is_scoped):
                reason = f"PROTECTION_ORDER_MISMATCH:{s.symbol}:{role}"
                self.ledger.set_entries_halted(True, reason)
                self.ledger.record_event(
                    "PROTECTION_ORDER_MISMATCH", signal_id=s.signal_id, symbol=s.symbol,
                    detail={"role": role, "client_algo_id": ids[role],
                            "expected_quantity": str(quantity),
                            "expected_trigger_price": str(trigger)},
                )
                raise RuntimeError(f"PROTECTION_ORDER_MISMATCH:{role}")
            self.ledger.record_order(
                client_id=ids[role], signal_id=s.signal_id, symbol=s.symbol, role=role,
                order_kind="ALGO", status=str(found.get("algoStatus", "UNKNOWN")),
                exchange_order_id=found.get("algoId"), payload=found,
            )
            responses[role] = found
        return responses["STOP_LOSS"], responses["TAKE_PROFIT"]

    def reconcile_pending_entries(self) -> list[ExecutionResult]:
        """Resolve pending/ambiguous entries by client order ID; never blindly resubmit."""
        with self._ioc_lock:
            return self._reconcile_pending_entries()

    def _reconcile_pending_entries(self) -> list[ExecutionResult]:
        if self.client is None:
            return []
        self.client.sync_server_time()
        results: list[ExecutionResult] = []
        pending = self.ledger.list_intents(("ENTRY_PENDING", "SUBMISSION_UNKNOWN", "ENTRY_PARTIALLY_OR_FULLY_FILLED",
                                            "PROTECTION_INCOMPLETE"))
        for row in pending:
            payload = json.loads(row["payload_json"])
            signal = payload["signal"]
            client_order_id = row["client_order_id"]
            ioc = signal["entry_type"] == "LIMIT_IOC"
            recovering_stop = ioc and row["last_error"] == IOC_INITIAL_STOP_REJECTED
            if row["status"] == "PROTECTION_INCOMPLETE" and not recovering_stop:
                continue
            try:
                order = self.client.get_order(row["symbol"], client_order_id=client_order_id)
                if ioc:
                    executed, order_status = self._ioc_fill_state(
                        order, row["symbol"], client_order_id, Decimal(payload["quantity"]),
                    )
                    if recovering_stop and (executed <= 0 or order_status not in _IOC_TERMINAL):
                        raise RuntimeError("IOC_STOP_RECOVERY_REQUIRES_CONFIRMED_TERMINAL_FILL")
                    self.ledger.record_order(
                        client_id=client_order_id, signal_id=row["signal_id"], symbol=row["symbol"],
                        role="ENTRY", order_kind="STANDARD", status=order_status,
                        exchange_order_id=order.get("orderId"), payload=order,
                    )
                else:
                    executed = Decimal(str(order.get("executedQty", "0")))
                    order_status = str(order.get("status", "")).upper()
                if executed > 0:
                    if order_status != "FILLED" and not (ioc and order_status in _IOC_TERMINAL):
                        order = self._cancel_unfilled_remainder(
                            row["symbol"], client_order_id, row["signal_id"],
                            observed_quantity=executed,
                            maximum_quantity=Decimal(payload["quantity"]),
                        )
                        executed = Decimal(str(order["executedQty"]))
                    dual_value = self.client.get_position_mode().get("dualSidePosition", False)
                    dual = dual_value is True or str(dual_value).strip().lower() == "true"
                    pos_side = self._position_side(signal["side"], dual)
                    # Rehydrate only the exact trade contract needed for protection.
                    from divatrading.trading.models import QualifiedSignal, TradePlan
                    s = QualifiedSignal(
                        signal_id=signal["signal_id"], symbol=signal["symbol"], side=signal["side"],
                        entry_type=signal["entry_type"], entry_price=Decimal(signal["entry_price"]),
                        stop_loss=Decimal(signal["stop_loss"]), take_profit=Decimal(signal["take_profit"]),
                        timeframe=signal["timeframe"], strategy_id=signal["strategy_id"],
                        created_at_ms=int(signal["created_at_ms"]), reason_codes=tuple(signal.get("reason_codes", ())),
                        minimum_net_rr=(Decimal(signal["minimum_net_rr"])
                                        if "minimum_net_rr" in signal else None),
                    )
                    plan = TradePlan(
                        s, Decimal(payload["quantity"]), Decimal(payload["notional_usdt"]),
                        Decimal(payload["risk_usdt"]), Decimal(payload["margin_estimate_usdt"]),
                        int(payload["leverage"]), client_order_id,
                        margin_mode=str(payload.get("margin_mode", "ISOLATED")),
                        fee_reserve_usdt=Decimal(payload.get("fee_reserve_usdt", "0")),
                        slippage_reserve_usdt=Decimal(payload.get("slippage_reserve_usdt", "0")),
                        funding_reserve_usdt=Decimal(payload.get("funding_reserve_usdt", "0")),
                        maintenance_margin_estimate_usdt=Decimal(
                            payload.get("maintenance_margin_estimate_usdt", "0")
                        ),
                    )
                    if recovering_stop:
                        results.append(self._recover_rejected_ioc_stop(plan, pos_side, executed, order))
                    else:
                        results.append(self._complete_filled_entry(plan, pos_side, executed, order))
                elif order_status in (_IOC_ZERO_FILL_TERMINAL if ioc else {"CANCELED", "REJECTED", "EXPIRED"}):
                    self.ledger.update_intent(row["signal_id"], f"ENTRY_{order_status}")
                    if ioc:
                        self.ledger.release_risk_reservation(row["signal_id"], f"IOC_TERMINAL_WITHOUT_FILL:{order_status}")
                    results.append(ExecutionResult(row["signal_id"], f"ENTRY_{order_status}", order))
            except Exception as exc:
                self.ledger.set_entries_halted(True, f"Unable to reconcile {row['symbol']} {client_order_id}: {exc}")
                self.ledger.record_event("RECONCILIATION_FAILED", signal_id=row["signal_id"],
                                         symbol=row["symbol"], detail={"error": str(exc)})
                raise
        return results

    def halt_new_entries(self, reason: str = "Operator emergency stop") -> None:
        """Stop new entries but intentionally preserve protective SL/TP algo orders."""
        self.ledger.set_entries_halted(True, reason)
        self.ledger.record_event("OPERATOR_KILL_SWITCH", detail={"reason": reason})

    def resume_new_entries(self, *, explicit_operator_confirmation: bool = False) -> None:
        if not explicit_operator_confirmation:
            raise PermissionError("Resuming entries requires explicit operator confirmation")
        unresolved = self.ledger.list_intents((
            "SUBMISSION_UNKNOWN", "PROTECTION_INCOMPLETE",
            "ENTRY_PARTIALLY_OR_FULLY_FILLED",
        ))
        if unresolved:
            raise RuntimeError("Cannot resume while unresolved or unprotected execution intents exist")
        halted, reason = self.ledger.entries_halted()
        if halted and reason and reason.startswith("POST_FILL_RISK:"):
            if self.ledger.list_managed_positions(status="OPEN"):
                raise RuntimeError("Cannot resume while post-fill risk breach position remains open")
        if self.config.mode != ExecutionMode.PAPER:
            # The halt itself is excluded from readiness; account state and
            # stream must otherwise be current and mutually reconciled.
            _, reasons = self.ledger.execution_readiness(
                now_ms=time.time_ns() // 1_000_000,
                max_reconciliation_age_ms=self.config.max_account_snapshot_age_ms,
            )
            blockers = [r for r in reasons if not r.startswith("ENTRIES_HALTED:")]
            if blockers:
                raise RuntimeError("ACCOUNT_NOT_READY_FOR_RESUME:" + ",".join(blockers))
        self.ledger.set_entries_halted(False)
        self.ledger.record_event("OPERATOR_RESUMED_ENTRIES")

    def sync_income_history(self, *, start_time_ms: int | None = None, end_time_ms: int | None = None) -> int:
        if self.client is None:
            return 0
        rows = self.client.get_income_history(start_time_ms=start_time_ms, end_time_ms=end_time_ms, limit=1000)
        return self.ledger.store_income_rows(rows)
