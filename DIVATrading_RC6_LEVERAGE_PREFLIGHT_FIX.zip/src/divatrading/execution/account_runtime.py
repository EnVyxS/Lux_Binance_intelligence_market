"""Co-runs the private account stream and periodic exchange reconciliation."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from .reconciliation import AccountReconciliationService, ReconciliationReport
from .user_data_stream import BinanceUserDataStreamSupervisor


@dataclass(frozen=True, slots=True)
class AccountRuntimeConfig:
    reconciliation_interval_seconds: float = 10.0
    disconnected_poll_seconds: float = 0.5

    def __post_init__(self) -> None:
        if self.reconciliation_interval_seconds <= 0 or self.disconnected_poll_seconds <= 0:
            raise ValueError("account runtime intervals must be positive")


class ExecutionAccountRuntime:
    """Account lifecycle supervisor required before TESTNET/LIVE order routing.

    It starts the stream first, then reconciles at a bounded cadence. If wired with an
    ExecutionService, reconciliation may recover a confirmed partial/full fill by
    cancelling its unfilled remainder and attaching missing protective SL/TP orders.
    Optional Stage D2 protection recovery is explicit TESTNET/LIVE opt-in, and
    handles only fresh, exact, terminal no-fill protection gaps. Triggered or ambiguous
    Algo orders remain with the fill reducer/reconciliation path and are never reposted.
    The stream's connection state and a fresh event-consistent reconciliation are both
    required by ExecutionService's account-readiness gate.
    """
    def __init__(self, *, user_stream: BinanceUserDataStreamSupervisor,
                 reconciler: AccountReconciliationService,
                 ledger: Any, config: AccountRuntimeConfig | None = None,
                 lifecycle_fill_reducer: Any | None = None,
                 position_supervisor: Any | None = None,
                 enable_protection_recovery: bool = False) -> None:
        self.user_stream = user_stream
        self.reconciler = reconciler
        self.ledger = ledger
        self.config = config or AccountRuntimeConfig()
        self.lifecycle_fill_reducer = lifecycle_fill_reducer
        self.position_supervisor = position_supervisor
        if not isinstance(enable_protection_recovery, bool):
            raise ValueError("enable_protection_recovery must be boolean")
        self.enable_protection_recovery = enable_protection_recovery
        if lifecycle_fill_reducer is not None:
            # D2/D3 recovery mutations are gated behind the explicit
            # DIVA_ENABLE_PROTECTION_RECOVERY opt-in. Ordinary confirmed fill
            # resizing remains part of the managed-position lifecycle.
            if hasattr(lifecycle_fill_reducer, "enable_zero_fill_reprotection"):
                lifecycle_fill_reducer.enable_zero_fill_reprotection = enable_protection_recovery
                if hasattr(lifecycle_fill_reducer, "adapter"):
                    lifecycle_fill_reducer.adapter.enable_zero_fill_reprotection = enable_protection_recovery
            previous_handler = self.user_stream.on_event

            async def dispatch_account_event(event: Any) -> None:
                failures: list[str] = []
                if previous_handler is not None:
                    try:
                        prior_result = previous_handler(event)
                        if asyncio.iscoroutine(prior_result) or hasattr(prior_result, "__await__"):
                            await prior_result
                    except Exception as exc:
                        failures.append(f"prior_handler:{type(exc).__name__}:{exc}")
                # REST reconciliation and lifecycle mutations are blocking I/O. Keep
                # them off the WebSocket receive loop so stream keepalive remains live.
                try:
                    await asyncio.to_thread(lifecycle_fill_reducer.handle, event)
                except Exception as exc:
                    failures.append(f"lifecycle_reducer:{type(exc).__name__}:{exc}")
                if failures:
                    reason = " | ".join(failures)[:500]
                    self.ledger.set_entries_halted(True, f"Account event reducer failure: {reason}")
                    self.ledger.record_event("ACCOUNT_EVENT_REDUCER_FAILED",
                                             detail={"event_type": getattr(event, "event_type", "UNKNOWN"),
                                                     "reason": reason})

            self.user_stream.on_event = dispatch_account_event
        self.last_report: ReconciliationReport | None = None

    async def run(self, stop_event: asyncio.Event) -> None:
        stream_stop = asyncio.Event()
        stream_task = asyncio.create_task(self.user_stream.run(stream_stop), name="diva:user-data-stream")
        supervisor_stop = asyncio.Event()
        supervisor_task = (
            asyncio.create_task(self.position_supervisor.run(supervisor_stop),
                                name="diva:managed-position-supervisor")
            if self.position_supervisor is not None else None
        )
        last_lifecycle_recovery_connection_ms: int | None = None
        last_trade_backfill_connection_ms: int | None = None
        last_protection_recovery_snapshot_key: tuple[int, int] | None = None
        try:
            while not stop_event.is_set():
                if supervisor_task is not None and supervisor_task.done():
                    error = supervisor_task.exception()
                    if error is not None:
                        self.ledger.set_entries_halted(True, f"Managed-position supervisor terminated: {error}"[:500])
                        raise RuntimeError("Managed-position supervisor terminated") from error
                    if not stop_event.is_set():
                        self.ledger.set_entries_halted(True, "Managed-position supervisor stopped unexpectedly")
                        raise RuntimeError("Managed-position supervisor stopped unexpectedly")
                if stream_task.done():
                    error = stream_task.exception()
                    if error is not None:
                        raise RuntimeError("Binance User Data Stream supervisor terminated") from error
                    if not stop_event.is_set():
                        raise RuntimeError("Binance User Data Stream supervisor stopped unexpectedly")
                state = self.ledger.get_user_stream_state()
                if state.get("status") == "CONNECTED":
                    connected_at_ms = state.get("connected_at_ms")
                    if (connected_at_ms is not None
                            and connected_at_ms != last_trade_backfill_connection_ms):
                        # Force userTrades recovery on every private-stream connection.
                        # The reconciler's normal interval must not leave a stream-gap
                        # blind spot when the socket reconnects shortly after a prior
                        # periodic backfill. Reconciliation performs this before its
                        # exchange account snapshot and keeps entries halted on failure.
                        request_trade_backfill = getattr(
                            self.reconciler, "request_trade_backfill", None
                        )
                        if callable(request_trade_backfill):
                            request_trade_backfill()
                        last_trade_backfill_connection_ms = connected_at_ms
                    if (self.lifecycle_fill_reducer is not None and connected_at_ms is not None
                            and connected_at_ms != last_lifecycle_recovery_connection_ms):
                        try:
                            await asyncio.to_thread(
                                self.lifecycle_fill_reducer.adapter.recover_on_startup
                            )
                            # REST backfill catches a triggered Algo whose ALGO_UPDATE
                            # was lost during a private-stream disconnect. It is
                            # read/query-first and routes any trigger through the same
                            # durable fill reducer used for live stream events.
                            trigger_backfill = getattr(
                                self.lifecycle_fill_reducer,
                                "recover_triggered_protections_from_rest",
                                None,
                            )
                            if callable(trigger_backfill):
                                await asyncio.to_thread(trigger_backfill)
                        except Exception as exc:
                            reason = f"Lifecycle startup recovery failed: {type(exc).__name__}: {exc}"[:500]
                            self.ledger.set_entries_halted(True, reason)
                            self.ledger.record_event("LIFECYCLE_STARTUP_RECOVERY_FAILED",
                                                     detail={"reason": reason})
                        finally:
                            # Do not hammer the exchange every polling interval. A new
                            # listenKey/WebSocket connection triggers the next recovery.
                            last_lifecycle_recovery_connection_ms = connected_at_ms
                    self.last_report = await asyncio.to_thread(self.reconciler.reconcile)
                    if (self.enable_protection_recovery and self.lifecycle_fill_reducer is not None
                            and self.last_report.status == "BLOCKED_MISMATCH"):
                        current_snapshot_key = (
                            int(state.get("last_event_at_ms") or 0),
                            int(self.last_report.captured_at_ms),
                        )
                        if current_snapshot_key != last_protection_recovery_snapshot_key:
                            last_protection_recovery_snapshot_key = current_snapshot_key
                            try:
                                recovery_results = await asyncio.to_thread(
                                    self.lifecycle_fill_reducer.adapter.recover_missing_protections
                                )
                            except Exception as exc:
                                self.ledger.set_entries_halted(
                                    True, f"Protective recovery sweep failed: {type(exc).__name__}:{exc}"[:500]
                                )
                                self.ledger.record_event(
                                    "PROTECTIVE_RECOVERY_SWEEP_FAILED",
                                    detail={"error_type": type(exc).__name__},
                                )
                            else:
                                if any(item.get("status") in {"CONFIRMED", "POSITION_FLAT_FINALIZED"}
                                       for item in recovery_results if isinstance(item, dict)):
                                    # A fresh second snapshot must prove coverage before the
                                    # account runtime can consider new-entry readiness again.
                                    self.last_report = await asyncio.to_thread(self.reconciler.reconcile)
                    delay = self.config.reconciliation_interval_seconds
                else:
                    delay = self.config.disconnected_poll_seconds
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    pass
        finally:
            supervisor_stop.set()
            if self.position_supervisor is not None:
                try:
                    await self.position_supervisor.stop()
                except Exception:
                    pass
            if supervisor_task is not None:
                try:
                    await supervisor_task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass
            stream_stop.set()
            try:
                await stream_task
            except asyncio.CancelledError:
                pass
