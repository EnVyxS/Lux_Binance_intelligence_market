"""Bounded REST recovery for Binance USD-M account trade history."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from .ledger import ExecutionLedger

SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000
THREE_MONTHS_MS = 90 * 24 * 60 * 60 * 1000


@dataclass(frozen=True, slots=True)
class TradeBackfillResult:
    symbol: str
    run_id: str
    pages: int
    received_trades: int
    inserted_trades: int
    max_trade_id: int
    max_trade_time_ms: int
    watermark: dict[str, Any]


class BinanceUserTradesBackfillService:
    """Merge private REST userTrades into the immutable fill ledger.

    Initial recovery uses inclusive time windows no wider than seven days. A full
    page is recursively split so no record is silently skipped at the 1000-row cap.
    Subsequent recovery uses fromId only (Binance forbids mixing it with time bounds).
    Watermarks advance only after every fetched page has been durably merged.
    """
    def __init__(self, *, client: Any, ledger: ExecutionLedger,
                 clock_ms: Callable[[], int] | None = None,
                 sleep: Callable[[float], None] = time.sleep,
                 request_pause_seconds: float = 0.15,
                 max_requests_per_run: int = 2000, page_limit: int = 1000) -> None:
        if not 0 <= request_pause_seconds <= 5:
            raise ValueError("request_pause_seconds must be between 0 and 5")
        if not 1 <= max_requests_per_run <= 10000:
            raise ValueError("max_requests_per_run must be between 1 and 10000")
        if not 1 <= page_limit <= 1000:
            raise ValueError("page_limit must be between 1 and 1000")
        self.client = client; self.ledger = ledger
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self.sleep = sleep; self.request_pause_seconds = request_pause_seconds
        self.max_requests_per_run = max_requests_per_run; self.page_limit = page_limit
        self._requests = 0

    def _fetch(self, symbol: str, **params: Any) -> list[dict[str, Any]]:
        self._requests += 1
        if self._requests > self.max_requests_per_run:
            raise RuntimeError("TRADE_BACKFILL_REQUEST_BUDGET_EXCEEDED")
        if self.request_pause_seconds:
            self.sleep(self.request_pause_seconds)
        rows = self.client.get_user_trades(symbol, limit=self.page_limit, **params)
        if rows != sorted(rows, key=lambda row: int(row.get("id", -1))):
            rows = sorted(rows, key=lambda row: int(row.get("id", -1)))
        return rows

    def backfill_symbol(self, symbol: str, *, start_time_ms: int | None = None,
                        end_time_ms: int | None = None) -> TradeBackfillResult:
        normalized = symbol.strip().upper()
        if not normalized or not normalized.isalnum():
            raise ValueError("symbol must be a non-empty alphanumeric Binance symbol")
        now = self.clock_ms()
        end = now if end_time_ms is None else end_time_ms
        if isinstance(end, bool) or not isinstance(end, int) or end <= 0 or end > now + 60_000:
            raise ValueError("end_time_ms must be a positive timestamp no more than 60 seconds in the future")
        watermark = self.ledger.get_trade_backfill_watermark(normalized)
        use_cursor = watermark is not None and start_time_ms is None
        if use_cursor:
            start = int(watermark["last_trade_time_ms"] or max(0, end - SEVEN_DAYS_MS))
        else:
            start = (max(0, end - THREE_MONTHS_MS) if start_time_ms is None else start_time_ms)
        if isinstance(start, bool) or not isinstance(start, int) or start < 0 or start > end:
            raise ValueError("start_time_ms must be a valid timestamp before end_time_ms")
        if end - start > THREE_MONTHS_MS:
            raise ValueError("userTrades REST recovery is limited to approximately three months by current Binance retention")
        run_id = f"TB{uuid.uuid4().hex[:24].upper()}"
        self._requests = 0; received = 0; inserted = 0; max_id = -1; max_time = 0
        self.ledger.begin_trade_backfill_run(run_id=run_id, symbol=normalized,
                                             range_start_ms=start, range_end_ms=end)
        try:
            if use_cursor:
                next_id = int(watermark["last_trade_id"]) + 1
                while True:
                    page = self._fetch(normalized, from_id=next_id)
                    if not page:
                        break
                    page_result = self.ledger.record_rest_user_trades_page(
                        run_id=run_id, symbol=normalized, trades=page)
                    received += len(page); inserted += page_result["inserted"]
                    max_id = max(max_id, page_result["max_trade_id"]); max_time = max(max_time, page_result["max_trade_time_ms"])
                    page_max = max(int(row["id"]) for row in page)
                    if page_max < next_id:
                        raise RuntimeError("TRADE_BACKFILL_CURSOR_DID_NOT_ADVANCE")
                    next_id = page_max + 1
                    if len(page) < self.page_limit:
                        break
            else:
                def fetch_window(window_start: int, window_end: int, depth: int = 0) -> None:
                    nonlocal received, inserted, max_id, max_time
                    page = self._fetch(normalized, start_time_ms=window_start, end_time_ms=window_end)
                    if len(page) >= self.page_limit:
                        if window_end <= window_start or depth >= 32:
                            raise RuntimeError("TRADE_BACKFILL_DENSE_MILLISECOND_WINDOW_EXCEEDS_PAGE_LIMIT")
                        midpoint = (window_start + window_end) // 2
                        fetch_window(window_start, midpoint, depth + 1)
                        fetch_window(midpoint + 1, window_end, depth + 1)
                        return
                    page_result = self.ledger.record_rest_user_trades_page(
                        run_id=run_id, symbol=normalized, trades=page)
                    received += len(page); inserted += page_result["inserted"]
                    max_id = max(max_id, page_result["max_trade_id"]); max_time = max(max_time, page_result["max_trade_time_ms"])
                cursor = start
                while cursor <= end:
                    window_end = min(end, cursor + SEVEN_DAYS_MS - 1)
                    fetch_window(cursor, window_end)
                    cursor = window_end + 1
            completed = self.ledger.complete_trade_backfill_run(run_id=run_id)
            return TradeBackfillResult(normalized, run_id, self._requests, received, inserted,
                                       max_id, max_time, completed)
        except Exception as exc:
            self.ledger.fail_trade_backfill_run(run_id=run_id, error=f"{type(exc).__name__}: {exc}")
            raise
