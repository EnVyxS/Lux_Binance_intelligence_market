"""Signed Binance USDⓈ-M Futures REST transport.

Trade requests are deliberately never retried automatically: a timeout after a
POST has an ambiguous outcome and must be reconciled using the client order ID.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import time
from decimal import Decimal
from typing import Any, Callable, Mapping
from urllib.parse import urlencode

import httpx


LIVE_BASE_URL = "https://fapi.binance.com"
TESTNET_BASE_URL = "https://demo-fapi.binance.com"
LIVE_USER_STREAM_BASE_URL = "wss://fstream.binance.com/private"
TESTNET_USER_STREAM_BASE_URL = "wss://demo-fstream.binance.com/private"


class BinancePrivateApiError(RuntimeError):
    def __init__(self, status_code: int, code: int | None, message: str, endpoint: str) -> None:
        self.status_code = status_code
        self.code = code
        self.endpoint = endpoint
        super().__init__(f"Binance private API error HTTP {status_code} code={code}: {message[:400]}")


class BinancePrivateTransportError(RuntimeError):
    """Transport failure; POST outcome may be unknown and must be reconciled."""


class BinancePrivateMetadataError(BinancePrivateTransportError):
    """Invalid symbol metadata response with a safe diagnostic code."""


def _symbol_metadata_rows(payload: Any, symbol: str | None, error_code: str) -> list[dict[str, Any]]:
    if isinstance(payload, dict) and symbol is not None and isinstance(payload.get("symbol"), str):
        return [payload]
    if not isinstance(payload, list) or any(not isinstance(row, dict) for row in payload):
        raise BinancePrivateMetadataError(error_code)
    return payload


class BinancePrivateRestClient:
    """Minimal signed Futures REST client with explicit TESTNET/LIVE base URL."""
    def __init__(
        self,
        api_key: str,
        api_secret: str,
        *,
        environment: str = "TESTNET",
        base_url: str | None = None,
        recv_window_ms: int = 5000,
        timeout_seconds: float = 8.0,
        http_client: httpx.Client | None = None,
        wall_clock_ms: Callable[[], int] | None = None,
    ) -> None:
        if not api_key or not api_secret:
            raise ValueError("Binance API key and secret are required")
        environment = environment.strip().upper()
        if environment not in {"TESTNET", "LIVE"}:
            raise ValueError("environment must be TESTNET or LIVE")
        if isinstance(recv_window_ms, bool) or not 1000 <= recv_window_ms <= 60000:
            raise ValueError("recv_window_ms must be between 1000 and 60000")
        self.api_key = api_key
        self._secret = api_secret.encode("utf-8")
        self.environment = environment
        self.base_url = (base_url or (TESTNET_BASE_URL if environment == "TESTNET" else LIVE_BASE_URL)).rstrip("/")
        expected = TESTNET_BASE_URL if environment == "TESTNET" else LIVE_BASE_URL
        if base_url is not None and self.base_url != expected:
            raise ValueError(f"{environment} must use the approved Binance base URL {expected}")
        self.recv_window_ms = recv_window_ms
        self._now_ms = wall_clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._time_offset_ms = 0
        self.last_time_sync_rtt_ms = 0
        self.last_server_time_ms = 0
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            timeout=httpx.Timeout(timeout_seconds),
            headers={"X-MBX-APIKEY": self.api_key, "User-Agent": "DIVATrading-AutoTrader/0.58.0rc1"},
            follow_redirects=False,
        )

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "BinancePrivateRestClient":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    def ping(self) -> dict[str, Any]:
        """Check REST reachability without authentication or order side effects."""
        payload = self.request("GET", "/fapi/v1/ping", signed=False)
        return payload if isinstance(payload, dict) else {}

    def get_order_book_top(self, symbol: str, *, limit: int = 5) -> dict[str, Any]:
        """Public USD-M depth on the exact same REST environment as execution.

        Only a bounded top-of-book snapshot is requested: no account mutation.
        """
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized or not normalized.isalnum() or limit not in {5, 10, 20}:
            raise ValueError("invalid order-book symbol or depth limit")
        payload = self.request("GET", "/fapi/v1/depth", {"symbol": normalized, "limit": limit}, signed=False)
        if not isinstance(payload, dict):
            raise BinancePrivateTransportError("Binance depth response is not an object")
        # Binance depth snapshots do not necessarily echo symbol. Bind the
        # exact queried symbol locally; no substitute symbol is accepted.
        if payload.get("symbol", normalized) != normalized:
            raise BinancePrivateTransportError("Binance depth symbol mismatch")
        return {**payload, "symbol": normalized}

    def exchange_now_ms(self) -> int:
        """Server-time-adjusted local clock, valid only after sync_server_time."""
        if self.last_server_time_ms <= 0:
            raise BinancePrivateTransportError("SERVER_TIME_NOT_SYNCHRONIZED")
        return self._now_ms() + self._time_offset_ms

    def get_exchange_info(self) -> dict[str, Any]:
        """Read current public contract metadata from this environment."""
        payload = self.request("GET", "/fapi/v1/exchangeInfo", signed=False)
        if not isinstance(payload, dict):
            raise BinancePrivateTransportError("Binance exchangeInfo response is not an object")
        return payload

    def sync_server_time(self) -> int:
        before = self._now_ms()
        response = self._client.get(f"{self.base_url}/fapi/v1/time")
        after = self._now_ms()
        response.raise_for_status()
        payload = response.json()
        server_time = int(payload["serverTime"])
        midpoint = (before + after) // 2
        self._time_offset_ms = server_time - midpoint
        self.last_time_sync_rtt_ms = max(0, after - before)
        self.last_server_time_ms = server_time
        return self._time_offset_ms

    @staticmethod
    def _value(value: Any) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, Decimal):
            return format(value, "f")
        return str(value)

    def request(self, method: str, path: str, params: Mapping[str, Any] | None = None, *, signed: bool = True) -> Any:
        method = method.upper()
        if method not in {"GET", "POST", "PUT", "DELETE"}:
            raise ValueError("Unsupported HTTP method")
        values = {k: v for k, v in (params or {}).items() if v is not None}
        if signed:
            values.setdefault("recvWindow", self.recv_window_ms)
            values["timestamp"] = self._now_ms() + self._time_offset_ms
        encoded_items = [(key, self._value(value)) for key, value in values.items()]
        query = urlencode(encoded_items)
        if signed:
            signature = hmac.new(self._secret, query.encode("utf-8"), hashlib.sha256).hexdigest()
            query = f"{query}&signature={signature}" if query else f"signature={signature}"
        url = f"{self.base_url}{path}"
        if query:
            url = f"{url}?{query}"
        try:
            # Do not retry signed writes. If a POST times out, the caller must
            # inspect by deterministic client ID before deciding whether to retry.
            response = self._client.request(method, url, headers={"X-MBX-APIKEY": self.api_key})
        except httpx.HTTPError as exc:
            # httpx exception strings can include the full signed URL, including
            # the HMAC signature. Keep diagnostics to the exception class only.
            raise BinancePrivateTransportError(
                f"Binance {method} {path} transport outcome may be unknown "
                f"({type(exc).__name__}); automatic retry is disabled"
            ) from None
        try:
            payload = response.json()
        except (ValueError, json.JSONDecodeError):
            payload = {"msg": response.text[:400], "code": None}
        if response.is_error or (isinstance(payload, dict) and isinstance(payload.get("code"), int) and payload["code"] < 0):
            code = payload.get("code") if isinstance(payload, dict) else None
            message = payload.get("msg", response.text) if isinstance(payload, dict) else response.text
            safe_message = str(message)
            for secret_value in (self.api_key, self._secret.decode("utf-8", errors="ignore")):
                if secret_value:
                    safe_message = safe_message.replace(secret_value, "[REDACTED]")
            safe_message = re.sub(r"(?i)(signature=)[^&\s]+", r"\1[REDACTED]", safe_message)
            safe_message = re.sub(r"(?i)(X-MBX-APIKEY[:=]\s*)[^\s,;]+", r"\1[REDACTED]", safe_message)
            raise BinancePrivateApiError(response.status_code, code, safe_message, path)
        return payload

    def start_user_data_stream(self) -> str:
        """Create or refresh the account listenKey; API-key auth, no HMAC signature."""
        payload = self.request("POST", "/fapi/v1/listenKey", signed=False)
        listen_key = payload.get("listenKey") if isinstance(payload, dict) else None
        if not isinstance(listen_key, str) or not listen_key.strip():
            raise BinancePrivateTransportError("Binance listenKey start response is missing listenKey")
        return listen_key

    def keepalive_user_data_stream(self, listen_key: str) -> dict[str, Any]:
        if not listen_key or not listen_key.strip():
            raise ValueError("listen_key must be non-empty")
        payload = self.request("PUT", "/fapi/v1/listenKey", {"listenKey": listen_key}, signed=False)
        return payload if isinstance(payload, dict) else {}

    def close_user_data_stream(self, listen_key: str) -> dict[str, Any]:
        if not listen_key or not listen_key.strip():
            raise ValueError("listen_key must be non-empty")
        payload = self.request("DELETE", "/fapi/v1/listenKey", {"listenKey": listen_key}, signed=False)
        return payload if isinstance(payload, dict) else {}

    def get_exchange_account(self) -> dict[str, Any]:
        """Return USDⓈ-M Futures Account Information V3 (balances/account state)."""
        return self.request("GET", "/fapi/v3/account")

    def get_account_config(self) -> dict[str, Any]:
        """Return account-level trading and multi-assets configuration (USER_DATA)."""
        return self.request("GET", "/fapi/v1/accountConfig")

    def get_balance(self) -> list[dict[str, Any]]:
        return self.request("GET", "/fapi/v3/balance")

    def get_symbol_config(self, symbol: str | None = None) -> list[dict[str, Any]]:
        """Read per-symbol leverage and marginType configuration (USER_DATA)."""
        result = self.request("GET", "/fapi/v1/symbolConfig", {"symbol": symbol})
        return _symbol_metadata_rows(result, symbol, "INVALID_SYMBOL_CONFIG_RESPONSE_SHAPE")

    def get_position_risk(self, symbol: str | None = None) -> list[dict[str, Any]]:
        result = self.request("GET", "/fapi/v3/positionRisk", {"symbol": symbol})
        return result if isinstance(result, list) else [result]

    def get_position_mode(self) -> dict[str, Any]:
        return self.request("GET", "/fapi/v1/positionSide/dual")

    def get_open_orders(self, symbol: str | None = None) -> list[dict[str, Any]]:
        result = self.request("GET", "/fapi/v1/openOrders", {"symbol": symbol})
        return result if isinstance(result, list) else [result]

    def get_open_algo_orders(self, symbol: str | None = None) -> list[dict[str, Any]]:
        result = self.request("GET", "/fapi/v1/openAlgoOrders", {"symbol": symbol})
        return result if isinstance(result, list) else [result]

    def get_order(self, symbol: str, *, order_id: int | None = None, client_order_id: str | None = None) -> dict[str, Any]:
        if (order_id is None) == (client_order_id is None):
            raise ValueError("Supply exactly one of order_id or client_order_id")
        return self.request("GET", "/fapi/v1/order", {
            "symbol": symbol, "orderId": order_id, "origClientOrderId": client_order_id,
        })

    def get_algo_order(self, *, algo_id: int | None = None, client_algo_id: str | None = None) -> dict[str, Any]:
        if (algo_id is None) == (client_algo_id is None):
            raise ValueError("Supply exactly one of algo_id or client_algo_id")
        return self.request("GET", "/fapi/v1/algoOrder", {"algoId": algo_id, "clientAlgoId": client_algo_id})

    def new_test_order(self, **params: Any) -> dict[str, Any]:
        """Validate a signed order request without submitting it to matching engine."""
        payload = self.request("POST", "/fapi/v1/order/test", params)
        return payload if isinstance(payload, dict) else {"response_type": type(payload).__name__}

    def new_order(self, **params: Any) -> dict[str, Any]:
        return self.request("POST", "/fapi/v1/order", params)

    def new_algo_order(self, **params: Any) -> dict[str, Any]:
        payload = {"algoType": "CONDITIONAL", **params}
        return self.request("POST", "/fapi/v1/algoOrder", payload)

    def cancel_order(self, symbol: str, *, order_id: int | None = None, client_order_id: str | None = None) -> dict[str, Any]:
        return self.request("DELETE", "/fapi/v1/order", {
            "symbol": symbol, "orderId": order_id, "origClientOrderId": client_order_id,
        })

    def cancel_algo_order(self, *, algo_id: int | None = None, client_algo_id: str | None = None) -> dict[str, Any]:
        if (algo_id is None) == (client_algo_id is None):
            raise ValueError("Supply exactly one of algo_id or client_algo_id")
        return self.request("DELETE", "/fapi/v1/algoOrder", {"algoId": algo_id, "clientAlgoId": client_algo_id})

    def set_leverage(self, symbol: str, leverage: int) -> dict[str, Any]:
        return self.request("POST", "/fapi/v1/leverage", {"symbol": symbol, "leverage": leverage})

    def change_margin_type(self, symbol: str, margin_type: str) -> dict[str, Any]:
        normalized = margin_type.strip().upper()
        if normalized not in {"ISOLATED", "CROSSED"}:
            raise ValueError("margin_type must be ISOLATED or CROSSED")
        return self.request("POST", "/fapi/v1/marginType",
                            {"symbol": symbol.strip().upper(), "marginType": normalized})

    def get_leverage_brackets(self, symbol: str | None = None) -> list[dict[str, Any]]:
        """Read account-specific USD-M leverage brackets; no account mutation."""
        result = self.request("GET", "/fapi/v1/leverageBracket", {"symbol": symbol})
        return _symbol_metadata_rows(result, symbol, "INVALID_LEVERAGE_BRACKET_RESPONSE_SHAPE")

    def get_commission_rate(self, symbol: str) -> dict[str, Any]:
        """Read symbol commission rates for fee-aware feasibility estimates."""
        result = self.request("GET", "/fapi/v1/commissionRate", {"symbol": symbol})
        if not isinstance(result, dict):
            raise BinancePrivateTransportError("Binance commissionRate response is not an object")
        return result

    def get_user_trades(
        self, symbol: str, *, from_id: int | None = None,
        start_time_ms: int | None = None, end_time_ms: int | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Fetch one bounded page of account fills from USD-M /fapi/v1/userTrades.

        Binance does not allow fromId together with startTime/endTime. The service
        layer chooses one pagination mode and enforces the seven-day time window.
        """
        normalized = symbol.strip().upper()
        if not normalized or not normalized.isalnum():
            raise ValueError("symbol must be a non-empty alphanumeric Binance symbol")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be an integer between 1 and 1000")
        if from_id is not None and (start_time_ms is not None or end_time_ms is not None):
            raise ValueError("from_id cannot be combined with start_time_ms/end_time_ms")
        if from_id is not None and (isinstance(from_id, bool) or not isinstance(from_id, int) or from_id < 0):
            raise ValueError("from_id must be a non-negative integer")
        if (start_time_ms is None) != (end_time_ms is None):
            raise ValueError("start_time_ms and end_time_ms must be supplied together")
        if start_time_ms is not None:
            if (isinstance(start_time_ms, bool) or not isinstance(start_time_ms, int)
                    or isinstance(end_time_ms, bool) or not isinstance(end_time_ms, int)
                    or start_time_ms < 0 or end_time_ms < start_time_ms):
                raise ValueError("invalid user-trades time range")
            if end_time_ms - start_time_ms > 7 * 24 * 60 * 60 * 1000:
                raise ValueError("user-trades time range cannot exceed seven days")
        payload = self.request("GET", "/fapi/v1/userTrades", {
            "symbol": normalized, "fromId": from_id, "startTime": start_time_ms,
            "endTime": end_time_ms, "limit": limit,
        })
        if not isinstance(payload, list) or any(not isinstance(row, dict) for row in payload):
            raise BinancePrivateTransportError("Binance userTrades response is not an array of objects")
        return payload

    def get_income_history(self, *, symbol: str | None = None, income_type: str | None = None,
                           start_time_ms: int | None = None, end_time_ms: int | None = None,
                           limit: int = 1000) -> list[dict[str, Any]]:
        result = self.request("GET", "/fapi/v1/income", {
            "symbol": symbol, "incomeType": income_type, "startTime": start_time_ms,
            "endTime": end_time_ms, "limit": limit,
        })
        return result if isinstance(result, list) else [result]
