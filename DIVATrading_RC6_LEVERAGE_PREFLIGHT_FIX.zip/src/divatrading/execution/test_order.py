"""Safe construction and exchange-filter validation for Binance Demo test orders.

Only LIMIT and MARKET requests are in scope. The Binance /order/test endpoint
validates signed parameters but does not submit the order to the matching engine.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from divatrading.strategy.scalping_market_data import InstrumentSpec


class TestOrderValidationError(ValueError):
    """Raised when a Demo test order cannot be safely normalized."""

    __test__ = False


def _positive_decimal(value: Any, field: str) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TestOrderValidationError(f"{field} must be a valid decimal") from exc
    if not parsed.is_finite() or parsed <= 0:
        raise TestOrderValidationError(f"{field} must be a positive finite decimal")
    return parsed


def _format(value: Decimal) -> str:
    return format(value, "f")


@dataclass(frozen=True, slots=True)
class TestOrderSpec:
    __test__ = False

    symbol: str
    side: str
    order_type: str
    quantity: Decimal
    price: Decimal | None = None
    time_in_force: str | None = None
    position_mode: str = "ONE_WAY"
    position_side: str | None = None

    def __post_init__(self) -> None:
        symbol = str(self.symbol).strip().upper()
        side = str(self.side).strip().upper()
        order_type = str(self.order_type).strip().upper()
        mode = str(self.position_mode).strip().upper()
        position_side = None if self.position_side is None else str(self.position_side).strip().upper()
        tif = None if self.time_in_force is None else str(self.time_in_force).strip().upper()
        if not symbol or not symbol.isalnum():
            raise TestOrderValidationError("symbol must be a non-empty alphanumeric contract symbol")
        if side not in {"BUY", "SELL"}:
            raise TestOrderValidationError("side must be BUY or SELL")
        if order_type not in {"LIMIT", "MARKET"}:
            raise TestOrderValidationError("Stage B only supports LIMIT and MARKET test orders")
        if mode not in {"ONE_WAY", "HEDGE"}:
            raise TestOrderValidationError("position_mode must be ONE_WAY or HEDGE")
        if mode == "HEDGE" and position_side not in {"LONG", "SHORT"}:
            raise TestOrderValidationError("position_side LONG or SHORT is required in Hedge Mode")
        if mode == "ONE_WAY" and position_side not in {None, "BOTH"}:
            raise TestOrderValidationError("position_side must be omitted or BOTH in One-way Mode")
        quantity = _positive_decimal(self.quantity, "quantity")
        price = None if self.price is None else _positive_decimal(self.price, "price")
        if order_type == "LIMIT":
            if price is None:
                raise TestOrderValidationError("price is required for LIMIT test orders")
            if tif is None:
                tif = "GTC"
            if tif not in {"GTC", "IOC", "FOK", "GTX", "RPI"}:
                raise TestOrderValidationError("time_in_force is not supported by this Stage B request builder")
        else:
            if price is not None:
                raise TestOrderValidationError("price must be omitted for MARKET test orders")
            if tif is not None:
                raise TestOrderValidationError("time_in_force must be omitted for MARKET test orders")
        object.__setattr__(self, "symbol", symbol)
        object.__setattr__(self, "side", side)
        object.__setattr__(self, "order_type", order_type)
        object.__setattr__(self, "quantity", quantity)
        object.__setattr__(self, "price", price)
        object.__setattr__(self, "time_in_force", tif)
        object.__setattr__(self, "position_mode", mode)
        object.__setattr__(self, "position_side", position_side)


@dataclass(frozen=True, slots=True)
class PreparedTestOrder:
    params: dict[str, str]
    notional_reference_usdt: str | None
    quantity_step: str
    price_tick: str | None

    def summary(self) -> dict[str, str]:
        return {
            "symbol": self.params["symbol"],
            "side": self.params["side"],
            "type": self.params["type"],
            "quantity": self.params["quantity"],
            "positionSide": self.params["positionSide"],
            "notional_reference_usdt": self.notional_reference_usdt or "EXCHANGE_AUTHORITATIVE_FOR_MARKET",
            "quantity_step": self.quantity_step,
            "price_tick": self.price_tick or "N/A",
            **({"price": self.params["price"], "timeInForce": self.params["timeInForce"]}
               if self.params["type"] == "LIMIT" else {}),
        }


def prepare_test_order(spec: TestOrderSpec, instrument: InstrumentSpec) -> PreparedTestOrder:
    """Validate a test order against current symbol filters and format exact strings."""
    if not isinstance(spec, TestOrderSpec) or not isinstance(instrument, InstrumentSpec):
        raise TypeError("spec and instrument must be TestOrderSpec and InstrumentSpec")
    if spec.symbol != instrument.symbol:
        raise TestOrderValidationError("symbol does not match the selected exchange instrument")
    if not instrument.is_usdt_perpetual or not instrument.is_trading:
        raise TestOrderValidationError("instrument is not an active USDT-margined perpetual")
    if spec.order_type not in instrument.order_types:
        raise TestOrderValidationError(f"{spec.order_type} is not enabled for {spec.symbol}")

    is_market = spec.order_type == "MARKET"
    step = instrument.market_lot_step_size if is_market else instrument.lot_step_size
    min_qty = instrument.market_min_qty if is_market else instrument.min_qty
    max_qty = instrument.market_max_qty if is_market else instrument.max_qty
    if step is None or step <= 0 or min_qty is None or max_qty is None:
        raise TestOrderValidationError("current exchange quantity filters are incomplete")
    if spec.quantity % step != 0:
        raise TestOrderValidationError(f"quantity is not aligned to the exchange step size {step}")
    if spec.quantity < min_qty or spec.quantity > max_qty:
        raise TestOrderValidationError("quantity is outside the current exchange quantity bounds")

    # LIMIT notional is exact because the request contains an explicit limit price.
    # MARKET notional uses exchange-side reference-price/filter semantics; do not
    # approximate those semantics with a last-price ticker. /order/test is authoritative.
    notional: Decimal | None = None
    if not is_market:
        if spec.price is None:
            raise TestOrderValidationError("LIMIT price is required for notional validation")
        if instrument.min_notional is None or instrument.min_notional <= 0:
            raise TestOrderValidationError("current exchange minimum-notional filter is unavailable")
        notional = spec.quantity * spec.price
        if notional < instrument.min_notional:
            raise TestOrderValidationError(
                f"order notional {notional} is below current minimum {instrument.min_notional} USDT"
            )
        if instrument.max_notional is not None and notional > instrument.max_notional:
            raise TestOrderValidationError("order notional exceeds the current exchange maximum")

    params: dict[str, str] = {
        "symbol": spec.symbol,
        "side": spec.side,
        "type": spec.order_type,
        "quantity": _format(spec.quantity),
        "positionSide": spec.position_side or "BOTH",
    }
    price_tick: str | None = None
    if not is_market:
        if instrument.tick_size is None or instrument.tick_size <= 0:
            raise TestOrderValidationError("current exchange price tick is unavailable")
        if not instrument.is_price_on_tick(spec.price):  # type: ignore[arg-type]
            raise TestOrderValidationError(
                f"price is not aligned to the exchange tick size {instrument.tick_size}"
            )
        if instrument.min_price is not None and spec.price < instrument.min_price:  # type: ignore[operator]
            raise TestOrderValidationError("price is below the current exchange minimum price")
        if instrument.max_price is not None and spec.price > instrument.max_price:  # type: ignore[operator]
            raise TestOrderValidationError("price is above the current exchange maximum price")
        if spec.time_in_force not in instrument.time_in_force:
            raise TestOrderValidationError("time_in_force is not enabled for the selected symbol")
        params["price"] = _format(spec.price)  # type: ignore[arg-type]
        params["timeInForce"] = spec.time_in_force or "GTC"
        price_tick = _format(instrument.tick_size)
    return PreparedTestOrder(
        params=params,
        notional_reference_usdt=None if notional is None else _format(notional),
        quantity_step=_format(step),
        price_tick=price_tick,
    )
