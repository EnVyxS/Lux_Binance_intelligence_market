"""Multi-symbol trade planning and portfolio risk primitives."""

from .models import QualifiedSignal, TradePlan
from .risk import PortfolioRiskConfig, PortfolioRiskManager, RiskDecision
from .universe import SymbolUniverseConfig, SymbolUniverseSelector, UniverseSelection
from .coordinator import MultiPairExecutionCoordinator, PortfolioSnapshot, SignalRouteResult

__all__ = [
    "QualifiedSignal", "TradePlan", "PortfolioRiskConfig", "PortfolioRiskManager",
    "RiskDecision", "SymbolUniverseConfig", "SymbolUniverseSelector", "UniverseSelection",
    "MultiPairExecutionCoordinator", "PortfolioSnapshot", "SignalRouteResult",
]
from .live_runtime import (
    LiveMarketRuntimeConfig, LiveMarketRuntimeSnapshot, MultiPairLiveMarketRuntime,
    SymbolRuntimeStatus,
)

__all__ += [
    "LiveMarketRuntimeConfig", "LiveMarketRuntimeSnapshot",
    "MultiPairLiveMarketRuntime", "SymbolRuntimeStatus",
]

from .signal_planner import (
    SMCTradePlannerConfig, SetupCandidate, CandidateEvaluation,
    TradePlanningResult, SMCV2TradePlanner,
)

__all__ += [
    "SMCTradePlannerConfig", "SetupCandidate", "CandidateEvaluation",
    "TradePlanningResult", "SMCV2TradePlanner",
]

from .dispatcher import (
    AutonomousDispatcherConfig, AutonomousEntryDispatcher, BinancePortfolioSnapshotProvider,
    DispatchResult, PaperPortfolioSnapshotProvider, PortfolioSnapshotProvider,
)

__all__ += [
    "AutonomousDispatcherConfig", "AutonomousEntryDispatcher",
    "BinancePortfolioSnapshotProvider", "DispatchResult",
    "PaperPortfolioSnapshotProvider", "PortfolioSnapshotProvider",
]
