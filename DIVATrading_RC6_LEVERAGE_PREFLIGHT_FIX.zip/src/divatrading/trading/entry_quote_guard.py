"""Fail-closed executable bid/ask and bounded order-book impact admission.

The exchange depth snapshot is short-lived and cannot guarantee a future fill.
It provides a last-moment *rejection* gate, not a trading/price guarantee.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from divatrading.trading.models import TradePlan


def _positive_decimal(value: object) -> Decimal:
    try:
        result = Decimal(str(value))
    except (TypeError, ValueError, InvalidOperation) as exc:
        raise ValueError("MALFORMED_QUOTE_DECIMAL") from exc
    if not result.is_finite() or result <= 0:
        raise ValueError("MALFORMED_QUOTE_DECIMAL")
    return result


@dataclass(frozen=True, slots=True)
class EntryQuoteGuardConfig:
    max_snapshot_age_ms: int = 2_500
    max_future_skew_ms: int = 500
    max_spread_bps: Decimal = Decimal("20")
    max_market_slippage_bps: Decimal = Decimal("20")

    def __post_init__(self) -> None:
        if isinstance(self.max_snapshot_age_ms, bool) or not 100 <= self.max_snapshot_age_ms <= 10000:
            raise ValueError("invalid max_snapshot_age_ms")
        if isinstance(self.max_future_skew_ms, bool) or not 0 <= self.max_future_skew_ms <= 2000:
            raise ValueError("invalid max_future_skew_ms")
        for v in (self.max_spread_bps, self.max_market_slippage_bps):
            if not isinstance(v, Decimal) or not v.is_finite() or v <= 0 or v > 1000:
                raise ValueError("invalid entry quote guard bps")


@dataclass(frozen=True, slots=True)
class EntryQuoteVerdict:
    allowed: bool
    reason: str
    spread_bps: Decimal | None = None
    estimated_fill_price: Decimal | None = None
    snapshot_age_ms: int | None = None


def check_entry_quote(plan: TradePlan, payload: Mapping[str, Any], *,
                      now_exchange_ms: int,
                      config: EntryQuoteGuardConfig | None = None) -> EntryQuoteVerdict:
    cfg = config or EntryQuoteGuardConfig()
    if not isinstance(payload, Mapping) or str(payload.get("symbol", "")).upper() != plan.signal.symbol:
        return EntryQuoteVerdict(False, "QUOTE_SYMBOL_MISMATCH")
    try:
        ts = int(payload.get("T") or payload.get("E"))
    except (TypeError, ValueError, OverflowError):
        return EntryQuoteVerdict(False, "QUOTE_TIMESTAMP_MISSING")
    if isinstance(now_exchange_ms, bool) or not isinstance(now_exchange_ms, int):
        raise ValueError("now_exchange_ms must be an integer")
    age = now_exchange_ms - ts
    if age < -cfg.max_future_skew_ms or age > cfg.max_snapshot_age_ms:
        return EntryQuoteVerdict(False, "QUOTE_STALE_OR_FUTURE", snapshot_age_ms=age)
    try:
        raw_bids, raw_asks = payload["bids"], payload["asks"]
        bids = [(_positive_decimal(p), _positive_decimal(q)) for p, q in raw_bids]
        asks = [(_positive_decimal(p), _positive_decimal(q)) for p, q in raw_asks]
        if not bids or not asks:
            raise ValueError("EMPTY_BOOK")
        if any(bids[i][0] <= bids[i + 1][0] for i in range(len(bids) - 1)):
            raise ValueError("INVALID_BOOK_ORDER")
        if any(asks[i][0] >= asks[i + 1][0] for i in range(len(asks) - 1)):
            raise ValueError("INVALID_BOOK_ORDER")
        bid, ask = bids[0][0], asks[0][0]
        if bid >= ask:
            raise ValueError("CROSSED_BOOK")
    except (KeyError, ValueError, TypeError, IndexError, ArithmeticError) as exc:
        return EntryQuoteVerdict(False, f"QUOTE_BOOK_INVALID:{type(exc).__name__}", snapshot_age_ms=age)
    mid = (bid + ask) / 2
    spread_bps = (ask - bid) / mid * Decimal(10_000)
    if spread_bps > cfg.max_spread_bps:
        return EntryQuoteVerdict(False, "QUOTE_SPREAD_TOO_WIDE", spread_bps, snapshot_age_ms=age)
    if plan.signal.entry_type == "LIMIT":
        return EntryQuoteVerdict(True, "LIMIT_QUOTE_ACCEPTED", spread_bps, snapshot_age_ms=age)

    reference = plan.signal.entry_price
    is_buy = plan.signal.side == "LONG"
    book_side = asks if is_buy else bids
    is_ioc = plan.signal.entry_type == "LIMIT_IOC"
    if is_ioc:
        best_price = book_side[0][0]
        distance = reference - best_price if is_buy else best_price - reference
        if distance < 0:
            return EntryQuoteVerdict(False, "IOC_LIMIT_NOT_MARKETABLE", spread_bps, snapshot_age_ms=age)
        if distance / best_price * Decimal(10_000) > cfg.max_market_slippage_bps:
            return EntryQuoteVerdict(False, "IOC_BOUND_TOO_FAR_FROM_EXECUTABLE_QUOTE", spread_bps,
                                     snapshot_age_ms=age)
        if (is_buy and bid <= plan.signal.stop_loss) or (not is_buy and ask >= plan.signal.stop_loss):
            return EntryQuoteVerdict(False, "IOC_QUOTE_AT_OR_BEYOND_STOP", spread_bps, snapshot_age_ms=age)

    remaining = plan.quantity
    price_notional = Decimal(0)
    for price, size in book_side:
        if is_ioc and (price > reference if is_buy else price < reference):
            break
        consumed = min(remaining, size)
        price_notional += consumed * price
        remaining -= consumed
        if remaining <= 0:
            break
    if remaining > 0:
        reason = "IOC_INSUFFICIENT_DEPTH_WITHIN_LIMIT" if is_ioc else "QUOTE_INSUFFICIENT_TOP_BOOK_DEPTH"
        return EntryQuoteVerdict(False, reason, spread_bps,
                                 snapshot_age_ms=age)
    vwap = price_notional / plan.quantity
    if is_ioc:
        return EntryQuoteVerdict(True, "IOC_QUOTE_ACCEPTED", spread_bps, vwap, age)
    adverse = ((vwap - reference) / reference if is_buy else (reference - vwap) / reference)
    if adverse * Decimal(10_000) > cfg.max_market_slippage_bps:
        return EntryQuoteVerdict(False, "QUOTE_ESTIMATED_SLIPPAGE_TOO_HIGH", spread_bps,
                                 vwap, age)
    return EntryQuoteVerdict(True, "MARKET_QUOTE_ACCEPTED", spread_bps, vwap, age)
