"""Portfolio-level risk sizing with exact Decimal exchange quantity grids."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from threading import RLock

from divatrading.strategy.scalping_market_data import InstrumentSpec
from .models import QualifiedSignal, TradePlan
from .exchange_feasibility import SymbolRiskInputs, assess_margin_feasibility


@dataclass(frozen=True, slots=True)
class PortfolioRiskConfig:
    risk_per_trade_pct: Decimal = Decimal("0.25")
    risk_per_trade_fixed_usdt: Decimal | None = None
    max_portfolio_open_risk_pct: Decimal = Decimal("1.00")
    max_symbol_notional_pct_equity: Decimal = Decimal("20")
    max_positions: int = 5
    leverage: int = 3
    max_leverage: int = 5
    leverage_mode: str = "AUTO"
    margin_mode: str = "ISOLATED"
    slippage_reserve_bps: Decimal = Decimal("5")
    funding_reserve_bps: Decimal = Decimal("10")
    fee_reserve_multiplier: Decimal = Decimal("1.25")
    paper_ioc_taker_fee_bps: Decimal = Decimal("5")

    def __post_init__(self) -> None:
        for name in ("risk_per_trade_pct", "max_portfolio_open_risk_pct", "max_symbol_notional_pct_equity"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
                raise ValueError(f"{name} must be a positive finite Decimal")
        if self.risk_per_trade_pct > self.max_portfolio_open_risk_pct and self.risk_per_trade_fixed_usdt is None:
            raise ValueError("risk_per_trade_pct cannot exceed max portfolio open risk")
        if self.risk_per_trade_fixed_usdt is not None and (not self.risk_per_trade_fixed_usdt.is_finite() or self.risk_per_trade_fixed_usdt <= 0):
            raise ValueError("risk_per_trade_fixed_usdt must be a positive finite Decimal")
        if isinstance(self.max_positions, bool) or not 1 <= self.max_positions <= 128:
            raise ValueError("max_positions must be between 1 and 128")
        if isinstance(self.leverage, bool) or not 1 <= self.leverage <= 125:
            raise ValueError("leverage must be between 1 and 125")
        if isinstance(self.max_leverage, bool) or not 1 <= self.max_leverage <= 125:
            raise ValueError("max_leverage must be between 1 and 125")
        if self.leverage > self.max_leverage:
            raise ValueError("configured leverage exceeds max_leverage")
        if self.leverage_mode not in {"AUTO", "FIXED"}:
            raise ValueError("leverage_mode must be AUTO or FIXED")
        if self.margin_mode not in {"ISOLATED", "CROSSED"}:
            raise ValueError("margin_mode must be ISOLATED or CROSSED")
        for name in ("slippage_reserve_bps", "funding_reserve_bps", "paper_ioc_taker_fee_bps"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value < 0 or value > 5000:
                raise ValueError(f"{name} must be a Decimal between 0 and 5000 bps")
        if (not isinstance(self.fee_reserve_multiplier, Decimal)
                or not self.fee_reserve_multiplier.is_finite()
                or self.fee_reserve_multiplier < 1 or self.fee_reserve_multiplier > 5):
            raise ValueError("fee_reserve_multiplier must be between 1 and 5")


@dataclass(frozen=True, slots=True)
class RiskDecision:
    accepted: bool
    reason: str
    plan: TradePlan | None = None


def _floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError("quantity step must be positive")
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step


class PortfolioRiskManager:
    """Calculates risk budgets centrally; caller supplies reconciled portfolio state."""
    def __init__(self, config: PortfolioRiskConfig | None = None) -> None:
        self.config = config or PortfolioRiskConfig()
        self._lock = RLock()

    def size_signal(
        self,
        signal: QualifiedSignal,
        instrument: InstrumentSpec,
        *,
        equity_usdt: Decimal,
        open_risk_usdt: Decimal = Decimal("0"),
        active_position_count: int = 0,
        existing_symbol_notional_usdt: Decimal = Decimal("0"),
        available_margin_usdt: Decimal | None = None,
        symbol_risk_inputs: SymbolRiskInputs | None = None,
        client_order_id: str,
    ) -> RiskDecision:
        with self._lock:
            if signal.symbol != instrument.symbol:
                return RiskDecision(False, "SIGNAL_INSTRUMENT_MISMATCH")
            if not instrument.is_usdt_perpetual or not instrument.is_trading:
                return RiskDecision(False, "INSTRUMENT_NOT_TRADABLE_USDT_PERPETUAL")
            if instrument.tick_size is None:
                return RiskDecision(False, "PRICE_TICK_SIZE_UNAVAILABLE")
            step = instrument.market_lot_step_size if signal.entry_type == "MARKET" else instrument.lot_step_size
            min_qty = instrument.market_min_qty if signal.entry_type == "MARKET" else instrument.min_qty
            max_qty = instrument.market_max_qty if signal.entry_type == "MARKET" else instrument.max_qty
            if step is None or step <= 0 or min_qty is None or max_qty is None:
                return RiskDecision(False, "QUANTITY_FILTER_INCOMPLETE")
            if instrument.min_notional is None:
                return RiskDecision(False, "NOTIONAL_FILTER_MINIMUM_UNAVAILABLE")
            if signal.entry_price % instrument.tick_size or signal.stop_loss % instrument.tick_size or signal.take_profit % instrument.tick_size:
                return RiskDecision(False, "PRICE_NOT_ALIGNED_TO_EXCHANGE_TICK")
            ioc = signal.entry_type == "LIMIT_IOC"
            if ioc:
                required_order_types = {"LIMIT", "STOP_MARKET", "TAKE_PROFIT_MARKET"}
                if not required_order_types.issubset(instrument.order_types) or "IOC" not in instrument.time_in_force:
                    return RiskDecision(False, "IOC_ENTRY_OR_PROTECTION_NOT_ENABLED")
                for price in (signal.entry_price, signal.stop_loss, signal.take_profit):
                    if (instrument.min_price and price < instrument.min_price
                            or instrument.max_price and price > instrument.max_price):
                        return RiskDecision(False, "PRICE_OUTSIDE_EXCHANGE_FILTER")
                market_step = instrument.market_lot_step_size
                market_min = instrument.market_min_qty
                market_max = instrument.market_max_qty
                # A one-step partial IOC fill must remain protectable by the
                # quantity-scoped stop/TP and executable by a market exit.
                if (market_step is None or market_step <= 0 or market_min is None
                        or market_max is None or step % market_step or market_min > step):
                    return RiskDecision(False, "IOC_PARTIAL_FILL_EXIT_GRID_INCOMPATIBLE")
                max_qty = min(max_qty, market_max)
            if not equity_usdt.is_finite() or equity_usdt <= 0:
                return RiskDecision(False, "ACCOUNT_EQUITY_INVALID")
            if not open_risk_usdt.is_finite() or open_risk_usdt < 0:
                return RiskDecision(False, "OPEN_PORTFOLIO_RISK_INVALID")
            if not existing_symbol_notional_usdt.is_finite() or existing_symbol_notional_usdt < 0:
                return RiskDecision(False, "EXISTING_SYMBOL_NOTIONAL_INVALID")
            if active_position_count >= self.config.max_positions:
                return RiskDecision(False, "MAX_OPEN_POSITIONS_REACHED")
            portfolio_cap = equity_usdt * self.config.max_portfolio_open_risk_pct / Decimal("100")
            risk_budget = (self.config.risk_per_trade_fixed_usdt if self.config.risk_per_trade_fixed_usdt is not None
                           else equity_usdt * self.config.risk_per_trade_pct / Decimal("100"))
            available_risk = portfolio_cap - open_risk_usdt
            if available_risk <= 0:
                return RiskDecision(False, "PORTFOLIO_RISK_BUDGET_EXHAUSTED")
            risk_budget = min(risk_budget, available_risk)
            stop_distance = abs(signal.entry_price - signal.stop_loss)

            # Risk sizing is performed before margin/leverage feasibility.
            # Fee/slippage/funding reserves are included in the risk cost per unit.
            leverage_cap = self.config.max_leverage if symbol_risk_inputs is not None else self.config.leverage
            if symbol_risk_inputs is not None and symbol_risk_inputs.symbol != signal.symbol:
                return RiskDecision(False, "ACCOUNT_RISK_INPUT_SYMBOL_MISMATCH")
            if symbol_risk_inputs is not None or ioc:
                taker = (symbol_risk_inputs.commission.taker_rate if symbol_risk_inputs is not None
                         else self.config.paper_ioc_taker_fee_bps / Decimal("10000"))
                # Match the round-trip reserve used by the feasibility calculation.
                # Use entry notional for both legs as a conservative common basis.
                fee_per_unit = signal.entry_price * taker * Decimal("2") * self.config.fee_reserve_multiplier
                slippage_per_unit = signal.entry_price * self.config.slippage_reserve_bps / Decimal("10000") * Decimal("2")
                funding_per_unit = signal.entry_price * self.config.funding_reserve_bps / Decimal("10000")
            else:
                fee_per_unit = slippage_per_unit = funding_per_unit = Decimal("0")
            total_risk_per_unit = stop_distance + fee_per_unit + slippage_per_unit + funding_per_unit
            raw_qty = risk_budget / total_risk_per_unit
            qty = _floor_step(raw_qty, step)
            if max_qty is not None:
                qty = min(qty, _floor_step(max_qty, step))

            def clamp_notional(quantity: Decimal, leverage_for_cap: int) -> Decimal:
                max_notional = (equity_usdt * self.config.max_symbol_notional_pct_equity
                                / Decimal("100") * Decimal(leverage_for_cap))
                remaining_notional = max_notional - existing_symbol_notional_usdt
                if remaining_notional <= 0:
                    return Decimal("0")
                result = min(quantity, _floor_step(remaining_notional / signal.entry_price, step))
                if instrument.max_notional is not None:
                    result = min(result, _floor_step(instrument.max_notional / signal.entry_price, step))
                return result

            qty = clamp_notional(qty, leverage_cap)
            if qty <= 0 or (min_qty is not None and qty < min_qty):
                return RiskDecision(False, "QUANTITY_BELOW_EXCHANGE_MINIMUM")
            notional = qty * signal.entry_price
            if instrument.min_notional is not None and notional < instrument.min_notional:
                return RiskDecision(False, "NOTIONAL_BELOW_EXCHANGE_MINIMUM")
            if instrument.max_notional is not None and notional > instrument.max_notional:
                return RiskDecision(False, "NOTIONAL_ABOVE_EXCHANGE_MAXIMUM")

            fee_reserve = qty * fee_per_unit
            slippage_reserve = qty * slippage_per_unit
            funding_reserve = qty * funding_per_unit
            maintenance = Decimal("0")
            margin_estimate = notional / Decimal(self.config.leverage)
            leverage = self.config.leverage
            if symbol_risk_inputs is not None:
                if available_margin_usdt is None or not available_margin_usdt.is_finite() or available_margin_usdt <= 0:
                    return RiskDecision(False, "AVAILABLE_MARGIN_UNAVAILABLE")
                slippage_reserve = notional * self.config.slippage_reserve_bps / Decimal("10000") * 2
                funding_reserve = notional * self.config.funding_reserve_bps / Decimal("10000")
                for _ in range(3):
                    # AUTO picks the LOWEST bracket-valid leverage that fits both
                    # spendable margin and symbol-level margin allocation. It is
                    # never necessary to force max leverage on every trade.
                    symbol_margin_budget = equity_usdt * self.config.max_symbol_notional_pct_equity / Decimal("100")
                    effective_margin_budget = min(available_margin_usdt, symbol_margin_budget)
                    feasibility = assess_margin_feasibility(
                        notional=notional, available_margin=effective_margin_budget,
                        brackets=symbol_risk_inputs.brackets, commission=symbol_risk_inputs.commission,
                        max_leverage=self.config.max_leverage,
                        fixed_leverage=(self.config.max_leverage if self.config.leverage_mode == "FIXED" else None),
                        slippage_reserve=slippage_reserve, funding_reserve=funding_reserve,
                        fee_multiplier=self.config.fee_reserve_multiplier,
                    )
                    if not feasibility.accepted:
                        return RiskDecision(False, f"EXCHANGE_MARGIN_INFEASIBLE:{feasibility.reason}")
                    leverage = int(feasibility.leverage)
                    limited_qty = clamp_notional(qty, leverage)
                    if limited_qty == qty:
                        fee_reserve = feasibility.fee_reserve or Decimal("0")
                        margin_estimate = feasibility.initial_margin_estimate or Decimal("0")
                        maintenance = feasibility.maintenance_margin_estimate or Decimal("0")
                        break
                    qty = limited_qty
                    if qty <= 0 or (min_qty is not None and qty < min_qty):
                        return RiskDecision(False, "RISK_SIZED_QUANTITY_BELOW_MINIMUM_AFTER_LEVERAGE_CAP")
                    notional = qty * signal.entry_price
                    if instrument.min_notional is not None and notional < instrument.min_notional:
                        return RiskDecision(False, "NOTIONAL_BELOW_EXCHANGE_MINIMUM_AFTER_LEVERAGE_CAP")
                    slippage_reserve = notional * self.config.slippage_reserve_bps / Decimal("10000") * 2
                    funding_reserve = notional * self.config.funding_reserve_bps / Decimal("10000")
                else:
                    return RiskDecision(False, "MARGIN_FEASIBILITY_DID_NOT_CONVERGE")

            costs = fee_reserve + slippage_reserve + funding_reserve
            actual_risk = qty * stop_distance + costs
            if actual_risk > risk_budget:
                return RiskDecision(False, "CALCULATED_RISK_WITH_COST_RESERVES_EXCEEDS_BUDGET")
            if ioc and signal.minimum_net_rr is not None:
                net_reward = qty * abs(signal.take_profit - signal.entry_price) - costs
                if net_reward < actual_risk * signal.minimum_net_rr:
                    return RiskDecision(False, "IOC_REWARD_RISK_BELOW_MINIMUM_AFTER_COSTS")
            if notional < instrument.min_notional:
                return RiskDecision(False, "NOTIONAL_BELOW_EXCHANGE_MINIMUM")
            plan = TradePlan(
                signal=signal, quantity=qty, notional_usdt=notional, risk_usdt=actual_risk,
                margin_estimate_usdt=margin_estimate, leverage=leverage,
                client_order_id=client_order_id, margin_mode=self.config.margin_mode,
                fee_reserve_usdt=fee_reserve, slippage_reserve_usdt=slippage_reserve,
                funding_reserve_usdt=funding_reserve,
                maintenance_margin_estimate_usdt=maintenance,
            )
            return RiskDecision(True, "RISK_APPROVED", plan)
