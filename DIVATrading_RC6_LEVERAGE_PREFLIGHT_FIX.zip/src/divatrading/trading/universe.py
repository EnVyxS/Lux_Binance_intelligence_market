"""Dynamic AUTO/MANUAL universe selection for eligible USDⓈ-M USDT perpetuals."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable

from divatrading.exchange.binance.models import ExchangeInfoSnapshot, SymbolInfo


@dataclass(frozen=True, slots=True)
class SymbolUniverseConfig:
    mode: str = "AUTO"
    max_active_symbols: int = 24
    min_quote_volume_usdt: Decimal = Decimal("10000000")
    min_trade_count_24h: int = 1000
    manual_symbols: tuple[str, ...] = ()
    exclude_symbols: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.mode not in {"AUTO", "MANUAL"}:
            raise ValueError("mode must be AUTO or MANUAL")
        if isinstance(self.max_active_symbols, bool) or not 1 <= self.max_active_symbols <= 128:
            raise ValueError("max_active_symbols must be between 1 and 128")
        if not isinstance(self.min_quote_volume_usdt, Decimal) or not self.min_quote_volume_usdt.is_finite() or self.min_quote_volume_usdt < 0:
            raise ValueError("min_quote_volume_usdt must be a non-negative finite Decimal")
        if isinstance(self.min_trade_count_24h, bool) or self.min_trade_count_24h < 0:
            raise ValueError("min_trade_count_24h must be a non-negative integer")
        object.__setattr__(self, "manual_symbols", tuple(x.strip().upper() for x in self.manual_symbols if x.strip()))
        object.__setattr__(self, "exclude_symbols", tuple(x.strip().upper() for x in self.exclude_symbols if x.strip()))
        if self.mode == "MANUAL" and not self.manual_symbols:
            raise ValueError("MANUAL mode requires at least one manual_symbols entry")


@dataclass(frozen=True, slots=True)
class SelectedSymbol:
    info: SymbolInfo
    quote_volume_24h: Decimal | None
    trade_count_24h: int | None
    rank: int


@dataclass(frozen=True, slots=True)
class UniverseSelection:
    mode: str
    selected: tuple[SelectedSymbol, ...]
    rejected: tuple[tuple[str, str], ...]

    @property
    def symbols(self) -> tuple[str, ...]:
        return tuple(item.info.symbol for item in self.selected)


class SymbolUniverseSelector:
    """Selects exact active USDT perpetual contracts; it never guesses a symbol."""
    def __init__(self, config: SymbolUniverseConfig | None = None) -> None:
        self.config = config or SymbolUniverseConfig()

    def select(
        self,
        snapshot: ExchangeInfoSnapshot,
        tickers_24h: Iterable[dict[str, Any]],
    ) -> UniverseSelection:
        if not isinstance(snapshot, ExchangeInfoSnapshot):
            raise TypeError("snapshot must be ExchangeInfoSnapshot")
        info_by_symbol = {item.symbol: item for item in snapshot.symbols}
        ticker_by_symbol: dict[str, tuple[Decimal, int]] = {}
        for row in tickers_24h:
            if not isinstance(row, dict) or not isinstance(row.get("symbol"), str):
                continue
            symbol = row["symbol"].strip().upper()
            try:
                quote_volume = Decimal(str(row.get("quoteVolume", "0")))
                trade_count = int(row.get("count", 0))
            except (InvalidOperation, TypeError, ValueError):
                continue
            if quote_volume.is_finite() and quote_volume >= 0 and trade_count >= 0:
                ticker_by_symbol[symbol] = (quote_volume, trade_count)

        rejected: list[tuple[str, str]] = []
        exclusions = set(self.config.exclude_symbols)
        if self.config.mode == "MANUAL":
            candidate_names = self.config.manual_symbols
        else:
            candidate_names = tuple(info_by_symbol)

        candidates: list[tuple[SymbolInfo, Decimal | None, int | None]] = []
        for name in candidate_names:
            info = info_by_symbol.get(name)
            if info is None:
                rejected.append((name, "SYMBOL_NOT_IN_EXCHANGE_INFO"))
                continue
            if name in exclusions:
                rejected.append((name, "USER_EXCLUDED"))
                continue
            if not info.is_tradable_usdt_perpetual:
                rejected.append((name, "NOT_ACTIVE_USDT_PERPETUAL"))
                continue
            ticker = ticker_by_symbol.get(name)
            if ticker is None:
                rejected.append((name, "24H_TICKER_MISSING"))
                continue
            quote_volume, trade_count = ticker
            if self.config.mode == "AUTO":
                if quote_volume < self.config.min_quote_volume_usdt:
                    rejected.append((name, "QUOTE_VOLUME_BELOW_MINIMUM"))
                    continue
                if trade_count < self.config.min_trade_count_24h:
                    rejected.append((name, "TRADE_COUNT_BELOW_MINIMUM"))
                    continue
            candidates.append((info, quote_volume, trade_count))

        candidates.sort(key=lambda item: (item[1] or Decimal("0"), item[2] or 0), reverse=True)
        selected = tuple(
            SelectedSymbol(info, volume, count, index + 1)
            for index, (info, volume, count) in enumerate(candidates[: self.config.max_active_symbols])
        )
        for info, _, _ in candidates[self.config.max_active_symbols:]:
            rejected.append((info.symbol, "ACTIVE_SYMBOL_CAP"))
        if not selected:
            raise ValueError("No eligible symbols selected; inspect rejected reasons and exchange metadata")
        return UniverseSelection(self.config.mode, selected, tuple(rejected))
