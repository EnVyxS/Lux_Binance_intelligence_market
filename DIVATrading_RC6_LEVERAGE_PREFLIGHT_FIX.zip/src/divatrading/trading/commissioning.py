"""Account-equity-aware, fail-closed TESTNET Stage C autonomous commissioning caps."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from divatrading.trading.risk import PortfolioRiskConfig


LIVE_MAX_POSITIONS = 2


@dataclass(frozen=True, slots=True)
class TestnetCommissioningCaps:
    __test__ = False  # Not a pytest test case.
    max_trade_risk_pct: Decimal = Decimal("0.10")
    max_portfolio_risk_pct: Decimal = Decimal("0.25")

    def __post_init__(self) -> None:
        for cap in (self.max_trade_risk_pct, self.max_portfolio_risk_pct):
            if not isinstance(cap, Decimal) or not cap.is_finite() or cap <= 0 or cap > 100:
                raise ValueError("TESTNET commissioning caps must be finite percentages within (0,100]")
        if self.max_trade_risk_pct > self.max_portfolio_risk_pct:
            raise ValueError("Trade risk cap may not exceed portfolio risk cap")

    def violation(self, config: PortfolioRiskConfig, *, equity_usdt: Decimal | None) -> str | None:
        """Check effective operator risk; fixed-USDT risk must use fresh equity.

        During startup equity may be unavailable. In that case a FIXED risk is
        never approved at dispatch; callers must pass actual account equity.
        """
        if config.max_portfolio_open_risk_pct > self.max_portfolio_risk_pct:
            return "TESTNET_COMMISSIONING_PORTFOLIO_RISK_CAP_EXCEEDED"
        fixed = config.risk_per_trade_fixed_usdt
        if fixed is not None:
            if equity_usdt is None:
                return "TESTNET_COMMISSIONING_FIXED_RISK_EQUITY_REQUIRED"
            if not isinstance(equity_usdt, Decimal) or not equity_usdt.is_finite() or equity_usdt <= 0:
                return "TESTNET_COMMISSIONING_EQUITY_INVALID"
            if fixed > equity_usdt * self.max_trade_risk_pct / Decimal("100"):
                return "TESTNET_COMMISSIONING_FIXED_RISK_CAP_EXCEEDED"
        elif config.risk_per_trade_pct > self.max_trade_risk_pct:
            return "TESTNET_COMMISSIONING_TRADE_RISK_CAP_EXCEEDED"
        return None


@dataclass(frozen=True, slots=True)
class LiveFirstCommissioningCaps(TestnetCommissioningCaps):
    """Live risk envelope supporting fixed-USDT bullets and percent sizing.

    The $0.20 bullet is always checked against account equity and a safety
    percentage ceiling; the exchange min-size never increases a risk budget.
    """
    max_trade_risk_pct: Decimal = Decimal("10")
    max_portfolio_risk_pct: Decimal = Decimal("20")

    # Validation runs again against fresh exchange equity during routing.
    def violation(self, config: PortfolioRiskConfig, *, equity_usdt: Decimal | None) -> str | None:
        if config.max_positions > LIVE_MAX_POSITIONS:
            return "LIVE_FIRST_COMMISSIONING_POSITION_CAP_EXCEEDED"
        result = TestnetCommissioningCaps.violation(self, config, equity_usdt=equity_usdt)
        return result.replace("TESTNET_COMMISSIONING", "LIVE_FIRST_COMMISSIONING") if result else None
