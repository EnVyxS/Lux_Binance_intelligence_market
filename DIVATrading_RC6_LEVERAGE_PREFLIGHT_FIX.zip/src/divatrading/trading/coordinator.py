"""Multi-pair router from strategy-qualified signals through global risk to execution."""
from __future__ import annotations

from dataclasses import dataclass
import time
from decimal import Decimal
from threading import RLock
from typing import Mapping, TYPE_CHECKING

from divatrading.execution.ledger import ExecutionLedger
if TYPE_CHECKING:
    from divatrading.execution.service import ExecutionResult, ExecutionService
from divatrading.strategy.scalping_market_data import InstrumentSpec
from .models import QualifiedSignal
from .risk import PortfolioRiskManager, RiskDecision
from .commissioning import TestnetCommissioningCaps, LiveFirstCommissioningCaps
from .exchange_feasibility import SymbolRiskInputs


@dataclass(frozen=True, slots=True)
class PortfolioSnapshot:
    equity_usdt: Decimal
    open_risk_usdt: Decimal
    active_position_count: int
    symbol_notional_usdt: Mapping[str, Decimal]
    captured_at_ms: int
    source: str = "INJECTED"
    available_margin_usdt: Decimal | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.equity_usdt, Decimal) or not self.equity_usdt.is_finite() or self.equity_usdt <= 0:
            raise ValueError("equity_usdt must be a positive finite Decimal")
        if not isinstance(self.open_risk_usdt, Decimal) or not self.open_risk_usdt.is_finite() or self.open_risk_usdt < 0:
            raise ValueError("open_risk_usdt must be a non-negative finite Decimal")
        if (isinstance(self.active_position_count, bool)
                or not isinstance(self.active_position_count, int) or self.active_position_count < 0):
            raise ValueError("active_position_count must be a non-negative integer")
        normalized = {key.strip().upper(): value for key, value in self.symbol_notional_usdt.items()}
        if any(not isinstance(value, Decimal) or not value.is_finite() or value < 0 for value in normalized.values()):
            raise ValueError("symbol_notional_usdt values must be non-negative finite Decimal")
        object.__setattr__(self, "symbol_notional_usdt", normalized)
        if isinstance(self.captured_at_ms, bool) or not isinstance(self.captured_at_ms, int) or self.captured_at_ms <= 0:
            raise ValueError("captured_at_ms must be a positive integer")
        if not isinstance(self.source, str) or not self.source.strip():
            raise ValueError("portfolio snapshot source must be non-empty")
        if self.available_margin_usdt is not None and (
            not isinstance(self.available_margin_usdt, Decimal)
            or not self.available_margin_usdt.is_finite() or self.available_margin_usdt < 0
        ):
            raise ValueError("available_margin_usdt must be a non-negative finite Decimal or None")


@dataclass(frozen=True, slots=True)
class SignalRouteResult:
    signal_id: str
    risk: RiskDecision
    execution: ExecutionResult | None


class MultiPairExecutionCoordinator:
    """One global risk manager and executor for independently analyzed symbols."""
    def __init__(self, *, instruments: Mapping[str, InstrumentSpec],
                 risk_manager: PortfolioRiskManager, execution_service: ExecutionService,
                 ledger: ExecutionLedger, allow_empty_instruments: bool = False,
                 testnet_commissioning_caps: TestnetCommissioningCaps | None = None,
                 live_first_caps: LiveFirstCommissioningCaps | None = None) -> None:
        self._lock = RLock()
        self._instruments = {key.strip().upper(): value for key, value in instruments.items()}
        if (not self._instruments and not allow_empty_instruments) or any(
            key != value.symbol for key, value in self._instruments.items()
        ):
            raise ValueError("instruments must be a non-empty map keyed by each exact InstrumentSpec.symbol")
        self.risk_manager = risk_manager
        self.testnet_commissioning_caps = testnet_commissioning_caps
        self.live_first_caps = live_first_caps
        self.execution_service = execution_service
        self.ledger = ledger

    @property
    def symbols(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._instruments))

    def update_universe(self, instruments: Mapping[str, InstrumentSpec]) -> None:
        prepared = {key.strip().upper(): value for key, value in instruments.items()}
        if not prepared or any(key != value.symbol for key, value in prepared.items()):
            raise ValueError("updated instruments must be non-empty and keyed by exact symbol")
        with self._lock:
            self._instruments = prepared

    def _entry_conflict(self, signal: QualifiedSignal) -> str | None:
        """Fail closed on another managed/pending entry until scale-in is TESTNET-qualified.

        Same-side Hedge Mode additions and all additions to a One-way position remain
        disabled. Opposite Hedge Mode exposure is allowed only when the existing lot
        proves that the account is already operating in Hedge Mode.
        """
        for row in self.ledger.list_managed_positions(status="OPEN"):
            if str(row.get("symbol", "")).upper() != signal.symbol:
                continue
            position_side = str(row.get("position_side", "")).upper()
            if position_side == "BOTH":
                return "ONE_WAY_SYMBOL_POSITION_ALREADY_OPEN"
            if position_side == signal.side:
                return "SAME_SIDE_SCALE_IN_DISABLED_PENDING_TESTNET_QUALIFICATION"

        pending_statuses = (
            "CLAIMED", "ENTRY_PENDING", "SUBMISSION_UNKNOWN",
            "ENTRY_PARTIALLY_OR_FULLY_FILLED",
        )
        for intent in self.ledger.list_intents(pending_statuses):
            if (str(intent.get("symbol", "")).upper() == signal.symbol
                    and str(intent.get("signal_id", "")) != signal.signal_id):
                return "SYMBOL_ENTRY_REQUIRES_RECONCILIATION"
        return None

    def route(self, signal: QualifiedSignal, portfolio: PortfolioSnapshot,
              *, symbol_risk_inputs: SymbolRiskInputs | None = None) -> SignalRouteResult:
        if not isinstance(signal, QualifiedSignal) or not isinstance(portfolio, PortfolioSnapshot):
            raise TypeError("route requires QualifiedSignal and PortfolioSnapshot")
        execution_config = self.execution_service.config
        if execution_config.mode.value == "LIVE" and self.live_first_caps is not None:
            violation = self.live_first_caps.violation(
                self.risk_manager.config, equity_usdt=portfolio.equity_usdt,
            )
            if violation:
                blocked = RiskDecision(False, violation)
                self.ledger.record_event(
                    "SIGNAL_REJECTED", signal_id=signal.signal_id, symbol=signal.symbol,
                    detail={"reason": violation, "gate": "EFFECTIVE_LIVE_FIRST_RISK"},
                )
                return SignalRouteResult(signal.signal_id, blocked, None)
        if execution_config.mode.value == "TESTNET" and self.testnet_commissioning_caps is not None:
            # Recheck at the last synchronous route boundary. Telegram risk changes
            # during asynchronous account I/O must not escape startup CLI checks.
            violation = self.testnet_commissioning_caps.violation(
                self.risk_manager.config, equity_usdt=portfolio.equity_usdt,
            )
            if violation:
                blocked = RiskDecision(False, violation)
                self.ledger.record_event(
                    "SIGNAL_REJECTED", signal_id=signal.signal_id, symbol=signal.symbol,
                    detail={"reason": violation, "gate": "EFFECTIVE_TESTNET_COMMISSIONING_RISK"},
                )
                return SignalRouteResult(signal.signal_id, blocked, None)
        if execution_config.mode.value != "PAPER":
            conflict = self._entry_conflict(signal)
            if conflict:
                blocked = RiskDecision(False, conflict)
                self.ledger.record_event(
                    "SIGNAL_REJECTED", signal_id=signal.signal_id, symbol=signal.symbol,
                    detail={"reason": conflict, "gate": "PRE_RISK_ENTRY_ADMISSION"},
                )
                return SignalRouteResult(signal.signal_id, blocked, None)
        if execution_config.mode.value != "PAPER" and execution_config.require_account_readiness:
            ready, reasons = self.ledger.execution_readiness(
                now_ms=time.time_ns() // 1_000_000,
                max_reconciliation_age_ms=execution_config.max_account_snapshot_age_ms,
            )
            if not ready:
                blocked = RiskDecision(False, "ACCOUNT_NOT_READY:" + ",".join(reasons))
                self.ledger.record_event("SIGNAL_REJECTED", signal_id=signal.signal_id,
                                         symbol=signal.symbol, detail={"reason": blocked.reason})
                return SignalRouteResult(signal.signal_id, blocked, None)
        if execution_config.mode.value != "PAPER":
            if symbol_risk_inputs is None:
                blocked = RiskDecision(False, "ACCOUNT_SPECIFIC_LEVERAGE_AND_COMMISSION_INPUTS_REQUIRED")
                self.ledger.record_event("SIGNAL_REJECTED", signal_id=signal.signal_id,
                                         symbol=signal.symbol, detail={"reason": blocked.reason})
                return SignalRouteResult(signal.signal_id, blocked, None)
            if portfolio.available_margin_usdt is None or portfolio.available_margin_usdt <= 0:
                blocked = RiskDecision(False, "ACCOUNT_AVAILABLE_MARGIN_REQUIRED")
                self.ledger.record_event("SIGNAL_REJECTED", signal_id=signal.signal_id,
                                         symbol=signal.symbol, detail={"reason": blocked.reason})
                return SignalRouteResult(signal.signal_id, blocked, None)
        with self._lock:
            instrument = self._instruments.get(signal.symbol)
            if instrument is None:
                risk = RiskDecision(False, "SYMBOL_NOT_IN_ACTIVE_UNIVERSE")
                self.ledger.record_event("SIGNAL_REJECTED", signal_id=signal.signal_id,
                                         symbol=signal.symbol, detail={"reason": risk.reason})
                return SignalRouteResult(signal.signal_id, risk, None)
            client_id = self.ledger.deterministic_client_id(signal.signal_id, "ENTRY")
            risk = self.risk_manager.size_signal(
                signal, instrument, equity_usdt=portfolio.equity_usdt,
                open_risk_usdt=portfolio.open_risk_usdt,
                active_position_count=portfolio.active_position_count,
                existing_symbol_notional_usdt=portfolio.symbol_notional_usdt.get(signal.symbol, Decimal("0")),
                available_margin_usdt=portfolio.available_margin_usdt,
                symbol_risk_inputs=symbol_risk_inputs,
                client_order_id=client_id,
            )
            if not risk.accepted or risk.plan is None:
                self.ledger.record_event("SIGNAL_REJECTED", signal_id=signal.signal_id,
                                         symbol=signal.symbol, detail={"reason": risk.reason})
                return SignalRouteResult(signal.signal_id, risk, None)
            reservation = self.ledger.reserve_portfolio_risk(
                signal_id=signal.signal_id,
                symbol=signal.symbol,
                risk_usdt=risk.plan.risk_usdt,
                notional_usdt=risk.plan.notional_usdt,
                equity_usdt=portfolio.equity_usdt,
                exchange_open_risk_usdt=portfolio.open_risk_usdt,
                exchange_active_position_count=portfolio.active_position_count,
                max_positions=self.risk_manager.config.max_positions,
                max_portfolio_open_risk_pct=self.risk_manager.config.max_portfolio_open_risk_pct,
                exchange_symbol_notional_usdt=portfolio.symbol_notional_usdt.get(
                    signal.symbol, Decimal("0"),
                ),
                max_symbol_notional_usdt=(
                    portfolio.equity_usdt
                    * self.risk_manager.config.max_symbol_notional_pct_equity
                    / Decimal("100")
                    * Decimal(risk.plan.leverage)
                ),
            )
            if not reservation.accepted:
                blocked = RiskDecision(False, reservation.reason)
                self.ledger.record_event(
                    "SIGNAL_REJECTED", signal_id=signal.signal_id, symbol=signal.symbol,
                    detail={"reason": reservation.reason,
                            "active_reserved_risk_usdt": str(reservation.active_reserved_risk_usdt),
                            "active_reserved_symbol_notional_usdt": str(
                                reservation.active_reserved_symbol_notional_usdt
                            )},
                )
                return SignalRouteResult(signal.signal_id, blocked, None)
            if reservation.duplicate:
                # An active reservation may represent a crash between reserve/claim/POST.
                # Never resubmit until the intent and exchange state have been reconciled.
                blocked = RiskDecision(False, "ACTIVE_SIGNAL_RESERVATION_REQUIRES_RECONCILIATION")
                self.ledger.record_event(
                    "DUPLICATE_RESERVATION_BLOCKED", signal_id=signal.signal_id,
                    symbol=signal.symbol,
                    detail={"reserved_risk_usdt": str(reservation.reserved_risk_usdt),
                            "reserved_symbol_notional_usdt": str(
                                reservation.active_reserved_symbol_notional_usdt
                            )},
                )
                return SignalRouteResult(signal.signal_id, blocked, None)
            try:
                execution = self.execution_service.submit(risk.plan)
            except Exception as exc:
                # Ambiguous exchange outcomes must retain the reservation until reconciliation.
                self.ledger.record_event(
                    "RISK_RESERVATION_RETAINED", signal_id=signal.signal_id,
                    symbol=signal.symbol, detail={"error": str(exc)},
                )
                raise
            mode = self.execution_service.config.mode.value
            if (mode == "PAPER" and execution.status != "PAPER_PROTECTED") or execution.status in {
                "ENTRY_REJECTED", "ENTRY_EXPIRED", "ENTRY_CANCELED", "ENTRY_CANCELLED",
                "ENTRY_BLOCKED_ACCOUNT_NOT_READY", "ENTRY_BLOCKED_EXISTING_POSITION",
            }:
                self.ledger.release_risk_reservation(
                    signal.signal_id, f"NO_ACTIVE_EXCHANGE_POSITION:{execution.status}",
                )
            self.ledger.record_event("SIGNAL_ROUTED", signal_id=signal.signal_id,
                                     symbol=signal.symbol,
                                     detail={"risk_usdt": str(risk.plan.risk_usdt),
                                             "quantity": str(risk.plan.quantity),
                                             "reservation": reservation.reason,
                                             "execution_status": execution.status})
            return SignalRouteResult(signal.signal_id, risk, execution)

    def release_position_risk_reservation(self, signal_id: str, reason: str) -> bool:
        """Release risk only after a reconciler confirms the position is flat/terminal."""
        released = self.ledger.release_risk_reservation(signal_id, reason)
        if released:
            self.ledger.record_event("RISK_RESERVATION_RELEASED", signal_id=signal_id,
                                     detail={"reason": reason})
        return released
