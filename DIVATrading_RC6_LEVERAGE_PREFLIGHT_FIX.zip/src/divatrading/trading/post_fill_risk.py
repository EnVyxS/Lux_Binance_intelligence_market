"""Exchange-fill risk check independent of strategy scores and order acknowledgments.

Checks per-unit risk against the exact original coordinator reservation.  A filled
entry is *not* automatically closed on breach: protective STOP/TP must remain in
place, while the durable operator halt prevents further risk accumulation.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from divatrading.trading.models import TradePlan


@dataclass(frozen=True, slots=True)
class PostFillRiskAudit:
    status: str
    actual_risk_usdt: Decimal | None
    allocated_risk_usdt: Decimal
    fill_price: Decimal | None
    executed_quantity: Decimal

    @property
    def safe_for_new_entries(self) -> bool:
        return self.status == "WITHIN_RESERVED_RISK"


def assess_post_fill_risk(
    plan: TradePlan, *, executed_quantity: Decimal, avg_fill_price: object,
) -> PostFillRiskAudit:
    """Audit *confirmed cumulative* fill using stop distance + pro-rata reserved costs.

    Never infer an unreported fill price from the requested entry or mark price;
    either is potentially different from the exchange's executable price.
    """
    if not isinstance(executed_quantity, Decimal) or not executed_quantity.is_finite() \
            or executed_quantity <= 0 or executed_quantity > plan.quantity:
        raise ValueError("POST_FILL_QUANTITY_INVALID")
    fraction = executed_quantity / plan.quantity
    allowed = plan.risk_usdt * fraction
    try:
        fill = Decimal(str(avg_fill_price))
    except (InvalidOperation, TypeError, ValueError):
        fill = None
    if fill is None or not fill.is_finite() or fill <= 0:
        return PostFillRiskAudit("FILL_PRICE_UNVERIFIED", None, allowed, None, executed_quantity)

    signal = plan.signal
    if signal.side == "LONG":
        stop_distance = fill - signal.stop_loss
        reward_distance = signal.take_profit - fill
    else:
        stop_distance = signal.stop_loss - fill
        reward_distance = fill - signal.take_profit
    if stop_distance <= 0 or reward_distance <= 0:
        return PostFillRiskAudit("FILL_PRICE_INVALIDATES_STOP_OR_TARGET", None, allowed, fill, executed_quantity)

    costs = (plan.fee_reserve_usdt + plan.slippage_reserve_usdt +
             plan.funding_reserve_usdt) * fraction
    actual_risk = executed_quantity * stop_distance + costs
    if actual_risk > allowed:
        return PostFillRiskAudit("ACTUAL_FILL_RISK_EXCEEDS_RESERVATION", actual_risk, allowed,
                                 fill, executed_quantity)
    return PostFillRiskAudit("WITHIN_RESERVED_RISK", actual_risk, allowed, fill, executed_quantity)
