"""Read-only Telegram health checks and non-authoritative dispatch notifications.

No Binance account/order access. Secrets never appear in exception messages.
Notification failures must never cause an order retry or make unprotected
positions invisible to the main account supervision loop.
"""
from __future__ import annotations

import httpx


class TelegramOperationalNotifier:
    def __init__(self, token: str, owner_id: str, *, timeout_seconds: float = 7.0) -> None:
        if not token or not token.strip() or not owner_id or not owner_id.isdigit():
            raise ValueError("Telegram bot token and numeric private owner ID are required")
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("Telegram timeout must be between 1 and 30 seconds")
        self._token = token
        self._owner_id = owner_id
        self._timeout = timeout_seconds

    def _invoke(self, method: str, *, params: dict | None = None, payload: dict | None = None) -> dict:
        url = f"https://api.telegram.org/bot{self._token}/{method}"
        try:
            with httpx.Client(timeout=self._timeout, follow_redirects=False) as client:
                response = (client.post(url, json=payload) if payload is not None
                            else client.get(url, params=params))
                response.raise_for_status()
                data = response.json()
            if not isinstance(data, dict) or data.get("ok") is not True:
                raise RuntimeError("API_REJECTED")
            return data
        except Exception:
            # httpx's default exception often embeds URL including private token.
            raise RuntimeError(f"TELEGRAM_{method.upper()}_FAILED (credentials redacted)") from None

    def verify_connection(self) -> dict[str, str | bool]:
        bot = self._invoke("getMe").get("result") or {}
        chat = self._invoke("getChat", params={"chat_id": self._owner_id}).get("result") or {}
        webhook = self._invoke("getWebhookInfo").get("result") or {}
        if webhook.get("url"):
            raise RuntimeError("TELEGRAM_WEBHOOK_CONFLICT: remove webhook before long polling")
        if not bot.get("is_bot") or str(chat.get("id")) != self._owner_id or chat.get("type") != "private":
            raise RuntimeError("TELEGRAM_IDENTITY_OR_PRIVATE_CHAT_NOT_CONFIRMED")
        return {"ok": True, "bot_username": str(bot.get("username") or ""),
                "owner_chat_valid": True}

    def notify_dispatch(self, *, symbol: str, timeframe: str, side: str, status: str,
                        reason: str, signal_id: str) -> None:
        """Delivery is best-effort and intentionally occurs AFTER durable order handling."""
        if status not in {"DISPATCHED", "REQUIRES_RECONCILIATION"}:
            return
        if not all(isinstance(v, str) for v in (symbol, timeframe, side, reason, signal_id)):
            raise TypeError("Invalid dispatch notification values")
        # Plain text, not Markdown/HTML; avoid formatting injections.
        body = (f"DIVATrading order dispatch\n"
                f"{symbol[:25]} / {timeframe[:10]} / {side[:10]}\n"
                f"State: {status}\nDetails: {reason[:180]}\n"
                f"Signal: {signal_id[:80]}\n"
                "Check Binance exchange orders/positions for authoritative status.")
        self._invoke("sendMessage", payload={"chat_id": self._owner_id, "text": body,
                                              "disable_web_page_preview": True})
