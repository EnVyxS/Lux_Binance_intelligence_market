"""Stable, symbol-agnostic contracts between strategy, risk and execution."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Literal

TradeSide = Literal["LONG", "SHORT"]
EntryType = Literal["MARKET", "LIMIT", "LIMIT_IOC"]


def _positive(value: Decimal, name: str) -> None:
    if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
        raise ValueError(f"{name} must be a positive finite Decimal")


@dataclass(frozen=True, slots=True)
class QualifiedSignal:
    """A strategy-approved candidate. Strategy approval is upstream, never inferred here."""
    signal_id: str
    symbol: str
    side: TradeSide
    entry_type: EntryType
    entry_price: Decimal
    stop_loss: Decimal
    take_profit: Decimal
    timeframe: str
    strategy_id: str
    created_at_ms: int
    reason_codes: tuple[str, ...] = ()
    score: int | None = None
    minimum_net_rr: Decimal | None = None

    def __post_init__(self) -> None:
        for name in ("signal_id", "symbol", "timeframe", "strategy_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        object.__setattr__(self, "symbol", self.symbol.strip().upper())
        if self.side not in ("LONG", "SHORT"):
            raise ValueError("side must be LONG or SHORT")
        if self.entry_type not in ("MARKET", "LIMIT", "LIMIT_IOC"):
            raise ValueError("entry_type must be MARKET, LIMIT or LIMIT_IOC")
        for name in ("entry_price", "stop_loss", "take_profit"):
            _positive(getattr(self, name), name)
        if self.side == "LONG" and not self.stop_loss < self.entry_price < self.take_profit:
            raise ValueError("LONG price geometry must satisfy stop_loss < entry < take_profit")
        if self.side == "SHORT" and not self.take_profit < self.entry_price < self.stop_loss:
            raise ValueError("SHORT price geometry must satisfy take_profit < entry < stop_loss")
        if isinstance(self.created_at_ms, bool) or not isinstance(self.created_at_ms, int) or self.created_at_ms <= 0:
            raise ValueError("created_at_ms must be a positive integer")
        object.__setattr__(self, "reason_codes", tuple(self.reason_codes))
        if self.score is not None and (
            isinstance(self.score, bool) or not isinstance(self.score, int) or not 0 <= self.score <= 100
        ):
            raise ValueError("score must be an integer from 0 to 100 or None")
        if self.minimum_net_rr is not None:
            _positive(self.minimum_net_rr, "minimum_net_rr")

    @property
    def reward_risk(self) -> Decimal:
        risk = abs(self.entry_price - self.stop_loss)
        reward = abs(self.take_profit - self.entry_price)
        return reward / risk


@dataclass(frozen=True, slots=True)
class TradePlan:
    signal: QualifiedSignal
    quantity: Decimal
    notional_usdt: Decimal
    risk_usdt: Decimal
    margin_estimate_usdt: Decimal
    leverage: int
    client_order_id: str
    margin_mode: str = "ISOLATED"
    fee_reserve_usdt: Decimal = Decimal("0")
    slippage_reserve_usdt: Decimal = Decimal("0")
    funding_reserve_usdt: Decimal = Decimal("0")
    maintenance_margin_estimate_usdt: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        for name in ("quantity", "notional_usdt", "risk_usdt", "margin_estimate_usdt"):
            _positive(getattr(self, name), name)
        if isinstance(self.leverage, bool) or not 1 <= self.leverage <= 125:
            raise ValueError("leverage must be between 1 and 125")
        if self.margin_mode not in {"ISOLATED", "CROSSED"}:
            raise ValueError("margin_mode must be ISOLATED or CROSSED")
        for name in ("fee_reserve_usdt", "slippage_reserve_usdt",
                     "funding_reserve_usdt", "maintenance_margin_estimate_usdt"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
                raise ValueError(f"{name} must be a finite non-negative Decimal")
        if not self.client_order_id or len(self.client_order_id) > 36:
            raise ValueError("client_order_id must contain 1..36 characters")
