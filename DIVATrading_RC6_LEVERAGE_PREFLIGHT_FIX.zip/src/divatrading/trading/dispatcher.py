"""Durable autonomous SMC-to-entry dispatch orchestration.

A qualified signal is claimed in SQLite before the dispatcher performs any account
or exchange I/O. Final sizing and atomic risk reservation remain authoritative in
MultiPairExecutionCoordinator; this module never recomputes quantity itself.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from decimal import Decimal
from threading import RLock
from typing import Any, Protocol

from divatrading.execution.account_state import BinanceAccountStateService
from divatrading.execution.ledger import ExecutionLedger
from .coordinator import MultiPairExecutionCoordinator, PortfolioSnapshot, SignalRouteResult
from .models import QualifiedSignal
from .exchange_feasibility import SymbolRiskInputs, parse_leverage_brackets, SymbolCommission


class PortfolioSnapshotProvider(Protocol):
    def capture(self) -> PortfolioSnapshot: ...


@dataclass(frozen=True, slots=True)
class PaperPortfolioSnapshotProvider:
    """Deterministic starting equity for PAPER; open risk is held in SQLite reservations."""
    equity_usdt: Decimal = Decimal("1000")
    clock_ms: Any = None

    def __post_init__(self) -> None:
        if not isinstance(self.equity_usdt, Decimal) or not self.equity_usdt.is_finite() or self.equity_usdt <= 0:
            raise ValueError("PAPER equity must be a positive finite Decimal")

    def capture(self) -> PortfolioSnapshot:
        clock = self.clock_ms or (lambda: time.time_ns() // 1_000_000)
        return PortfolioSnapshot(
            equity_usdt=self.equity_usdt,
            open_risk_usdt=Decimal("0"),
            active_position_count=0,
            symbol_notional_usdt={},
            captured_at_ms=int(clock()),
            source="PAPER_SIMULATOR",
        )


class BinancePortfolioSnapshotProvider:
    """Captures exchange-truth balances, open positions and notionals for one signal."""
    def __init__(self, account_state: BinanceAccountStateService, *,
                 ledger: ExecutionLedger | None = None, clock_ms: Any = None) -> None:
        self.account_state = account_state
        self.ledger = ledger
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)

    def capture(self) -> PortfolioSnapshot:
        snapshot = self.account_state.capture()
        if self.ledger is None:
            # Compatibility fallback: without local ownership data, count every
            # exchange position at absolute notional and avoid assuming its stop risk.
            symbol_notional: dict[str, Decimal] = {}
            for position in snapshot.positions:
                symbol_notional[position.symbol] = (
                    symbol_notional.get(position.symbol, Decimal("0")) + abs(position.notional)
                )
            return PortfolioSnapshot(
                equity_usdt=snapshot.equity,
                open_risk_usdt=snapshot.open_risk_usdt,
                active_position_count=snapshot.active_position_count,
                symbol_notional_usdt=symbol_notional,
                captured_at_ms=int(self.clock_ms()),
                source="BINANCE_REST_CONSERVATIVE_UNATTRIBUTED",
                available_margin_usdt=snapshot.available_balance,
            )

        # DIVA-owned positions are represented by their durable stop-distance risk
        # reservations, not by full exchange notional a second time. A group is
        # considered owned only when its complete quantity maps to OPEN local lots
        # and every lot still has an active reservation. Any mismatch is treated as
        # external/unattributed and remains fully conservative.
        managed = self.ledger.list_managed_positions(status="OPEN")
        reservations = {
            row["signal_id"]: row
            for row in self.ledger.list_risk_reservations(status="ACTIVE")
        }
        # Locally owned entry orders are represented by their active reservation;
        # owned protective orders reduce exposure and must not be added again.
        local_order_roles: dict[str, str] = {}
        for order in self.ledger.list_all_execution_orders():
            local_order_roles[str(order["client_id"])] = str(order["role"]).upper()
            payload = order.get("payload", {})
            if isinstance(payload, dict):
                for key in ("clientOrderId", "origClientOrderId", "clientAlgoId", "algoClientId"):
                    value = payload.get(key)
                    if value:
                        local_order_roles[str(value)] = str(order["role"]).upper()

        external_risk = Decimal("0")
        external_count = 0
        external_notional: dict[str, Decimal] = {}

        def add_external_order(order: dict[str, Any], *, algo: bool) -> None:
            nonlocal external_risk, external_count
            client_id = str(
                order.get("clientAlgoId" if algo else "clientOrderId")
                or order.get("algoClientId" if algo else "origClientOrderId")
                or ""
            )
            if client_id in local_order_roles:
                return
            if str(order.get("reduceOnly", "false")).lower() == "true" or \
                    str(order.get("closePosition", "false")).lower() == "true":
                return
            symbol = str(order.get("symbol", "")).upper()
            if not symbol:
                raise RuntimeError("UNATTRIBUTED_OPEN_ORDER_WITHOUT_SYMBOL")
            quantity_raw = order.get("origQty", order.get("quantity"))
            if quantity_raw in (None, ""):
                raise RuntimeError(f"UNPRICED_EXTERNAL_OPEN_ORDER:{symbol}:{client_id or 'UNKNOWN'}")
            quantity = abs(Decimal(str(quantity_raw)))
            executed = abs(Decimal(str(order.get("executedQty", "0"))))
            remaining = max(Decimal("0"), quantity - executed)
            if remaining == 0:
                return
            price_raw = order.get("price") or order.get("stopPrice") or order.get("triggerPrice")
            if price_raw in (None, "", "0", 0):
                raise RuntimeError(f"UNPRICED_EXTERNAL_OPEN_ORDER:{symbol}:{client_id or 'UNKNOWN'}")
            price = Decimal(str(price_raw))
            if not price.is_finite() or not quantity.is_finite() or price <= 0:
                raise RuntimeError(f"INVALID_EXTERNAL_OPEN_ORDER:{symbol}:{client_id or 'UNKNOWN'}")
            notional = remaining * price
            external_risk += notional
            external_count += 1
            external_notional[symbol] = external_notional.get(symbol, Decimal("0")) + notional
        for position in snapshot.positions:
            symbol = position.symbol.upper()
            exchange_position_side = str(position.position_side).upper()
            if exchange_position_side in {"LONG", "SHORT"}:
                direction = exchange_position_side
            else:
                direction = "LONG" if position.quantity > 0 else "SHORT"
            candidates = [
                row for row in managed
                if str(row.get("symbol", "")).upper() == symbol
                and (
                    str(row.get("position_side", "")).upper() == exchange_position_side
                    or (
                        exchange_position_side == "BOTH"
                        and str(row.get("position_side", "")).upper() == "BOTH"
                        and str(row.get("signal_side", "")).upper() == direction
                    )
                )
            ]
            owned_quantity = sum(
                (abs(Decimal(str(row["quantity"]))) for row in candidates), Decimal("0")
            )
            fully_reserved = bool(candidates) and all(
                row["signal_id"] in reservations
                and reservations[row["signal_id"]].get("symbol", "").upper() == symbol
                for row in candidates
            )
            if fully_reserved and owned_quantity == abs(position.quantity):
                continue
            exposure = abs(position.notional)
            external_risk += exposure
            external_count += 1
            external_notional[symbol] = external_notional.get(symbol, Decimal("0")) + exposure

        for order in snapshot.open_standard_orders:
            add_external_order(order, algo=False)
        for order in snapshot.open_algo_orders:
            add_external_order(order, algo=True)

        return PortfolioSnapshot(
            equity_usdt=snapshot.equity,
            open_risk_usdt=external_risk,
            active_position_count=external_count,
            symbol_notional_usdt=external_notional,
            captured_at_ms=int(self.clock_ms()),
            source="BINANCE_REST_WITH_DIVA_OWNERSHIP_NETTING",
            available_margin_usdt=snapshot.available_balance,
        )

    def get_symbol_risk_inputs(self, symbol: str) -> SymbolRiskInputs:
        """Read account-specific leverage tiers and commission for one symbol."""
        client = self.account_state.client
        required = ("get_leverage_brackets", "get_commission_rate")
        if any(not callable(getattr(client, name, None)) for name in required):
            raise RuntimeError("BINANCE_ACCOUNT_RISK_ENDPOINTS_UNAVAILABLE")
        normalized = symbol.strip().upper()
        brackets = parse_leverage_brackets(client.get_leverage_brackets(normalized), normalized)
        commission = SymbolCommission.from_binance(client.get_commission_rate(normalized))
        return SymbolRiskInputs(normalized, brackets, commission, int(self.clock_ms()))


@dataclass(frozen=True, slots=True)
class AutonomousDispatcherConfig:
    max_signal_age_ms: int = 30_000
    max_snapshot_age_ms: int = 30_000
    max_future_skew_ms: int = 5_000

    def __post_init__(self) -> None:
        for name in ("max_signal_age_ms", "max_snapshot_age_ms"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1_000:
                raise ValueError(f"{name} must be an integer >= 1000")
        if isinstance(self.max_future_skew_ms, bool) or not isinstance(self.max_future_skew_ms, int) or self.max_future_skew_ms < 0:
            raise ValueError("max_future_skew_ms must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class DispatchResult:
    signal_id: str
    status: str
    route: SignalRouteResult | None
    reason: str = ""
    duplicate: bool = False


class AutonomousEntryDispatcher:
    """At-most-once bridge from qualified SMC signals to global risk/execution."""
    def __init__(self, *, coordinator: MultiPairExecutionCoordinator,
                 snapshot_provider: PortfolioSnapshotProvider,
                 ledger: ExecutionLedger | None = None,
                 config: AutonomousDispatcherConfig | None = None,
                 clock_ms: Any = None) -> None:
        self.coordinator = coordinator
        self.snapshot_provider = snapshot_provider
        self.ledger = ledger or coordinator.ledger
        if self.ledger is not coordinator.ledger:
            raise ValueError("dispatcher and coordinator must share the same durable ExecutionLedger")
        self.config = config or AutonomousDispatcherConfig()
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._lock = RLock()

    @staticmethod
    def _signal_payload(signal: QualifiedSignal) -> dict[str, Any]:
        return {
            "signal_id": signal.signal_id,
            "symbol": signal.symbol,
            "side": signal.side,
            "entry_type": signal.entry_type,
            "entry_price": str(signal.entry_price),
            "stop_loss": str(signal.stop_loss),
            "take_profit": str(signal.take_profit),
            "timeframe": signal.timeframe,
            "strategy_id": signal.strategy_id,
            "created_at_ms": signal.created_at_ms,
            "reason_codes": list(signal.reason_codes),
            "score": signal.score,
        }

    def dispatch(self, signal: QualifiedSignal) -> DispatchResult:
        if not isinstance(signal, QualifiedSignal):
            raise TypeError("dispatch requires a QualifiedSignal")
        now = int(self.clock_ms())
        payload = self._signal_payload(signal)
        # Durable de-duplication happens before the account snapshot's REST I/O.
        created = self.ledger.claim_signal_dispatch(
            signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side, payload=payload,
        )
        if not created:
            existing = self.ledger.get_signal_dispatch(signal.signal_id) or {}
            status = str(existing.get("status", "DUPLICATE"))
            self.ledger.record_event(
                "AUTONOMOUS_DISPATCH_DUPLICATE", signal_id=signal.signal_id,
                symbol=signal.symbol, detail={"existing_status": status},
            )
            return DispatchResult(signal.signal_id, status, None,
                                  "DURABLE_SIGNAL_ALREADY_CLAIMED", duplicate=True)

        try:
            age = now - signal.created_at_ms
            if age < -self.config.max_future_skew_ms:
                raise ValueError("SIGNAL_TIMESTAMP_TOO_FAR_IN_FUTURE")
            if age > self.config.max_signal_age_ms:
                raise ValueError("SIGNAL_EXPIRED_BEFORE_DISPATCH")
            halted, halt_reason = self.ledger.entries_halted()
            if halted:
                raise RuntimeError(f"ENTRIES_HALTED:{halt_reason or 'UNSPECIFIED'}")

            self.ledger.update_signal_dispatch(signal.signal_id, "SNAPSHOT_PENDING")
            portfolio = self.snapshot_provider.capture()
            # Measure snapshot and signal age after the REST snapshot completes. Using
            # the pre-request timestamp can misclassify a newly captured snapshot as
            # future-dated and can route a signal that expired during a slow request.
            decision_now = int(self.clock_ms())
            snapshot_age = decision_now - portfolio.captured_at_ms
            if snapshot_age < -self.config.max_future_skew_ms or snapshot_age > self.config.max_snapshot_age_ms:
                raise RuntimeError("PORTFOLIO_SNAPSHOT_STALE_OR_FUTURE")
            post_snapshot_signal_age = decision_now - signal.created_at_ms
            if post_snapshot_signal_age < -self.config.max_future_skew_ms:
                raise ValueError("SIGNAL_TIMESTAMP_TOO_FAR_IN_FUTURE")
            if post_snapshot_signal_age > self.config.max_signal_age_ms:
                raise ValueError("SIGNAL_EXPIRED_DURING_PORTFOLIO_SNAPSHOT")
            halted, halt_reason = self.ledger.entries_halted()
            if halted:
                raise RuntimeError(f"ENTRIES_HALTED_AFTER_SNAPSHOT:{halt_reason or 'UNSPECIFIED'}")
            symbol_risk_inputs = None
            risk_input_provider = getattr(self.snapshot_provider, "get_symbol_risk_inputs", None)
            if callable(risk_input_provider):
                symbol_risk_inputs = risk_input_provider(signal.symbol)
                risk_check_now = int(self.clock_ms())
                risk_age = risk_check_now - symbol_risk_inputs.captured_at_ms
                if risk_age < -self.config.max_future_skew_ms or risk_age > self.config.max_snapshot_age_ms:
                    raise RuntimeError("ACCOUNT_SYMBOL_RISK_INPUTS_STALE_OR_FUTURE")
            if signal.symbol not in self.coordinator.symbols:
                raise RuntimeError("SYMBOL_NOT_IN_ACTIVE_UNIVERSE")

            self.ledger.update_signal_dispatch(signal.signal_id, "RISK_ROUTING", result={
                "snapshot_source": portfolio.source,
                "snapshot_captured_at_ms": portfolio.captured_at_ms,
                "snapshot_age_ms": max(0, snapshot_age),
                "signal_age_at_risk_routing_ms": max(0, post_snapshot_signal_age),
            })
            routed = self.coordinator.route(signal, portfolio, symbol_risk_inputs=symbol_risk_inputs)
            result_payload: dict[str, Any] = {
                "risk_accepted": routed.risk.accepted,
                "risk_reason": routed.risk.reason,
                "snapshot_source": portfolio.source,
                "snapshot_captured_at_ms": portfolio.captured_at_ms,
                "snapshot_age_ms": max(0, snapshot_age),
                "signal_age_at_risk_routing_ms": max(0, post_snapshot_signal_age),
            }
            if routed.risk.plan is not None:
                result_payload.update({
                    "quantity": str(routed.risk.plan.quantity),
                    "notional_usdt": str(routed.risk.plan.notional_usdt),
                    "risk_usdt": str(routed.risk.plan.risk_usdt),
                    "client_order_id": routed.risk.plan.client_order_id,
                })
            if routed.execution is not None:
                result_payload["execution_status"] = routed.execution.status
                result_payload["execution_detail"] = routed.execution.detail
                if routed.execution.duplicate:
                    result_payload["execution_duplicate"] = True
            if not routed.risk.accepted:
                status = "REJECTED"
                reason = routed.risk.reason
            elif routed.execution is None:
                status = "REQUIRES_RECONCILIATION"
                reason = "ROUTE_RETURNED_WITHOUT_EXECUTION_RESULT"
            elif routed.execution.status in {
                "PAPER_ACCEPTED", "PAPER_PROTECTED", "PROTECTED", "ENTRY_PENDING",
            }:
                status = "DISPATCHED"
                reason = routed.execution.status
            else:
                status = "REQUIRES_RECONCILIATION" if routed.execution.status in {
                    "SUBMISSION_UNKNOWN", "PROTECTION_INCOMPLETE", "ENTRY_PARTIALLY_OR_FULLY_FILLED",
                } else "REJECTED"
                reason = routed.execution.status
            self.ledger.update_signal_dispatch(signal.signal_id, status, result=result_payload)
            self.ledger.record_event(
                "AUTONOMOUS_DISPATCH_COMPLETED", signal_id=signal.signal_id,
                symbol=signal.symbol, detail={"status": status, **result_payload},
            )
            return DispatchResult(signal.signal_id, status, routed, reason)
        except Exception as exc:
            error = f"{type(exc).__name__}:{exc}"[:500]
            self.ledger.update_signal_dispatch(
                signal.signal_id, "REQUIRES_RECONCILIATION", error=error,
            )
            self.ledger.record_event(
                "AUTONOMOUS_DISPATCH_FAILED", signal_id=signal.signal_id,
                symbol=signal.symbol, detail={"error": error},
            )
            # Preserve existing manual/operator halt; never clear or overwrite it.
            if self.coordinator.execution_service.config.mode.value != "PAPER":
                self.ledger.set_entries_halted(True, f"Autonomous dispatch failed for {signal.symbol}: {error}")
            return DispatchResult(signal.signal_id, "REQUIRES_RECONCILIATION", None, error)

    async def dispatch_signals(self, signals: tuple[QualifiedSignal, ...] | list[QualifiedSignal]) -> tuple[DispatchResult, ...]:
        """Run synchronous REST/sizing work off the market WebSocket event loop."""
        results: list[DispatchResult] = []
        for signal in signals:
            results.append(await asyncio.to_thread(self.dispatch, signal))
        return tuple(results)
