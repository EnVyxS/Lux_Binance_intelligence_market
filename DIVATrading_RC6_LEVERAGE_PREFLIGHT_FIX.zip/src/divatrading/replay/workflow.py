"""Orchestrate the complete read-only Stage 6B dataset-to-evidence workflow."""

from __future__ import annotations

from decimal import Decimal
import json
import os
from pathlib import Path
from typing import Any

from .analytics import analyze_replay_ledger, write_evidence_analytics_report
from .convergence import analyze_warmup_convergence, write_warmup_convergence_report
from .engine import HistoricalReplayRunner, ReplayConfig
from .manifest import ReplayDatasetManifest, ReplayManifestError, canonical_json, sha256_file, sha256_text
from .quality import audit_replay_manifest_quality, write_dataset_quality_report
from .splits import ReplaySplitError, create_chronological_split_plan
from divatrading.market_data.klines import INTERVAL_MILLISECONDS


class ReplayWorkflowError(ValueError):
    """Raised when the integrated Stage 6B workflow cannot safely proceed."""


class ReplayWorkflowEligibilityError(ReplayWorkflowError):
    """Raised when a quality or provenance gate rejects a trial dataset."""


_STAGE_ORDER = [
    "RAW_SOURCE_QUALITY_AUDIT",
    "STRICT_MANIFEST_AND_SOURCE_ELIGIBILITY",
    "DETERMINISTIC_STAGE6A_REPLAY_WITH_CHECKPOINT_RESUME",
    "STAGE6B2_CHRONOLOGICAL_EVIDENCE_ANALYTICS",
    "STAGE6B3_WARMUP_CONVERGENCE",
    "FINAL_SOURCE_AND_LEDGER_IMMUTABILITY_CHECK",
]


def _sha256_path(path: Path) -> str:
    return sha256_file(path)


def _load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ReplayWorkflowError(f"cannot load {label}: {exc}") from exc
    if not isinstance(value, dict):
        raise ReplayWorkflowError(f"{label} must be a JSON object")
    return value


def _resolve(base: Path, value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ReplayWorkflowError(f"{label} must be a non-empty path string")
    candidate = Path(value)
    return (base / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()


def _validate_schema(payload: dict[str, Any], schema_path: Path, label: str) -> None:
    try:
        from jsonschema import Draft202012Validator
        schema = _load_json(schema_path, f"{label} schema")
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(payload)
    except Exception as exc:
        raise ReplayWorkflowError(f"{label} schema validation failed: {exc}") from exc


def _atomic_write_json(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    raw = json.dumps(payload, sort_keys=True, indent=2, ensure_ascii=False) + "\n"
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except OSError:
        temporary.unlink(missing_ok=True)
        raise


def run_stage6b_workflow(
    plan_path: str | Path,
    report_path: str | Path,
    *,
    output_dir: str | Path | None = None,
    plan_schema_path: str | Path | None = None,
    report_schema_path: str | Path | None = None,
) -> dict[str, Any]:
    """Run quality -> manifest gate -> replay -> analytics -> convergence.

    The function never modifies dataset inputs. It performs each replay through the
    existing Stage 6A checkpoint/resume path so the integrated route exercises restart
    recovery rather than bypassing it. Any failed eligibility or provenance gate stops
    downstream execution and leaves the quality report available for diagnosis.
    """
    plan_file = Path(plan_path).resolve()
    plan = _load_json(plan_file, "workflow plan")
    project_schemas = Path(__file__).resolve().parents[3] / "docs" / "schemas"
    plan_schema = Path(plan_schema_path).resolve() if plan_schema_path else project_schemas / "stage6b_workflow_plan.schema.json"
    report_schema = Path(report_schema_path).resolve() if report_schema_path else project_schemas / "stage6b_workflow_report.schema.json"
    _validate_schema(plan, plan_schema, "Stage 6B workflow plan")

    base = plan_file.parent
    evaluation = plan["evaluation_window"]
    start_ms = evaluation["start_ms"]
    end_ms = evaluation["end_ms_exclusive"]
    if start_ms >= end_ms:
        raise ReplayWorkflowError("evaluation window must be non-empty and end-exclusive")
    evidence_ref = plan["metadata_evidence_ref"].strip()
    replay_mode = plan.get("replay_mode", "STRICT")
    if replay_mode not in {"STRICT", "PROVISIONAL_STRATEGY_EVIDENCE"}:
        raise ReplayWorkflowError(
            "replay_mode must be STRICT or PROVISIONAL_STRATEGY_EVIDENCE"
        )
    provisional_mode = replay_mode == "PROVISIONAL_STRATEGY_EVIDENCE"
    trials_raw = plan["trials"]
    trial_ids = [item["trial_id"] for item in trials_raw]
    if len(set(trial_ids)) != len(trial_ids):
        raise ReplayWorkflowError("trial_id values must be unique")
    out_root = Path(output_dir).resolve() if output_dir else _resolve(base, plan.get("output_dir", "stage6b_workflow_output"), "output_dir")
    report_target = Path(report_path).resolve()
    if report_target == plan_file:
        raise ReplayWorkflowError("workflow report destination cannot overwrite the workflow plan")

    replay_raw = plan.get("replay_config", {})
    max_history = replay_raw.get("max_history_candles", 1000)
    checkpoint_every = replay_raw.get("checkpoint_every_captures", 1000)
    if type(max_history) is not int or not 2 <= max_history <= 2000:
        raise ReplayWorkflowError("replay_config.max_history_candles must be between 2 and 2000")
    if type(checkpoint_every) is not int or checkpoint_every < 1:
        raise ReplayWorkflowError("replay_config.checkpoint_every_captures must be a positive integer")

    trial_context: list[dict[str, Any]] = []
    expected_symbol: str | None = None
    expected_intervals: tuple[str, ...] | None = None
    expected_metadata_sha: str | None = None
    frozen_config_sha: str | None = None
    frozen_code_sha: str | None = None
    frozen_clock_policy = "UTC_KLINE_CLOSE_PLUS_1MS_V1"

    # Resolve and freeze all input identities before starting any engine replay.
    for trial in trials_raw:
        trial_id = trial["trial_id"]
        manifest_path = _resolve(base, trial["manifest"], f"trial {trial_id} manifest")
        root_path = _resolve(base, trial.get("root", str(manifest_path.parent)), f"trial {trial_id} root")
        try:
            manifest_bytes_sha = _sha256_path(manifest_path)
            manifest = ReplayDatasetManifest.load(manifest_path)
        except (OSError, ReplayManifestError) as exc:
            raise ReplayWorkflowError(f"trial {trial_id}: manifest load failed: {exc}") from exc
        source_paths: dict[str, Path] = {}
        source_hashes: dict[str, str] = {}
        for item in manifest.files:
            source_path = (root_path / item.path).resolve()
            if root_path not in source_path.parents:
                raise ReplayWorkflowError(f"trial {trial_id}: source path escapes dataset root")
            source_paths[item.path] = source_path
            source_hashes[item.path] = _sha256_path(source_path)
            if source_hashes[item.path] != item.sha256:
                raise ReplayWorkflowError(f"trial {trial_id}: source hash differs from manifest: {item.path}")
        if manifest.start_open_time_ms > start_ms or manifest.end_open_time_ms < end_ms:
            raise ReplayWorkflowError(f"trial {trial_id}: manifest does not cover the common evaluation window")
        for interval in manifest.intervals:
            step_ms = INTERVAL_MILLISECONDS[interval]
            if start_ms % step_ms or end_ms % step_ms:
                raise ReplayWorkflowError(
                    f"trial {trial_id}: evaluation window is not aligned to active timeframe {interval}"
                )
        try:
            # Mirror Stage 6B.2 split construction before spending time on Stage 6A replay.
            create_chronological_split_plan(
                manifest.start_open_time_ms,
                manifest.end_open_time_ms + 1,
                manifest.intervals,
                target_ratios=(Decimal("0.60"), Decimal("0.20"), Decimal("0.20")),
                terminal_boundary_ms=manifest.end_open_time_ms,
            )
        except ReplaySplitError as exc:
            raise ReplayWorkflowError(f"trial {trial_id}: dataset cannot support the frozen 60/20/20 split: {exc}") from exc
        if expected_symbol is None:
            expected_symbol = manifest.symbol
            expected_intervals = manifest.intervals
            expected_metadata_sha = manifest.metadata.sha256
        elif (manifest.symbol, manifest.intervals, manifest.metadata.sha256) != (
            expected_symbol, expected_intervals, expected_metadata_sha
        ):
            raise ReplayWorkflowError("all trials must share symbol, native intervals and metadata snapshot")
        if out_root == root_path or root_path in out_root.parents:
            raise ReplayWorkflowError(f"trial {trial_id}: output directory cannot be inside dataset root")
        if root_path == report_target or root_path in report_target.parents:
            raise ReplayWorkflowError(f"trial {trial_id}: workflow report cannot be written inside dataset root")
        if report_target in source_paths.values() or report_target == manifest_path:
            raise ReplayWorkflowError(f"trial {trial_id}: workflow report cannot overwrite a source or manifest")
        trial_context.append({
            "trial_id": trial_id,
            "manifest_path": manifest_path,
            "root_path": root_path,
            "manifest": manifest,
            "manifest_sha256_before": manifest_bytes_sha,
            "source_paths": source_paths,
            "source_hashes_before": source_hashes,
        })

    if len({item["manifest"].start_open_time_ms for item in trial_context}) < 2:
        raise ReplayWorkflowError("trials must use at least two distinct pre-roll start times")
    if report_target == out_root or out_root in report_target.parents:
        raise ReplayWorkflowError("workflow report destination must be outside output_dir")
    out_root.mkdir(parents=True, exist_ok=True)

    trial_reports: list[dict[str, Any]] = []
    convergence_trials: list[dict[str, str]] = []
    quality_schema = project_schemas / "stage6b_dataset_quality_report.schema.json"
    analytics_schema = project_schemas / "stage6b_evidence_analytics_report.schema.json"
    convergence_schema = project_schemas / "stage6b_warmup_convergence_report.schema.json"

    for item in trial_context:
        trial_id = item["trial_id"]
        manifest: ReplayDatasetManifest = item["manifest"]
        root_path: Path = item["root_path"]
        trial_dir = out_root / trial_id
        trial_dir.mkdir(parents=True, exist_ok=True)
        quality_path = trial_dir / "quality_report.json"
        ledger_path = trial_dir / "replay.jsonl"
        checkpoint_path = trial_dir / "replay.checkpoint.json"
        analytics_path = trial_dir / "analytics_report.json"

        quality_report = audit_replay_manifest_quality(
            manifest,
            dataset_root=root_path,
            independent_evidence_ref=evidence_ref,
        )
        _validate_schema(quality_report, quality_schema, "Stage 6B.1 quality report")
        write_dataset_quality_report(quality_report, quality_path)
        quality_summary = quality_report["quality_summary"]
        gates = quality_report["eligibility_gates"]
        if provisional_mode:
            if not gates["provisional_strategy_replay_eligible"]:
                raise ReplayWorkflowEligibilityError(
                    f"trial {trial_id}: provisional strategy replay rejected; "
                    f"market_data={gates['market_data']['status']}; "
                    f"market_data_failures={gates['market_data']['failure_codes']}; "
                    f"market_data_warnings={gates['market_data']['warning_codes']}; "
                    f"execution_metadata_blockers={gates['execution_metadata']['blocking_codes']}. "
                    f"Quality report: {quality_path}"
                )
        elif not quality_summary["strict_replay_eligible"]:
            raise ReplayWorkflowEligibilityError(
                f"trial {trial_id}: strict replay eligibility rejected; quality_status="
                f"{quality_summary['quality_status']}; failure_codes={quality_summary['failure_codes']}; "
                f"warning_codes={quality_summary['warning_codes']}. Quality report: {quality_path}"
            )

        try:
            manifest.validate(root_path, strict_metadata=not provisional_mode, verify_hashes=True)
        except ReplayManifestError as exc:
            label = "provisional diagnostic" if provisional_mode else "strict"
            raise ReplayWorkflowEligibilityError(f"trial {trial_id}: {label} manifest validation failed: {exc}") from exc

        config = ReplayConfig(
            max_history_candles=max_history,
            include_m15="15m" in manifest.intervals,
            strict_metadata=not provisional_mode,
            checkpoint_every_captures=checkpoint_every,
        )
        runner = HistoricalReplayRunner(manifest, dataset_root=root_path, config=config)
        if frozen_config_sha is None:
            frozen_config_sha = runner.config_sha256
            frozen_code_sha = runner.code_sha256
        elif (runner.config_sha256, runner.code_sha256) != (frozen_config_sha, frozen_code_sha):
            raise ReplayWorkflowError("trial replay code/configuration identity changed during workflow setup")

        # Integrated restart probe: create a one-capture prefix, then recover and finish.
        runner.run_to_file(
            ledger_path,
            checkpoint_path=checkpoint_path,
            stop_after_captures=1,
        )
        checkpoint_partial = _load_json(checkpoint_path, f"trial {trial_id} partial replay checkpoint")
        if checkpoint_partial.get("completed") is not False:
            raise ReplayWorkflowError(f"trial {trial_id}: replay did not produce an incomplete restart checkpoint")
        summary = runner.run_to_file(
            ledger_path,
            checkpoint_path=checkpoint_path,
            resume_from_checkpoint=True,
        )
        checkpoint_final = _load_json(checkpoint_path, f"trial {trial_id} completed replay checkpoint")
        if checkpoint_final.get("completed") is not True:
            raise ReplayWorkflowError(f"trial {trial_id}: replay checkpoint did not reach completed state")

        analytics_report = analyze_replay_ledger(ledger_path)
        _validate_schema(analytics_report, analytics_schema, "Stage 6B.2 analytics report")
        write_evidence_analytics_report(analytics_report, analytics_path)
        ledger_sha = _sha256_path(ledger_path)
        if ledger_sha != summary.ledger_sha256 or ledger_sha != analytics_report["provenance"]["ledger_sha256"]:
            raise ReplayWorkflowError(f"trial {trial_id}: ledger identity mismatch across Stage 6A/6B.2")
        if analytics_report["provenance"]["dataset_id"] != manifest.dataset_id:
            raise ReplayWorkflowError(f"trial {trial_id}: analytics dataset identity differs from manifest")
        convergence_trials.append({
            "trial_id": trial_id,
            "manifest": str(item["manifest_path"]),
            "root": str(root_path),
            "ledger": str(ledger_path.resolve()),
        })
        trial_reports.append({
            "trial_id": trial_id,
            "dataset_id": manifest.dataset_id,
            "manifest_sha256": item["manifest_sha256_before"],
            "metadata_sha256": manifest.metadata.sha256,
            "source_files": [
                {"path": name, "sha256": digest}
                for name, digest in sorted(item["source_hashes_before"].items())
            ],
            "quality": {
                "quality_status": quality_summary["quality_status"],
                "strict_replay_eligible": quality_summary["strict_replay_eligible"],
                "market_data_status": gates["market_data"]["status"],
                "market_data_eligible": gates["market_data"]["eligible_for_strategy_replay"],
                "execution_metadata_status": gates["execution_metadata"]["status"],
                "report_sha256": quality_report["report_sha256"],
            },
            "replay": {
                "replay_run_id": summary.replay_run_id,
                "config_sha256": summary.config_sha256,
                "code_sha256": summary.code_sha256,
                "ledger_sha256": ledger_sha,
                "capture_count": summary.capture_count,
                "gap_count": summary.gap_count,
                "right_censored_ob_count": summary.right_censored_ob_count,
                "right_censored_fvg_count": summary.right_censored_fvg_count,
                "restart_probe": "PARTIAL_CHECKPOINT_RESUMED_TO_COMPLETION",
                "checkpoint_completed": True,
            },
            "analytics": {
                "report_sha256": analytics_report["report_sha256"],
                "split_method": analytics_report["split_plan"]["method"],
                "state_policy": analytics_report["state_policy"],
            },
            "artifacts": {
                "quality_report": f"{trial_id}/quality_report.json",
                "ledger": f"{trial_id}/replay.jsonl",
                "checkpoint": f"{trial_id}/replay.checkpoint.json",
                "analytics_report": f"{trial_id}/analytics_report.json",
            },
        })

    convergence_plan_path = out_root / "convergence_plan.generated.json"
    convergence_plan = {
        "plan_schema_version": 1,
        "evaluation_window": {"start_ms": start_ms, "end_ms_exclusive": end_ms},
        "trials": convergence_trials,
    }
    _atomic_write_json(convergence_plan, convergence_plan_path)
    convergence_report = analyze_warmup_convergence(convergence_plan_path)
    _validate_schema(convergence_report, convergence_schema, "Stage 6B.3 convergence report")
    convergence_path = out_root / "convergence_report.json"
    write_warmup_convergence_report(convergence_report, convergence_path, convergence_schema)

    # Re-check all original inputs after every downstream consumer has completed.
    for item in trial_context:
        if _sha256_path(item["manifest_path"]) != item["manifest_sha256_before"]:
            raise ReplayWorkflowError(f"trial {item['trial_id']}: manifest changed during workflow")
        for relative, path in item["source_paths"].items():
            if _sha256_path(path) != item["source_hashes_before"][relative]:
                raise ReplayWorkflowError(f"trial {item['trial_id']}: source changed during workflow: {relative}")

    artifact_hashes = []
    for trial in trial_reports:
        for key in ("quality_report", "ledger", "checkpoint", "analytics_report"):
            relative = trial["artifacts"][key]
            artifact_hashes.append({"path": relative, "sha256": _sha256_path(out_root / relative)})
    artifact_hashes.extend([
        {"path": "convergence_plan.generated.json", "sha256": _sha256_path(convergence_plan_path)},
        {"path": "convergence_report.json", "sha256": _sha256_path(convergence_path)},
    ])
    report: dict[str, Any] = {
        "workflow_schema_version": 2,
        "report_type": "STAGE6B_INTEGRATED_REPLAY_WORKFLOW",
        "workflow_status": "COMPLETED_PROVISIONAL" if provisional_mode else "COMPLETED",
        "replay_mode": replay_mode,
        "qualification": {
            "market_data_gate": "PASS",
            "execution_metadata_gate": "BLOCKED" if provisional_mode else "PASS",
            "strict_execution_eligible": not provisional_mode,
            "result_scope": (
                "STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION"
                if provisional_mode else "STRICT_HISTORICAL_REPLAY"
            ),
        },
        "symbol": expected_symbol,
        "evaluation_window": {"start_ms": start_ms, "end_ms_exclusive": end_ms},
        "stage_order": list(_STAGE_ORDER),
        "frozen_identity": {
            "code_sha256": frozen_code_sha,
            "config_sha256": frozen_config_sha,
            "metadata_sha256": expected_metadata_sha,
            "clock_policy": frozen_clock_policy,
        },
        "state_policy": "ONE_CONTINUOUS_REPLAY_NO_SPLIT_OR_EVALUATION_RESET",
        "trials": trial_reports,
        "convergence": {
            "comparison_mode": convergence_report["comparison_mode"],
            "trial_count": len(convergence_report["trials"]),
            "pairwise_comparison_count": len(convergence_report["comparisons"]),
            "report_sha256": convergence_report["report_sha256"],
            "artifact": "convergence_report.json",
            "automatic_convergence_verdict": False,
        },
        "artifact_hashes": sorted(artifact_hashes, key=lambda row: row["path"]),
        "input_immutability_verified": True,
        "report_sha256": "",
    }
    report["report_sha256"] = sha256_text(canonical_json({key: value for key, value in report.items() if key != "report_sha256"}))
    _validate_schema(report, report_schema, "Stage 6B integrated workflow report")
    _atomic_write_json(report, report_target)
    return report
