"""Streaming reader for Binance USD-M native Kline CSV/ZIP archives."""

from __future__ import annotations

import csv
from pathlib import Path
from zipfile import ZipFile
from io import TextIOWrapper
from typing import Callable, Iterator, TextIO

from divatrading.market_data.klines import Kline
from .manifest import ReplayKlineFile, ReplayManifestError


class ReplayKlineReadError(ReplayManifestError):
    """Raised for malformed or mismatched historical Kline source files."""


def _open_csv(path: Path) -> tuple[TextIO, object | None]:
    if path.suffix.lower() == ".zip":
        archive = ZipFile(path, "r")
        names = sorted(name for name in archive.namelist() if name.lower().endswith(".csv") and not name.endswith("/"))
        if len(names) != 1:
            archive.close()
            raise ReplayKlineReadError("Kline ZIP must contain exactly one CSV member")
        member = archive.open(names[0], "r")
        return TextIOWrapper(member, encoding="utf-8", newline=""), archive
    if path.suffix.lower() not in {".csv", ".txt"}:
        raise ReplayKlineReadError("Kline source must be a .csv/.txt file or a .zip archive")
    return path.open("r", encoding="utf-8", newline=""), None


def iter_binance_kline_rows(
    path: str | Path,
    *,
    symbol: str,
    interval: str,
    source_endpoint: str,
) -> Iterator[Kline]:
    """Yield native Binance 12-column rows without materializing a full archive."""
    source = Path(path)
    try:
        handle, archive = _open_csv(source)
    except ReplayKlineReadError:
        raise
    except Exception as exc:
        raise ReplayKlineReadError(f"cannot open Kline source {source}: {exc}") from exc
    count = 0
    previous_open: int | None = None
    try:
        reader = csv.reader(handle)
        for line_number, row in enumerate(reader, start=1):
            if not row or all(not field.strip() for field in row):
                continue
            if line_number == 1 and row[0].strip().lower() in {"open_time", "open_time_ms"}:
                continue
            try:
                candle = Kline.from_binance_row(
                    row, symbol=symbol, interval=interval, source_endpoint=source_endpoint
                )
            except (ValueError, TypeError) as exc:
                raise ReplayKlineReadError(f"invalid Binance Kline row {line_number} in {source}: {exc}") from exc
            if previous_open is not None and candle.open_time_ms <= previous_open:
                raise ReplayKlineReadError(f"Kline open times are duplicate or decreasing at row {line_number}")
            previous_open = candle.open_time_ms
            count += 1
            yield candle
    finally:
        handle.close()
        if archive is not None:
            archive.close()
    if count == 0:
        raise ReplayKlineReadError(f"Kline source contains no data rows: {source}")


def iter_manifest_klines(
    root: str | Path,
    files: tuple[ReplayKlineFile, ...],
    *,
    symbol: str,
    interval: str,
) -> Iterator[Kline]:
    """Stream sorted non-overlapping source files for one timeframe."""
    base = Path(root).resolve()
    selected = sorted((item for item in files if item.interval == interval), key=lambda item: item.first_open_time_ms)
    if not selected:
        return
    previous_open: int | None = None
    for item in selected:
        path = (base / item.path).resolve()
        if base not in path.parents:
            raise ReplayKlineReadError("Kline file path escapes dataset root")
        count = 0
        first: int | None = None
        last: int | None = None
        for candle in iter_binance_kline_rows(
            path,
            symbol=symbol,
            interval=interval,
            source_endpoint=item.source_url or f"archive:{item.path}",
        ):
            if previous_open is not None and candle.open_time_ms <= previous_open:
                raise ReplayKlineReadError("overlapping or revised candles across source files")
            previous_open = candle.open_time_ms
            first = candle.open_time_ms if first is None else first
            last = candle.open_time_ms
            count += 1
            yield candle
        if count != item.row_count or first != item.first_open_time_ms or last != item.last_open_time_ms:
            raise ReplayKlineReadError(f"source row count/range changed during replay: {item.path}")


def iter_kline_chunks(candles: Iterator[Kline], *, chunk_size: int) -> Iterator[tuple[Kline, ...]]:
    """Yield bounded chunks from any typed Kline iterator."""
    if isinstance(chunk_size, bool) or not isinstance(chunk_size, int) or chunk_size < 1:
        raise ValueError("chunk_size must be a positive integer")
    chunk: list[Kline] = []
    for candle in candles:
        if not isinstance(candle, Kline):
            raise ReplayKlineReadError("chunk input must yield typed Kline records")
        chunk.append(candle)
        if len(chunk) == chunk_size:
            yield tuple(chunk)
            chunk.clear()
    if chunk:
        yield tuple(chunk)


def iter_rest_klines(
    client,
    *,
    symbol: str,
    interval: str,
    start_time_ms: int,
    end_time_ms: int,
    page_limit: int = 1500,
    pages_per_chunk: int = 4,
    min_request_interval_seconds: float = 0.1,
    sleep: Callable[[float], None] | None = None,
) -> Iterator[Kline]:
    """Yield typed Klines through bounded, cursor-safe Binance REST page batches.

    The existing HistoricalKlineService remains the sole pagination/row parser.
    Returned timestamp gaps are preserved for the replay runner to classify; this
    iterator never fabricates or fills an absent candle.
    """
    from divatrading.market_data.history import HistoricalKlineService

    if isinstance(pages_per_chunk, bool) or not isinstance(pages_per_chunk, int) or not 1 <= pages_per_chunk <= 100:
        raise ValueError("pages_per_chunk must be between 1 and 100")
    kwargs = {
        "page_limit": page_limit,
        "max_pages": pages_per_chunk,
        "min_request_interval_seconds": min_request_interval_seconds,
    }
    if sleep is not None:
        kwargs["sleep"] = sleep
    service = HistoricalKlineService(client, **kwargs)
    cursor = start_time_ms
    previous_open: int | None = None
    while cursor <= end_time_ms:
        batch = service.fetch(
            symbol=symbol, interval=interval,
            start_time_ms=cursor, end_time_ms=end_time_ms,
            max_pages=pages_per_chunk,
        )
        for candle in batch.candles:
            if previous_open is not None and candle.open_time_ms <= previous_open:
                raise ReplayKlineReadError("REST Kline pages overlap or arrive out of order")
            previous_open = candle.open_time_ms
            yield candle
        if batch.complete:
            return
        next_cursor = batch.next_start_time_ms
        if next_cursor is None or next_cursor <= cursor:
            raise ReplayKlineReadError("REST Kline pagination did not advance its cursor")
        cursor = next_cursor
