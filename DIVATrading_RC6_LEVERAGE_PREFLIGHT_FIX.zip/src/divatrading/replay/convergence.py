"""Read-only comparison of SMC V2 evidence after differing pre-roll histories.

The common evaluation slice is content-addressed per native timeframe. Trial ledgers
are validated with the Stage 6B.2 strict JSONL validator and evidence is compared
through a temporary SQLite spool so memory use does not scale with ledger size.
"""

from __future__ import annotations

from hashlib import sha256
import itertools
import json
import os
from pathlib import Path
import sqlite3
import tempfile
from typing import Any

from .analytics import (
    _extract_header,
    _iter_strict_ledger,
    _read_terminal_summary,
    _sha256_file,
    _valid_sha,
)
from .klines import iter_manifest_klines
from .manifest import (
    ReplayDatasetManifest,
    ReplayManifestError,
    canonical_json,
    sha256_file,
    sha256_text,
)
from divatrading.market_data.klines import INTERVAL_MILLISECONDS


_EVIDENCE_STAGES = (
    "STAGE_2_MARKET_STRUCTURE",
    "STAGE_3_OB_FORMATION",
    "STAGE_4_OB_LIFECYCLE",
    "STAGE_5_LIQUIDITY_FVG",
)
_EVIDENCE_TYPES = {
    "BAR_TRACE", "OB_FORMATION_TRACE", "ORDER_BLOCK_CANDIDATE",
    "OB_LIFECYCLE_TRACE", "ORDER_BLOCK_LIFECYCLE",
    "LIQUIDITY_FVG_TRACE", "LIQUIDITY_REFERENCE", "LIQUIDITY_SWEEP", "FVG",
}


class WarmupConvergenceError(ValueError):
    """Raised when warm-up trials cannot be compared on an identical evaluation slice."""


def _require_int(value: Any, name: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise WarmupConvergenceError(f"{name} must be an integer >= {minimum}")
    return value


def _source_fingerprint_and_confounds(
    manifest: ReplayDatasetManifest,
    root: Path,
    evaluation: dict[str, int],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Stream each timeframe once; retain only hashes, counts and bounded gap samples."""
    fingerprints: dict[str, str] = {}
    counts: dict[str, int] = {}
    preroll_counts: dict[str, int] = {}
    preroll_starts: dict[str, int | None] = {}
    gaps: list[dict[str, Any]] = []
    start_ms = evaluation["start_ms"]
    end_ms = evaluation["end_ms_exclusive"]

    for interval in manifest.intervals:
        step = INTERVAL_MILLISECONDS[interval]
        if start_ms % step or end_ms % step:
            raise WarmupConvergenceError(
                f"evaluation window must align to active timeframe {interval} boundaries"
            )
        expected_preroll = (start_ms - manifest.start_open_time_ms) // step
        expected_eval = (end_ms - start_ms) // step
        preroll_cursor = manifest.start_open_time_ms
        eval_cursor = start_ms
        preroll_first: int | None = None
        preroll_last: int | None = None
        eval_first: int | None = None
        eval_last: int | None = None
        preroll_count = eval_count = 0
        preroll_gaps: list[dict[str, int]] = []
        eval_gaps: list[dict[str, int]] = []
        preroll_missing = eval_missing = 0
        digest = sha256()

        def track_open(
            opened: int, cursor: int, *, segment: str,
            samples: list[dict[str, int]],
        ) -> tuple[int, int]:
            if opened < cursor:
                raise WarmupConvergenceError(f"{interval} source candles are duplicated or out of order")
            missing = (opened - cursor) // step
            if missing and len(samples) < 100:
                samples.append({"first_missing_open_time_ms": cursor, "missing_bar_count": missing})
            return opened + step, missing

        for candle in iter_manifest_klines(root, manifest.files, symbol=manifest.symbol, interval=interval):
            opened = candle.open_time_ms
            if opened < start_ms:
                preroll_cursor, missing = track_open(
                    opened, preroll_cursor, segment="PRE_ROLL", samples=preroll_gaps
                )
                preroll_missing += missing
                preroll_first = opened if preroll_first is None else preroll_first
                preroll_last = opened
                preroll_count += 1
            elif start_ms <= opened < end_ms:
                eval_cursor, missing = track_open(
                    opened, eval_cursor, segment="EVALUATION", samples=eval_gaps
                )
                eval_missing += missing
                eval_first = opened if eval_first is None else eval_first
                eval_last = opened
                eval_count += 1
                record = {
                    "open_time_ms": opened,
                    "close_time_ms": candle.close_time_ms,
                    "open": format(candle.open, "f"),
                    "high": format(candle.high, "f"),
                    "low": format(candle.low, "f"),
                    "close": format(candle.close, "f"),
                    "volume": format(candle.volume, "f"),
                    "quote_asset_volume": format(candle.quote_asset_volume, "f"),
                    "trade_count": candle.trade_count,
                    "taker_buy_base_volume": format(candle.taker_buy_base_volume, "f"),
                    "taker_buy_quote_volume": format(candle.taker_buy_quote_volume, "f"),
                    "ignore_value": candle.ignore_value,
                }
                digest.update(canonical_json(record).encode("utf-8"))
                digest.update(b"\n")

        if preroll_cursor < start_ms:
            missing = (start_ms - preroll_cursor) // step
            preroll_missing += missing
            if missing and len(preroll_gaps) < 100:
                preroll_gaps.append({"first_missing_open_time_ms": preroll_cursor, "missing_bar_count": missing})
        if eval_cursor < end_ms:
            missing = (end_ms - eval_cursor) // step
            eval_missing += missing
            if missing and len(eval_gaps) < 100:
                eval_gaps.append({"first_missing_open_time_ms": eval_cursor, "missing_bar_count": missing})

        # Count-derived missing values must agree with the chronological cursor scan.
        if preroll_missing != expected_preroll - preroll_count or eval_missing != expected_eval - eval_count:
            raise WarmupConvergenceError(f"{interval} source gap accounting is inconsistent")
        preroll_leading = expected_preroll if preroll_first is None else (preroll_first - manifest.start_open_time_ms) // step
        preroll_trailing = expected_preroll if preroll_last is None else (start_ms - preroll_last - step) // step
        eval_leading = expected_eval if eval_first is None else (eval_first - start_ms) // step
        eval_trailing = expected_eval if eval_last is None else (end_ms - eval_last - step) // step

        preroll_counts[interval] = preroll_count
        preroll_starts[interval] = preroll_first
        counts[interval] = eval_count
        fingerprints[interval] = digest.hexdigest()
        if eval_missing:
            gaps.append({
                "interval": interval, "segment": "EVALUATION", "expected_bar_count": expected_eval,
                "observed_bar_count": eval_count, "missing_bar_count": eval_missing,
                "leading_missing_bar_count": eval_leading,
                "trailing_missing_bar_count": eval_trailing,
                "gap_clusters": eval_gaps,
            })
        if preroll_missing:
            gaps.append({
                "interval": interval, "segment": "PRE_ROLL", "expected_bar_count": expected_preroll,
                "observed_bar_count": preroll_count, "missing_bar_count": preroll_missing,
                "leading_missing_bar_count": preroll_leading,
                "trailing_missing_bar_count": preroll_trailing,
                "gap_clusters": preroll_gaps,
            })

    aggregate = sha256_text(canonical_json({"by_timeframe": fingerprints}))
    return ({
        "evaluation_slice_sha256": aggregate,
        "evaluation_slice_fingerprints": fingerprints,
        "evaluation_slice_bar_counts": counts,
    }, {
        "pre_roll_start_ms": manifest.start_open_time_ms,
        "pre_roll_duration_ms": start_ms - manifest.start_open_time_ms,
        "pre_roll_start_by_interval": preroll_starts,
        "pre_roll_bars": preroll_counts,
        "gap_summary": gaps,
    })


def _comparison_payload(value: Any) -> Any:
    """Remove replay-relative positional indices while retaining timestamp anchors.

    Absolute source/confirmation timestamps and deterministic entity IDs remain in
    the comparison. Integer indices are relative to the replay's pre-roll origin,
    so comparing them would guarantee false divergence for otherwise identical
    evidence produced from different warm-up lengths.
    """
    if isinstance(value, dict):
        return {
            key: _comparison_payload(item)
            for key, item in value.items()
            if not key.endswith("_index")
        }
    if isinstance(value, list):
        return [_comparison_payload(item) for item in value]
    return value


def _stable_evidence_key(record_type: str, payload: dict[str, Any], known_at: int) -> str | None:
    if record_type == "BAR_TRACE":
        value = payload.get("bar_open_time_ms")
        return f"bar:{value}" if type(value) is int else None
    if record_type == "OB_LIFECYCLE_TRACE":
        # event_id identifies the originating market-structure event, not an
        # individual lifecycle transition. One OB can emit several transitions
        # (created, activated, touched, mitigated, invalidated) sharing that ID.
        # Mirror the replay engine's deterministic lifecycle trace identity so
        # each transition remains distinct while staying stable across pre-rolls.
        candidate = payload.get("candidate_id")
        transition = payload.get("transition")
        observed = payload.get("observed_time_ms")
        to_status = payload.get("to_status")
        if (
            isinstance(candidate, str) and candidate
            and isinstance(transition, str) and transition
            and type(observed) is int
            and isinstance(to_status, str) and to_status
        ):
            return f"lifecycle:{candidate}|{transition}|{observed}|{to_status}"
        return None
    if record_type in {"OB_FORMATION_TRACE", "LIQUIDITY_FVG_TRACE"}:
        value = payload.get("event_id")
        return f"event:{value}" if isinstance(value, str) and value else None
    if record_type == "ORDER_BLOCK_CANDIDATE":
        value = payload.get("candidate_id")
        return f"candidate:{value}" if isinstance(value, str) and value else None
    if record_type == "ORDER_BLOCK_LIFECYCLE":
        candidate = payload.get("candidate")
        value = candidate.get("candidate_id") if isinstance(candidate, dict) else None
        return f"candidate:{value}@{known_at}" if isinstance(value, str) and value else None
    if record_type == "LIQUIDITY_REFERENCE":
        value = payload.get("reference_id")
        return f"reference:{value}" if isinstance(value, str) and value else None
    if record_type == "LIQUIDITY_SWEEP":
        value = payload.get("evidence_id")
        return f"sweep:{value}" if isinstance(value, str) and value else None
    if record_type == "FVG":
        value = payload.get("fvg_id")
        return f"fvg:{value}@{known_at}" if isinstance(value, str) and value else None
    return None


def _prepare_trial(
    trial: dict[str, Any],
    evaluation: dict[str, int],
    db: sqlite3.Connection,
) -> dict[str, Any]:
    trial_id = trial.get("trial_id")
    if not isinstance(trial_id, str) or not trial_id.strip():
        raise WarmupConvergenceError("each trial requires a non-empty trial_id")
    manifest_path = Path(trial.get("manifest", ""))
    if not manifest_path.is_file():
        raise WarmupConvergenceError(f"trial {trial_id}: manifest file is missing: {manifest_path}")
    ledger_path = Path(trial.get("ledger", ""))
    if not ledger_path.is_file():
        raise WarmupConvergenceError(f"trial {trial_id}: ledger file is missing: {ledger_path}")
    root = Path(trial.get("root") or manifest_path.parent).resolve()
    manifest = ReplayDatasetManifest.load(manifest_path)
    header = _extract_header(ledger_path)
    if header.get("symbol") != manifest.symbol or header.get("dataset_id") != manifest.dataset_id:
        raise WarmupConvergenceError(f"trial {trial_id}: ledger identity does not match its manifest")
    if header.get("metadata_sha256") != manifest.metadata.sha256:
        raise WarmupConvergenceError(f"trial {trial_id}: ledger metadata hash does not match manifest")
    if header.get("clock_policy") != "UTC_KLINE_CLOSE_PLUS_1MS_V1":
        raise WarmupConvergenceError(f"trial {trial_id}: unsupported Stage 6A clock policy")
    strict_metadata = header.get("strict_metadata") is True
    try:
        manifest.validate(root, strict_metadata=strict_metadata, verify_hashes=True)
    except ReplayManifestError as exc:
        raise WarmupConvergenceError(f"trial {trial_id}: manifest/source validation failed: {exc}") from exc
    if evaluation["start_ms"] < manifest.start_open_time_ms or evaluation["end_ms_exclusive"] > manifest.end_open_time_ms:
        raise WarmupConvergenceError(f"trial {trial_id}: evaluation window is outside its manifest window")
    intervals = list(manifest.intervals)
    header_sources = header.get("source_files")
    if not isinstance(header_sources, list):
        raise WarmupConvergenceError(f"trial {trial_id}: ledger source_files are malformed")
    header_intervals = sorted({item.get("interval") for item in header_sources if isinstance(item, dict)})
    if header_intervals != sorted(intervals):
        raise WarmupConvergenceError(f"trial {trial_id}: ledger and manifest active timeframe sets differ")
    manifest_sources = sorted(
        ({"interval": item.interval, "path": item.path, "sha256": item.sha256, "row_count": item.row_count}
         for item in manifest.files),
        key=lambda row: (row["interval"], row["path"], row["sha256"], row["row_count"]),
    )
    normalized_header_sources = sorted(
        ({"interval": item.get("interval"), "path": item.get("path"), "sha256": item.get("sha256"), "row_count": item.get("row_count")}
         for item in header_sources if isinstance(item, dict)),
        key=lambda row: (str(row["interval"]), str(row["path"]), str(row["sha256"]), int(row["row_count"] or 0)),
    )
    if normalized_header_sources != manifest_sources:
        raise WarmupConvergenceError(f"trial {trial_id}: ledger source file hashes/ranges differ from manifest")
    for interval in intervals:
        if evaluation["start_ms"] % INTERVAL_MILLISECONDS[interval] or evaluation["end_ms_exclusive"] % INTERVAL_MILLISECONDS[interval]:
            raise WarmupConvergenceError(f"trial {trial_id}: evaluation window is not aligned to {interval}")

    for key in ("replay_run_id", "dataset_id", "code_sha256", "config_sha256", "metadata_sha256"):
        _valid_sha(header.get(key), key)
    _valid_sha(manifest.dataset_id, "manifest.dataset_id")
    if not isinstance(header.get("config"), dict):
        raise WarmupConvergenceError(f"trial {trial_id}: replay configuration payload is missing")
    if sha256_text(canonical_json(header["config"])) != header["config_sha256"]:
        raise WarmupConvergenceError(f"trial {trial_id}: config_sha256 does not match canonical strategy configuration")
    expected_run_id = sha256_text(canonical_json({
        "dataset_id": manifest.dataset_id,
        "config_sha256": header["config_sha256"],
        "code_sha256": header["code_sha256"],
        "software_version": header.get("software_version"),
        "clock_policy": header["clock_policy"],
    }))
    if expected_run_id != header["replay_run_id"]:
        raise WarmupConvergenceError(f"trial {trial_id}: replay_run_id does not match frozen replay identity")
    terminal = _read_terminal_summary(ledger_path)
    header_for_validation = dict(header)
    header_for_validation["_capture_count"] = terminal.get("capture_count")
    source_end = manifest.end_open_time_ms
    split_plan = {"splits": [{"label": "EVALUATION", "start_ms": manifest.start_open_time_ms,
                              "end_ms_exclusive": source_end + 1}]}
    ledger_sha, ledger_bytes = _sha256_file(ledger_path)

    # Strict parser validates every capture sequence, identity and terminal summary.
    db.execute("DROP TABLE IF EXISTS records")
    db.execute("DROP TABLE IF EXISTS snapshots")
    _iter_strict_ledger(ledger_path, expected_header=header_for_validation, db=db, split_plan=split_plan)
    db.execute("DROP TABLE records")
    db.execute("DROP TABLE snapshots")

    candle_identity, pre_roll = _source_fingerprint_and_confounds(manifest, root, evaluation)
    post_sha, post_size = _sha256_file(ledger_path)
    if post_sha != ledger_sha or post_size != ledger_bytes:
        raise WarmupConvergenceError(f"trial {trial_id}: ledger changed during validation")
    for item in manifest.files:
        if sha256_file(root / item.path) != item.sha256:
            raise WarmupConvergenceError(f"trial {trial_id}: source file changed during validation")
    return {
        "trial_id": trial_id,
        "window_label": trial.get("window_label"),
        "manifest": manifest,
        "root": root,
        "header": header,
        "ledger_path": ledger_path,
        "ledger_sha256": ledger_sha,
        "ledger_bytes": ledger_bytes,
        **candle_identity,
        **pre_roll,
        "replay_gap_events": [],
        "replay_gap_event_count": 0,
    }


def _load_trial_records(trial: dict[str, Any], evaluation: dict[str, int], db: sqlite3.Connection) -> None:
    """Scan immutable JSONL again to retain close-clock time and stable evidence keys."""
    trial_id = trial["trial_id"]
    ledger_path: Path = trial["ledger_path"]
    with ledger_path.open("rb") as handle:
        for line_number, raw in enumerate(handle, start=1):
            try:
                item = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise WarmupConvergenceError(f"trial {trial_id}: invalid ledger line {line_number}") from exc
            if not isinstance(item, dict) or item.get("record_type") not in _EVIDENCE_TYPES | {"REPLAY_CAPTURE_SUMMARY", "REPLAY_DATA_GAP"}:
                continue
            record_type = item["record_type"]
            known_at = item.get("known_at_time_ms")
            timeframe = item.get("timeframe")
            if record_type == "REPLAY_DATA_GAP":
                if isinstance(known_at, int) and timeframe in trial["pre_roll_bars"]:
                    opened = known_at - INTERVAL_MILLISECONDS[timeframe]
                    if evaluation["start_ms"] <= opened < evaluation["end_ms_exclusive"]:
                        trial["replay_gap_event_count"] += 1
                        if len(trial["replay_gap_events"]) < 100:
                            trial["replay_gap_events"].append({
                                "timeframe": timeframe, "known_at_time_ms": known_at,
                                "payload": item.get("payload"),
                            })
                continue
            if record_type == "REPLAY_CAPTURE_SUMMARY":
                payload = item.get("payload", {})
                for latest in payload.get("latest_closed_klines", []):
                    if not isinstance(latest, dict):
                        continue
                    interval = latest.get("interval")
                    opened = latest.get("open_time_ms")
                    if interval not in payload.get("updated_intervals", []):
                        continue
                    if interval not in trial["pre_roll_bars"] or type(opened) is not int or not (evaluation["start_ms"] <= opened < evaluation["end_ms_exclusive"]):
                        continue
                    readiness = next((row for row in payload.get("readiness", {}).get("timeframes", [])
                                       if isinstance(row, dict) and row.get("timeframe") == interval), None)
                    if readiness:
                        db.execute(
                            "INSERT INTO readiness(trial_id,timeframe,known_at,status,remaining) VALUES(?,?,?,?,?)",
                            (trial_id, interval, known_at, readiness.get("status"), readiness.get("warmup_remaining_bars")),
                        )
                continue
            if not isinstance(known_at, int) or timeframe not in trial["pre_roll_bars"]:
                continue
            step = INTERVAL_MILLISECONDS[timeframe]
            open_equivalent = item.get("payload", {}).get("bar_open_time_ms") if record_type == "BAR_TRACE" else known_at - step
            if type(open_equivalent) is not int or not (evaluation["start_ms"] <= open_equivalent < evaluation["end_ms_exclusive"]):
                continue
            payload = item.get("payload")
            if not isinstance(payload, dict) or item.get("stage") not in _EVIDENCE_STAGES:
                raise WarmupConvergenceError(f"trial {trial_id}: malformed Stage 2-5 evidence at line {line_number}")
            key = _stable_evidence_key(record_type, payload, known_at)
            if key is None:
                raise WarmupConvergenceError(f"trial {trial_id}: {record_type} lacks stable evidence identity")
            payload_json = canonical_json(payload)
            comparison_json = canonical_json(_comparison_payload(payload))
            try:
                db.execute(
                    "INSERT INTO evidence(trial_id,stage,timeframe,record_type,stable_key,known_at,payload,comparison_payload) VALUES(?,?,?,?,?,?,?,?)",
                    (trial_id, item["stage"], timeframe, record_type, key, known_at, payload_json, comparison_json),
                )
            except sqlite3.IntegrityError as exc:
                raise WarmupConvergenceError(
                    f"trial {trial_id}: duplicate stable evidence key {item['stage']}/{timeframe}/{key}"
                ) from exc
    db.commit()


def _readiness_summary(trial_id: str, intervals: list[str], db: sqlite3.Connection) -> list[dict[str, Any]]:
    output = []
    for interval in intervals:
        total = db.execute(
            "SELECT COUNT(*) FROM readiness WHERE trial_id=? AND timeframe=?",
            (trial_id, interval),
        ).fetchone()[0]
        statuses = {
            str(status or "UNKNOWN"): count
            for status, count in db.execute(
                "SELECT status,COUNT(*) FROM readiness WHERE trial_id=? AND timeframe=? GROUP BY status ORDER BY status",
                (trial_id, interval),
            )
        }
        first = db.execute(
            "SELECT known_at,status,remaining FROM readiness WHERE trial_id=? AND timeframe=? ORDER BY known_at LIMIT 1",
            (trial_id, interval),
        ).fetchone()
        last = db.execute(
            "SELECT known_at,status,remaining FROM readiness WHERE trial_id=? AND timeframe=? ORDER BY known_at DESC LIMIT 1",
            (trial_id, interval),
        ).fetchone()
        output.append({
            "interval": interval,
            "observations": total,
            "status_counts": dict(sorted(statuses.items())),
            "first_known_at_time_ms": first[0] if first else None,
            "first_status": first[1] if first else None,
            "first_warmup_remaining_bars": first[2] if first else None,
            "last_known_at_time_ms": last[0] if last else None,
            "last_status": last[1] if last else None,
            "last_warmup_remaining_bars": last[2] if last else None,
        })
    return output


def _compare_pair(left: str, right: str, stage: str, interval: str,
                  db: sqlite3.Connection, sample_cap: int = 100) -> dict[str, Any]:
    left_count = db.execute(
        "SELECT COUNT(*) FROM evidence WHERE trial_id=? AND stage=? AND timeframe=?",
        (left, stage, interval),
    ).fetchone()[0]
    right_count = db.execute(
        "SELECT COUNT(*) FROM evidence WHERE trial_id=? AND stage=? AND timeframe=?",
        (right, stage, interval),
    ).fetchone()[0]
    query = """
        SELECT stable_key,left_known,left_payload,left_compare,right_known,right_payload,right_compare FROM (
          SELECT l.stable_key AS stable_key,l.known_at AS left_known,l.payload AS left_payload,
                 l.comparison_payload AS left_compare,
                 r.known_at AS right_known,r.payload AS right_payload,
                 r.comparison_payload AS right_compare
          FROM evidence l LEFT JOIN evidence r
            ON r.trial_id=? AND r.stage=l.stage AND r.timeframe=l.timeframe AND r.stable_key=l.stable_key
          WHERE l.trial_id=? AND l.stage=? AND l.timeframe=?
          UNION ALL
          SELECT r.stable_key AS stable_key,NULL AS left_known,NULL AS left_payload,
                 NULL AS left_compare,
                 r.known_at AS right_known,r.payload AS right_payload,
                 r.comparison_payload AS right_compare
          FROM evidence r LEFT JOIN evidence l
            ON l.trial_id=? AND l.stage=r.stage AND l.timeframe=r.timeframe AND l.stable_key=r.stable_key
          WHERE r.trial_id=? AND r.stage=? AND r.timeframe=? AND l.stable_key IS NULL
        ) ORDER BY COALESCE(left_known,right_known),stable_key
    """
    matched = exact = left_only = right_only = changed = divergence_total = 0
    first_divergence: int | None = None
    samples: list[dict[str, Any]] = []
    for key, left_known, left_payload, left_compare, right_known, right_payload, right_compare in db.execute(
        query, (right, left, stage, interval, left, right, stage, interval)
    ):
        differs = left_payload is None or right_payload is None or left_compare != right_compare or left_known != right_known
        if left_payload is None:
            right_only += 1
        elif right_payload is None:
            left_only += 1
        else:
            matched += 1
            if left_compare == right_compare:
                exact += 1
            else:
                changed += 1
        if differs:
            divergence_total += 1
            divergence_time = min(value for value in (left_known, right_known) if value is not None)
            if first_divergence is None or divergence_time < first_divergence:
                first_divergence = divergence_time
            if len(samples) < sample_cap:
                samples.append({
                    "stable_key": key,
                    "first_divergence_time_ms": divergence_time,
                    "left_known_at_time_ms": left_known,
                    "right_known_at_time_ms": right_known,
                    "left_payload": json.loads(left_payload) if left_payload is not None else None,
                    "right_payload": json.loads(right_payload) if right_payload is not None else None,
                })
    union_count = matched + left_only + right_only
    agreement = None if union_count == 0 else format(exact / union_count, ".12f").rstrip("0").rstrip(".")
    if agreement == "":
        agreement = "0"
    return {
        "left_trial_id": left,
        "right_trial_id": right,
        "stage": stage,
        "timeframe": interval,
        "record_counts": {
            "left": left_count, "right": right_count, "matched_keys": matched,
            "exact_payload_matches": exact, "left_only": left_only,
            "right_only": right_only, "same_key_changed_payload": changed,
        },
        "agreement": agreement,
        "first_divergence_time_ms": first_divergence,
        "divergence_count": divergence_total,
        "divergence_samples_truncated": divergence_total > len(samples),
        "divergence_samples": samples,
    }


def analyze_warmup_convergence(plan_path: str | Path) -> dict[str, Any]:
    """Compare two or more pre-roll trials on one identical native-Kline evaluation slice."""
    path = Path(plan_path).resolve()
    try:
        plan = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WarmupConvergenceError(f"cannot read convergence plan JSON: {exc}") from exc
    if not isinstance(plan, dict) or plan.get("plan_schema_version") != 1:
        raise WarmupConvergenceError("convergence plan must be an object with plan_schema_version=1")
    evaluation_raw = plan.get("evaluation_window")
    if not isinstance(evaluation_raw, dict):
        raise WarmupConvergenceError("evaluation_window is required")
    evaluation = {
        "start_ms": _require_int(evaluation_raw.get("start_ms"), "evaluation_window.start_ms"),
        "end_ms_exclusive": _require_int(evaluation_raw.get("end_ms_exclusive"), "evaluation_window.end_ms_exclusive", minimum=1),
    }
    if evaluation["end_ms_exclusive"] <= evaluation["start_ms"]:
        raise WarmupConvergenceError("evaluation window must be non-empty")
    raw_trials = plan.get("trials")
    if not isinstance(raw_trials, list) or len(raw_trials) < 2:
        raise WarmupConvergenceError("at least two trials are required")
    if len(raw_trials) > 10:
        raise WarmupConvergenceError("at most ten trials are supported to bound pairwise work and report size")
    trial_ids = [item.get("trial_id") if isinstance(item, dict) else None for item in raw_trials]
    if any(not isinstance(item, str) or not item.strip() for item in trial_ids) or len(set(trial_ids)) != len(trial_ids):
        raise WarmupConvergenceError("trial_id values must be non-empty and unique")

    def resolve(item: Any) -> dict[str, Any]:
        if not isinstance(item, str) or not item.strip():
            raise WarmupConvergenceError("trial manifest/ledger/root paths must be non-empty strings")
        candidate = Path(item)
        return (path.parent / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()

    normalized_trials = []
    for item in raw_trials:
        if not isinstance(item, dict):
            raise WarmupConvergenceError("each trial must be an object")
        normalized_trials.append({
            **item,
            "manifest": resolve(item.get("manifest")),
            "ledger": resolve(item.get("ledger")),
            "root": resolve(item["root"]) if item.get("root") else None,
        })

    with tempfile.TemporaryDirectory(prefix="divatrading_warmup_convergence_") as temp_dir:
        db = sqlite3.connect(Path(temp_dir) / "convergence.sqlite3")
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            db.execute("CREATE TABLE records (row_id INTEGER PRIMARY KEY, split_label TEXT NOT NULL, record_type TEXT NOT NULL, timeframe TEXT, stage TEXT, payload TEXT NOT NULL)")
            db.execute("CREATE INDEX records_split_type ON records(split_label,record_type,timeframe)")
            db.execute("CREATE TABLE snapshots (split_label TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, known_at INTEGER NOT NULL, timeframe TEXT, payload TEXT NOT NULL, PRIMARY KEY(split_label,entity_type,entity_id))")
            db.execute("CREATE TABLE evidence (trial_id TEXT NOT NULL, stage TEXT NOT NULL, timeframe TEXT NOT NULL, record_type TEXT NOT NULL, stable_key TEXT NOT NULL, known_at INTEGER NOT NULL, payload TEXT NOT NULL, comparison_payload TEXT NOT NULL, PRIMARY KEY(trial_id,stage,timeframe,stable_key))")
            db.execute("CREATE TABLE readiness (trial_id TEXT NOT NULL,timeframe TEXT NOT NULL,known_at INTEGER NOT NULL,status TEXT,remaining INTEGER)")
            db.execute("CREATE INDEX readiness_trial_tf ON readiness(trial_id,timeframe,known_at)")

            trials = []
            for item in normalized_trials:
                trial = _prepare_trial(item, evaluation, db)
                trials.append(trial)
                _load_trial_records(trial, evaluation, db)

            durations = [item["pre_roll_duration_ms"] for item in trials]
            if len(set(durations)) != len(durations):
                raise WarmupConvergenceError("each trial must use a distinct pre-roll duration")
            ordered_by_duration = sorted(trials, key=lambda item: item["pre_roll_duration_ms"])
            default_labels = ("SHORT", "MEDIUM", "LONG") if len(trials) == 3 else None
            for index, trial in enumerate(ordered_by_duration):
                if not trial.get("window_label"):
                    if default_labels:
                        trial["window_label"] = default_labels[index]
                    elif len(trials) == 2:
                        trial["window_label"] = "SHORT" if index == 0 else "LONG"
                    else:
                        trial["window_label"] = f"WINDOW_{index + 1}"

            first = trials[0]
            common_identity = {
                "symbol": first["manifest"].symbol,
                "evaluation_window": evaluation,
                "code_sha256": first["header"]["code_sha256"],
                "config_sha256": first["header"]["config_sha256"],
                "metadata_sha256": first["header"]["metadata_sha256"],
                "clock_policy": first["header"]["clock_policy"],
                "intervals": list(first["manifest"].intervals),
            }
            for trial in trials[1:]:
                header = trial["header"]
                other = {
                    "symbol": trial["manifest"].symbol,
                    "evaluation_window": evaluation,
                    "code_sha256": header["code_sha256"],
                    "config_sha256": header["config_sha256"],
                    "metadata_sha256": header["metadata_sha256"],
                    "clock_policy": header["clock_policy"],
                    "intervals": list(trial["manifest"].intervals),
                }
                if other != common_identity:
                    raise WarmupConvergenceError("trials differ in symbol, timeframes, code/config/metadata identity or clock policy")
                if trial["evaluation_slice_fingerprints"] != first["evaluation_slice_fingerprints"]:
                    raise WarmupConvergenceError("trials do not contain identical per-timeframe evaluation-slice candles")
                if trial["evaluation_slice_bar_counts"] != first["evaluation_slice_bar_counts"]:
                    raise WarmupConvergenceError("trials have different evaluation-slice candle counts")

            # Freeze every trial/data/config identity before deriving any pairwise result.
            frozen_trials = [{
                "trial_id": item["trial_id"],
                "dataset_id": item["manifest"].dataset_id,
                "replay_run_id": item["header"]["replay_run_id"],
                "ledger_sha256": item["ledger_sha256"],
                "ledger_bytes": item["ledger_bytes"],
                "window_label": item.get("window_label", item["trial_id"]),
                "pre_roll_start_ms": item["pre_roll_start_ms"],
                "pre_roll_duration_ms": item["pre_roll_duration_ms"],
                "pre_roll_start_by_interval": item["pre_roll_start_by_interval"],
                "pre_roll_bars": item["pre_roll_bars"],
                "evaluation_slice_sha256": item["evaluation_slice_sha256"],
                "evaluation_slice_fingerprints": item["evaluation_slice_fingerprints"],
                "evaluation_slice_bar_counts": item["evaluation_slice_bar_counts"],
                "gap_summary": item["gap_summary"],
                "warmup_readiness_summary": _readiness_summary(item["trial_id"], list(item["manifest"].intervals), db),
                "replay_gap_events": item["replay_gap_events"],
                "replay_gap_event_count": item["replay_gap_event_count"],
                "replay_gap_events_truncated": item["replay_gap_event_count"] > len(item["replay_gap_events"]),
            } for item in trials]
            frozen_identity = {**common_identity, "trials": frozen_trials}
            frozen_identity["identity_sha256"] = sha256_text(canonical_json(frozen_identity))

            comparisons = []
            for left, right in itertools.combinations([item["trial_id"] for item in trials], 2):
                for stage in _EVIDENCE_STAGES:
                    for interval in common_identity["intervals"]:
                        comparisons.append(_compare_pair(left, right, stage, interval, db))

            report = {
                "report_schema_version": 1,
                "report_type": "REPLAY_WARMUP_CONVERGENCE",
                "symbol": common_identity["symbol"],
                "evaluation_window": evaluation,
                "frozen_identity": {
                    "code_sha256": common_identity["code_sha256"],
                    "config_sha256": common_identity["config_sha256"],
                    "metadata_sha256": common_identity["metadata_sha256"],
                    "clock_policy": common_identity["clock_policy"],
                    "intervals": common_identity["intervals"],
                    "identity_sha256": frozen_identity["identity_sha256"],
                },
                "comparison_mode": "LIMITED_TWO_TRIAL_COMPARISON" if len(trials) == 2 else "THREE_PLUS_TRIAL_COMPARISON",
                "trials": frozen_trials,
                "comparisons": comparisons,
                "comparison_payload_policy": "EXCLUDE_REPLAY_RELATIVE_*_INDEX_FIELDS; RETAIN_ABSOLUTE_TIME_AND_ENTITY_IDENTITIES",
                "convergence_policy": "DESCRIPTIVE_NO_AUTOMATIC_PASS_THRESHOLD",
            }
            report["report_sha256"] = sha256_text(canonical_json(report))
        finally:
            db.close()

    # Confirm no input ledger/source changed after the identity freeze and comparison.
    for trial in trials:
        if _sha256_file(trial["ledger_path"])[0] != trial["ledger_sha256"]:
            raise WarmupConvergenceError(f"trial {trial['trial_id']}: ledger changed during comparison")
        for source in trial["manifest"].files:
            if sha256_file(trial["root"] / source.path) != source.sha256:
                raise WarmupConvergenceError(f"trial {trial['trial_id']}: source changed during comparison")
    return report


def write_warmup_convergence_report(report: dict[str, Any], destination: str | Path,
                                    schema_path: str | Path | None = None) -> Path:
    """Validate and atomically write the report JSON."""
    try:
        from jsonschema import Draft202012Validator
        schema_file = Path(schema_path) if schema_path else Path(__file__).resolve().parents[3] / "docs" / "schemas" / "stage6b_warmup_convergence_report.schema.json"
        schema = json.loads(schema_file.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(report)
    except Exception as exc:
        raise WarmupConvergenceError(f"warm-up convergence report schema validation failed: {exc}") from exc
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    raw = json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except OSError:
        temporary.unlink(missing_ok=True)
        raise
    return path
