"""Strict streaming analytics for immutable Stage 6A replay JSONL ledgers.

The source ledger is never modified. A temporary SQLite spool bounds Python memory
while preserving exact Decimal measurements and per-entity end-of-window snapshots.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Any, Iterator

from .manifest import canonical_json, sha256_text
from .splits import ReplaySplitError, create_chronological_split_plan


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_ALLOWED_INTERVALS = {"1m", "5m", "15m"}
_OB_CENSORED = {"CANDIDATE", "ACTIVE_FRESH", "TOUCHED", "MITIGATED"}


class ReplayAnalyticsError(ValueError):
    """Raised when a replay ledger or analytics request is invalid."""


def _sha256_file(path: Path) -> tuple[str, int]:
    digest = sha256()
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def _valid_sha(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _SHA256_RE.fullmatch(value):
        raise ReplayAnalyticsError(f"ledger {label} must be a lowercase SHA-256 digest")
    return value


def _as_int(value: Any, label: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ReplayAnalyticsError(f"ledger {label} must be an integer >= {minimum}")
    return value


def _decimal(value: Any) -> Decimal | None:
    if value is None or isinstance(value, (bool, float)):
        return None
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None
    return result if result.is_finite() else None


def _decimal_text(value: Decimal | None) -> str | None:
    if value is None:
        return None
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def _distribution(values: list[Decimal]) -> dict[str, Any]:
    if not values:
        return {"n": 0, "min": None, "p50": None, "p90": None, "p95": None, "max": None}
    ordered = sorted(values)

    def nearest_rank(probability: Decimal) -> Decimal:
        rank = int((probability * len(ordered)).to_integral_value(rounding="ROUND_CEILING"))
        return ordered[max(0, rank - 1)]

    return {
        "n": len(ordered),
        "min": _decimal_text(ordered[0]),
        "p50": _decimal_text(nearest_rank(Decimal("0.50"))),
        "p90": _decimal_text(nearest_rank(Decimal("0.90"))),
        "p95": _decimal_text(nearest_rank(Decimal("0.95"))),
        "max": _decimal_text(ordered[-1]),
    }


def _rate(event_count: int, closed_bars: int) -> dict[str, Any]:
    if closed_bars == 0:
        value = None
    else:
        quantized = (Decimal(event_count) * Decimal(1000) / Decimal(closed_bars)).quantize(
            Decimal("0.000001"), rounding=ROUND_HALF_UP
        )
        value = _decimal_text(quantized)
    return {
        "event_count": event_count,
        "closed_bar_count": closed_bars,
        "rate_per_1000_closed_bars": value,
    }


def _extract_header(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as handle:
            line = handle.readline()
        item = json.loads(line.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ReplayAnalyticsError(f"cannot read valid UTF-8 JSONL header: {exc}") from exc
    if not isinstance(item, dict) or item.get("record_type") != "REPLAY_RUN_HEADER":
        raise ReplayAnalyticsError("ledger must begin with exactly one REPLAY_RUN_HEADER")
    return item


def _iter_strict_ledger(path: Path, *, expected_header: dict[str, Any], db: sqlite3.Connection,
                        split_plan: dict[str, Any]) -> tuple[int, int]:
    splits = split_plan["splits"]
    header_seen = False
    summary_seen = False
    previous_sequence = 0
    previous_known_at = -1
    sequence_known_at: int | None = None
    capture_summary_sequence: int | None = None
    capture_summary_count = 0
    capture_count = 0
    row_count = 0
    active_intervals = {item["interval"] for item in expected_header.get("source_files", [])}
    if not active_intervals or not active_intervals <= _ALLOWED_INTERVALS:
        raise ReplayAnalyticsError("ledger header source_files must declare supported active intervals")

    db.execute("CREATE TABLE records (row_id INTEGER PRIMARY KEY, split_label TEXT NOT NULL, record_type TEXT NOT NULL, timeframe TEXT, stage TEXT, payload TEXT NOT NULL)")
    db.execute("CREATE INDEX records_split_type ON records(split_label, record_type, timeframe)")
    db.execute("CREATE TABLE snapshots (split_label TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, known_at INTEGER NOT NULL, timeframe TEXT, payload TEXT NOT NULL, PRIMARY KEY(split_label, entity_type, entity_id))")

    with path.open("rb") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            if not raw_line.strip():
                raise ReplayAnalyticsError(f"blank JSONL line at {line_number}; one JSON object per line is required")
            try:
                item = json.loads(raw_line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ReplayAnalyticsError(f"invalid UTF-8 JSON at line {line_number}: {exc}") from exc
            if not isinstance(item, dict):
                raise ReplayAnalyticsError(f"line {line_number} is not a JSON object")
            if type(item.get("record_schema_version")) is not int or item.get("record_schema_version") != 1:
                raise ReplayAnalyticsError(f"unsupported/missing record_schema_version at line {line_number}")
            record_type = item.get("record_type")
            if not isinstance(record_type, str) or not record_type:
                raise ReplayAnalyticsError(f"missing record_type at line {line_number}")

            if line_number == 1:
                if record_type != "REPLAY_RUN_HEADER":
                    raise ReplayAnalyticsError("ledger must start with REPLAY_RUN_HEADER")
                header_seen = True
                if item != expected_header:
                    # Header bytes could be reformatted, but its parsed identity must remain stable.
                    if any(item.get(key) != expected_header.get(key) for key in (
                        "replay_run_id", "dataset_id", "config_sha256", "code_sha256",
                        "metadata_sha256", "dataset_window", "source_files", "clock_policy",
                    )):
                        raise ReplayAnalyticsError("ledger header changed between identity freeze and analysis")
                continue

            if summary_seen:
                raise ReplayAnalyticsError("records found after terminal REPLAY_RUN_SUMMARY")
            if item.get("replay_run_id") != expected_header["replay_run_id"]:
                raise ReplayAnalyticsError(f"mixed replay_run_id at line {line_number}")
            if item.get("dataset_id") != expected_header["dataset_id"]:
                raise ReplayAnalyticsError(f"mixed dataset_id at line {line_number}")

            if record_type == "REPLAY_RUN_SUMMARY":
                if line_number == 2 and not header_seen:
                    raise ReplayAnalyticsError("missing run header")
                if item.get("replay_run_id") != expected_header["replay_run_id"]:
                    raise ReplayAnalyticsError("terminal summary replay identity mismatch")
                summary_seen = True
                continue

            if item.get("symbol") != expected_header.get("symbol"):
                raise ReplayAnalyticsError(f"symbol identity mismatch at line {line_number}")
            sequence = _as_int(item.get("capture_sequence"), f"capture_sequence at line {line_number}")
            known_at = _as_int(item.get("known_at_time_ms"), f"known_at_time_ms at line {line_number}")
            if sequence < previous_sequence:
                raise ReplayAnalyticsError(f"capture_sequence reordered at line {line_number}")
            if sequence > previous_sequence:
                if sequence != previous_sequence + 1:
                    raise ReplayAnalyticsError(f"capture_sequence gap at line {line_number}")
                if previous_sequence and capture_summary_sequence != previous_sequence:
                    raise ReplayAnalyticsError(f"missing capture summary before sequence {sequence}")
                sequence_known_at = known_at
            elif sequence_known_at != known_at:
                raise ReplayAnalyticsError(f"capture known-at time changed within sequence {sequence}")
            if known_at < previous_known_at:
                raise ReplayAnalyticsError(f"known_at_time_ms reordered at line {line_number}")
            previous_sequence, previous_known_at = sequence, known_at
            if item.get("metadata_sha256") != expected_header["metadata_sha256"]:
                raise ReplayAnalyticsError(f"metadata identity mismatch at line {line_number}")
            if not isinstance(item.get("payload"), dict):
                raise ReplayAnalyticsError(f"payload must be an object at line {line_number}")
            payload = item["payload"]
            if payload.get("record_type") != record_type:
                raise ReplayAnalyticsError(f"payload record_type mismatch at line {line_number}")
            payload_timeframe = payload.get("timeframe")
            if item.get("timeframe") is not None and payload_timeframe is not None and item.get("timeframe") != payload_timeframe:
                raise ReplayAnalyticsError(f"timeframe identity mismatch at line {line_number}")
            if record_type == "REPLAY_CAPTURE_SUMMARY":
                if capture_summary_sequence == sequence:
                    raise ReplayAnalyticsError(f"duplicate capture summary at line {line_number}")
                updated = payload.get("updated_intervals")
                if (
                    not isinstance(updated, list)
                    or any(not isinstance(value, str) for value in updated)
                    or len(updated) != len(set(updated))
                    or any(value not in active_intervals for value in updated)
                ):
                    raise ReplayAnalyticsError(f"invalid updated_intervals at line {line_number}")
                if payload.get("capture_sequence") != sequence or payload.get("captured_at_ms") != known_at:
                    raise ReplayAnalyticsError(f"capture summary clock identity mismatch at line {line_number}")
                if payload.get("replay_capture_id") != item.get("replay_capture_id"):
                    raise ReplayAnalyticsError(f"capture summary id mismatch at line {line_number}")
                capture_count += 1
                capture_summary_count += 1
                capture_summary_sequence = sequence
            elif capture_summary_sequence == sequence:
                raise ReplayAnalyticsError(f"records follow capture summary for sequence {sequence}")

            label = next((split["label"] for split in splits
                          if split["start_ms"] <= known_at < split["end_ms_exclusive"]), None)
            if label is None:
                start = splits[0]["start_ms"]
                end = splits[-1]["end_ms_exclusive"]
                raise ReplayAnalyticsError(
                    f"known_at_time_ms {known_at} at line {line_number} falls outside [{start}, {end})"
                )
            timeframe = item.get("timeframe")
            if timeframe is not None and timeframe not in active_intervals:
                raise ReplayAnalyticsError(f"timeframe is not declared active in the manifest at line {line_number}: {timeframe!r}")
            payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            db.execute(
                "INSERT INTO records(split_label,record_type,timeframe,stage,payload) VALUES(?,?,?,?,?)",
                (label, record_type, timeframe, item.get("stage"), payload_json),
            )
            row_count += 1

            entity_type = entity_id = None
            if record_type == "ORDER_BLOCK_LIFECYCLE":
                candidate = payload.get("candidate")
                entity_id = candidate.get("candidate_id") if isinstance(candidate, dict) else None
                entity_type = "OB"
            elif record_type == "FVG":
                entity_id = payload.get("fvg_id")
                entity_type = "FVG"
            if isinstance(entity_id, str) and entity_id:
                for split in splits:
                    if known_at < split["end_ms_exclusive"]:
                        db.execute(
                            "INSERT INTO snapshots(split_label,entity_type,entity_id,known_at,timeframe,payload) "
                            "VALUES(?,?,?,?,?,?) ON CONFLICT(split_label,entity_type,entity_id) DO UPDATE SET "
                            "known_at=excluded.known_at,timeframe=excluded.timeframe,payload=excluded.payload "
                            "WHERE excluded.known_at >= snapshots.known_at",
                            (split["label"], entity_type, entity_id, known_at, timeframe, payload_json),
                        )
            if line_number % 2000 == 0:
                db.commit()

    if not header_seen or not summary_seen:
        raise ReplayAnalyticsError("ledger is truncated: run header and terminal run summary are required")
    expected_capture_count = _as_int(expected_header.get("_capture_count", capture_count), "capture_count")
    if expected_capture_count != capture_count:
        raise ReplayAnalyticsError("capture summary count does not match terminal run summary")
    if capture_count != previous_sequence or capture_summary_count != previous_sequence:
        raise ReplayAnalyticsError("capture sequence count does not match exactly one summary per sequence")
    db.commit()
    return row_count, capture_count


def _rows_for_split(db: sqlite3.Connection, label: str) -> Iterator[tuple[str, str | None, str | None, dict[str, Any]]]:
    cursor = db.execute(
        "SELECT record_type,timeframe,stage,payload FROM records WHERE split_label=? ORDER BY row_id",
        (label,),
    )
    for record_type, timeframe, stage, payload in cursor:
        yield record_type, timeframe, stage, json.loads(payload)


def _analyze_split(db: sqlite3.Connection, split: dict[str, Any], intervals: list[str]) -> dict[str, Any]:
    label = split["label"]
    bars: Counter[str] = Counter()
    rates: Counter[tuple[str, str | None, str | None]] = Counter()
    pivots = 0
    structure_events: Counter[str] = Counter()
    readiness_statuses: Counter[tuple[str, str]] = Counter()
    warmup_remaining: dict[str, list[Decimal]] = defaultdict(list)
    structure_by_layer: Counter[tuple[str, str]] = Counter()
    formation_outcomes: Counter[str] = Counter()
    rejection_reasons: Counter[str] = Counter()
    candidate_ids: set[str] = set()
    displacement: dict[str, list[Decimal]] = {
        "break_body_range_ratio": [],
        "close_extension_ticks": [],
        "leg_body_range_ratio": [],
        "directional_leg_candle_count": [],
    }
    ob_transition_counts: Counter[str] = Counter()
    ob_reason_counts: Counter[str] = Counter()
    ob_lifecycle_observed: list[tuple[str, str, int]] = []
    liquidity_reference_kinds: Counter[str] = Counter()
    liquidity_trace_events: Counter[str] = Counter()
    sweep_outcomes: Counter[str] = Counter()
    sweep_count = qualified_sweep_count = 0
    fvg_directions: Counter[str] = Counter()
    fvg_ids_created_in_split: set[str] = set()
    event_record_counts: Counter[str] = Counter()

    for record_type, timeframe, stage, payload in _rows_for_split(db, label):
        if record_type != "REPLAY_CAPTURE_SUMMARY":
            rates[(record_type, timeframe, stage)] += 1
        if record_type == "REPLAY_CAPTURE_SUMMARY":
            for interval in payload.get("updated_intervals", []):
                bars[interval] += 1
            readiness = payload.get("readiness", {})
            if isinstance(readiness, dict):
                for item in readiness.get("timeframes", []):
                    if isinstance(item, dict):
                        tf = str(item.get("timeframe", "UNKNOWN"))
                        status = str(item.get("status", "UNKNOWN"))
                        readiness_statuses[(tf, status)] += 1
                        remaining = _decimal(item.get("warmup_remaining_bars"))
                        if remaining is not None:
                            warmup_remaining[tf].append(remaining)
        elif record_type == "BAR_TRACE":
            pivots += len(payload.get("new_pivots", []))
            for event in payload.get("events", []):
                if isinstance(event, dict):
                    kind = str(event.get("event_type", "UNKNOWN"))
                    layer = str(event.get("layer", "UNKNOWN"))
                    structure_events[kind] += 1
                    structure_by_layer[(layer, kind)] += 1
        elif record_type == "OB_FORMATION_TRACE":
            outcome = str(payload.get("outcome", "UNKNOWN"))
            formation_outcomes[outcome] += 1
            if outcome != "CREATED":
                for reason in payload.get("reason_codes", []):
                    if isinstance(reason, str):
                        rejection_reasons[reason] += 1
            disp = payload.get("displacement")
            if isinstance(disp, dict):
                for key in displacement:
                    value = _decimal(disp.get(key))
                    if value is not None:
                        displacement[key].append(value)
        elif record_type == "ORDER_BLOCK_CANDIDATE":
            candidate_id = payload.get("candidate_id")
            if isinstance(candidate_id, str):
                candidate_ids.add(candidate_id)
        elif record_type == "OB_LIFECYCLE_TRACE":
            transition = str(payload.get("transition", "UNKNOWN"))
            to_status = str(payload.get("to_status", "UNKNOWN"))
            ob_transition_counts[f"{transition}:{to_status}"] += 1
            reason = payload.get("reason_code")
            if isinstance(reason, str) and reason:
                ob_reason_counts[reason] += 1
            candidate_id = payload.get("candidate_id")
            observed = payload.get("observed_time_ms")
            if isinstance(candidate_id, str) and isinstance(observed, int):
                ob_lifecycle_observed.append((candidate_id, transition, observed))
        elif record_type == "LIQUIDITY_FVG_TRACE":
            liquidity_trace_events[str(payload.get("event_type", "UNKNOWN"))] += 1
        elif record_type == "LIQUIDITY_REFERENCE":
            liquidity_reference_kinds[str(payload.get("kind", "UNKNOWN"))] += 1
        elif record_type == "LIQUIDITY_SWEEP":
            sweep_count += 1
            sweep_outcomes[str(payload.get("outcome", "UNKNOWN"))] += 1
            if payload.get("qualifies_as_sweep") is True:
                qualified_sweep_count += 1
        elif record_type == "FVG":
            fvg_id = payload.get("fvg_id")
            if isinstance(fvg_id, str):
                fvg_ids_created_in_split.add(fvg_id)
        event_record_counts[record_type] += 1

    for interval in intervals:
        bars.setdefault(interval, 0)

    event_rates = []
    for (record_type, timeframe, stage), count in sorted(
        rates.items(), key=lambda item: (item[0][0], item[0][1] or "", item[0][2] or "")
    ):
        denominator = bars.get(timeframe, 0) if timeframe else 0
        event_rates.append({
            "record_type": record_type,
            "timeframe": timeframe,
            "stage": stage,
            "rate": _rate(count, denominator),
        })

    snapshots = db.execute(
        "SELECT entity_type,entity_id,known_at,timeframe,payload FROM snapshots WHERE split_label=? ORDER BY entity_type,entity_id",
        (label,),
    )
    ob_statuses: Counter[str] = Counter()
    fvg_statuses: Counter[str] = Counter()
    ob_ages: list[Decimal] = []
    ob_mitigation_depths: list[Decimal] = []
    ob_elapsed_age_ms: list[Decimal] = []
    ob_touch_elapsed_ms: list[Decimal] = []
    ob_mitigation_elapsed_ms: list[Decimal] = []
    ob_invalidation_elapsed_ms: list[Decimal] = []
    ob_expiry_elapsed_ms: list[Decimal] = []
    ob_transition_elapsed_ms: dict[str, list[Decimal]] = defaultdict(list)
    fvg_fill_ratios: list[Decimal] = []
    fvg_touch_elapsed_bars: list[Decimal] = []
    fvg_fill_elapsed_bars: list[Decimal] = []
    censored_ob = censored_fvg = unique_ob = unique_fvg = 0
    from divatrading.market_data.klines import INTERVAL_MILLISECONDS
    for entity_type, entity_id, snapshot_known_at, timeframe, raw_payload in snapshots:
        payload = json.loads(raw_payload)
        if entity_type == "OB":
            unique_ob += 1
            status = str(payload.get("status", "UNKNOWN"))
            ob_statuses[status] += 1
            if status in _OB_CENSORED:
                censored_ob += 1
            age = _decimal(payload.get("age_bars"))
            if age is not None:
                ob_ages.append(age)
            candidate_payload = payload.get("candidate")
            candidate_break = candidate_payload.get("break") if isinstance(candidate_payload, dict) else None
            break_time = candidate_break.get("confirmation_time_ms") if isinstance(candidate_break, dict) else None
            if isinstance(break_time, int) and snapshot_known_at >= break_time:
                ob_elapsed_age_ms.append(Decimal(snapshot_known_at - break_time))
            for field_name, target in (("first_touch_time_ms", ob_touch_elapsed_ms), ("mitigation_time_ms", ob_mitigation_elapsed_ms), ("invalidation_time_ms", ob_invalidation_elapsed_ms), ("expiry_time_ms", ob_expiry_elapsed_ms)):
                event_time = payload.get(field_name)
                if isinstance(break_time, int) and isinstance(event_time, int) and event_time >= break_time:
                    target.append(Decimal(event_time - break_time))
            depth = _decimal(payload.get("maximum_mitigation_depth_ratio"))
            if depth is not None:
                ob_mitigation_depths.append(depth)
        elif entity_type == "FVG":
            unique_fvg += 1
            status = str(payload.get("status", "UNKNOWN"))
            fvg_statuses[status] += 1
            direction = payload.get("direction")
            fvg_directions["BULLISH" if direction == 1 else "BEARISH" if direction == -1 else "UNKNOWN"] += 1
            if status != "FILLED":
                censored_fvg += 1
            ratio = _decimal(payload.get("maximum_fill_ratio"))
            if ratio is not None:
                fvg_fill_ratios.append(ratio)
            duration = INTERVAL_MILLISECONDS.get(timeframe or "")
            confirmed = payload.get("confirmation_time_ms")
            touched = payload.get("first_touch_time_ms")
            filled = payload.get("fill_time_ms")
            if duration and isinstance(confirmed, int) and isinstance(touched, int) and touched >= confirmed:
                fvg_touch_elapsed_bars.append(Decimal((touched - confirmed) // duration))
            if duration and isinstance(confirmed, int) and isinstance(filled, int) and filled >= confirmed:
                fvg_fill_elapsed_bars.append(Decimal((filled - confirmed) // duration))

    for candidate_id, transition, observed_time in ob_lifecycle_observed:
        snapshot_row = db.execute(
            "SELECT payload FROM snapshots WHERE split_label=? AND entity_type='OB' AND entity_id=?",
            (label, candidate_id),
        ).fetchone()
        if snapshot_row is None:
            continue
        snapshot_payload = json.loads(snapshot_row[0])
        candidate_payload = snapshot_payload.get("candidate")
        break_payload = candidate_payload.get("break") if isinstance(candidate_payload, dict) else None
        break_time = break_payload.get("confirmation_time_ms") if isinstance(break_payload, dict) else None
        if isinstance(break_time, int) and observed_time >= break_time:
            ob_transition_elapsed_ms[transition].append(Decimal(observed_time - break_time))

    return {
        "split_label": label,
        "closed_bars_by_timeframe": dict(sorted(bars.items())),
        "event_rates": event_rates,
        "rejection_reason_counts": [
            {"reason_code": code, "count": count} for code, count in sorted(rejection_reasons.items())
        ],
        "market_structure": {
            "bar_trace_count": event_record_counts.get("BAR_TRACE", 0),
            "pivot_count": pivots,
            "event_counts": dict(sorted(structure_events.items())),
            "readiness_status_counts": [
                {"timeframe": tf, "status": status, "count": count}
                for (tf, status), count in sorted(readiness_statuses.items())
            ],
            "warmup_remaining_bars_distributions": {tf: _distribution(values) for tf, values in sorted(warmup_remaining.items())},
            "event_counts_by_layer": [
                {"layer": layer, "event_type": event_type, "count": count}
                for (layer, event_type), count in sorted(structure_by_layer.items())
            ],
        },
        "displacement_distributions": {key: _distribution(values) for key, values in displacement.items()},
        "ob_lifecycle": {
            "formation_trace_count": event_record_counts.get("OB_FORMATION_TRACE", 0),
            "formation_outcomes": dict(sorted(formation_outcomes.items())),
            "unique_candidates_created_in_split": len(candidate_ids),
            "lifecycle_transition_counts": dict(sorted(ob_transition_counts.items())),
            "lifecycle_reason_counts": dict(sorted(ob_reason_counts.items())),
            "unique_entities_observed_by_split_end": unique_ob,
            "status_counts_at_split_end": dict(sorted(ob_statuses.items())),
            "age_bars_distribution": _distribution(ob_ages),
            "elapsed_age_ms_distribution": _distribution(ob_elapsed_age_ms),
            "confirmation_to_first_touch_elapsed_ms_distribution": _distribution(ob_touch_elapsed_ms),
            "confirmation_to_mitigation_elapsed_ms_distribution": _distribution(ob_mitigation_elapsed_ms),
            "confirmation_to_invalidation_elapsed_ms_distribution": _distribution(ob_invalidation_elapsed_ms),
            "confirmation_to_expiry_elapsed_ms_distribution": _distribution(ob_expiry_elapsed_ms),
            "transition_elapsed_ms_distributions": {key: _distribution(values) for key, values in sorted(ob_transition_elapsed_ms.items())},
            "touch_transition_count": sum(count for key, count in ob_transition_counts.items() if key.startswith("TOUCH:")),
            "mitigation_transition_count": sum(count for key, count in ob_transition_counts.items() if key.startswith("MITIGATION")),
            "invalidation_transition_count": sum(count for key, count in ob_transition_counts.items() if key.startswith("INVALIDATED:")),
            "expiry_transition_count": sum(count for key, count in ob_transition_counts.items() if key.startswith("EXPIRED:")),
            "maximum_mitigation_depth_ratio_distribution": _distribution(ob_mitigation_depths),
        },
        "liquidity_fvg": {
            "liquidity_reference_count": event_record_counts.get("LIQUIDITY_REFERENCE", 0),
            "reference_kind_counts": dict(sorted(liquidity_reference_kinds.items())),
            "liquidity_trace_event_counts": dict(sorted(liquidity_trace_events.items())),
            "sweep_count": sweep_count,
            "qualified_sweep_count": qualified_sweep_count,
            "sweep_outcome_counts": dict(sorted(sweep_outcomes.items())),
            "fvg_snapshot_records_in_split": event_record_counts.get("FVG", 0),
            "unique_fvgs_observed_in_split": len(fvg_ids_created_in_split),
            "unique_entities_observed_by_split_end": unique_fvg,
            "direction_counts_at_split_end": dict(sorted(fvg_directions.items())),
            "status_counts_at_split_end": dict(sorted(fvg_statuses.items())),
            "maximum_fill_ratio_distribution": _distribution(fvg_fill_ratios),
            "confirmation_to_first_touch_elapsed_bars_distribution": _distribution(fvg_touch_elapsed_bars),
            "confirmation_to_full_fill_elapsed_bars_distribution": _distribution(fvg_fill_elapsed_bars),
        },
        "right_censored": {
            "ob_count": censored_ob,
            "fvg_count": censored_fvg,
            "censoring_policy": "ADMINISTRATIVE_AT_SPLIT_END_NOT_TRADE_FAILURE",
        },
    }


def analyze_replay_ledger(ledger_path: str | Path) -> dict[str, Any]:
    """Validate, split-label and aggregate one complete immutable Stage 6A ledger."""
    path = Path(ledger_path).resolve()
    if not path.is_file():
        raise ReplayAnalyticsError(f"ledger file does not exist: {path}")
    ledger_sha256, ledger_bytes = _sha256_file(path)
    header = _extract_header(path)
    if type(header.get("record_schema_version")) is not int or header.get("record_schema_version") != 1:
        raise ReplayAnalyticsError("unsupported replay ledger header schema version")
    replay_run_id = _valid_sha(header.get("replay_run_id"), "replay_run_id")
    dataset_id = _valid_sha(header.get("dataset_id"), "dataset_id")
    config_sha256 = _valid_sha(header.get("config_sha256"), "config_sha256")
    code_sha256 = _valid_sha(header.get("code_sha256"), "code_sha256")
    metadata_sha256 = _valid_sha(header.get("metadata_sha256"), "metadata_sha256")
    window = header.get("dataset_window")
    if not isinstance(window, dict):
        raise ReplayAnalyticsError("ledger header dataset_window is missing")
    start_ms = _as_int(window.get("start_open_time_ms"), "dataset_window.start_open_time_ms")
    dataset_end_ms = _as_int(window.get("end_open_time_ms_exclusive"), "dataset_window.end_open_time_ms_exclusive", minimum=1)
    if dataset_end_ms <= start_ms:
        raise ReplayAnalyticsError("ledger dataset window is invalid")
    # The close-plus-one-millisecond replay clock can produce a final capture exactly
    # at the source window's end boundary. Extend only the final half-open boundary by
    # 1ms so that this known-at-terminal candle is assigned to TEST rather than lost.
    analysis_end_ms = dataset_end_ms + 1
    source_files = header.get("source_files")
    if not isinstance(source_files, list) or not source_files:
        raise ReplayAnalyticsError("ledger header source_files are missing")
    intervals: list[str] = []
    for entry in source_files:
        if not isinstance(entry, dict) or entry.get("interval") not in _ALLOWED_INTERVALS:
            raise ReplayAnalyticsError("ledger source_files contain an invalid interval")
        intervals.append(entry["interval"])
        _valid_sha(entry.get("sha256"), "source file sha256")
    intervals = sorted(set(intervals), key=lambda item: (int(item[:-1]), item))

    try:
        split_plan = create_chronological_split_plan(
            start_ms, analysis_end_ms, intervals,
            target_ratios=(Decimal("0.60"), Decimal("0.20"), Decimal("0.20")),
            terminal_boundary_ms=dataset_end_ms,
        )
    except ReplaySplitError as exc:
        raise ReplayAnalyticsError(str(exc)) from exc

    frozen_identity = {
        "dataset_id": dataset_id,
        "ledger_sha256": ledger_sha256,
        "code_sha256": code_sha256,
        "config_sha256": config_sha256,
        "metadata_sha256": metadata_sha256,
        "split_plan": split_plan,
        "analysis_schema_version": 1,
    }
    split_plan["frozen_identity_sha256"] = sha256_text(canonical_json(frozen_identity))

    with tempfile.TemporaryDirectory(prefix="divatrading_replay_analytics_") as temp_dir:
        db_path = Path(temp_dir) / "analytics.sqlite3"
        db = sqlite3.connect(db_path)
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            header_for_validation = dict(header)
            # The terminal capture count is checked against capture summary records after streaming.
            terminal_summary = _read_terminal_summary(path)
            header_for_validation["_capture_count"] = terminal_summary.get("capture_count")
            _iter_strict_ledger(path, expected_header=header_for_validation, db=db, split_plan=split_plan)
            report = {
                "report_schema_version": 1,
                "report_type": "REPLAY_EVIDENCE_ANALYTICS",
                "provenance": {
                    "replay_run_id": replay_run_id,
                    "dataset_id": dataset_id,
                    "ledger_sha256": ledger_sha256,
                    "code_sha256": code_sha256,
                    "config_sha256": config_sha256,
                    "metadata_sha256": metadata_sha256,
                    "ledger_bytes": ledger_bytes,
                },
                "analysis_window": {"start_ms": start_ms, "end_ms_exclusive": analysis_end_ms},
                "split_plan": split_plan,
                "state_policy": "ONE_CONTINUOUS_REPLAY_NO_SPLIT_RESET",
                "metrics_by_split": [
                    _analyze_split(db, split, intervals) for split in split_plan["splits"]
                ],
            }
            report["report_sha256"] = sha256_text(canonical_json(report))
        finally:
            db.close()

    # Detect source mutation between identity freeze and completion of analytics.
    post_sha, post_size = _sha256_file(path)
    if post_sha != ledger_sha256 or post_size != ledger_bytes:
        raise ReplayAnalyticsError("ledger changed during analysis; refusing to emit a report")
    return report


def _read_terminal_summary(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as handle:
            last = None
            for raw in handle:
                if raw.strip():
                    last = raw
        item = json.loads(last.decode("utf-8")) if last is not None else None
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ReplayAnalyticsError(f"cannot read terminal summary: {exc}") from exc
    if not isinstance(item, dict) or item.get("record_type") != "REPLAY_RUN_SUMMARY":
        raise ReplayAnalyticsError("ledger must end with REPLAY_RUN_SUMMARY")
    return item


def write_evidence_analytics_report(report: dict[str, Any], destination: str | Path) -> Path:
    """Atomically write an analytics report without altering the source ledger."""
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    raw = json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except OSError:
        temporary.unlink(missing_ok=True)
        raise
    return path
