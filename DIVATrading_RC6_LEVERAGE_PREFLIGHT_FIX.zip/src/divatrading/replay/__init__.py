"""Deterministic, evidence-only historical replay for SMC V2."""

from .engine import (
    HistoricalReplayRunner,
    ReplayConfig,
    ReplayRunSummary,
    ReplayRunnerError,
)
from .klines import ReplayKlineReadError, iter_binance_kline_rows, iter_kline_chunks, iter_rest_klines
from .analytics import ReplayAnalyticsError, analyze_replay_ledger, write_evidence_analytics_report
from .convergence import WarmupConvergenceError, analyze_warmup_convergence, write_warmup_convergence_report
from .splits import ReplaySplitError, create_chronological_split_plan, interval_alignment_quantum, label_split
from .quality import (
    DatasetQualityAuditError,
    ReplayQualitySource,
    audit_replay_dataset_quality,
    audit_replay_manifest_quality,
    write_dataset_quality_report,
)
from .workflow import ReplayWorkflowError, ReplayWorkflowEligibilityError, run_stage6b_workflow
from .intake import (
    BinanceIntakeError,
    BinanceRestKlineIntake,
    BinanceMetadataCapture,
    collect_binance_um_klines_rest,
    capture_current_binance_um_metadata,
)
from .manifest import (
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayManifestError,
    ReplayMetadataSnapshot,
    sha256_file,
)

__all__ = [
    "DatasetQualityAuditError",
    "BinanceIntakeError",
    "BinanceRestKlineIntake",
    "BinanceMetadataCapture",
    "collect_binance_um_klines_rest",
    "capture_current_binance_um_metadata",
    "ReplayWorkflowError",
    "ReplayWorkflowEligibilityError",
    "run_stage6b_workflow",
    "ReplayAnalyticsError",
    "WarmupConvergenceError",
    "analyze_warmup_convergence",
    "write_warmup_convergence_report",
    "ReplaySplitError",
    "analyze_replay_ledger",
    "create_chronological_split_plan",
    "interval_alignment_quantum",
    "label_split",
    "write_evidence_analytics_report",
    "HistoricalReplayRunner",
    "ReplayConfig",
    "ReplayDatasetManifest",
    "ReplayKlineFile",
    "ReplayKlineReadError",
    "ReplayManifestError",
    "ReplayMetadataSnapshot",
    "ReplayRunSummary",
    "ReplayRunnerError",
    "ReplayQualitySource",
    "iter_binance_kline_rows",
    "iter_kline_chunks",
    "iter_rest_klines",
    "sha256_file",
    "audit_replay_dataset_quality",
    "audit_replay_manifest_quality",
    "write_dataset_quality_report",
]
