"""Read-only raw-source dataset quality auditor for Binance USD-M Klines.

The scanner intentionally runs before strict ReplayDatasetManifest construction so
that duplicate/revision and ordering defects remain observable. It never repairs,
sorts, deduplicates, rounds, or rewrites source rows.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from hashlib import sha256
import json
import sqlite3
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping
from zipfile import BadZipFile, ZipFile
from io import TextIOWrapper

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS
from .manifest import (
    ReplayDatasetManifest,
    ReplayMetadataSnapshot,
    canonical_json,
    sha256_file,
    sha256_text,
)


_REPORT_SCHEMA_VERSION = 2
_SAMPLE_CAP = 100
_ZERO_SHA256 = sha256(b"").hexdigest()
_PRICE_FIELDS = ((1, "open"), (2, "high"), (3, "low"), (4, "close"))
_NUMERIC_FIELDS = (1, 2, 3, 4, 5, 7, 9, 10)


class DatasetQualityAuditError(ValueError):
    """Raised when an audit request itself is invalid (not when source data is bad)."""


@dataclass(frozen=True, slots=True)
class ReplayQualitySource:
    """One raw source file. Paths are relative to ``dataset_root``."""

    interval: str
    path: str
    expected_sha256: str | None = None
    row_count_declared: int | None = None
    declared_symbol: str | None = None
    source_url: str = ""

    def __post_init__(self) -> None:
        if self.interval not in INTERVAL_MILLISECONDS:
            raise DatasetQualityAuditError("source interval must be 1m, 5m or 15m")
        if not isinstance(self.path, str) or not self.path.strip():
            raise DatasetQualityAuditError("source path is required")
        source_path = Path(self.path)
        if source_path.is_absolute() or ".." in source_path.parts:
            raise DatasetQualityAuditError("source path must be relative and cannot escape dataset root")
        if self.expected_sha256 is not None:
            if len(self.expected_sha256) != 64 or any(c not in "0123456789abcdef" for c in self.expected_sha256):
                raise DatasetQualityAuditError("expected_sha256 must be 64 lowercase hexadecimal characters")
        if self.row_count_declared is not None and (
            isinstance(self.row_count_declared, bool)
            or not isinstance(self.row_count_declared, int)
            or self.row_count_declared < 0
        ):
            raise DatasetQualityAuditError("row_count_declared must be a non-negative integer or None")
        if self.declared_symbol is not None and not isinstance(self.declared_symbol, str):
            raise DatasetQualityAuditError("declared_symbol must be a string or None")
        if not isinstance(self.source_url, str):
            raise DatasetQualityAuditError("source_url must be a string")


def _parse_int(value: str) -> int:
    text = value.strip()
    parsed = int(text)
    if text not in {str(parsed), f"{parsed}.0"}:
        raise ValueError("not an exact integer")
    return parsed


def _parse_decimal(value: str) -> Decimal:
    parsed = Decimal(value.strip())
    if not parsed.is_finite():
        raise ValueError("decimal must be finite")
    return parsed


def _open_raw_source(path: Path):
    """Return a text CSV stream and optional archive handle."""
    if path.suffix.lower() == ".zip":
        archive = ZipFile(path, "r")
        names = sorted(
            name for name in archive.namelist()
            if name.lower().endswith(".csv") and not name.endswith("/")
        )
        if len(names) != 1:
            archive.close()
            raise DatasetQualityAuditError("Kline ZIP must contain exactly one CSV member")
        return TextIOWrapper(archive.open(names[0], "r"), encoding="utf-8", newline=""), archive
    if path.suffix.lower() not in {".csv", ".txt"}:
        raise DatasetQualityAuditError("source must be .csv, .txt or .zip")
    return path.open("r", encoding="utf-8", newline=""), None


def _metadata_payload(
    symbol: str,
    metadata: ReplayMetadataSnapshot | None,
    independent_evidence_ref: str | None,
) -> tuple[dict[str, Any], Decimal | None, list[tuple[str, str]]]:
    issues: list[tuple[str, str]] = []
    if metadata is None:
        return ({
            "quality": "MISSING_OR_CONFLICTED",
            "source_url": "unavailable",
            "captured_at_ms": 0,
            "effective_from_ms": None,
            "effective_to_ms": None,
            "tick_size": None,
            "sha256": _ZERO_SHA256,
            "independent_evidence_ref": None,
        }, None, [("METADATA_MISSING", "No exchange metadata snapshot was supplied.")])

    raw = json.loads(metadata.raw_symbol_info_json)
    tick_size: Decimal | None = None
    try:
        info = SymbolInfo.from_payload(raw)
        if info.symbol != symbol:
            issues.append(("METADATA_SYMBOL_MISMATCH", "Metadata symbol does not match audit symbol."))
        if not info.is_tradable_usdt_perpetual:
            issues.append(("METADATA_CONTRACT_MISMATCH", "Metadata is not an active USDT-margined USD-M perpetual."))
        if info.price_filter is not None and info.price_filter.tick_size is not None:
            candidate = info.price_filter.tick_size
            if candidate > 0:
                tick_size = candidate
    except Exception as exc:  # Metadata is user-supplied evidence; report rather than hide it.
        issues.append(("METADATA_INVALID", f"Cannot parse Binance symbol metadata: {exc}"))

    evidence_ref = independent_evidence_ref.strip() if isinstance(independent_evidence_ref, str) else None
    if evidence_ref == "":
        evidence_ref = None
    payload = {
        "quality": metadata.quality,
        "source_url": metadata.source_url,
        "captured_at_ms": metadata.captured_at_ms,
        "effective_from_ms": metadata.effective_from_ms,
        "effective_to_ms": metadata.effective_to_ms,
        "tick_size": format(tick_size, "f") if tick_size is not None else None,
        "sha256": metadata.sha256,
        "independent_evidence_ref": evidence_ref,
    }
    return payload, tick_size, issues


def _coverage_gap_clusters(
    connection: sqlite3.Connection,
    interval: str,
    start_ms: int,
    end_ms: int,
    step_ms: int,
    *,
    sample_cap: int = _SAMPLE_CAP,
) -> tuple[int, int, int, list[dict[str, int | None]], int]:
    """Return missing count, leading/trailing counts, and bounded gap clusters."""
    cursor = start_ms
    previous_valid: int | None = None
    missing_total = 0
    leading_missing = 0
    trailing_missing = 0
    cluster_count = 0
    samples: list[dict[str, int | None]] = []

    rows = connection.execute(
        "SELECT open_time_ms FROM bars WHERE interval = ? AND coverage_valid = 1 "
        "AND open_time_ms >= ? AND open_time_ms < ? AND open_time_ms % ? = 0 "
        "ORDER BY open_time_ms",
        (interval, start_ms, end_ms, step_ms),
    )
    for (open_time_ms,) in rows:
        if open_time_ms < cursor:
            continue
        if open_time_ms > cursor:
            count = (open_time_ms - cursor) // step_ms
            missing_total += count
            if previous_valid is None:
                leading_missing += count
            cluster_count += 1
            if len(samples) < sample_cap:
                samples.append({
                    "last_valid_open_time_ms": previous_valid,
                    "first_missing_open_time_ms": cursor,
                    "last_missing_open_time_ms": open_time_ms - step_ms,
                    "first_resumed_open_time_ms": open_time_ms,
                    "missing_bar_count": count,
                })
        previous_valid = open_time_ms
        cursor = open_time_ms + step_ms

    if cursor < end_ms:
        count = (end_ms - cursor) // step_ms
        missing_total += count
        trailing_missing = count
        cluster_count += 1
        if previous_valid is None:
            leading_missing = count
        if len(samples) < sample_cap:
            samples.append({
                "last_valid_open_time_ms": previous_valid,
                "first_missing_open_time_ms": cursor,
                "last_missing_open_time_ms": end_ms - step_ms,
                "first_resumed_open_time_ms": None,
                "missing_bar_count": count,
            })
    return missing_total, leading_missing, trailing_missing, samples, cluster_count


def audit_replay_dataset_quality(
    *,
    dataset_root: str | Path,
    symbol: str,
    start_open_time_ms: int,
    end_open_time_ms_exclusive: int,
    sources: Iterable[ReplayQualitySource],
    metadata: ReplayMetadataSnapshot | None,
    independent_evidence_ref: str | None = None,
    sample_cap: int = _SAMPLE_CAP,
) -> dict[str, Any]:
    """Audit raw Binance Kline files and return a deterministic schema-v1 report.

    This API deliberately accepts raw descriptors rather than requiring a strict
    Stage 6A manifest, allowing invalid files to be diagnosed before manifest creation.
    """
    normalized_symbol = symbol.strip().upper() if isinstance(symbol, str) else ""
    if not normalized_symbol or not normalized_symbol.isalnum() or len(normalized_symbol) > 30:
        raise DatasetQualityAuditError("symbol must be an exact uppercase Binance symbol")
    if any(isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in (start_open_time_ms, end_open_time_ms_exclusive)):
        raise DatasetQualityAuditError("dataset window must use non-negative integer UTC milliseconds")
    if start_open_time_ms >= end_open_time_ms_exclusive:
        raise DatasetQualityAuditError("dataset window must be non-empty and end-exclusive")
    if isinstance(sample_cap, bool) or not isinstance(sample_cap, int) or not 1 <= sample_cap <= 100:
        raise DatasetQualityAuditError("sample_cap must be between 1 and 100")
    selected_sources = tuple(sources)
    if not selected_sources or any(not isinstance(item, ReplayQualitySource) for item in selected_sources):
        raise DatasetQualityAuditError("at least one ReplayQualitySource is required")

    intervals = sorted({item.interval for item in selected_sources}, key=("1m", "5m", "15m").index)
    for interval in intervals:
        step = INTERVAL_MILLISECONDS[interval]
        if start_open_time_ms % step or end_open_time_ms_exclusive % step:
            raise DatasetQualityAuditError(f"dataset window must align to selected {interval} boundaries")

    root = Path(dataset_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    metadata_report, tick_size, metadata_issues = _metadata_payload(
        normalized_symbol, metadata, independent_evidence_ref
    )
    issue_samples: dict[str, list[dict[str, Any]]] = {interval: [] for interval in intervals}
    global_sample_count = 0

    def sample(interval: str, code: str, path: str, row_number: int | None, **details: Any) -> None:
        nonlocal global_sample_count
        if global_sample_count >= sample_cap:
            return
        issue_samples[interval].append({
            "issue_code": code,
            "source_path": path,
            "row_number": row_number,
            **details,
        })
        global_sample_count += 1

    integrity: dict[str, dict[str, int]] = {
        interval: {
            "identical_duplicate_rows": 0,
            "conflicting_revision_rows": 0,
            "non_monotonic_rows": 0,
            "cross_file_overlap_rows": 0,
            "malformed_rows": 0,
            "out_of_window_rows": 0,
            "misaligned_open_times": 0,
            "close_time_mismatches": 0,
            "ohlc_relationship_violations": 0,
            "symbol_interval_mismatches": 0,
        }
        for interval in intervals
    }
    tick_violations = {interval: 0 for interval in intervals}
    timeframe_rows = {interval: 0 for interval in intervals}
    source_reports: list[dict[str, Any]] = []
    failure_conditions: set[str] = set()
    warning_conditions: set[str] = set()
    failure_occurrences: dict[str, int] = {}
    warning_occurrences: dict[str, int] = {}

    def fail(code: str, count: int = 1) -> None:
        if count <= 0:
            return
        failure_conditions.add(code)
        failure_occurrences[code] = failure_occurrences.get(code, 0) + count

    def warn(code: str, count: int = 1) -> None:
        if count <= 0:
            return
        warning_conditions.add(code)
        warning_occurrences[code] = warning_occurrences.get(code, 0) + count

    with tempfile.TemporaryDirectory(prefix="divatrading-quality-") as temp_dir:
        db_path = Path(temp_dir) / "quality-index.sqlite3"
        connection = sqlite3.connect(db_path)
        try:
            connection.execute("PRAGMA journal_mode=OFF")
            connection.execute("PRAGMA synchronous=OFF")
            connection.execute("PRAGMA temp_store=MEMORY")
            connection.execute("PRAGMA cache_size=-8192")
            connection.execute(
                "CREATE TABLE bars (interval TEXT NOT NULL, open_time_ms INTEGER NOT NULL, "
                "signature TEXT NOT NULL, first_source TEXT NOT NULL, coverage_valid INTEGER NOT NULL, "
                "PRIMARY KEY(interval, open_time_ms)) WITHOUT ROWID"
            )
            ordered_sources = sorted(selected_sources, key=lambda item: (intervals.index(item.interval), item.path))
            for source_index, source in enumerate(ordered_sources):
                interval = source.interval
                step = INTERVAL_MILLISECONDS[interval]
                source_path = (root / source.path).resolve()
                if root != source_path and root not in source_path.parents:
                    raise DatasetQualityAuditError(f"source path escapes dataset root: {source.path}")
                observed_rows = 0
                previous_open: int | None = None
                source_hash = _ZERO_SHA256
                source_readable = source_path.is_file()
                if not source_readable:
                    fail("SOURCE_MISSING")
                    sample(interval, "SOURCE_MISSING", source.path, None)
                else:
                    try:
                        source_hash = sha256_file(source_path)
                    except OSError as exc:
                        source_readable = False
                        fail("SOURCE_UNREADABLE")
                        sample(interval, "SOURCE_UNREADABLE", source.path, None, message=str(exc))
                if source.expected_sha256 and source_hash != source.expected_sha256:
                    fail("SOURCE_HASH_MISMATCH")
                    sample(interval, "SOURCE_HASH_MISMATCH", source.path, None,
                           expected_sha256=source.expected_sha256, observed_sha256=source_hash)
                if source.declared_symbol and source.declared_symbol.strip().upper() != normalized_symbol:
                    integrity[interval]["symbol_interval_mismatches"] += 1
                    fail("SOURCE_SYMBOL_MISMATCH")
                    sample(interval, "SOURCE_SYMBOL_MISMATCH", source.path, None,
                           declared_symbol=source.declared_symbol, expected_symbol=normalized_symbol)

                if source_readable:
                    try:
                        handle, archive = _open_raw_source(source_path)
                    except (OSError, BadZipFile, DatasetQualityAuditError) as exc:
                        integrity[interval]["malformed_rows"] += 1
                        fail("SOURCE_FORMAT_INVALID")
                        sample(interval, "SOURCE_FORMAT_INVALID", source.path, None, message=str(exc))
                        handle = archive = None
                    if handle is not None:
                        try:
                            reader = csv.reader(handle, strict=True)
                            for row in reader:
                                line_number = reader.line_num
                                if not row or all(not field.strip() for field in row):
                                    continue
                                if observed_rows == 0 and row[0].strip().lower() in {"open_time", "open_time_ms"}:
                                    continue
                                observed_rows += 1
                                timeframe_rows[interval] += 1
                                if len(row) != 12:
                                    integrity[interval]["malformed_rows"] += 1
                                    fail("MALFORMED_ROW")
                                    sample(interval, "MALFORMED_ROW", source.path, line_number,
                                           field_count=len(row), expected_field_count=12)
                                    continue

                                raw = tuple(field.strip() for field in row)
                                try:
                                    open_time = _parse_int(raw[0])
                                except (ValueError, TypeError, InvalidOperation):
                                    integrity[interval]["malformed_rows"] += 1
                                    fail("MALFORMED_TIMESTAMP")
                                    sample(interval, "MALFORMED_TIMESTAMP", source.path, line_number,
                                           raw_open_time=raw[0])
                                    continue
                                if open_time < 0:
                                    integrity[interval]["malformed_rows"] += 1
                                    fail("NEGATIVE_TIMESTAMP")
                                    sample(interval, "NEGATIVE_TIMESTAMP", source.path, line_number,
                                           open_time_ms=open_time)
                                    continue
                                if previous_open is not None and open_time < previous_open:
                                    integrity[interval]["non_monotonic_rows"] += 1
                                    fail("NON_MONOTONIC_ROW")
                                    sample(interval, "NON_MONOTONIC_ROW", source.path, line_number,
                                           previous_open_time_ms=previous_open, open_time_ms=open_time)
                                previous_open = open_time
                                in_window = start_open_time_ms <= open_time < end_open_time_ms_exclusive
                                aligned = open_time % step == 0
                                if not in_window:
                                    integrity[interval]["out_of_window_rows"] += 1
                                    fail("OUT_OF_WINDOW_ROW")
                                    sample(interval, "OUT_OF_WINDOW_ROW", source.path, line_number,
                                           open_time_ms=open_time)
                                if not aligned:
                                    integrity[interval]["misaligned_open_times"] += 1
                                    fail("MISALIGNED_OPEN_TIME")
                                    sample(interval, "MISALIGNED_OPEN_TIME", source.path, line_number,
                                           open_time_ms=open_time, step_ms=step)

                                numeric_ok = True
                                decimals: dict[int, Decimal] = {}
                                for field_index in _NUMERIC_FIELDS:
                                    try:
                                        decimals[field_index] = _parse_decimal(raw[field_index])
                                    except (InvalidOperation, ValueError, TypeError):
                                        numeric_ok = False
                                close_time: int | None = None
                                try:
                                    close_time = _parse_int(raw[6])
                                except (ValueError, TypeError, InvalidOperation):
                                    numeric_ok = False
                                try:
                                    trade_count = _parse_int(raw[8])
                                    if trade_count < 0:
                                        numeric_ok = False
                                except (ValueError, TypeError, InvalidOperation):
                                    numeric_ok = False
                                if min(decimals.get(i, Decimal("-1")) for i in (5, 7, 9, 10)) < 0:
                                    numeric_ok = False
                                if not numeric_ok:
                                    integrity[interval]["malformed_rows"] += 1
                                    fail("MALFORMED_NUMERIC_ROW")
                                    sample(interval, "MALFORMED_NUMERIC_ROW", source.path, line_number,
                                           open_time_ms=open_time)
                                close_time_valid = close_time is not None and close_time == open_time + step - 1
                                if close_time is not None and not close_time_valid:
                                    integrity[interval]["close_time_mismatches"] += 1
                                    fail("CLOSE_TIME_MISMATCH")
                                    sample(interval, "CLOSE_TIME_MISMATCH", source.path, line_number,
                                           open_time_ms=open_time, close_time_ms=close_time,
                                           expected_close_time_ms=open_time + step - 1)

                                price_fields_available = all(index in decimals for index, _ in _PRICE_FIELDS)
                                ohlc_valid = False
                                if price_fields_available:
                                    prices = [decimals[index] for index, _ in _PRICE_FIELDS]
                                    open_price, high_price, low_price, close_price = prices
                                    ohlc_valid = (
                                        min(prices) > 0
                                        and high_price >= max(open_price, low_price, close_price)
                                        and low_price <= min(open_price, high_price, close_price)
                                    )
                                    if not ohlc_valid:
                                        integrity[interval]["ohlc_relationship_violations"] += 1
                                        fail("OHLC_RELATIONSHIP")
                                        sample(interval, "OHLC_RELATIONSHIP", source.path, line_number,
                                               open_time_ms=open_time, open=raw[1], high=raw[2],
                                               low=raw[3], close=raw[4])
                                    if tick_size is not None and in_window:
                                        for field_index, field_name in _PRICE_FIELDS:
                                            price = decimals[field_index]
                                            if price % tick_size != 0:
                                                tick_violations[interval] += 1
                                                fail("TICK_GRID_VIOLATION")
                                                sample(interval, "TICK_GRID_VIOLATION", source.path, line_number,
                                                       open_time_ms=open_time, field=field_name,
                                                       price=format(price, "f"), tick_size=format(tick_size, "f"))

                                signature = json.dumps(raw, ensure_ascii=False, separators=(",", ":"))
                                coverage_valid = int(numeric_ok and close_time_valid and ohlc_valid and in_window and aligned)
                                existing = connection.execute(
                                    "SELECT signature, first_source, coverage_valid FROM bars "
                                    "WHERE interval = ? AND open_time_ms = ?",
                                    (interval, open_time),
                                ).fetchone()
                                if existing is None:
                                    connection.execute(
                                        "INSERT INTO bars VALUES (?, ?, ?, ?, ?)",
                                        (interval, open_time, signature, source.path, coverage_valid),
                                    )
                                else:
                                    first_signature, first_source, old_coverage_valid = existing
                                    if signature == first_signature:
                                        integrity[interval]["identical_duplicate_rows"] += 1
                                        fail("IDENTICAL_DUPLICATE")
                                        sample(interval, "IDENTICAL_DUPLICATE", source.path, line_number,
                                               open_time_ms=open_time, first_source=first_source)
                                    else:
                                        integrity[interval]["conflicting_revision_rows"] += 1
                                        fail("CONFLICTING_REVISION")
                                        sample(interval, "CONFLICTING_REVISION", source.path, line_number,
                                               open_time_ms=open_time, first_source=first_source)
                                    if first_source != source.path:
                                        integrity[interval]["cross_file_overlap_rows"] += 1
                                        fail("CROSS_FILE_OVERLAP")
                                        sample(interval, "CROSS_FILE_OVERLAP", source.path, line_number,
                                               open_time_ms=open_time, first_source=first_source)
                                    if coverage_valid and not old_coverage_valid:
                                        connection.execute(
                                            "UPDATE bars SET coverage_valid = 1 WHERE interval = ? AND open_time_ms = ?",
                                            (interval, open_time),
                                        )
                        except (csv.Error, UnicodeDecodeError, OSError) as exc:
                            integrity[interval]["malformed_rows"] += 1
                            fail("SOURCE_PARSE_ERROR")
                            sample(interval, "SOURCE_PARSE_ERROR", source.path, None, message=str(exc))
                        finally:
                            handle.close()
                            if archive is not None:
                                archive.close()
                        # Detect concurrent mutation between the initial hash and the scan.
                        try:
                            post_scan_hash = sha256_file(source_path)
                        except OSError as exc:
                            post_scan_hash = _ZERO_SHA256
                            fail("SOURCE_CHANGED_OR_UNREADABLE_DURING_AUDIT")
                            sample(interval, "SOURCE_CHANGED_OR_UNREADABLE_DURING_AUDIT", source.path, None,
                                   message=str(exc))
                        if post_scan_hash != source_hash:
                            fail("SOURCE_CHANGED_DURING_AUDIT")
                            sample(interval, "SOURCE_CHANGED_DURING_AUDIT", source.path, None,
                                   initial_sha256=source_hash, post_scan_sha256=post_scan_hash)

                if source.row_count_declared is not None and observed_rows != source.row_count_declared:
                    fail("DECLARED_ROW_COUNT_MISMATCH")
                    sample(interval, "DECLARED_ROW_COUNT_MISMATCH", source.path, None,
                           declared=source.row_count_declared, observed=observed_rows)
                source_reports.append({
                    "interval": interval,
                    "path": source.path,
                    "sha256": source_hash,
                    "row_count_declared": source.row_count_declared,
                    "row_count_observed": observed_rows,
                })

            connection.commit()
            timeframe_reports: list[dict[str, Any]] = []
            for interval in intervals:
                step = INTERVAL_MILLISECONDS[interval]
                expected = (end_open_time_ms_exclusive - start_open_time_ms) // step
                observed_unique = connection.execute(
                    "SELECT COUNT(*) FROM bars WHERE interval = ? AND coverage_valid = 1 "
                    "AND open_time_ms >= ? AND open_time_ms < ? AND open_time_ms % ? = 0",
                    (interval, start_open_time_ms, end_open_time_ms_exclusive, step),
                ).fetchone()[0]
                missing, leading, trailing, gap_clusters, cluster_count = _coverage_gap_clusters(
                    connection, interval, start_open_time_ms, end_open_time_ms_exclusive, step,
                    sample_cap=sample_cap,
                )
                ratio = (Decimal(observed_unique) / Decimal(expected)).quantize(
                    Decimal("0.000001"), rounding=ROUND_HALF_UP
                )
                counts = integrity[interval]
                timeframe_reports.append({
                    "interval": interval,
                    "step_ms": step,
                    "expected_bar_count": expected,
                    "observed_row_count": timeframe_rows[interval],
                    "observed_unique_bar_count": observed_unique,
                    "missing_bar_count": missing,
                    "leading_missing_bar_count": leading,
                    "trailing_missing_bar_count": trailing,
                    "coverage_ratio_decimal": format(ratio, ".6f"),
                    "gap_cluster_count": cluster_count,
                    "gap_clusters_truncated": cluster_count > len(gap_clusters),
                    "gap_clusters": gap_clusters,
                    "integrity_counts": counts,
                    "tick_grid_violations": tick_violations[interval],
                    "samples": issue_samples[interval],
                })
                if leading or trailing:
                    fail("BOUNDARY_COVERAGE_GAP", int(bool(leading)) + int(bool(trailing)))
                internal_gap_clusters = max(0, cluster_count - int(bool(leading)) - int(bool(trailing)))
                if internal_gap_clusters:
                    warn("INTERNAL_GAPS", internal_gap_clusters)

        finally:
            connection.close()

    for code, detail in metadata_issues:
        fail(code)
    metadata_quality = metadata_report["quality"]
    if metadata_quality == "MISSING_OR_CONFLICTED":
        fail("METADATA_MISSING_OR_CONFLICTED")
    elif metadata_quality == "CURRENT_SNAPSHOT_ONLY":
        warn("CURRENT_METADATA_SNAPSHOT")
    elif metadata_quality == "HISTORICAL_EFFECTIVE":
        effective_from = metadata_report["effective_from_ms"]
        effective_to = metadata_report["effective_to_ms"]
        if effective_from is None or effective_to is None or effective_from > start_open_time_ms or effective_to < end_open_time_ms_exclusive:
            fail("METADATA_EFFECTIVE_WINDOW_MISMATCH")
        if metadata_report["independent_evidence_ref"] is None:
            warn("METADATA_EVIDENCE_REFERENCE_MISSING")
    if tick_size is None or tick_size <= 0:
        fail("EXACT_TICK_SIZE_MISSING")

    failure_count = sum(failure_occurrences.values())
    warning_count = sum(warning_occurrences.values())
    quality_status = "FAIL" if failure_count else "WARN" if warning_count else "PASS"
    strict_eligible = (
        quality_status == "PASS"
        and metadata_quality == "HISTORICAL_EFFECTIVE"
        and metadata_report["independent_evidence_ref"] is not None
    )

    # Keep the historical combined summary above for backward-facing CLI semantics,
    # while exposing orthogonal eligibility gates for strategy research vs execution.
    execution_failure_codes = {
        "METADATA_MISSING", "METADATA_INVALID", "METADATA_SYMBOL_MISMATCH",
        "METADATA_CONTRACT_MISMATCH", "METADATA_MISSING_OR_CONFLICTED",
        "METADATA_EFFECTIVE_WINDOW_MISMATCH", "EXACT_TICK_SIZE_MISSING",
        "TICK_GRID_VIOLATION",
    }
    execution_warning_codes = {
        "CURRENT_METADATA_SNAPSHOT", "METADATA_EVIDENCE_REFERENCE_MISSING",
    }
    market_data_failure_codes = sorted(failure_conditions - execution_failure_codes)
    market_data_warning_codes = sorted(warning_conditions - execution_warning_codes)
    execution_metadata_failure_codes = sorted(failure_conditions & execution_failure_codes)
    execution_metadata_warning_codes = sorted(warning_conditions & execution_warning_codes)

    market_data_status = (
        "FAIL" if market_data_failure_codes
        else "WARN" if market_data_warning_codes
        else "PASS"
    )
    market_data_eligible = market_data_status == "PASS"

    metadata_contract_valid = not any(code in failure_conditions for code in (
        "METADATA_INVALID", "METADATA_SYMBOL_MISMATCH", "METADATA_CONTRACT_MISMATCH",
    ))
    provisional_metadata_usable = (
        tick_size is not None and tick_size > 0 and metadata_contract_valid
        and "TICK_GRID_VIOLATION" not in failure_conditions
        and metadata_quality != "MISSING_OR_CONFLICTED"
    )
    provisional_strategy_eligible = market_data_eligible and provisional_metadata_usable

    historical_metadata_covered = (
        metadata_quality == "HISTORICAL_EFFECTIVE"
        and metadata_report["effective_from_ms"] is not None
        and metadata_report["effective_to_ms"] is not None
        and metadata_report["effective_from_ms"] <= start_open_time_ms
        and metadata_report["effective_to_ms"] >= end_open_time_ms_exclusive
        and metadata_report["independent_evidence_ref"] is not None
        and not execution_metadata_failure_codes
    )
    execution_metadata_status = "PASS" if historical_metadata_covered else "BLOCKED"
    execution_metadata_blockers = list(execution_metadata_failure_codes)
    if metadata_quality != "HISTORICAL_EFFECTIVE":
        execution_metadata_blockers.append("HISTORICAL_METADATA_NOT_PROVEN")
    elif metadata_report["independent_evidence_ref"] is None:
        execution_metadata_blockers.append("INDEPENDENT_METADATA_EVIDENCE_MISSING")
    execution_metadata_blockers = sorted(set(execution_metadata_blockers))

    eligibility_gates = {
        "market_data": {
            "status": market_data_status,
            "eligible_for_strategy_replay": market_data_eligible,
            "failure_codes": market_data_failure_codes,
            "warning_codes": market_data_warning_codes,
        },
        "execution_metadata": {
            "status": execution_metadata_status,
            "strict_replay_eligible": historical_metadata_covered,
            "metadata_quality": metadata_quality,
            "candidate_tick_size": format(tick_size, "f") if tick_size is not None else None,
            "failure_codes": execution_metadata_failure_codes,
            "warning_codes": execution_metadata_warning_codes,
            "blocking_codes": execution_metadata_blockers,
        },
        "provisional_strategy_replay_eligible": provisional_strategy_eligible,
        "strict_replay_eligible": strict_eligible,
        "provisional_replay_policy": "STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION",
    }
    sources_identity = [
        {"interval": item["interval"], "path": item["path"], "sha256": item["sha256"],
         "row_count_observed": item["row_count_observed"]}
        for item in source_reports
    ]
    dataset_id = sha256_text(canonical_json({
        "symbol": normalized_symbol,
        "start_open_time_ms": start_open_time_ms,
        "end_open_time_ms_exclusive": end_open_time_ms_exclusive,
        "sources": sources_identity,
        "metadata_sha256": metadata_report["sha256"],
    }))
    report: dict[str, Any] = {
        "report_schema_version": _REPORT_SCHEMA_VERSION,
        "report_type": "REPLAY_DATASET_QUALITY",
        "dataset_id": dataset_id,
        "symbol": normalized_symbol,
        "dataset_window": {
            "start_open_time_ms": start_open_time_ms,
            "end_open_time_ms_exclusive": end_open_time_ms_exclusive,
        },
        "metadata": metadata_report,
        "source_files": source_reports,
        "timeframes": timeframe_reports,
        "eligibility_gates": eligibility_gates,
        "quality_summary": {
            "quality_status": quality_status,
            "strict_replay_eligible": strict_eligible,
            "issue_count": failure_count + warning_count,
            "warning_count": warning_count,
            "failure_count": failure_count,
            "sample_cap": sample_cap,
            "failure_codes": sorted(failure_conditions),
            "warning_codes": sorted(warning_conditions),
        },
    }
    report["report_sha256"] = sha256_text(canonical_json(report))
    return report


def audit_replay_manifest_quality(
    manifest: ReplayDatasetManifest,
    *,
    dataset_root: str | Path,
    independent_evidence_ref: str | None = None,
    sample_cap: int = _SAMPLE_CAP,
) -> dict[str, Any]:
    """Audit manifest sources while rechecking declared hashes and row counts."""
    sources = tuple(
        ReplayQualitySource(
            interval=item.interval,
            path=item.path,
            expected_sha256=item.sha256,
            row_count_declared=item.row_count,
            source_url=item.source_url,
        )
        for item in manifest.files
    )
    report = audit_replay_dataset_quality(
        dataset_root=dataset_root,
        symbol=manifest.symbol,
        start_open_time_ms=manifest.start_open_time_ms,
        end_open_time_ms_exclusive=manifest.end_open_time_ms,
        sources=sources,
        metadata=manifest.metadata,
        independent_evidence_ref=independent_evidence_ref,
        sample_cap=sample_cap,
    )
    # In manifest mode the report must retain the exact Stage 6A dataset identity.
    report["dataset_id"] = manifest.dataset_id
    report.pop("report_sha256", None)
    report["report_sha256"] = sha256_text(canonical_json(report))
    return report


def write_dataset_quality_report(report: Mapping[str, Any], path: str | Path) -> Path:
    """Atomically write a deterministic JSON report without modifying its sources."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_text(json.dumps(report, sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(target)
    return target
