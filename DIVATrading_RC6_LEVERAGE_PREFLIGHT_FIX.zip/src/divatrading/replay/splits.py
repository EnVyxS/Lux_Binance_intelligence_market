"""Deterministic chronological split planning for historical replay analysis."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from math import gcd
from typing import Iterable

from divatrading.market_data.klines import INTERVAL_MILLISECONDS


class ReplaySplitError(ValueError):
    """Raised when a dataset cannot be split without violating chronology/alignment."""


@dataclass(frozen=True, slots=True)
class ReplaySplit:
    label: str
    start_ms: int
    end_ms_exclusive: int
    target_fraction: Decimal
    realized_fraction: Decimal

    def contains(self, timestamp_ms: int) -> bool:
        return self.start_ms <= timestamp_ms < self.end_ms_exclusive

    def to_dict(self) -> dict[str, object]:
        return {
            "label": self.label,
            "start_ms": self.start_ms,
            "end_ms_exclusive": self.end_ms_exclusive,
            "target_fraction_decimal": _decimal_text(self.target_fraction),
            "realized_fraction_decimal": _decimal_text(self.realized_fraction),
            "test_status": "OPENED_AFTER_FREEZE" if self.label == "TEST" else "NOT_APPLICABLE",
        }


def _decimal_text(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def interval_alignment_quantum(intervals: Iterable[str]) -> int:
    normalized = tuple(dict.fromkeys(intervals))
    if not normalized:
        raise ReplaySplitError("at least one active interval is required")
    quantum = 1
    for interval in normalized:
        try:
            duration = INTERVAL_MILLISECONDS[interval]
        except KeyError as exc:
            raise ReplaySplitError(f"unsupported active interval: {interval!r}") from exc
        quantum = quantum * duration // gcd(quantum, duration)
    return quantum


def create_chronological_split_plan(
    start_ms: int,
    end_ms_exclusive: int,
    intervals: Iterable[str],
    *,
    target_ratios: tuple[Decimal, Decimal, Decimal] = (
        Decimal("0.60"), Decimal("0.20"), Decimal("0.20")
    ),
    terminal_boundary_ms: int | None = None,
) -> dict[str, object]:
    """Create a half-open, UTC-chronological 60/20/20 plan with aligned inner cuts."""
    for name, value in (("start_ms", start_ms), ("end_ms_exclusive", end_ms_exclusive)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ReplaySplitError(f"{name} must be a non-negative integer")
    if end_ms_exclusive <= start_ms:
        raise ReplaySplitError("end_ms_exclusive must be greater than start_ms")
    try:
        ratios = tuple(Decimal(item) for item in target_ratios)
    except Exception as exc:
        raise ReplaySplitError("split ratios must be finite Decimal values") from exc
    if len(ratios) != 3 or any(not item.is_finite() or item <= 0 for item in ratios):
        raise ReplaySplitError("exactly three positive finite split ratios are required")
    if sum(ratios) != Decimal("1"):
        raise ReplaySplitError("split ratios must sum exactly to 1")

    active = tuple(dict.fromkeys(intervals))
    quantum = interval_alignment_quantum(active)
    nominal_end = end_ms_exclusive if terminal_boundary_ms is None else terminal_boundary_ms
    if isinstance(nominal_end, bool) or not isinstance(nominal_end, int) or nominal_end <= start_ms or nominal_end > end_ms_exclusive:
        raise ReplaySplitError("terminal_boundary_ms must lie inside the requested final exclusive boundary")
    total = nominal_end - start_ms
    # At least one full alignment quantum per partition. A terminal +1ms close-clock
    # inclusion is assigned to the final partition but is not counted as elapsed time.
    if total < 3 * quantum:
        raise ReplaySplitError(
            f"dataset window is too short: each of 3 partitions requires at least {quantum} ms"
        )

    def aligned_cut(fraction: Decimal) -> int:
        raw = Decimal(start_ms) + Decimal(total) * fraction
        steps = ((raw / Decimal(quantum)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        return int(steps) * quantum

    first = aligned_cut(ratios[0])
    second = aligned_cut(ratios[0] + ratios[1])
    first = min(max(first, start_ms + quantum), nominal_end - 2 * quantum)
    second = min(max(second, first + quantum), nominal_end - quantum)
    boundaries = (start_ms, first, second, nominal_end)
    if any(boundaries[i + 1] - boundaries[i] < quantum for i in range(3)):
        raise ReplaySplitError("aligned split would create an empty or too-short partition")

    labels = ("TRAIN", "VALIDATION", "TEST")
    split_ratios = (ratios[0], ratios[1], ratios[2])
    splits: list[ReplaySplit] = []
    for index, label in enumerate(labels):
        left, right = boundaries[index], boundaries[index + 1]
        exclusive_right = end_ms_exclusive if index == 2 else right
        realized = Decimal(right - left) / Decimal(total)
        splits.append(ReplaySplit(label, left, exclusive_right, split_ratios[index], realized))

    return {
        "method": "CHRONOLOGICAL_60_20_20_ALIGNED_LCM",
        "alignment_quantum_ms": quantum,
        "target_ratios": [format(item.quantize(Decimal("0.00")), "f") for item in ratios],
        "splits": [item.to_dict() for item in splits],
    }


def label_split(timestamp_ms: int, splits: Iterable[dict[str, object]]) -> str | None:
    """Label a known-at timestamp using exact half-open boundary semantics."""
    if isinstance(timestamp_ms, bool) or not isinstance(timestamp_ms, int):
        raise ReplaySplitError("timestamp_ms must be an integer")
    for split in splits:
        if int(split["start_ms"]) <= timestamp_ms < int(split["end_ms_exclusive"]):
            return str(split["label"])
    return None
