"""Versioned and content-addressed historical replay dataset manifests."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import re
from typing import Any, Mapping

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline


class ReplayManifestError(ValueError):
    """Raised when a replay manifest or its referenced source files are invalid."""


_METADATA_QUALITIES = {"HISTORICAL_EFFECTIVE", "CURRENT_SNAPSHOT_ONLY", "MISSING_OR_CONFLICTED"}
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(value: str) -> str:
    return sha256(value.encode("utf-8")).hexdigest()


def sha256_file(path: Path, *, chunk_bytes: int = 1024 * 1024) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_bytes):
            digest.update(chunk)
    return digest.hexdigest()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class ReplayKlineFile:
    interval: str
    path: str
    sha256: str
    row_count: int
    first_open_time_ms: int
    last_open_time_ms: int
    source_url: str = ""

    def __post_init__(self) -> None:
        if self.interval not in INTERVAL_MILLISECONDS:
            raise ReplayManifestError("Kline file interval must be 1m, 5m or 15m")
        if not isinstance(self.path, str) or not self.path.strip():
            raise ReplayManifestError("Kline file path is required")
        relative = Path(self.path)
        if relative.is_absolute() or ".." in relative.parts:
            raise ReplayManifestError("Kline file path must be relative and cannot escape dataset root")
        if not _SHA256_RE.fullmatch(self.sha256):
            raise ReplayManifestError("Kline file sha256 must be 64 lowercase hexadecimal characters")
        if isinstance(self.row_count, bool) or not isinstance(self.row_count, int) or self.row_count <= 0:
            raise ReplayManifestError("Kline file row_count must be positive")
        for name in ("first_open_time_ms", "last_open_time_ms"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ReplayManifestError(f"{name} must be a non-negative integer")
        if self.first_open_time_ms > self.last_open_time_ms:
            raise ReplayManifestError("Kline file first open time exceeds last open time")
        if self.first_open_time_ms % INTERVAL_MILLISECONDS[self.interval] or self.last_open_time_ms % INTERVAL_MILLISECONDS[self.interval]:
            raise ReplayManifestError("Kline file open times are not aligned to its interval")
        if not isinstance(self.source_url, str):
            raise ReplayManifestError("source_url must be a string")

    @classmethod
    def inspect(
        cls,
        root: str | Path,
        relative_path: str,
        interval: str,
        *,
        symbol: str,
        source_url: str = "",
    ) -> "ReplayKlineFile":
        """Inspect an archive/CSV and return its exact hash and observed row range."""
        from .klines import iter_binance_kline_rows

        base = Path(root).resolve()
        path = (base / relative_path).resolve()
        if base not in path.parents:
            raise ReplayManifestError("Kline file path resolves outside dataset root")
        count = 0
        first: int | None = None
        last: int | None = None
        previous: int | None = None
        for candle in iter_binance_kline_rows(path, symbol=symbol, interval=interval, source_endpoint=source_url or f"archive:{relative_path}"):
            if previous is not None and candle.open_time_ms <= previous:
                raise ReplayManifestError("Kline file is not strictly chronological")
            previous = candle.open_time_ms
            if first is None:
                first = candle.open_time_ms
            last = candle.open_time_ms
            count += 1
        if count == 0 or first is None or last is None:
            raise ReplayManifestError("Kline file contains no data rows")
        return cls(interval, relative_path, sha256_file(path), count, first, last, source_url)


@dataclass(frozen=True, slots=True)
class ReplayMetadataSnapshot:
    quality: str
    source_url: str
    captured_at_ms: int
    raw_symbol_info_json: str
    effective_from_ms: int | None = None
    effective_to_ms: int | None = None
    sha256: str = ""

    def __post_init__(self) -> None:
        if self.quality not in _METADATA_QUALITIES:
            raise ReplayManifestError(f"metadata quality must be one of {sorted(_METADATA_QUALITIES)}")
        if not isinstance(self.source_url, str) or not self.source_url.strip():
            raise ReplayManifestError("metadata source_url is required")
        for name in ("captured_at_ms", "effective_from_ms", "effective_to_ms"):
            value = getattr(self, name)
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
                raise ReplayManifestError(f"metadata {name} must be a non-negative integer or None")
        if self.effective_from_ms is not None and self.effective_to_ms is not None and self.effective_from_ms >= self.effective_to_ms:
            raise ReplayManifestError("metadata effective interval must be non-empty")
        try:
            raw = json.loads(self.raw_symbol_info_json)
        except (TypeError, json.JSONDecodeError) as exc:
            raise ReplayManifestError("raw_symbol_info_json must contain valid JSON") from exc
        if not isinstance(raw, dict):
            raise ReplayManifestError("raw_symbol_info_json must encode one Binance symbol object")
        canonical = canonical_json(raw)
        if canonical != self.raw_symbol_info_json:
            object.__setattr__(self, "raw_symbol_info_json", canonical)
        expected = sha256_text(canonical)
        if self.sha256 and self.sha256 != expected:
            raise ReplayManifestError("metadata SHA-256 does not match canonical symbol metadata")
        object.__setattr__(self, "sha256", expected)

    @classmethod
    def from_symbol_payload(
        cls,
        payload: Mapping[str, Any],
        *,
        quality: str,
        source_url: str,
        captured_at_ms: int,
        effective_from_ms: int | None = None,
        effective_to_ms: int | None = None,
    ) -> "ReplayMetadataSnapshot":
        raw_json = canonical_json(_jsonable(payload))
        return cls(quality, source_url, captured_at_ms, raw_json, effective_from_ms, effective_to_ms)

    def symbol_info(self, expected_symbol: str) -> SymbolInfo:
        try:
            info = SymbolInfo.from_payload(json.loads(self.raw_symbol_info_json))
        except Exception as exc:
            raise ReplayManifestError(f"invalid Binance symbol metadata: {exc}") from exc
        if info.symbol != expected_symbol.upper():
            raise ReplayManifestError("metadata symbol does not match dataset symbol")
        if not info.is_tradable_usdt_perpetual:
            raise ReplayManifestError("dataset metadata must identify an active USDT-margined USD-M perpetual")
        if info.price_filter is None or info.price_filter.tick_size is None or info.price_filter.tick_size <= 0:
            raise ReplayManifestError("exact PRICE_FILTER.tickSize is required; precision is not a substitute")
        return info

    def to_dict(self) -> dict[str, Any]:
        return {
            "quality": self.quality,
            "source_url": self.source_url,
            "captured_at_ms": self.captured_at_ms,
            "effective_from_ms": self.effective_from_ms,
            "effective_to_ms": self.effective_to_ms,
            "raw_symbol_info": json.loads(self.raw_symbol_info_json),
            "sha256": self.sha256,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "ReplayMetadataSnapshot":
        raw = payload.get("raw_symbol_info")
        if not isinstance(raw, Mapping):
            raise ReplayManifestError("manifest metadata.raw_symbol_info must be an object")
        return cls(
            quality=str(payload.get("quality", "")),
            source_url=str(payload.get("source_url", "")),
            captured_at_ms=payload.get("captured_at_ms"),
            raw_symbol_info_json=canonical_json(raw),
            effective_from_ms=payload.get("effective_from_ms"),
            effective_to_ms=payload.get("effective_to_ms"),
            sha256=str(payload.get("sha256", "")),
        )


@dataclass(frozen=True, slots=True)
class ReplayDatasetManifest:
    symbol: str
    start_open_time_ms: int
    end_open_time_ms: int
    files: tuple[ReplayKlineFile, ...]
    metadata: ReplayMetadataSnapshot
    schema_version: int = 1
    exchange: str = "BINANCE_UM"
    market_type: str = "USD_M_FUTURES"
    contract_type: str = "PERPETUAL"
    quote_asset: str = "USDT"
    margin_asset: str = "USDT"
    dataset_id: str = ""

    def __post_init__(self) -> None:
        symbol = self.symbol.strip().upper() if isinstance(self.symbol, str) else ""
        if not re.fullmatch(r"[A-Z0-9]{3,30}", symbol):
            raise ReplayManifestError("manifest symbol must be an exact exchange symbol")
        object.__setattr__(self, "symbol", symbol)
        if self.schema_version != 1:
            raise ReplayManifestError("unsupported replay manifest schema_version")
        if (self.exchange, self.market_type, self.contract_type, self.quote_asset, self.margin_asset) != (
            "BINANCE_UM", "USD_M_FUTURES", "PERPETUAL", "USDT", "USDT"
        ):
            raise ReplayManifestError("manifest must describe a Binance USD-M USDT perpetual contract")
        for name in ("start_open_time_ms", "end_open_time_ms"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ReplayManifestError(f"{name} must be a non-negative integer")
        if self.start_open_time_ms >= self.end_open_time_ms:
            raise ReplayManifestError("manifest time window must be non-empty and end-exclusive")
        try:
            files = tuple(self.files)
        except TypeError as exc:
            raise ReplayManifestError("manifest files must be iterable") from exc
        if not files or any(not isinstance(item, ReplayKlineFile) for item in files):
            raise ReplayManifestError("manifest requires ReplayKlineFile entries")
        available_intervals = {item.interval for item in files}
        if not {"1m", "5m"}.issubset(available_intervals):
            raise ReplayManifestError("Stage 1-5 replay requires native 1m and 5m Kline datasets")
        object.__setattr__(self, "files", tuple(sorted(files, key=lambda item: (item.interval, item.first_open_time_ms, item.path))))
        if not isinstance(self.metadata, ReplayMetadataSnapshot):
            raise ReplayManifestError("manifest metadata must be ReplayMetadataSnapshot")
        self.metadata.symbol_info(symbol)
        intervals = sorted({item.interval for item in files})
        for interval in intervals:
            step = INTERVAL_MILLISECONDS[interval]
            if self.start_open_time_ms % step or self.end_open_time_ms % step:
                raise ReplayManifestError(
                    f"dataset window boundaries must align to the native {interval} interval"
                )
        for interval in intervals:
            same = [item for item in files if item.interval == interval]
            step = INTERVAL_MILLISECONDS[interval]
            if min(item.first_open_time_ms for item in same) != self.start_open_time_ms:
                raise ReplayManifestError(
                    f"{interval} files must cover the dataset window start; leading gaps are not implicit"
                )
            if max(item.last_open_time_ms for item in same) + step != self.end_open_time_ms:
                raise ReplayManifestError(
                    f"{interval} files must end with the final fully closed candle at the dataset boundary"
                )
            for previous, current in zip(same, same[1:]):
                if current.first_open_time_ms <= previous.last_open_time_ms:
                    raise ReplayManifestError(f"overlapping {interval} source files are not allowed")
                if current.first_open_time_ms != previous.last_open_time_ms + step:
                    # Internal gaps are explicitly allowed and surfaced by the replay clock.
                    continue
        identity = self._identity_dict()
        computed = sha256_text(canonical_json(identity))
        if self.dataset_id and self.dataset_id != computed:
            raise ReplayManifestError("dataset_id does not match canonical manifest content")
        object.__setattr__(self, "dataset_id", computed)

    def _identity_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "exchange": self.exchange,
            "market_type": self.market_type,
            "contract_type": self.contract_type,
            "symbol": self.symbol,
            "quote_asset": self.quote_asset,
            "margin_asset": self.margin_asset,
            "start_open_time_ms": self.start_open_time_ms,
            "end_open_time_ms": self.end_open_time_ms,
            "files": [
                {
                    "interval": item.interval,
                    "path": item.path,
                    "sha256": item.sha256,
                    "row_count": item.row_count,
                    "first_open_time_ms": item.first_open_time_ms,
                    "last_open_time_ms": item.last_open_time_ms,
                    "source_url": item.source_url,
                }
                for item in self.files
            ],
            "metadata": self.metadata.to_dict(),
        }

    @property
    def intervals(self) -> tuple[str, ...]:
        return tuple(interval for interval in ("1m", "5m", "15m") if any(item.interval == interval for item in self.files))

    def validate(self, root: str | Path, *, strict_metadata: bool = True, verify_hashes: bool = True) -> SymbolInfo:
        """Validate files, coverage, contract identity and effective metadata quality."""
        from .klines import iter_binance_kline_rows

        base = Path(root).resolve()
        if strict_metadata:
            if self.metadata.quality != "HISTORICAL_EFFECTIVE":
                raise ReplayManifestError("strict replay requires HISTORICAL_EFFECTIVE tick-size metadata")
            if self.metadata.effective_from_ms is None or self.metadata.effective_to_ms is None:
                raise ReplayManifestError("historical metadata must declare an effective interval")
            if self.metadata.effective_from_ms > self.start_open_time_ms or self.metadata.effective_to_ms < self.end_open_time_ms:
                raise ReplayManifestError("historical tick-size metadata does not cover the full dataset window")
        elif self.metadata.quality == "MISSING_OR_CONFLICTED":
            raise ReplayManifestError("diagnostic replay still requires an exact, non-conflicted tick size")

        info = self.metadata.symbol_info(self.symbol)
        for item in self.files:
            path = (base / item.path).resolve()
            if base not in path.parents or not path.is_file():
                raise ReplayManifestError(f"manifest source file is missing or escapes dataset root: {item.path}")
            if verify_hashes and sha256_file(path) != item.sha256:
                raise ReplayManifestError(f"source file SHA-256 mismatch: {item.path}")
            observed = 0
            first: int | None = None
            last: int | None = None
            previous: int | None = None
            for candle in iter_binance_kline_rows(
                path, symbol=self.symbol, interval=item.interval,
                source_endpoint=item.source_url or f"archive:{item.path}",
            ):
                if previous is not None and candle.open_time_ms <= previous:
                    raise ReplayManifestError(f"source file is not strictly chronological: {item.path}")
                previous = candle.open_time_ms
                first = candle.open_time_ms if first is None else first
                last = candle.open_time_ms
                observed += 1
            if observed != item.row_count or first != item.first_open_time_ms or last != item.last_open_time_ms:
                raise ReplayManifestError(f"source file row count/range mismatch: {item.path}")
            if item.first_open_time_ms < self.start_open_time_ms or item.last_open_time_ms >= self.end_open_time_ms:
                raise ReplayManifestError(f"source file row range is outside manifest window: {item.path}")
        return info

    def to_dict(self) -> dict[str, Any]:
        return {**self._identity_dict(), "dataset_id": self.dataset_id}

    def write(self, path: str | Path) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return target

    @classmethod
    def load(cls, path: str | Path) -> "ReplayDatasetManifest":
        source = Path(path)
        try:
            payload = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ReplayManifestError(f"cannot read replay manifest: {exc}") from exc
        if not isinstance(payload, dict):
            raise ReplayManifestError("manifest root must be an object")
        files_raw = payload.get("files")
        if not isinstance(files_raw, list):
            raise ReplayManifestError("manifest files must be an array")
        metadata_raw = payload.get("metadata")
        if not isinstance(metadata_raw, Mapping):
            raise ReplayManifestError("manifest metadata must be an object")
        files = tuple(ReplayKlineFile(**item) for item in files_raw if isinstance(item, dict))
        if len(files) != len(files_raw):
            raise ReplayManifestError("manifest files must contain only objects")
        return cls(
            symbol=payload.get("symbol", ""),
            start_open_time_ms=payload.get("start_open_time_ms"),
            end_open_time_ms=payload.get("end_open_time_ms"),
            files=files,
            metadata=ReplayMetadataSnapshot.from_dict(metadata_raw),
            schema_version=payload.get("schema_version", 1),
            exchange=payload.get("exchange", "BINANCE_UM"),
            market_type=payload.get("market_type", "USD_M_FUTURES"),
            contract_type=payload.get("contract_type", "PERPETUAL"),
            quote_asset=payload.get("quote_asset", "USDT"),
            margin_asset=payload.get("margin_asset", "USDT"),
            dataset_id=payload.get("dataset_id", ""),
        )
