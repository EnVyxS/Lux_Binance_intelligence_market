"""Chronological deterministic replay driver for the SMC V2 evidence engines.

This module intentionally stops at evidence generation. It does not model orders,
executions, fills, risk, PnL, scoring or setup qualification.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, field, replace
from hashlib import sha256
import json
import os
from pathlib import Path
from typing import Any, Iterator

from divatrading import __version__
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataAdapter,
    ScalpingMarketDataConfig,
)
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureEngine,
)
from divatrading.strategy.scalping_order_block_formation import (
    ScalpingOrderBlockFormationConfig,
    ScalpingOrderBlockFormationEngine,
)
from divatrading.strategy.scalping_order_block_lifecycle import (
    ScalpingOrderBlockLifecycleConfig,
    ScalpingOrderBlockLifecycleEngine,
)
from divatrading.strategy.scalping_liquidity_fvg import (
    ScalpingLiquidityFVGConfig,
    ScalpingLiquidityFVGEngine,
)

from .klines import iter_manifest_klines
from .manifest import ReplayDatasetManifest, ReplayManifestError, canonical_json, sha256_file, sha256_text


class ReplayRunnerError(RuntimeError):
    """Raised when replay cannot proceed without compromising deterministic evidence."""


def _jsonable(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return _jsonable(value.to_dict())
    if hasattr(value, "__dataclass_fields__"):
        return _jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, deque)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "as_tuple") and value.__class__.__name__ == "Decimal":
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _hash_code_tree() -> str:
    package_root = Path(__file__).resolve().parents[1]
    files = sorted(
        path for path in package_root.rglob("*.py")
        if "__pycache__" not in path.parts
    )
    digest = sha256()
    for path in files:
        relative = path.relative_to(package_root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


@dataclass(frozen=True, slots=True)
class ReplayConfig:
    """Bounded replay and engine configuration; values are hashed into replay identity."""

    max_history_candles: int = 1000
    include_m15: bool = True
    strict_metadata: bool = True
    checkpoint_every_captures: int = 1000
    evidence_start_time_ms: int | None = None
    market_data_config: ScalpingMarketDataConfig = field(default_factory=ScalpingMarketDataConfig)
    structure_config: ScalpingMarketStructureConfig = field(default_factory=ScalpingMarketStructureConfig)
    formation_config: ScalpingOrderBlockFormationConfig = field(default_factory=ScalpingOrderBlockFormationConfig)
    lifecycle_config: ScalpingOrderBlockLifecycleConfig = field(default_factory=ScalpingOrderBlockLifecycleConfig)
    liquidity_config: ScalpingLiquidityFVGConfig = field(default_factory=ScalpingLiquidityFVGConfig)

    def __post_init__(self) -> None:
        if isinstance(self.max_history_candles, bool) or not isinstance(self.max_history_candles, int) or not 2 <= self.max_history_candles <= 2000:
            raise ValueError("max_history_candles must be between 2 and 2000")
        if not isinstance(self.include_m15, bool) or not isinstance(self.strict_metadata, bool):
            raise ValueError("include_m15 and strict_metadata must be boolean")
        if isinstance(self.checkpoint_every_captures, bool) or not isinstance(self.checkpoint_every_captures, int) or self.checkpoint_every_captures < 1:
            raise ValueError("checkpoint_every_captures must be a positive integer")
        if self.evidence_start_time_ms is not None and (isinstance(self.evidence_start_time_ms, bool) or not isinstance(self.evidence_start_time_ms, int) or self.evidence_start_time_ms < 0):
            raise ValueError("evidence_start_time_ms must be a non-negative UTC epoch millisecond or None")
        for name in ("market_data_config", "structure_config", "formation_config", "lifecycle_config", "liquidity_config"):
            expected = {
                "market_data_config": ScalpingMarketDataConfig,
                "structure_config": ScalpingMarketStructureConfig,
                "formation_config": ScalpingOrderBlockFormationConfig,
                "lifecycle_config": ScalpingOrderBlockLifecycleConfig,
                "liquidity_config": ScalpingLiquidityFVGConfig,
            }[name]
            if not isinstance(getattr(self, name), expected):
                raise ValueError(f"{name} must be {expected.__name__}")
        object.__setattr__(
            self,
            "market_data_config",
            replace(self.market_data_config, max_candles_per_interval=self.max_history_candles),
        )
        if self.structure_config.enable_m15_context != self.include_m15:
            object.__setattr__(
                self, "structure_config",
                replace(self.structure_config, enable_m15_context=self.include_m15),
            )


@dataclass(frozen=True, slots=True)
class ReplayRunSummary:
    replay_run_id: str
    dataset_id: str
    config_sha256: str
    code_sha256: str
    capture_count: int
    gap_count: int
    emitted_record_count: int
    last_capture_time_ms: int | None
    right_censored_ob_count: int
    right_censored_fvg_count: int
    ledger_sha256: str | None = None
    ledger_path: str | None = None
    suppressed_pre_roll_record_count: int = 0
    suppressed_pre_roll_records_sha256: str | None = None


class _BoundedIds:
    def __init__(self, maximum: int) -> None:
        self.maximum = maximum
        self.items: deque[str] = deque()
        self.values: set[str] = set()

    def add(self, value: str) -> bool:
        if value in self.values:
            return False
        self.items.append(value)
        self.values.add(value)
        while len(self.items) > self.maximum:
            self.values.discard(self.items.popleft())
        return True


class HistoricalReplayRunner:
    """Stream a manifest's native Klines through Stage 1–5 in UTC close-time order."""

    def __init__(
        self,
        manifest: ReplayDatasetManifest,
        *,
        dataset_root: str | Path,
        config: ReplayConfig | None = None,
    ) -> None:
        if not isinstance(manifest, ReplayDatasetManifest):
            raise TypeError("manifest must be ReplayDatasetManifest")
        self.manifest = manifest
        self.dataset_root = Path(dataset_root).resolve()
        self.config = config or ReplayConfig()
        self.instrument = manifest.validate(self.dataset_root, strict_metadata=self.config.strict_metadata)
        self._effective_structure_config = self.config.structure_config
        self.config_sha256 = sha256_text(canonical_json(_jsonable(self.config)))
        self.code_sha256 = _hash_code_tree()
        self.replay_run_id = sha256_text(canonical_json({
            "dataset_id": manifest.dataset_id,
            "config_sha256": self.config_sha256,
            "code_sha256": self.code_sha256,
            "software_version": __version__,
            "clock_policy": "UTC_KLINE_CLOSE_PLUS_1MS_V1",
        }))
        self._reset_runtime()

    def _reset_runtime(self) -> None:
        self.adapter = ScalpingMarketDataAdapter(
            config=replace(self.config.market_data_config, max_candles_per_interval=self.config.max_history_candles)
        )
        self.structure_engine = ScalpingMarketStructureEngine(config=self._effective_structure_config)
        self.formation_engine = ScalpingOrderBlockFormationEngine(config=self.config.formation_config)
        self.lifecycle_engine = ScalpingOrderBlockLifecycleEngine(config=self.config.lifecycle_config)
        self.liquidity_engine = ScalpingLiquidityFVGEngine(config=self.config.liquidity_config)
        self._history: dict[str, deque[Kline]] = {
            interval: deque(maxlen=self.config.max_history_candles)
            for interval in ("1m", "5m", "15m")
        }
        self._last_open: dict[str, int] = {}
        self._last_emitted_bar: dict[str, int] = {}
        self._formation_trace_ids = _BoundedIds(self.config.formation_config.max_traces_per_timeframe * 2)
        self._candidate_ids = _BoundedIds(self.config.formation_config.max_candidates_per_timeframe * 2)
        self._lifecycle_trace_ids = _BoundedIds(self.config.lifecycle_config.max_traces_per_timeframe * 2)
        self._ob_snapshot_hashes: dict[str, str] = {}
        self._liquidity_trace_ids = _BoundedIds(self.config.liquidity_config.max_traces_per_timeframe * 2)
        self._reference_ids = _BoundedIds(self.config.liquidity_config.max_references_per_timeframe * 2)
        self._sweep_ids = _BoundedIds(self.config.liquidity_config.max_sweeps_per_timeframe * 2)
        self._fvg_hashes: dict[str, str] = {}
        self._last_lifecycle = None
        self._last_liquidity = None
        self._capture_sequence = 0
        self._gap_count = 0
        self._suppressed_pre_roll_record_count = 0
        self._suppressed_pre_roll_digest = sha256()

    def _reset_timeframe(self, timeframe: str) -> None:
        self.structure_engine.reset(symbol=self.manifest.symbol, timeframe=timeframe)
        self.formation_engine.reset(symbol=self.manifest.symbol, timeframe=timeframe)
        self.lifecycle_engine.reset(symbol=self.manifest.symbol, timeframe=timeframe)
        self.liquidity_engine.reset(symbol=self.manifest.symbol, timeframe=timeframe)
        self._history[timeframe].clear()
        self._last_emitted_bar.pop(timeframe, None)

    def _series(self, captured_at_ms: int) -> tuple[KlineSeriesInput, ...]:
        result: list[KlineSeriesInput] = []
        for interval in ("1m", "5m", "15m"):
            if interval == "15m" and not self.config.include_m15:
                continue
            rows = tuple(self._history[interval])
            if not rows:
                continue
            # Closed-only replay: the newest included close must precede this clock.
            if any(candle.close_time_ms >= captured_at_ms for candle in rows):
                raise ReplayRunnerError("forming or future candle reached a replay capture")
            result.append(KlineSeriesInput(
                symbol=self.manifest.symbol,
                interval=interval,
                candles=rows,
                source_observed_at_ms=captured_at_ms,
                source_healthy=True,
                source_complete=True,
            ))
        return tuple(result)

    def _capture_id(self, sequence: int, captured_at_ms: int) -> str:
        included = []
        for interval in ("1m", "5m", "15m"):
            if interval == "15m" and not self.config.include_m15:
                continue
            candle = self._history[interval][-1] if self._history[interval] else None
            included.append({
                "interval": interval,
                "open_time_ms": None if candle is None else candle.open_time_ms,
                "close_time_ms": None if candle is None else candle.close_time_ms,
            })
        return sha256_text(canonical_json({
            "replay_run_id": self.replay_run_id,
            "sequence": sequence,
            "symbol": self.manifest.symbol,
            "captured_at_ms": captured_at_ms,
            "latest_closed": included,
            "metadata_sha256": self.manifest.metadata.sha256,
        }))

    def _envelope(
        self,
        payload: dict[str, Any],
        *,
        capture_id: str,
        sequence: int,
        captured_at_ms: int,
        stage: str,
        timeframe: str | None = None,
    ) -> dict[str, Any]:
        record_type = payload.get("record_type", "REPLAY_EVIDENCE")
        return {
            "record_schema_version": 1,
            "record_type": record_type,
            "replay_run_id": self.replay_run_id,
            "replay_capture_id": capture_id,
            "capture_sequence": sequence,
            "dataset_id": self.manifest.dataset_id,
            "symbol": self.manifest.symbol,
            "timeframe": timeframe or payload.get("timeframe"),
            "stage": stage,
            "known_at_time_ms": captured_at_ms,
            "metadata_sha256": self.manifest.metadata.sha256,
            "payload": payload,
        }

    def _new_records(
        self,
        *,
        capture_id: str,
        sequence: int,
        captured_at_ms: int,
        structure: Any,
        formation: Any,
        lifecycle: Any,
        liquidity: Any,
        gap_events: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for gap in gap_events:
            records.append(self._envelope(
                {"record_type": "REPLAY_DATA_GAP", **gap}, capture_id=capture_id,
                sequence=sequence, captured_at_ms=captured_at_ms, stage="REPLAY_CONTROL",
                timeframe=gap["timeframe"],
            ))

        for timeframe_result in structure.timeframes:
            tf = timeframe_result.timeframe
            last_open = self._last_emitted_bar.get(tf, -1)
            for trace in timeframe_result.bar_traces:
                if trace.bar_open_time_ms <= last_open:
                    continue
                payload = trace.to_dict()
                records.append(self._envelope(
                    payload, capture_id=capture_id, sequence=sequence,
                    captured_at_ms=captured_at_ms, stage="STAGE_2_MARKET_STRUCTURE", timeframe=tf,
                ))
                last_open = trace.bar_open_time_ms
            if last_open >= 0:
                self._last_emitted_bar[tf] = last_open

        for timeframe_result in formation.timeframes:
            tf = timeframe_result.timeframe
            for trace in timeframe_result.traces:
                if self._formation_trace_ids.add(trace.event_id):
                    records.append(self._envelope(
                        trace.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_3_OB_FORMATION", timeframe=tf,
                    ))
            for candidate in timeframe_result.candidates:
                if self._candidate_ids.add(candidate.candidate_id):
                    records.append(self._envelope(
                        candidate.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_3_OB_FORMATION", timeframe=tf,
                    ))

        for timeframe_result in lifecycle.timeframes:
            tf = timeframe_result.timeframe
            for trace in timeframe_result.traces:
                key = f"{trace.candidate_id}|{trace.transition}|{trace.observed_time_ms}|{trace.to_status}"
                if self._lifecycle_trace_ids.add(key):
                    records.append(self._envelope(
                        trace.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_4_OB_LIFECYCLE", timeframe=tf,
                    ))
            current_ids: set[str] = set()
            for snapshot in timeframe_result.order_blocks:
                candidate_id = snapshot.candidate.candidate_id
                current_ids.add(candidate_id)
                payload = snapshot.to_dict()
                fingerprint = sha256_text(canonical_json(payload))
                if self._ob_snapshot_hashes.get(candidate_id) != fingerprint:
                    self._ob_snapshot_hashes[candidate_id] = fingerprint
                    records.append(self._envelope(
                        payload, capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_4_OB_LIFECYCLE", timeframe=tf,
                    ))
            for candidate_id in tuple(self._ob_snapshot_hashes):
                if candidate_id not in current_ids:
                    del self._ob_snapshot_hashes[candidate_id]

        for timeframe_result in liquidity.timeframes:
            tf = timeframe_result.timeframe
            for trace in timeframe_result.traces:
                if self._liquidity_trace_ids.add(trace.event_id):
                    records.append(self._envelope(
                        trace.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_5_LIQUIDITY_FVG", timeframe=tf,
                    ))
            for reference in timeframe_result.references:
                if self._reference_ids.add(reference.reference_id):
                    records.append(self._envelope(
                        reference.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_5_LIQUIDITY_FVG", timeframe=tf,
                    ))
            for sweep in timeframe_result.sweeps:
                if self._sweep_ids.add(sweep.evidence_id):
                    records.append(self._envelope(
                        sweep.to_dict(), capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_5_LIQUIDITY_FVG", timeframe=tf,
                    ))
            current_fvg_ids: set[str] = set()
            for fvg in timeframe_result.fvgs:
                current_fvg_ids.add(fvg.fvg_id)
                payload = fvg.to_dict()
                fingerprint = sha256_text(canonical_json(payload))
                if self._fvg_hashes.get(fvg.fvg_id) != fingerprint:
                    self._fvg_hashes[fvg.fvg_id] = fingerprint
                    records.append(self._envelope(
                        payload, capture_id=capture_id, sequence=sequence,
                        captured_at_ms=captured_at_ms, stage="STAGE_5_LIQUIDITY_FVG", timeframe=tf,
                    ))
            for fvg_id in tuple(self._fvg_hashes):
                if fvg_id not in current_fvg_ids:
                    del self._fvg_hashes[fvg_id]

        readiness = {
            "setup_timeframe_ready": structure.m1_setup_ready or structure.m5_setup_ready,
            "timeframes": [
                {
                    "timeframe": item.timeframe,
                    "status": item.status,
                    "reason_codes": list(item.reason_codes),
                    "bars_processed": item.bars_processed,
                    "warmup_remaining_bars": item.warmup_remaining_bars,
                }
                for item in structure.timeframes
            ],
        }
        records.append(self._envelope({
            "record_type": "REPLAY_CAPTURE_SUMMARY",
            "replay_capture_id": capture_id,
            "capture_sequence": sequence,
            "captured_at_ms": captured_at_ms,
            "updated_intervals": [
                interval for interval in ("1m", "5m", "15m")
                if self._history[interval] and self._history[interval][-1].close_time_ms + 1 == captured_at_ms
            ],
            "latest_closed_klines": [
                {
                    "interval": interval,
                    "open_time_ms": self._history[interval][-1].open_time_ms,
                    "close_time_ms": self._history[interval][-1].close_time_ms,
                }
                for interval in ("1m", "5m", "15m")
                if self._history[interval] and (interval != "15m" or self.config.include_m15)
            ],
            "source_file_hashes": [
                {"interval": item.interval, "path": item.path, "sha256": item.sha256}
                for item in self.manifest.files
            ],
            "readiness": readiness,
            "ob_candidate_count": len(formation.candidates),
            "ob_lifecycle_count": len(lifecycle.order_blocks),
            "liquidity_reference_count": sum(len(item.references) for item in liquidity.timeframes),
            "liquidity_sweep_count": sum(len(item.sweeps) for item in liquidity.timeframes),
            "fvg_count": sum(len(item.fvgs) for item in liquidity.timeframes),
        }, capture_id=capture_id, sequence=sequence, captured_at_ms=captured_at_ms, stage="REPLAY_CONTROL"))
        return records

    def _iter_capture_batches(self) -> Iterator[tuple[int, int, list[dict[str, Any]]]]:
        intervals = [item for item in ("1m", "5m", "15m") if item in self.manifest.intervals and (item != "15m" or self.config.include_m15)]
        iterators = {
            interval: iter_manifest_klines(
                self.dataset_root, self.manifest.files, symbol=self.manifest.symbol, interval=interval
            )
            for interval in intervals
        }
        next_rows: dict[str, Kline] = {}
        for interval, iterator in iterators.items():
            row = next(iterator, None)
            if row is not None:
                next_rows[interval] = row
        sequence = 0
        while next_rows:
            next_close = min(item.close_time_ms for item in next_rows.values())
            captured_at_ms = next_close + 1
            gap_events: list[dict[str, Any]] = []
            updated: list[str] = []
            for interval in intervals:
                row = next_rows.get(interval)
                if row is None or row.close_time_ms != next_close:
                    continue
                previous_open = self._last_open.get(interval)
                step = INTERVAL_MILLISECONDS[interval]
                if previous_open is not None and row.open_time_ms != previous_open + step:
                    if row.open_time_ms <= previous_open:
                        raise ReplayRunnerError(f"duplicate/revised {interval} Kline open time {row.open_time_ms}")
                    missing_count = (row.open_time_ms - previous_open) // step - 1
                    self._gap_count += 1
                    gap_events.append({
                        "timeframe": interval,
                        "last_valid_open_time_ms": previous_open,
                        "first_resumed_open_time_ms": row.open_time_ms,
                        "missing_bar_count": missing_count,
                        "first_missing_open_time_ms": previous_open + step,
                        "reset_policy": "RESET_ONLY_AFFECTED_SYMBOL_TIMEFRAME_AND_REWARMUP",
                    })
                    self._reset_timeframe(interval)
                self._history[interval].append(row)
                self._last_open[interval] = row.open_time_ms
                updated.append(interval)
                next_row = next(iterators[interval], None)
                if next_row is None:
                    next_rows.pop(interval, None)
                else:
                    next_rows[interval] = next_row

            # A single capture envelope at the UTC close boundary; all intervals
            # closing together are visible before the adapter/engines run.
            view = self.adapter.build_view(
                symbol=self.manifest.symbol,
                now_ms=captured_at_ms,
                symbol_info=self.instrument,
                kline_series=self._series(captured_at_ms),
            )
            structure = self.structure_engine.process(view)
            formation = self.formation_engine.process(structure, view)
            lifecycle = self.lifecycle_engine.process(formation, view)
            liquidity = self.liquidity_engine.process(structure, view)
            self._last_lifecycle = lifecycle
            self._last_liquidity = liquidity
            sequence += 1
            capture_id = self._capture_id(sequence, captured_at_ms)
            records = self._new_records(
                capture_id=capture_id,
                sequence=sequence,
                captured_at_ms=captured_at_ms,
                structure=structure,
                formation=formation,
                lifecycle=lifecycle,
                liquidity=liquidity,
                gap_events=gap_events,
            )
            yield sequence, captured_at_ms, records

    def _header_record(self) -> dict[str, Any]:
        return {
            "record_schema_version": 1,
            "record_type": "REPLAY_RUN_HEADER",
            "replay_run_id": self.replay_run_id,
            "dataset_id": self.manifest.dataset_id,
            "symbol": self.manifest.symbol,
            "software_version": __version__,
            "config_sha256": self.config_sha256,
            "code_sha256": self.code_sha256,
            "metadata_sha256": self.manifest.metadata.sha256,
            "metadata_quality": self.manifest.metadata.quality,
            "dataset_window": {
                "start_open_time_ms": self.manifest.start_open_time_ms,
                "end_open_time_ms_exclusive": self.manifest.end_open_time_ms,
            },
            "strict_metadata": self.config.strict_metadata,
            "evidence_mode": "COMPACT_PRE_ROLL" if self.config.evidence_start_time_ms is not None else "FULL_LEDGER",
            "evidence_start_time_ms": self.config.evidence_start_time_ms,
            "max_history_candles": self.config.max_history_candles,
            "clock_policy": "UTC_KLINE_CLOSE_PLUS_1MS_V1",
            "closed_bar_rule": "close_time_ms < captured_at_ms",
            "stages": ["STAGE_1_ADAPTER", "STAGE_2_STRUCTURE", "STAGE_3_OB_FORMATION", "STAGE_4_OB_LIFECYCLE", "STAGE_5_LIQUIDITY_FVG"],
            "config": _jsonable(self.config),
            "source_files": [
                {"interval": item.interval, "path": item.path, "sha256": item.sha256, "row_count": item.row_count}
                for item in self.manifest.files
            ],
        }

    def _final_summary_record(self, capture_count: int, gap_count: int, last_capture: int | None) -> dict[str, Any]:
        ob_censored = 0
        if self._last_lifecycle is not None:
            ob_censored = sum(1 for item in self._last_lifecycle.order_blocks if not item.is_terminal)
        fvg_censored = 0
        if self._last_liquidity is not None:
            fvg_censored = sum(1 for timeframe in self._last_liquidity.timeframes for item in timeframe.fvgs if not item.is_terminal)
        return {
            "record_schema_version": 1,
            "record_type": "REPLAY_RUN_SUMMARY",
            "replay_run_id": self.replay_run_id,
            "dataset_id": self.manifest.dataset_id,
            "capture_count": capture_count,
            "gap_count": gap_count,
            "last_capture_time_ms": last_capture,
            "right_censored_ob_count": ob_censored,
            "right_censored_fvg_count": fvg_censored,
            "suppressed_pre_roll_record_count": self._suppressed_pre_roll_record_count,
            "suppressed_pre_roll_records_sha256": self._suppressed_pre_roll_digest.hexdigest(),
            "evidence_start_time_ms": self.config.evidence_start_time_ms,
            "interpretation": "EVIDENCE_ONLY_NO_FILL_PNL_OR_PROFITABILITY_INFERENCE",
        }

    def _checkpoint_payload(
        self, *, last_capture: int | None, capture_count: int, byte_offset: int,
        ledger_prefix_sha256: str, completed: bool,
    ) -> dict[str, Any]:
        return {
            "checkpoint_schema_version": 1,
            "replay_run_id": self.replay_run_id,
            "dataset_id": self.manifest.dataset_id,
            "config_sha256": self.config_sha256,
            "code_sha256": self.code_sha256,
            "last_capture_time_ms": last_capture,
            "capture_count": capture_count,
            "ledger_byte_offset": byte_offset,
            "ledger_prefix_sha256": ledger_prefix_sha256,
            "completed": completed,
            "restart_policy": "REPLAY_FROM_DATASET_START_TO_REBUILD_ENGINE_STATE",
        }

    @staticmethod
    def _write_checkpoint(path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")

        serialized = json.dumps(payload, indent=2, sort_keys=True) + "\n"

        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())

        os.replace(temporary, path)

    def run_to_file(
        self,
        ledger_path: str | Path,
        *,
        checkpoint_path: str | Path | None = None,
        resume_from_checkpoint: bool = False,
        stop_after_captures: int | None = None,
    ) -> ReplayRunSummary:
        """Write a deterministic JSONL ledger; resume reconstructs state by replaying the prefix."""
        ledger = Path(ledger_path)
        ledger.parent.mkdir(parents=True, exist_ok=True)
        if stop_after_captures is not None and (
            isinstance(stop_after_captures, bool) or not isinstance(stop_after_captures, int) or stop_after_captures < 1
        ):
            raise ValueError("stop_after_captures must be a positive integer or None")
        if stop_after_captures is not None and checkpoint_path is None:
            raise ValueError("stop_after_captures requires checkpoint_path so the partial run can be resumed")
        checkpoint = None if checkpoint_path is None else Path(checkpoint_path)
        if resume_from_checkpoint and (checkpoint is None or not checkpoint.is_file() or not ledger.is_file()):
            raise ReplayRunnerError("resume requires an existing ledger and checkpoint")
        if checkpoint is not None and not resume_from_checkpoint and checkpoint.exists():
            checkpoint.unlink()

        resume_after: int | None = None
        expected_resume_count: int | None = None
        byte_offset = 0
        ledger_digest = sha256()
        if resume_from_checkpoint:
            try:
                saved = json.loads(checkpoint.read_text(encoding="utf-8"))  # type: ignore[union-attr]
            except (OSError, json.JSONDecodeError) as exc:
                raise ReplayRunnerError(f"cannot read replay checkpoint: {exc}") from exc
            for field_name, expected in (
                ("replay_run_id", self.replay_run_id),
                ("dataset_id", self.manifest.dataset_id),
                ("config_sha256", self.config_sha256),
                ("code_sha256", self.code_sha256),
            ):
                if saved.get(field_name) != expected:
                    raise ReplayRunnerError(f"checkpoint {field_name} mismatch; refusing unsafe resume")
            if saved.get("completed"):
                raise ReplayRunnerError("checkpoint already marks this replay complete")
            resume_after = saved.get("last_capture_time_ms")
            expected_resume_count = saved.get("capture_count")
            if isinstance(resume_after, bool) or not isinstance(resume_after, int) or resume_after < 0:
                raise ReplayRunnerError("checkpoint last_capture_time_ms is invalid")
            if isinstance(expected_resume_count, bool) or not isinstance(expected_resume_count, int) or expected_resume_count < 1:
                raise ReplayRunnerError("checkpoint capture_count is invalid")
            byte_offset = saved.get("ledger_byte_offset", -1)
            expected_ledger_hash = saved.get("ledger_prefix_sha256")
            if isinstance(byte_offset, bool) or not isinstance(byte_offset, int) or byte_offset < 1:
                raise ReplayRunnerError("checkpoint ledger offset is invalid")
            if not isinstance(expected_ledger_hash, str) or len(expected_ledger_hash) != 64 or any(ch not in "0123456789abcdef" for ch in expected_ledger_hash):
                raise ReplayRunnerError("checkpoint ledger prefix SHA-256 is invalid")
            with ledger.open("r+b") as handle:
                handle.seek(0)
                header_line = handle.readline()
                try:
                    header = json.loads(header_line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise ReplayRunnerError("ledger header is invalid; refusing unsafe resume") from exc
                if header.get("record_type") != "REPLAY_RUN_HEADER" or header.get("replay_run_id") != self.replay_run_id:
                    raise ReplayRunnerError("ledger header does not match checkpoint replay identity")
                if handle.seek(0, os.SEEK_END) < byte_offset:
                    raise ReplayRunnerError("ledger is shorter than the checkpoint offset")
                handle.seek(byte_offset - 1)
                if handle.read(1) != b"\n":
                    raise ReplayRunnerError("checkpoint offset is not at a complete JSONL record boundary")
                handle.truncate(byte_offset)
                handle.flush()
                os.fsync(handle.fileno())
                handle.seek(0)
                remaining = byte_offset
                while remaining:
                    chunk = handle.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ReplayRunnerError("ledger ended before the checkpoint offset")
                    ledger_digest.update(chunk)
                    remaining -= len(chunk)
                if ledger_digest.hexdigest() != expected_ledger_hash:
                    raise ReplayRunnerError("ledger prefix SHA-256 does not match checkpoint")
            handle = ledger.open("ab")
        else:
            handle = ledger.open("wb")

        self._reset_runtime()
        capture_count = 0
        emitted_records = 0
        last_capture: int | None = None
        resume_reached = resume_after is None
        stopped_early = False
        try:
            if not resume_from_checkpoint:
                ledger_digest.update(self._write_line(handle, self._header_record()))
                emitted_records += 1
            for sequence, captured_at_ms, records in self._iter_capture_batches():
                capture_count = sequence
                last_capture = captured_at_ms
                # Compact mode still computes every pre-roll transition. Only its
                # verbose evidence rows are omitted; a canonical digest and count
                # preserve an auditable commitment to those deterministic records.
                for record in records:
                    if self.config.evidence_start_time_ms is not None and captured_at_ms < self.config.evidence_start_time_ms:
                        suppressed_line = (canonical_json(record) + "\n").encode("utf-8")
                        self._suppressed_pre_roll_digest.update(suppressed_line)
                        self._suppressed_pre_roll_record_count += 1
                if not resume_reached and captured_at_ms == resume_after:
                    if sequence != expected_resume_count:
                        raise ReplayRunnerError("checkpoint timestamp and capture_count do not identify the same capture")
                    resume_reached = True
                    continue
                if not resume_reached and resume_after is not None and captured_at_ms > resume_after:
                    raise ReplayRunnerError("checkpoint capture timestamp is not aligned to the replay event clock")
                should_write = resume_reached
                if should_write and not (self.config.evidence_start_time_ms is not None and captured_at_ms < self.config.evidence_start_time_ms):
                    for record in records:
                        ledger_digest.update(self._write_line(handle, record))
                        emitted_records += 1
                is_new_after_resume = resume_after is None or captured_at_ms > resume_after
                if checkpoint is not None and is_new_after_resume and sequence % self.config.checkpoint_every_captures == 0:
                    handle.flush()
                    os.fsync(handle.fileno())
                    offset = handle.tell()
                    self._write_checkpoint(checkpoint, self._checkpoint_payload(
                        last_capture=captured_at_ms, capture_count=sequence,
                        byte_offset=offset, ledger_prefix_sha256=ledger_digest.hexdigest(), completed=False,
                    ))
                if stop_after_captures is not None and sequence >= stop_after_captures:
                    stopped_early = True
                    break
            if resume_after is not None and not resume_reached:
                raise ReplayRunnerError("checkpoint capture timestamp is not present in the current dataset")
            handle.flush()
            os.fsync(handle.fileno())
            final_offset = handle.tell()
            if stopped_early:
                if checkpoint is not None:
                    self._write_checkpoint(checkpoint, self._checkpoint_payload(
                        last_capture=last_capture, capture_count=capture_count,
                        byte_offset=final_offset, ledger_prefix_sha256=ledger_digest.hexdigest(), completed=False,
                    ))
            else:
                summary_record = self._final_summary_record(capture_count, self._gap_count, last_capture)
                ledger_digest.update(self._write_line(handle, summary_record))
                emitted_records += 1
                handle.flush()
                os.fsync(handle.fileno())
                final_offset = handle.tell()
                if checkpoint is not None:
                    self._write_checkpoint(checkpoint, self._checkpoint_payload(
                        last_capture=last_capture, capture_count=capture_count,
                        byte_offset=final_offset, ledger_prefix_sha256=ledger_digest.hexdigest(), completed=True,
                    ))
        finally:
            handle.close()

        if stopped_early:
            ob_censored = 0 if self._last_lifecycle is None else sum(1 for item in self._last_lifecycle.order_blocks if not item.is_terminal)
            fvg_censored = 0 if self._last_liquidity is None else sum(1 for timeframe in self._last_liquidity.timeframes for item in timeframe.fvgs if not item.is_terminal)
        else:
            ob_censored = summary_record["right_censored_ob_count"]
            fvg_censored = summary_record["right_censored_fvg_count"]
        return ReplayRunSummary(
            replay_run_id=self.replay_run_id,
            dataset_id=self.manifest.dataset_id,
            config_sha256=self.config_sha256,
            code_sha256=self.code_sha256,
            capture_count=capture_count,
            gap_count=self._gap_count,
            emitted_record_count=emitted_records,
            last_capture_time_ms=last_capture,
            right_censored_ob_count=ob_censored,
            right_censored_fvg_count=fvg_censored,
            ledger_sha256=sha256_file(ledger),
            ledger_path=str(ledger.resolve()),
            suppressed_pre_roll_record_count=self._suppressed_pre_roll_record_count,
            suppressed_pre_roll_records_sha256=self._suppressed_pre_roll_digest.hexdigest(),
        )

    @staticmethod
    def _write_line(handle: Any, record: dict[str, Any]) -> bytes:
        line = (canonical_json(record) + "\n").encode("utf-8")
        try:
            handle.write(line.decode("utf-8"))
        except TypeError:
            handle.write(line)
        return line

    def run_to_jsonl(self) -> tuple[str, ReplayRunSummary]:
        """Convenience method for tests/small fixtures; large runs should use run_to_file."""
        import io

        self._reset_runtime()
        handle = io.StringIO()
        self._write_line(handle, self._header_record())
        capture_count = 0
        record_count = 1
        last_capture: int | None = None
        for sequence, captured_at_ms, records in self._iter_capture_batches():
            capture_count = sequence
            last_capture = captured_at_ms
            if self.config.evidence_start_time_ms is not None and captured_at_ms < self.config.evidence_start_time_ms:
                for record in records:
                    self._suppressed_pre_roll_digest.update((canonical_json(record) + "\n").encode("utf-8"))
                    self._suppressed_pre_roll_record_count += 1
            else:
                for record in records:
                    self._write_line(handle, record)
                    record_count += 1
        summary_record = self._final_summary_record(capture_count, self._gap_count, last_capture)
        self._write_line(handle, summary_record)
        record_count += 1
        ledger_text = handle.getvalue()
        ob_censored = summary_record["right_censored_ob_count"]
        fvg_censored = summary_record["right_censored_fvg_count"]
        summary = ReplayRunSummary(
            replay_run_id=self.replay_run_id,
            dataset_id=self.manifest.dataset_id,
            config_sha256=self.config_sha256,
            code_sha256=self.code_sha256,
            capture_count=capture_count,
            gap_count=self._gap_count,
            emitted_record_count=record_count,
            last_capture_time_ms=last_capture,
            right_censored_ob_count=ob_censored,
            right_censored_fvg_count=fvg_censored,
            ledger_sha256=sha256_text(ledger_text),
            suppressed_pre_roll_record_count=self._suppressed_pre_roll_record_count,
            suppressed_pre_roll_records_sha256=self._suppressed_pre_roll_digest.hexdigest(),
        )
        return ledger_text, summary
