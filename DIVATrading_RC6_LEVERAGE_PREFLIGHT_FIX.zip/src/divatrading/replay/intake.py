"""Evidence-preserving Binance USD-M REST Kline acquisition and metadata capture.

Raw REST response pages are retained byte-for-byte. A derived native 12-column
CSV is emitted for replay tooling; gaps are recorded and never repaired.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import UTC, datetime
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import tempfile
import time
import uuid
from typing import Any, Callable, Mapping

import httpx

from divatrading.exchange.binance.client import BinanceRawKlinePage, BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from .manifest import ReplayMetadataSnapshot, sha256_file

_EXCHANGE_INFO_URL = "https://fapi.binance.com/fapi/v1/exchangeInfo"
_SERVER_TIME_URL = "https://fapi.binance.com/fapi/v1/time"
_KLINES_URL = "https://fapi.binance.com/fapi/v1/klines"
_SYMBOL_RE = re.compile(r"^[A-Z0-9]{3,30}$")
_CAPTURE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
_RETRYABLE_STATUS = {408, 425, 429, 500, 502, 503, 504}
_DEFAULT_TIMEOUT = 30.0
_DEFAULT_ATTEMPTS = 3


class BinanceIntakeError(RuntimeError):
    """Raised when official Binance public data cannot be safely retained."""


@dataclass(frozen=True, slots=True)
class BinanceRestKlineIntake:
    symbol: str
    interval: str
    capture_id: str
    raw_capture_dir: Path
    pages_index_path: Path
    csv_path: Path
    provenance_path: Path
    requested_start_open_time_ms: int
    requested_end_open_time_ms_exclusive: int
    first_open_time_ms: int | None
    last_open_time_ms: int | None
    row_count: int
    page_count: int
    complete: bool
    gap_count: int
    gap_sample_open_times_ms: tuple[int, ...]
    source_sha256: str
    derived_csv_sha256: str
    server_time_ms: int


@dataclass(frozen=True, slots=True)
class BinanceMetadataCapture:
    raw_exchange_info_path: Path
    replay_snapshot_path: Path
    provenance_path: Path
    symbol: str
    tick_size: str
    captured_at_ms: int
    server_time_ms: int
    raw_exchange_info_sha256: str
    snapshot_sha256: str
    quality: str = "CURRENT_SNAPSHOT_ONLY"


def _validate_symbol(symbol: str) -> str:
    value = symbol.strip().upper() if isinstance(symbol, str) else ""
    if not _SYMBOL_RE.fullmatch(value):
        raise BinanceIntakeError("symbol must be a Binance symbol, e.g. BTCUSDT")
    return value


def _atomic_write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    encoded = (json.dumps(payload, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    _atomic_write(path, encoded)


def _append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
    with path.open("ab") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())


def _request_with_retries(
    client: httpx.Client,
    method: str,
    url: str,
    *,
    attempts: int,
    timeout: float,
) -> httpx.Response:
    last_error: Exception | None = None
    for attempt in range(attempts):
        try:
            response = client.request(method, url, timeout=timeout)
            if response.status_code in _RETRYABLE_STATUS and attempt + 1 < attempts:
                retry_after = response.headers.get("Retry-After")
                try:
                    delay = min(max(float(retry_after), 0.0), 10.0) if retry_after else min(2**attempt, 4)
                except ValueError:
                    delay = min(2**attempt, 4)
                time.sleep(delay)
                continue
            if response.status_code >= 400:
                raise BinanceIntakeError(f"Binance returned HTTP {response.status_code} for {url}")
            return response
        except httpx.TransportError as exc:
            last_error = exc
            if attempt + 1 >= attempts:
                break
            time.sleep(min(2**attempt, 4))
    if last_error is not None:
        raise BinanceIntakeError(f"network error fetching {url}: {last_error}") from last_error
    raise BinanceIntakeError(f"request failed after {attempts} attempts: {url}")


def _capture_id(value: str | None) -> str:
    if value is None:
        return datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ") + "-" + uuid.uuid4().hex[:8]
    if not _CAPTURE_RE.fullmatch(value):
        raise BinanceIntakeError("capture_id must be 1-80 safe ASCII letters, digits, dot, underscore or hyphen")
    return value


def collect_binance_um_klines_rest(
    *,
    symbol: str,
    interval: str,
    start_open_time_ms: int,
    end_open_time_ms_exclusive: int,
    dataset_root: str | Path,
    capture_id: str | None = None,
    page_limit: int = 1500,
    max_pages: int = 1000,
    request_interval_seconds: float = 1.0,
    client: BinanceUsdMFuturesRestClient | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> BinanceRestKlineIntake:
    """Retain raw REST pages and stream a derived CSV over a closed UTC window.

    ``end_open_time_ms_exclusive`` is exclusive and must not exceed Binance's
    current interval floor. API pagination is complete independently of whether
    the resulting market-data series is gap-free.
    """
    normalized_symbol = _validate_symbol(symbol)
    if interval not in INTERVAL_MILLISECONDS:
        raise BinanceIntakeError("interval must be one of: 1m, 5m, 15m")
    interval_ms = INTERVAL_MILLISECONDS[interval]
    for name, value in (("start_open_time_ms", start_open_time_ms), ("end_open_time_ms_exclusive", end_open_time_ms_exclusive)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0 or value % interval_ms:
            raise BinanceIntakeError(f"{name} must be a non-negative interval-aligned UTC millisecond timestamp")
    if end_open_time_ms_exclusive <= start_open_time_ms:
        raise BinanceIntakeError("end_open_time_ms_exclusive must be greater than start_open_time_ms")
    if isinstance(page_limit, bool) or not isinstance(page_limit, int) or not 1 <= page_limit <= 1500:
        raise BinanceIntakeError("page_limit must be between 1 and 1500")
    if isinstance(max_pages, bool) or not isinstance(max_pages, int) or not 1 <= max_pages <= 10000:
        raise BinanceIntakeError("max_pages must be between 1 and 10000")
    if isinstance(request_interval_seconds, bool) or not isinstance(request_interval_seconds, (int, float)) or not 0 <= request_interval_seconds <= 60:
        raise BinanceIntakeError("request_interval_seconds must be between 0 and 60")

    capture = _capture_id(capture_id)
    root = Path(dataset_root).resolve()
    capture_dir = root / "raw" / "rest_klines" / normalized_symbol / interval / capture
    derived_dir = root / "derived" / "rest_klines"
    pages_dir = capture_dir / "pages"
    pages_index = capture_dir / "pages.jsonl"
    provenance_path = capture_dir / "capture.provenance.json"
    csv_path = derived_dir / f"{normalized_symbol}-{interval}-{capture}.csv"
    partial_csv_path = derived_dir / f"{normalized_symbol}-{interval}-{capture}.partial.csv"
    csv_temp = derived_dir / (f".{normalized_symbol}-{interval}-{capture}.csv.part")
    if capture_dir.exists() and any(capture_dir.iterdir()):
        raise BinanceIntakeError(f"capture directory already contains data; refusing overwrite: {capture_dir}")
    if csv_path.exists() or partial_csv_path.exists() or csv_temp.exists():
        raise BinanceIntakeError("derived CSV target or unfinished temporary capture already exists; refusing overwrite")
    owns_client = client is None
    active_client = client or BinanceUsdMFuturesRestClient()
    try:
        server_time_ms = active_client.get_server_time_ms()
        latest_closed_boundary_ms = (server_time_ms // interval_ms) * interval_ms
        if end_open_time_ms_exclusive > latest_closed_boundary_ms:
            raise BinanceIntakeError(
                "requested window extends into the current, not-yet-closed Kline interval; "
                f"latest_closed_boundary_ms={latest_closed_boundary_ms}"
            )
        pages_dir.mkdir(parents=True, exist_ok=True)
        derived_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        if owns_client:
            active_client.close()
        raise

    row_count = page_count = gap_count = 0
    gap_samples: list[int] = []
    first_open: int | None = None
    last_open: int | None = None
    expected_next = start_open_time_ms
    cursor = start_open_time_ms
    previous_request_at: float | None = None
    all_source_hashes: list[str] = []
    complete = False
    failure: Exception | None = None
    capture_started_at_utc = datetime.now(UTC).isoformat()

    try:
        with csv_temp.open("w", encoding="utf-8", newline="") as csv_handle:
            writer = csv.writer(csv_handle, lineterminator="\n")
            while cursor < end_open_time_ms_exclusive and page_count < max_pages:
                if previous_request_at is not None and request_interval_seconds:
                    elapsed = time.monotonic() - previous_request_at
                    remaining = request_interval_seconds - elapsed
                    if remaining > 0:
                        sleep(remaining)
                previous_request_at = time.monotonic()
                page = active_client.get_klines_page_with_evidence(
                    symbol=normalized_symbol,
                    interval=interval,
                    start_time_ms=cursor,
                    end_time_ms=end_open_time_ms_exclusive - 1,
                    limit=page_limit,
                )
                if not page.raw_body:
                    raise BinanceIntakeError("Binance returned an empty HTTP body for a Kline page")
                if len(page.rows) > page_limit:
                    raise BinanceIntakeError("Binance returned more rows than the requested page limit")
                page_received_at_utc = datetime.now(UTC).isoformat()
                page_number = page_count + 1
                page_name = f"page_{page_number:06d}.json"
                page_path = pages_dir / page_name
                _atomic_write(page_path, page.raw_body)
                page_hash = sha256(page.raw_body).hexdigest()
                all_source_hashes.append(page_hash)
                if not page.rows:
                    _append_jsonl(pages_index, {
                        "page": page_number, "raw_file": f"pages/{page_name}",
                        "raw_sha256": page_hash, "row_count": 0,
                        "endpoint": page.endpoint, "request_params": dict(page.request_params),
                        "response_headers": dict(page.response_headers),
                        "validation_status": "EMPTY_PAGE",
                    })
                    raise BinanceIntakeError("Binance returned an empty page before requested end; capture is incomplete")

                parsed_rows: list[Kline] = []
                for raw_row in page.rows:
                    try:
                        candle = Kline.from_binance_row(
                            raw_row, symbol=normalized_symbol, interval=interval,
                            source_endpoint=page.endpoint,
                        )
                    except Exception as exc:
                        _append_jsonl(pages_index, {
                            "page": page_number, "raw_file": f"pages/{page_name}",
                            "raw_sha256": page_hash, "row_count": len(page.rows),
                            "endpoint": page.endpoint, "request_params": dict(page.request_params),
                            "response_headers": dict(page.response_headers),
                            "validation_status": "INVALID_ROW",
                        })
                        raise BinanceIntakeError(f"invalid Kline page {page_number}: {exc}") from exc
                    if not start_open_time_ms <= candle.open_time_ms < end_open_time_ms_exclusive:
                        raise BinanceIntakeError("Binance returned a Kline outside the requested half-open window")
                    if candle.open_time_ms < cursor:
                        raise BinanceIntakeError("Binance returned a Kline before the requested page cursor")
                    if last_open is not None and candle.open_time_ms <= last_open:
                        raise BinanceIntakeError("Binance returned duplicate or decreasing Kline open times")
                    if candle.open_time_ms > expected_next:
                        missing = (candle.open_time_ms - expected_next) // interval_ms
                        gap_count += missing
                        sample_until = min(missing, 100 - len(gap_samples))
                        gap_samples.extend(expected_next + i * interval_ms for i in range(sample_until))
                    expected_next = candle.open_time_ms + interval_ms
                    parsed_rows.append(candle)
                    writer.writerow([str(value) for value in raw_row])
                    row_count += 1
                    if first_open is None:
                        first_open = candle.open_time_ms
                    last_open = candle.open_time_ms

                page_count += 1
                _append_jsonl(pages_index, {
                    "page": page_number, "raw_file": f"pages/{page_name}",
                    "raw_sha256": page_hash, "row_count": len(parsed_rows),
                    "first_open_time_ms": parsed_rows[0].open_time_ms,
                    "last_open_time_ms": parsed_rows[-1].open_time_ms,
                    "endpoint": page.endpoint, "request_params": dict(page.request_params),
                    "response_headers": dict(page.response_headers),
                    "received_at_utc": page_received_at_utc,
                    "validation_status": "VALIDATED",
                })
                cursor = parsed_rows[-1].open_time_ms + interval_ms
                if len(page.rows) < page_limit:
                    complete = True
                    break
            else:
                complete = cursor >= end_open_time_ms_exclusive
            if cursor >= end_open_time_ms_exclusive:
                complete = True
            if complete and expected_next < end_open_time_ms_exclusive:
                missing = (end_open_time_ms_exclusive - expected_next) // interval_ms
                gap_count += missing
                sample_until = min(missing, 100 - len(gap_samples))
                gap_samples.extend(expected_next + i * interval_ms for i in range(sample_until))
            csv_handle.flush()
            os.fsync(csv_handle.fileno())
        target_csv = csv_path if complete else partial_csv_path
        os.replace(csv_temp, target_csv)
    except Exception as exc:
        failure = exc
        if csv_temp.exists():
            failed_path = partial_csv_path
            if not failed_path.exists():
                os.replace(csv_temp, failed_path)
    finally:
        if owns_client:
            active_client.close()

    if failure is not None:
        provenance = {
            "schema_version": 1, "capture_id": capture, "symbol": normalized_symbol,
            "interval": interval, "source": "BINANCE_USDM_REST_KLINES",
            "source_endpoint": _KLINES_URL, "status": "FAILED_PARTIAL_RETAINED",
            "requested_start_open_time_ms": start_open_time_ms,
            "requested_end_open_time_ms_exclusive": end_open_time_ms_exclusive,
            "server_time_ms": server_time_ms, "capture_started_at_utc": capture_started_at_utc,
            "capture_failed_at_utc": datetime.now(UTC).isoformat(),
            "pages_retained": page_count + (1 if len(all_source_hashes) > page_count else 0),
            "raw_page_sha256": all_source_hashes, "error": f"{type(failure).__name__}: {failure}",
            "source_bytes_modified": False,
        }
        _atomic_json(provenance_path, provenance)
        raise BinanceIntakeError(f"REST Kline capture failed; partial raw pages retained at {capture_dir}: {failure}") from failure

    source_sha = sha256("".join(all_source_hashes).encode("ascii")).hexdigest()
    target_csv = csv_path if complete else partial_csv_path
    derived_sha = sha256_file(target_csv)
    provenance = {
        "schema_version": 1, "capture_id": capture, "source": "BINANCE_USDM_REST_KLINES",
        "market_type": "USD_M_FUTURES", "symbol": normalized_symbol, "interval": interval,
        "source_endpoint": _KLINES_URL, "request_window": {
            "start_open_time_ms_inclusive": start_open_time_ms,
            "end_open_time_ms_exclusive": end_open_time_ms_exclusive,
        },
        "server_time_ms_before_capture": server_time_ms,
        "capture_started_at_utc": capture_started_at_utc,
        "capture_completed_at_utc": datetime.now(UTC).isoformat(),
        "capture_status": "COMPLETE" if complete else "PARTIAL_PAGE_CAP",
        "api_window_fully_paginated": complete,
        "row_count": row_count, "page_count": page_count,
        "first_open_time_ms": first_open, "last_open_time_ms": last_open,
        "gap_count": gap_count, "gap_sample_open_times_ms": gap_samples,
        "gap_assessment_complete": complete,
        "raw_pages_index": "pages.jsonl", "raw_pages_index_sha256": sha256_file(pages_index),
        "raw_page_sha256": all_source_hashes, "raw_pages_sha256_aggregate": source_sha,
        "derived_csv_path": str(target_csv.relative_to(root)),
        "derived_csv_sha256": derived_sha,
        "source_bytes_modified": False,
        "gap_policy": "REPORT_ONLY_NO_INTERPOLATION_OR_SYNTHESIS",
        "metadata_quality": "NOT_INCLUDED_CURRENT_OR_HISTORICAL_TICK_SIZE_NOT_INFERRED",
        "strict_historical_calibration_eligible": False,
        "notes": "API pagination completion does not imply a gap-free Kline dataset; run replay-quality before manifest creation.",
    }
    _atomic_json(provenance_path, provenance)
    return BinanceRestKlineIntake(
        normalized_symbol, interval, capture, capture_dir, pages_index, target_csv,
        provenance_path, start_open_time_ms, end_open_time_ms_exclusive,
        first_open, last_open, row_count, page_count, complete, gap_count,
        tuple(gap_samples), source_sha, derived_sha, server_time_ms,
    )


def capture_current_binance_um_metadata(
    *,
    symbol: str,
    output_dir: str | Path,
    timeout: float = _DEFAULT_TIMEOUT,
    attempts: int = _DEFAULT_ATTEMPTS,
    client: httpx.Client | None = None,
) -> BinanceMetadataCapture:
    """Retain raw current exchangeInfo and an explicitly non-historical snapshot."""
    normalized_symbol = _validate_symbol(symbol)
    if timeout <= 0 or attempts < 1:
        raise BinanceIntakeError("timeout and attempts must be positive")
    owns_client = client is None
    active_client = client or httpx.Client(follow_redirects=True)
    try:
        exchange_response = _request_with_retries(
            active_client, "GET", _EXCHANGE_INFO_URL, attempts=attempts, timeout=timeout
        )
        raw_bytes = exchange_response.content
        if not raw_bytes or len(raw_bytes) > 64 * 1024 * 1024:
            raise BinanceIntakeError("Binance exchangeInfo response is empty or exceeds 64 MiB")
        captured_at_ms = int(datetime.now(UTC).timestamp() * 1000)
        try:
            payload = json.loads(raw_bytes)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BinanceIntakeError("Binance exchangeInfo returned invalid JSON") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("symbols"), list):
            raise BinanceIntakeError("Binance exchangeInfo response has an invalid root structure")
        matches = [item for item in payload["symbols"] if isinstance(item, dict) and item.get("symbol") == normalized_symbol]
        if len(matches) != 1:
            raise BinanceIntakeError(f"exchangeInfo did not return exactly one {normalized_symbol} symbol record")
        symbol_payload = matches[0]
        try:
            info = SymbolInfo.from_payload(symbol_payload)
        except Exception as exc:
            raise BinanceIntakeError(f"exchangeInfo symbol record is invalid: {exc}") from exc
        if not info.is_tradable_usdt_perpetual:
            raise BinanceIntakeError("symbol is not an active Binance USD-M USDT perpetual")
        if info.price_filter is None or info.price_filter.tick_size is None or info.price_filter.tick_size <= 0:
            raise BinanceIntakeError("exact positive PRICE_FILTER.tickSize is absent")

        time_response = _request_with_retries(
            active_client, "GET", _SERVER_TIME_URL, attempts=attempts, timeout=timeout
        )
        try:
            server_time_payload = time_response.json()
            server_time_ms = int(server_time_payload["serverTime"])
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            raise BinanceIntakeError("Binance server-time response is invalid") from exc
        if server_time_ms <= 0:
            raise BinanceIntakeError("Binance serverTime must be positive")
        metadata = ReplayMetadataSnapshot.from_symbol_payload(
            symbol_payload,
            quality="CURRENT_SNAPSHOT_ONLY",
            source_url=_EXCHANGE_INFO_URL,
            captured_at_ms=captured_at_ms,
        )
        root = Path(output_dir).resolve()
        root.mkdir(parents=True, exist_ok=True)
        raw_path = root / f"exchangeInfo-{normalized_symbol}-{captured_at_ms}.json"
        snapshot_path = root / f"metadata-snapshot-{normalized_symbol}-{captured_at_ms}.json"
        provenance_path = root / f"exchangeInfo-{normalized_symbol}-{captured_at_ms}.provenance.json"
        snapshot_bytes = (json.dumps(metadata.to_dict(), sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        provenance = {
            "schema_version": 1,
            "source": "BINANCE_USDM_REST_API",
            "symbol": normalized_symbol,
            "exchange_info_url": _EXCHANGE_INFO_URL,
            "server_time_url": _SERVER_TIME_URL,
            "server_time_ms": server_time_ms,
            "local_response_received_at_ms": captured_at_ms,
            "exchange_info_http_date": exchange_response.headers.get("date"),
            "exchange_info_etag": exchange_response.headers.get("etag"),
            "raw_exchange_info_sha256": sha256(raw_bytes).hexdigest(),
            "symbol_snapshot_sha256": metadata.sha256,
            "tick_size": format(info.price_filter.tick_size, "f"),
            "metadata_quality": "CURRENT_SNAPSHOT_ONLY",
            "effective_from_ms": None,
            "effective_to_ms": None,
            "strict_historical_calibration_eligible": False,
            "limitation": (
                "GET /fapi/v1/exchangeInfo returns current trading rules; this capture does not prove "
                "historical PRICE_FILTER.tickSize effectiveness."
            ),
        }
        provenance_bytes = (json.dumps(provenance, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        for target, expected in (
            (raw_path, raw_bytes), (snapshot_path, snapshot_bytes), (provenance_path, provenance_bytes)
        ):
            if target.exists() and target.read_bytes() != expected:
                raise BinanceIntakeError(
                    f"metadata evidence target already exists with different bytes: {target}"
                )
        for target, expected in (
            (raw_path, raw_bytes), (snapshot_path, snapshot_bytes), (provenance_path, provenance_bytes)
        ):
            if not target.exists():
                _atomic_write(target, expected)
        return BinanceMetadataCapture(
            raw_path, snapshot_path, provenance_path, normalized_symbol,
            format(info.price_filter.tick_size, "f"), captured_at_ms, server_time_ms,
            sha256(raw_bytes).hexdigest(), metadata.sha256,
        )
    finally:
        if owns_client:
            active_client.close()
