"""Read-only public REST client for Binance USDⓈ-M Futures."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

import httpx


DEFAULT_BASE_URL = "https://fapi.binance.com"
EXCHANGE_INFO_PATH = "/fapi/v1/exchangeInfo"
KLINES_PATH = "/fapi/v1/klines"
AGG_TRADES_PATH = "/fapi/v1/aggTrades"
TICKER_24H_PATH = "/fapi/v1/ticker/24hr"


class BinanceRestError(RuntimeError):
    """Base class for public REST errors."""


class BinanceTransportError(BinanceRestError):
    """Network or timeout failure after bounded retries."""


class BinanceHttpError(BinanceRestError):
    """Non-success HTTP response after applicable retries."""

    def __init__(self, status_code: int, message: str, endpoint: str) -> None:
        self.status_code = status_code
        self.endpoint = endpoint
        super().__init__(f"Binance HTTP {status_code} from {endpoint}: {message[:500]}")


class BinanceApiError(BinanceRestError):
    """Binance returned an API-level error payload."""

    def __init__(self, code: int, message: str, endpoint: str) -> None:
        self.code = code
        self.endpoint = endpoint
        super().__init__(f"Binance API error {code} from {endpoint}: {message[:500]}")


class BinanceResponseError(BinanceRestError):
    """Binance returned a response that is not the expected JSON structure."""


@dataclass(frozen=True, slots=True)
class BinanceRawKlinePage:
    """A parsed Kline page with the exact original HTTP response bytes retained."""

    rows: tuple[tuple[Any, ...], ...]
    raw_body: bytes
    endpoint: str
    request_params: tuple[tuple[str, str | int], ...]
    response_headers: tuple[tuple[str, str], ...]


class BinanceUsdMFuturesRestClient:
    """Public GET-only client with separate connect/read timeouts and bounded retry."""

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        connect_timeout: float = 3.0,
        read_timeout: float = 5.0,
        max_attempts: int = 3,
        base_backoff_seconds: float = 0.25,
        max_backoff_seconds: float = 1.0,
        http_client: httpx.Client | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if connect_timeout <= 0 or read_timeout <= 0:
            raise ValueError("Connect and read timeouts must be positive")
        if max_attempts < 1 or max_attempts > 5:
            raise ValueError("max_attempts must be between 1 and 5")
        if base_backoff_seconds < 0 or max_backoff_seconds < 0:
            raise ValueError("Backoff values cannot be negative")
        self.base_url = base_url.rstrip("/")
        self.exchange_info_endpoint = f"{self.base_url}{EXCHANGE_INFO_PATH}"
        self.klines_endpoint = f"{self.base_url}{KLINES_PATH}"
        self.server_time_endpoint = f"{self.base_url}/fapi/v1/time"
        self.aggregate_trades_endpoint = f"{self.base_url}{AGG_TRADES_PATH}"
        self.ticker_24h_endpoint = f"{self.base_url}{TICKER_24H_PATH}"
        self.max_attempts = max_attempts
        self.base_backoff_seconds = base_backoff_seconds
        self.max_backoff_seconds = max_backoff_seconds
        self._sleep = sleep
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            timeout=httpx.Timeout(
                connect=connect_timeout,
                read=read_timeout,
                write=connect_timeout,
                pool=connect_timeout,
            ),
            headers={"User-Agent": "DIVATrading-BinanceBot/0.57.0", "Accept": "application/json", "Accept-Encoding": "identity"},
            follow_redirects=False,
        )

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "BinanceUsdMFuturesRestClient":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    def get_exchange_info(self) -> dict[str, Any]:
        """Fetch public contract metadata; this method never accesses private endpoints."""
        payload = self._get_json(self.exchange_info_endpoint)
        if not isinstance(payload, dict):
            raise BinanceResponseError(
                f"Expected JSON object from {self.exchange_info_endpoint}, got {type(payload).__name__}"
            )
        return payload

    def get_klines(
        self,
        *,
        symbol: str,
        interval: str,
        start_time_ms: int,
        end_time_ms: int,
        limit: int = 500,
    ) -> list[list[Any]]:
        """Fetch one bounded page of public contract klines.

        The time bounds use Binance's inclusive millisecond parameters. Pagination is
        deliberately handled by HistoricalKlineService, not by this transport method.
        """
        normalized_symbol = symbol.strip().upper()
        if not normalized_symbol or not normalized_symbol.isalnum():
            raise ValueError("symbol must be a non-empty alphanumeric Binance contract symbol")
        if interval not in {"1m", "5m", "15m"}:
            raise ValueError("interval must be one of: 1m, 5m, 15m")
        if isinstance(start_time_ms, bool) or not isinstance(start_time_ms, int) or start_time_ms < 0:
            raise ValueError("start_time_ms must be a non-negative integer")
        if isinstance(end_time_ms, bool) or not isinstance(end_time_ms, int) or end_time_ms < start_time_ms:
            raise ValueError("end_time_ms must be an integer greater than or equal to start_time_ms")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1500:
            raise ValueError("limit must be an integer between 1 and 1500")

        payload = self._get_json(
            self.klines_endpoint,
            params={
                "symbol": normalized_symbol,
                "interval": interval,
                "startTime": start_time_ms,
                "endTime": end_time_ms,
                "limit": limit,
            },
        )
        if not isinstance(payload, list):
            raise BinanceResponseError(
                f"Expected JSON array from {self.klines_endpoint}, got {type(payload).__name__}"
            )
        return payload

    def get_klines_page_with_evidence(
        self,
        *,
        symbol: str,
        interval: str,
        start_time_ms: int,
        end_time_ms: int,
        limit: int = 1500,
    ) -> BinanceRawKlinePage:
        """Fetch one Kline page while preserving its exact response body and headers."""
        normalized_symbol = symbol.strip().upper()
        if not normalized_symbol or not normalized_symbol.isalnum():
            raise ValueError("symbol must be a non-empty alphanumeric Binance contract symbol")
        if interval not in {"1m", "5m", "15m"}:
            raise ValueError("interval must be one of: 1m, 5m, 15m")
        if isinstance(start_time_ms, bool) or not isinstance(start_time_ms, int) or start_time_ms < 0:
            raise ValueError("start_time_ms must be a non-negative integer")
        if isinstance(end_time_ms, bool) or not isinstance(end_time_ms, int) or end_time_ms < start_time_ms:
            raise ValueError("end_time_ms must be an integer greater than or equal to start_time_ms")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1500:
            raise ValueError("limit must be an integer between 1 and 1500")
        params: dict[str, str | int] = {
            "symbol": normalized_symbol,
            "interval": interval,
            "startTime": start_time_ms,
            "endTime": end_time_ms,
            "limit": limit,
        }
        response = self._get_response(self.klines_endpoint, params=params)
        content_encoding = response.headers.get("content-encoding", "identity").strip().lower()
        if content_encoding not in {"", "identity"}:
            raise BinanceResponseError(
                "Binance Kline response used content encoding despite the identity request; "
                "raw response bytes cannot be guaranteed"
            )
        payload = self._decode_json_response(response, self.klines_endpoint)
        if not isinstance(payload, list) or any(not isinstance(row, (list, tuple)) for row in payload):
            raise BinanceResponseError(
                f"Expected array of Kline rows from {self.klines_endpoint}"
            )
        headers = tuple(sorted(
            (name.lower(), value)
            for name, value in response.headers.items()
            if name.lower() in {
                "date", "etag", "last-modified", "content-length", "content-type", "content-encoding",
                "x-mbx-used-weight-1m", "x-mbx-used-weight",
            }
        ))
        return BinanceRawKlinePage(
            rows=tuple(tuple(row) for row in payload),
            raw_body=response.content,
            endpoint=self.klines_endpoint,
            request_params=tuple(sorted(params.items())),
            response_headers=headers,
        )

    def get_server_time_ms(self) -> int:
        """Fetch Binance's public USD-M server clock in Unix milliseconds."""
        payload = self._get_json(self.server_time_endpoint)
        if not isinstance(payload, dict):
            raise BinanceResponseError("Expected JSON object from Binance server-time endpoint")
        value = payload.get("serverTime")
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise BinanceResponseError("Binance serverTime is not a positive integer")
        return value

    def get_ticker_24h(self, *, symbol: str | None = None) -> list[dict[str, Any]]:
        """Fetch current 24h ticker statistics for the complete USD-M universe or one symbol."""
        params: dict[str, Any] = {}
        if symbol is not None:
            normalized = symbol.strip().upper()
            if not normalized or not normalized.isalnum():
                raise ValueError("symbol must be a non-empty alphanumeric Binance contract symbol")
            params["symbol"] = normalized
        payload = self._get_json(self.ticker_24h_endpoint, params=params or None)
        if isinstance(payload, dict):
            payload = [payload]
        if not isinstance(payload, list) or any(not isinstance(item, dict) for item in payload):
            raise BinanceResponseError(f"Expected ticker object array from {self.ticker_24h_endpoint}")
        return payload

    def get_aggregate_trades(
        self,
        *,
        symbol: str,
        from_id: int | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Fetch one bounded page of USDⓈ-M aggregate trades.

        ``from_id`` is inclusive. Time bounds are deliberately not mixed with
        fromId because Binance warns that combining them can cause timeouts.
        Pagination belongs to AggregateTradeHistoryService.
        """
        normalized_symbol = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized_symbol or not normalized_symbol.isalnum():
            raise ValueError("symbol must be a non-empty alphanumeric Binance contract symbol")
        if from_id is not None and (
            isinstance(from_id, bool) or not isinstance(from_id, int) or from_id < 0
        ):
            raise ValueError("from_id must be a non-negative integer or None")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be an integer between 1 and 1000")

        params: dict[str, Any] = {"symbol": normalized_symbol, "limit": limit}
        if from_id is not None:
            params["fromId"] = from_id
        payload = self._get_json(self.aggregate_trades_endpoint, params=params)
        if not isinstance(payload, list):
            raise BinanceResponseError(
                f"Expected JSON array from {self.aggregate_trades_endpoint}, "
                f"got {type(payload).__name__}"
            )
        if any(not isinstance(item, dict) for item in payload):
            raise BinanceResponseError(
                f"Expected objects in response from {self.aggregate_trades_endpoint}"
            )
        return payload

    def _get_json(self, endpoint: str, *, params: dict[str, Any] | None = None) -> Any:
        response = self._get_response(endpoint, params=params)
        return self._decode_json_response(response, endpoint)

    def _get_response(
        self, endpoint: str, *, params: dict[str, Any] | None = None
    ) -> httpx.Response:
        last_transport_error: Exception | None = None
        last_http_error: BinanceHttpError | None = None

        for attempt in range(self.max_attempts):
            try:
                response = self._client.get(endpoint, params=params)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_transport_error = exc
                if attempt + 1 >= self.max_attempts:
                    break
                self._sleep(self._backoff(attempt))
                continue

            if response.status_code < 200 or response.status_code >= 300:
                last_http_error = BinanceHttpError(response.status_code, response.text, endpoint)
                retryable = response.status_code == 429 or 500 <= response.status_code <= 599
                if retryable and attempt + 1 < self.max_attempts:
                    self._sleep(self._backoff(attempt, response.headers.get("Retry-After")))
                    continue
                raise last_http_error
            return response

        if last_transport_error is not None:
            raise BinanceTransportError(
                f"Binance request failed after {self.max_attempts} attempts: "
                f"{endpoint} ({type(last_transport_error).__name__}: {last_transport_error})"
            ) from last_transport_error
        if last_http_error is not None:
            raise last_http_error
        raise BinanceRestError(f"Binance request failed without a response: {endpoint}")

    @staticmethod
    def _decode_json_response(response: httpx.Response, endpoint: str) -> Any:
        try:
            payload = response.json()
        except ValueError as exc:
            raise BinanceResponseError(f"Binance returned invalid JSON from {endpoint}") from exc
        if isinstance(payload, dict):
            code = payload.get("code")
            message = payload.get("msg")
            if isinstance(code, int) and code < 0:
                raise BinanceApiError(code, str(message or "Unspecified API error"), endpoint)
        return payload

    def _backoff(self, attempt: int, retry_after: str | None = None) -> float:
        if retry_after:
            try:
                requested = max(0.0, float(retry_after))
                return min(requested, self.max_backoff_seconds)
            except ValueError:
                pass
        return min(self.base_backoff_seconds * (2**attempt), self.max_backoff_seconds)
