"""Exact-symbol resolver for Binance USDⓈ-M Futures contracts."""

from __future__ import annotations

from divatrading.exchange.binance.models import ExchangeInfoSnapshot, SymbolInfo


class SymbolResolutionError(LookupError):
    """Base class for instrument resolution errors."""


class SymbolNotFoundError(SymbolResolutionError):
    """The requested exact Binance symbol is absent from Exchange Information."""


class SymbolNotTradableError(SymbolResolutionError):
    """The symbol exists but is not an active USDT-margined perpetual contract."""


class SymbolResolver:
    """Resolve exact Binance contract symbols; intentionally no fuzzy aliases."""

    def __init__(self, snapshot: ExchangeInfoSnapshot) -> None:
        self._snapshot = snapshot
        self._symbols = {item.symbol: item for item in snapshot.symbols}

    def resolve(self, symbol: str, *, tradable_only: bool = True) -> SymbolInfo:
        normalized = symbol.strip().upper()
        if not normalized:
            raise ValueError("Symbol cannot be empty")
        instrument = self._symbols.get(normalized)
        if instrument is None:
            raise SymbolNotFoundError(
                f"Exact Binance symbol '{normalized}' was not found in Exchange Information; "
                "use the contract symbol, for example BTCUSDT (not the base asset BTC)."
            )
        if tradable_only and not instrument.is_tradable_usdt_perpetual:
            raise SymbolNotTradableError(
                f"{normalized} exists but is not an active USDT-margined perpetual: "
                f"status={instrument.status}, contractType={instrument.contract_type}, "
                f"quoteAsset={instrument.quote_asset}, marginAsset={instrument.margin_asset!r}."
            )
        return instrument

    def list_tradable(self) -> tuple[SymbolInfo, ...]:
        return self._snapshot.tradable_usdt_perpetuals

    def contains_exact(self, symbol: str) -> bool:
        return symbol.strip().upper() in self._symbols
