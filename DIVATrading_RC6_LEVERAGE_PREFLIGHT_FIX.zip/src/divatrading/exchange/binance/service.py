"""Application service that fetches, parses and caches public contract metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import ExchangeInfoSnapshot, parse_exchange_info


@dataclass(frozen=True, slots=True)
class MetadataRefreshResult:
    snapshot: ExchangeInfoSnapshot
    database_snapshot_id: int

    @property
    def all_symbol_count(self) -> int:
        return len(self.snapshot.symbols)

    @property
    def tradable_symbol_count(self) -> int:
        return len(self.snapshot.tradable_usdt_perpetuals)


class BinanceMetadataService:
    """Keep the last successful Exchange Information payload in local SQLite."""

    def __init__(self, client: BinanceUsdMFuturesRestClient | None, database: Database) -> None:
        self.client = client
        self.database = database

    def refresh(self) -> MetadataRefreshResult:
        if self.client is None:
            raise RuntimeError("A Binance REST client is required to refresh Exchange Information")
        # Parsing completes before cache write. A malformed response never replaces
        # the last known-good snapshot.
        payload: dict[str, Any] = self.client.get_exchange_info()
        snapshot = parse_exchange_info(
            payload,
            source_endpoint=self.client.exchange_info_endpoint,
        )
        snapshot_id = self.database.save_exchange_metadata_snapshot(
            source_endpoint=snapshot.source_endpoint,
            fetched_at_utc=snapshot.fetched_at_utc,
            server_time_ms=snapshot.server_time_ms,
            symbol_count=len(snapshot.symbols),
            payload=snapshot.raw_payload,
        )
        self.database.record_event(
            "INFO",
            "binance_metadata",
            "exchange_info_refreshed",
            "Binance USD-M Exchange Information refreshed",
            {
                "snapshot_id": snapshot_id,
                "all_symbol_count": len(snapshot.symbols),
                "tradable_symbol_count": len(snapshot.tradable_usdt_perpetuals),
                "source_endpoint": snapshot.source_endpoint,
                "fetched_at_utc": snapshot.fetched_at_utc,
            },
        )
        return MetadataRefreshResult(snapshot=snapshot, database_snapshot_id=snapshot_id)

    def load_latest_cached(self) -> ExchangeInfoSnapshot | None:
        record = self.database.latest_exchange_metadata_snapshot()
        if record is None:
            return None
        return parse_exchange_info(
            record["payload"],
            source_endpoint=record["source_endpoint"],
            fetched_at_utc=record["fetched_at_utc"],
        )
