"""Typed models and defensive parsing for Binance USDⓈ-M Exchange Information."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping


class MetadataParseError(ValueError):
    """Raised when the top-level Exchange Information payload is unusable."""


def _optional_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if not result.is_finite():
        return None
    return result


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return None


def _optional_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    if isinstance(value, (int, str)):
        normalized = str(value).strip().lower()
        if normalized in {"1", "true", "yes"}:
            return True
        if normalized in {"0", "false", "no"}:
            return False
    return None


@dataclass(frozen=True, slots=True)
class PriceFilter:
    min_price: Decimal | None = None
    max_price: Decimal | None = None
    tick_size: Decimal | None = None


@dataclass(frozen=True, slots=True)
class QuantityFilter:
    min_qty: Decimal | None = None
    max_qty: Decimal | None = None
    step_size: Decimal | None = None


@dataclass(frozen=True, slots=True)
class NotionalFilter:
    min_notional: Decimal | None = None
    max_notional: Decimal | None = None
    apply_to_market: bool | None = None
    apply_min_to_market: bool | None = None
    apply_max_to_market: bool | None = None
    avg_price_mins: int | None = None


@dataclass(frozen=True, slots=True)
class SymbolInfo:
    symbol: str
    pair: str | None
    contract_type: str
    status: str
    base_asset: str
    quote_asset: str
    margin_asset: str | None
    price_precision: int | None
    quantity_precision: int | None
    onboard_date_ms: int | None
    delivery_date_ms: int | None
    underlying_type: str | None
    underlying_sub_type: tuple[str, ...]
    order_types: tuple[str, ...]
    time_in_force: tuple[str, ...]
    price_filter: PriceFilter | None
    lot_size: QuantityFilter | None
    market_lot_size: QuantityFilter | None
    min_notional_filter: NotionalFilter | None
    notional_filter: NotionalFilter | None
    raw_filters: tuple[Any, ...]
    unknown_filter_types: tuple[str, ...]
    filter_parse_warnings: tuple[str, ...]
    raw_symbol: dict[str, Any]

    @property
    def is_tradable_usdt_perpetual(self) -> bool:
        """True only for active, USDT-quoted and USDT-margined perpetuals."""
        return (
            self.status == "TRADING"
            and self.contract_type == "PERPETUAL"
            and self.quote_asset == "USDT"
            and self.margin_asset == "USDT"
        )

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "SymbolInfo":
        required = ("symbol", "contractType", "status", "baseAsset", "quoteAsset")
        missing = [key for key in required if not isinstance(payload.get(key), str) or not payload[key]]
        if missing:
            raise MetadataParseError(f"Symbol metadata missing required string fields: {', '.join(missing)}")

        raw_filters_value = payload.get("filters", [])
        warnings: list[str] = []
        if raw_filters_value is None:
            raw_filters_value = []
        if not isinstance(raw_filters_value, list):
            warnings.append("filters is not a list; raw value was not parsed")
            raw_filters_value = []

        raw_filters: list[Any] = []
        by_type: dict[str, dict[str, Any]] = {}
        unknown_types: list[str] = []
        known_types = {"PRICE_FILTER", "LOT_SIZE", "MARKET_LOT_SIZE", "MIN_NOTIONAL", "NOTIONAL"}
        for index, item in enumerate(raw_filters_value):
            if not isinstance(item, dict):
                warnings.append(f"filters[{index}] is not an object")
                raw_filters.append(item)
                continue
            raw_copy = dict(item)
            raw_filters.append(raw_copy)
            filter_type = item.get("filterType")
            if not isinstance(filter_type, str) or not filter_type:
                warnings.append(f"filters[{index}] has no valid filterType")
                continue
            by_type.setdefault(filter_type, raw_copy)
            if filter_type not in known_types and filter_type not in unknown_types:
                unknown_types.append(filter_type)

        price_raw = by_type.get("PRICE_FILTER")
        lot_raw = by_type.get("LOT_SIZE")
        market_lot_raw = by_type.get("MARKET_LOT_SIZE")
        min_notional_raw = by_type.get("MIN_NOTIONAL")
        notional_raw = by_type.get("NOTIONAL")

        def quantity_filter(raw: dict[str, Any] | None) -> QuantityFilter | None:
            if raw is None:
                return None
            return QuantityFilter(
                min_qty=_optional_decimal(raw.get("minQty")),
                max_qty=_optional_decimal(raw.get("maxQty")),
                step_size=_optional_decimal(raw.get("stepSize")),
            )

        def notional_filter(raw: dict[str, Any] | None) -> NotionalFilter | None:
            if raw is None:
                return None
            # Futures Exchange Information has used both minNotional and notional
            # across filter variants/document revisions; preserve raw data too.
            minimum = raw.get("minNotional", raw.get("notional"))
            return NotionalFilter(
                min_notional=_optional_decimal(minimum),
                max_notional=_optional_decimal(raw.get("maxNotional")),
                apply_to_market=_optional_bool(raw.get("applyToMarket")),
                apply_min_to_market=_optional_bool(raw.get("applyMinToMarket")),
                apply_max_to_market=_optional_bool(raw.get("applyMaxToMarket")),
                avg_price_mins=_optional_int(raw.get("avgPriceMins")),
            )

        if price_raw is not None:
            price_filter = PriceFilter(
                min_price=_optional_decimal(price_raw.get("minPrice")),
                max_price=_optional_decimal(price_raw.get("maxPrice")),
                tick_size=_optional_decimal(price_raw.get("tickSize")),
            )
        else:
            price_filter = None

        underlying = payload.get("underlyingSubType", [])
        if not isinstance(underlying, list):
            warnings.append("underlyingSubType is not a list")
            underlying = []
        order_types = payload.get("orderTypes", [])
        if not isinstance(order_types, list):
            warnings.append("orderTypes is not a list")
            order_types = []
        time_in_force = payload.get("timeInForce", [])
        if not isinstance(time_in_force, list):
            warnings.append("timeInForce is not a list")
            time_in_force = []

        return cls(
            symbol=payload["symbol"].upper(),
            pair=payload.get("pair") if isinstance(payload.get("pair"), str) else None,
            contract_type=payload["contractType"].upper(),
            status=payload["status"].upper(),
            base_asset=payload["baseAsset"].upper(),
            quote_asset=payload["quoteAsset"].upper(),
            margin_asset=(str(payload.get("marginAsset")).upper() if payload.get("marginAsset") else None),
            price_precision=_optional_int(payload.get("pricePrecision")),
            quantity_precision=_optional_int(payload.get("quantityPrecision")),
            onboard_date_ms=_optional_int(payload.get("onboardDate")),
            delivery_date_ms=_optional_int(payload.get("deliveryDate")),
            underlying_type=(payload.get("underlyingType") if isinstance(payload.get("underlyingType"), str) else None),
            underlying_sub_type=tuple(str(value) for value in underlying),
            order_types=tuple(str(value) for value in order_types),
            time_in_force=tuple(str(value) for value in time_in_force),
            price_filter=price_filter,
            lot_size=quantity_filter(lot_raw),
            market_lot_size=quantity_filter(market_lot_raw),
            min_notional_filter=notional_filter(min_notional_raw),
            notional_filter=notional_filter(notional_raw),
            raw_filters=tuple(raw_filters),
            unknown_filter_types=tuple(unknown_types),
            filter_parse_warnings=tuple(warnings),
            raw_symbol=dict(payload),
        )


@dataclass(frozen=True, slots=True)
class ExchangeInfoSnapshot:
    source_endpoint: str
    fetched_at_utc: str
    server_time_ms: int | None
    timezone: str | None
    symbols: tuple[SymbolInfo, ...]
    raw_payload: dict[str, Any]

    @property
    def tradable_usdt_perpetuals(self) -> tuple[SymbolInfo, ...]:
        return tuple(symbol for symbol in self.symbols if symbol.is_tradable_usdt_perpetual)

    def get_symbol(self, symbol: str) -> SymbolInfo | None:
        normalized = symbol.strip().upper()
        return next((item for item in self.symbols if item.symbol == normalized), None)


def parse_exchange_info(
    payload: Any,
    *,
    source_endpoint: str,
    fetched_at_utc: str | None = None,
) -> ExchangeInfoSnapshot:
    """Parse an Exchange Information response without guessing symbol aliases."""
    if not isinstance(payload, dict):
        raise MetadataParseError("Exchange Information response must be a JSON object")
    raw_symbols = payload.get("symbols")
    if not isinstance(raw_symbols, list):
        raise MetadataParseError("Exchange Information response does not contain a symbols array")

    symbols: list[SymbolInfo] = []
    seen_symbols: set[str] = set()
    for index, raw_symbol in enumerate(raw_symbols):
        if not isinstance(raw_symbol, dict):
            raise MetadataParseError(f"Exchange Information symbols[{index}] must be an object")
        try:
            parsed_symbol = SymbolInfo.from_payload(raw_symbol)
        except MetadataParseError as exc:
            raise MetadataParseError(f"Invalid symbols[{index}]: {exc}") from exc
        if parsed_symbol.symbol in seen_symbols:
            raise MetadataParseError(f"Duplicate contract symbol in Exchange Information: {parsed_symbol.symbol}")
        seen_symbols.add(parsed_symbol.symbol)
        symbols.append(parsed_symbol)

    now = datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    server_time = _optional_int(payload.get("serverTime"))
    timezone = payload.get("timezone") if isinstance(payload.get("timezone"), str) else None
    return ExchangeInfoSnapshot(
        source_endpoint=source_endpoint,
        fetched_at_utc=fetched_at_utc or now,
        server_time_ms=server_time,
        timezone=timezone,
        symbols=tuple(symbols),
        raw_payload=dict(payload),
    )
