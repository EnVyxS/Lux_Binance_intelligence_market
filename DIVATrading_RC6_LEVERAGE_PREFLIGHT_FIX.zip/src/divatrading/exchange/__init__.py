"""Exchange connectivity adapters."""
