"""Explicit, opt-in installer for the isolated Kronos-mini shadow model."""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from divatrading.intelligence.kronos import KRONOS_MODEL_REPO, KRONOS_TOKENIZER_REPO

GITHUB_REPOSITORY = "shiyu-coder/Kronos"
CPU_TORCH_VERSION = "2.5.1+cpu"
PYTHON_PACKAGES = (
    "numpy==1.26.4",
    "pandas==2.2.2",
    "einops==0.8.1",
    "huggingface_hub==0.33.1",
    "matplotlib==3.9.3",
    "tqdm==4.67.1",
    "safetensors==0.6.2",
)


class KronosInstallError(RuntimeError):
    """Raised when safe optional-model installation cannot be completed."""


def _download(url: str, destination: Path, *, timeout: int = 60) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "DIVATrading-KronosInstaller/0.58"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, destination.open("wb") as handle:
            shutil.copyfileobj(response, handle)
    except Exception as exc:
        destination.unlink(missing_ok=True)
        raise KronosInstallError(f"Download failed for {url.split('?')[0]} ({type(exc).__name__})") from None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_extract(zip_path: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    try:
        with zipfile.ZipFile(zip_path) as archive:
            members = archive.infolist()
            for member in members:
                candidate = (root / member.filename).resolve()
                if candidate != root and root not in candidate.parents:
                    raise KronosInstallError("Kronos source archive contains an unsafe path")
            archive.extractall(root)
    except (OSError, zipfile.BadZipFile) as exc:
        raise KronosInstallError(f"Unable to extract Kronos source ({type(exc).__name__})") from None
    candidates = [item for item in root.iterdir() if item.is_dir() and (item / "model" / "__init__.py").is_file()]
    if len(candidates) != 1 or not (candidates[0] / "LICENSE").is_file():
        raise KronosInstallError("Downloaded repository did not match the expected Kronos source layout/license")
    return candidates[0]


def _run_pip(args: list[str]) -> None:
    command = [sys.executable, "-m", "pip", "install", *args]
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as exc:
        raise KronosInstallError(f"Python dependency installation failed with exit code {exc.returncode}") from None


def install_kronos(root: Path, *, install_dependencies: bool = True) -> dict[str, Any]:
    """Download pinned source/model snapshots and write the install manifest last.

    This function never runs during normal DIVATrading startup. Model weights are
    stored outside the release archive under ``.kronos``.
    """
    root = Path(root).expanduser().resolve()
    kronos_root = root / ".kronos"
    staging = kronos_root / "staging"
    if sys.version_info[:3] != (3, 12, 9):
        raise KronosInstallError(
            f"Kronos install requires the target Python 3.12.9 runtime; found {sys.version.split()[0]}"
        )
    kronos_root.mkdir(parents=True, exist_ok=True)
    # Invalidate any previous manifest first. A failed re-install must never
    # leave a stale manifest claiming that a partially replaced model is ready.
    (kronos_root / "kronos_install_manifest.json").unlink(missing_ok=True)
    if install_dependencies:
        # CPU wheel avoids pulling a CUDA stack onto the 8 GB Windows target.
        _run_pip([f"torch=={CPU_TORCH_VERSION}", "--extra-index-url", "https://download.pytorch.org/whl/cpu"])
        _run_pip(list(PYTHON_PACKAGES))

    try:
        from huggingface_hub import HfApi, snapshot_download
    except ImportError as exc:
        raise KronosInstallError("huggingface_hub missing; run this command through the project venv") from exc

    staging.mkdir(parents=True, exist_ok=True)
    api_request = urllib.request.Request(
        f"https://api.github.com/repos/{GITHUB_REPOSITORY}/commits/master",
        headers={"Accept": "application/vnd.github+json", "User-Agent": "DIVATrading-KronosInstaller/0.58"},
    )
    try:
        with urllib.request.urlopen(api_request, timeout=30) as response:
            source_info = json.loads(response.read().decode("utf-8"))
        source_commit = str(source_info["sha"])
    except Exception as exc:
        raise KronosInstallError(f"Unable to resolve official Kronos source revision ({type(exc).__name__})") from None
    if len(source_commit) != 40 or any(char not in "0123456789abcdef" for char in source_commit.lower()):
        raise KronosInstallError("GitHub returned an invalid Kronos source commit")

    archive_path = staging / "kronos-source.zip"
    source_url = f"https://codeload.github.com/{GITHUB_REPOSITORY}/zip/{source_commit}"
    _download(source_url, archive_path)
    archive_sha256 = _sha256(archive_path)
    source_extract = staging / "source-extract"
    if source_extract.exists():
        shutil.rmtree(source_extract)
    source_dir = _safe_extract(archive_path, source_extract)
    final_source = kronos_root / "source"
    if final_source.exists():
        shutil.rmtree(final_source)
    shutil.move(str(source_dir), str(final_source))

    api = HfApi()
    try:
        model_revision = str(api.model_info(KRONOS_MODEL_REPO).sha)
        tokenizer_revision = str(api.model_info(KRONOS_TOKENIZER_REPO).sha)
        model_dir = Path(snapshot_download(
            repo_id=KRONOS_MODEL_REPO, revision=model_revision,
            local_dir=str(kronos_root / "model"),
        )).resolve()
        tokenizer_dir = Path(snapshot_download(
            repo_id=KRONOS_TOKENIZER_REPO, revision=tokenizer_revision,
            local_dir=str(kronos_root / "tokenizer"),
        )).resolve()
    except Exception as exc:
        raise KronosInstallError(f"Hugging Face model download failed ({type(exc).__name__})") from None

    if not (model_dir / "config.json").is_file() or not any(model_dir.glob("*.safetensors")):
        raise KronosInstallError("Kronos-mini model snapshot is incomplete")
    if not (tokenizer_dir / "config.json").is_file() and not any(tokenizer_dir.glob("*.json")):
        raise KronosInstallError("Kronos tokenizer snapshot is incomplete")

    manifest: dict[str, Any] = {
        "schema_version": 1,
        "installed_at_utc": datetime.now(UTC).isoformat(),
        "python_version": sys.version.split()[0],
        "device": "cpu",
        "source_repository": f"https://github.com/{GITHUB_REPOSITORY}",
        "source_commit": source_commit,
        "source_archive_sha256": archive_sha256,
        "source_dir": str(final_source.resolve()),
        "model_repo": KRONOS_MODEL_REPO,
        "model_revision": model_revision,
        "model_dir": str(model_dir),
        "tokenizer_repo": KRONOS_TOKENIZER_REPO,
        "tokenizer_revision": tokenizer_revision,
        "tokenizer_dir": str(tokenizer_dir),
        "torch_version": CPU_TORCH_VERSION if install_dependencies else "preinstalled",
        "install_profile": "CPU_ONLY",
    }
    manifest_path = kronos_root / "kronos_install_manifest.json"
    temporary = manifest_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(manifest_path)
    shutil.rmtree(staging, ignore_errors=True)
    return manifest


__all__ = ["KronosInstallError", "install_kronos"]
