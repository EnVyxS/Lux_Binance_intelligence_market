"""Out-of-sample evaluation of stored Kronos forecasts against closed Binance M5 bars."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from divatrading.intelligence.kronos import KronosForecast, KronosForecastError
from divatrading.market_data.klines import Kline


@dataclass(frozen=True, slots=True)
class KronosForecastEvaluation:
    forecast_id: str
    symbol: str
    horizon_bars: int
    direction_hit: bool
    directional_accuracy_pct: Decimal
    close_mae: Decimal
    close_mape_pct: Decimal
    range_containment_pct: Decimal
    evaluated_bars: int

    def to_dict(self) -> dict[str, str | int | bool]:
        return {
            "forecast_id": self.forecast_id,
            "symbol": self.symbol,
            "horizon_bars": self.horizon_bars,
            "direction_hit": self.direction_hit,
            "directional_accuracy_pct": str(self.directional_accuracy_pct),
            "close_mae": str(self.close_mae),
            "close_mape_pct": str(self.close_mape_pct),
            "range_containment_pct": str(self.range_containment_pct),
            "evaluated_bars": self.evaluated_bars,
        }


def evaluate_kronos_forecast(
    forecast: KronosForecast, actual_candles: Iterable[Kline],
) -> KronosForecastEvaluation:
    """Compare each forecast bar to the matching later closed M5 candle.

    This is forecast diagnostics only. It does not estimate trade PnL, execution
    fill quality, strategy edge, or probability of a signal succeeding.
    """
    actual = tuple(actual_candles)
    if len(actual) != forecast.horizon_bars:
        raise KronosForecastError("actual candle count must equal the complete forecast horizon")
    if any(not isinstance(item, Kline) for item in actual):
        raise KronosForecastError("actual observations must be validated Binance Kline objects")
    expected_times = tuple(item.open_time_ms for item in forecast.forecast_bars)
    actual_times = tuple(item.open_time_ms for item in actual)
    if actual_times != expected_times:
        raise KronosForecastError("actual M5 candles do not exactly match the forecast timestamps")
    if any(item.symbol != forecast.symbol or item.exchange != "BINANCE_UM" or item.interval != "5m" for item in actual):
        raise KronosForecastError("actual candles must match the forecast symbol and Binance USD-M M5")
    previous_forecast_close = forecast.last_observed_close
    previous_actual_close = forecast.last_observed_close
    correct_directions = 0
    absolute_errors: list[Decimal] = []
    percentage_errors: list[Decimal] = []
    contained_ranges = 0
    for predicted, observed in zip(forecast.forecast_bars, actual, strict=True):
        predicted_move = predicted.close - previous_forecast_close
        observed_move = observed.close - previous_actual_close
        if (predicted_move > 0 and observed_move > 0) or (predicted_move < 0 and observed_move < 0) or (predicted_move == 0 and observed_move == 0):
            correct_directions += 1
        error = abs(predicted.close - observed.close)
        absolute_errors.append(error)
        percentage_errors.append(error / observed.close * Decimal("100"))
        if observed.high <= predicted.high and observed.low >= predicted.low:
            contained_ranges += 1
        previous_forecast_close = predicted.close
        previous_actual_close = observed.close
    last_actual = actual[-1].close
    actual_direction = "UP" if last_actual > forecast.last_observed_close else "DOWN" if last_actual < forecast.last_observed_close else "FLAT"
    count = Decimal(len(actual))
    return KronosForecastEvaluation(
        forecast_id=forecast.forecast_id,
        symbol=forecast.symbol,
        horizon_bars=forecast.horizon_bars,
        direction_hit=(actual_direction == forecast.direction),
        directional_accuracy_pct=Decimal(correct_directions) / count * Decimal("100"),
        close_mae=sum(absolute_errors, Decimal("0")) / count,
        close_mape_pct=sum(percentage_errors, Decimal("0")) / count,
        range_containment_pct=Decimal(contained_ranges) / count * Decimal("100"),
        evaluated_bars=len(actual),
    )


__all__ = ["KronosForecastEvaluation", "evaluate_kronos_forecast"]
