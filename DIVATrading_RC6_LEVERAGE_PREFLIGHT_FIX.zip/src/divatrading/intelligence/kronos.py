"""Lazy, read-only Kronos-mini forecast adapter for Binance USD-M M5 candles.

The adapter never participates in SMC qualification, risk sizing or order execution.
Heavy imports (PyTorch, pandas and the official Kronos source tree) are deferred
until the first forecast request so the core trading runtime remains usable when
Kronos has not been installed.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
import hashlib
import importlib
import json
import math
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Sequence

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline


KRONOS_MODEL_REPO = "NeoQuasar/Kronos-mini"
KRONOS_TOKENIZER_REPO = "NeoQuasar/Kronos-Tokenizer-2k"
KRONOS_GITHUB_REPO = "https://github.com/shiyu-coder/Kronos"
KRONOS_CONTEXT_LIMIT = 2048


class KronosForecastError(RuntimeError):
    """Base class for invalid inputs or failed Kronos inference."""


class KronosForecastUnavailable(KronosForecastError):
    """Raised when the optional Kronos runtime/model has not been installed."""


def _positive_int(value: int, name: str, minimum: int, maximum: int) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise ValueError(f"{name} must be an integer between {minimum} and {maximum}")


def _decimal(value: Any, name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise KronosForecastError(f"Kronos output field {name} is not numeric") from exc
    if not result.is_finite():
        raise KronosForecastError(f"Kronos output field {name} is not finite")
    return result


@dataclass(frozen=True, slots=True)
class KronosConfig:
    """Bounded inference configuration; v1 is deliberately restricted to M5."""

    context_bars: int = 512
    minimum_input_bars: int = 64
    horizon_bars: int = 6
    device: str = "cpu"
    temperature: float = 1.0
    top_p: float = 0.9
    sample_count: int = 1
    torch_threads: int = 2

    def __post_init__(self) -> None:
        _positive_int(self.context_bars, "context_bars", 64, KRONOS_CONTEXT_LIMIT)
        _positive_int(self.minimum_input_bars, "minimum_input_bars", 32, self.context_bars)
        _positive_int(self.horizon_bars, "horizon_bars", 1, 48)
        _positive_int(self.sample_count, "sample_count", 1, 16)
        _positive_int(self.torch_threads, "torch_threads", 1, 16)
        if self.device != "cpu":
            raise ValueError("The supported first-release inference device is cpu")
        if not math.isfinite(self.temperature) or self.temperature <= 0:
            raise ValueError("temperature must be positive and finite")
        if not math.isfinite(self.top_p) or not 0 < self.top_p <= 1:
            raise ValueError("top_p must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class KronosForecastBar:
    open_time_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    amount: Decimal

    def __post_init__(self) -> None:
        if isinstance(self.open_time_ms, bool) or not isinstance(self.open_time_ms, int) or self.open_time_ms < 0:
            raise ValueError("forecast open_time_ms must be a non-negative integer")
        for name in ("open", "high", "low", "close"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
                raise ValueError(f"forecast {name} must be positive finite Decimal")
        if self.high < max(self.open, self.low, self.close):
            raise ValueError("forecast high is inconsistent with OHLC")
        if self.low > min(self.open, self.high, self.close):
            raise ValueError("forecast low is inconsistent with OHLC")
        for name in ("volume", "amount"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
                raise ValueError(f"forecast {name} must be non-negative finite Decimal")

    def to_dict(self) -> dict[str, Any]:
        return {
            "open_time_ms": self.open_time_ms,
            "open": str(self.open), "high": str(self.high), "low": str(self.low),
            "close": str(self.close), "volume": str(self.volume), "amount": str(self.amount),
        }


@dataclass(frozen=True, slots=True)
class KronosForecast:
    forecast_id: str
    symbol: str
    interval: str
    created_at_utc: str
    model_repo: str
    tokenizer_repo: str
    source_commit: str
    model_revision: str
    tokenizer_revision: str
    input_bars: int
    context_bars: int
    horizon_bars: int
    last_observed_open_time_ms: int
    last_observed_close: Decimal
    projected_close: Decimal
    projected_return_pct: Decimal
    direction: str
    forecast_bars: tuple[KronosForecastBar, ...]
    shadow_only: bool = True

    def __post_init__(self) -> None:
        if self.interval != "5m":
            raise ValueError("KronosForecast v1 supports only 5m")
        if self.direction not in {"UP", "DOWN", "FLAT"}:
            raise ValueError("direction must be UP, DOWN or FLAT")
        if not self.shadow_only:
            raise ValueError("Kronos forecasts must remain shadow-only")
        if len(self.forecast_bars) != self.horizon_bars:
            raise ValueError("forecast bar count must match horizon_bars")

    def to_dict(self) -> dict[str, Any]:
        return {
            "forecast_id": self.forecast_id,
            "symbol": self.symbol,
            "interval": self.interval,
            "created_at_utc": self.created_at_utc,
            "model_repo": self.model_repo,
            "tokenizer_repo": self.tokenizer_repo,
            "source_commit": self.source_commit,
            "model_revision": self.model_revision,
            "tokenizer_revision": self.tokenizer_revision,
            "input_bars": self.input_bars,
            "context_bars": self.context_bars,
            "horizon_bars": self.horizon_bars,
            "last_observed_open_time_ms": self.last_observed_open_time_ms,
            "last_observed_close": str(self.last_observed_close),
            "projected_close": str(self.projected_close),
            "projected_return_pct": str(self.projected_return_pct),
            "direction": self.direction,
            "forecast_bars": [item.to_dict() for item in self.forecast_bars],
            "shadow_only": True,
        }


class KronosShadowAdapter:
    """Lazy Kronos-mini inference on a validated contiguous closed M5 Kline series."""

    def __init__(
        self,
        *,
        root: Path | None = None,
        config: KronosConfig | None = None,
        predictor: Any | None = None,
        manifest: dict[str, Any] | None = None,
    ) -> None:
        self.root = Path(root or Path.cwd()).expanduser().resolve()
        self.kronos_dir = self.root / ".kronos"
        self.config = config or KronosConfig()
        self._predictor = predictor
        self._manifest = manifest

    @property
    def manifest_path(self) -> Path:
        return self.kronos_dir / "kronos_install_manifest.json"

    def installed_status(self) -> dict[str, Any]:
        if self._manifest is not None:
            manifest = self._manifest
        elif not self.manifest_path.is_file():
            return {"installed": False, "reason": "KRONOS_INSTALL_MANIFEST_MISSING"}
        else:
            try:
                manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                return {"installed": False, "reason": "KRONOS_INSTALL_MANIFEST_INVALID"}
        required = ("source_dir", "model_dir", "tokenizer_dir", "source_commit", "model_revision", "tokenizer_revision")
        if any(not manifest.get(name) for name in required):
            return {"installed": False, "reason": "KRONOS_INSTALL_MANIFEST_INCOMPLETE"}
        for key in ("source_dir", "model_dir", "tokenizer_dir"):
            if not Path(manifest[key]).is_dir():
                return {"installed": False, "reason": f"KRONOS_PATH_MISSING:{key}"}
        if not (Path(manifest["source_dir"]) / "model").is_dir():
            return {"installed": False, "reason": "KRONOS_SOURCE_MODEL_PACKAGE_MISSING"}
        return {
            "installed": True,
            "model_repo": KRONOS_MODEL_REPO,
            "tokenizer_repo": KRONOS_TOKENIZER_REPO,
            "source_commit": str(manifest["source_commit"]),
            "model_revision": str(manifest["model_revision"]),
            "tokenizer_revision": str(manifest["tokenizer_revision"]),
            "source_dir": str(manifest["source_dir"]),
            "model_dir": str(manifest["model_dir"]),
            "tokenizer_dir": str(manifest["tokenizer_dir"]),
        }

    def _load_predictor(self) -> Any:
        if self._predictor is not None:
            return self._predictor
        status = self.installed_status()
        if not status.get("installed"):
            raise KronosForecastUnavailable(
                "Kronos-mini is not installed. Run: python -m divatrading kronos-install"
            )
        try:
            import torch
            torch.set_num_threads(self.config.torch_threads)
            source_dir = status["source_dir"]
            if source_dir not in sys.path:
                sys.path.insert(0, source_dir)
            kronos_model = importlib.import_module("model")
            imported_from = Path(getattr(kronos_model, "__file__", "")).resolve()
            expected_root = Path(source_dir).resolve()
            if expected_root not in imported_from.parents:
                raise KronosForecastUnavailable(
                    "Python resolved an unrelated 'model' package; refusing ambiguous Kronos import"
                )
            tokenizer = kronos_model.KronosTokenizer.from_pretrained(status["tokenizer_dir"])
            model = kronos_model.Kronos.from_pretrained(status["model_dir"])
            self._predictor = kronos_model.KronosPredictor(
                model, tokenizer, device=self.config.device, max_context=self.config.context_bars,
            )
            return self._predictor
        except KronosForecastUnavailable:
            raise
        except Exception as exc:
            raise KronosForecastUnavailable(f"Unable to load local Kronos runtime: {exc}") from exc

    @staticmethod
    def _validate_candles(
        candles: Iterable[Kline], *, now_ms: int, minimum_input_bars: int
    ) -> tuple[Kline, ...]:
        try:
            rows = tuple(candles)
        except TypeError as exc:
            raise KronosForecastError("candles must be an iterable of validated Kline objects") from exc
        if len(rows) < minimum_input_bars:
            raise KronosForecastError(
                f"at least {minimum_input_bars} closed M5 candles are required"
            )
        if any(not isinstance(item, Kline) for item in rows):
            raise KronosForecastError("only validated Binance Kline objects are accepted")
        symbol = rows[0].symbol
        previous_open: int | None = None
        for item in rows:
            if item.exchange != "BINANCE_UM" or item.symbol != symbol or item.interval != "5m":
                raise KronosForecastError("input must contain one symbol of Binance USD-M M5 candles")
            if item.close_time_ms >= now_ms:
                raise KronosForecastError("forming/future M5 candles are forbidden in Kronos input")
            if previous_open is not None:
                if item.open_time_ms <= previous_open:
                    raise KronosForecastError("M5 candles must be strictly chronological and unique")
                if item.open_time_ms - previous_open != INTERVAL_MILLISECONDS["5m"]:
                    raise KronosForecastError("M5 input contains a gap; Kronos forecast is rejected")
            previous_open = item.open_time_ms
        return rows

    def forecast(
        self,
        candles: Sequence[Kline] | Iterable[Kline],
        *,
        horizon_bars: int | None = None,
        now_ms: int | None = None,
    ) -> KronosForecast:
        """Create a shadow forecast; no signal, risk or execution state is modified."""
        now_value = int(time.time_ns() // 1_000_000) if now_ms is None else now_ms
        if isinstance(now_value, bool) or not isinstance(now_value, int) or now_value <= 0:
            raise KronosForecastError("now_ms must be a positive integer")
        horizon = self.config.horizon_bars if horizon_bars is None else horizon_bars
        _positive_int(horizon, "horizon_bars", 1, 48)
        rows = self._validate_candles(
            candles, now_ms=now_value, minimum_input_bars=self.config.minimum_input_bars,
        )
        context = rows[-self.config.context_bars:]
        try:
            import pandas as pd
        except ImportError as exc:
            raise KronosForecastUnavailable(
                "Kronos dependencies are missing. Run: python -m divatrading kronos-install"
            ) from exc

        interval_ms = INTERVAL_MILLISECONDS["5m"]
        timestamps = pd.to_datetime([item.open_time_ms for item in context], unit="ms", utc=True).tz_localize(None)
        future_open_times = [context[-1].open_time_ms + interval_ms * (index + 1) for index in range(horizon)]
        future_timestamps = pd.to_datetime(future_open_times, unit="ms", utc=True).tz_localize(None)
        frame = pd.DataFrame({
            "open": [float(item.open) for item in context],
            "high": [float(item.high) for item in context],
            "low": [float(item.low) for item in context],
            "close": [float(item.close) for item in context],
            "volume": [float(item.volume) for item in context],
            "amount": [float(item.quote_asset_volume) for item in context],
        })
        predictor = self._load_predictor()
        try:
            predicted = predictor.predict(
                df=frame,
                x_timestamp=pd.Series(timestamps),
                y_timestamp=pd.Series(future_timestamps),
                pred_len=horizon,
                T=self.config.temperature,
                top_p=self.config.top_p,
                sample_count=self.config.sample_count,
            )
        except Exception as exc:
            raise KronosForecastError(f"Kronos inference failed: {exc}") from exc
        if not hasattr(predicted, "iloc") or len(predicted) != horizon:
            raise KronosForecastError("Kronos returned an unexpected forecast frame length")

        bars: list[KronosForecastBar] = []
        for index, open_time_ms in enumerate(future_open_times):
            row = predicted.iloc[index]
            bars.append(KronosForecastBar(
                open_time_ms=open_time_ms,
                open=_decimal(row["open"], "open"),
                high=_decimal(row["high"], "high"),
                low=_decimal(row["low"], "low"),
                close=_decimal(row["close"], "close"),
                volume=max(Decimal("0"), _decimal(row.get("volume", 0), "volume")),
                amount=max(Decimal("0"), _decimal(row.get("amount", 0), "amount")),
            ))
        last_close = context[-1].close
        projected_close = bars[-1].close
        pct = (projected_close - last_close) / last_close * Decimal("100")
        direction = "UP" if projected_close > last_close else "DOWN" if projected_close < last_close else "FLAT"
        status = self.installed_status()
        source_commit = str(status.get("source_commit", "INJECTED"))
        model_revision = str(status.get("model_revision", "INJECTED"))
        tokenizer_revision = str(status.get("tokenizer_revision", "INJECTED"))
        input_digest = hashlib.sha256()
        for item in context:
            input_digest.update((
                f"{item.open_time_ms}|{item.open}|{item.high}|{item.low}|{item.close}|"
                f"{item.volume}|{item.quote_asset_volume}\n"
            ).encode("utf-8"))
        digest_input = "|".join((
            context[0].symbol, "5m", str(context[-1].open_time_ms), str(horizon),
            source_commit, model_revision, tokenizer_revision,
            str(self.config.context_bars), str(self.config.temperature),
            str(self.config.top_p), str(self.config.sample_count), input_digest.hexdigest(),
        ))
        forecast_id = hashlib.sha256(digest_input.encode("utf-8")).hexdigest()[:24]
        return KronosForecast(
            forecast_id=forecast_id,
            symbol=context[-1].symbol,
            interval="5m",
            created_at_utc=datetime.fromtimestamp(now_value / 1000, tz=UTC).isoformat(),
            model_repo=KRONOS_MODEL_REPO,
            tokenizer_repo=KRONOS_TOKENIZER_REPO,
            source_commit=source_commit,
            model_revision=model_revision,
            tokenizer_revision=tokenizer_revision,
            input_bars=len(context),
            context_bars=self.config.context_bars,
            horizon_bars=horizon,
            last_observed_open_time_ms=context[-1].open_time_ms,
            last_observed_close=last_close,
            projected_close=projected_close,
            projected_return_pct=pct,
            direction=direction,
            forecast_bars=tuple(bars),
        )


__all__ = [
    "KRONOS_MODEL_REPO", "KRONOS_TOKENIZER_REPO", "KRONOS_GITHUB_REPO",
    "KRONOS_CONTEXT_LIMIT", "KronosConfig", "KronosForecast", "KronosForecastBar",
    "KronosForecastError", "KronosForecastUnavailable", "KronosShadowAdapter",
]
