"""Rotating file/console logging with basic secret redaction."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterable


class SecretRedactionFilter(logging.Filter):
    """Redact known secret values before a log record reaches a handler."""

    def __init__(self, secrets: Iterable[str] = ()) -> None:
        super().__init__()
        self._secrets = tuple(sorted({s for s in secrets if s and len(s) >= 4}, key=len, reverse=True))

    def filter(self, record: logging.LogRecord) -> bool:
        if not self._secrets:
            return True
        message = record.getMessage()
        for secret in self._secrets:
            message = message.replace(secret, "[REDACTED]")
        record.msg = message
        record.args = ()
        return True


def configure_logging(
    log_dir: Path,
    level: str = "INFO",
    secrets: Iterable[str] = (),
) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("divatrading")
    logger.setLevel(getattr(logging, level.upper()))
    logger.propagate = False

    # Reconfiguration is safe when CLI commands or tests initialize logging more than once.
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()

    formatter = logging.Formatter(
        fmt="%(asctime)sZ | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    redactor = SecretRedactionFilter(secrets)

    file_handler = RotatingFileHandler(
        log_dir / "divatrading.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8"
    )
    console_handler = logging.StreamHandler()
    for handler in (file_handler, console_handler):
        handler.setFormatter(formatter)
        handler.addFilter(redactor)
        logger.addHandler(handler)
    return logger
