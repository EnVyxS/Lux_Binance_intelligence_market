"""Runtime compatibility checks. Trading is deliberately not enabled here."""

from __future__ import annotations

import platform
import struct
import sys
from dataclasses import dataclass
from typing import Sequence


SUPPORTED_PYTHON = (3, 12, 9)


class RuntimeCompatibilityError(RuntimeError):
    """Raised when the interpreter does not match the pinned runtime."""


@dataclass(frozen=True, slots=True)
class RuntimeInfo:
    python_version: str
    bitness: int
    operating_system: str
    platform_release: str


def get_runtime_info() -> RuntimeInfo:
    return RuntimeInfo(
        python_version=platform.python_version(),
        bitness=struct.calcsize("P") * 8,
        operating_system=platform.system(),
        platform_release=platform.release(),
    )


def validate_runtime(
    version: Sequence[int] | None = None,
    bitness: int | None = None,
) -> RuntimeInfo:
    actual_version = tuple(version if version is not None else sys.version_info[:3])
    actual_bits = bitness if bitness is not None else struct.calcsize("P") * 8
    if actual_version != SUPPORTED_PYTHON:
        actual_text = ".".join(str(part) for part in actual_version)
        expected_text = ".".join(str(part) for part in SUPPORTED_PYTHON)
        raise RuntimeCompatibilityError(
            f"Python {expected_text} is required; detected Python {actual_text}. "
            "Run INSTALL_WINDOWS.bat to create the supported virtual environment."
        )
    if actual_bits != 64:
        raise RuntimeCompatibilityError(
            f"64-bit Python is required; detected {actual_bits}-bit interpreter."
        )
    return get_runtime_info()
