"""Small, dependency-free .env and application configuration loader."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


class ConfigurationError(ValueError):
    """Raised when local application configuration is invalid."""


def _parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values

    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            raise ConfigurationError(f"Invalid .env entry at line {line_number}: expected KEY=VALUE")
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or not key.replace("_", "").isalnum() or key[0].isdigit():
            raise ConfigurationError(f"Invalid .env key at line {line_number}")
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        values[key] = value
    return values


def _as_bool(name: str, value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off", ""}:
        return False
    raise ConfigurationError(f"{name} must be true/false, yes/no, on/off, or 1/0")


def _resolve_path(root: Path, raw_value: str) -> Path:
    candidate = Path(raw_value).expanduser()
    return (candidate if candidate.is_absolute() else root / candidate).resolve()


@dataclass(frozen=True, slots=True)
class Settings:
    """Validated immutable settings for the local bot process."""

    project_root: Path
    data_dir: Path
    log_dir: Path
    database_path: Path
    log_level: str
    trading_mode: str
    live_trading_enabled: bool
    binance_api_key: str | None
    binance_api_secret: str | None
    telegram_bot_token: str | None
    telegram_owner_id: str | None

    @classmethod
    def load(
        cls,
        project_root: Path | None = None,
        environ: Mapping[str, str] | None = None,
    ) -> "Settings":
        root = (project_root or Path.cwd()).expanduser().resolve()
        file_values = _parse_env_file(root / ".env")
        merged = dict(file_values)
        # Process environment takes precedence over .env.
        merged.update(dict(os.environ if environ is None else environ))

        data_dir = _resolve_path(root, merged.get("DIVA_DATA_DIR", "data"))
        log_dir = _resolve_path(root, merged.get("DIVA_LOG_DIR", "logs"))
        database_path = _resolve_path(
            root, merged.get("DIVA_DATABASE_PATH", str(data_dir / "divatrading.db"))
        )
        log_level = merged.get("DIVA_LOG_LEVEL", "INFO").strip().upper()
        if log_level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ConfigurationError("DIVA_LOG_LEVEL must be DEBUG, INFO, WARNING, ERROR, or CRITICAL")

        trading_mode = merged.get("DIVA_TRADING_MODE", "PAPER").strip().upper()
        if trading_mode != "PAPER":
            raise ConfigurationError(
                "Unit 01 is PAPER-only. DIVA_TRADING_MODE must remain PAPER until a later, "
                "explicitly validated release supports Testnet or Live mode."
            )
        live_enabled = _as_bool(
            "DIVA_LIVE_TRADING_ENABLED", merged.get("DIVA_LIVE_TRADING_ENABLED", "false")
        )
        # This legacy foundation profile remains PAPER. Execution mode and its
        # separate opt-ins are enforced by ExecutionConfig; a bare boolean flag
        # must never activate live orders on its own.

        return cls(
            project_root=root,
            data_dir=data_dir,
            log_dir=log_dir,
            database_path=database_path,
            log_level=log_level,
            trading_mode=trading_mode,
            live_trading_enabled=live_enabled,
            binance_api_key=merged.get("BINANCE_API_KEY") or None,
            binance_api_secret=merged.get("BINANCE_API_SECRET") or None,
            telegram_bot_token=merged.get("TELEGRAM_BOT_TOKEN") or None,
            telegram_owner_id=merged.get("TELEGRAM_OWNER_ID") or None,
        )
