"""Process ownership, discrepancy policy, worker liveness and operator status."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable


class ProcessLockError(RuntimeError):
    pass


class ProcessLock:
    """OS advisory lock held for the lifetime of the context (POSIX/Windows)."""
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._handle = None

    def acquire(self) -> "ProcessLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt
                handle.seek(0)
                if handle.read(1) == b"":
                    handle.seek(0); handle.write(b"0"); handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            handle.close()
            raise ProcessLockError(f"Another DIVATrading runtime owns lock: {self.path}") from exc
        self._handle = handle
        return self

    def release(self) -> None:
        if self._handle is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                self._handle.seek(0)
                msvcrt.locking(self._handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
        finally:
            self._handle.close(); self._handle = None

    def __enter__(self) -> "ProcessLock":
        return self.acquire()

    def __exit__(self, *_: Any) -> None:
        self.release()


def live_exchange_lock(api_key: str) -> ProcessLock:
    """Share LIVE ownership between local runtimes using the same Binance key."""
    if not api_key:
        raise ValueError("LIVE Binance API key is required for the ownership lock")
    local_app_data = os.environ.get("LOCALAPPDATA") if os.name == "nt" else None
    lock_dir = Path(local_app_data) / "DIVATrading" if local_app_data else Path.home() / ".divatrading"
    account_id = sha256(api_key.encode("utf-8")).hexdigest()
    return ProcessLock(lock_dir / "locks" / f"live-{account_id}.lock")


@dataclass(frozen=True, slots=True)
class DiscrepancyPolicy:
    code: str
    category: str
    halt_entries: bool
    halt_management: bool
    operator_action_required: bool


_HARD_STOP = {
    "ACCOUNT_SNAPSHOT_FAILED", "USER_STREAM_NOT_CONNECTED", "POSITION_QUANTITY_MISMATCH",
    "POSITION_MISSING_PROTECTION", "ORPHAN_DIVA_ORDER", "ORPHAN_DIVA_ALGO_ORDER",
    "PENDING_ENTRY_ORDER_NOT_FOUND", "EVENT_DURING_SNAPSHOT",
}
_OPERATOR = {"UNMANAGED_EXCHANGE_POSITION", "LOCAL_POSITION_NOT_ON_EXCHANGE"}
_RECOVERABLE = {"STALE_RECONCILIATION", "STREAM_RECONNECTED", "TRANSIENT_REST_FAILURE", "EVENT_DURING_SNAPSHOT"}


def classify_discrepancy(code: str) -> DiscrepancyPolicy:
    normalized = str(code).strip().upper()
    if normalized in _HARD_STOP:
        return DiscrepancyPolicy(normalized, "HARD_STOP", True, True, True)
    if normalized in _OPERATOR:
        return DiscrepancyPolicy(normalized, "OPERATOR_ONLY", True, True, True)
    if normalized in _RECOVERABLE:
        return DiscrepancyPolicy(normalized, "RECOVERABLE", True, False, False)
    return DiscrepancyPolicy(normalized or "UNKNOWN", "UNKNOWN_HARD_STOP", True, True, True)


class WorkerWatchdog:
    """In-memory heartbeat registry; stale workers fail closed, never auto-restarted blindly."""
    def __init__(self, *, stale_after_seconds: float = 15.0, clock: Any = time.monotonic) -> None:
        if stale_after_seconds <= 0:
            raise ValueError("stale_after_seconds must be positive")
        self.stale_after_seconds = stale_after_seconds
        self.clock = clock
        self._heartbeats: dict[str, float] = {}

    def heartbeat(self, worker: str) -> None:
        if not worker:
            raise ValueError("worker name is required")
        self._heartbeats[worker] = self.clock()

    def stale_workers(self) -> tuple[str, ...]:
        now = self.clock()
        return tuple(sorted(name for name, stamp in self._heartbeats.items()
                            if now - stamp > self.stale_after_seconds))

    def snapshot(self) -> dict[str, float]:
        return dict(self._heartbeats)


def operator_status(ledger: Any, *, now_ms: int | None = None) -> dict[str, Any]:
    """Return a read-only, JSON-safe operational snapshot without exchange calls."""
    now_ms = now_ms if now_ms is not None else time.time_ns() // 1_000_000
    halted, halt_reason = ledger.entries_halted()
    stream = ledger.get_user_stream_state()
    reconciliation = ledger.get_reconciliation_state()
    positions = ledger.list_managed_positions(status="OPEN")
    actions = ledger.list_position_management_actions()
    reservations = ledger.list_risk_reservations() if hasattr(ledger, "list_risk_reservations") else []
    position_groups = ledger.list_managed_position_groups() if hasattr(ledger, "list_managed_position_groups") else []
    fill_counts = ledger.position_fill_allocation_counts() if hasattr(ledger, "position_fill_allocation_counts") else {}
    return {
        "captured_at_ms": now_ms,
        "entries_halted": halted,
        "entry_halt_reason": halt_reason,
        "user_stream": stream,
        "reconciliation": reconciliation,
        "open_managed_positions": positions,
        "aggregated_position_groups": position_groups,
        "position_fill_allocation_counts": fill_counts,
        "pending_lifecycle_actions": [a for a in actions if str(a.get("status", "")).upper() not in {"CONFIRMED", "FAILED", "CANCELLED"}],
        "risk_reservations": reservations,
    }
