"""Core configuration, runtime, logging, and persistence primitives."""
