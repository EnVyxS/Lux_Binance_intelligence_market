"""Critical multi-task supervision for autonomous market/account runtimes."""
from __future__ import annotations

import asyncio
from typing import Awaitable, Callable


async def run_with_account_supervision(
    market_runner: Callable[[asyncio.Event], Awaitable[None]],
    account_task: asyncio.Task[None],
    stop_event: asyncio.Event,
    halt_entries: Callable[[str], None],
) -> None:
    """Fail closed if account supervision ends while the market runtime is running.

    This function never flattens positions or cancels protective orders. Its
    responsibility is preventing new entries when account truth disappears.
    """
    market_task = asyncio.create_task(market_runner(stop_event), name="diva:market-runtime")
    try:
        done, _ = await asyncio.wait(
            (market_task, account_task), return_when=asyncio.FIRST_COMPLETED,
        )
        # During a normal market shutdown, both tasks can finish in the same
        # event-loop turn after stop_event is set. That is not an account fault.
        if market_task in done:
            await market_task
            return
        if account_task in done:
            halt_entries("AUTONOMOUS_ACCOUNT_SUPERVISOR_STOPPED")
            if account_task.cancelled():
                raise RuntimeError("Account supervisor was cancelled while market runtime was active")
            error = account_task.exception()
            if error is not None:
                raise RuntimeError("Account supervisor failed while market runtime was active") from error
            raise RuntimeError("Account supervisor stopped unexpectedly while market runtime was active")
        await market_task
    finally:
        stop_event.set()
        if not market_task.done():
            market_task.cancel()
        await asyncio.gather(market_task, return_exceptions=True)
