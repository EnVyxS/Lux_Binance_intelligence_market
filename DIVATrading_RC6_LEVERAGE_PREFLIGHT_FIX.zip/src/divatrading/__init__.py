"""DIVATrading Binance Bot package."""

__version__ = "0.59.0rc6"
