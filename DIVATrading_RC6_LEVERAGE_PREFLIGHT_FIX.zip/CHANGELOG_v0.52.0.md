# Changelog v0.52.0 — Quantity-Scoped Protection & Partial-Exit Resize

Date: 2026-11-13

## Implemented

- Replaces new initial STOP/TAKE_PROFIT Algo protection with exact `quantity` scope. `closePosition=true` is omitted. One-way Mode sends `reduceOnly=true`; Hedge Mode sends `positionSide=LONG/SHORT` and omits `reduceOnly`.
- Adds shared validation/build helpers for STOP_MARKET and TAKE_PROFIT_MARKET conditional Algo orders.
- Tightens account reconciliation to verify each managed lot's exact algo client ID, status, order type, closing side, positionSide, quantity, and position-mode-specific reduce semantics.
- Resizes both protective orders after REST-confirmed partial TP fills and partial structural/emergency market exits. New deterministic STOP/TP client IDs are queried before POST, each replacement is REST-verified, and old orders are only cancelled after both replacement orders are confirmed active.
- Adds restart recovery through the durable `RESIZE_PROTECTION` action. Ambiguous submission/cancellation outcomes fail closed and preserve the risk reservation.
- Keeps same-side multi-signal execution disabled until fill allocation and multi-lot supervisor semantics are completed.

## Safety boundaries

- The adapter still requires an explicitly configured TESTNET/LIVE private client; PAPER remains the default execution mode.
- A triggered Algo order that leaves a non-flat residual position remains a safety-halt/reconciliation case. This release does not claim full automatic recovery of partial fills originating from a protective Algo trigger.
- No exchange API request, TESTNET order, LIVE order, or Windows target-PC run was performed in this build environment.
