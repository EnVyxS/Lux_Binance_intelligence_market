# Test Report — v0.58.0rc4

## Full regression
`pytest -q`: **1,024 passed**.

## Focused regression
`pytest -q tests/test_exchange_feasibility_rc4.py tests/test_trade_risk_ledger_rc4.py tests/test_control_plane_v058.py tests/test_live_read_only_preflight.py`: **20 passed**.

## Static/build checks
- `python -m compileall -q src`: passed.
- `import divatrading`; version reports `0.58.0rc4`: passed.
- CLI help smoke test: pending final packaging verification.

## Scope limitations
Tests use fixtures/mocks and local SQLite. They do not represent live Binance authentication, live fee/bracket data, private WebSocket behavior, exchange order acceptance, liquidation behavior, or Windows Python 3.12.9 qualification.
