# Next Task — v0.57.0B: TEST Order Validation

## Entry criteria
- User has extracted v0.57.0 release on the target PC.
- Python 3.12.9 environment and dependencies are installed.
- Demo Trading API key/secret are stored locally in `.env`; never transmitted through chat.
- `DIVA_EXECUTION_MODE=TESTNET`, `DIVA_ENABLE_TESTNET_ORDERS=false`, `DIVA_LIVE_TRADING_ENABLED=false`.
- `testnet-preflight --symbols <selected-symbol>` returns `READY_FOR_TEST_ORDER_VALIDATION`.
- The Demo wallet has available USDT and no open positions/standard/Algo orders.

## Scope
1. Add a signed `POST /fapi/v1/order/test` method with no automatic retry.
2. Validate normalized LIMIT/MARKET request parameter construction against current exchange filters and account position mode.
3. Run a Demo signed test-order request; this endpoint validates order parameters but does not create a live order.
4. Sanitize all request/response logs and prevent API key/secret leakage.
5. Record API response/error classification, latency, timestamp and endpoint; do not save credentials/signatures.
6. No `/fapi/v1/order` or `/fapi/v1/algoOrder` order placement until the separate Stage C explicit test authorization and execution checks.

## Later stages
- v0.57.0C: explicitly authorized tiny Demo entry and fill confirmation.
- v0.57.0D: Algo STOP/TP and residual lifecycle.
- v0.57.0E: stream, backfill, restart, multi-lot and end-to-end qualification.
- LIVE remains disabled throughout v0.57.
