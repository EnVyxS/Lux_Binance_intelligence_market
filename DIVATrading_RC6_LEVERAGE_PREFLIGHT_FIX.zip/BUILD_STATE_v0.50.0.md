# Build State v0.50.0

Baseline: v0.49.0 Managed Position Supervisor.

## Implemented
- `core.reliability.ProcessLock`: POSIX `flock` / Windows `msvcrt` non-blocking lock; integrated into `account-runtime` and `market-runtime`.
- `classify_discrepancy`: recoverable, operator-only, hard-stop and unknown-hard-stop categories. Unknown discrepancy codes fail closed.
- Reconciliation detail includes policy, halt-management and operator-action flags.
- `WorkerWatchdog`: heartbeat registry and stale worker detection primitive.
- `runtime-status`: local read-only JSON snapshot from the execution ledger.
- Ledger read-only listing for risk reservations.

## Verification
- Full regression: 838 passed.
- Compileall: PASS.
- CLI help: PASS; runtime-status command registered.
- Clean extraction: see CLEAN_EXTRACTION_TEST_REPORT_v0.50.0.md.

## Not implemented in this checkpoint
- Telegram transport, delivery retry/idempotency and operator callback actions.
- Embedded HTTP dashboard; operator visibility is currently CLI JSON.
- Automatic worker restart; stale worker detection is fail-closed primitive only.
- Aggregate same-symbol multi-signal position accounting.
- Full autonomous SMC signal-to-entry dispatch.
- Windows 10 / Python 3.12.9 hardware validation and live Binance integration tests.

PAPER remains default. No private Binance API requests or orders were made during tests.
