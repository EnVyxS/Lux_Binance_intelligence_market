@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Project virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 2
)
echo Installing optional Kronos-mini CPU runtime and downloading pinned source/model snapshots...
echo This step requires internet access and can download several hundred MB of Python/model files.
.venv\Scripts\python.exe -m divatrading kronos-install
if errorlevel 1 (
  echo Kronos installation did not complete. DIVATrading core remains installed.
  exit /b 1
)
.venv\Scripts\python.exe -m divatrading kronos-status
exit /b %errorlevel%
