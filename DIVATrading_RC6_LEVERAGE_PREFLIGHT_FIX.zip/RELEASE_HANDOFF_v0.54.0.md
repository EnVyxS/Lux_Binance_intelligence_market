# Release Handoff — DIVATrading Binance Bot v0.54.0

## Release purpose

v0.54.0 adds REST account-trade recovery so fills missed during User Data Stream gaps can be merged into the same immutable fill ledger and per-signal projections.

## Key files

- `src/divatrading/execution/trade_backfill.py` — bounded backfill service and durable run/watermark orchestration.
- `src/divatrading/execution/binance_private.py` — signed `/fapi/v1/userTrades` method.
- `src/divatrading/execution/ledger.py` — REST fill ingestion, source provenance, conflict detection, durable run/watermark tables.
- `src/divatrading/execution/reconciliation.py` — transient halt, backfill integration, 60-second throttle, fail-closed behavior.
- `src/divatrading/cli.py` — TESTNET/LIVE account runtime wiring.
- `tests/test_trade_backfill.py` — REST recovery tests.

## Operating behavior

- PAPER remains default and does not load private API credentials.
- Backfill is only wired into explicitly configured TESTNET/LIVE account-runtime.
- The initial scan defaults to 180 days and is split into inclusive windows no longer than seven days.
- Later runs use `fromId = last_trade_id + 1` only.
- A watermark advances only after all pages/windows have been committed.
- Repeated scans are idempotent by `(symbol, tradeId)`.
- Backfill failure leaves entries halted and reconciliation not-ready.
- A prior manual/safety halt is preserved.

## Verification results

- Full regression: 875 passed.
- Focused REST backfill + User Data Stream/reconciliation: 39 passed.
- Compileall, CLI help, account-runtime help, package import/version and ZIP clean extraction checks: PASS (final clean-extraction report is included in the release).

## Verification boundary

Tests use mocked HTTP and local SQLite. No actual Binance TESTNET/LIVE request or order was executed. Python target remains exactly 3.12.9; current build environment is Linux/Python 3.13.5. Windows 10 validation remains pending.

## Next release

v0.55.0: true multi-lot position supervisor with per-lot mark-price events, lifecycle actions, protection, risk reservations, aggregate position reconciliation and same-side scale-in safety. Do not enable scale-in before full supervisor and TESTNET qualification.
