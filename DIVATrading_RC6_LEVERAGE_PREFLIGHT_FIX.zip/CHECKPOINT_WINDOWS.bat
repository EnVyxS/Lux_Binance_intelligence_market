@echo off
setlocal
cd /d "%~dp0"
where powershell >nul 2>nul
if errorlevel 1 (
  echo ERROR: PowerShell was not found.
  exit /b 1
)
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set STAMP=%%I
if not exist "releases" mkdir "releases"
set OUT=releases\DIVATrading_Unit03D_Checkpoint_%STAMP%.zip
set HASH=%OUT%.sha256
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root=(Get-Location).Path; $out=Join-Path $root '%OUT%'; Add-Type -AssemblyName System.IO.Compression; $skip=@('.venv','.git','releases','__pycache__','.pytest_cache','.diva_temp','data','logs'); $files=Get-ChildItem -LiteralPath $root -Recurse -File -Force | Where-Object { $rel=$_.FullName.Substring($root.Length+1); $parts=$rel -split '[\\/]+'; ($parts | Where-Object { $skip -contains $_ -or $_ -like '*.egg-info' }).Count -eq 0 -and $_.Name -ne '.env' -and $_.Extension -ne '.pyc' }; $stream=[IO.File]::Open($out,[IO.FileMode]::CreateNew); $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create); foreach($file in $files) { $name=$file.FullName.Substring($root.Length+1).Replace('\','/'); $entry=$zip.CreateEntry($name,[IO.Compression.CompressionLevel]::Optimal); $source=$file.OpenRead(); $target=$entry.Open(); try { $source.CopyTo($target) } finally { $target.Dispose(); $source.Dispose() } }; $zip.Dispose(); $stream.Dispose(); $digest=(Get-FileHash -Algorithm SHA256 -LiteralPath $out).Hash.ToLower(); Set-Content -LiteralPath (Join-Path $root '%HASH%') -Value ($digest + '  ' + '%OUT%') -Encoding ascii"
if errorlevel 1 exit /b 1
echo Checkpoint created: %OUT%
echo SHA-256 created: %HASH%
echo Verify the archive and keep every previous known-good release.
exit /b 0
