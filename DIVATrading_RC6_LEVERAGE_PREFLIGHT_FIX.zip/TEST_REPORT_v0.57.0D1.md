# Test Report — v0.57.0D1

## Automated regression

- Full suite on working source: **956 passed** in 16.11 seconds.
- Full suite on clean extracted release tree: **956 passed** in 18.15 seconds.
- Focused `test_position_lifecycle_execution.py`, `test_position_supervisor.py`, and `test_user_data_stream.py`: **92 passed** in 6.60 seconds.
- Python compilation: `python -m compileall -q src tests` — PASS.
- Tests cover exact symbol/clientAlgoId/trigger binding, GET-after-POST protection verification, re-query of ledger-recorded protection, fail-closed handling when recorded protection is missing, and reconciliation rejection of wrong protective trigger prices.

## Environment

- Build/test host: Linux / Python 3.13.5.
- Project package intentionally retains `requires-python ==3.12.9` and Windows 10 64-bit as deployment target.
- This test run is not a Windows 10 / Python 3.12.9 D1 qualification; the C1 Windows evidence remains 952/952 for C1 source.

## Exchange integration not performed

- No actual Binance Demo entry, standard order, Algo order POST/cancel, fill, or User Data Stream session was performed by the build.
- Stage B `/fapi/v1/order/test` and Stage A preflight were previously validated by the operator on C1, but D1's tightened protection-integrity behavior is not yet exchange-qualified.
- LIVE remains disabled and unauthorized.

## Packaging notes

- Wheel build: PASS; wheel metadata reports package `0.57.0rc2` and `Requires-Python: ==3.12.9`.
- The shared build container's global `pip check` reports a pre-existing unrelated environment conflict (`moviepy` requires Pillow below 12, while the container has Pillow 12.3.0). This conflict is not among DIVATrading's declared runtime/development dependencies. No claim is made that the global container environment is dependency-clean; `pip check` must be repeated in the target isolated Windows virtual environment.
