# Release Handoff — v0.49.0

## Release

DIVATrading Binance Bot v0.49.0 — Managed Position Supervisor.

## Baseline

Continue from `DIVATrading_BinanceBot_LifecycleExecutionAdapter_0.48.0.zip`. The recovered v0.48.0 source passed its original 824-test regression before modifications.

## Completed

- Continuous bounded Mark Price supervision for actively managed symbols.
- Per-symbol feed workers with event identity/freshness checks, reconnect/restart and fail-closed entry halt.
- Runtime integration with User Data Stream, lifecycle event reducer and periodic REST account reconciliation.
- Automatic dispatch of partial TP and BE/trailing STOP replacement actions.
- Structural invalidation exit using the approved SMC TradePlan stop/invalidation boundary.
- Explicit emergency close command requiring TESTNET/LIVE, exact managed signal ID, non-empty reason and operator confirmation phrase.
- Full market-close path with deterministic action/client IDs, One-way/Hedge parameter handling, exact market filters, REST fill confirmation, linked protection cleanup and verified-flat risk release.
- Partial terminal TP fill tracking against original position size; remaining target is computed cumulatively rather than recalculated as a fraction of residual size, and the target is snapped/persisted to MARKET quantity step to avoid dust.
- Existing-position observation gate remains available during entry halt only for discrepancy-free, fresh, watermark-consistent exchange reconciliation.
- Single-managed-signal-per-symbol/position-side guard, with deterministic multi-symbol worker coverage. Same-side DIVA scale-in remains unsupported.
- Full regression: 834 passed; focused suites 37 passed; compileall, CLI help and clean extraction validation pass.

## Important boundaries

- This release manages already-open DIVA positions; it does not yet create a fully autonomous signal-to-entry runtime from the continuous SMC market feed.
- Only one active managed signal per exchange symbol/position side is supported. Aggregate same-symbol position ownership and scale-in/scale-out attribution are not implemented.
- Structural invalidation currently uses the approved TradePlan SL boundary because the live TradePlan contract does not yet expose a separate independent OB invalidation boundary.
- Partial/ambiguous full exits retain protection and risk reservation; they are not treated as closed. Operator intervention may be required.
- Dashboard/Telegram, process lock/watchdog and discrepancy remediation remain for v0.50.
- Windows packaging and target-PC validation remain for v0.52.
- No actual Binance TESTNET/LIVE network, account stream, Mark Price WebSocket, order, cancel or fill was validated.

## Next task

v0.50.0 — Runtime reliability, reconciliation remediation and operator visibility: safe discrepancy classification, single-instance process lock, watchdog, worker health/status view, Telegram alerts and guarded operator controls.

## Environment and safety

- PAPER remains default.
- No credentials or private account data are included in the release.
- Tested in Linux / Python 3.13.5. Project contract requires Python 3.12.9; target Windows environment is untested.
- Do not enable LIVE from this checkpoint alone.
