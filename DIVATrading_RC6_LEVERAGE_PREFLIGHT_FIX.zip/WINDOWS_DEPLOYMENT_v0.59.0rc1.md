# Windows Deployment — DIVATrading v0.59.0rc1

## 1. Install and qualify the exact release

1. Extract the ZIP into a new, stable folder. Do not merge it over an older release directory.
2. Install/verify Python 3.12.9 64-bit and the Windows Python Launcher (`py`).
3. Run `INSTALL_WINDOWS.bat`.
4. Run `TEST_WINDOWS.bat`. It verifies Python 3.12.9 x64 and executes the full suite. Stop if any test fails.
5. Run `RUN_WINDOWS.bat` to initialize the local runtime and SQLite database; inspect the generated logs. Do not start an order-enabled mode from an unqualified database.
6. Keep the release directory and `data/divatrading.db` backed up. Do not delete/replace the DB on restarts: it stores order ownership, reconciliation watermarks, completed trades and Telegram update offset.

## 2. Credentials and controls

- `.env.example` is a template only. Copy it to `.env` locally and never upload or share the `.env` file.
- Never paste Binance API key/secret or Telegram token into chat, source code, screenshots, CLI arguments or logs.
- Keep withdrawals disabled and use API IP restrictions where supported.
- The bot is designed for a dedicated USDⓈ-M Futures account under `BOT_ONLY`; manual positions/orders cause entry halt rather than auto-close.
- Telegram token and numeric owner ID must be configured locally. In `auto-trade-runtime`, the owner-only control loop runs alongside account/position supervision. If Telegram disconnects, persisted controls remain active; command availability pauses until reconnect.

## 3. Optional read-only LIVE preflight

Only use a dedicated Binance USDⓈ-M Futures account and only after the exact release passes Windows regression. Set these local `.env` values:

```ini
DIVA_EXECUTION_MODE=LIVE
DIVA_LIVE_TRADING_ENABLED=false
DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true
BINANCE_API_KEY=<local key>
BINANCE_API_SECRET=<local secret>
```

Run:

```powershell
.\.venv\Scripts\python.exe -m divatrading live-read-only-preflight --symbols BTCUSDT
```

This performs signed/public reads only: server time, exchange metadata, account permission/mode, balances, open positions/orders, per-symbol leverage brackets, commission rate and symbol margin/leverage configuration. It does not place/cancel orders or mutate account settings. The LIVE trading flag must remain false.

## 4. Trading status

**Do not start LIVE auto-trading with v0.59.0rc1.** The autonomous CLI contains an explicit hard block for LIVE routing. This candidate is not exchange-commissioned. Before any LIVE release can be authorized, the exact ZIP must pass Windows qualification, read-only account preflight, and a separately reviewed controlled exchange lifecycle acceptance covering entry, fill, both protective legs, partial/final exit, reconnect, restart, reconciliation and kill/pause behavior.
