# Next Task — After v0.57.0D1

1. Stage D2: implement position-aware recovery for a missing or terminal STOP/TP on an already-open managed lot. Require fresh User Data Stream + REST evidence, exact aggregate position quantity, exact signal-lot allocation, and terminal source Algo state before any replacement.
2. Replacement protection must be deterministic, query-first, verified after POST, and must not cancel a known active sibling until both expected protections are verified.
3. Ambiguous POST/query and quantity mismatch remain fail-closed with active risk reservations and entry halt.
4. Extend mocked tests for missing STOP only, missing TP only, triggered STOP with residual quantity, full flat, ambiguous POST, duplicate restart, and two-lot same-side allocations.
5. Do not enable same-side scale-in on actual TESTNET/LIVE until dedicated aggregate quantity and partial fill qualification is complete.
6. C1 actual Stage C entry/fill/protection evidence remains deferred; later supervised Demo qualification is still required before marking exchange integration complete.
7. LIVE remains disabled and unauthorized.
