# Account State v0.44.0

`BinanceAccountStateService.capture()` obtains account equity/balances, open position risk rows, standard open orders and conditional/algo open orders from one signed-client capture sequence. Any failed endpoint or invalid numeric field raises; callers must not size new entries from a partial snapshot.

`open_risk_usdt` is intentionally conservative: it currently reserves absolute position notional, not theoretical stop-loss risk. This can under-allocate available risk but avoids assuming protection exists. Before replacing this with stop-distance risk, reconciliation must verify protective orders and map them to positions, including hedge-mode positionSide.

This module does not submit orders, open User Data Streams, or claim atomic exchange snapshots. The REST calls are sequential and may observe changing account state; execution coordinator must refresh immediately before committing a new entry and reserve risk atomically locally.
