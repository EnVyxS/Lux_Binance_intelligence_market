"""Convert retained TradingView chart CSV exports into a v2 Pine fixture."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from divatrading.strategy.fixture_intake import (  # noqa: E402
    PineFixtureIntakeError,
    build_fixture_from_capture_manifest,
    validate_reference_fixture,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path, help="capture_manifest.json in the CSV directory")
    parser.add_argument("--output", type=Path, help="Output JSON fixture (default: reference_fixture.v2.json beside manifest)")
    args = parser.parse_args()
    output = args.output or args.manifest.parent / "reference_fixture.v2.json"
    try:
        built = build_fixture_from_capture_manifest(args.manifest, output)
    except PineFixtureIntakeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    report = validate_reference_fixture(built, source_dir=args.manifest.parent)
    print(json.dumps({
        "fixture": str(built),
        "accepted": report.accepted,
        "fixture_sha256": report.fixture_sha256,
        "candle_counts": dict(report.candle_counts),
        "signal_count": report.signal_count,
        "issues": [issue.__dict__ if hasattr(issue, "__dict__") else {
            "code": issue.code, "path": issue.path, "message": issue.message
        } for issue in report.issues],
    }, indent=2))
    return 0 if report.accepted else 3


if __name__ == "__main__":
    raise SystemExit(main())
