# Test Report v0.46.0

## Result

- Full regression suite: **779 passed**.
- Focused User Data Stream / account reconciliation suite: **17 passed**.
- `python -m compileall -q src/divatrading`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS; `account-runtime` listed.
- `PYTHONPATH=src python -m divatrading account-runtime --help`: PASS.

## New coverage

- listenKey create/keepalive/close use API-key authorization without HMAC signature/timestamp.
- LIVE WebSocket uses `/private/ws/{listenKey}`; TESTNET uses its configured stream host.
- Reconnect, keepalive, fresh listen-key creation, previous key cleanup, and graceful shutdown.
- Duplicate event suppression and partial ACCOUNT_UPDATE projection.
- Standard ORDER_TRADE_UPDATE and conditional ALGO_UPDATE projection.
- Account position and STOP/TP reconciliation.
- Wrong-side protection rejected (LONG must close with SELL; SHORT must close with BUY).
- Unmanaged positions and missing protection block readiness and halt new entries.
- New account events invalidate prior READY state.
- Event arriving during a sequential REST snapshot prevents READY.
- Atomic commit rejects a late stream event or a disconnected stream before reconciliation can become READY.
- Coordinator and direct TESTNET execution paths block when account is not reconciled.
- TESTNET/LIVE cannot disable the readiness gate; direct submission rechecks immediately before POST and blocks/releases the reservation when account state changes during request preparation.

## Not tested / not claimed

- No connection to Binance LIVE or TESTNET was performed.
- No real listenKey was created; no private account stream event was received from Binance.
- No exchange order was submitted, canceled, or modified by build tests.
- Windows 10 / Python 3.12.9 and 8 GB target hardware are not tested.
- No profitability, strategy calibration, or unattended live-safety claim is made.
