# DIVATrading Release Handoff — v0.57.0B2

## Release identity

- Version: `0.57.0b2`
- Release label: `DIVATrading_BinanceBot_AccountConfigHotfix_0.57.0B2.zip`
- Base release: v0.57.0B
- Hotfix: route account configuration checks to Binance `GET /fapi/v1/accountConfig`.

## Context and diagnosis

A sanitized Demo preflight from the Windows client showed signed account connectivity and several successful account reads, but failed on `ACCOUNT_TRADING_STATUS` and `MARGIN_MODE`. The cause was an outdated expectation that `/fapi/v3/account` would still contain `canTrade` and `multiAssetsMargin`. Binance's account migration moves these account-configuration fields to `/fapi/v1/accountConfig`.

## Source changes

- `src/divatrading/execution/binance_private.py`: new signed GET method `get_account_config()` for `/fapi/v1/accountConfig`.
- `src/divatrading/execution/testnet_qualification.py`: separates balance data parsing from account config checks; fail closed if the config request or required fields are unavailable.
- `tests/test_testnet_qualification.py`: regression tests for the split response shape, missing/failed config response, and signed routing to the Demo host.
- `pyproject.toml`: version bump to `0.57.0b2`.
- Added `ACCOUNT_CONFIG_V0570B2_HOTFIX.md` and build/test/verification reports.

## Safety guarantees

- Demo REST host remains pinned; no LIVE endpoint fallback.
- No API Key or Secret is embedded in source or release package.
- No account setting writes, leverage changes, margin-mode changes, standard orders, Algo orders, or `/fapi/v1/order/test` requests occur during preflight.
- `DIVA_ENABLE_TESTNET_ORDERS=false` and `DIVA_LIVE_TRADING_ENABLED=false` remain mandatory safe defaults.

## Outstanding qualification

- Re-run the patched preflight on the user's Demo account.
- Confirm signed `/fapi/v1/order/test` separately (Stage B); this must not be confused with actual order execution.
- Stage C actual Demo entry/fill/protective order qualification remains pending.
- Windows 10 / Python 3.12.9 installation/runtime has not been executed by the Linux build environment.

See `TEST_REPORT_v0.57.0B2.md`, `CLEAN_EXTRACTION_TEST_REPORT_v0.57.0B2.md`, and `FINAL_RELEASE_VERIFICATION_v0.57.0B2.md`.
