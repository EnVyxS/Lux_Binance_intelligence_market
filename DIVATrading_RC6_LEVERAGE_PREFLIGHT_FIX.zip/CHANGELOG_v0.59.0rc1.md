# Changelog — DIVATrading

## v0.59.0rc1 — Autonomous Execution & Risk Integration Candidate (2026-11-15)

- Connects typed account-specific USDⓈ-M leverage brackets, symbol commission rates and fresh available margin to non-PAPER coordinator/dispatcher sizing. The risk budget is calculated first; round-trip commission, slippage and funding reserves are included; quantity is never increased to satisfy minimum notional.
- Adds guarded per-symbol margin/leverage preparation: exact position/standard-order/Algo-order checks before mutation, `marginType`/leverage writes only for a flat and order-free symbol, and exact `symbolConfig` readback verification. This path is not reachable from autonomous LIVE runtime in this candidate.
- Integrates a restart-safe income-history backfill (90-day bootstrap, seven-day windows, recursive full-page splitting, idempotent rows and fail-closed watermark) with user-trade backfill and account reconciliation.
- Connects completed-lifecycle accounting to attributed fill projections, USDT commissions/realized PnL and funding allocations. Daily loss consumes exchange income rows; transfer cashflows are normalized out of the equity series; mid-day day-start anchors are reconstructed from account margin balance, realized PnL and floating PnL.
- Unknown non-zero income types, unsupported non-USDT fees/cashflows, unowned fills, ambiguous funding allocation and incomplete closed-lot projections keep the risk ledger unready and block new entries.
- Integrates persistent owner-only Telegram controls in the autonomous runtime with automatic reconnect, durable update offset, pre-candidate settings refresh, and confirmed `/resetkill confirm` handling. Pause/kill blocks new entries but does not blindly close managed positions.
- Full source regression: 1,038 passed; `compileall`: passed. Current build host: Linux / Python 3.13.5; project target remains Windows 10 / Python 3.12.9.
- No real exchange account was connected and no TESTNET/LIVE order was submitted. Autonomous LIVE remains explicitly disabled; the package is not permission to begin LIVE trading. Exact archive Windows qualification and supervised exchange lifecycle commissioning remain mandatory.
