# Test Report — v0.57.0

## Environment
- Linux x86_64 container, Python 3.13.5.
- Project requirement remains Python `==3.12.9`; target Windows 10 not tested here.

## Source test results
- Full regression: **927 passed**.
- Focused TESTNET preflight, CLI, User Data Stream and trade-backfill regression: **64 passed**.
- `compileall -q src tests`: PASS.
- `python -m divatrading --help`: PASS; `testnet-preflight` and `auto-trade-runtime` registered.
- `python -m divatrading testnet-preflight --help`: PASS.

## Coverage added/updated
- Demo endpoint isolation; rejects LIVE/custom REST URL before requests.
- REST ping/time sync/metadata/account/position mode/position/order preflight using mocks.
- Signed REST preflight uses GET only on the Demo host.
- CLI requires local TESTNET credentials and prevents LIVE opt-in; output excludes secret.
- Current private WebSocket URL path/query for LIVE and Demo, slash-delimited multi-event subscription, listenKey URL encoding, reconnect path.
- Demo Mark Price endpoint selection.
- User Trades retention bootstrap defaults to 90 days and rejects explicit larger ranges.

- Clean-extraction regression: **927 passed** from the final ZIP.
- ZIP CRC, sensitive-file audit and SHA sidecar verification: PASS.

## Validation boundary
All tests use local SQLite, fixture exchange metadata, fake clients or `httpx.MockTransport`. No actual Binance account authentication, Demo WebSocket connection, `/fapi/v1/order/test`, actual Demo order, or LIVE request was performed. `READY_FOR_TEST_ORDER_VALIDATION` is an expected result for a successful future local preflight, not a result obtained against Binance in this build.
