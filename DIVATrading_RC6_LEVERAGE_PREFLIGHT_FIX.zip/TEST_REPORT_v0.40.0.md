# DIVATrading Test Report — v0.40.0

**Build:** Multi-Pair Auto-Trading Core  
**Date:** 2026-11-12  
**Environment:** Linux x86_64, Python 3.13.5  
**Target:** Windows 10 / Python 3.12.9 / 8 GB RAM — not tested here.

## Automated checks executed

| Check | Result |
|---|---:|
| Full regression suite (`PYTHONPATH=src pytest -q`) | **729 passed** |
| `python -m compileall -q src/divatrading` | PASS |
| `python -m divatrading --help` | PASS |
| `python -m divatrading universe --help` | PASS |
| Package import and version | PASS (`0.40.0`) |
| Execution default configuration | PASS (`PAPER`) |
| PAPER service factory without API keys | PASS |

## New behavior covered by tests

- AUTO selection ranks only active eligible USDⓈ-M USDT perpetuals and enforces volume/trade thresholds and active-symbol caps.
- MANUAL selection applies explicit contract membership and exclusions.
- Decimal risk sizing respects risk budget, portfolio cap, quantity step, minimum quantity/notional and exact tick grid.
- SQLite intent claim is unique across multiple ledger instances.
- PAPER submission records an intent and never invokes the exchange.
- LIVE config fails closed without both explicit enablement and exact confirmation phrase.
- Signed private REST request contains the expected HMAC-SHA256 signature and API-key header; transport layer does not retry a write.
- Multi-pair coordinator routes an already-qualified active-universe signal through one global risk manager and rejects symbols outside the active universe.

## Not tested / no claim made

- No real Binance public/private network interaction was run as part of these tests.
- No TESTNET or LIVE order was submitted.
- No real partial-fill or Algo Order was exercised against Binance; behavior is covered only by code review/unit-level mocks where applicable.
- No continuous market-feed runtime or end-to-end SMC-to-order loop exists yet.
- No strategy profitability, win rate, expectancy, drawdown, slippage or fill quality is claimed.
- Windows 10 / Python 3.12.9 / 8 GB compatibility and performance are not yet verified.

## Conclusion

The v0.40.0 trading-side core passes the available automated regression suite. It is a development foundation for the full auto-trading runtime, not yet the complete unattended trading bot and not approved for LIVE operation.
