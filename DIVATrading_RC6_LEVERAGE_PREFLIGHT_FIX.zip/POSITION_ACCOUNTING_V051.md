# Aggregate Position Accounting — v0.51.0

## Objective

Represent multiple strategy signal lots under one exchange position identity without confusing the exchange's aggregated position amount with per-signal lifecycle quantities. The grouping key is `(symbol, positionSide)`; each signal remains an independently tracked allocation.

## Delivered

- `divatrading.execution.position_accounting.build_position_groups(rows)` builds deterministic group snapshots with total quantity, weighted-average entry, notional and the original lot list. Decimal arithmetic is used throughout.
- `PositionGroup.protection_allocations` exposes the intended per-signal quantity/SL/TP allocations. `validate_protection_coverage` verifies an externally supplied set of quantity-scoped protection quantities equals every signal lot.
- `allocate_close_fill` assigns a known client-order fill to its exact signal. FIFO fallback is explicit and stable by immutable lot-open time then signal ID; it is not a silent fallback for an unknown DIVA-owned order.
- The SQLite ledger records client-order ownership and immutable trade-fill evidence from `ORDER_TRADE_UPDATE` and `TRADE_LITE`. One `(symbol, trade ID)` can be recorded only once even when both event types report the same execution.
- If an internal `DIVA*` fill arrives before its REST ownership record, it is first stored as `UNATTRIBUTED` and new entries are halted. When the corresponding order/action ownership is committed, the fill record is backfilled to the correct signal. The safety halt is intentionally not cleared automatically.
- Existing SQLite databases receive an additive `managed_positions.opened_at_utc` migration. Existing rows are backfilled from their previous `updated_at_utc`; later updates do not rewrite the original lot-open time.
- `runtime-status` now reports aggregate position groups and fill attribution counts.

## Critical execution boundary

This release adds accounting and fill attribution, **not permission to execute multiple signals on the same exchange position side**. The current execution service still creates conditional protective orders with `closePosition=true`, and the lifecycle adapter verifies each signal against the full exchange-side quantity. The current supervisor therefore continues to refuse multiple managed signals for one `(symbol, positionSide)` and latches the entry halt.

Before same-side scale-in can be enabled, the execution layer must switch to quantity-scoped protection for every lot, validate exact step/minimum quantities, ensure STOP and TP coverage across all lots, cancel/resolve the sibling protective order after a fill, and reconcile the aggregate exchange position against the sum of allocations. The current execution service sends `closePosition=true`, which is close-all semantics and cannot express separate per-signal protective quantities. The migration to quantity-scoped protection must be implemented and validated against the exact `/fapi/v1/algoOrder` contract before same-side scale-in is enabled.

## Fill accounting semantics

`position_fill_allocations` is an immutable execution-evidence ledger. It does not directly mutate `managed_positions.quantity`; exchange-confirmed REST reconciliation and lifecycle confirmation remain authoritative for current position quantity. This avoids double-applying cumulative order fills or replaying duplicate User Data Stream updates. The next execution integration step must reconcile the immutable fill ledger with REST `userTrades`/order state and the current managed-lot balances before applying fill deltas.

## Verification boundary

Local tests cover aggregation, weighted entry, FIFO, exact-signal attribution, per-lot protection quantity validation, SQLite migration, fill deduplication, management-action attribution, unknown DIVA fill halt and late owner backfill. They do not constitute a live Binance integration test.
