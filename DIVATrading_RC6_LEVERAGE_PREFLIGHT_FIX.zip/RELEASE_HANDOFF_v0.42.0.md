# DIVATrading Release Handoff — v0.42.0

## Identity
- Release: `DIVATrading_BinanceBot_MultiPairProductionFeedGraph_0.42.0.zip`
- Base: v0.41.0
- Scope: public market-data feed graph for live multi-pair observation, read-only.
- Package version: 0.42.0

## What changed
Concrete per-symbol Binance public feed graph has been added and wired into the existing multi-pair runtime supervisor. It combines M1/M5/M15 Klines with REST bootstrap/recovery, Mark Price, Aggregate Trades with recovery/storage and Delta/CVD, depth with shared REST snapshot pacing and Futures book sequencing, absorption alignment, and validated strategy snapshots delivered into existing SMC V2 Stage 2–5.

The graph only emits complete, ready data views. It rejects unknown symbols without exact current exchange metadata. REST history and depth snapshot requests use shared pacing gates across workers. The default active-symbol cap is eight for the target 8 GB PC profile.

## Start command (after local installation)
AUTO:
```powershell
python -m divatrading init-db
python -m divatrading market-runtime --mode AUTO --max-symbols 8
```
MANUAL:
```powershell
python -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT,ETHUSDT,SOLUSDT --max-symbols 3
```
Windows helper: `RUN_MARKET_RUNTIME_WINDOWS.bat` (requires the project `.venv` created by `INSTALL_WINDOWS.bat`).

## Safety boundary
This is public-data and read-only. It does not place orders and does not make the project a complete auto-trading system yet. Continue v0.43 (signal qualification/trade plan), then v0.44 (risk/execution/position lifecycle), v0.45 (dashboard/Telegram/monitoring), and v0.46 (Windows deployment and complete feature integration). Do not enable unattended LIVE trading based on this release.

## Verification
See `TEST_REPORT_v0.42.0.md` and `CLEAN_EXTRACTION_TEST_REPORT_v0.42.0.md`. Test suite passed 735 tests in the working tree; additional exact-archive extraction results are recorded in the clean-extraction report.

## Next task
See `NEXT_TASK_v0.43.0.md`.
