# DIVATrading Release Handoff — v0.43.0

## Identity
- Release: `DIVATrading_BinanceBot_SMCV2SignalPlanner_0.43.0.zip`
- Base: v0.42.0 Production Multi-Pair Feed Graph
- Scope: SMC V2 candidate qualification, dynamic entry/SL/TP and Decimal risk-sized TradePlan output. No orders are submitted.
- Package version: 0.43.0

## Included
- The immutable `SMCV2EvidenceSnapshot` now carries the exact validated `ScalpingMarketDataView` from the same capture.
- New `SMCV2TradePlanner`, immutable candidate/evaluation/result models, configurable qualification and traceable parameter/reason output.
- Independent M1/M5 candidate evaluation; M15 remains advisory and cannot veto by default.
- Optional FVG, sweep, Delta/CVD, depth and absorption scoring/requirements.
- Separate LIMIT_RETRACEMENT midpoint and CONFIRMATION_MARKET closed-candle models.
- Dynamic OB-boundary SL, configured-R or confirmed structural TP, exact tick arithmetic and exchange entry/bracket metadata checks.
- `InstrumentSpec.max_notional` propagation and max-notional quantity capping in global risk sizing.
- `market-runtime` now emits candidate decision/plan JSON records to application logs; default `PAPER` reference equity is configurable and is not represented as actual account equity.
- Short-lived in-memory planning reservations and candidate signal de-duplication; these do not replace exchange portfolio reconciliation.

## Verification
- Full regression suite: 747 passed.
- `compileall`, package import, root CLI and `market-runtime --help`: PASS.
- Clean extraction test and extracted-tree full regression are recorded in `CLEAN_EXTRACTION_TEST_REPORT_v0.43.0.md`.
- No Binance private request or order was submitted.

## Known boundaries
- Not an autonomous order-placement release yet. v0.44 must integrate exchange-truth account state, User Data Stream, order/position lifecycle and recovery.
- Paper equity is a user-supplied reference value; it is not fetched from Binance.
- Candidate thresholds, confluence weights, RR and OB age remain provisional and configurable.
- Build runtime in this session: Linux x86_64 / Python 3.13.x. Target Windows 10 / Python 3.12.9 / 8 GB remains unverified on the user's PC.
