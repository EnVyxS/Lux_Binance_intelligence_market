# Test Report v0.49.0

## Automated tests

- Full regression suite: **834 passed**.
- Focused lifecycle execution + Mark Price supervisor suites: **37 passed**.
- `python -m compileall -q src`: **PASS**.
- `PYTHONPATH=src python -m divatrading --help`: **PASS**.
- `PYTHONPATH=src python -m divatrading account-runtime --help`: **PASS**.
- `PYTHONPATH=src python -m divatrading emergency-close --help`: **PASS**.
- Package version import: **0.49.0**.
- `python -m divatrading check`: expected environment rejection; container is Python 3.13.5 while project contract is exactly Python 3.12.9.

## Added and extended coverage

- Structural invalidation precedes partial TP / BE / trailing decisions.
- Mark Price supervisor processes isolated per-symbol events, checks freshness and cross-symbol contamination, restarts degraded feeds and halts entries on unsafe input.
- Structural exit dispatches full MARKET close and releases risk only after flat + linked order cleanup verification.
- Emergency close uses correct One-way/Hedge position parameters and requires an explicit reason; partial emergency fill keeps residual quantity, protective order and risk reservation.
- Duplicate managed signals on the same symbol/position side are refused; two-symbol worker execution is independently exercised.
- Runtime wiring launches the Mark Price supervisor alongside account event processing and reconciliation.
- Mark Price events can drive partial TP and trailing STOP replacement through the exchange adapter.
- A terminal partial TP fill records original quantity and cumulative fills; the next action requests only the unfilled portion of the original configured target. The target is aligned down to the exchange MARKET step once and persisted, avoiding repeated dust requests below `minQty`.
- Existing-position account observation may remain ready while new entries are halted only when REST reconciliation is discrepancy-free, fresh and event-watermark-consistent; mismatched accounts remain blocked.

## Environment and scope

- Linux container, Python 3.13.5.
- `pyproject.toml` intentionally retains `requires-python ==3.12.9`; no change was made to the target Python contract.
- All exchange behavior is exercised through local deterministic fakes/mocks. No actual Binance TESTNET/LIVE API request, User Data Stream connection, Mark Price WebSocket, order placement, cancel or fill was performed.
- Windows 10 / Python 3.12.9 / 8 GB target is not validated.
