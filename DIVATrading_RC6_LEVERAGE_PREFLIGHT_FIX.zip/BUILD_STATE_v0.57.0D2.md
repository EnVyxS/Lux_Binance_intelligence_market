# Build State — v0.57.0D2

- Release label: `v0.57.0D2 — Position-Aware Protective Recovery`
- Python package version: `0.57.0rc3` (PEP 440 prerelease identity)
- Baseline: v0.57.0D1 protective-order integrity hardening
- Project Python requirement: exactly `==3.12.9`
- Build/test host: Linux x86_64, Python 3.13.5, setuptools 82.0.1
- Windows target: Windows 10 x64 / Python 3.12.9; exact D2 package has not yet been validated on that target

## Implemented

1. Adds TESTNET-only opt-in `DIVA_ENABLE_PROTECTION_RECOVERY`, default `false` in both environment templates.
2. Adds fresh sequential reconciliation and connected User Data Stream gates for missing protection recovery.
3. Requires exact symbol, position side, managed-lot quantity, active risk reservation, order type, closing side, trigger, reduceOnly/closePosition, workingType and priceProtect identity.
4. Uses signed REST Query Algo Order as primary source evidence; `-2013` fallback is limited to exact durable ALGO_UPDATE evidence and hash-verified persisted source evidence during restart.
5. Defers triggered/filled/ambiguous Algo orders to existing fill reconciliation; no replacement is sent in those branches.
6. Uses one deterministic replacement action/client ID and a durable pre-POST marker; query-before-POST, one POST maximum, GET-after-POST verification, then final exchange quantity verification.
7. Handles the crash window after protection pointer persistence but before action confirmation without a second POST.
8. Processes one missing protection role per fresh reconciliation snapshot; account runtime does not release the entry halt.
9. Adds integration tests for account-runtime opt-in and snapshot deduplication.

## Build state

- Source compile: PASS
- Full regression on source tree: 972 passed
- Full regression on clean extraction: 972 passed
- Focused recovery + TESTNET-only config + account runtime tests: 19 passed
- Wheel: generated with `setuptools.build_meta.build_wheel`; pure Python wheel metadata records `Requires-Python: ==3.12.9` and version `0.57.0rc3`.
- CLI help: 4/4 PASS (`divatrading`, `auto-trade-runtime`, `testnet-preflight`, `testnet-order-test`)
- No real Binance Demo or LIVE order/Algo mutation was performed.

## Qualification boundary

The user previously validated v0.57.0C1 full regression on Windows 10 / Python 3.12.9 (952 passed), Demo preflight, and validation-only signed `/fapi/v1/order/test`. These are C1 results, not D2 Windows results. The exact D2 archive still requires Windows installation/regression qualification. Actual Stage C matching-engine entry/fill/protective-order cycle remains unconfirmed. D2 recovery remains disabled by default and must not be enabled for LIVE.
