@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
if not exist ".env" (
  echo ERROR: .env is missing. Run INSTALL_WINDOWS.bat to copy .env.example.
  exit /b 1
)
echo.
echo ================================================================
echo DIVATRADING RC6 - REAL BINANCE USD-M FUTURES / AUTO SCALPING
echo LIVE exchange, AUTO pair scan M1/M5, M15 soft context.
echo Default 1 managed position. LIVE ceiling 2. Default risk FIXED 0.20 USDT.
echo Default daily loss halt 1.00 USDT. Leverage AUTO via symbol bracket.
echo Live API key and secret must be set in local .env.
echo Telegram optional: requires separate bot token and numeric owner ID.
echo No DEMO or TESTNET required. Real losses including liquidation possible.
echo ================================================================
echo This command can SEND REAL ORDERS after entry readiness and risk checks.
echo No orders are created merely by installing or editing the .env file.
set /p "ACK=To START real-money autonomous trading, type exactly START LIVE TRADING : "
if not "%ACK%"=="START LIVE TRADING" (
  echo Operator did not approve. No order process launched.
  exit /b 2
)
.venv\Scripts\python.exe -m divatrading auto-trade-runtime ^
  --activate-live --mode AUTO --max-symbols 8 ^
  --setup-timeframes 1m,5m --entry-model LIMIT_RETRACEMENT ^
  --risk-per-trade-pct 0.25 --max-portfolio-risk-pct 20 ^
  --target-r-multiple 2.0 --min-signal-score 55
set "CODE=%errorlevel%"
echo LIVE runtime terminated. Exit code %CODE%.
echo IMPORTANT: check exchange positions AND orders in Binance before restarting.
exit /b %CODE%
