# REST User-Trades Backfill — v0.54.0

## Scope

This module recovers USDⓈ-M account fills missed during User Data Stream gaps. It merges REST `GET /fapi/v1/userTrades` evidence with `ORDER_TRADE_UPDATE` / `TRADE_LITE` using `(symbol, tradeId)` as the immutable identity.

## API constraints enforced

- `symbol` is mandatory and normalized to uppercase alphanumeric.
- `limit` is bounded to 1..1000.
- `fromId` is never combined with `startTime` or `endTime`.
- A time query must provide both bounds and spans no more than seven days.
- Initial historical recovery was originally implemented with a 180-day bound. Binance changed the USDⓈ-M `GET /fapi/v1/userTrades` historical query window to **3 months effective 2026-08-26**; v0.57.0 therefore enforces a 90-day bootstrap bound.
- Time windows are inclusive and adjacent windows start at `previous_end + 1`.
- A full page is recursively split by millisecond until it is no longer full. If one millisecond still exceeds the page cap, recovery fails closed instead of silently truncating.
- Request count is bounded per run and requests are paced by a configurable delay (default 150 ms, approximately 2,000 request-weight units/minute at weight 5 per symbol).

## Recovery modes

### Initial/bootstrap mode

Without a saved symbol watermark, the service scans the configured time range in windows no wider than seven days. The current default is the most recent 90 days under Binance retention effective 2026-08-26. Each returned page is merged transactionally into the fill ledger.

### Cursor mode

With a saved watermark and no explicit override range, the service starts at `last_trade_id + 1` using `fromId` only. Pages continue until a short or empty page is returned. This avoids mixing time and ID cursor parameters.

## Durable state

`trade_backfill_runs` records the bounded run, committed page count, received trade count, maximum trade ID/time and terminal status. `trade_backfill_watermarks` stores the last completed trade ID/time and completed-through timestamp per symbol.

Each page merge and run counters commit in one SQLite transaction. The per-symbol watermark advances only after all windows/pages complete. A failed run leaves the prior watermark unchanged; already committed fill rows are safe to replay because `(symbol, tradeId)` is the primary fill key.

## Fill merge and provenance

REST records are normalized into the same fill-ingestion path used by stream evidence. Ownership is resolved through the persisted matching-engine `exchange_order_id` link. REST and stream duplicates enrich the same fill record and set provenance to `REST+USER_STREAM`; they do not create a second fill application.

Quantity, price, exchange order ID and order-side contradictions for the same trade key raise an error and roll back the current page. Unknown trades remain external/unattributed rather than being assigned to a guessed signal. Unknown DIVA-owned stream fills retain the existing entry-halt policy.

## Account-runtime integration

In TESTNET/LIVE `account-runtime`, the reconciliation service invokes backfill for symbols represented by local trade intents or known fills. A temporary `TRADE_HISTORY_BACKFILL_IN_PROGRESS` entry halt is applied only if no prior operator/safety halt exists. The temporary halt is cleared only after backfill and the subsequent exchange reconciliation succeed without discrepancies. Backfill failure or account mismatch leaves entries halted. Existing manual/safety halt reasons are never cleared by this mechanism.

The backfill is throttled to one run per 60 seconds per reconciliation-service process, avoiding a userTrades call on every 10-second account snapshot.

## Limitations

- The endpoint is symbol-scoped; symbols with no local intent/fill evidence are not scanned.
- This is bounded REST history recovery, not an infinite-history archive. Current Binance USDⓈ-M documentation/change log states that the standard `userTrades` history query supports the most recent 3 months (effective 2026-08-26). Records older than that require Binance's asynchronous trade-history export process or an operator-supplied archive. Existing local ledger records remain retained independently of REST availability.
- No actual TESTNET/LIVE request was performed in this build. The signed client and reconciliation wiring are verified with mocked HTTP and local SQLite only.
- This does not enable same-side multi-lot execution or the autonomous SMC entry dispatcher.

## References

- Binance USDⓈ-M Futures General Info: https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/general-info
- Binance USDⓈ-M Futures Change Log (2026-08-26 history retention update): https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/change-log
