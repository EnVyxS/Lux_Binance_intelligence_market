# Next Task — After v0.57.0C1

1. Extract the C1 ZIP to a new folder on the project drive; retain the current working folder as rollback evidence.
2. Copy `.env` locally only; keep `DIVA_ENABLE_TESTNET_ORDERS=false`, `DIVA_ENABLE_TESTNET_STAGE_C=false`, `DIVA_ENABLE_TESTNET_ORDER_TEST=false`, and `DIVA_LIVE_TRADING_ENABLED=false`.
3. Run `INSTALL_WINDOWS.bat` and `TEST_WINDOWS.bat`; both route their temp work to `.diva_temp` on the project drive.
4. Verify `pip check`, `python -m divatrading auto-trade-runtime --help`, and read-only `testnet-preflight --symbols BTCUSDT`.
5. Review all preflight/account readiness evidence before preparing a supervised Stage C session.
6. Stage C requires both TESTNET order authorization flags and may submit an actual Demo order only after a qualified SMC signal. Run one symbol (BTCUSDT), MANUAL mode, one worker, <=0.10% risk per trade and <=0.25% portfolio risk, supervised.
7. Collect sanitized evidence for entry acknowledgement, User Data Stream fill, REST position reconciliation, STOP/TP Algo protection and lifecycle recovery. Do not advance to Stage D if any evidence is missing.
8. LIVE remains disabled and unauthorized.
