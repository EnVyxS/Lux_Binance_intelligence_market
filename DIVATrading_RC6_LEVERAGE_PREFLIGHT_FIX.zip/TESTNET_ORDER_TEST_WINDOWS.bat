@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Project virtual environment is missing. Run INSTALL_WINDOWS.bat first.
  exit /b 2
)
".venv\Scripts\python.exe" -m divatrading testnet-order-test %*
exit /b %ERRORLEVEL%
