# Changelog v0.55.0 — True Multi-Lot Position Supervisor

## Added
- Multiple open signal lots are accepted by the managed-position supervisor for the same `(symbol, positionSide)` group.
- Each Mark Price event is evaluated independently for every lot on that symbol; each lot retains independent lifecycle state and action identity.
- Aggregate local quantity is checked against exchange position quantity before any lot-level close/protection adjustment.
- Partial TP and market exits reduce only the attributed signal lot and resize only that lot's protective orders.
- Protective Algo full-fill can finalize its own lot while sibling lots remain open; Algo partial-fill reconciles the aggregate residual before resizing the affected lot.
- Exchange-confirmed flat aggregate groups can be finalized after owned protective orders are canceled and verified terminal.
- Reconciliation verifies STOP/TP ownership and quantity separately for every same-side signal allocation.
- Group-level action serialization prevents concurrent reductions/protection changes against stale aggregate snapshots.
- Coordinator and ExecutionService admission gates block same-side TESTNET/LIVE scale-in until the exchange behavior is TESTNET-qualified. One-way `BOTH` blocks another position entry on the same symbol. PAPER multi-lot simulation remains available.

## Validation
- Full source regression: 891 passed.
- Full clean-extraction regression: 891 passed. ZIP integrity, compileall, CLI help and package version 0.55.0: PASS.
- No authenticated Binance TESTNET/LIVE API sessions or orders were used.
- Runtime build: Linux / Python 3.13.5. Project pin remains Python `==3.12.9`; Windows 10 target validation is pending.
