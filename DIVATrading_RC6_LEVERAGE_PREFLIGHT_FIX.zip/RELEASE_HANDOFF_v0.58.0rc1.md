# Release Handoff — DIVATrading v0.58.0rc1

## Baseline and build
- Baseline: v0.57.0D4 (`0.57.0rc5`), exact D4 archive restored from the Library.
- Package version: `0.58.0rc1`.
- Python pin remains `==3.12.9`.
- Source: DIVATrading Binance USDⓈ-M Futures multi-symbol bot.

## Implemented in this checkpoint
- Persistent SQLite operator-control state and audit events.
- Fixed-USDT and percentage per-trade risk settings; runtime refresh before each candidate.
- Telegram long-polling control process with owner ID validation and token redaction.
- Daily equity-loss and drawdown entry gates.
- Loss-streak configuration is intentionally fail-closed until a reconciled closed-trade streak ledger exists.
- BOT_ONLY account gate checks unmanaged positions, quantity mismatch on netted symbol/side exposure, missing managed positions, and unmanaged standard/Algo orders.
- Deterministic leverage feasibility primitive using caller-supplied verified liquidation-buffer estimates.

## Commands
Run Telegram control process from the project root:

```powershell
.venv\Scripts\python.exe -m divatrading telegram-control
```

Required local `.env` values:

```dotenv
TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN
TELEGRAM_OWNER_ID=YOUR_NUMERIC_TELEGRAM_USER_ID
```

Telegram examples:

```text
/risk fixed 0.20
/risk percent 0.10
/maxloss daily 1
/maxloss daily percent 2
/maxloss streak 3
/maxloss drawdown percent 5
/leverage auto 20
/margin isolated
/pause
/resume
/kill
/status
```

Use the actual numeric limits approved by the operator. Values above are examples, not recommended defaults. Risk remains `UNCONFIGURED` until explicitly set. The `auto` leverage policy and margin preference are persisted, but not yet connected to a fully qualified live exchange bracket/margin-mode adapter.

## Safety behavior
- `BOT_ONLY`: unknown positions/orders or quantity mismatch halt new entries. The bot never auto-closes unknown/manual exposure.
- `/pause` and `/kill` block new entries; existing position supervision continues. `/kill` is latched until `/resume`.
- Daily equity loss is based on a persisted day-start equity anchor in `Asia/Jakarta`; drawdown uses persisted high-watermark. Equity changes include realized/unrealized PnL and exchange-charged costs reflected in equity. Deposits/withdrawals may distort the measure.
- Configured loss streak currently blocks new entries because exact streak accounting is not yet qualified.
- Never send API credentials, Telegram token, `.env`, signatures, or signed URLs in chat.

## Release artifact
- ZIP: `DIVATrading_BinanceBot_PersistentOperatorControlPlane_0.58.0rc1.zip`
- SHA-256: see adjacent `.zip.sha256` sidecar and final assistant handoff.
- Clean extraction: 995 passed; ZIP CRC and source manifest verification passed.

## LIVE status — NOT READY / NOT ENABLED
The current autonomous runtime explicitly rejects `ExecutionMode.LIVE`. This is intentional. Missing gates include:
1. Live account read-only preflight on the dedicated account and verification of account/position mode, balances, filters, leverage brackets, open orders and Algo orders.
2. End-to-end runtime integration for dynamic leverage and margin mode, using current symbol-specific bracket data and liquidation calculations.
3. Dedicated, exchange-reconciled consecutive-loss accounting and robust day boundary/adjustment handling.
4. Exact D4/v0.58 target-platform qualification on Windows 10 / Python 3.12.9.
5. Supervised exchange validation of entry → fill → paired STOP/TP → partial/full exit → stream-gap/restart → flat reconciliation.
6. Explicit user authorization for LIVE after the above checks. No credentials are available in this build environment.

Do not set `DIVA_LIVE_TRADING_ENABLED=true` or change the runtime guard to bypass these gates. This release candidate is not a production LIVE release.
