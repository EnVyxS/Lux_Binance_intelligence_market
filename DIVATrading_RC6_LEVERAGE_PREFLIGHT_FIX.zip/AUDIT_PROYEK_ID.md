> Arsip historis audit **v0.59.0rc2**. Status terbaru dan perbaikan lanjutan v0.59.0rc3: [AUDIT_RC3_STATUS_DAN_HANDOFF.md](AUDIT_RC3_STATUS_DAN_HANDOFF.md).

# Audit DIVATrading — 15 November 2026

## Kesimpulan

Versi masukan: 0.59.0rc1. Kandidat hasil audit: 0.59.0rc2.
**BELUM SIAP LIVE. Target modul final untuk akun real belum tercapai.**
Audit mencakup roadmap, master specification, arsitektur, handoff terbaru, konfigurasi, jalur utama strategi/risk/entry/account runtime/position supervisor, dan suite regresi. Ini bukan klaim seluruh baris kode atau seluruh kemungkinan kegagalan sudah diverifikasi.

Proyek adalah bot Binance USDⓈ-M USDT perpetual, bukan Spot atau MT5. Sasaran deployment: Windows 10, Python tepat 3.12.9 x64, RAM 8 GB. Fondasi yang ada dipertahankan. SMC V2 adalah strategi aktif; Pine legacy merupakan referensi terpisah.

## Peta status berdasarkan kode

| Komponen | Sudah ada | Batas yang masih berlaku |
|---|---|---|
| Data pasar | Metadata, kline M1/M5/M15, mark price, aggregate trades, depth, recovery, Delta/CVD, absorption | Data publik berhasil diakses melalui plugin; seluruh feed bot belum diuji end-to-end dalam sesi ini |
| SMC V2 | Struktur terkonfirmasi, pembentukan/lifecycle OB, FVG, sweep, qualification/ranking; M1/M5 independen, M15 advisory | Threshold/score belum membuktikan edge; bukan probabilitas win terkalibrasi |
| Planner | LIMIT retracement atau MARKET confirmation; SL melewati OB; target pivot atau fallback R | SL hanya buffer tick; MARKET memakai mark sebagai referensi; ATR/spread buffer, bid/ask execution quote, minimum net-RR dan target opposing OB belum lengkap |
| Risk | Decimal sizing, portfolio reservations, account fee/bracket/margin, fee/slippage/funding reserve | Estimasi bukan jaminan loss maksimum; belum mengikat kembali seluruh risiko pada fill aktual dan validasi live |
| Eksekusi | Signed REST, deterministic client ID, ledger, partial-fill handling, query/verify STOP dan TP | LIMIT memakai GTC; maker-attempt → bounded IOC/price cap yang disebut master spec belum tersedia |
| Posisi | Per-lot accounting, partial TP, BE setelah fill, trailing berbasis R, structural/emergency exit primitives | Supervisor memanggil engine dengan mark price; belum ada integrasi penuh early exit berbasis delta/absorption/opposite setup atau TP extension |
| Recovery | Private stream, REST userTrades/income backfill, trigger reconciliation, reconnect/restart state | Sebagian recovery dibatasi TESTNET; belum terbukti pada matching engine akun pengguna |
| Kontrol | Telegram owner commands, pause/kill, risiko/maxloss/leverage/margin, offset persisten | Kill memblokir entry baru, bukan flatten semua posisi; UI inline lengkap/redeem/dashboard masih cakupan rancangan |
| Kronos | Shadow forecast, installer dan evaluasi forecast | Bukan pengambil keputusan trade; model tidak disertakan dan keuntungan tidak terbukti |
| Replay | Replay kronologis evidence, quality/convergence/intake tools | Bukan backtest PnL realistis lengkap; PAPER fill deterministik tidak mencakup queue/spread/latency |
| Autonomous runtime | SMC → dispatcher → risk → execution; PAPER dan jalur TESTNET terhubung | LIVE ditolak eksplisit; TESTNET commissioning dibatasi satu simbol manual |
| Deployment | Installer/runner/test Windows | Arsip hasil audit belum dijalankan pada Windows pengguna |

## Temuan penting

1. **Bug entry cancel race — diperbaiki.** `execution/service.py` sebelumnya membaca executedQty sebelum cancel lalu memasang proteksi dengan angka lama. Jika 0.04 terisi dan bertambah menjadi 0.08 ketika cancel, proteksi tetap 0.04. Ini terjadi pada submit langsung dan reconcile pending. Perbaikan melakukan GET ulang dengan client ID asli, memeriksa identitas/status terminal/jumlah monoton dan batas order/harga rata-rata valid, lalu memakai jumlah serta harga final. Kondisi ambigu menghentikan entry dan tidak diklaim PROTECTED. Tidak ada retry POST entry.
2. **Gate TESTNET versus kontrol dinamis — belum selesai.** CLI mengecek batas risiko argumen startup, tetapi risk tersimpan/Telegram kemudian menggantikan konfigurasi tersebut. Batas commissioning perlu ditegakkan pada konfigurasi efektif dan sebelum dispatch, termasuk fixed USDT setelah diketahui equity.
3. **Supervisi tugas akun — belum selesai.** Startup memeriksa account_task; sesudah siap, run_integrated menunggu market_runtime tanpa monitoring account_task yang setara. Freshness gate membantu menutup entry kemudian, tetapi penghentian supervisor harus segera terdeteksi dan diaudit.
4. **Sumber harga TESTNET — perlu keputusan eksplisit.** Autonomous public market client memakai default mainnet, sedangkan private execution memakai Demo. Jangan menganggapnya bukti fill/price parity Demo; sinkronisasi sumber data harus ditentukan dan diuji.
5. **Risiko setelah fill — belum lengkap.** Reservation awal berasal dari harga rencana. Perubahan average fill harus diikat ke actual stop-risk dan kebijakan overshoot; perbaikan cancel race ini tidak menyelesaikan seluruh persoalan slippage.
6. **Dokumentasi lama tidak boleh dipakai sebagai status terkini.** MASTER_SPEC/ARCHITECTURE/BUILD_STATE memuat checkpoint lama yang menyebut komponen belum ada padahal sudah diimplementasikan. Header rujukan audit ditambahkan; sejarah tidak dihapus.
7. **Belum ada bukti profitabilitas.** Banyak unit test bukan bukti PF/WR/expectancy positif. Kalibrasi, walk-forward/OOS, sensitivitas biaya, dan historical PnL tetap terpisah dan belum selesai.

## Bukti pengujian

- Lima skenario awal reproduksi bug gagal pada source asli, lalu lulus setelah patch.
- Cakupan diperluas menjadi delapan skenario: submit/recovery, cancel berakhir partial-terminal/full fill, status belum terminal, cumulative fill mundur, NaN, dan melebihi quantity order.
- Regresi penuh kandidat: lihat `AUDIT_TEST_RESULT.txt` (1.046 tests).
- Host pengujian: Linux, Python 3.12.14; ini bukan Windows 10/Python 3.12.9 qualification.
- Percobaan baseline awal: 1.030 pass/8 fail karena lingkungan SOCKS membutuhkan socksio. Setelah dependency lingkungan disediakan, seluruh suite lama dan baru lulus. Ini bukan delapan bug produk.
- pytest 9.2.0, pytest-asyncio 1.5.0, httpx 0.28.1, websockets 16.0, jsonschema 4.26.0. Dependency lain memakai runtime host; bukan instalasi identik Windows.
- Plugin Binance berhasil mengembalikan public exchangeInfo. Plugin hanya read-only/public: tidak mengakses saldo, API key, private stream, atau menempatkan order.
- Tidak ada order TESTNET/LIVE, perubahan leverage/margin akun, atau pesan Telegram dikirim dalam sesi ini.
- Tidak ada API secret dalam paket.

Referensi API resmi untuk query status order: https://developers.binance.me/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/trade (Query Order). Pilihan query ulang setelah cancel adalah keputusan implementasi untuk mencegah stale fill quantity.

## Urutan menuju hasil akhir live

1. Selesaikan effective risk/position caps, supervisi semua task kritis, identitas environment/database/account, dan post-fill risk reconciliation.
2. Lengkapi atau secara eksplisit persempit kontrak strategi/eksekusi: executable quote, spread/slippage cap, entry expiration/cancel ketika setup invalid, stop buffer volatilitas, target/net-RR, dan hubungan lifecycle dengan SMC state.
3. Uji fault injection terintegrasi: fill/cancel race, ACK hilang, private stream mati, proteksi ditolak, restart saat posisi terbuka, duplicate replay, pause/kill, fee/funding dan loss limits.
4. Jalankan exact package di Windows pengguna: instalasi, semua tes, startup/shutdown, SQLite backup/restart. Jangan hapus ledger akun aktif.
5. Read-only preflight akun Binance pengguna dari PC pengguna. Simpan API key/secret hanya pada .env lokal; jangan kirim ke chat. Diperlukan hasil pemeriksaan akun, bukan kredensial.
6. Controlled exchange acceptance satu simbol: entry → fill → kedua proteksi → partial exit → final flat → reconnect/restart. Kode mock tidak menggantikannya.
7. Setelah gap kode dan bukti exchange selesai, implementasikan aktivasi LIVE lokal dengan batas commissioning yang benar-benar enforced. Baru kemudian paket dapat disebut modul live; bukan hanya menghapus hard gate.

## Langkah lokal yang sudah bisa dilakukan

Jalankan INSTALL_WINDOWS.bat lalu TEST_WINDOWS.bat. Untuk pemeriksaan read-only, gunakan .env lokal dengan DIVA_EXECUTION_MODE=LIVE, DIVA_LIVE_TRADING_ENABLED=false, DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true, dan kredensial milik akun yang dituju. Dari folder proyek:

```powershell
.\.venv\Scripts\python.exe -m divatrading live-read-only-preflight --symbols BTCUSDT
```

Perintah ini tidak mengaktifkan trading. BTCUSDT hanya contoh simbol pemeriksaan. Kembalikan konfigurasi PAPER untuk menjalankan runtime PAPER. Hasil tes/preflight yang sudah disamarkan dapat digunakan untuk langkah selanjutnya. Saldo, risk budget, account mode, dan simbol commissioning pengguna belum ditetapkan dalam sesi ini.
