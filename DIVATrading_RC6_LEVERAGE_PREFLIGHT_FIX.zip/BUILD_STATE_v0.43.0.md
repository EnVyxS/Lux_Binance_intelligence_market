# Build State — v0.43.0

- Package: `0.43.0`
- Base release: `0.42.0`
- Product target: fully automated Binance USDⓈ-M Futures multi-pair bot
- Current delivery: SMC V2 signal qualification and dynamic trade planning
- Implemented: see `docs/SMC_V2_SIGNAL_PLANNER_V043.md`
- Existing Stage 2–5 strategy engines: unchanged
- Current runtime: public multi-pair market feeds → same-capture SMC Stage 2–5 → candidate evaluation → QualifiedSignal → global Decimal risk sizing → TradePlan/log output
- Order submission in v0.43: disabled; no private API calls are made by market-runtime
- Default entry planner: LIMIT_RETRACEMENT
- Alternative: CONFIRMATION_MARKET
- Default PAPER reference equity: 1000 USDT (CLI parameter; not an account balance)
- Default risk per trade: 0.25%; portfolio open-risk planning cap: 1.00%; leverage: 3x; symbol notional cap: 20% equity × leverage; max planned positions: 5
- Planning reservations: in-memory, 60 seconds; exchange-truth portfolio reconciliation is next delivery
- Regression: 747 passed
- Clean extraction and isolated test results: `CLEAN_EXTRACTION_TEST_REPORT_v0.43.0.md`
- Build environment: Linux x86_64 / Python 3.13.x
- Target: Windows 10 / Python 3.12.9 / 8GB, not yet verified
- Next: `NEXT_TASK_v0.44.0.md`
