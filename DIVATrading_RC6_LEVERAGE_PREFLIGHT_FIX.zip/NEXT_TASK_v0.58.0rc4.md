# Next Task — After v0.58.0rc4

1. Integrate `assess_margin_feasibility` into the actual risk-sizing/dispatcher path using fresh account available margin, typed symbol brackets, commission rates, and bounded slippage/funding reserves. Quantity must be computed from risk first and never inflated to meet minNotional.
2. Feed completed multi-lot lifecycle close events into `CompletedTradeRiskLedger` exactly once; include realized PnL, all commissions and funding allocations. Backfill/reconcile using `/fapi/v1/userTrades` and income history after reconnect/restart. Keep entries blocked while incomplete.
3. Replace equity-delta daily PnL with reconciled realized PnL + commission + funding, and maintain Jakarta day-start equity anchors adjusted for deposits/withdrawals/transfers.
4. Connect persisted Telegram risk/maxloss/leverage/margin/pause/kill controls to live worker refresh. Pause/kill blocks new entries while position supervision continues.
5. Validate symbolConfig parsing against a dedicated Binance Futures account; do not write margin/leverage settings in this phase.
6. Clean extraction regression, wheel build, Windows 10 / Python 3.12.9 qualification.
7. Only after all above: supervised TESTNET lifecycle acceptance; then separately review LIVE acceptance. No unattended multi-pair LIVE rollout before evidence exists.
