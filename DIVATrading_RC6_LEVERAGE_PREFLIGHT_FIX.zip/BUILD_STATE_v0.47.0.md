# Build State v0.47.0

- Baseline: v0.46.0 User Data Stream and Account Reconciliation.
- Added `PositionLifecycleEngine` and typed state/action/decision models.
- Added SQLite `position_management_state` (versioned CAS) and `position_management_actions` (idempotent claim/status) tables.
- Added lifecycle tests for LONG/SHORT, 1R partial TP, confirmed-fill-only BE, trailing watermark, monotonic stops, deterministic IDs, validation, state persistence and action idempotency.
- Full regression: 797 passed.
- Compileall and CLI help are required in final clean-extraction verification.
- No private Binance API calls, WebSocket sessions, or exchange orders were used.
- Not yet implemented: Binance partial close / algo stop replacement adapter, fill-confirmed lifecycle reducer, automated verified-flat reservation release, emergency exit workflow, Windows target validation.
