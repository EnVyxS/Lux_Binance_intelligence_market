# DIVATrading v0.58.0rc3 — LIVE Read-Only Account Feasibility

- Added explicitly opted-in `live-read-only-preflight` CLI command.
- Pins requests to official `https://fapi.binance.com`; endpoint mismatch blocks before network access.
- Checks signed account access, server time, account trading configuration, single-asset mode, position mode, available USDT, selected active USDT perpetual symbols, positions, standard orders, Algo orders, and account-specific leverage brackets.
- Added read-only Binance `leverageBracket` and `commissionRate` REST methods.
- Any active position or open order blocks initial clean-account onboarding. No external exposure is auto-closed.
- The command requires `DIVA_EXECUTION_MODE=LIVE`, `DIVA_LIVE_TRADING_ENABLED=false`, and explicit `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true`.
- This release does not submit orders, change leverage, change margin mode, or activate LIVE trading.
