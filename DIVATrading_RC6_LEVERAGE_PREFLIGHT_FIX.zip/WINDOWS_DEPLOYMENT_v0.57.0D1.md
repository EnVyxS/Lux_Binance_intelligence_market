# Windows Deployment Notes — v0.57.0D1

Target runtime remains Windows 10 64-bit with Python 3.12.9 64-bit. Keep the current C1 folder as rollback and extract D1 into a new project folder. Copy `.env` locally only, keep all order permissions disabled, run `INSTALL_WINDOWS.bat`, `pip check`, `TEST_WINDOWS.bat`, CLI help and read-only Demo preflight before any runtime. Project-drive `.diva_temp` is used by installer/test launcher to avoid relying on system drive temporary storage.

D1 tightens STOP/TP exchange-response verification. It does not authorize actual Demo entry or LIVE. Do not enable Stage C until a separately supervised Demo qualification has demonstrated entry, fill, current position, both protective Algo orders and recovery.
