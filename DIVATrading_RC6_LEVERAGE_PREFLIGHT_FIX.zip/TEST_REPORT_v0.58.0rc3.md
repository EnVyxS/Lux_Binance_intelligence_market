# Test Report — v0.58.0rc3

## Targeted tests
`tests/test_live_read_only_preflight.py`, `tests/test_testnet_preflight_cli.py`, `tests/test_binance_client.py`, `tests/test_release_metadata.py`, `tests/test_config.py`: **23 passed**.

## Static/runtime checks
- `python -m compileall -q src tests`: PASS.
- `python -m divatrading live-read-only-preflight --help`: PASS.
- Parser confirms read-only command and `--symbols` option.

## Full regression limitation
1,018 tests were collected. Partitioned execution confirmed multiple chunks passed, but the complete suite did not finish within the available build execution window because several existing lifecycle/strategy test batches ran unusually long. Therefore this release does **not** claim a full 1,018-test pass. Re-run `TEST_WINDOWS.bat` on the target Windows/Python environment before operational use.

## Exchange validation
No real Binance account was accessed. No orders, leverage changes, margin changes, cancellations, or other account mutations were performed.
