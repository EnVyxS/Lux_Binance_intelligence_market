# Test Report v0.45.0

## Results

- Full pytest suite: **762 passed**.
- New risk-reservation tests cover exact Decimal portfolio and symbol-notional cap arithmetic, release, duplicate active/released signal handling, max-position admission, invalid numeric input rejection, and concurrent reservations through independent ledger instances.
- Multi-pair coordinator regressions verify PAPER route releases the reservation, still sends no exchange order, blocks denied reservations and blocks duplicate active reservations pending reconciliation.
- TESTNET mock-client tests verify execution without a matching active reservation, or with a risk-mismatched reservation, fails before intent claim/network access.
- Python `compileall`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.

## Environment and exclusions

- Runtime: Linux x86_64 / Python 3.13.5.
- `ruff` was not installed in the environment; lint was not run.
- No Windows/Python 3.12.9 execution test.
- No Binance private API connection, TESTNET order or LIVE order was performed.
- Additional cross-process smoke test: eight independent worker processes shared one SQLite ledger; exactly three 30-USDT reservations were admitted under a 100-USDT cap (90 USDT total).
- Tests do not simulate manual orders or independent bots outside this ledger.
