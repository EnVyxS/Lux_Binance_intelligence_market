# Test Report — v0.53.0

## Environment

- Build OS: Linux.
- Python: 3.13.5 (the project target remains pinned to Python 3.12.9).
- Test runner: pytest.
- Exchange interaction: mocked clients only; local SQLite.

## Results

- Full working-tree regression: **863 passed in 14.36s**.
- Focused lifecycle execution + User Data Stream tests: **64 passed in 3.96s**.
- `python -m compileall -q src`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -c 'import divatrading; print(divatrading.__version__)'`: `0.53.0` after version bump.

## New coverage

- Protective conditional Algo trigger with partial execution in One-way and Hedge Mode.
- `actualOrderId` mapping to standard matching-engine order and exchange-order ownership links.
- Cancellation of active matching-engine remainder and terminal-state re-query.
- Exact REST residual matching and fail-closed mismatch behavior.
- Residual quantity-scoped STOP/TP replacement, verification-before-sibling-cancel and duplicate-event idempotency.
- Stream fill attribution by client ID and exchange order ID, late ownership backfill, TRADE_LITE enrichment, trade-ID deduplication and restart projection rebuild.
- Per-signal Decimal fill application, weighted entry, close/open limits, fees grouped by asset, USDT realized PnL and SQLite migration from the prior fill-allocation schema.

## Not tested

- Actual Binance TESTNET/LIVE account, REST, WebSocket or order behavior.
- Actual exchange fills, latency, rate limits, reconnect windows or production Algo-order edge cases.
- Windows 10 / Python 3.12.9 deployment or 8 GB resource ceiling.
- REST `userTrades` historical backfill, which is not implemented in this release.

The 863 tests are software regression evidence, not exchange certification or a profitability claim.
