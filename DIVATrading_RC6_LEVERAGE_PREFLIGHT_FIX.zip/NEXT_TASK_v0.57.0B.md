# Next Task — v0.57.0C: Controlled Demo Entry & Fill Confirmation

## Entry criteria

- v0.57.0B release extracted on Windows target.
- Python 3.12.9 and dependencies installed.
- New rotated Demo credentials stored locally in `.env` only.
- Stage A preflight returns `READY_FOR_TEST_ORDER_VALIDATION`.
- Stage B signed `/fapi/v1/order/test` returns `TEST_ORDER_ACCEPTED`.
- `DIVA_ENABLE_TESTNET_ORDERS=false` remains the default until the separate Stage C authorization is designed and explicitly opted into.

## Scope

1. Define a separate Stage C local opt-in and an explicit operator confirmation string for actual Demo order placement.
2. Enforce exact exchange filters, current account position mode, account cleanliness, fresh balance and conservative quantity caps.
3. Use deterministic client order IDs and durable intent state; never blindly retry an ambiguous POST.
4. Place one small isolated Demo entry using `/fapi/v1/order` only after all gates pass.
5. Confirm the exchange order ID/status and actual execution quantity from REST/User Data Stream; reconcile to exchange truth.
6. Fail closed on partial, rejected, unknown, duplicate, or mismatched order state.
7. Do not place Algo protection or enable same-side multi-lot scale-in in Stage C; that remains Stage D/E.

## Safety

- PAPER remains default.
- Demo only; no LIVE keys, host, or fallback.
- Actual order placement must remain unavailable without explicit Stage C authorization.
