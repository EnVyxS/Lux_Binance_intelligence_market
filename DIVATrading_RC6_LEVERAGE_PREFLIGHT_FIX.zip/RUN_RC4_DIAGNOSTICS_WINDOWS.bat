@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
if not exist "logs" mkdir "logs"
REM No live orders and no authenticated exchange calls are performed.
.venv\Scripts\python.exe tools\rc4_acceptance.py --output logs\rc4_local_acceptance.json
if errorlevel 1 (
  echo Local verification incomplete. Review logs\rc4_local_acceptance.json.
  exit /b 1
)
echo Offline acceptance only. Do not activate LIVE based solely on this report.
exit /b 0
