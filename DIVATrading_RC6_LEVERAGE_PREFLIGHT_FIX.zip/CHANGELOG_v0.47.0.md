# v0.47.0 — Managed Position Lifecycle Foundation (2026-11-13)

- Adds deterministic Decimal-based LONG/SHORT lifecycle engine: partial TP at configurable R, breakeven proposal after confirmed partial fill, and favorable-excursion trailing stop proposals.
- Adds stable management action IDs; stop proposals are monotonic and closed positions do not emit actions.
- Adds durable SQLite lifecycle state with compare-and-swap versions and idempotent action claims/status updates for restart recovery.
- Adds 18 focused lifecycle and persistence tests. Full regression: 797 passed.
- Important boundary: no Binance partial-close or stop-modification POST is issued by this release. Exchange adapter, fill confirmation, verified-flat release and full exit/recovery orchestration remain next tasks.
- No Binance TESTNET/LIVE request or order used. Windows target not tested.
