# Release Handoff — DIVATrading Binance Bot v0.52.0

## Baseline and objective

Continues v0.51.0. Objective: use per-signal quantity-scoped protective Algo orders and keep the remaining STOP/TP sizes synchronized after confirmed partial exits, without enabling unsafe same-side scale-in.

## Delivered

1. Initial STOP_MARKET and TAKE_PROFIT_MARKET protection is created with explicit fill quantity; no `closePosition=true` is combined with `quantity`.
2. One-way Mode uses `reduceOnly=true`; Hedge Mode uses explicit `positionSide` and omits `reduceOnly`.
3. Reconciliation verifies each managed signal lot's exact STOP/TP client IDs, order types, direction, positionSide, quantity and mode flags.
4. Partial TP and partial structural/emergency market exits update the local lot only after REST order/position confirmation, then start a deterministic paired protection-resize action.
5. Replacement STOP and TP orders must both be REST-verified active before any old protection is cancelled. Old-order cancellation is identity-checked and recoverable.
6. Deterministic IDs and durable action payloads support restart query-first recovery without blind resubmission.
7. Lifecycle tests now assert repeated resize idempotency, residual quantity correctness and both One-way/Hedge Mode parameter rules.

## Verification

- Baseline before changes: 850 passed.
- Final full regression: 855 passed.
- Focused lifecycle / User Data Stream / supervisor tests: 64 passed.
- Compileall: PASS.
- Clean-extraction full test suite, CLI and archive verification: see `CLEAN_EXTRACTION_TEST_REPORT_v0.52.0.md`.

## Safety boundary

- Same-side multi-signal execution remains disabled. Multi-lot fill allocation and the supervisor must be completed before scale-in.
- A protective Algo trigger that leaves residual position quantity is still a safety-halt/reconciliation case; automated partial-trigger fill resizing is not certified in this release.
- The SMC TradePlan-to-entry dispatcher is not yet fully wired as a continuous autonomous order path.
- PAPER remains default. No Binance TESTNET/LIVE API call or order was made. Windows 10 / Python 3.12.9 was not tested in this Linux / Python 3.13.5 build environment.
