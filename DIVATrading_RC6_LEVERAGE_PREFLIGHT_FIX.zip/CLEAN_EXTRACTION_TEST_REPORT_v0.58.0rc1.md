# Clean Extraction Test Report — v0.58.0rc1

- Archive: `DIVATrading_BinanceBot_PersistentOperatorControlPlane_0.58.0rc1.zip`.
- ZIP integrity: CRC test passed.
- Archive members: 417.
- Source manifest entries: 416; all paths present and every size/SHA-256 matched.
- Clean extraction regression: **995 passed**.
- Compileall: passed.
- CLI root help: passed.
- Telegram control help: passed.
- Autonomous runtime help: passed.
- No `.env` or credential-bearing local configuration included.
- LIVE routing remains disabled.
