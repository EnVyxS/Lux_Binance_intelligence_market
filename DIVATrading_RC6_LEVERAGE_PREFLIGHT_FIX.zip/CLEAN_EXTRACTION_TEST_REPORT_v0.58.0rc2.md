# Clean Extraction Test Report — v0.58.0rc2

## Procedure

1. Create the release ZIP from the source tree using the release exclusion rules.
2. Extract the ZIP into a new empty directory, without reusing the source workspace or pre-existing virtual environment.
3. Verify ZIP CRC and every file hash listed in `SOURCE_MANIFEST_v0.58.0rc2.json`.
4. Run the full test suite, compileall, CLI help and import/version checks from the extracted tree.

## Results

- ZIP CRC: PASS.
- Source-manifest SHA-256 checks: PASS for every listed packaged file.
- Full clean-extraction regression: **1,013 passed**.
- `compileall`: PASS.
- CLI root help and Kronos/Signal Center subcommand help: PASS.
- Package/new-module imports and `0.58.0rc2` version metadata: PASS.
- No `.env`, `.venv`, local database, logs, `.kronos/` model weights, cache or build artifacts are packaged.

## Environment and boundary

Clean extraction was tested on Linux x86_64 / Python 3.13.5 using the build environment's test dependencies. This is not a substitute for the required user-side Windows 10 x64 / Python 3.12.9 install and regression. The real Kronos model was not downloaded or inferred; Telegram and exchange access were mocked or not invoked.
