# Changelog v0.41.0

- Added continuous multi-pair live market runtime supervisor.
- Added periodic ExchangeInfo/24h ticker universe refresh.
- Added dynamic symbol worker lifecycle and failure isolation.
- Added validated feed-to-SMC V2 pipeline handoff.
- Added worker status/capture telemetry and bounded runtime configuration.
- Updated package and HTTP User-Agent version to 0.41.0.
- Read-only; no order execution changes.
