# Next Task — After v0.57.0D2

1. Stage D3: extend triggered Algo fill/residual-quantity qualification around `actualOrderId`, `executedQty`, matching-engine order status and REST position snapshots. D2 deliberately defers triggered/part-filled orders to the existing fill reducer and never replaces them.
2. Test STOP trigger with zero fill, partial fill, full fill, canceled unfilled remainder, residual quantity, late/out-of-order `ALGO_UPDATE`, and duplicate/restart delivery.
3. Preserve the rule that both residual STOP/TP orders are verified for exact quantity/trigger/side before any old sibling protection is canceled.
4. Test One-way and Hedge Mode, multi-lot same-side aggregate accounting, stream disconnect during trigger, and REST backfill after stream gap.
5. Keep automatic D2 recovery disabled by default. Enable only on explicitly authorized TESTNET after operator has a fresh sequential account reconciliation; never enable this feature in LIVE.
6. Actual C1 Stage C entry/fill/protection evidence remains deferred. Before expanding symbols or same-side scale-in, complete a supervised single-pair Demo cycle and D3 qualification.
7. LIVE remains disabled and unauthorized.
