from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.core.database import Database
from divatrading.market_data.klines import Kline
from divatrading.signals.telegram import (
    SignalPublicationStore, SignalTelegramPublisher, TelegramSignalError,
    render_signal_chart,
)
from divatrading.trading.models import QualifiedSignal


def _candles(symbol="BTCUSDT", count=80):
    start = 1_800_000_000_000
    interval = 300_000
    output = []
    for index in range(count):
        open_time = start + index * interval
        base = Decimal("100") + Decimal(index) / Decimal("10")
        output.append(Kline.from_binance_row(
            [open_time, str(base), str(base + 2), str(base - 1), str(base + 1), "10",
             open_time + interval - 1, "1010", 100, "5", "505", "0"],
            symbol=symbol, interval="5m", source_endpoint="/fapi/v1/klines",
        ))
    return tuple(output)


def _signal():
    return QualifiedSignal(
        signal_id="sig-test-001", symbol="BTCUSDT", side="LONG", entry_type="LIMIT",
        entry_price=Decimal("101"), stop_loss=Decimal("99"), take_profit=Decimal("105"),
        timeframe="5m", strategy_id="SMC_V2", created_at_ms=1_800_000_000_000,
        reason_codes=("BOS_BULLISH", "OB_RETEST"), score=75,
    )


def test_chart_renderer_outputs_png_with_valid_candle_inputs():
    image = render_signal_chart(
        _signal(), _candles(), ob_zone=(Decimal("100"), Decimal("102")),
    )
    assert image.startswith(b"\x89PNG\r\n\x1a\n")
    assert len(image) > 10_000


def test_signal_store_deduplicates_and_retains_history(tmp_path: Path):
    store = SignalPublicationStore(Database(tmp_path / "diva.db"))
    signal = _signal()
    payload = {"signal_id": signal.signal_id, "entry": str(signal.entry_price)}
    assert store.reserve(signal, payload=payload) is True
    assert store.reserve(signal, payload=payload) is False
    store.finish(signal.signal_id, "SENT", message_id="77")
    history = store.history()
    assert history[0]["status"] == "SENT"
    assert history[0]["telegram_message_id"] == "77"


def test_signal_publisher_marks_delivery_unknown_and_never_retries_automatically(tmp_path: Path, monkeypatch):
    import httpx

    class BrokenClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def post(self, *args, **kwargs): raise httpx.ConnectTimeout("offline")

    monkeypatch.setattr(httpx, "Client", BrokenClient)
    store = SignalPublicationStore(Database(tmp_path / "diva.db"))
    publisher = SignalTelegramPublisher("123:secret", "12345", store)
    with pytest.raises(TelegramSignalError, match="token redacted"):
        publisher.publish(_signal(), _candles())
    assert store.history()[0]["status"] == "DELIVERY_UNKNOWN"
    assert publisher.publish(_signal(), _candles()) is False


def test_signal_store_links_one_shared_forecast_to_multiple_signals(tmp_path: Path):
    from dataclasses import replace
    from divatrading.intelligence.kronos import (
        KronosForecast, KronosForecastBar,
    )

    store = SignalPublicationStore(Database(tmp_path / "diva.db"))
    signal = _signal()
    other = replace(signal, signal_id="sig-test-002", created_at_ms=signal.created_at_ms + 1)
    store.reserve(signal, payload={"signal_id": signal.signal_id})
    store.reserve(other, payload={"signal_id": other.signal_id})
    bar = KronosForecastBar(
        open_time_ms=1_800_000_300_000,
        open=Decimal("101"), high=Decimal("103"), low=Decimal("100"),
        close=Decimal("102"), volume=Decimal("1"), amount=Decimal("100"),
    )
    forecast = KronosForecast(
        forecast_id="forecast-shared", symbol="BTCUSDT", interval="5m",
        created_at_utc="2027-01-15T00:00:00+00:00", model_repo="NeoQuasar/Kronos-mini",
        tokenizer_repo="NeoQuasar/Kronos-Tokenizer-2k", source_commit="a" * 40,
        model_revision="b" * 40, tokenizer_revision="c" * 40, input_bars=64,
        context_bars=64, horizon_bars=1, last_observed_open_time_ms=1_800_000_000_000,
        last_observed_close=Decimal("101"), projected_close=Decimal("102"),
        projected_return_pct=Decimal("0.99"), direction="UP", forecast_bars=(bar,),
    )
    store.save_forecast(signal.signal_id, forecast)
    store.save_forecast(other.signal_id, forecast)
    assert store.forecast("forecast-shared")["forecast_id"] == "forecast-shared"
    with store.database.connection() as connection:
        rows = connection.execute(
            "SELECT COUNT(*) AS n FROM signal_forecast_links WHERE forecast_id=?",
            ("forecast-shared",),
        ).fetchone()
    assert rows["n"] == 2


def test_chart_rejects_m5_gaps_instead_of_interpolating():
    from divatrading.signals.telegram import TelegramSignalError

    rows = _candles(count=20)
    broken = rows[:10] + rows[11:]
    with pytest.raises(TelegramSignalError, match="M5 gap"):
        render_signal_chart(_signal(), broken)


def test_chart_validates_only_the_visible_last_hundred_bars():
    rows = _candles(count=120)
    # A historical gap outside the plotted 100-bar window does not invalidate
    # the current visible chart segment.
    broken = rows[:5] + rows[6:]
    image = render_signal_chart(_signal(), broken)
    assert image.startswith(b"\x89PNG\r\n\x1a\n")


def test_signal_publisher_success_persists_telegram_message_id(tmp_path: Path, monkeypatch):
    import httpx

    class Response:
        def raise_for_status(self):
            return None
        def json(self):
            return {"ok": True, "result": {"message_id": 321}}

    class Client:
        def __init__(self, *args, **kwargs):
            self.requests = []
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def post(self, url, **kwargs):
            self.requests.append((url, kwargs))
            return Response()

    client = Client()
    monkeypatch.setattr(httpx, "Client", lambda *args, **kwargs: client)
    store = SignalPublicationStore(Database(tmp_path / "diva.db"))
    publisher = SignalTelegramPublisher("123:secret", "12345", store)
    assert publisher.publish(_signal(), _candles()) is True
    item = store.history()[0]
    assert item["status"] == "SENT"
    assert item["telegram_message_id"] == "321"
    assert len(client.requests) == 1
    assert client.requests[0][0].endswith("/sendPhoto")
