"""Schema smoke tests for the Stage 6B design-only checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "docs" / "schemas"
HASH = "a" * 64


def _load_schema(name: str) -> dict:
    payload = json.loads((SCHEMAS / name).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(payload)
    return payload


def test_stage6b_report_schemas_are_valid_draft_2020_12():
    for name in (
        "stage6b_dataset_quality_report.schema.json",
        "stage6b_warmup_convergence_report.schema.json",
        "stage6b_evidence_analytics_report.schema.json",
    ):
        _load_schema(name)


def test_stage6b_dataset_quality_schema_accepts_minimal_report():
    report = {
        "report_schema_version": 2,
        "report_type": "REPLAY_DATASET_QUALITY",
        "dataset_id": HASH,
        "symbol": "BTCUSDT",
        "dataset_window": {"start_open_time_ms": 0, "end_open_time_ms_exclusive": 900000},
        "metadata": {
            "quality": "HISTORICAL_EFFECTIVE",
            "source_url": "https://data.example/source",
            "captured_at_ms": 900000,
            "effective_from_ms": 0,
            "effective_to_ms": 900000,
            "tick_size": "0.10",
            "sha256": HASH,
            "independent_evidence_ref": "archive:exchange-info-2026-01",
        },
        "source_files": [{
            "interval": "1m", "path": "BTCUSDT-1m.csv", "sha256": HASH,
            "row_count_declared": 15, "row_count_observed": 15,
        }],
        "timeframes": [{
            "interval": "1m", "step_ms": 60000, "expected_bar_count": 15,
            "observed_row_count": 15, "observed_unique_bar_count": 15,
            "missing_bar_count": 0, "coverage_ratio_decimal": "1.000000",
            "leading_missing_bar_count": 0, "trailing_missing_bar_count": 0,
            "gap_cluster_count": 0, "gap_clusters_truncated": False, "gap_clusters": [],
            "integrity_counts": {
                "identical_duplicate_rows": 0, "conflicting_revision_rows": 0,
                "non_monotonic_rows": 0, "cross_file_overlap_rows": 0,
                "malformed_rows": 0, "out_of_window_rows": 0,
                "misaligned_open_times": 0, "close_time_mismatches": 0,
                "ohlc_relationship_violations": 0, "symbol_interval_mismatches": 0,
            },
            "tick_grid_violations": 0, "samples": [],
        }],
        "eligibility_gates": {
            "market_data": {"status": "PASS", "eligible_for_strategy_replay": True,
                             "failure_codes": [], "warning_codes": []},
            "execution_metadata": {"status": "PASS", "strict_replay_eligible": True,
                                    "metadata_quality": "HISTORICAL_EFFECTIVE", "candidate_tick_size": "0.10",
                                    "failure_codes": [], "warning_codes": [], "blocking_codes": []},
            "provisional_strategy_replay_eligible": True, "strict_replay_eligible": True,
            "provisional_replay_policy": "STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION",
        },
        "quality_summary": {
            "quality_status": "PASS", "strict_replay_eligible": True,
            "issue_count": 0, "warning_count": 0, "failure_count": 0, "sample_cap": 100,
            "failure_codes": [], "warning_codes": [],
        },
        "report_sha256": HASH,
    }
    Draft202012Validator(_load_schema("stage6b_dataset_quality_report.schema.json")).validate(report)


def test_stage6b_warmup_and_analytics_schemas_accept_contract_examples():
    warmup = {
        "report_schema_version": 1,
        "report_type": "REPLAY_WARMUP_CONVERGENCE",
        "symbol": "BTCUSDT",
        "evaluation_window": {"start_ms": 600000, "end_ms_exclusive": 1200000},
        "frozen_identity": {
            "code_sha256": HASH, "config_sha256": HASH, "metadata_sha256": HASH,
            "clock_policy": "UTC_KLINE_CLOSE_PLUS_1MS_V1", "intervals": ["1m", "5m"],
            "identity_sha256": HASH,
        },
        "comparison_mode": "LIMITED_TWO_TRIAL_COMPARISON",
        "trials": [
            {
                "trial_id": "short", "dataset_id": HASH, "replay_run_id": HASH,
                "ledger_sha256": HASH, "ledger_bytes": 2048, "pre_roll_start_ms": 300000,
                "pre_roll_duration_ms": 300000,
                "pre_roll_start_by_interval": {"1m": 0, "5m": 0},
                "pre_roll_bars": {"1m": 5, "5m": 1},
                "evaluation_slice_sha256": HASH,
                "evaluation_slice_fingerprints": {"1m": HASH, "5m": HASH},
                "evaluation_slice_bar_counts": {"1m": 10, "5m": 2},
                "gap_summary": [], "warmup_readiness_summary": [], "replay_gap_events": [],
                "replay_gap_event_count": 0, "replay_gap_events_truncated": False,
            },
            {
                "trial_id": "long", "dataset_id": HASH, "replay_run_id": HASH,
                "ledger_sha256": HASH, "ledger_bytes": 4096, "pre_roll_start_ms": 0,
                "pre_roll_duration_ms": 600000,
                "pre_roll_start_by_interval": {"1m": 0, "5m": 0},
                "pre_roll_bars": {"1m": 100, "5m": 20},
                "evaluation_slice_sha256": HASH,
                "evaluation_slice_fingerprints": {"1m": HASH, "5m": HASH},
                "evaluation_slice_bar_counts": {"1m": 10, "5m": 2},
                "gap_summary": [], "warmup_readiness_summary": [], "replay_gap_events": [],
                "replay_gap_event_count": 0, "replay_gap_events_truncated": False,
            },
        ],
        "comparisons": [{
            "left_trial_id": "short", "right_trial_id": "long",
            "stage": "STAGE_2_MARKET_STRUCTURE", "timeframe": "1m",
            "record_counts": {
                "left": 10, "right": 10, "matched_keys": 10, "exact_payload_matches": 10,
                "left_only": 0, "right_only": 0, "same_key_changed_payload": 0,
            },
            "agreement": "1.0", "first_divergence_time_ms": None,
            "divergence_count": 0, "divergence_samples_truncated": False,
            "divergence_samples": [],
        }],
        "comparison_payload_policy": "EXCLUDE_REPLAY_RELATIVE_*_INDEX_FIELDS; RETAIN_ABSOLUTE_TIME_AND_ENTITY_IDENTITIES",
        "convergence_policy": "DESCRIPTIVE_NO_AUTOMATIC_PASS_THRESHOLD",
        "report_sha256": HASH,
    }
    Draft202012Validator(_load_schema("stage6b_warmup_convergence_report.schema.json")).validate(warmup)

    analytics = {
        "report_schema_version": 1,
        "report_type": "REPLAY_EVIDENCE_ANALYTICS",
        "provenance": {
            "replay_run_id": HASH, "dataset_id": HASH, "ledger_sha256": HASH,
            "code_sha256": HASH, "config_sha256": HASH,
            "metadata_sha256": HASH, "ledger_bytes": 1024,
        },
        "analysis_window": {"start_ms": 0, "end_ms_exclusive": 9000000},
        "split_plan": {
            "method": "CHRONOLOGICAL_60_20_20_ALIGNED_LCM",
            "alignment_quantum_ms": 900000,
            "target_ratios": ["0.60", "0.20", "0.20"],
            "splits": [
                {"label": "TRAIN", "start_ms": 0, "end_ms_exclusive": 5400000,
                 "target_fraction_decimal": "0.60", "realized_fraction_decimal": "0.60", "test_status": "NOT_APPLICABLE"},
                {"label": "VALIDATION", "start_ms": 5400000, "end_ms_exclusive": 7200000,
                 "target_fraction_decimal": "0.20", "realized_fraction_decimal": "0.20", "test_status": "NOT_APPLICABLE"},
                {"label": "TEST", "start_ms": 7200000, "end_ms_exclusive": 9000000,
                 "target_fraction_decimal": "0.20", "realized_fraction_decimal": "0.20", "test_status": "SEALED"},
            ],
            "frozen_identity_sha256": HASH,
        },
        "state_policy": "ONE_CONTINUOUS_REPLAY_NO_SPLIT_RESET",
        "metrics_by_split": [{
            "split_label": "TRAIN", "closed_bars_by_timeframe": {"1m": 9},
            "event_rates": [{"record_type": "ORDER_BLOCK_CANDIDATE", "timeframe": "1m",
                             "rate": {"event_count": 1, "closed_bar_count": 9, "rate_per_1000_closed_bars": "111.111"}}],
            "market_structure": {
                "bar_trace_count": 0, "pivot_count": 0, "event_counts": {},
                "event_counts_by_layer": [], "readiness_status_counts": [],
                "warmup_remaining_bars_distributions": {},
            },
            "rejection_reason_counts": [{"reason_code": "TEST_REASON", "count": 1}],
            "displacement_distributions": {"close_extension_ticks": {
                "n": 1, "min": "2", "p50": "2", "p90": "2", "p95": "2", "max": "2"}},
            "ob_lifecycle": {}, "liquidity_fvg": {},
            "right_censored": {"ob_count": 1, "fvg_count": 0,
                               "censoring_policy": "ADMINISTRATIVE_AT_SPLIT_END_NOT_TRADE_FAILURE"},
        }],
        "report_sha256": HASH,
    }
    Draft202012Validator(_load_schema("stage6b_evidence_analytics_report.schema.json")).validate(analytics)
