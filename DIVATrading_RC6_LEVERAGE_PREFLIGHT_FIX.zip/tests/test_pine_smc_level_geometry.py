from __future__ import annotations

from dataclasses import FrozenInstanceError
from decimal import Decimal
import json

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcLevelEvaluationTrace,
    PineSmcObScoreTrace,
    PineSmcObScoringTrace,
    PineSmcOrderBlockTrace,
    PineSmcReplayError,
    PineSmcSignalProxy,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
    PineSmcTriggerSweepTrace,
)
from divatrading.strategy.pine_builtin_ta import PineBuiltinTAValues
from divatrading.strategy.pine_smc_structure import (
    PineSmcIndicatorTrace,
    _PineOrderBlockState,
    _PineSmcState,
)

BASE_TIME_MS = 1_700_000_000_000


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 10,
        "internal_len": 1,
        "use_volatility_regime": False,
        "use_trend_filter": False,
        "use_pd_filter": False,
        "fresh_only": False,
        "tick_size": Decimal("0.1"),
        "sl_buffer_atr": 0.10,
        "sl_spread_mult": 2.0,
        "max_sl_atr": 3.0,
        "max_spread_sl_pct": 20.0,
        "high_vol_sl_mult": 1.50,
        "tp_mode": "Fixed RR",
        "rr": 2.0,
        "min_rr": 1.5,
        "spread_estimate_ticks": 0.0,
        "min_stop_ticks": 1.0,
        "consume_ob_on_signal": True,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def _kline(
    index: int = 3,
    *,
    open_price: str = "108",
    high: str = "112",
    low: str = "107",
    close: str = "110",
) -> Kline:
    interval = "1m"
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            "10",
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def _ob(
    *,
    bias: int = 1,
    top: float = 105.0,
    bottom: float = 95.0,
    used: bool = False,
    index: int = 0,
) -> _PineOrderBlockState:
    interval_ms = INTERVAL_MILLISECONDS["1m"]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    return _PineOrderBlockState(
        top=top,
        bottom=bottom,
        bar_local_index=max(0, index - 1),
        break_local_index=max(0, index - 1),
        source_time_ms=base_time + max(0, index - 1) * interval_ms,
        break_time_ms=base_time + max(0, index - 1) * interval_ms,
        bias=bias,
        has_fvg=True,
        used=used,
    )


def _score(ob: _PineOrderBlockState, *, index: int = 0) -> PineSmcObScoreTrace:
    snapshot = ob.snapshot()
    return PineSmcObScoreTrace(
        active_array_index=index,
        order_block=snapshot,
        age=2,
        entry_band_low=97.0 if ob.bias == 1 else 100.0,
        entry_band_high=100.0 if ob.bias == 1 else 103.0,
        ob_quality_score=80.0,
        timing_score=70.0,
        setup_score=78.0,
        volatility_score=90.0,
        displacement_score=80.0,
        source_candle_score=70.0,
        rsi_score=75.0,
        trend_score=80.0,
        fvg_score=100.0,
        volume_score=60.0,
        freshness_score=99.0,
        current_candle_score=75.0,
        proximity_score=65.0,
        sweep_score=45.0,
        swept_current_candle=False,
    )


def _indicator(
    *,
    atr_fast: float | None = 2.0,
    atr_ratio: float | None = 1.0,
) -> PineSmcIndicatorTrace:
    return PineSmcIndicatorTrace(
        atr_fast_now=atr_fast,
        rsi_now=58.0,
        volume_avg_now=10.0,
        di_plus_now=20.0,
        di_minus_now=10.0,
        adx_now=25.0,
        atr200_ratio_base=1.0,
        atr_ratio_now=atr_ratio,
        volatility_extreme=False,
        volatility_choppy=False,
    )


def _state(
    *,
    selected: _PineOrderBlockState | None = None,
    other_obs: tuple[_PineOrderBlockState, ...] = (),
    atr200: float = 10.0,
    range_top: float = 130.0,
    range_bottom: float = 80.0,
) -> _PineSmcState:
    state = _PineSmcState(
        local_index=3,
        atr200=atr200,
        range_top=range_top,
        range_top_valid=True,
        range_bottom=range_bottom,
        range_bottom_valid=True,
    )
    if selected is not None:
        state.active_order_blocks.append(selected)
    state.active_order_blocks.extend(other_obs)
    return state


def _stage7_scoring(
    selected: _PineOrderBlockState | None,
    *,
    index: int = 0,
    available: bool = True,
    tick_size: float | None = 0.1,
) -> PineSmcObScoringTrace:
    score = None if selected is None or not available else _score(selected, index=index)
    return PineSmcObScoringTrace(
        available=available,
        unavailable_reason=None if available else "exact_tick_size_required_for_syminfo_mintick",
        tick_size=tick_size,
        max_age=300,
        near_depth=0.50,
        deep_depth=0.80,
        prior_lowest_sweep=100.0,
        prior_highest_sweep=120.0,
        active_order_block_scores=() if score is None else (score,),
        chosen_active_array_index=None if selected is None else index,
        chosen_score=score,
    )


def _trigger(index: int | None = 0, code: int = 1) -> PineSmcTriggerSweepTrace:
    return PineSmcTriggerSweepTrace(
        trigger_mode="Either",
        require_sweep=False,
        chosen_active_array_index=index,
        chosen_trigger_code=code if index is not None else 0,
    )


def _evaluate(
    *,
    config: PineSmcStructureConfig | None = None,
    state: _PineSmcState | None = None,
    candle: Kline | None = None,
    indicators: PineSmcIndicatorTrace | None = None,
    trigger: PineSmcTriggerSweepTrace | None = None,
    scoring: PineSmcObScoringTrace | None = None,
) -> tuple[PineSmcLevelEvaluationTrace, _PineSmcState]:
    selected_state = _ob() if state is None else None
    actual_state = _state(selected=selected_state) if state is None else state
    actual_candle = _kline() if candle is None else candle
    chosen = _trigger() if trigger is None else trigger
    engine = PineSmcStructureEngine(_config() if config is None else config)
    if scoring is None:
        selected = (
            None
            if chosen.chosen_active_array_index is None
            else actual_state.active_order_blocks[chosen.chosen_active_array_index]
        )
        scoring = _stage7_scoring(
            selected,
            index=chosen.chosen_active_array_index or 0,
            available=True,
            tick_size=engine.config.tick_size,
        )
    result = engine._evaluate_signal_levels(
        state=actual_state,
        candle=actual_candle,
        indicators=_indicator() if indicators is None else indicators,
        trigger_sweep=chosen,
        ob_scoring=scoring,
    )
    return result, actual_state


def test_stage8_config_defaults_and_validation_match_pine_level_inputs() -> None:
    config = _config()
    assert config.sl_buffer_atr == 0.10
    assert config.sl_spread_mult == 2.0
    assert config.max_sl_atr == 3.0
    assert config.max_spread_sl_pct == 20.0
    assert config.high_vol_sl_mult == 1.50
    assert config.tp_mode == "Fixed RR"
    assert config.rr == 2.0
    assert config.min_rr == 1.5
    assert config.spread_estimate_ticks == 0.0
    assert config.min_stop_ticks == 1.0
    assert config.consume_ob_on_signal is True

    for name, invalid_values in (
        ("sl_buffer_atr", (-0.01, True, float("nan"), float("inf"))),
        ("sl_spread_mult", (-0.01, True, float("nan"))),
        ("max_sl_atr", (0.49, True, float("nan"))),
        ("max_spread_sl_pct", (-0.01, True, float("inf"))),
        ("high_vol_sl_mult", (0.99, 3.01, True, float("nan"))),
        ("rr", (0.24, True, float("nan"))),
        ("min_rr", (0.24, True, float("inf"))),
        ("spread_estimate_ticks", (-0.5, True, float("nan"))),
        ("min_stop_ticks", (-1.0, True, float("inf"))),
        ("tp_mode", ("RR", "Hybrid", "structure", "")),
        ("consume_ob_on_signal", (1, None, "true")),
    ):
        for invalid in invalid_values:
            with pytest.raises(PineSmcReplayError, match=name):
                _config(**{name: invalid})


def test_fixed_rr_bullish_uses_close_proxy_structural_stop_and_weighted_buffer() -> None:
    ob = _ob()
    state = _state(selected=ob, range_top=130.0)
    indicators = _indicator(atr_fast=2.0, atr_ratio=1.8)
    config = _config(
        use_volatility_regime=True,
        high_vol_ratio=1.6,
        high_vol_sl_mult=1.5,
        spread_estimate_ticks=10.0,
    )
    result, updated = _evaluate(config=config, state=state, indicators=indicators)

    # spreadPrice=1.0, spread buffer=2.0, ATR buffer=0.2, regime multiplier=1.5.
    assert result.attempted is True
    assert result.available is True
    assert result.accepted is True
    assert result.entry_proxy == pytest.approx(110.0)
    assert result.spread_price == pytest.approx(1.0)
    assert result.stop_buffer == pytest.approx(3.0)
    assert result.stop_loss_proxy == pytest.approx(92.0)
    assert result.stop_distance == pytest.approx(18.0)
    assert result.minimum_stop_distance == pytest.approx(0.1)
    assert result.structural_target == pytest.approx(130.0)
    assert result.take_profit_proxy == pytest.approx(146.0)
    assert result.target_source == "fixed_rr"
    assert result.final_reward == pytest.approx(36.0)
    assert result.risk_reward == pytest.approx(2.0)
    assert result.signal is not None
    assert result.signal.direction == 1
    assert result.signal.trigger_code == 1
    assert result.signal.source_time_ms == _kline().open_time_ms
    assert result.signal.setup_score == pytest.approx(78.0)
    assert result.signal.entry_band_low == pytest.approx(97.0)
    assert result.signal.ob_consumed_by_signal_proxy is True
    # Signal captures the selected OB before the proxy-used mutation; active
    # array snapshots later in the bar reflect the post-signal used state.
    assert result.signal.order_block.used is False
    assert updated.active_order_blocks[0].used is True


def test_bearish_fixed_rr_mirrors_structural_stop_and_target_geometry() -> None:
    selected = _ob(bias=-1, top=115.0, bottom=105.0)
    state = _state(selected=selected, range_bottom=80.0)
    candle = _kline(open_price="100", high="103", low="98", close="100")
    result, _ = _evaluate(
        config=_config(rr=1.5),
        state=state,
        candle=candle,
        trigger=_trigger(code=2),
        scoring=_stage7_scoring(selected),
    )
    assert result.accepted is True
    assert result.entry_proxy == pytest.approx(100.0)
    assert result.stop_loss_proxy == pytest.approx(115.2)
    assert result.stop_distance == pytest.approx(15.2)
    assert result.structural_target == pytest.approx(80.0)
    assert result.take_profit_proxy == pytest.approx(77.2)
    assert result.risk_reward == pytest.approx(1.5)
    assert result.signal is not None and result.signal.direction == -1
    assert result.signal.trigger_code == 2


def test_minimum_stop_distance_expands_sl_from_entry_after_structural_buffer() -> None:
    selected = _ob(top=100.1, bottom=99.9)
    state = _state(selected=selected, atr200=100.0, range_top=130.0)
    candle = _kline(open_price="100", high="101", low="99", close="100.05")
    result, _ = _evaluate(
        config=_config(min_stop_ticks=10.0),
        state=state,
        candle=candle,
        scoring=_stage7_scoring(selected),
    )
    assert result.accepted is True
    assert result.minimum_stop_distance == pytest.approx(1.0)
    assert result.stop_distance == pytest.approx(1.0)
    assert result.stop_loss_proxy == pytest.approx(99.05)


def test_non_positive_stop_distance_rejects_before_target_calculation_and_does_not_consume() -> None:
    selected = _ob(top=105.0, bottom=95.0)
    state = _state(selected=selected)
    candle = _kline(open_price="90", high="96", low="88", close="90")
    result, updated = _evaluate(state=state, candle=candle)
    assert result.accepted is False
    assert result.rejection_reasons == ("stop_distance_non_positive",)
    assert result.take_profit_proxy is None
    assert result.signal is None
    assert updated.active_order_blocks[0].used is False


def test_max_sl_atr_and_spread_pct_gates_are_strict_and_preserve_reasons() -> None:
    selected = _ob()
    too_wide, state = _evaluate(
        config=_config(max_sl_atr=0.5),
        state=_state(selected=selected, atr200=10.0),
    )
    assert too_wide.accepted is False
    assert "max_sl_atr_exceeded" in too_wide.rejection_reasons
    assert state.active_order_blocks[0].used is False

    spread_gate, state = _evaluate(
        config=_config(spread_estimate_ticks=100.0, sl_spread_mult=0.0, sl_buffer_atr=0.1,
                       max_spread_sl_pct=1.0, max_sl_atr=10.0),
        state=_state(selected=_ob(), atr200=1000.0),
        indicators=_indicator(atr_fast=1.0),
    )
    assert spread_gate.accepted is False
    assert "spread_to_stop_pct_exceeded" in spread_gate.rejection_reasons
    assert state.active_order_blocks[0].used is False


def test_fixed_rr_does_not_apply_min_rr_input_as_a_separate_gate() -> None:
    selected = _ob()
    result, _ = _evaluate(
        config=_config(rr=0.5, min_rr=3.0),
        state=_state(selected=selected, atr200=100.0),
    )
    assert result.accepted is True
    assert result.risk_reward == pytest.approx(0.5)


def test_structure_tp_requires_directional_structural_target_and_min_rr() -> None:
    selected = _ob()
    insufficient, state = _evaluate(
        config=_config(tp_mode="Structure", min_rr=1.5),
        state=_state(selected=selected, range_top=120.0, atr200=10.0),
    )
    assert insufficient.accepted is False
    assert insufficient.target_source == "structural_liquidity"
    assert "structure_target_below_min_rr" in insufficient.rejection_reasons
    assert state.active_order_blocks[0].used is False

    sufficient, state = _evaluate(
        config=_config(tp_mode="Structure", min_rr=1.5),
        state=_state(selected=_ob(), range_top=150.0, atr200=10.0),
    )
    assert sufficient.accepted is True
    assert sufficient.take_profit_proxy == pytest.approx(150.0)
    assert sufficient.risk_reward >= 1.5
    assert state.active_order_blocks[0].used is True


def test_structure_tp_rejects_missing_or_wrong_side_structural_liquidity() -> None:
    selected = _ob()
    result, state = _evaluate(
        config=_config(tp_mode="Structure"),
        state=_state(selected=selected, range_top=100.0),
    )
    assert result.accepted is False
    assert result.take_profit_proxy is None
    assert "take_profit_unavailable" in result.rejection_reasons
    assert state.active_order_blocks[0].used is False


def test_hybrid_prefers_nearest_opposing_ob_when_min_rr_is_satisfied() -> None:
    selected = _ob()
    opposing_far = _ob(bias=-1, top=151.0, bottom=145.0, index=2)
    opposing_near = _ob(bias=-1, top=148.0, bottom=142.0, index=1)
    state = _state(
        selected=selected,
        other_obs=(opposing_far, opposing_near),
        range_top=170.0,
    )
    result, _ = _evaluate(
        config=_config(tp_mode="Hybrid OB/Liquidity", min_rr=1.5),
        state=state,
    )
    assert result.accepted is True
    assert result.opposing_ob_target == pytest.approx(142.0)
    assert result.structural_target == pytest.approx(170.0)
    assert result.take_profit_proxy == pytest.approx(142.0)
    assert result.target_source == "opposing_ob"


def test_hybrid_uses_structure_when_no_opposing_ob_and_falls_back_when_rr_is_low() -> None:
    selected = _ob()
    structure_pass, _ = _evaluate(
        config=_config(tp_mode="Hybrid OB/Liquidity", min_rr=0.25),
        state=_state(selected=selected, range_top=130.0),
    )
    assert structure_pass.accepted is True
    assert structure_pass.target_source == "structural_liquidity"
    assert structure_pass.take_profit_proxy == pytest.approx(130.0)

    fallback, _ = _evaluate(
        config=_config(tp_mode="Hybrid OB/Liquidity", min_rr=2.0, rr=2.5),
        state=_state(selected=_ob(), range_top=120.0),
    )
    assert fallback.accepted is True
    assert fallback.target_source == "fixed_rr_fallback"
    assert fallback.take_profit_proxy == pytest.approx(148.0)


def test_hybrid_rr_fallback_is_rejected_when_it_would_cross_an_opposing_ob() -> None:
    selected = _ob()
    opposing = _ob(bias=-1, top=130.0, bottom=125.0, index=2)
    result, state = _evaluate(
        config=_config(tp_mode="Hybrid OB/Liquidity", min_rr=2.0, rr=2.5),
        state=_state(selected=selected, other_obs=(opposing,), range_top=160.0),
    )
    assert result.accepted is False
    assert result.target_source == "fixed_rr_fallback"
    assert "opposing_ob_blocks_rr_fallback" in result.rejection_reasons
    assert state.active_order_blocks[0].used is False


def test_hybrid_short_uses_nearest_opposing_bullish_ob_and_obstacle_direction() -> None:
    selected = _ob(bias=-1, top=115.0, bottom=105.0)
    opposing = _ob(bias=1, top=95.0, bottom=90.0, index=2)
    state = _state(
        selected=selected,
        other_obs=(opposing,),
        range_bottom=70.0,
    )
    result, _ = _evaluate(
        config=_config(tp_mode="Hybrid OB/Liquidity", min_rr=0.25),
        state=state,
        candle=_kline(open_price="100", high="103", low="98", close="100"),
        scoring=_stage7_scoring(selected),
    )
    assert result.accepted is True
    assert result.opposing_ob_target == pytest.approx(95.0)
    assert result.take_profit_proxy == pytest.approx(95.0)
    assert result.target_source == "opposing_ob"


def test_stage8_does_not_retry_later_candidates_when_chosen_candidate_levels_fail() -> None:
    first = _ob(top=105.0, bottom=95.0)
    second = _ob(top=108.0, bottom=80.0, index=2)
    state = _state(selected=first, other_obs=(second,), atr200=1.0)
    scoring = _stage7_scoring(first, index=0)
    trigger = _trigger(index=0, code=1)
    result, updated = _evaluate(
        config=_config(max_sl_atr=0.5),
        state=state,
        trigger=trigger,
        scoring=scoring,
    )
    assert result.accepted is False
    assert result.chosen_active_array_index == 0
    assert updated.active_order_blocks[0].used is False
    assert updated.active_order_blocks[1].used is False


def test_missing_tick_size_or_atr14_fails_closed_without_mutating_ob() -> None:
    selected = _ob()
    result, state = _evaluate(
        config=_config(tick_size=None),
        state=_state(selected=selected),
        scoring=_stage7_scoring(selected, available=False, tick_size=None),
    )
    assert result.attempted is True
    assert result.available is False
    assert result.signal is None
    assert "tick_size" in (result.unavailable_reason or "")
    assert state.active_order_blocks[0].used is False

    result, state = _evaluate(
        state=_state(selected=_ob()),
        indicators=_indicator(atr_fast=None),
    )
    assert result.available is False
    assert result.unavailable_reason == "pine_atr_14_unavailable_for_sl_buffer"
    assert state.active_order_blocks[0].used is False


def test_consume_ob_on_signal_is_opt_out_and_never_equal_to_fill() -> None:
    selected = _ob()
    result, state = _evaluate(
        config=_config(consume_ob_on_signal=False),
        state=_state(selected=selected),
    )
    assert result.accepted is True
    assert result.signal is not None
    assert result.ob_consumed_by_signal_proxy is False
    assert result.signal.ob_consumed_by_signal_proxy is False
    assert state.active_order_blocks[0].used is False
    assert result.signal.entry_proxy == pytest.approx(110.0)
    assert not hasattr(result.signal, "fill_price")


def test_signal_and_level_trace_are_immutable_and_json_serializable() -> None:
    result, _ = _evaluate()
    assert result.signal is not None
    with pytest.raises(FrozenInstanceError):
        result.signal.entry_proxy = 1.0  # type: ignore[misc]
    with pytest.raises(FrozenInstanceError):
        result.accepted = False  # type: ignore[misc]
    payload = json.dumps(
        {
            "level_evaluation": result,
            "signal": result.signal,
        },
        default=lambda value: value.__dict__ if hasattr(value, "__dict__") else {
            field: getattr(value, field)
            for field in value.__dataclass_fields__
        },
        allow_nan=False,
    )
    assert "entry_proxy" in payload
    assert "ob_consumed_by_signal_proxy" in payload


def test_max_sl_atr_and_spread_percentage_exact_boundaries_are_allowed() -> None:
    selected = _ob()
    # entry=110, OB bottom=95, ATR buffer=1.0 => SL distance=16.0.
    # Both strict gates are exactly on their boundary: maxSL=1.6*10 and
    # spread=2.0 equals 12.5% of the stop distance.
    accepted, _ = _evaluate(
        config=_config(
            max_sl_atr=1.6,
            max_spread_sl_pct=12.5,
            spread_estimate_ticks=20.0,
            sl_spread_mult=0.0,
            sl_buffer_atr=0.2,
        ),
        state=_state(selected=selected, atr200=10.0),
        indicators=_indicator(atr_fast=5.0),
    )
    assert accepted.accepted is True


def test_stage7_score_must_reference_the_same_stage6_selected_ob() -> None:
    selected = _ob()
    mismatched = _stage7_scoring(_ob(top=106.0, bottom=96.0))
    with pytest.raises(PineSmcReplayError, match="does not match"):
        _evaluate(
            state=_state(selected=selected),
            scoring=mismatched,
        )


def test_no_stage6_candidate_means_no_level_attempt() -> None:
    result, _ = _evaluate(trigger=_trigger(index=None, code=0))
    assert result.attempted is False
    assert result.available is True
    assert result.accepted is False
    assert result.signal is None


def test_replay_trace_exposes_level_evaluation_and_config_metadata() -> None:
    engine = PineSmcStructureEngine(_config())
    candles = [
        _kline(0, open_price="100", high="101", low="99", close="100"),
        _kline(1, open_price="100", high="102", low="98", close="101"),
        _kline(2, open_price="101", high="103", low="99", close="102"),
        _kline(3, open_price="102", high="104", low="100", close="103"),
    ]
    replay = engine.replay(candles)
    assert replay.tp_mode == "Fixed RR"
    assert replay.sl_buffer_atr == pytest.approx(0.10)
    assert replay.consume_ob_on_signal is True
    assert replay.trace[-1].level_evaluation.attempted is False
    payload = json.loads(replay.to_jsonl().splitlines()[-1])
    assert "level_evaluation" in payload
    assert payload["level_evaluation"]["signal"] is None
