from decimal import Decimal as D
from pathlib import Path

import pytest

from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.position_lifecycle import LifecycleAction, ManagedPositionState
from divatrading.execution.position_lifecycle_execution import (
    PositionLifecycleExecutionAdapter,
    PositionLifecycleFillReducer,
)
from divatrading.execution.trade_backfill import BinanceUserTradesBackfillService
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.trading.models import QualifiedSignal, TradePlan

NOW = 1_800_000_000_000


def _ready_ledger(path: Path) -> ExecutionLedger:
    ledger = ExecutionLedger(path)
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=NOW, updated_at_ms=NOW)
    ledger.set_reconciliation_state(
        True, status="READY", captured_at_ms=NOW,
        detail={"test": True}, stream_event_watermark_ms=0,
    )
    return ledger


def _managed(ledger: ExecutionLedger, *, signal_id="sig-lc", side="LONG",
             quantity="1", position_side="BOTH", with_reservation=True):
    client_id = ledger.deterministic_client_id(signal_id, "ENTRY")
    ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side=side,
                        client_order_id=client_id, payload={})
    entry = D("100")
    stop = D("90") if side == "LONG" else D("110")
    take = D("120") if side == "LONG" else D("80")
    ledger.record_position(symbol="BTCUSDT", position_side=position_side,
                           signal_id=signal_id, quantity=quantity,
                           entry_price=str(entry), stop_loss=str(stop), take_profit=str(take))
    state = {
        "signal_id": signal_id, "symbol": "BTCUSDT", "side": side,
        "quantity": quantity, "entry_price": "100", "initial_stop": str(stop),
        "current_stop": str(stop), "initial_risk_per_unit": "10",
        "partial_tp_fraction": "0.5", "partial_tp_done": False,
        "breakeven_done": False, "trailing_active": False,
        "favorable_extreme": None, "last_mark_price": None, "closed": False,
        "stop_algo_client_id": ledger.deterministic_client_id(signal_id, "STOP_LOSS"),
        "take_profit_algo_client_id": ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"),
    }
    ledger.save_position_management_state(signal_id=signal_id, symbol="BTCUSDT", state=state)
    if with_reservation:
        result = ledger.reserve_portfolio_risk(
            signal_id=signal_id, symbol="BTCUSDT", risk_usdt=D("10"),
            notional_usdt=D("100"), equity_usdt=D("1000"),
            exchange_open_risk_usdt=D("0"), exchange_active_position_count=0,
            max_positions=5, max_portfolio_open_risk_pct=D("5"),
            exchange_symbol_notional_usdt=D("0"), max_symbol_notional_usdt=D("10000"),
        )
        assert result.accepted
    return state


class FakeExecutionClient:
    environment = "TESTNET"

    def __init__(self, *, dual=False, quantity="1"):
        self.dual = dual
        position_side = "LONG" if dual else "BOTH"
        self.positions = [{"symbol": "BTCUSDT", "positionSide": position_side,
                           "positionAmt": quantity}]
        self.orders = {}
        self.algos = {}
        self.new_order_calls = []
        self.new_algo_calls = []
        self.cancel_order_calls = []
        self.cancel_algo_calls = []
        self.next_algo_status = "NEW"
        self.fail_get_algo = False

    def sync_server_time(self):
        return 0

    def get_position_mode(self):
        return {"dualSidePosition": self.dual}

    def get_position_risk(self, symbol=None):
        return [row for row in self.positions if symbol is None or row["symbol"] == symbol]

    def new_order(self, **params):
        self.new_order_calls.append(params)
        response = {"orderId": 101, "clientOrderId": params["newClientOrderId"],
                    "status": "NEW", "executedQty": "0", "origQty": str(params["quantity"])}
        self.orders[params["newClientOrderId"]] = response
        return response

    def get_order(self, symbol, *, order_id=None, client_order_id=None):
        if client_order_id is not None:
            return dict(self.orders[client_order_id])
        for order in self.orders.values():
            if str(order.get("orderId")) == str(order_id) and str(order.get("symbol", symbol)).upper() == symbol.upper():
                return dict(order)
        from divatrading.execution.binance_private import BinancePrivateApiError
        raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/order")

    def cancel_order(self, symbol, *, order_id=None, client_order_id=None):
        if client_order_id is not None:
            order = self.orders[client_order_id]
            self.cancel_order_calls.append(client_order_id)
        else:
            order = next((item for item in self.orders.values()
                          if str(item.get("orderId")) == str(order_id)), None)
            if order is None:
                from divatrading.execution.binance_private import BinancePrivateApiError
                raise BinancePrivateApiError(400, -2011, "Unknown order sent", "/fapi/v1/order")
            self.cancel_order_calls.append(str(order_id))
        order["status"] = "CANCELED"
        return dict(order)

    def new_algo_order(self, **params):
        self.new_algo_calls.append(params)
        response = {"algoId": 202, "clientAlgoId": params["clientAlgoId"],
                    "algoStatus": self.next_algo_status, "symbol": params["symbol"],
                    "orderType": params["type"], **params}
        self.algos[params["clientAlgoId"]] = response
        return dict(response)

    def get_algo_order(self, *, algo_id=None, client_algo_id=None):
        if self.fail_get_algo:
            raise RuntimeError("simulated REST query timeout")
        if client_algo_id not in self.algos:
            from divatrading.execution.binance_private import BinancePrivateApiError
            raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
        return dict(self.algos[client_algo_id])

    def get_open_algo_orders(self, symbol=None):
        return [dict(row) for row in self.algos.values()
                if row.get("algoStatus") in {"NEW", "PENDING_NEW"}
                and (symbol is None or row.get("symbol") == symbol)]

    def cancel_algo_order(self, *, algo_id=None, client_algo_id=None):
        self.cancel_algo_calls.append(client_algo_id)
        self.algos[client_algo_id]["algoStatus"] = "CANCELED"
        return {"clientAlgoId": client_algo_id, "code": "200"}

    def get_open_orders(self, symbol=None):
        return [dict(row) for row in self.orders.values()
                if row.get("status") in {"NEW", "PARTIALLY_FILLED"}
                and (symbol is None or row.get("symbol") == symbol)]


def _adapter(ledger, client):
    return PositionLifecycleExecutionAdapter(
        client=client, ledger=ledger, clock_ms=lambda: NOW,
    )


def _state(**changes):
    values = dict(signal_id="sig-lc", symbol="BTCUSDT", side="LONG", quantity=D("1"),
                  entry_price=D("100"), initial_stop=D("90"), current_stop=D("90"),
                  initial_risk_per_unit=D("10"))
    values.update(changes)
    return ManagedPositionState(**values)


def test_partial_tp_submission_uses_reduce_only_in_one_way_and_confirmation_is_separate(tmp_path):
    ledger = _ready_ledger(tmp_path / "partial.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-partial", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.5"), reason="Reached 1R")

    submitted = adapter.submit_partial_take_profit(action, _state(),
                                                    market_step_size=D("0.1"), market_min_qty=D("0.1"))
    params = client.new_order_calls[0]
    assert params["side"] == "SELL" and params["positionSide"] == "BOTH"
    assert params["reduceOnly"] is True
    assert submitted["status"] == "SUBMITTED"
    assert ledger.get_position_management_state("sig-lc")["state"]["partial_tp_done"] is False

    order = client.orders[submitted["client_order_id"]]
    order.update(status="FILLED", executedQty="0.5")
    client.positions[0]["positionAmt"] = "0.5"
    confirmed = adapter.confirm_partial_take_profit("action-partial")
    assert confirmed["status"] == "CONFIRMED"
    assert confirmed["protection_resize"]["status"] == "CONFIRMED"
    state = ledger.get_position_management_state("sig-lc")["state"]
    assert state["partial_tp_done"] is True and state["quantity"] == "0.5"
    assert state["stop_algo_client_id"] == confirmed["protection_resize"]["stop_client_algo_id"]
    assert state["take_profit_algo_client_id"] == confirmed["protection_resize"]["take_profit_client_algo_id"]
    active_protections = client.get_open_algo_orders("BTCUSDT")
    assert len(active_protections) == 2
    assert {str(item["quantity"]) for item in active_protections} == {"0.5"}
    assert all(item["reduceOnly"] is True and "closePosition" not in item
               for item in active_protections)
    posted_count = len(client.new_algo_calls)
    duplicate_resize = adapter.resize_protection_quantity(
        "sig-lc", D("0.5"), source_action_id="action-partial",
    )
    assert duplicate_resize["duplicate"] is True
    assert len(client.new_algo_calls) == posted_count
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"


def test_partial_tp_hedge_mode_omits_reduce_only_and_sets_position_side(tmp_path):
    ledger = _ready_ledger(tmp_path / "hedge.sqlite")
    _managed(ledger, position_side="LONG")
    client = FakeExecutionClient(dual=True, quantity="1")
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-hedge", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.4"))

    submitted = adapter.submit_partial_take_profit(action, _state(),
                                                    market_step_size=D("0.1"), market_min_qty=D("0.1"))
    params = client.new_order_calls[0]
    assert params["positionSide"] == "LONG"
    assert "reduceOnly" not in params
    client.orders[submitted["client_order_id"]].update(status="FILLED", executedQty="0.4")
    client.positions[0]["positionAmt"] = "0.6"
    confirmed = adapter.confirm_partial_take_profit("action-hedge")
    assert confirmed["protection_resize"]["status"] == "CONFIRMED"
    protections = client.get_open_algo_orders("BTCUSDT")
    assert len(protections) == 2
    assert {str(item["quantity"]) for item in protections} == {"0.6"}
    assert all(item["positionSide"] == "LONG" and "reduceOnly" not in item
               and "closePosition" not in item for item in protections)


def test_partial_full_exit_resizes_remaining_stop_and_take_profit(tmp_path):
    ledger = _ready_ledger(tmp_path / "partial-full-exit.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    adapter = _adapter(ledger, client)
    action = LifecycleAction(
        "action-structural-partial", "STRUCTURAL_EXIT", "sig-lc", "BTCUSDT", "LONG",
        reason="SMC structural invalidation",
    )
    submitted = adapter.submit_market_exit(
        action, _state(), market_step_size=D("0.1"), market_min_qty=D("0.1"),
    )
    client.orders[submitted["client_order_id"]].update(
        status="FILLED", executedQty="0.4",
    )
    client.positions[0]["positionAmt"] = "0.6"
    result = adapter.confirm_market_exit("action-structural-partial")
    assert result["status"] == "PARTIAL_EXIT_REMAINS"
    assert result["protection_resize"]["status"] == "CONFIRMED"
    state = ledger.get_position_management_state("sig-lc")["state"]
    assert state["quantity"] == "0.6"
    protections = client.get_open_algo_orders("BTCUSDT")
    assert len(protections) == 2
    assert {str(item["quantity"]) for item in protections} == {"0.6"}
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"


def test_partial_tp_duplicate_action_never_posts_twice(tmp_path):
    ledger = _ready_ledger(tmp_path / "duplicate.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-duplicate", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.5"))
    first = adapter.submit_partial_take_profit(action, _state(),
                                               market_step_size=D("0.1"), market_min_qty=D("0.1"))
    second = adapter.submit_partial_take_profit(action, _state(),
                                                market_step_size=D("0.1"), market_min_qty=D("0.1"))
    assert first["status"] == "SUBMITTED"
    assert second["duplicate"] is True
    assert len(client.new_order_calls) == 1


def test_partial_fill_terminal_reconciles_actual_quantity_without_marking_target_done(tmp_path):
    ledger = _ready_ledger(tmp_path / "partial-fill.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-partial-fill", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.5"))
    submitted = adapter.submit_partial_take_profit(action, _state(),
                                                    market_step_size=D("0.1"), market_min_qty=D("0.1"))
    order = client.orders[submitted["client_order_id"]]
    order.update(status="PARTIALLY_FILLED", executedQty="0.3")
    client.positions[0]["positionAmt"] = "0.7"
    result = adapter.confirm_partial_take_profit("action-partial-fill")
    assert result["status"] == "PARTIAL_FILL_TERMINAL"
    stored = ledger.get_position_management_state("sig-lc")["state"]
    assert stored["quantity"] == "0.7"
    assert stored["initial_quantity"] == "1"
    assert stored["partial_tp_filled_quantity"] == "0.3"
    assert stored["partial_tp_done"] is False
    assert client.cancel_order_calls == [submitted["client_order_id"]]
    # The next trigger requests only the 0.2 remainder of the original 0.5 target,
    # not half of the already reduced 0.7 residual position.
    from divatrading.execution.position_lifecycle import PositionLifecycleEngine
    next_decision = PositionLifecycleEngine().evaluate(adapter.load_state("sig-lc"), D("110"))
    assert len(next_decision.actions) == 1
    assert next_decision.actions[0].kind == "PARTIAL_TP"
    assert next_decision.actions[0].quantity == D("0.2")
    second_submit = adapter.submit_partial_take_profit(
        next_decision.actions[0], adapter.load_state("sig-lc"),
        market_step_size=D("0.1"), market_min_qty=D("0.1"),
    )
    client.orders[second_submit["client_order_id"]].update(
        status="FILLED", executedQty="0.2"
    )
    client.positions[0]["positionAmt"] = "0.5"
    second_confirm = adapter.confirm_partial_take_profit(next_decision.actions[0].action_id)
    assert second_confirm["status"] == "CONFIRMED"
    stored_after_second = ledger.get_position_management_state("sig-lc")["state"]
    assert stored_after_second["quantity"] == "0.5"
    assert stored_after_second["partial_tp_filled_quantity"] == "0.5"
    assert stored_after_second["partial_tp_done"] is True
    active_protections = client.get_open_algo_orders("BTCUSDT")
    assert len(active_protections) == 2
    assert {str(item["quantity"]) for item in active_protections} == {"0.5"}



def test_partial_tp_snaps_original_target_to_market_step_and_does_not_leave_untradeable_dust(tmp_path):
    ledger = _ready_ledger(tmp_path / "partial-step.sqlite")
    _managed(ledger, quantity="0.3")
    client = FakeExecutionClient(quantity="0.3")
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-partial-step", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.15"), reason="Reached 1R")
    submitted = adapter.submit_partial_take_profit(
        action, _state(quantity=D("0.3")),
        market_step_size=D("0.1"), market_min_qty=D("0.1"),
    )
    assert submitted["quantity"] == "0.1"
    client.orders[submitted["client_order_id"]].update(status="FILLED", executedQty="0.1")
    client.positions[0]["positionAmt"] = "0.2"
    confirmed = adapter.confirm_partial_take_profit(action.action_id)
    assert confirmed["status"] == "CONFIRMED"
    stored = adapter.load_state("sig-lc")
    assert stored.partial_tp_target_quantity == D("0.1")
    assert stored.partial_tp_filled_quantity == D("0.1")
    assert stored.partial_tp_done is True
    from divatrading.execution.position_lifecycle import PositionLifecycleEngine
    next_decision = PositionLifecycleEngine().evaluate(stored, D("110"))
    assert all(item.kind != "PARTIAL_TP" for item in next_decision.actions)

def test_stop_replace_creates_verified_algo_before_canceling_old_stop(tmp_path):
    ledger = _ready_ledger(tmp_path / "replace-stop.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id, "algoStatus": "NEW",
                            "symbol": "BTCUSDT", "orderType": "STOP_MARKET"}
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-stop", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Move stop to breakeven")

    result = adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    params = client.new_algo_calls[0]
    assert result["status"] == "CONFIRMED"
    assert params["type"] == "STOP_MARKET"
    assert params["side"] == "SELL" and params["positionSide"] == "BOTH"
    assert params["quantity"] == D("1") and params["reduceOnly"] is True
    assert "closePosition" not in params
    assert "newOrderRespType" not in params
    assert client.cancel_algo_calls == [old_id]
    state_row = ledger.get_position_management_state("sig-lc")["state"]
    assert state_row["current_stop"] == "95" and state_row["breakeven_done"] is True


def test_hedge_stop_replace_uses_side_and_close_position_without_reduce_only(tmp_path):
    ledger = _ready_ledger(tmp_path / "hedge-stop.sqlite")
    _managed(ledger, position_side="LONG")
    client = FakeExecutionClient(dual=True)
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id, "algoStatus": "NEW",
                            "symbol": "BTCUSDT", "orderType": "STOP_MARKET"}
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-hedge-stop", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Trailing stop")

    adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    params = client.new_algo_calls[0]
    assert params["positionSide"] == "LONG"
    assert params["quantity"] == D("1")
    assert "reduceOnly" not in params and "closePosition" not in params


def test_stop_triggered_during_replacement_never_cancels_old_stop(tmp_path):
    ledger = _ready_ledger(tmp_path / "triggered.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id, "algoStatus": "NEW",
                            "symbol": "BTCUSDT", "orderType": "STOP_MARKET"}
    client.next_algo_status = "TRIGGERED"
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-triggered", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Trailing stop")

    result = adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    assert result["status"] == "STOP_TRIGGERED_POSITION_NOT_FLAT"
    assert client.cancel_algo_calls == []
    assert ledger.entries_halted()[0] is True


def test_flat_finalization_cancels_only_linked_orders_and_releases_reservation(tmp_path):
    ledger = _ready_ledger(tmp_path / "flat.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {"algoId": 1, "clientAlgoId": stop_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    client.algos[take_id] = {"algoId": 2, "clientAlgoId": take_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)

    assert adapter.finalize_if_flat("sig-lc") is True
    assert set(client.cancel_algo_calls) == {stop_id, take_id}
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is True
    # A normal exit is per-position; it must not stop entries across all symbols.
    assert ledger.entries_halted()[0] is False
    assert adapter.finalize_if_flat("sig-lc") is True


def test_account_observation_gate_stays_available_when_new_entries_are_halted(tmp_path):
    ledger = _ready_ledger(tmp_path / "halt.sqlite")
    ledger.set_entries_halted(True, "operator stop")
    # The account runtime reports ENTRIES_HALTED even though its exchange snapshot
    # remains consistent. Existing positions must remain manageable in this state.
    ledger.set_reconciliation_state(
        False, status="ENTRIES_HALTED", captured_at_ms=NOW,
        detail={"discrepancies": []}, stream_event_watermark_ms=0,
    )
    ready, reasons = ledger.account_observation_readiness(
        now_ms=NOW, max_reconciliation_age_ms=30_000,
    )
    assert ready is True and reasons == ()


def test_account_observation_gate_rejects_halted_reconciliation_with_mismatch(tmp_path):
    ledger = _ready_ledger(tmp_path / "halt-mismatch.sqlite")
    ledger.set_entries_halted(True, "position mismatch")
    ledger.set_reconciliation_state(
        False, status="BLOCKED_MISMATCH", captured_at_ms=NOW,
        detail={"discrepancies": [{"code": "POSITION_QUANTITY_MISMATCH"}]},
        stream_event_watermark_ms=0,
    )
    ready, reasons = ledger.account_observation_readiness(
        now_ms=NOW, max_reconciliation_age_ms=30_000,
    )
    assert ready is False and "ACCOUNT_NOT_RECONCILED" in reasons


def test_fill_reducer_routes_matching_partial_order_event_to_rest_reconciliation(tmp_path):
    ledger = _ready_ledger(tmp_path / "reducer.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-reducer", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.5"))
    submitted = adapter.submit_partial_take_profit(action, _state(),
                                                    market_step_size=D("0.1"), market_min_qty=D("0.1"))
    order = client.orders[submitted["client_order_id"]]
    order.update(status="FILLED", executedQty="0.5")
    client.positions[0]["positionAmt"] = "0.5"
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)
    result = reducer.handle({"e": "ORDER_TRADE_UPDATE", "o": {"c": submitted["client_order_id"]}})
    assert result["status"] == "CONFIRMED"
    assert reducer.handle({"e": "ACCOUNT_UPDATE", "a": {}}) is None


def test_service_initializes_lifecycle_state_from_confirmed_entry_and_does_not_overwrite(tmp_path):
    ledger = ExecutionLedger(tmp_path / "init-state.sqlite")
    signal = QualifiedSignal(
        signal_id="init-sig", symbol="BTCUSDT", side="LONG", entry_type="MARKET",
        entry_price=D("100"), stop_loss=D("90"), take_profit=D("120"),
        timeframe="M5", strategy_id="SMC_V2", created_at_ms=NOW,
    )
    plan = TradePlan(signal, D("1"), D("100"), D("10"), D("20"), 5, "DIVA-ENTRY")
    ledger.claim_intent(signal_id="init-sig", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVA-ENTRY", payload={})
    service = ExecutionService(ledger, config=ExecutionConfig())
    service._initialize_position_management_state(plan, quantity=D("1"), entry_price=D("101"))
    first = ledger.get_position_management_state("init-sig")
    assert first["state"]["initial_risk_per_unit"] == "11"
    modified = dict(first["state"])
    modified["partial_tp_done"] = True
    ledger.save_position_management_state(signal_id="init-sig", symbol="BTCUSDT",
                                           state=modified, expected_version=first["version"])
    service._initialize_position_management_state(plan, quantity=D("1"), entry_price=D("101"))
    assert ledger.get_position_management_state("init-sig")["state"]["partial_tp_done"] is True



def test_execution_service_initial_protection_is_quantity_scoped_one_way_and_hedge(tmp_path):
    from divatrading.execution.binance_private import BinancePrivateApiError
    from divatrading.trading.models import QualifiedSignal, TradePlan

    class ProtectionClient:
        environment = "TESTNET"
        def __init__(self, dual):
            self.dual = dual
            self.calls = []
            self.orders = {}
            self.queries = []
        def get_position_mode(self):
            return {"dualSidePosition": self.dual}
        def get_algo_order(self, *, algo_id=None, client_algo_id=None):
            self.queries.append(client_algo_id)
            if client_algo_id not in self.orders:
                raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
            return dict(self.orders[client_algo_id])
        def new_algo_order(self, **params):
            self.calls.append(params)
            response = {"algoId": len(self.calls), "clientAlgoId": params["clientAlgoId"],
                        "algoStatus": "NEW", **params}
            self.orders[params["clientAlgoId"]] = response
            return {"algoId": response["algoId"], "clientAlgoId": response["clientAlgoId"],
                    "algoStatus": response["algoStatus"]}

    for dual, position_side in ((False, "BOTH"), (True, "LONG")):
        ledger = ExecutionLedger(tmp_path / f"protection-mode-{dual}.sqlite")
        signal = QualifiedSignal(
            signal_id=f"protection-{dual}", symbol="BTCUSDT", side="LONG", entry_type="MARKET",
            entry_price=D("100"), stop_loss=D("90"), take_profit=D("120"),
            timeframe="M5", strategy_id="SMC_V2", created_at_ms=NOW,
        )
        plan = TradePlan(signal, D("0.25"), D("25"), D("2.5"), D("5"), 5, f"DIVA-ENTRY-{dual}")
        ledger.claim_intent(signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side,
                            client_order_id=plan.client_order_id, payload={})
        client = ProtectionClient(dual)
        service = ExecutionService(
            ledger,
            config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
            client=client,
        )
        stop, take = service._ensure_protection(plan, position_side, quantity=D("0.25"))
        assert stop["algoStatus"] == take["algoStatus"] == "NEW"
        assert len(client.calls) == 2
        assert len(client.queries) == 4  # query-first and post-acknowledgement query per role
        for params in client.calls:
            assert params["quantity"] == D("0.25")
            assert "closePosition" not in params
            assert params["positionSide"] == position_side
            if dual:
                assert "reduceOnly" not in params
            else:
                assert params["reduceOnly"] is True


def test_quantity_scoped_protection_builder_rejects_mode_mismatch():
    from divatrading.execution.protection import build_quantity_scoped_protection_params

    with pytest.raises(ValueError, match="conflicts with mode"):
        build_quantity_scoped_protection_params(
            symbol="BTCUSDT", position_direction="LONG", position_side="LONG",
            dual_side_position=False, order_type="STOP_MARKET", quantity=D("1"),
            trigger_price=D("90"), working_type="MARK_PRICE", price_protect=True,
            client_algo_id="DIVA-STOP",
        )

def test_adapter_load_state_hydrates_decimal_and_optional_fields(tmp_path):
    ledger = _ready_ledger(tmp_path / "load-state.sqlite")
    _managed(ledger)
    adapter = _adapter(ledger, FakeExecutionClient())
    loaded = adapter.load_state("sig-lc")
    assert loaded.quantity == D("1") and loaded.entry_price == D("100")
    assert loaded.favorable_extreme is None


def test_second_stop_replacement_cancels_latest_stop_not_original_id(tmp_path):
    ledger = _ready_ledger(tmp_path / "second-stop.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    original_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[original_id] = {"algoId": 1, "clientAlgoId": original_id,
                                "algoStatus": "NEW", "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    first_action = LifecycleAction("action-stop-1", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                                   stop_price=D("95"), reason="Breakeven")
    first = adapter.replace_stop(first_action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    latest_stop_id = first["client_algo_id"]
    assert latest_stop_id != original_id

    second_action = LifecycleAction("action-stop-2", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                                    stop_price=D("97"), reason="Trailing stop")
    adapter.replace_stop(second_action, adapter.load_state("sig-lc"),
                         tick_size=D("0.1"), mark_price=D("100"))
    assert client.cancel_algo_calls == [original_id, latest_stop_id]
    assert client.algos[latest_stop_id]["algoStatus"] == "CANCELED"


def test_confirmed_stop_duplicate_does_not_query_or_submit_again(tmp_path):
    ledger = _ready_ledger(tmp_path / "duplicate-stop.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id,
                            "algoStatus": "NEW", "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-stop-dup", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Breakeven")
    first = adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    calls = len(client.new_algo_calls)
    duplicate = adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    assert first["status"] == "CONFIRMED"
    assert duplicate["duplicate"] is True
    assert len(client.new_algo_calls) == calls == 1


def test_finalize_does_not_release_reservation_when_position_is_not_flat(tmp_path):
    ledger = _ready_ledger(tmp_path / "not-flat.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.2")
    adapter = _adapter(ledger, client)
    assert adapter.finalize_if_flat("sig-lc") is False
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is False


def test_finalize_recovers_after_closed_position_state_was_persisted_before_release(tmp_path):
    ledger = _ready_ledger(tmp_path / "finalize-recovery.sqlite")
    _managed(ledger)
    # Simulate a crash after local close state is persisted but before risk release.
    row = ledger.get_position_management_state("sig-lc")
    closed = dict(row["state"])
    closed.update(quantity="0", closed=True)
    ledger.save_position_management_state(signal_id="sig-lc", symbol="BTCUSDT", state=closed,
                                           expected_version=row["version"])
    ledger.update_managed_position(signal_id="sig-lc", symbol="BTCUSDT", position_side="BOTH",
                                   quantity="0", status="CLOSED")
    client = FakeExecutionClient(quantity="0")
    adapter = _adapter(ledger, client)
    assert adapter.finalize_if_flat("sig-lc") is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"


def test_initial_take_profit_algo_event_triggers_verified_flat_cleanup(tmp_path):
    ledger = _ready_ledger(tmp_path / "initial-tp-event.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {"algoId": 1, "clientAlgoId": stop_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    client.algos[take_id] = {"algoId": 2, "clientAlgoId": take_id, "algoStatus": "TRIGGERED",
                             "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": take_id, "algoStatus": "TRIGGERED"}})
    assert result == {"signal_id": "sig-lc", "status": "CLOSED_CONFIRMED"}
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"
    # The triggered TP is already terminal; only the still-open SL is canceled.
    assert client.cancel_algo_calls == [stop_id]



def test_initial_protection_new_algo_update_is_not_mistaken_for_a_fill(tmp_path):
    ledger = _ready_ledger(tmp_path / "initial-protection-new-event.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[stop_id] = {"algoId": 1, "clientAlgoId": stop_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "NEW"}})
    assert result is None
    assert ledger.entries_halted()[0] is False
    assert client.cancel_algo_calls == []


def test_triggered_protection_with_residual_quantity_keeps_sibling_order(tmp_path):
    ledger = _ready_ledger(tmp_path / "initial-protection-residual.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.4")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {"algoId": 1, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
                             "symbol": "BTCUSDT"}
    client.algos[take_id] = {"algoId": 2, "clientAlgoId": take_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert result == {"signal_id": "sig-lc", "status": "PROTECTION_EVENT_POSITION_NOT_FLAT"}
    assert client.cancel_algo_calls == []
    assert ledger.entries_halted()[0] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"

def test_account_update_flat_position_triggers_rest_verified_finalization(tmp_path):
    ledger = _ready_ledger(tmp_path / "account-flat-event.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[stop_id] = {"algoId": 1, "clientAlgoId": stop_id, "algoStatus": "NEW",
                             "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ACCOUNT_UPDATE", "a": {"P": [
        {"s": "BTCUSDT", "ps": "BOTH", "pa": "0"},
    ]}})
    assert result == [{"signal_id": "sig-lc", "status": "CLOSED_CONFIRMED"}]
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"


def test_account_runtime_chains_existing_callback_and_lifecycle_reducer(tmp_path):
    import asyncio

    called = []

    class UserStream:
        on_event = lambda self, event: called.append(("prior", event))

    class Reducer:
        def handle(self, event):
            called.append(("reducer", event))

    class Reconciler:
        pass

    from divatrading.execution.account_runtime import ExecutionAccountRuntime
    user_stream = UserStream()
    runtime = ExecutionAccountRuntime(
        user_stream=user_stream, reconciler=Reconciler(), ledger=object(),
        lifecycle_fill_reducer=Reducer(),
    )
    event = {"e": "ACCOUNT_UPDATE"}
    asyncio.run(user_stream.on_event(event))
    assert called == [("prior", event), ("reducer", event)]
    assert runtime.lifecycle_fill_reducer is not None


def test_second_inflight_action_for_same_position_is_blocked_atomically(tmp_path):
    ledger = _ready_ledger(tmp_path / "single-flight.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    adapter = _adapter(ledger, client)
    first = LifecycleAction("action-flight-1", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                            quantity=D("0.5"))
    second = LifecycleAction("action-flight-2", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.4"))
    adapter.submit_partial_take_profit(first, _state(),
                                       market_step_size=D("0.1"), market_min_qty=D("0.1"))
    with pytest.raises(RuntimeError, match="ALREADY_PENDING"):
        adapter.submit_partial_take_profit(second, _state(),
                                           market_step_size=D("0.1"), market_min_qty=D("0.1"))
    assert len(client.new_order_calls) == 1
    assert ledger.entries_halted()[0] is True


def test_stop_post_success_followed_by_query_failure_stays_submitted_for_recovery(tmp_path):
    ledger = _ready_ledger(tmp_path / "stop-recovery.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id,
                            "algoStatus": "NEW", "symbol": "BTCUSDT"}
    client.fail_get_algo = True
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-stop-query-timeout", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Breakeven")

    with pytest.raises(RuntimeError, match="simulated REST query timeout"):
        adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))
    row = ledger.get_position_management_action(action.action_id)
    assert row["status"] == "SUBMITTED"
    assert len(client.new_algo_calls) == 1
    assert client.cancel_algo_calls == []

    client.fail_get_algo = False
    recovered = adapter.recover_pending_actions()
    assert recovered[0]["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 1
    assert client.cancel_algo_calls == [old_id]


def test_stop_replacement_rejects_unowned_old_algo_id(tmp_path):
    ledger = _ready_ledger(tmp_path / "unowned-stop.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-unowned-stop", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Breakeven")

    with pytest.raises(ValueError, match="not a DIVA-managed stop"):
        adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"),
                             old_client_algo_id="MANUAL-USER-STOP")
    assert client.new_algo_calls == []
    assert ledger.get_position_management_action("action-unowned-stop") is None


def test_post_cleanup_verification_error_halts_and_keeps_risk_reservation(tmp_path, monkeypatch):
    ledger = _ready_ledger(tmp_path / "cleanup-verification-error.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    adapter = _adapter(ledger, client)
    original_get_open_orders = client.get_open_orders
    calls = {"count": 0}

    def fail_second_open_orders_query(symbol=None):
        calls["count"] += 1
        if calls["count"] == 2:
            raise RuntimeError("simulated post-cleanup verification timeout")
        return original_get_open_orders(symbol)

    monkeypatch.setattr(client, "get_open_orders", fail_second_open_orders_query)
    with pytest.raises(RuntimeError, match="simulated post-cleanup verification timeout"):
        adapter.finalize_if_flat("sig-lc")

    assert calls["count"] == 2
    assert ledger.entries_halted()[0] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is False


def test_startup_recovery_finalizes_flat_managed_position_and_releases_reservation(tmp_path):
    ledger = _ready_ledger(tmp_path / "startup-flat.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    adapter = _adapter(ledger, client)

    result = adapter.recover_on_startup()

    assert result["actions"] == []
    assert result["positions"] == [{"signal_id": "sig-lc", "status": "CLOSED_CONFIRMED"}]
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is True


def test_startup_recovery_keeps_reservation_when_exchange_position_is_still_open(tmp_path):
    ledger = _ready_ledger(tmp_path / "startup-open.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    adapter = _adapter(ledger, client)

    result = adapter.recover_on_startup()

    assert result["positions"] == []
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is False


def test_account_runtime_runs_lifecycle_recovery_once_per_stream_connection(tmp_path):
    import asyncio
    from types import SimpleNamespace

    ledger = _ready_ledger(tmp_path / "runtime-recovery.sqlite")
    calls = {"recover": 0, "trigger_backfill": 0, "reconcile": 0,
             "supervisor_started": 0, "supervisor_stopped": 0}

    class UserStream:
        on_event = None

        async def run(self, stop_event):
            ledger.set_user_stream_state("CONNECTED", connected_at_ms=NOW,
                                         updated_at_ms=NOW)
            await stop_event.wait()
            ledger.set_user_stream_state("STOPPED", updated_at_ms=NOW + 1)

    class Adapter:
        def recover_on_startup(self):
            calls["recover"] += 1
            return {"actions": [], "positions": []}

    class Reducer:
        adapter = Adapter()

        def handle(self, event):
            return None

        def recover_triggered_protections_from_rest(self):
            calls["trigger_backfill"] += 1
            return []

    class Reconciler:
        def reconcile(self):
            calls["reconcile"] += 1
            return None

    class PositionSupervisor:
        async def run(self, stop_event):
            calls["supervisor_started"] += 1
            await stop_event.wait()

        async def stop(self):
            calls["supervisor_stopped"] += 1

    from divatrading.execution.account_runtime import (
        AccountRuntimeConfig, ExecutionAccountRuntime,
    )
    runtime = ExecutionAccountRuntime(
        user_stream=UserStream(), reconciler=Reconciler(), ledger=ledger,
        config=AccountRuntimeConfig(reconciliation_interval_seconds=0.01,
                                    disconnected_poll_seconds=0.005),
        lifecycle_fill_reducer=Reducer(),
        position_supervisor=PositionSupervisor(),
    )

    async def run_runtime():
        stop = asyncio.Event()
        asyncio.get_running_loop().call_later(0.04, stop.set)
        await runtime.run(stop)

    asyncio.run(run_runtime())
    assert calls["recover"] == 1
    assert calls["trigger_backfill"] == 1
    assert calls["reconcile"] >= 1
    assert calls["supervisor_started"] == 1
    assert calls["supervisor_stopped"] == 1


def test_stop_replacement_detects_position_flat_race_after_new_stop_submission(tmp_path, monkeypatch):
    ledger = _ready_ledger(tmp_path / "stop-flat-race.sqlite")
    _managed(ledger)
    client = FakeExecutionClient()
    old_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    client.algos[old_id] = {"algoId": 1, "clientAlgoId": old_id,
                            "algoStatus": "NEW", "symbol": "BTCUSDT"}
    adapter = _adapter(ledger, client)
    original_position_quantity = adapter._position_quantity
    calls = {"count": 0}

    def flat_after_post(symbol, side, dual_side):
        calls["count"] += 1
        if calls["count"] >= 3:
            client.positions[0]["positionAmt"] = "0"
            return D("0")
        return original_position_quantity(symbol, side, dual_side)

    monkeypatch.setattr(adapter, "_position_quantity", flat_after_post)
    action = LifecycleAction("action-stop-flat-race", "MOVE_STOP", "sig-lc", "BTCUSDT", "LONG",
                             stop_price=D("95"), reason="Breakeven")
    result = adapter.replace_stop(action, _state(), tick_size=D("0.1"), mark_price=D("100"))

    assert result["status"] == "STOP_TRIGGERED_POSITION_FLAT"
    assert result["finalized"] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"
    assert ledger.get_position_management_action(action.action_id)["status"] == "STOP_TRIGGERED_POSITION_FLAT"
    assert set(client.cancel_algo_calls) == {old_id, _client_id_for_test(action.action_id)}


def _client_id_for_test(action_id):
    import hashlib
    return "DIVASL" + hashlib.sha256(action_id.encode("utf-8")).hexdigest()[:24].upper()


@pytest.mark.parametrize(
    ("dual", "position_side", "reduce_only", "actual_status"),
    [(False, "BOTH", True, "CANCELED"), (True, "LONG", False, "PARTIALLY_FILLED")],
)
def test_protective_algo_partial_fill_uses_actual_order_id_and_resizes_both_protections(
    tmp_path, dual, position_side, reduce_only, actual_status,
):
    ledger = _ready_ledger(tmp_path / f"protective-partial-{position_side}.sqlite")
    _managed(ledger, position_side=position_side)
    ledger.record_order(
        client_id="DIVAENTRY-PROTECTIVE-TEST", signal_id="sig-lc", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=700,
        payload={"symbol": "BTCUSDT", "positionSide": position_side},
    )
    from divatrading.execution.user_data_stream import UserDataStreamProcessor
    fill_processor = UserDataStreamProcessor(ledger, clock_ms=lambda: NOW + 10)
    fill_processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 10, "T": 10,
        "o": {"s": "BTCUSDT", "c": "DIVAENTRY-PROTECTIVE-TEST", "i": 700,
              "S": "BUY", "ps": position_side, "x": "TRADE", "X": "FILLED",
              "l": "1", "L": "100", "t": 700, "n": "0.001", "N": "BNB", "rp": "0"},
    })
    client = FakeExecutionClient(dual=dual, quantity="0.4")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 701, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "777",
    }
    client.algos[take_id] = {
        "algoId": 702, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": position_side,
        "type": "TAKE_PROFIT_MARKET",
    }
    actual_order = {
        "orderId": 777, "clientOrderId": "autoclose-777", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": position_side, "status": actual_status,
        "executedQty": "0.6", "origQty": "1", "reduceOnly": reduce_only,
        "closePosition": False, "type": "MARKET",
    }
    client.orders["autoclose-777"] = actual_order
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    assert result["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert result["actual_order_id"] == "777"
    assert result["executed_quantity"] == "0.6"
    assert result["residual_quantity"] == "0.4"
    assert result["protection_resize"]["status"] == "CONFIRMED"
    managed = ledger.list_managed_positions(status="OPEN")[0]
    assert managed["quantity"] == "0.4"
    state = ledger.get_position_management_state("sig-lc")["state"]
    assert state["quantity"] == "0.4"
    assert state["stop_algo_client_id"] != stop_id
    assert state["take_profit_algo_client_id"] != take_id
    assert client.cancel_algo_calls == [take_id]
    assert client.cancel_order_calls == (["777"] if actual_status == "PARTIALLY_FILLED" else [])
    assert len(client.new_algo_calls) == 2
    assert all(str(call["quantity"]) == "0.4" for call in client.new_algo_calls)

    trigger_action_id = f"protective-trigger:sig-lc:{stop_id}"
    trigger_action = ledger.get_position_management_action(trigger_action_id)
    assert trigger_action["status"] == "CONFIRMED"
    assert trigger_action["payload"]["actual_order_id"] == "777"
    with ledger._connection() as db:
        linked = db.execute(
            "SELECT signal_id,role,effect FROM execution_exchange_order_links "
            "WHERE symbol='BTCUSDT' AND exchange_order_id='777'"
        ).fetchone()
    assert tuple(linked) == ("sig-lc", "STOP_LOSS", "CLOSE")
    assert ledger.entries_halted()[0] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    # A later trade event whose client ID differs is attributed by actualOrderId.
    fill_processor.process({
        "e": "ORDER_TRADE_UPDATE", "E": 20, "T": 20,
        "o": {"s": "BTCUSDT", "c": "exchange-generated-client-id", "i": 777,
              "S": "SELL", "ps": position_side, "x": "TRADE", "X": "FILLED",
              "l": "0.6", "L": "90", "t": 778, "n": "0.002", "N": "BNB", "rp": "6.0"},
    })
    projection = ledger.get_position_fill_projection("sig-lc")
    assert projection["net_quantity"] == "0.4"
    assert projection["commissions"]["BNB"] == "0.003"
    assert projection["realized_pnl"]["USDT"] == "6.0"

    # Replayed ALGO_UPDATE is a durable no-op and cannot submit duplicate protections.
    duplicate = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert duplicate["duplicate"] is True
    assert len(client.new_algo_calls) == 2
    assert client.cancel_algo_calls == [take_id]


def test_protective_algo_uses_final_executed_quantity_after_cancel_race(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-cancel-race.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.4")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 790, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "7790",
    }
    client.algos[take_id] = {
        "algoId": 791, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-7790"] = {
        "orderId": 7790, "clientOrderId": "autoclose-7790", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "PARTIALLY_FILLED",
        "executedQty": "0.4", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    original_cancel = client.cancel_order

    def cancel_with_fill_race(symbol, *, order_id=None, client_order_id=None):
        # Simulate an additional 0.2 fill between the initial GET and cancel ack.
        order = original_cancel(symbol, order_id=order_id, client_order_id=client_order_id)
        order["executedQty"] = "0.6"
        client.orders["autoclose-7790"]["executedQty"] = "0.6"
        client.positions[0]["positionAmt"] = "0.4"
        return dict(client.orders["autoclose-7790"])

    client.cancel_order = cancel_with_fill_race
    reducer = PositionLifecycleFillReducer(adapter=_adapter(ledger, client), ledger=ledger)

    # The stream payload is deliberately stale/out-of-order. REST after cancellation wins.
    result = reducer.handle({"e": "ALGO_UPDATE", "o": {
        "caid": stop_id, "algoStatus": "TRIGGERED", "aq": "0.8",
    }})

    assert result["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert result["executed_quantity"] == "0.6"
    assert result["residual_quantity"] == "0.4"
    action = ledger.get_position_management_action(f"protective-trigger:sig-lc:{stop_id}")
    assert action["payload"]["initial_actual_executed_quantity"] == "0.4"
    assert action["payload"]["final_executed_quantity"] == "0.6"
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "0.4"
    assert len(client.new_algo_calls) == 2
    assert all(call["quantity"] == D("0.4") for call in client.new_algo_calls)


def test_protective_trigger_with_zero_fill_reprotects_unchanged_position_once(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-zero-fill.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 792, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "7792",
    }
    client.algos[take_id] = {
        "algoId": 793, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-7792"] = {
        "orderId": 7792, "clientOrderId": "autoclose-7792", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "NEW",
        "executedQty": "0", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    reducer = PositionLifecycleFillReducer(
        adapter=_adapter(ledger, client), ledger=ledger, enable_zero_fill_reprotection=True,
    )

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    assert result["status"] == "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTED"
    assert result["executed_quantity"] == "0"
    assert result["residual_quantity"] == "1"
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "1"
    assert ledger.list_managed_positions(status="OPEN")[0]["quantity"] == "1"
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    state = ledger.get_position_management_state("sig-lc")["state"]
    assert state["stop_algo_client_id"] != stop_id
    assert state["take_profit_algo_client_id"] != take_id
    assert len(client.new_algo_calls) == 2
    assert client.cancel_algo_calls == [take_id]
    assert len(client.cancel_order_calls) == 1
    assert ledger.entries_halted()[0] is True

    duplicate = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert duplicate["status"] == "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTED"
    assert duplicate["duplicate"] is True
    assert len(client.new_algo_calls) == 2


def test_protective_trigger_zero_fill_does_not_reprotect_without_explicit_opt_in(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-zero-fill-disabled.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 798, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "7798",
    }
    client.algos[take_id] = {
        "algoId": 799, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-7798"] = {
        "orderId": 7798, "clientOrderId": "autoclose-7798", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "CANCELED",
        "executedQty": "0", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    reducer = PositionLifecycleFillReducer(adapter=_adapter(ledger, client), ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    assert result["status"] == "PROTECTIVE_TRIGGER_NO_FILL_REPROTECTION_DISABLED"
    assert result["automatic_recovery"] is False
    assert client.new_algo_calls == []
    assert client.cancel_algo_calls == []
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "1"
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_position_management_action(f"protective-trigger:sig-lc:{stop_id}")["status"] ==         "PROTECTIVE_TRIGGER_RECONCILIATION_PENDING"
    assert ledger.entries_halted()[0] is True


def test_startup_rest_backfill_reconciles_triggered_protection_after_stream_gap(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-rest-backfill.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.4")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 794, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "7794",
    }
    client.algos[take_id] = {
        "algoId": 795, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-7794"] = {
        "orderId": 7794, "clientOrderId": "autoclose-7794", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "CANCELED",
        "executedQty": "0.6", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    reducer = PositionLifecycleFillReducer(adapter=_adapter(ledger, client), ledger=ledger)

    # No ALGO_UPDATE was recorded. Startup scan discovers the triggered Algo via REST.
    results = reducer.recover_triggered_protections_from_rest()

    assert len(results) == 1
    assert results[0]["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert results[0]["evidence"] == "REST_QUERY"
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "0.4"
    assert len(client.new_algo_calls) == 2
    assert ledger.entries_halted()[0] is True


def test_protective_trigger_cancel_ambiguity_recovers_from_final_rest_state_without_repost(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-cancel-ambiguous.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.5")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 796, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "7796",
    }
    client.algos[take_id] = {
        "algoId": 797, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-7796"] = {
        "orderId": 7796, "clientOrderId": "autoclose-7796", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "PARTIALLY_FILLED",
        "executedQty": "0.5", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    original_cancel = client.cancel_order

    def cancel_but_lose_ack(symbol, *, order_id=None, client_order_id=None):
        original_cancel(symbol, order_id=order_id, client_order_id=client_order_id)
        client.orders["autoclose-7796"]["executedQty"] = "0.5"
        client.positions[0]["positionAmt"] = "0.5"
        raise RuntimeError("simulated cancel response lost after exchange cancellation")

    client.cancel_order = cancel_but_lose_ack
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)
    action_id = f"protective-trigger:sig-lc:{stop_id}"

    with pytest.raises(RuntimeError, match="simulated cancel response lost"):
        reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    pending = ledger.get_position_management_action(action_id)
    assert pending["status"] == "PROTECTIVE_TRIGGER_RECONCILIATION_PENDING"
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "1"
    assert client.new_algo_calls == []

    # Restart recovery queries the now-terminal child order and does not cancel or
    # submit a second time. The final REST executedQty determines the residual.
    client.cancel_order = original_cancel
    recovered = adapter.reconcile_protective_trigger(action_id)
    assert recovered["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert recovered["executed_quantity"] == "0.5"
    assert recovered["residual_quantity"] == "0.5"
    assert len(client.cancel_order_calls) == 1
    assert len(client.new_algo_calls) == 2
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "0.5"
    assert ledger.get_position_management_action(action_id)["status"] == "CONFIRMED"


def test_protective_algo_partial_fill_mismatch_never_resizes_or_mutates_local_quantity(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-partial-mismatch.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0.5")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 801, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "888",
    }
    client.algos[take_id] = {
        "algoId": 802, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-888"] = {
        "orderId": 888, "clientOrderId": "autoclose-888", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "CANCELED",
        "executedQty": "0.6", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }
    reducer = PositionLifecycleFillReducer(adapter=_adapter(ledger, client), ledger=ledger)

    with pytest.raises(RuntimeError, match="PROTECTIVE_TRIGGER_RESIDUAL_QUANTITY_MISMATCH"):
        reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert ledger.get_position_management_state("sig-lc")["state"]["quantity"] == "1"
    assert ledger.list_managed_positions(status="OPEN")[0]["quantity"] == "1"
    assert client.new_algo_calls == []
    assert client.cancel_algo_calls == []
    assert ledger.entries_halted()[0] is True


@pytest.mark.parametrize(("dual", "position_side", "reduce_only"),
                         [(False, "BOTH", True), (True, "LONG", False)])
def test_protective_algo_full_fill_closes_only_its_lot_when_sibling_remains(
    tmp_path, dual, position_side, reduce_only,
):
    ledger = _ready_ledger(tmp_path / f"protective-full-lot-with-sibling-{position_side}.sqlite")
    _managed(ledger, signal_id="sig-lc", position_side=position_side)
    _managed(ledger, signal_id="sig-sibling", position_side=position_side)
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    sibling_stop = ledger.deterministic_client_id("sig-sibling", "STOP_LOSS")
    sibling_take = ledger.deterministic_client_id("sig-sibling", "TAKE_PROFIT")
    client = FakeExecutionClient(dual=dual, quantity="1")  # sibling lot remains after sig-lc exits
    client.algos[stop_id] = {
        "algoId": 901, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "999",
    }
    client.algos[take_id] = {
        "algoId": 902, "clientAlgoId": take_id, "algoStatus": "NEW", "symbol": "BTCUSDT",
    }
    client.algos[sibling_stop] = {
        "algoId": 903, "clientAlgoId": sibling_stop, "algoStatus": "NEW", "symbol": "BTCUSDT",
    }
    client.algos[sibling_take] = {
        "algoId": 904, "clientAlgoId": sibling_take, "algoStatus": "NEW", "symbol": "BTCUSDT",
    }
    client.orders["autoclose-999"] = {
        "orderId": 999, "clientOrderId": "autoclose-999", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": position_side, "status": "FILLED",
        "executedQty": "1", "origQty": "1", "reduceOnly": reduce_only, "closePosition": False,
        "type": "MARKET",
    }
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    assert result["status"] == "PROTECTIVE_LOT_CLOSED"
    assert result["lot_closed"] is True
    assert result["aggregate_position_quantity"] == "1"
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"
    assert ledger.get_position_management_state("sig-sibling")["state"]["closed"] is False
    assert ledger.get_risk_reservation("sig-sibling")["status"] == "ACTIVE"
    assert client.cancel_algo_calls == [take_id]
    duplicate = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert duplicate["status"] == "PROTECTIVE_LOT_CLOSED" and duplicate["duplicate"] is True


def test_account_update_flat_aggregate_finalizes_all_signal_lots_and_orders(tmp_path):
    ledger = _ready_ledger(tmp_path / "account-flat-multi-lot.sqlite")
    _managed(ledger, signal_id="sig-lc")
    _managed(ledger, signal_id="sig-sibling")
    client = FakeExecutionClient(quantity="0")
    expected_cancelled = set()
    for index, signal_id in enumerate(("sig-lc", "sig-sibling"), start=1):
        for role in ("STOP_LOSS", "TAKE_PROFIT"):
            client_id = ledger.deterministic_client_id(signal_id, role)
            expected_cancelled.add(client_id)
            client.algos[client_id] = {
                "algoId": 910 + index, "clientAlgoId": client_id,
                "algoStatus": "NEW", "symbol": "BTCUSDT",
            }
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ACCOUNT_UPDATE", "a": {"P": [
        {"s": "BTCUSDT", "ps": "BOTH", "pa": "0"},
    ]}})

    assert [item["status"] for item in result] == ["CLOSED_CONFIRMED", "CLOSED_CONFIRMED"]
    assert {item["signal_id"] for item in result} == {"sig-lc", "sig-sibling"}
    for signal_id in ("sig-lc", "sig-sibling"):
        assert ledger.get_position_management_state(signal_id)["state"]["closed"] is True
        assert ledger.get_risk_reservation(signal_id)["status"] == "RELEASED"
    assert set(client.cancel_algo_calls) == expected_cancelled


def test_protective_partial_fill_resizes_only_its_lot_with_sibling_aggregate_open(tmp_path):
    ledger = _ready_ledger(tmp_path / "protective-partial-lot-with-sibling.sqlite")
    _managed(ledger, signal_id="sig-lc")
    _managed(ledger, signal_id="sig-sibling")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client = FakeExecutionClient(quantity="1.4")  # 0.6 closed from sig-lc; sibling remains 1.0
    client.algos[stop_id] = {
        "algoId": 951, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "1051",
    }
    client.algos[take_id] = {
        "algoId": 952, "clientAlgoId": take_id, "algoStatus": "NEW", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "type": "TAKE_PROFIT_MARKET",
    }
    client.orders["autoclose-1051"] = {
        "orderId": 1051, "clientOrderId": "autoclose-1051", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "CANCELED",
        "executedQty": "0.6", "origQty": "1", "reduceOnly": True, "closePosition": False,
        "type": "MARKET",
    }
    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})

    assert result["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert result["residual_quantity"] == "0.4"
    assert result["aggregate_position_quantity"] == "1.4"
    quantities = {row["signal_id"]: row["quantity"]
                  for row in ledger.list_managed_positions(status="OPEN")}
    assert quantities == {"sig-lc": "0.4", "sig-sibling": "1"}
    assert len(client.new_algo_calls) == 2
    assert {str(item["quantity"]) for item in client.new_algo_calls} == {"0.4"}
    assert client.get_open_algo_orders("BTCUSDT")
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_risk_reservation("sig-sibling")["status"] == "ACTIVE"


def test_d4_multilot_trigger_child_rest_fill_backfill_restart_and_flat_finalization(tmp_path):
    """End-to-end deterministic simulation across stream gap and child-order backfill."""
    ledger = _ready_ledger(tmp_path / "d4-full-lifecycle.sqlite")
    _managed(ledger, signal_id="sig-lc")
    _managed(ledger, signal_id="sig-sibling")

    # Persist the entry order ownership before a stream-gap recovery; the later
    # userTrades page will include both entry fills and the triggered child fill.
    for signal_id, entry_order_id in (("sig-lc", 8001), ("sig-sibling", 8002)):
        entry_client_id = ledger.deterministic_client_id(signal_id, "ENTRY")
        ledger.record_order(
            client_id=entry_client_id, signal_id=signal_id, symbol="BTCUSDT",
            role="ENTRY", order_kind="STANDARD", status="FILLED",
            exchange_order_id=entry_order_id, payload={"positionSide": "BOTH"},
        )

    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    sibling_stop = ledger.deterministic_client_id("sig-sibling", "STOP_LOSS")
    sibling_take = ledger.deterministic_client_id("sig-sibling", "TAKE_PROFIT")
    client = FakeExecutionClient(quantity="1.4")
    client.algos[stop_id] = {
        "algoId": 951, "clientAlgoId": stop_id, "algoStatus": "TRIGGERED",
        "symbol": "BTCUSDT", "actualOrderId": "1051",
    }
    client.algos[take_id] = {
        "algoId": 952, "clientAlgoId": take_id, "algoStatus": "NEW",
        "symbol": "BTCUSDT", "side": "SELL", "positionSide": "BOTH",
        "type": "TAKE_PROFIT_MARKET",
    }
    client.algos[sibling_stop] = {
        "algoId": 953, "clientAlgoId": sibling_stop, "algoStatus": "NEW", "symbol": "BTCUSDT",
    }
    client.algos[sibling_take] = {
        "algoId": 954, "clientAlgoId": sibling_take, "algoStatus": "NEW", "symbol": "BTCUSDT",
    }
    client.orders["autoclose-1051"] = {
        "orderId": 1051, "clientOrderId": "autoclose-1051", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "status": "CANCELED",
        "executedQty": "0.6", "origQty": "1", "reduceOnly": True,
        "closePosition": False, "type": "MARKET",
    }

    adapter = _adapter(ledger, client)
    reducer = PositionLifecycleFillReducer(adapter=adapter, ledger=ledger)

    # The ALGO_UPDATE is the first observation after a private-stream gap. REST
    # determines the 0.6 child fill; only sig-lc is resized to 0.4 and sig-sibling
    # remains at 1.0 with its original protection.
    result = reducer.handle({"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}})
    assert result["status"] == "PROTECTIVE_PARTIAL_FILL_RESIZED"
    assert result["residual_quantity"] == "0.4"
    assert result["aggregate_position_quantity"] == "1.4"

    # The child order is linked by its exact REST-verified actualOrderId. This is
    # the ownership bridge needed when the later trade history has no DIVA client ID.
    linked = ledger.get_exchange_order_link(symbol="BTCUSDT", exchange_order_id=1051)
    assert linked is not None
    assert (linked["signal_id"], linked["role"], linked["effect"]) == (
        "sig-lc", "STOP_LOSS", "CLOSE",
    )
    # Exact duplicate ownership is idempotent; a competing lot cannot steal it.
    ledger.link_exchange_order_to_signal(
        symbol="BTCUSDT", exchange_order_id=1051, client_order_id=stop_id,
        signal_id="sig-lc", position_side="BOTH", role="STOP_LOSS",
    )
    with pytest.raises(RuntimeError, match="EXCHANGE_ORDER_ID_OWNERSHIP_CONFLICT"):
        ledger.link_exchange_order_to_signal(
            symbol="BTCUSDT", exchange_order_id=1051, client_order_id=stop_id,
            signal_id="sig-sibling", position_side="BOTH", role="STOP_LOSS",
        )
    assert ledger.get_exchange_order_link(
        symbol="BTCUSDT", exchange_order_id=1051,
    )["signal_id"] == "sig-lc"

    class StaticTradesClient:
        def get_user_trades(self, symbol, **params):
            assert symbol == "BTCUSDT"
            return [
                {"symbol": "BTCUSDT", "id": 1, "orderId": 8001, "price": "100",
                 "qty": "1", "commission": "0.001", "commissionAsset": "USDT",
                 "realizedPnl": "0", "side": "BUY", "positionSide": "BOTH",
                 "time": NOW + 1, "maker": False},
                {"symbol": "BTCUSDT", "id": 2, "orderId": 8002, "price": "100",
                 "qty": "1", "commission": "0.001", "commissionAsset": "USDT",
                 "realizedPnl": "0", "side": "BUY", "positionSide": "BOTH",
                 "time": NOW + 2, "maker": False},
                {"symbol": "BTCUSDT", "id": 3, "orderId": 1051, "price": "90",
                 "qty": "0.6", "commission": "0.0006", "commissionAsset": "USDT",
                 "realizedPnl": "-6", "side": "SELL", "positionSide": "BOTH",
                 "time": NOW + 3, "maker": False},
            ]

    backfill = BinanceUserTradesBackfillService(
        client=StaticTradesClient(), ledger=ledger,
        clock_ms=lambda: NOW + 100, sleep=lambda _: None, request_pause_seconds=0,
    )
    history = backfill.backfill_symbol("BTCUSDT", start_time_ms=NOW)
    assert history.inserted_trades == 3
    projections = {item["signal_id"]: item for item in ledger.list_position_fill_projections()}
    assert D(projections["sig-lc"]["entry_quantity"]) == D("1")
    assert D(projections["sig-lc"]["close_quantity"]) == D("0.6")
    assert D(projections["sig-lc"]["net_quantity"]) == D("0.4")
    assert D(projections["sig-lc"]["realized_pnl"]["USDT"]) == D("-6")
    assert D(projections["sig-sibling"]["net_quantity"]) == D("1")
    assert D(projections["sig-lc"]["net_quantity"]) + D(
        projections["sig-sibling"]["net_quantity"]
    ) == D("1.4")
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_risk_reservation("sig-sibling")["status"] == "ACTIVE"

    # Process restart: a duplicate/late ALGO_UPDATE resolves the same durable action
    # and cannot create another pair of residual protections or release either risk.
    before_posts = len(client.new_algo_calls)
    restarted_reducer = PositionLifecycleFillReducer(adapter=_adapter(ledger, client), ledger=ledger)
    duplicate = restarted_reducer.handle(
        {"e": "ALGO_UPDATE", "o": {"caid": stop_id, "algoStatus": "TRIGGERED"}}
    )
    assert duplicate["duplicate"] is True
    assert len(client.new_algo_calls) == before_posts

    # Later the sibling lot closes too. The aggregate ACCOUNT_UPDATE is the flat
    # signal; the lifecycle adapter cancels only DIVA-linked protections and releases
    # each lot's reservation after the REST position confirms zero.
    client.positions[0]["positionAmt"] = "0"
    flat = restarted_reducer.handle({"e": "ACCOUNT_UPDATE", "a": {"P": [
        {"s": "BTCUSDT", "ps": "BOTH", "pa": "0"},
    ]}})
    assert {item["signal_id"] for item in flat} == {"sig-lc", "sig-sibling"}
    assert all(item["status"] == "CLOSED_CONFIRMED" for item in flat)
    for signal_id in ("sig-lc", "sig-sibling"):
        assert ledger.get_position_management_state(signal_id)["state"]["closed"] is True
        assert ledger.get_risk_reservation(signal_id)["status"] == "RELEASED"


def test_partial_take_profit_reduces_and_resizes_only_one_signal_lot(tmp_path):
    ledger = _ready_ledger(tmp_path / "partial-tp-multi-lot.sqlite")
    _managed(ledger, signal_id="sig-lc")
    _managed(ledger, signal_id="sig-sibling")
    client = FakeExecutionClient(quantity="2")
    stop_id = ledger.deterministic_client_id("sig-lc", "STOP_LOSS")
    take_id = ledger.deterministic_client_id("sig-lc", "TAKE_PROFIT")
    client.algos[stop_id] = {
        "algoId": 1101, "clientAlgoId": stop_id, "algoStatus": "NEW", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "type": "STOP_MARKET",
        "quantity": "1", "reduceOnly": True, "closePosition": False,
    }
    client.algos[take_id] = {
        "algoId": 1102, "clientAlgoId": take_id, "algoStatus": "NEW", "symbol": "BTCUSDT",
        "side": "SELL", "positionSide": "BOTH", "type": "TAKE_PROFIT_MARKET",
        "quantity": "1", "reduceOnly": True, "closePosition": False,
    }
    adapter = _adapter(ledger, client)
    action = LifecycleAction("action-multi-lot-partial", "PARTIAL_TP", "sig-lc", "BTCUSDT", "LONG",
                             quantity=D("0.5"), reason="Reached 1R")
    submitted = adapter.submit_partial_take_profit(
        action, _state(), market_step_size=D("0.1"), market_min_qty=D("0.1"),
    )
    client.orders[submitted["client_order_id"]].update(
        status="FILLED", executedQty="0.5", origQty="0.5",
    )
    client.positions[0]["positionAmt"] = "1.5"

    result = adapter.confirm_partial_take_profit(action.action_id)

    assert result["status"] == "CONFIRMED"
    quantities = {row["signal_id"]: row["quantity"]
                  for row in ledger.list_managed_positions(status="OPEN")}
    assert quantities == {"sig-lc": "0.5", "sig-sibling": "1"}
    assert len(client.new_algo_calls) == 2
    assert {str(item["quantity"]) for item in client.new_algo_calls} == {"0.5"}
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.get_risk_reservation("sig-sibling")["status"] == "ACTIVE"


def test_quantity_scoped_protection_validator_checks_symbol_client_id_and_trigger():
    from divatrading.execution.protection import is_quantity_scoped_order_valid

    order = {
        "symbol": "BTCUSDT", "clientAlgoId": "DIVASL-EXACT", "algoStatus": "NEW",
        "type": "STOP_MARKET", "side": "SELL", "positionSide": "BOTH",
        "quantity": "0.25", "triggerPrice": "90", "reduceOnly": True,
        "closePosition": False,
    }
    expected = dict(
        expected_quantity=D("0.25"), dual_side_position=False,
        expected_position_side="BOTH", expected_order_side="SELL",
        expected_type="STOP_MARKET", expected_symbol="BTCUSDT",
        expected_client_algo_id="DIVASL-EXACT", expected_trigger_price=D("90"),
    )
    assert is_quantity_scoped_order_valid(order, **expected)
    assert not is_quantity_scoped_order_valid(order, **{**expected, "expected_symbol": "ETHUSDT"})
    assert not is_quantity_scoped_order_valid(order, **{**expected, "expected_client_algo_id": "DIVASL-OTHER"})
    assert not is_quantity_scoped_order_valid(order, **{**expected, "expected_trigger_price": D("89.9")})


def test_existing_ledger_protection_is_requeried_and_mismatch_halts_without_repost(tmp_path):
    from divatrading.execution.binance_private import BinancePrivateApiError
    from divatrading.trading.models import QualifiedSignal, TradePlan

    class ExistingProtectionClient:
        environment = "TESTNET"
        def __init__(self, orders):
            self.orders = orders
            self.new_calls = []
            self.queries = []
        def get_position_mode(self):
            return {"dualSidePosition": False}
        def get_algo_order(self, *, algo_id=None, client_algo_id=None):
            self.queries.append(client_algo_id)
            if client_algo_id not in self.orders:
                raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
            return dict(self.orders[client_algo_id])
        def new_algo_order(self, **params):
            self.new_calls.append(params)
            raise AssertionError("existing recorded protection must not be blindly reposted")

    ledger = ExecutionLedger(tmp_path / "recorded-protection-mismatch.sqlite")
    signal = QualifiedSignal(
        signal_id="recorded-protection", symbol="BTCUSDT", side="LONG", entry_type="MARKET",
        entry_price=D("100"), stop_loss=D("90"), take_profit=D("120"),
        timeframe="M5", strategy_id="SMC_V2", created_at_ms=NOW,
    )
    plan = TradePlan(signal, D("0.25"), D("25"), D("2.5"), D("5"), 5, "DIVA-ENTRY-RECORDED")
    ledger.claim_intent(signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side,
                        client_order_id=plan.client_order_id, payload={})
    stop_id = ledger.deterministic_client_id(signal.signal_id, "STOP_LOSS")
    ledger.record_order(
        client_id=stop_id, signal_id=signal.signal_id, symbol="BTCUSDT", role="STOP_LOSS",
        order_kind="ALGO", status="NEW", exchange_order_id=11,
        payload={"symbol": "BTCUSDT", "clientAlgoId": stop_id},
    )
    client = ExistingProtectionClient({
        stop_id: {
            "algoId": 11, "clientAlgoId": stop_id, "symbol": "BTCUSDT",
            "algoStatus": "NEW", "type": "STOP_MARKET", "side": "SELL",
            "positionSide": "BOTH", "quantity": "0.25", "triggerPrice": "89",
            "reduceOnly": True, "closePosition": False,
        }
    })
    service = ExecutionService(
        ledger,
        config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True,
                               enable_testnet_stage_c=True),
        client=client,
    )
    with pytest.raises(RuntimeError, match="PROTECTION_ORDER_MISMATCH:STOP_LOSS"):
        service._ensure_protection(plan, "BOTH", quantity=D("0.25"))
    assert client.queries == [stop_id]
    assert client.new_calls == []
    assert ledger.entries_halted()[0] is True


def test_existing_recorded_but_missing_protection_halts_without_blind_repost(tmp_path):
    from divatrading.execution.binance_private import BinancePrivateApiError
    from divatrading.trading.models import QualifiedSignal, TradePlan

    class MissingProtectionClient:
        environment = "TESTNET"
        def __init__(self):
            self.new_calls = []
        def get_position_mode(self):
            return {"dualSidePosition": False}
        def get_algo_order(self, *, algo_id=None, client_algo_id=None):
            raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
        def new_algo_order(self, **params):
            self.new_calls.append(params)
            raise AssertionError("missing recorded protection must fail closed")

    ledger = ExecutionLedger(tmp_path / "recorded-protection-missing.sqlite")
    signal = QualifiedSignal(
        signal_id="missing-protection", symbol="BTCUSDT", side="LONG", entry_type="MARKET",
        entry_price=D("100"), stop_loss=D("90"), take_profit=D("120"),
        timeframe="M5", strategy_id="SMC_V2", created_at_ms=NOW,
    )
    plan = TradePlan(signal, D("0.25"), D("25"), D("2.5"), D("5"), 5, "DIVA-ENTRY-MISSING")
    ledger.claim_intent(signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side,
                        client_order_id=plan.client_order_id, payload={})
    stop_id = ledger.deterministic_client_id(signal.signal_id, "STOP_LOSS")
    ledger.record_order(
        client_id=stop_id, signal_id=signal.signal_id, symbol="BTCUSDT", role="STOP_LOSS",
        order_kind="ALGO", status="NEW", exchange_order_id=12,
        payload={"symbol": "BTCUSDT", "clientAlgoId": stop_id},
    )
    client = MissingProtectionClient()
    service = ExecutionService(
        ledger,
        config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True,
                               enable_testnet_stage_c=True),
        client=client,
    )
    with pytest.raises(RuntimeError, match="PROTECTION_ORDER_MISSING_REQUIRES_POSITION_RECONCILIATION"):
        service._ensure_protection(plan, "BOTH", quantity=D("0.25"))
    assert client.new_calls == []
    halted, reason = ledger.entries_halted()
    assert halted and reason.startswith("PROTECTION_ORDER_MISSING:")


def _set_missing_protection_reconciliation(ledger, gaps):
    stream = ledger.get_user_stream_state()
    watermark = int(stream.get("last_event_at_ms") or 0)
    discrepancies = [
        {
            "code": "POSITION_MISSING_PROTECTION",
            "symbol": "BTCUSDT",
            "side": "LONG",
            "signal_id": signal_id,
            "role": role,
        }
        for signal_id, role in gaps
    ]
    ledger.set_reconciliation_state(
        False,
        status="BLOCKED_MISMATCH",
        captured_at_ms=NOW,
        detail={
            "snapshot_is_sequential_rest": True,
            "event_during_snapshot": False,
            "discrepancies": discrepancies,
        },
        stream_event_watermark_ms=watermark,
    )
    ledger.set_entries_halted(True, "ACCOUNT_RECONCILIATION_MISMATCH")


def _seed_protection_algo(client, ledger, signal_id, role, *, status="NEW", quantity="1",
                          trigger=None, actual_order_id=None, executed_qty="0"):
    state = ledger.get_position_management_state(signal_id)["state"]
    managed = next(row for row in ledger.list_managed_positions(status="OPEN")
                   if row["signal_id"] == signal_id)
    if role == "STOP_LOSS":
        client_id = state["stop_algo_client_id"]
        order_type = "STOP_MARKET"
        trigger = str(trigger if trigger is not None else state["current_stop"])
    else:
        client_id = state["take_profit_algo_client_id"]
        order_type = "TAKE_PROFIT_MARKET"
        trigger = str(trigger if trigger is not None else managed["take_profit"])
    row = {
        "algoId": 500 + len(client.algos),
        "clientAlgoId": client_id,
        "symbol": "BTCUSDT",
        "side": "SELL",
        "positionSide": managed["position_side"],
        "type": order_type,
        "orderType": order_type,
        "algoStatus": status,
        "quantity": str(quantity),
        "triggerPrice": trigger,
        "executedQty": str(executed_qty),
        "actualOrderId": str(actual_order_id or ""),
        "reduceOnly": managed["position_side"] == "BOTH",
        "closePosition": False,
        "workingType": "MARK_PRICE",
        "priceProtect": True,
    }
    client.algos[client_id] = row
    return row


def test_recover_canceled_stop_only_after_exact_source_and_sibling_verification(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-stop.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    take = _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 1
    replacement = client.new_algo_calls[0]
    assert replacement["type"] == "STOP_MARKET"
    assert replacement["quantity"] == D("1")
    assert replacement["triggerPrice"] == D("90")
    assert replacement["reduceOnly"] is True
    assert take["algoStatus"] == "NEW"
    state = ledger.get_position_management_state("sig-lc")["state"]
    assert state["stop_algo_client_id"] == result["replacement_client_algo_id"]
    duplicate = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")
    assert duplicate["status"] == "ALREADY_PROTECTED"
    assert len(client.new_algo_calls) == 1
    assert ledger.entries_halted()[0] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"


def test_recovery_defers_triggered_stop_to_existing_fill_reducer_without_replacement(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-triggered.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(
        client, ledger, "sig-lc", "STOP_LOSS", status="TRIGGERED",
        actual_order_id="98765", executed_qty="0.4",
    )
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "TRIGGERED_REQUIRES_FILL_RECONCILIATION"
    assert client.new_algo_calls == []
    assert ledger.get_risk_reservation("sig-lc")["status"] == "ACTIVE"
    assert ledger.entries_halted()[0] is True


def test_recovery_ambiguous_post_is_never_automatically_reposted(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-ambiguous.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="EXPIRED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])
    calls = []

    def ambiguous_post(**params):
        calls.append(params)
        raise RuntimeError("simulated response timeout after request write")

    client.new_algo_order = ambiguous_post
    adapter = _adapter(ledger, client)
    result = adapter.recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "SUBMISSION_UNKNOWN"
    assert len(calls) == 1
    action = next(item for item in ledger.list_position_management_actions("sig-lc")
                  if item["action_kind"] == "PROTECTIVE_ORDER_RECOVERY")
    assert action["status"] == "SUBMISSION_UNKNOWN"
    assert action["payload"]["post_attempted"] is True
    resumed = adapter.reconcile_protective_order_recovery(action["action_id"])
    assert resumed["status"] == "SUBMISSION_UNKNOWN"
    assert resumed["automatic_retry"] is False
    assert len(calls) == 1


def test_recovery_uses_durable_algo_update_evidence_only_after_rest_not_found(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-stream-evidence.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    state = ledger.get_position_management_state("sig-lc")["state"]
    stop_id = state["stop_algo_client_id"]
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    client.algos.pop(stop_id, None)
    body = {
        "caid": stop_id, "aid": 501, "s": "BTCUSDT", "S": "SELL", "ps": "BOTH",
        "o": "STOP_MARKET", "q": "1", "X": "CANCELED", "tp": "90", "aq": "0",
        "ai": "", "R": True, "cp": False, "wt": "MARK_PRICE", "pP": True,
    }
    ledger.record_user_stream_event(
        {"e": "ALGO_UPDATE", "E": NOW, "T": NOW, "o": body}, received_at_ms=NOW,
    )
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 1


def test_recovery_finalizes_flat_position_without_recreating_protection(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-flat.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="0")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    ledger.set_reconciliation_state(
        False, status="BLOCKED_MISMATCH", captured_at_ms=NOW,
        detail={
            "snapshot_is_sequential_rest": True, "event_during_snapshot": False,
            "discrepancies": [{"code": "LOCAL_POSITION_NOT_ON_EXCHANGE",
                               "symbol": "BTCUSDT", "side": "LONG", "signal_id": "sig-lc"}],
        }, stream_event_watermark_ms=0,
    )
    ledger.set_entries_halted(True, "ACCOUNT_RECONCILIATION_MISMATCH")

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "POSITION_FLAT_FINALIZED"
    assert client.new_algo_calls == []
    assert ledger.get_position_management_state("sig-lc")["state"]["closed"] is True
    assert ledger.get_risk_reservation("sig-lc")["status"] == "RELEASED"


def test_recovery_sizes_one_lot_not_aggregate_and_preserves_sibling_protection(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-multi-lot.sqlite")
    _managed(ledger, signal_id="sig-one", quantity="1")
    _managed(ledger, signal_id="sig-two", quantity="1")
    client = FakeExecutionClient(quantity="2")
    _seed_protection_algo(client, ledger, "sig-one", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-one", "TAKE_PROFIT", status="NEW")
    sibling_stop = _seed_protection_algo(client, ledger, "sig-two", "STOP_LOSS", status="NEW")
    sibling_take = _seed_protection_algo(client, ledger, "sig-two", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-one", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-one", "STOP_LOSS")

    assert result["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 1
    assert client.new_algo_calls[0]["quantity"] == D("1")
    assert sibling_stop["algoStatus"] == "NEW"
    assert sibling_take["algoStatus"] == "NEW"
    assert client.cancel_algo_calls == []
    assert ledger.get_risk_reservation("sig-two")["status"] == "ACTIVE"


def test_recovery_sweep_processes_only_one_gap_per_fresh_snapshot(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-one-gap.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="EXPIRED")
    _set_missing_protection_reconciliation(
        ledger, [("sig-lc", "STOP_LOSS"), ("sig-lc", "TAKE_PROFIT")],
    )
    adapter = _adapter(ledger, client)

    first = adapter.recover_missing_protections()
    assert len(first) == 1
    assert first[0]["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 1

    # Until a new REST reconciliation snapshot removes the first gap and preserves
    # the second, the sweep must not process a second role from stale discrepancy data.
    # Once the first order is reflected in a fresh snapshot, the second can proceed.
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "TAKE_PROFIT")])
    second = adapter.recover_missing_protections()
    assert len(second) == 1
    assert second[0]["status"] == "CONFIRMED"
    assert len(client.new_algo_calls) == 2



def test_recovery_restart_completes_after_state_pointer_commit_before_action_confirmation(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-crash-window.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])
    adapter = _adapter(ledger, client)
    original_update = ledger.update_position_management_action

    def fail_before_confirm(*, action_id, status, payload_update=None):
        if status == "CONFIRMED":
            raise RuntimeError("simulated process crash before action confirmation")
        return original_update(action_id=action_id, status=status, payload_update=payload_update)

    ledger.update_position_management_action = fail_before_confirm
    with pytest.raises(RuntimeError, match="simulated process crash"):
        adapter.recover_terminal_protection("sig-lc", "STOP_LOSS")
    ledger.update_position_management_action = original_update

    action = next(item for item in ledger.list_position_management_actions("sig-lc")
                  if item["action_kind"] == "PROTECTIVE_ORDER_RECOVERY")
    assert action["status"] == "SUBMITTED"
    replacement_id = action["payload"]["replacement_client_algo_id"]
    assert ledger.get_position_management_state("sig-lc")["state"]["stop_algo_client_id"] == replacement_id
    assert replacement_id in client.algos

    recovered = adapter.reconcile_action(action["action_id"])
    assert recovered["status"] == "CONFIRMED"
    assert recovered["duplicate"] is False
    assert len(client.new_algo_calls) == 1
    assert ledger.get_position_management_action(action["action_id"])["status"] == "CONFIRMED"


def test_recovery_post_query_rejects_wrong_working_type_or_price_protect(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-invalid-fields.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])
    original_post = client.new_algo_order

    def post_with_mismatched_protection_semantics(**params):
        response = original_post(**params)
        client.algos[params["clientAlgoId"]]["priceProtect"] = False
        return response

    client.new_algo_order = post_with_mismatched_protection_semantics
    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "SUBMISSION_UNKNOWN"
    assert len(client.new_algo_calls) == 1
    assert ledger.entries_halted()[0] is True


def test_recovery_uses_hedge_mode_position_side_without_reduce_only(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-hedge.sqlite")
    _managed(ledger, position_side="LONG")
    client = FakeExecutionClient(dual=True, quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "CONFIRMED"
    params = client.new_algo_calls[0]
    assert params["positionSide"] == "LONG"
    assert "reduceOnly" not in params
    assert params["quantity"] == D("1")



def test_recovery_rejects_sibling_protection_that_is_triggered_even_if_gap_is_listed(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-sibling-triggered.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="CANCELED")
    _seed_protection_algo(
        client, ledger, "sig-lc", "TAKE_PROFIT", status="TRIGGERED",
        actual_order_id="888", executed_qty="0.25",
    )
    _set_missing_protection_reconciliation(
        ledger, [("sig-lc", "STOP_LOSS"), ("sig-lc", "TAKE_PROFIT")],
    )

    with pytest.raises(RuntimeError, match="SIBLING_TRIGGERED"):
        _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert client.new_algo_calls == []
    assert ledger.entries_halted()[0] is True


def test_recovery_rejects_active_order_with_wrong_working_type_even_if_quantity_matches(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-working-type.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    _seed_protection_algo(client, ledger, "sig-lc", "STOP_LOSS", status="NEW")
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    client.algos[ledger.get_position_management_state("sig-lc")["state"]["stop_algo_client_id"]]["workingType"] = "CONTRACT_PRICE"
    _set_missing_protection_reconciliation(ledger, [])

    with pytest.raises(RuntimeError, match="GAP_NOT_IN_FRESH_RECONCILIATION"):
        _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert client.new_algo_calls == []



def test_recovery_uses_latest_stream_terminal_update_over_older_canceled_event(tmp_path):
    ledger = _ready_ledger(tmp_path / "recover-latest-stream.sqlite")
    _managed(ledger)
    client = FakeExecutionClient(quantity="1")
    state = ledger.get_position_management_state("sig-lc")["state"]
    stop_id = state["stop_algo_client_id"]
    _seed_protection_algo(client, ledger, "sig-lc", "TAKE_PROFIT", status="NEW")
    client.algos.pop(stop_id, None)
    canceled = {
        "caid": stop_id, "aid": 501, "s": "BTCUSDT", "S": "SELL", "ps": "BOTH",
        "o": "STOP_MARKET", "q": "1", "X": "CANCELED", "tp": "90", "aq": "0",
        "ai": "", "R": True, "cp": False, "wt": "MARK_PRICE", "pP": True,
    }
    triggered = {**canceled, "X": "TRIGGERED", "aq": "0.2", "ai": "777"}
    ledger.record_user_stream_event(
        {"e": "ALGO_UPDATE", "E": NOW - 2, "T": NOW - 2, "o": canceled},
        received_at_ms=NOW - 2,
    )
    ledger.record_user_stream_event(
        {"e": "ALGO_UPDATE", "E": NOW - 1, "T": NOW - 1, "o": triggered},
        received_at_ms=NOW - 1,
    )
    _set_missing_protection_reconciliation(ledger, [("sig-lc", "STOP_LOSS")])

    result = _adapter(ledger, client).recover_terminal_protection("sig-lc", "STOP_LOSS")

    assert result["status"] == "TRIGGERED_REQUIRES_FILL_RECONCILIATION"
    assert client.new_algo_calls == []


@pytest.mark.parametrize("enabled", [False, True])
def test_account_runtime_protection_recovery_opt_in_and_snapshot_dedup(tmp_path, enabled):
    import asyncio
    from divatrading.execution.account_runtime import (
        AccountRuntimeConfig, ExecutionAccountRuntime,
    )
    from divatrading.execution.reconciliation import ReconciliationReport

    ledger = _ready_ledger(tmp_path / f"account-protection-recovery-{enabled}.sqlite")
    ledger.set_entries_halted(True, "ACCOUNT_RECONCILIATION_MISMATCH")
    calls = {"recover_startup": 0, "recover_missing": 0, "reconcile": 0}

    class UserStream:
        on_event = None

        async def run(self, stop_event):
            ledger.set_user_stream_state(
                "CONNECTED", connected_at_ms=NOW, updated_at_ms=NOW,
            )
            await stop_event.wait()
            ledger.set_user_stream_state("STOPPED", updated_at_ms=NOW + 1)

    class Adapter:
        def recover_on_startup(self):
            calls["recover_startup"] += 1
            return {"actions": [], "positions": []}

        def recover_missing_protections(self):
            calls["recover_missing"] += 1
            return [{"status": "SUBMISSION_UNKNOWN", "automatic_retry": False}]

    class Reducer:
        adapter = Adapter()
        enable_zero_fill_reprotection = False

        def handle(self, event):
            return None

    class Reconciler:
        def reconcile(self):
            calls["reconcile"] += 1
            return ReconciliationReport(
                ready=False, status="BLOCKED_MISMATCH", captured_at_ms=NOW,
                exchange_position_count=1, local_position_count=1,
                open_standard_order_count=0, open_algo_order_count=1,
                discrepancies=({"code": "POSITION_MISSING_PROTECTION"},),
            )

    runtime = ExecutionAccountRuntime(
        user_stream=UserStream(), reconciler=Reconciler(), ledger=ledger,
        config=AccountRuntimeConfig(
            reconciliation_interval_seconds=0.005,
            disconnected_poll_seconds=0.002,
        ),
        lifecycle_fill_reducer=Reducer(),
        enable_protection_recovery=enabled,
    )
    assert runtime.lifecycle_fill_reducer.enable_zero_fill_reprotection is enabled
    assert runtime.lifecycle_fill_reducer.adapter.enable_zero_fill_reprotection is enabled

    async def run_case():
        stop = asyncio.Event()
        asyncio.get_running_loop().call_later(0.04, stop.set)
        await runtime.run(stop)

    asyncio.run(run_case())
    assert calls["recover_startup"] == 1
    assert calls["recover_missing"] == (1 if enabled else 0)
    assert calls["reconcile"] >= 1
    # Recovery must never clear an existing entry halt; a fresh successful
    # reconciliation is required before the separate readiness gate can reopen.
    assert ledger.entries_halted()[0] is True
