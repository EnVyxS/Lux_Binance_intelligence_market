from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from divatrading.strategy.fixture_intake import (
    INSTRUMENTATION_ID,
    INSTRUMENTATION_SHA256,
    PINE_SOURCE_SHA256,
    build_fixture_from_capture_manifest,
    validate_reference_fixture,
)

BASE = 1_704_067_200_000
FIELDS = (
    "EVENT_TIME_MS", "DIRECTION", "TRIGGER", "ENTRY_PROXY", "STOP_LOSS", "TAKE_PROFIT",
    "OB_TOP", "OB_BOTTOM", "OB_SOURCE_TIME_MS", "SETUP_SCORE", "OB_QUALITY_SCORE",
    "TIMING_SCORE", "ENTRY_BAND_LOW", "ENTRY_BAND_HIGH",
)
FLAGS = (
    "DIVA_M1_INDEPENDENT_FLAG", "DIVA_M5_NESTED_FLAG",
    "DIVA_M5_STANDALONE_FLAG", "DIVA_M15_PRIMARY_FLAG",
)


def _write_csv(path: Path, timeframe: str, *, with_plots: bool = False) -> None:
    headers = ["time", "open", "high", "low", "close", "Volume"]
    if with_plots:
        headers.append("DIVA_EVALUATION_TIME_MS")
        for prefix in ("M1", "M5", "M15"):
            headers.extend(f"DIVA_{prefix}_{field}" for field in FIELDS)
        headers.extend(FLAGS)
    duration = {"1m": 60_000, "5m": 300_000, "15m": 900_000}[timeframe]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers)
        writer.writeheader()
        for index in range(3):
            offset = index if timeframe == "1m" else index - 2
            open_time_ms = BASE + offset * duration
            from datetime import datetime, timezone
            time_text = datetime.fromtimestamp(open_time_ms / 1000, timezone.utc).isoformat().replace("+00:00", "Z")
            row = {
                "time": time_text,
                "open": "100.0", "high": "101.0", "low": "99.0", "close": "100.5", "Volume": "12.5",
            }
            if with_plots:
                row["DIVA_EVALUATION_TIME_MS"] = str(BASE + index * 60_000)
                for prefix in ("M1", "M5", "M15"):
                    for field in FIELDS:
                        row[f"DIVA_{prefix}_{field}"] = ""
                for flag in FLAGS:
                    row[flag] = "0"
                if index == 1:
                    values = {
                        "EVENT_TIME_MS": str(BASE), "DIRECTION": "1", "TRIGGER": "1",
                        "ENTRY_PROXY": "100.5", "STOP_LOSS": "99.0", "TAKE_PROFIT": "102.0",
                        "OB_TOP": "100.8", "OB_BOTTOM": "99.2", "OB_SOURCE_TIME_MS": str(BASE),
                        "SETUP_SCORE": "82.0", "OB_QUALITY_SCORE": "80.0", "TIMING_SCORE": "90.0",
                        "ENTRY_BAND_LOW": "99.8", "ENTRY_BAND_HIGH": "100.4",
                    }
                    for field, value in values.items():
                        row[f"DIVA_M1_{field}"] = value
                    row[FLAGS[0]] = "1"
            writer.writerow(row)


def _make_capture(tmp_path: Path) -> tuple[Path, Path]:
    _write_csv(tmp_path / "m1.csv", "1m", with_plots=True)
    _write_csv(tmp_path / "m5.csv", "5m")
    _write_csv(tmp_path / "m15.csv", "15m")
    template_path = Path(__file__).parents[1] / "reference/pine_smc/reference_fixture.template.json"
    template = json.loads(template_path.read_text(encoding="utf-8"))
    manifest = {
        "provenance": {
            **template["provenance"],
            "tradingview_ticker_id": "BINANCE:BTCUSDT.P",
            "capture_method": "TradingView Export Chart Data CSV",
            "captured_at_utc": "2024-01-01T00:31:00Z",
            "chart_timezone": "UTC",
            "chart_timeframe": "1",
            "tick_size": "0.10",
            "effective_inputs_source": "TRADINGVIEW_DEFAULTS_CONFIRMED",
            "candle_data_source": "TRADINGVIEW_CHART_EXPORT",
        },
        "replay": {"symbol": "BTCUSDT", "warmup_bars": 1500, "full_loaded_history_included": True},
        "capture_files": {"1m": "m1.csv", "5m": "m5.csv", "15m": "m15.csv"},
        "timestamp_encoding": "iso8601_with_offset",
        "coverage": {
            "start_time_ms": BASE,
            "end_time_ms": BASE + 180_000,
            "complete": True,
            "assert_no_other_signals": True,
        },
    }
    manifest_path = tmp_path / "capture_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    fixture_path = build_fixture_from_capture_manifest(manifest_path, tmp_path / "fixture.json")
    return fixture_path, manifest_path


def test_build_and_validate_provenance_checked_fixture(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert report.accepted
    assert report.signal_count == 1
    assert dict(report.candle_counts) == {"1m": 3, "5m": 3, "15m": 3}
    assert report.issues == ()


def test_rejects_changed_raw_source_export(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    with (tmp_path / "m5.csv").open("a", encoding="utf-8") as stream:
        stream.write("\n")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "SOURCE_EXPORT_HASH_MISMATCH" for issue in report.issues)


def test_rejects_ticker_that_is_not_matching_binance_perpetual(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["provenance"]["tradingview_ticker_id"] = "BINANCE:ETHUSDT.P"
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "TICKER_SYMBOL_MISMATCH" for issue in report.issues)


def test_rejects_candle_gap(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["candle_series"]["1m"][2]["open_time_ms"] += 60_000
    data["replay"]["last_bar_open_time_ms_by_timeframe"]["1m"] += 60_000
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "CANDLE_GAP_OR_DUPLICATE" for issue in report.issues)


def test_rejects_fixture_when_embedded_candles_do_not_match_export(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["candle_series"]["1m"][0]["close"] = "100.6"
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "SOURCE_CANDLE_CONTENT_MISMATCH" for issue in report.issues)


def test_rejects_non_tick_aligned_candle_prices(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["candle_series"]["15m"][0]["open"] = "100.01"
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "PRICE_OFF_TICK_GRID" for issue in report.issues)


def test_rejects_false_negative_signal_coverage_claim(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["coverage"]["complete"] = False
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "SCHEMA_ERROR" for issue in report.issues)


def test_rejects_warmup_mismatch(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["replay"]["warmup_bars"] = 1499
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "WARMUP_INPUT_MISMATCH" for issue in report.issues)


def test_patch_constants_are_pinned_to_manifest() -> None:
    manifest = json.loads((Path(__file__).parents[1] / "reference/pine_smc/PINE_SOURCE_MANIFEST.json").read_text())
    assert manifest["sha256"] == PINE_SOURCE_SHA256
    patch = Path(__file__).parents[1] / "reference/pine_smc/TV_CAPTURE_INSTRUMENTATION_V1.pine.txt"
    patch_text = patch.read_text(encoding="utf-8")
    assert INSTRUMENTATION_ID == "DIVATrading Pine Capture Instrumentation v1"
    assert hashlib.sha256(patch.read_bytes()).hexdigest() == INSTRUMENTATION_SHA256
    assert sum(line.startswith("plot(") for line in patch_text.splitlines()) == 47
    assert 47 + manifest["capture_instrumentation"]["original_alertcondition_count"] <= 64


def test_rejects_mismatched_mtf_last_bar_boundary(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["replay"]["last_bar_open_time_ms_by_timeframe"]["5m"] += 300_000
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "MTF_LAST_BAR_BOUNDARY_MISMATCH" for issue in report.issues)


def test_rejects_signal_entry_not_matching_event_candle_close(tmp_path: Path) -> None:
    fixture, _ = _make_capture(tmp_path)
    data = json.loads(fixture.read_text(encoding="utf-8"))
    data["reference_signals"][0]["entry_proxy"] = "100.6"
    fixture.write_text(json.dumps(data), encoding="utf-8")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert not report.accepted
    assert any(issue.code == "ENTRY_PROXY_NOT_SOURCE_CLOSE" for issue in report.issues)


def test_instrumentation_patch_stays_inside_pine_plot_budget_and_uses_real_series_names() -> None:
    patch = Path(__file__).parents[1] / "reference/pine_smc/TV_CAPTURE_INSTRUMENTATION_V1.pine.txt"
    patch_text = patch.read_text(encoding="utf-8")
    assert sum(line.startswith("plot(") for line in patch_text.splitlines()) == 47
    pine_fields = (
        "Time", "Dir", "Trig", "Entry", "SL", "TP", "OBTop", "OBBot", "OBTime",
        "Score", "Quality", "Timing", "EntryLow", "EntryHigh",
    )
    for suffix in ("1", "5", "15"):
        for field in pine_fields:
            assert f"sig{field}{suffix}" in patch_text
    assert not any(f"sig{field}M{tf}" in patch_text for tf in (1, 5, 15) for field in pine_fields)



def test_ready_to_paste_instrumented_pine_preserves_original_source_byte_for_byte() -> None:
    root = Path(__file__).parents[1]
    manifest = json.loads((root / "reference/pine_smc/PINE_SOURCE_MANIFEST.json").read_text())
    patch = (root / "reference/pine_smc/TV_CAPTURE_INSTRUMENTATION_V1.pine.txt").read_bytes()
    instrumented_path = root / "reference/pine_smc/Sniper_SMC_MTF_Enhanced_Instrumented_v1.pine"
    instrumented = instrumented_path.read_bytes()
    assert instrumented.count(patch) == 1
    restored = instrumented.replace(patch + b"\n", b"", 1)
    assert hashlib.sha256(restored).hexdigest() == PINE_SOURCE_SHA256
    assert hashlib.sha256(instrumented).hexdigest() == manifest["capture_instrumentation"]["instrumented_full_script_sha256"]
    assert len(instrumented) == manifest["capture_instrumentation"]["instrumented_full_script_bytes"]

def test_accepts_explicit_complete_no_signal_reference_window(tmp_path: Path) -> None:
    m1_path = tmp_path / "m1.csv"
    _write_csv(m1_path, "1m", with_plots=True)
    with m1_path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames
        rows = list(reader)
    for row in rows:
        for prefix in ("M1", "M5", "M15"):
            for field in FIELDS:
                row[f"DIVA_{prefix}_{field}"] = ""
        for flag in FLAGS:
            row[flag] = "0"
    with m1_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)
    _write_csv(tmp_path / "m5.csv", "5m")
    _write_csv(tmp_path / "m15.csv", "15m")
    template = json.loads((Path(__file__).parents[1] / "reference/pine_smc/reference_fixture.template.json").read_text())
    manifest = {
        "provenance": {
            **template["provenance"],
            "tradingview_ticker_id": "BINANCE:BTCUSDT.P",
            "capture_method": "TradingView Export Chart Data CSV",
            "captured_at_utc": "2024-01-01T00:31:00Z",
            "chart_timezone": "UTC",
            "chart_timeframe": "1",
            "tick_size": "0.10",
            "effective_inputs_source": "TRADINGVIEW_DEFAULTS_CONFIRMED",
            "candle_data_source": "TRADINGVIEW_CHART_EXPORT",
        },
        "replay": {"symbol": "BTCUSDT", "warmup_bars": 1500, "full_loaded_history_included": True},
        "capture_files": {"1m": "m1.csv", "5m": "m5.csv", "15m": "m15.csv"},
        "timestamp_encoding": "iso8601_with_offset",
        "coverage": {
            "start_time_ms": BASE, "end_time_ms": BASE + 180_000,
            "complete": True, "assert_no_other_signals": True,
        },
    }
    manifest_path = tmp_path / "capture_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    fixture = build_fixture_from_capture_manifest(manifest_path, tmp_path / "fixture.json")
    report = validate_reference_fixture(fixture, source_dir=tmp_path)
    assert report.accepted
    assert report.signal_count == 0
