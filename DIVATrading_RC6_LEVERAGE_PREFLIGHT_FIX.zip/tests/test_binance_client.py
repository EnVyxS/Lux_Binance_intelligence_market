from __future__ import annotations

import json

import httpx
import pytest

from divatrading.exchange.binance.client import (
    BinanceApiError,
    BinanceHttpError,
    BinanceResponseError,
    BinanceTransportError,
    BinanceUsdMFuturesRestClient,
)


def build_client(handler, *, sleeps=None, max_attempts=3):
    transport = httpx.MockTransport(handler)
    http_client = httpx.Client(transport=transport)
    return BinanceUsdMFuturesRestClient(
        base_url="https://fixture.local",
        max_attempts=max_attempts,
        base_backoff_seconds=0.1,
        max_backoff_seconds=0.2,
        http_client=http_client,
        sleep=(sleeps.append if sleeps is not None else lambda _: None),
    )


def test_successful_public_exchange_info_get_has_no_credentials():
    observed = {}

    def handler(request):
        observed["method"] = request.method
        observed["url"] = str(request.url)
        observed["headers"] = dict(request.headers)
        return httpx.Response(200, json={"symbols": []})

    client = build_client(handler)
    try:
        assert client.get_exchange_info() == {"symbols": []}
    finally:
        client.close()
    assert observed["method"] == "GET"
    assert observed["url"] == "https://fixture.local/fapi/v1/exchangeInfo"
    assert "X-MBX-APIKEY" not in {key.upper() for key in observed["headers"]}


def test_timeout_retries_then_succeeds_with_bounded_backoff():
    calls = {"count": 0}
    sleeps = []

    def handler(request):
        calls["count"] += 1
        if calls["count"] == 1:
            raise httpx.ReadTimeout("simulated read timeout", request=request)
        return httpx.Response(200, json={"symbols": [1]})

    client = build_client(handler, sleeps=sleeps)
    try:
        assert client.get_exchange_info() == {"symbols": [1]}
    finally:
        client.close()
    assert calls["count"] == 2
    assert sleeps == [0.1]


def test_retryable_server_error_retries_but_client_error_does_not():
    calls = {"count": 0}
    sleeps = []

    def retry_handler(request):
        calls["count"] += 1
        if calls["count"] == 1:
            return httpx.Response(503, text="maintenance")
        return httpx.Response(200, json={"symbols": []})

    client = build_client(retry_handler, sleeps=sleeps)
    try:
        assert client.get_exchange_info() == {"symbols": []}
    finally:
        client.close()
    assert calls["count"] == 2
    assert sleeps == [0.1]

    calls["count"] = 0

    def bad_request_handler(request):
        calls["count"] += 1
        return httpx.Response(400, text="bad request")

    client = build_client(bad_request_handler, max_attempts=4)
    try:
        with pytest.raises(BinanceHttpError, match="HTTP 400"):
            client.get_exchange_info()
    finally:
        client.close()
    assert calls["count"] == 1


def test_retry_exhaustion_surfaces_transport_error():
    calls = {"count": 0}

    def handler(request):
        calls["count"] += 1
        raise httpx.ConnectTimeout("simulated connect timeout", request=request)

    client = build_client(handler, max_attempts=2)
    try:
        with pytest.raises(BinanceTransportError, match="after 2 attempts"):
            client.get_exchange_info()
    finally:
        client.close()
    assert calls["count"] == 2


def test_invalid_json_and_binance_api_error_are_explicit():
    client = build_client(lambda request: httpx.Response(200, text="not json"))
    try:
        with pytest.raises(BinanceResponseError, match="invalid JSON"):
            client.get_exchange_info()
    finally:
        client.close()

    client = build_client(lambda request: httpx.Response(200, json={"code": -1003, "msg": "rate limit"}))
    try:
        with pytest.raises(BinanceApiError, match="-1003"):
            client.get_exchange_info()
    finally:
        client.close()


def test_rate_limit_retry_is_bounded_by_max_attempts_and_backoff_cap():
    calls = {"count": 0}
    sleeps = []

    def handler(request):
        calls["count"] += 1
        return httpx.Response(429, text="rate limited", headers={"Retry-After": "10"})

    client = build_client(handler, sleeps=sleeps, max_attempts=3)
    try:
        with pytest.raises(BinanceHttpError, match="HTTP 429"):
            client.get_exchange_info()
    finally:
        client.close()
    assert calls["count"] == 3
    assert sleeps == [0.2, 0.2]
