"""Offline coverage for launcher, planner selection, and autonomous dispatch wiring."""

import logging
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading import cli
from divatrading.core.database import Database
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode
from divatrading.trading.control_plane import OperatorControlStore
from divatrading.trading.models import QualifiedSignal
from divatrading.trading.risk import PortfolioRiskConfig, PortfolioRiskManager
from divatrading.trading.signal_planner import SMCV2TradePlanner


def test_autonomous_cli_keeps_legacy_planner_and_parses_merged_trial_flags():
    from divatrading.trading.sweep_reclaim import SweepReclaimPlanner

    parser = cli.build_parser()
    risk = PortfolioRiskManager(PortfolioRiskConfig())

    legacy = parser.parse_args(["auto-trade-runtime"])
    assert legacy.strategy == "rc6"
    assert not legacy.early_exit_protection
    assert not legacy.activate_live
    assert isinstance(cli._autonomous_planner(legacy, risk, ExecutionMode.PAPER), SMCV2TradePlanner)

    merged = parser.parse_args([
        "auto-trade-runtime", "--strategy", "sweep-reclaim", "--early-exit-protection",
        "--max-positions", "1", "--activate-live",
    ])
    assert merged.early_exit_protection and merged.activate_live
    assert merged.max_positions == 1
    assert isinstance(cli._autonomous_planner(merged, risk, ExecutionMode.LIVE), SweepReclaimPlanner)

    with pytest.raises(SystemExit):
        parser.parse_args(["auto-trade-runtime", "--max-positions", "3"])


def test_windows_launchers_keep_merged_trial_explicit_and_separate():
    project = Path(__file__).resolve().parents[1]
    legacy = (project / "START_LIVE_WINDOWS.bat").read_text(encoding="utf-8")
    merged = (project / "START_MERGED_TRIAL_WINDOWS.bat").read_text(encoding="utf-8")
    entrypoint = "-m divatrading auto-trade-runtime"

    assert "--strategy sweep-reclaim" not in legacy
    assert "--early-exit-protection" not in legacy
    assert "merged-trial.db" not in legacy
    assert "DIVA_DATABASE_PATH=data/merged-trial.db" in merged.replace("\\", "/")
    assert merged.index("START LIVE TRADING") < merged.index(entrypoint)
    command = merged.split(entrypoint, 1)[1].split("\nset ", 1)[0]
    for flag in ("--activate-live", "--strategy sweep-reclaim", "%DIVA_TRIAL_EXIT_FLAG%", "--max-positions 1"):
        assert flag in command
    assert 'set "DIVA_TRIAL_EXIT_FLAG="' in merged
    assert 'if defined DIVA_TRIAL_EARLY_EXIT set "DIVA_TRIAL_EXIT_FLAG=--early-exit-protection"' in merged


def test_live_actor_lock_ignores_database_and_log_directory(tmp_path, monkeypatch):
    from divatrading.core.reliability import ProcessLockError

    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    service = SimpleNamespace(
        config=SimpleNamespace(mode=ExecutionMode.LIVE),
        client=SimpleNamespace(api_key="test-only-binance-key"),
    )
    entry = cli._exchange_actor_lock(service, tmp_path / "log-a" / "autonomous-runtime.lock")
    account = cli._exchange_actor_lock(service, tmp_path / "log-b" / "account-runtime.lock")
    assert entry.path == account.path
    assert service.client.api_key not in str(entry.path)
    with entry:
        with pytest.raises(ProcessLockError):
            account.acquire()


@pytest.mark.parametrize("requested,expected", [(None, 1), (2, 2)])
def test_live_position_cap_counts_pending_reservations_across_pairs(tmp_path, requested, expected):
    cap = cli._autonomous_max_positions(ExecutionMode.LIVE, requested)
    assert cap == expected
    ledger = ExecutionLedger(tmp_path / "risk.sqlite")

    def reserve(symbol):
        return ledger.reserve_portfolio_risk(
            signal_id=f"sweep-{symbol}", symbol=symbol, risk_usdt=Decimal("0.20"),
            notional_usdt=Decimal("10"), equity_usdt=Decimal("100"),
            exchange_open_risk_usdt=Decimal(0), exchange_active_position_count=0,
            max_positions=cap, max_portfolio_open_risk_pct=Decimal("20"),
            exchange_symbol_notional_usdt=Decimal(0), max_symbol_notional_usdt=Decimal("100"),
        )

    with ThreadPoolExecutor(max_workers=3) as pool:
        decisions = tuple(pool.map(reserve, ("BTCUSDT", "ETHUSDT", "SOLUSDT")))

    assert sum(decision.accepted for decision in decisions) == expected
    assert {decision.reason for decision in decisions if not decision.accepted} == {
        "MAX_OPEN_POSITIONS_RESERVED",
    }


def test_paper_runtime_dispatches_merged_strategy_and_reloads_operator_risk(tmp_path, monkeypatch):
    """Run the autonomous command with fake feeds and dispatcher, and real SQLite controls."""
    from divatrading.trading.sweep_reclaim import SWEEP_RECLAIM_STRATEGY_ID, SweepReclaimPlanner

    monkeypatch.chdir(tmp_path)
    settings = SimpleNamespace(
        database_path=tmp_path / "trial.sqlite", log_dir=tmp_path / "logs",
        telegram_bot_token=None, telegram_owner_id=None,
    )
    monkeypatch.setattr(cli, "_settings", lambda: settings)
    monkeypatch.setattr(cli, "_configure", lambda settings: logging.getLogger("test-merged-runtime"))
    monkeypatch.setattr(cli, "validate_runtime", lambda: None)
    control = OperatorControlStore(Database(settings.database_path))
    client_free_service = SimpleNamespace(config=ExecutionConfig(), client=None, ledger=object())
    monkeypatch.setattr(cli.ExecutionService, "from_environment", lambda path: client_free_service)

    seen = []
    dispatched = []
    signal = QualifiedSignal(
        "test-sweep", "BTCUSDT", "LONG", "LIMIT_IOC", Decimal("100.01"),
        Decimal("99.50"), Decimal("102.00"), "5m", SWEEP_RECLAIM_STRATEGY_ID, 1000,
    )

    select_planner = cli._autonomous_planner

    def planner(args, risk, mode):
        selected = select_planner(args, risk, mode)
        assert isinstance(selected, SweepReclaimPlanner)

        def evaluate(snapshot, **options):
            assert snapshot.symbol == signal.symbol
            assert options["qualification_only"] is True
            assert options["mark_qualified_emitted"] is False
            seen.append(risk.config)
            # Mirror an unqualified candidate alongside the valid signal.
            return SimpleNamespace(evaluations=(
                SimpleNamespace(status="QUALIFIED", signal=signal),
                SimpleNamespace(status="WATCH", signal=None),
            ))

        return SimpleNamespace(evaluate=evaluate)

    class MarketClient:
        def __init__(self, **_):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_):
            pass

    class FeedFactory:
        def __init__(self, **_):
            pass

        def close(self):
            pass

    class MarketRuntime:
        def __init__(self, *, on_evidence, **_):
            self.on_evidence = on_evidence

        async def run(self, _stop_event):
            snapshot = SimpleNamespace(symbol=signal.symbol)
            await self.on_evidence(snapshot)
            control.set_risk("PERCENT", "0.30")
            await self.on_evidence(snapshot)
            control.set_risk("FIXED", "0.22")
            await self.on_evidence(snapshot)

    class Dispatcher:
        def __init__(self, **_):
            pass

        async def dispatch_signals(self, signals):
            dispatched.append(signals)
            return ()

    monkeypatch.setattr(cli, "_autonomous_planner", planner)
    monkeypatch.setattr(cli, "BinanceUsdMFuturesRestClient", MarketClient)
    monkeypatch.setattr(cli, "BinancePublicFeedFactory", FeedFactory)
    monkeypatch.setattr(cli, "MultiPairLiveMarketRuntime", MarketRuntime)
    monkeypatch.setattr(cli, "AutonomousEntryDispatcher", Dispatcher)
    args = cli.build_parser().parse_args([
        "auto-trade-runtime", "--strategy", "sweep-reclaim", "--max-positions", "1",
    ])

    assert cli.command_autonomous_runtime(args) == 0
    assert dispatched == [(signal,)] * 3
    assert [config.max_positions for config in seen] == [1, 1, 1]
    assert seen[0].risk_per_trade_fixed_usdt == Decimal("0.20")
    assert seen[1].risk_per_trade_fixed_usdt is None
    assert seen[1].risk_per_trade_pct == Decimal("0.30")
    assert seen[2].risk_per_trade_fixed_usdt == Decimal("0.22")
