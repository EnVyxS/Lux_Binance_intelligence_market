from __future__ import annotations

import json
from dataclasses import replace
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.strategy.scalping_market_data import InstrumentSpec
from divatrading.strategy.scalping_order_block_formation import (
    DisplacementMeasurements, OrderBlockCandidate,
)
from divatrading.strategy.scalping_order_block_lifecycle import OrderBlockLifecycleSnapshot
from divatrading.strategy.scalping_market_structure import StructureEvent, StructurePivot, StructurePivotState
from divatrading.strategy.scalping_pipeline import SMCV2EvidenceSnapshot
from divatrading.trading.risk import PortfolioRiskConfig, PortfolioRiskManager
from divatrading.trading.signal_planner import SMCTradePlannerConfig, SMCV2TradePlanner

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"
CAPTURE_MS = 1_794_400_000_000


def _evidence(*, lifecycle_status="ACTIVE_FRESH", candle_open="50050.0",
              candle_close="50100.0", mark="50100.0", pivots=(), m15_direction=0,
              min_notional=Decimal("5"), include_touched=False, include_retest=False):
    payload = json.loads(FIXTURE.read_text())
    metadata = parse_exchange_info(payload, source_endpoint="fixture").get_symbol("BTCUSDT")
    assert metadata is not None
    instrument = InstrumentSpec.from_symbol_info(metadata)
    instrument = replace(
        instrument, order_types=("LIMIT", "MARKET", "STOP_MARKET", "TAKE_PROFIT_MARKET"),
        min_notional=min_notional,
    )

    displacement = DisplacementMeasurements(
        break_body=Decimal("10"), break_full_range=Decimal("15"),
        break_body_range_ratio=Decimal("0.66"), close_extension=Decimal("2"),
        close_extension_ticks=Decimal("20"), directional_leg_start_index=1,
        directional_leg_start_open_time_ms=CAPTURE_MS - 120_000,
        directional_leg_candle_count=2, leg_body_sum=Decimal("20"),
        leg_full_range_sum=Decimal("30"), leg_body_range_ratio=Decimal("0.66"),
    )
    ob = OrderBlockCandidate(
        candidate_id="ob-btc-001", event_id="event-btc-001", symbol="BTCUSDT",
        timeframe="1m", structure_layer="SWING", structure_event_type="BOS",
        direction=1, source_bar_index=1, source_open_time_ms=CAPTURE_MS - 180_000,
        source_confirmation_time_ms=CAPTURE_MS - 120_000,
        source_open=Decimal("49995.0"), source_high=Decimal("50000.0"),
        source_low=Decimal("49990.0"), source_close=Decimal("49992.0"),
        zone_top=Decimal("50000.0"), zone_bottom=Decimal("49990.0"),
        zone_boundary_convention="FULL_WICK", broken_structure_level=Decimal("50010.0"),
        break_bar_index=2, break_bar_open_time_ms=CAPTURE_MS - 60_000,
        break_confirmation_time_ms=CAPTURE_MS - (120_000 if include_retest else 1),
        break_open=Decimal("49998.0"), break_high=Decimal("50110.0"),
        break_low=Decimal("49997.0"), break_close=Decimal("50100.0"),
        displacement_leg_id="leg-1", displacement=displacement,
        reason_codes=("STRUCTURE_BOS", "DIRECTIONAL_DISPLACEMENT"),
    )
    lifecycle = OrderBlockLifecycleSnapshot(
        candidate=ob, status=("TOUCHED" if include_retest else lifecycle_status), age_bars=3,
        first_touch_time_ms=(CAPTURE_MS - 60_000 if include_retest else None), first_touch_bar_open_time_ms=(CAPTURE_MS - 120_000 if include_retest else None),
        maximum_mitigation_depth_ratio=Decimal("0"), maximum_mitigation_price=None,
        mitigation_time_ms=None, invalidation_time_ms=None,
        invalidation_bar_open_time_ms=None, invalidation_price=None,
        invalidation_reason=None, expiry_time_ms=None, expiry_reason=None,
        last_processed_bar_open_time_ms=CAPTURE_MS - 60_000,
    )
    event = StructureEvent(
        event_id="event-btc-001", symbol="BTCUSDT", timeframe="1m",
        layer="SWING", event_type="BOS", direction=1,
        broken_level=Decimal("50010.0"), pivot_id="piv-1", pivot_price=Decimal("50010.0"),
        pivot_source_open_time_ms=CAPTURE_MS - 240_000,
        pivot_confirmation_close_time_ms=CAPTURE_MS - 180_000,
        break_bar_open_time_ms=CAPTURE_MS - 60_000,
        confirmation_time_ms=CAPTURE_MS - (120_000 if include_retest else 1),
        previous_close=Decimal("49998.0"), confirmation_close=Decimal("50100.0"),
        protected_pivot_id="piv-low", protected_price=Decimal("49990.0"),
        protected_kind="LOW",
    )
    tf = SimpleNamespace(status="READY", events=(event,), pivots=tuple(pivots),
                         swing=SimpleNamespace(direction=1), internal=SimpleNamespace(direction=1))
    m15_tf = SimpleNamespace(status="READY", events=(), pivots=(),
                             swing=SimpleNamespace(direction=m15_direction),
                             internal=SimpleNamespace(direction=m15_direction))
    structure = SimpleNamespace(timeframe=lambda interval: tf if interval == "1m" else (m15_tf if interval == "15m" else None))
    lifecycle_rows = (lifecycle,)
    if include_touched:
        second_ob = replace(ob, candidate_id="ob-btc-002")
        second_lifecycle = replace(lifecycle, candidate=second_ob, status="TOUCHED", age_bars=4)
        lifecycle_rows = (lifecycle, second_lifecycle)
    ob_lifecycle = SimpleNamespace(timeframe=lambda interval: SimpleNamespace(order_blocks=lifecycle_rows) if interval == "1m" else None)
    liquidity = SimpleNamespace(timeframe=lambda interval: SimpleNamespace(fvgs=(), sweeps=()) if interval == "1m" else None)
    candle = SimpleNamespace(open=Decimal(candle_open), close=Decimal(candle_close), close_time_ms=CAPTURE_MS - 1)
    market_view = SimpleNamespace(
        symbol="BTCUSDT", captured_at_ms=CAPTURE_MS, instrument=instrument,
        readiness=SimpleNamespace(m1_setup_ready=True, m5_setup_ready=False),
        mark_price=SimpleNamespace(symbol="BTCUSDT", mark_price=Decimal(mark), event_time_ms=CAPTURE_MS),
        kline=lambda interval: SimpleNamespace(latest_closed_candle=candle) if interval == "1m" else None,
        flow=None, order_book_metrics=None, absorption=None,
    )
    return SMCV2EvidenceSnapshot(
        symbol="BTCUSDT", captured_at_ms=CAPTURE_MS,
        structure=structure, ob_formation=SimpleNamespace(),
        ob_lifecycle=ob_lifecycle, liquidity_fvg=liquidity,
        market_view=market_view,
    )


def test_limit_retracement_builds_decimal_trade_plan_and_never_emits_duplicate():
    planner = SMCV2TradePlanner(
        config=SMCTradePlannerConfig(entry_model="LIMIT_RETRACEMENT"),
        risk_manager=PortfolioRiskManager(PortfolioRiskConfig()),
    )
    first = planner.evaluate(_evidence(), equity_usdt=Decimal("1000"))
    assert len(first.evaluations) == 1
    item = first.evaluations[0]
    assert item.status == "PLANNED"
    assert item.rank == 1
    assert item.signal is not None and item.signal.entry_type == "LIMIT"
    assert item.signal.score == item.score
    assert item.signal.entry_price == Decimal("49995.00")
    assert item.signal.stop_loss == Decimal("49989.90")
    assert item.signal.take_profit == Decimal("50005.20")
    assert item.plan is not None and item.plan.quantity > 0
    assert item.plan.risk_usdt <= Decimal("2.5")
    assert "DYNAMIC_SL_BEYOND_OB_INVALIDATION" in item.signal.reason_codes
    assert dict(item.parameter_snapshot)["entry_model"] == "LIMIT_RETRACEMENT"

    second = planner.evaluate(_evidence(), equity_usdt=Decimal("1000"))
    assert second.evaluations[0].status == "ALREADY_EMITTED"
    assert second.plans == ()


def test_confirmation_market_is_a_separate_market_trigger():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(entry_model="CONFIRMATION_MARKET", min_candidate_score=50))
    result = planner.evaluate(_evidence(include_retest=True), equity_usdt=Decimal("1000"))
    item = result.evaluations[0]
    assert item.status == "PLANNED"
    assert item.signal is not None
    assert item.signal.entry_type == "MARKET"
    assert item.signal.entry_price == Decimal("50100.0")


def test_confirmation_market_rejects_without_directional_closed_candle():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(entry_model="CONFIRMATION_MARKET", min_candidate_score=50))
    result = planner.evaluate(
        _evidence(candle_open="50110.0", candle_close="50100.0", include_retest=True),
        equity_usdt=Decimal("1000"),
    )
    assert result.evaluations[0].status == "REJECTED"
    assert "BULLISH_MARKET_CONFIRMATION_NOT_MET" in result.evaluations[0].reason_codes


def test_optional_fvg_confluence_is_not_a_hard_gate_by_default_but_can_be_required():
    default = SMCV2TradePlanner(config=SMCTradePlannerConfig())
    assert default.evaluate(_evidence(), equity_usdt=Decimal("1000")).evaluations[0].status == "PLANNED"

    required = SMCV2TradePlanner(config=SMCTradePlannerConfig(require_fvg=True))
    result = required.evaluate(_evidence(), equity_usdt=Decimal("1000"))
    assert result.evaluations[0].status == "REJECTED"
    assert "REQUIRED_FVG_CONFLUENCE_MISSING" in result.evaluations[0].reason_codes


def test_invalidated_ob_is_rejected_with_traceable_reason():
    planner = SMCV2TradePlanner()
    result = planner.evaluate(
        _evidence(lifecycle_status="INVALIDATED"), equity_usdt=Decimal("1000"),
    )
    assert result.evaluations[0].status == "REJECTED"
    assert "OB_LIFECYCLE_INVALIDATED" in result.evaluations[0].reason_codes


def test_confirmed_unbroken_structure_target_replaces_rr_target_when_it_meets_minimum_r():
    pivot = StructurePivot(
        pivot_id="target-high-1", symbol="BTCUSDT", timeframe="1m", layer="SWING",
        kind="HIGH", price=Decimal("50120.0"), source_open_time_ms=CAPTURE_MS - 300_000,
        confirmation_close_time_ms=CAPTURE_MS - 120_000, source_index=1, confirmation_index=3,
    )
    broken = StructurePivotState(replace(pivot, pivot_id="broken-high", price=Decimal("50200.0")), True)
    active = StructurePivotState(pivot, False)
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(prefer_structural_target=True))
    result = planner.evaluate(_evidence(pivots=(broken, active)), equity_usdt=Decimal("1000"))
    assert result.evaluations[0].status == "PLANNED"
    assert result.evaluations[0].signal is not None
    assert result.evaluations[0].signal.take_profit == Decimal("50120.0")
    assert "TARGET_CONFIRMED_STRUCTURE_PIVOT" in result.evaluations[0].signal.reason_codes


def test_m15_is_advisory_and_opposing_context_does_not_veto_by_default():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(require_m15_alignment=False))
    result = planner.evaluate(_evidence(m15_direction=-1), equity_usdt=Decimal("1000"))
    assert result.evaluations[0].status == "PLANNED"
    assert "M15_ADVISORY_OPPOSES_SETUP_NO_HARD_VETO" in result.evaluations[0].reason_codes


def test_missing_min_notional_filter_fails_closed_for_trade_planning():
    planner = SMCV2TradePlanner()
    result = planner.evaluate(_evidence(min_notional=None), equity_usdt=Decimal("1000"))
    assert result.evaluations[0].status == "REJECTED"
    assert "NOTIONAL_FILTER_MINIMUM_UNAVAILABLE" in result.evaluations[0].reason_codes


def test_candidate_ranking_orders_higher_scored_setups_before_risk_sizing():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(min_candidate_score=50))
    result = planner.evaluate(
        _evidence(include_touched=True), equity_usdt=Decimal("1000"),
    )
    assert len(result.evaluations) == 2
    assert result.evaluations[0].rank == 1
    assert result.evaluations[0].candidate is not None
    assert result.evaluations[0].candidate.lifecycle_status == "ACTIVE_FRESH"
    assert result.evaluations[1].rank == 2
    assert result.evaluations[1].candidate is not None
    assert result.evaluations[1].candidate.lifecycle_status == "TOUCHED"
    assert "CANDIDATE_SCORE_RANK_1" in result.evaluations[0].reason_codes


def test_qualification_only_defers_all_final_sizing_to_autonomous_dispatcher():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig(entry_model="LIMIT_RETRACEMENT"))
    result = planner.evaluate(
        _evidence(), equity_usdt=Decimal("1000"), qualification_only=True,
    )
    assert len(result.evaluations) == 1
    item = result.evaluations[0]
    assert item.status == "QUALIFIED"
    assert item.signal is not None
    assert item.plan is None
    assert result.plans == ()
    assert result.qualified_signals == (item.signal,)
    assert "DEFERRED_TO_AUTONOMOUS_GLOBAL_RISK" in item.reason_codes
