from decimal import Decimal
import pytest
from divatrading.execution.account_state import BinanceAccountStateService

class Fake:
    def get_exchange_account(self):
        return {"totalWalletBalance":"1000","totalMarginBalance":"1025","availableBalance":"800"}
    def get_position_risk(self, symbol=None):
        return [
          {"symbol":"BTCUSDT","positionSide":"BOTH","positionAmt":"0.01","entryPrice":"60000","markPrice":"61000","unRealizedProfit":"10","notional":"610","isolated":"false"},
          {"symbol":"ETHUSDT","positionAmt":"0","entryPrice":"0","markPrice":"0","unRealizedProfit":"0","notional":"0"},
        ]
    def get_open_orders(self, symbol=None): return [{"symbol":"BTCUSDT","status":"NEW"}]
    def get_open_algo_orders(self, symbol=None): return [{"symbol":"BTCUSDT","algoStatus":"NEW"}]

def test_snapshot_uses_exchange_truth_and_conservative_risk():
    snap=BinanceAccountStateService(Fake()).capture()
    assert snap.wallet_balance == Decimal("1000")
    assert snap.equity == Decimal("1025")
    assert snap.available_balance == Decimal("800")
    assert snap.active_position_count == 1
    assert snap.symbol_notional("BTCUSDT") == Decimal("610")
    assert snap.open_risk_usdt == Decimal("610")
    assert len(snap.open_standard_orders) == len(snap.open_algo_orders) == 1

def test_incomplete_account_snapshot_fails_closed():
    class Bad(Fake):
        def get_exchange_account(self): return {"totalWalletBalance":"NaN"}
    with pytest.raises(ValueError): BinanceAccountStateService(Bad()).capture()
