import asyncio
from pathlib import Path

import pytest

from divatrading.trading.live_runtime import LiveMarketRuntimeConfig, MultiPairLiveMarketRuntime
from divatrading.trading.universe import SymbolUniverseConfig


FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


class FakeRest:
    exchange_info_endpoint = "https://fapi.binance.com/fapi/v1/exchangeInfo"

    def __init__(self):
        self.payload = __import__("json").loads(FIXTURE.read_text())

    def get_exchange_info(self):
        return self.payload

    def get_ticker_24h(self):
        return [
            {"symbol": item["symbol"], "quoteVolume": "50000000", "count": 5000}
            for item in self.payload["symbols"]
            if item.get("quoteAsset") == "USDT"
        ]


@pytest.mark.asyncio
async def test_runtime_refresh_selects_symbols_and_starts_workers():
    started = []

    async def feed(symbol):
        started.append(symbol)
        if False:
            yield None

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(mode="AUTO", max_active_symbols=3,
                                      min_quote_volume_usdt=__import__("decimal").Decimal("1"),
                                      min_trade_count_24h=1),
        max_concurrent_workers=3,
        worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(rest_client=FakeRest(), feed_factory=feed, config=cfg)
    selected = await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    assert len(selected.symbols) == 2
    assert set(started) == set(selected.symbols)
    assert set(runtime.snapshot.selected_symbols) == set(selected.symbols)
    await runtime.stop()


def test_runtime_config_rejects_unbounded_symbol_count():
    with pytest.raises(ValueError):
        LiveMarketRuntimeConfig(
            universe=SymbolUniverseConfig(max_active_symbols=25),
            max_concurrent_workers=24,
        )


@pytest.mark.asyncio
async def test_runtime_is_read_only_and_rejects_non_async_feed():
    async def bad_feed(symbol):
        return []

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(mode="MANUAL", manual_symbols=("BTCUSDT",),
                                      max_active_symbols=1),
        max_concurrent_workers=1,
        worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(rest_client=FakeRest(), feed_factory=bad_feed, config=cfg)
    await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    status = runtime.snapshot.workers[0]
    assert status.status == "DEGRADED"
    assert "TypeError" in status.last_error
    await runtime.stop()


@pytest.mark.asyncio
async def test_runtime_publishes_selected_exchange_instruments_before_workers_start():
    from divatrading.strategy.scalping_market_data import InstrumentSpec

    observed = []

    def on_universe(selection, metadata):
        observed.append((selection.symbols, metadata.source_endpoint))

    async def feed(symbol):
        if False:
            yield None

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(
            mode="MANUAL", manual_symbols=("BTCUSDT",), max_active_symbols=1,
        ),
        max_concurrent_workers=1, worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(
        rest_client=FakeRest(), feed_factory=feed, on_universe=on_universe, config=cfg,
    )
    selected = await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    assert observed == [(selected.symbols, FakeRest.exchange_info_endpoint)]
    assert selected.symbols == ("BTCUSDT",)
    await runtime.stop()
