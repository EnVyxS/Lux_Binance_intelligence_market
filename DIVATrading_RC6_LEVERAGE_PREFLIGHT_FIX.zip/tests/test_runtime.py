import pytest

from divatrading.core.runtime import RuntimeCompatibilityError, SUPPORTED_PYTHON, validate_runtime


def test_supported_runtime_version_and_bitness() -> None:
    info = validate_runtime(version=SUPPORTED_PYTHON, bitness=64)
    assert info.bitness == 64


def test_wrong_python_version_is_rejected() -> None:
    with pytest.raises(RuntimeCompatibilityError, match="Python 3.12.9 is required"):
        validate_runtime(version=(3, 13, 5), bitness=64)


def test_32_bit_runtime_is_rejected() -> None:
    with pytest.raises(RuntimeCompatibilityError, match="64-bit Python is required"):
        validate_runtime(version=SUPPORTED_PYTHON, bitness=32)
