from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from divatrading.cli import main
from divatrading.market_data.klines import INTERVAL_MILLISECONDS
from divatrading.replay import (
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayMetadataSnapshot,
    ReplayWorkflowEligibilityError,
    ReplayWorkflowError,
    run_stage6b_workflow,
)

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "tests" / "fixtures" / "exchange_info_valid.json"
PLAN_SCHEMA = ROOT / "docs" / "schemas" / "stage6b_workflow_plan.schema.json"
REPORT_SCHEMA = ROOT / "docs" / "schemas" / "stage6b_workflow_report.schema.json"


def _metadata(quality: str = "HISTORICAL_EFFECTIVE") -> ReplayMetadataSnapshot:
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    symbol = next(item for item in payload["symbols"] if item["symbol"] == "BTCUSDT")
    return ReplayMetadataSnapshot.from_symbol_payload(
        symbol,
        quality=quality,
        source_url="https://fapi.binance.com/fapi/v1/exchangeInfo",
        captured_at_ms=5_000_000,
        effective_from_ms=0 if quality == "HISTORICAL_EFFECTIVE" else None,
        effective_to_ms=5_000_000 if quality == "HISTORICAL_EFFECTIVE" else None,
    )


def _write_source(root: Path, interval: str, start: int, end: int) -> ReplayKlineFile:
    step = INTERVAL_MILLISECONDS[interval]
    path = root / f"BTCUSDT-{interval}.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        for opened in range(start, end, step):
            absolute_index = opened // step
            op = 100.0 + (absolute_index % 5) * 0.1
            writer.writerow([
                opened, f"{op:.1f}", f"{op + 0.5:.1f}", f"{op - 0.5:.1f}",
                f"{op + (0.1 if absolute_index % 2 else -0.1):.1f}", "10",
                opened + step - 1, "1000", 10, "5", "500", "0",
            ])
    return ReplayKlineFile.inspect(
        root, path.name, interval, symbol="BTCUSDT", source_url="fixture://native-kline"
    )


def _build_workflow_plan(
    tmp_path: Path, *, gap_trial: str | None = None,
    replay_mode: str = "STRICT", metadata_quality: str = "HISTORICAL_EFFECTIVE",
) -> Path:
    end_ms = 4_200_000
    trials = []
    for index, start_ms in enumerate((0, 900_000, 1_800_000)):
        trial_id = ("short", "medium", "long")[index]
        root = tmp_path / trial_id
        root.mkdir()
        files = []
        for interval in ("1m", "5m"):
            item = _write_source(root, interval, start_ms, end_ms)
            if gap_trial == trial_id and interval == "1m":
                source = root / item.path
                rows = list(csv.reader(source.open(encoding="utf-8")))
                rows = [row for row in rows if int(row[0]) != start_ms + 3 * INTERVAL_MILLISECONDS["1m"]]
                with source.open("w", newline="", encoding="utf-8") as handle:
                    csv.writer(handle).writerows(rows)
                item = ReplayKlineFile.inspect(root, item.path, interval, symbol="BTCUSDT")
            files.append(item)
        manifest = ReplayDatasetManifest(
            symbol="BTCUSDT",
            start_open_time_ms=start_ms,
            end_open_time_ms=end_ms,
            files=tuple(files),
            metadata=_metadata(metadata_quality),
        )
        manifest_path = manifest.write(root / "manifest.json")
        trials.append({
            "trial_id": trial_id,
            "manifest": str(manifest_path.relative_to(tmp_path)),
            "root": str(root.relative_to(tmp_path)),
        })

    plan = {
        "workflow_schema_version": 1,
        "replay_mode": replay_mode,
        "evaluation_window": {"start_ms": 2_400_000, "end_ms_exclusive": end_ms},
        "metadata_evidence_ref": "fixture://retained-exchange-info-capture",
        "output_dir": "workflow_output",
        "replay_config": {"max_history_candles": 128, "checkpoint_every_captures": 2},
        "trials": trials,
    }
    path = tmp_path / "workflow_plan.json"
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return path


def _input_hashes(plan_path: Path) -> dict[str, str]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    base = plan_path.parent.resolve()
    result = {}

    for trial in plan["trials"]:
        root = Path(trial["root"])
        if not root.is_absolute():
            root = base / root
        root = root.resolve()

        manifest = Path(trial["manifest"])
        if not manifest.is_absolute():
            manifest = base / manifest
        manifest = manifest.resolve()

        result[str(manifest)] = hashlib.sha256(
            manifest.read_bytes()
        ).hexdigest()

        for filename in ("BTCUSDT-1m.csv", "BTCUSDT-5m.csv"):
            path = root / filename
            result[str(path)] = hashlib.sha256(
                path.read_bytes()
            ).hexdigest()

    return result


def test_integrated_stage6b_workflow_replays_resumes_analyzes_and_compares_deterministically(tmp_path):
    plan_path = _build_workflow_plan(tmp_path)
    before = _input_hashes(plan_path)
    report_path = tmp_path / "workflow_report.json"
    report = run_stage6b_workflow(plan_path, report_path)
    repeated = run_stage6b_workflow(plan_path, report_path)

    assert report == repeated
    assert report["report_sha256"] == repeated["report_sha256"]
    assert report["workflow_status"] == "COMPLETED"
    assert report["stage_order"][0] == "RAW_SOURCE_QUALITY_AUDIT"
    assert report["convergence"]["comparison_mode"] == "THREE_PLUS_TRIAL_COMPARISON"
    assert report["convergence"]["pairwise_comparison_count"] == 24
    assert report["convergence"]["automatic_convergence_verdict"] is False
    assert report["state_policy"] == "ONE_CONTINUOUS_REPLAY_NO_SPLIT_OR_EVALUATION_RESET"
    assert all(item["quality"]["quality_status"] == "PASS" for item in report["trials"])
    assert all(item["replay"]["restart_probe"] == "PARTIAL_CHECKPOINT_RESUMED_TO_COMPLETION" for item in report["trials"])
    assert all(item["replay"]["checkpoint_completed"] is True for item in report["trials"])
    assert all(item["analytics"]["state_policy"] == "ONE_CONTINUOUS_REPLAY_NO_SPLIT_RESET" for item in report["trials"])
    assert _input_hashes(plan_path) == before

    schema = json.loads(REPORT_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(report)
    for item in report["trials"]:
        trial_root = tmp_path / "workflow_output" / item["trial_id"]
        checkpoint = json.loads((trial_root / "replay.checkpoint.json").read_text(encoding="utf-8"))
        assert checkpoint["completed"] is True
        assert (trial_root / "replay.jsonl").is_file()
        assert (trial_root / "analytics_report.json").is_file()
    assert (tmp_path / "workflow_output" / "convergence_report.json").is_file()


def test_quality_gap_is_reported_but_strict_gate_blocks_replay(tmp_path):
    plan_path = _build_workflow_plan(tmp_path, gap_trial="medium")
    report_path = tmp_path / "must_not_exist.json"
    with pytest.raises(ReplayWorkflowEligibilityError, match="strict replay eligibility rejected"):
        run_stage6b_workflow(plan_path, report_path)
    quality_path = tmp_path / "workflow_output" / "medium" / "quality_report.json"
    quality = json.loads(quality_path.read_text(encoding="utf-8"))
    assert quality["quality_summary"]["quality_status"] == "WARN"
    assert quality["quality_summary"]["strict_replay_eligible"] is False
    assert "INTERNAL_GAPS" in quality["quality_summary"]["warning_codes"]
    assert not (tmp_path / "workflow_output" / "medium" / "replay.jsonl").exists()
    assert not report_path.exists()



def test_provisional_workflow_runs_strategy_evidence_with_current_metadata_but_not_execution_validation(tmp_path):
    plan_path = _build_workflow_plan(
        tmp_path, replay_mode="PROVISIONAL_STRATEGY_EVIDENCE",
        metadata_quality="CURRENT_SNAPSHOT_ONLY",
    )
    report_path = tmp_path / "provisional_report.json"
    report = run_stage6b_workflow(plan_path, report_path)
    assert report["workflow_status"] == "COMPLETED_PROVISIONAL"
    assert report["replay_mode"] == "PROVISIONAL_STRATEGY_EVIDENCE"
    assert report["qualification"] == {
        "market_data_gate": "PASS",
        "execution_metadata_gate": "BLOCKED",
        "strict_execution_eligible": False,
        "result_scope": "STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION",
    }
    assert all(item["quality"]["market_data_eligible"] is True for item in report["trials"])
    assert all(item["quality"]["market_data_status"] == "PASS" for item in report["trials"])
    assert all(item["quality"]["execution_metadata_status"] == "BLOCKED" for item in report["trials"])
    assert all(item["quality"]["strict_replay_eligible"] is False for item in report["trials"])
    schema = json.loads(REPORT_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(report)


def test_provisional_workflow_still_rejects_market_data_gaps(tmp_path):
    plan_path = _build_workflow_plan(
        tmp_path, gap_trial="medium", replay_mode="PROVISIONAL_STRATEGY_EVIDENCE",
        metadata_quality="CURRENT_SNAPSHOT_ONLY",
    )
    with pytest.raises(ReplayWorkflowEligibilityError, match="provisional strategy replay rejected"):
        run_stage6b_workflow(plan_path, tmp_path / "blocked_provisional_report.json")
    quality_path = tmp_path / "workflow_output" / "medium" / "quality_report.json"
    quality = json.loads(quality_path.read_text(encoding="utf-8"))
    assert quality["eligibility_gates"]["market_data"]["status"] == "WARN"
    assert quality["eligibility_gates"]["provisional_strategy_replay_eligible"] is False
    assert not (tmp_path / "workflow_output" / "medium" / "replay.jsonl").exists()


def test_tampered_source_fails_before_quality_or_replay(tmp_path):
    plan_path = _build_workflow_plan(tmp_path)
    source = tmp_path / "short" / "BTCUSDT-1m.csv"
    source.write_text(source.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    with pytest.raises(ReplayWorkflowError, match="source hash differs from manifest"):
        run_stage6b_workflow(plan_path, tmp_path / "report.json")
    assert not (tmp_path / "workflow_output" / "short" / "quality_report.json").exists()


def test_replay_workflow_cli_validates_plan_and_writes_report(tmp_path, capsys):
    plan_path = _build_workflow_plan(tmp_path)
    report_path = tmp_path / "cli_report.json"
    assert main(["replay-workflow", "--plan", str(plan_path), "--report", str(report_path)]) == 0
    output = capsys.readouterr().out
    assert "Integrated Stage 6B replay workflow completed" in output
    report = json.loads(report_path.read_text(encoding="utf-8"))
    schema = json.loads(REPORT_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(report)


def test_workflow_plan_schema_rejects_duplicate_or_malformed_trial_shape(tmp_path):
    schema = json.loads(PLAN_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    invalid = {
        "workflow_schema_version": 1,
        "evaluation_window": {"start_ms": 10, "end_ms_exclusive": 5},
        "metadata_evidence_ref": "fixture://metadata",
        "trials": [{"trial_id": "x", "manifest": "m.json"}],
    }
    errors = list(Draft202012Validator(schema).iter_errors(invalid))
    assert errors
