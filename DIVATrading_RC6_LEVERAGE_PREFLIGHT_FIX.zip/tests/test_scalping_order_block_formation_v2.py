from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json

import pytest

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.strategy.scalping_market_data import ScalpingMarketDataAdapter
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureEngine,
)
from divatrading.strategy.scalping_order_block_formation import (
    ScalpingOrderBlockFormationConfig,
    ScalpingOrderBlockFormationEngine,
    ScalpingOrderBlockFormationInputError,
)

NOW = 1_800_000_000_000


def instrument(symbol: str = "BTCUSDT") -> SymbolInfo:
    payload = json.loads((__import__("pathlib").Path(__file__).parent / "fixtures" / "exchange_info_valid.json").read_text(encoding="utf-8"))
    return SymbolInfo.from_payload(next(item for item in payload["symbols"] if item["symbol"] == symbol))


def make_candle(interval: str, open_time: int, values: tuple[str, str, str, str], symbol: str = "BTCUSDT") -> Kline:
    op, hi, lo, cl = values
    span = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, op, hi, lo, cl, "10", open_time + span - 1, "1000", 10, "5", "500", "0"],
        symbol=symbol, interval=interval, source_endpoint="https://fixture/klines",
    )


def view_for(*, m1_values=None, m5_values=None, m15_values=None, now_ms=NOW, symbol="BTCUSDT"):
    items = []
    for interval, values in (("1m", m1_values), ("5m", m5_values), ("15m", m15_values)):
        if values is None:
            continue
        span = INTERVAL_MILLISECONDS[interval]
        last_open = (now_ms // span - 1) * span
        first_open = last_open - (len(values) - 1) * span
        candles = tuple(make_candle(interval, first_open + i * span, row, symbol) for i, row in enumerate(values))
        items.append(KlineSeriesInput(
            symbol=symbol, interval=interval, candles=candles,
            source_observed_at_ms=now_ms - 100, source_healthy=True, source_complete=True,
        ))
    return ScalpingMarketDataAdapter().build_view(
        symbol=symbol, now_ms=now_ms, symbol_info=instrument(symbol), kline_series=tuple(items)
    )


BULL_ROWS = [
    ("102.0", "105.0", "101.0", "103.0"),
    ("104.0", "110.0", "100.0", "108.0"),
    ("106.0", "108.0", "102.0", "105.0"),
    ("109.0", "112.0", "104.0", "111.0"),
]
BEAR_ROWS = BULL_ROWS + [("100.0", "111.0", "98.0", "99.0")]


def build_structure(view, **config):
    settings = dict(
        swing_left_bars=1, swing_right_bars=1,
        internal_left_bars=1, internal_right_bars=1,
    )
    settings.update(config)
    return ScalpingMarketStructureEngine(config=ScalpingMarketStructureConfig(**settings)).process(view)


def build(view, **config):
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(**config))
    return engine, structure, engine.process(structure, view)


def test_bullish_structure_break_forms_last_bearish_candle_as_full_wick_ob():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    _, structure, result = build(view)
    m1 = result.timeframe("1m")
    assert m1 is not None
    swing_event = next(event for event in structure.timeframe("1m").events if event.layer == "SWING")
    candidate = next(item for item in m1.candidates if item.event_id == swing_event.event_id)
    assert candidate.direction == 1
    assert candidate.source_bar_index == 2
    assert candidate.source_open == Decimal("106.0")
    assert candidate.source_close == Decimal("105.0")
    assert candidate.zone_top == Decimal("108.0")
    assert candidate.zone_bottom == Decimal("102.0")
    assert candidate.zone_boundary_convention == "FULL_SOURCE_CANDLE_WICK"
    assert candidate.broken_structure_level == Decimal("110.0")
    assert candidate.break_bar_index == 3


def test_bearish_structure_break_forms_last_bullish_candle_as_full_wick_ob():
    view = view_for(m1_values=BEAR_ROWS, m5_values=BEAR_ROWS)
    _, structure, result = build(view)
    m1 = result.timeframe("1m")
    assert m1 is not None
    swing_event = next(event for event in structure.timeframe("1m").events if event.layer == "SWING" and event.direction == -1)
    candidate = next(item for item in m1.candidates if item.event_id == swing_event.event_id)
    assert candidate.direction == -1
    assert candidate.source_bar_index == 3
    assert candidate.source_open == Decimal("109.0")
    assert candidate.source_close == Decimal("111.0")
    assert candidate.zone_top == Decimal("112.0")
    assert candidate.zone_bottom == Decimal("104.0")


def test_displacement_measurements_are_exact_and_trace_fvg_as_not_evaluated():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    _, structure, result = build(view)
    event = next(event for event in structure.timeframe("1m").events if event.layer == "SWING")
    candidate = next(item for item in result.timeframe("1m").candidates if item.event_id == event.event_id)
    metrics = candidate.displacement
    assert metrics.break_body == Decimal("2.0")
    assert metrics.break_full_range == Decimal("8.0")
    assert metrics.break_body_range_ratio == Decimal("0.25")
    assert metrics.close_extension == Decimal("1.0")
    assert metrics.close_extension_ticks == Decimal("10")
    assert metrics.directional_leg_candle_count == 1
    assert metrics.leg_body_sum == Decimal("2.0")
    assert metrics.leg_full_range_sum == Decimal("8.0")
    assert metrics.leg_body_range_ratio == Decimal("0.25")
    assert metrics.fvg_evidence_present is None
    assert metrics.fvg_evidence_status == "NOT_EVALUATED"


def test_numeric_threshold_equality_passes_for_body_ratio_leg_ratio_and_extension():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(
        min_break_body_range_ratio=Decimal("0.25"),
        min_leg_body_range_ratio=Decimal("0.25"),
        min_close_extension_ticks=Decimal("10"),
    ))
    result = engine.process(structure, view)
    assert any(item.timeframe == "1m" and item.candidates for item in result.timeframes)


def test_explicit_numeric_threshold_rejects_below_cutoff_with_reason_codes():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(
        min_break_body_range_ratio=Decimal("0.251"),
    ))
    result = engine.process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None and not m1.candidates
    trace = next(item for item in m1.traces if item.reason_codes == ("BREAK_BODY_RANGE_RATIO_BELOW_MINIMUM",))
    assert trace.outcome == "REJECTED"
    assert trace.displacement is not None


def test_minimum_close_extension_is_measured_in_exact_symbol_ticks():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(
        min_close_extension_ticks=Decimal("10.1"),
    ))
    result = engine.process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None and not m1.candidates
    assert any("CLOSE_EXTENSION_TICKS_BELOW_MINIMUM" in item.reason_codes for item in m1.traces)


def test_last_opposing_candle_search_skips_doji_and_uses_nearest_opposing_source():
    rows = [
        BULL_ROWS[0], BULL_ROWS[1], BULL_ROWS[2],
        ("105.0", "109.0", "103.0", "105.0"),  # doji before break candle
        ("106.0", "112.0", "104.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    _, structure, result = build(view, ob_source_lookback_bars=2)
    m1 = result.timeframe("1m")
    assert m1 is not None
    event = next(event for event in structure.timeframe("1m").events if event.layer == "SWING" and event.direction == 1)
    candidate = next(item for item in m1.candidates if item.event_id == event.event_id)
    assert candidate.source_bar_index == 2


def test_source_lookback_boundary_is_inclusive_and_bounded():
    rows = [
        BULL_ROWS[0], BULL_ROWS[1], BULL_ROWS[2],
        ("105.0", "109.0", "103.0", "105.0"),
        ("106.0", "112.0", "104.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    accepted = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(ob_source_lookback_bars=2)).process(structure, view)
    rejected = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(ob_source_lookback_bars=1)).process(structure, view)
    accepted_m1 = accepted.timeframe("1m")
    rejected_m1 = rejected.timeframe("1m")
    assert accepted_m1 is not None and accepted_m1.candidates
    assert rejected_m1 is not None and not rejected_m1.candidates
    assert any("LAST_OPPOSING_SOURCE_CANDLE_NOT_FOUND" in item.reason_codes for item in rejected_m1.traces)


def test_no_opposing_source_candle_rejects_candidate():
    rows = [
        ("101.0", "105.0", "100.0", "103.0"),
        ("103.0", "110.0", "101.0", "108.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "112.0", "104.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None and not m1.candidates
    assert any("LAST_OPPOSING_SOURCE_CANDLE_NOT_FOUND" in item.reason_codes for item in m1.traces)


def test_wrong_color_source_is_not_accepted_as_valid_ob():
    rows = [
        ("101.0", "105.0", "100.0", "103.0"),
        ("103.0", "110.0", "101.0", "108.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "112.0", "104.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert not m1.candidates
    assert all(item.source_bar_index is None for item in m1.traces)


def test_break_candle_direction_mismatch_is_rejected():
    rows = BULL_ROWS[:3] + [("112.0", "113.0", "109.0", "111.0")]  # red body but closes beyond pivot
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    assert any(event.direction == 1 for event in structure.timeframe("1m").events)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None and not m1.candidates
    assert any("BREAK_BAR_DIRECTION_MISMATCH" in item.reason_codes for item in m1.traces)


def test_displacement_leg_counts_consecutive_directional_candles():
    rows = [
        BULL_ROWS[0], BULL_ROWS[1], BULL_ROWS[2],
        ("107.0", "110.0", "106.0", "109.0"),
        ("109.0", "112.0", "108.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    _, structure, result = build(view)
    m1 = result.timeframe("1m")
    assert m1 is not None
    event = next(event for event in structure.timeframe("1m").events if event.layer == "SWING" and event.direction == 1)
    candidate = next(item for item in m1.candidates if item.event_id == event.event_id)
    assert candidate.displacement.directional_leg_candle_count == 2
    assert candidate.displacement.directional_leg_start_index == 3


def test_maximum_directional_leg_bound_fails_closed_when_leg_exceeds_cap():
    rows = [
        BULL_ROWS[0], BULL_ROWS[1], BULL_ROWS[2],
        ("106.0", "109.0", "105.0", "108.0"),
        ("108.0", "110.0", "107.0", "109.0"),
        ("109.0", "112.0", "108.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig(
        max_displacement_leg_candles=2,
    )).process(structure, view)
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert any("DISPLACEMENT_LEG_LOOKBACK_EXCEEDED" in item.reason_codes for item in m1.traces)


def test_m1_m5_candidates_are_independent_and_m15_is_advisory_only():
    view = view_for(m1_values=BULL_ROWS, m5_values=BEAR_ROWS, m15_values=BEAR_ROWS)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    m1 = result.timeframe("1m")
    m5 = result.timeframe("5m")
    m15 = result.timeframe("15m")
    assert m1 is not None and m1.candidates
    assert m5 is not None and m5.candidates
    assert m15 is not None and m15.status == "ADVISORY_ONLY"
    assert not m15.candidates
    assert {item.timeframe for item in result.candidates} == {"1m", "5m"}


def test_repeated_same_structure_result_is_idempotent():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine()
    first = engine.process(structure, view)
    second = engine.process(structure, view)
    assert len(first.timeframe("1m").candidates) == len(second.timeframe("1m").candidates)
    assert first.timeframe("1m").processed_event_count == second.timeframe("1m").processed_event_count


def test_duplicate_structure_event_id_with_conflicting_content_fails_closed():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None and m1.events
    altered = replace(m1.events[0], protected_price=m1.events[0].protected_price + Decimal("0.1"))
    bad_m1 = replace(m1, events=m1.events + (altered,))
    bad_structure = replace(structure, timeframes=tuple(bad_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    with pytest.raises(ScalpingOrderBlockFormationInputError, match="conflicting content"):
        ScalpingOrderBlockFormationEngine().process(bad_structure, view)


def test_missing_break_bar_trace_is_rejected_with_provenance_reason():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None and m1.events
    break_time = m1.events[0].break_bar_open_time_ms
    traces = tuple(item for item in m1.bar_traces if item.bar_open_time_ms != break_time)
    bad_m1 = replace(m1, bar_traces=traces)
    bad_structure = replace(structure, timeframes=tuple(bad_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    result = ScalpingOrderBlockFormationEngine().process(bad_structure, view)
    out = result.timeframe("1m")
    assert out is not None and not out.candidates
    assert any("STRUCTURE_EVENT_TRACE_MISSING" in item.reason_codes for item in out.traces)


def test_stage3_preflight_is_atomic_across_m1_and_m5():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m5 = structure.timeframe("5m")
    assert m5 is not None
    break_trace = next(item for item in m5.bar_traces if item.events)
    bad_trace = replace(break_trace, close=break_trace.close + Decimal("0.01"))
    bad_m5 = replace(m5, bar_traces=tuple(bad_trace if item.bar_index == break_trace.bar_index else item for item in m5.bar_traces))
    bad_structure = replace(structure, timeframes=tuple(bad_m5 if item.timeframe == "5m" else item for item in structure.timeframes))
    engine = ScalpingOrderBlockFormationEngine()
    with pytest.raises(ScalpingOrderBlockFormationInputError, match="tick"):
        engine.process(bad_structure, view)
    valid_after = engine.process(structure, view)
    assert valid_after.timeframe("1m").candidates
    assert valid_after.timeframe("5m").candidates
    assert valid_after.timeframe("1m").processed_event_count == len(structure.timeframe("1m").events)


def test_ob_source_and_zone_prices_must_remain_on_exact_tick_grid():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None
    source_trace = next(item for item in m1.bar_traces if item.bar_index == 2)
    bad_source = replace(source_trace, high=source_trace.high + Decimal("0.01"))
    bad_m1 = replace(m1, bar_traces=tuple(bad_source if item.bar_index == 2 else item for item in m1.bar_traces))
    bad_structure = replace(structure, timeframes=tuple(bad_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    with pytest.raises(ScalpingOrderBlockFormationInputError, match="tick"):
        ScalpingOrderBlockFormationEngine().process(bad_structure, view)


def test_capture_time_and_symbol_mismatch_are_rejected():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    with pytest.raises(ScalpingOrderBlockFormationInputError, match="capture identity"):
        ScalpingOrderBlockFormationEngine().process(replace(structure, captured_at_ms=NOW + 1), view)


def test_m15_events_do_not_create_candidates_or_suppress_m1_m5():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS, m15_values=BEAR_ROWS)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    assert result.timeframe("1m").candidates
    assert result.timeframe("5m").candidates
    assert result.timeframe("15m").candidates == ()


def test_reset_can_clear_one_symbol_timeframe_without_touching_another():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    engine = ScalpingOrderBlockFormationEngine()
    engine.process(structure, view)
    engine.reset(symbol="BTCUSDT", timeframe="1m")
    again = engine.process(structure, view)
    assert again.timeframe("1m").candidates
    assert again.timeframe("1m").processed_event_count > 0


def test_result_jsonl_is_deterministic_and_candidates_are_immutable():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    first = ScalpingOrderBlockFormationEngine().process(structure, view)
    second = ScalpingOrderBlockFormationEngine().process(structure, view)
    assert first.to_jsonl() == second.to_jsonl()
    candidate = first.timeframe("1m").candidates[0]
    with pytest.raises((AttributeError, TypeError)):
        candidate.zone_top = Decimal("1")


def test_config_rejects_invalid_thresholds_and_unbounded_values():
    with pytest.raises(ValueError):
        ScalpingOrderBlockFormationConfig(min_break_body_range_ratio=Decimal("1.01"))
    with pytest.raises(ValueError):
        ScalpingOrderBlockFormationConfig(min_close_extension_ticks=Decimal("-1"))
    with pytest.raises(ValueError):
        ScalpingOrderBlockFormationConfig(min_directional_leg_candles=9, max_displacement_leg_candles=8)
    with pytest.raises(ValueError):
        ScalpingOrderBlockFormationConfig(ob_source_lookback_bars=201)


def test_displacement_and_candidate_reason_codes_preserve_exact_structure_event_reference():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    result = ScalpingOrderBlockFormationEngine().process(structure, view)
    for tf in ("1m", "5m"):
        source_events = {item.event_id for item in structure.timeframe(tf).events}
        candidate_events = {item.event_id for item in result.timeframe(tf).candidates}
        assert candidate_events.issubset(source_events)
        for candidate in result.timeframe(tf).candidates:
            assert candidate.reason_codes == (
                "CONFIRMED_STRUCTURE_BREAK", "DIRECTIONAL_DISPLACEMENT_VALID",
                "LAST_OPPOSING_CANDLE_SELECTED", "FULL_WICK_ZONE",
            )


def test_missing_retained_source_history_rejects_instead_of_guessing():
    rows = [
        BULL_ROWS[0],
        ("109.0", "110.0", "100.0", "108.0"),  # opposing source candidate
        ("107.0", "109.0", "103.0", "107.0"),  # doji separates source and leg
        ("109.0", "112.0", "104.0", "111.0"),  # confirmed bullish break
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None
    # Preserve break and leg-boundary bars, but remove the only source candidate.
    sparse = tuple(item for item in m1.bar_traces if item.bar_index in (0, 2, 3))
    bad_m1 = replace(m1, bar_traces=sparse)
    bad_structure = replace(structure, timeframes=tuple(bad_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    result = ScalpingOrderBlockFormationEngine().process(bad_structure, view)
    output = result.timeframe("1m")
    assert output is not None and not output.candidates
    assert any("OB_SOURCE_HISTORY_INSUFFICIENT" in item.reason_codes for item in output.traces)


def test_break_event_payload_must_match_its_embedded_bar_trace():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None and m1.events
    altered = replace(m1.events[0], confirmation_close=m1.events[0].confirmation_close + Decimal("0.1"))
    bad_m1 = replace(m1, events=(altered,) + m1.events[1:])
    bad_structure = replace(structure, timeframes=tuple(bad_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    with pytest.raises(ScalpingOrderBlockFormationInputError, match="event content does not match"):
        ScalpingOrderBlockFormationEngine().process(bad_structure, view)


def test_identical_duplicate_event_in_one_batch_is_processed_once():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None and m1.events
    duplicate = replace(m1, events=m1.events + (m1.events[0],))
    bad_structure = replace(structure, timeframes=tuple(duplicate if item.timeframe == "1m" else item for item in structure.timeframes))
    result = ScalpingOrderBlockFormationEngine().process(bad_structure, view)
    output = result.timeframe("1m")
    assert output is not None
    assert output.processed_event_count == len(m1.events)
    assert len([item for item in output.traces if item.event_id == m1.events[0].event_id]) == 1


def test_source_search_stops_after_nearest_opposing_candle_without_needing_older_tail():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None
    # The nearest opposing candle is bar 2; older bar 1/0 data is unnecessary.
    sparse = tuple(item for item in m1.bar_traces if item.bar_index in (2, 3))
    sparse_m1 = replace(m1, bar_traces=sparse)
    sparse_structure = replace(structure, timeframes=tuple(sparse_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    result = ScalpingOrderBlockFormationEngine().process(sparse_structure, view)
    output = result.timeframe("1m")
    assert output is not None
    assert output.candidates
    assert all(item.source_bar_index == 2 for item in output.candidates)


def test_missing_previous_break_bar_trace_rejects_structure_event():
    view = view_for(m1_values=BULL_ROWS, m5_values=BULL_ROWS)
    structure = build_structure(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None
    sparse = tuple(item for item in m1.bar_traces if item.bar_index == 3)
    sparse_m1 = replace(m1, bar_traces=sparse)
    sparse_structure = replace(structure, timeframes=tuple(sparse_m1 if item.timeframe == "1m" else item for item in structure.timeframes))
    result = ScalpingOrderBlockFormationEngine().process(sparse_structure, view)
    output = result.timeframe("1m")
    assert output is not None and not output.candidates
    assert any("STRUCTURE_EVENT_PREVIOUS_BAR_TRACE_MISSING" in item.reason_codes for item in output.traces)
