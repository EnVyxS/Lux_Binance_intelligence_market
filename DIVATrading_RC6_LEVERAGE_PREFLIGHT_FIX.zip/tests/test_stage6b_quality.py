from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from jsonschema import Draft202012Validator

from divatrading.replay import (
    DatasetQualityAuditError,
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayMetadataSnapshot,
    ReplayQualitySource,
    audit_replay_dataset_quality,
    audit_replay_manifest_quality,
    write_dataset_quality_report,
)
from divatrading.replay.manifest import canonical_json, sha256_text

ROOT = Path(__file__).parent
EXCHANGE_INFO = ROOT / "fixtures" / "exchange_info_valid.json"
SCHEMA = ROOT.parent / "docs" / "schemas" / "stage6b_dataset_quality_report.schema.json"
STEP = 60_000
START = 0
END = 5 * STEP


def metadata(quality="HISTORICAL_EFFECTIVE"):
    payload = json.loads(EXCHANGE_INFO.read_text(encoding="utf-8"))
    symbol = next(item for item in payload["symbols"] if item["symbol"] == "BTCUSDT")
    return ReplayMetadataSnapshot.from_symbol_payload(
        symbol,
        quality=quality,
        source_url="https://fapi.binance.com/fapi/v1/exchangeInfo",
        captured_at_ms=END,
        effective_from_ms=START if quality == "HISTORICAL_EFFECTIVE" else None,
        effective_to_ms=END if quality == "HISTORICAL_EFFECTIVE" else None,
    )


def row(open_ms: int, *, price="100.0", close_time=None, high=None, low=None, close=None, volume="10", step_ms=STEP):
    return [
        str(open_ms), price, high or "100.5", low or "99.5", close or "100.1",
        volume, str(open_ms + step_ms - 1 if close_time is None else close_time),
        "1000", "10", "5", "500", "0",
    ]


def write_rows(root: Path, name: str, rows: list[list[str]], *, zip_file=False) -> str:
    csv_path = root / (name + ".csv")
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerows(rows)
    if not zip_file:
        return csv_path.name
    zip_path = root / (name + ".zip")
    with ZipFile(zip_path, "w", compression=ZIP_DEFLATED) as archive:
        archive.write(csv_path, arcname=csv_path.name)
    csv_path.unlink()
    return zip_path.name


def audit(root: Path, paths: list[str], *, rows_by_path=None, sources=None, quality="HISTORICAL_EFFECTIVE"):
    descriptors = sources or [ReplayQualitySource("1m", path) for path in paths]
    return audit_replay_dataset_quality(
        dataset_root=root,
        symbol="BTCUSDT",
        start_open_time_ms=START,
        end_open_time_ms_exclusive=END,
        sources=descriptors,
        metadata=metadata(quality),
        independent_evidence_ref="archive:exchange-info-evidence-001",
    )


def test_clean_dataset_passes_exact_coverage_tick_grid_and_report_hash(tmp_path):
    path = write_rows(tmp_path, "clean", [row(i * STEP) for i in range(5)])
    before = hashlib.sha256((tmp_path / path).read_bytes()).hexdigest()
    report = audit(tmp_path, [path])
    timeframe = report["timeframes"][0]
    assert report["quality_summary"]["quality_status"] == "PASS"
    assert report["quality_summary"]["strict_replay_eligible"] is True
    assert timeframe["expected_bar_count"] == timeframe["observed_unique_bar_count"] == 5
    assert timeframe["missing_bar_count"] == 0
    assert timeframe["coverage_ratio_decimal"] == "1.000000"
    assert timeframe["tick_grid_violations"] == 0
    digest = report.pop("report_sha256")
    assert digest == sha256_text(canonical_json(report))
    report["report_sha256"] = digest
    Draft202012Validator(json.loads(SCHEMA.read_text())).validate(report)
    again = audit(tmp_path, [path])
    assert again == report
    write_dataset_quality_report(report, tmp_path / "reports" / "quality.json")
    assert before == hashlib.sha256((tmp_path / path).read_bytes()).hexdigest()


def test_internal_gap_is_warn_with_exact_gap_cluster_and_no_repair(tmp_path):
    path = write_rows(tmp_path, "gap", [row(i * STEP) for i in (0, 1, 3, 4)])
    report = audit(tmp_path, [path])
    tf = report["timeframes"][0]
    assert report["quality_summary"]["quality_status"] == "WARN"
    assert report["quality_summary"]["strict_replay_eligible"] is False
    assert tf["observed_unique_bar_count"] == 4
    assert tf["missing_bar_count"] == 1
    assert tf["leading_missing_bar_count"] == tf["trailing_missing_bar_count"] == 0
    assert tf["gap_cluster_count"] == 1
    assert tf["gap_clusters"] == [{
        "last_valid_open_time_ms": STEP,
        "first_missing_open_time_ms": 2 * STEP,
        "last_missing_open_time_ms": 2 * STEP,
        "first_resumed_open_time_ms": 3 * STEP,
        "missing_bar_count": 1,
    }]



def test_current_snapshot_blocks_execution_gate_but_not_clean_market_data_gate(tmp_path):
    path = write_rows(tmp_path, "current-metadata", [row(i * STEP) for i in range(5)])
    report = audit(tmp_path, [path], quality="CURRENT_SNAPSHOT_ONLY")
    gates = report["eligibility_gates"]
    assert report["quality_summary"]["quality_status"] == "WARN"
    assert report["quality_summary"]["strict_replay_eligible"] is False
    assert gates["market_data"]["status"] == "PASS"
    assert gates["market_data"]["eligible_for_strategy_replay"] is True
    assert gates["execution_metadata"]["status"] == "BLOCKED"
    assert gates["execution_metadata"]["strict_replay_eligible"] is False
    assert gates["execution_metadata"]["metadata_quality"] == "CURRENT_SNAPSHOT_ONLY"
    assert gates["execution_metadata"]["candidate_tick_size"] == "0.10"
    assert gates["provisional_strategy_replay_eligible"] is True
    Draft202012Validator(json.loads(SCHEMA.read_text())).validate(report)


def test_internal_gap_blocks_market_data_and_provisional_strategy_gate(tmp_path):
    path = write_rows(tmp_path, "gap-current-metadata", [row(i * STEP) for i in (0, 1, 3, 4)])
    report = audit(tmp_path, [path], quality="CURRENT_SNAPSHOT_ONLY")
    gates = report["eligibility_gates"]
    assert gates["market_data"]["status"] == "WARN"
    assert gates["market_data"]["eligible_for_strategy_replay"] is False
    assert gates["provisional_strategy_replay_eligible"] is False
    assert gates["execution_metadata"]["status"] == "BLOCKED"


def test_leading_and_trailing_coverage_gaps_fail_separately(tmp_path):
    path = write_rows(tmp_path, "edges", [row(i * STEP) for i in (1, 2, 3)])
    report = audit(tmp_path, [path])
    tf = report["timeframes"][0]
    assert report["quality_summary"]["quality_status"] == "FAIL"
    assert tf["leading_missing_bar_count"] == 1
    assert tf["trailing_missing_bar_count"] == 1
    assert tf["gap_cluster_count"] == 2
    assert tf["gap_clusters"][0]["last_valid_open_time_ms"] is None
    assert tf["gap_clusters"][1]["first_resumed_open_time_ms"] is None


def test_identical_duplicate_is_not_silently_deduplicated(tmp_path):
    duplicated = row(STEP)
    path = write_rows(tmp_path, "duplicate", [row(0), duplicated, duplicated, row(2 * STEP), row(3 * STEP), row(4 * STEP)])
    report = audit(tmp_path, [path])
    tf = report["timeframes"][0]
    assert report["quality_summary"]["quality_status"] == "FAIL"
    assert tf["integrity_counts"]["identical_duplicate_rows"] == 1
    assert tf["observed_unique_bar_count"] == 5
    assert tf["observed_row_count"] == 6


def test_conflicting_revision_is_classified_against_same_open_time(tmp_path):
    original = row(STEP)
    revised = row(STEP, close="100.2")
    path = write_rows(tmp_path, "revision", [row(0), original, revised, row(2 * STEP), row(3 * STEP), row(4 * STEP)])
    report = audit(tmp_path, [path])
    counts = report["timeframes"][0]["integrity_counts"]
    assert report["quality_summary"]["quality_status"] == "FAIL"
    assert counts["conflicting_revision_rows"] == 1
    assert counts["identical_duplicate_rows"] == 0


def test_non_monotonic_rows_are_flagged_without_sorting(tmp_path):
    path = write_rows(tmp_path, "order", [row(0), row(2 * STEP), row(STEP), row(3 * STEP), row(4 * STEP)])
    report = audit(tmp_path, [path])
    counts = report["timeframes"][0]["integrity_counts"]
    assert counts["non_monotonic_rows"] == 1
    assert report["quality_summary"]["quality_status"] == "FAIL"


def test_cross_file_overlap_is_separately_counted(tmp_path):
    a = write_rows(tmp_path, "a", [row(0), row(STEP), row(2 * STEP)])
    b = write_rows(tmp_path, "b", [row(2 * STEP), row(3 * STEP), row(4 * STEP)])
    report = audit(tmp_path, [a, b])
    counts = report["timeframes"][0]["integrity_counts"]
    assert counts["cross_file_overlap_rows"] == 1
    assert counts["identical_duplicate_rows"] == 1
    assert report["quality_summary"]["quality_status"] == "FAIL"


def test_decimal_tick_violation_is_exact_and_not_rounded(tmp_path):
    rows = [row(i * STEP) for i in range(5)]
    rows[2] = row(2 * STEP, price="100.05")
    path = write_rows(tmp_path, "offgrid", rows)
    report = audit(tmp_path, [path])
    tf = report["timeframes"][0]
    assert tf["tick_grid_violations"] == 1
    assert any(sample["field"] == "open" and sample["price"] == "100.05" for sample in tf["samples"])
    assert report["quality_summary"]["quality_status"] == "FAIL"


def test_bad_close_time_ohlc_and_numeric_values_are_reported(tmp_path):
    rows = [row(i * STEP) for i in range(5)]
    rows[1] = row(STEP, close_time=STEP, high="99.0")
    rows[2] = row(2 * STEP, volume="-1")
    path = write_rows(tmp_path, "badrows", rows)
    report = audit(tmp_path, [path])
    counts = report["timeframes"][0]["integrity_counts"]
    assert counts["close_time_mismatches"] == 1
    assert counts["ohlc_relationship_violations"] == 1
    assert counts["malformed_rows"] == 1
    assert report["quality_summary"]["quality_status"] == "FAIL"


def test_out_of_window_and_misaligned_times_fail(tmp_path):
    rows = [row(0), row(STEP + 1), row(2 * STEP), row(3 * STEP), row(END)]
    path = write_rows(tmp_path, "timestamp", rows)
    report = audit(tmp_path, [path])
    counts = report["timeframes"][0]["integrity_counts"]
    assert counts["misaligned_open_times"] == 1
    assert counts["out_of_window_rows"] == 1
    assert report["quality_summary"]["quality_status"] == "FAIL"


def test_declared_hash_mismatch_fails_and_is_reported(tmp_path):
    path = write_rows(tmp_path, "hash", [row(i * STEP) for i in range(5)])
    report = audit(tmp_path, [path], sources=[ReplayQualitySource("1m", path, expected_sha256="0" * 64)])
    assert "SOURCE_HASH_MISMATCH" in report["quality_summary"]["failure_codes"]


def test_current_metadata_is_diagnostic_only(tmp_path):
    path = write_rows(tmp_path, "current", [row(i * STEP) for i in range(5)])
    report = audit(tmp_path, [path], quality="CURRENT_SNAPSHOT_ONLY")
    assert report["quality_summary"]["quality_status"] == "WARN"
    assert report["quality_summary"]["strict_replay_eligible"] is False


def test_zip_source_supported_and_header_ignored(tmp_path):
    rows = [["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume", "count", "taker_base", "taker_quote", "ignore"]]
    rows += [row(i * STEP) for i in range(5)]
    path = write_rows(tmp_path, "native", rows, zip_file=True)
    report = audit(tmp_path, [path])
    assert report["quality_summary"]["quality_status"] == "PASS"
    assert report["source_files"][0]["row_count_observed"] == 5


def test_invalid_source_descriptor_and_unaligned_window_are_rejected(tmp_path):
    with pytest.raises(DatasetQualityAuditError):
        ReplayQualitySource("2m", "bad.csv")
    path = write_rows(tmp_path, "valid", [row(i * STEP) for i in range(5)])
    with pytest.raises(DatasetQualityAuditError, match="align"):
        audit_replay_dataset_quality(
            dataset_root=tmp_path, symbol="BTCUSDT", start_open_time_ms=1,
            end_open_time_ms_exclusive=END, sources=[ReplayQualitySource("1m", path)],
            metadata=metadata(),
        )


def test_missing_metadata_and_missing_evidence_reference_never_qualify_strictly(tmp_path):
    path = write_rows(tmp_path, "no_meta", [row(i * STEP) for i in range(5)])
    missing = audit_replay_dataset_quality(
        dataset_root=tmp_path, symbol="BTCUSDT", start_open_time_ms=START,
        end_open_time_ms_exclusive=END, sources=[ReplayQualitySource("1m", path)], metadata=None,
    )
    assert missing["quality_summary"]["quality_status"] == "FAIL"
    assert missing["metadata"]["tick_size"] is None

    no_ref = audit_replay_dataset_quality(
        dataset_root=tmp_path, symbol="BTCUSDT", start_open_time_ms=START,
        end_open_time_ms_exclusive=END, sources=[ReplayQualitySource("1m", path)],
        metadata=metadata(), independent_evidence_ref=None,
    )
    assert no_ref["quality_summary"]["quality_status"] == "WARN"
    assert no_ref["quality_summary"]["strict_replay_eligible"] is False
    assert "METADATA_EVIDENCE_REFERENCE_MISSING" in no_ref["quality_summary"]["warning_codes"]


def test_source_row_count_mismatch_and_sample_cap_are_explicit(tmp_path):
    rows = [row(i * STEP) for i in range(5)]
    rows[1] = row(STEP, price="100.05")
    rows[2] = row(2 * STEP, price="100.05")
    path = write_rows(tmp_path, "samplecap", rows)
    source = ReplayQualitySource("1m", path, row_count_declared=99)
    report = audit_replay_dataset_quality(
        dataset_root=tmp_path, symbol="BTCUSDT", start_open_time_ms=START,
        end_open_time_ms_exclusive=END, sources=[source], metadata=metadata(),
        independent_evidence_ref="archive:metadata", sample_cap=1,
    )
    assert report["quality_summary"]["sample_cap"] == 1
    assert sum(len(tf["samples"]) for tf in report["timeframes"]) <= 1
    assert "DECLARED_ROW_COUNT_MISMATCH" in report["quality_summary"]["failure_codes"]
    assert report["quality_summary"]["failure_count"] >= 3
    Draft202012Validator(json.loads(SCHEMA.read_text())).validate(report)


def test_off_grid_prices_still_count_when_an_unrelated_volume_field_is_invalid(tmp_path):
    rows = [row(i * STEP) for i in range(5)]
    rows[2] = row(2 * STEP, price="100.05", volume="-1")
    path = write_rows(tmp_path, "offgrid_badvolume", rows)
    report = audit(tmp_path, [path])
    tf = report["timeframes"][0]
    assert tf["tick_grid_violations"] == 1
    assert tf["integrity_counts"]["malformed_rows"] == 1
    assert tf["observed_unique_bar_count"] == 4


def test_cli_raw_source_mode_writes_schema_validated_report(tmp_path):
    from divatrading.cli import main

    path = write_rows(tmp_path, "cli", [row(i * STEP) for i in range(5)])
    meta_path = tmp_path / "metadata.json"
    meta_path.write_text(json.dumps(metadata().to_dict()), encoding="utf-8")
    digest = hashlib.sha256((tmp_path / path).read_bytes()).hexdigest()
    report_path = tmp_path / "reports" / "quality.json"
    exit_code = main([
        "replay-quality", "--root", str(tmp_path), "--symbol", "BTCUSDT",
        "--start-open-time-ms", str(START), "--end-open-time-ms", str(END),
        "--source", f"1m={path}", "--metadata", str(meta_path),
        "--metadata-evidence-ref", "archive:exchange-info-evidence",
        "--source-sha256", f"{path}={digest}", "--source-row-count", f"{path}=5",
        "--sample-cap", "25", "--report", str(report_path),
    ])
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert exit_code == 0
    assert report["quality_summary"]["quality_status"] == "PASS"
    assert report["quality_summary"]["strict_replay_eligible"] is True
    Draft202012Validator(json.loads(SCHEMA.read_text())).validate(report)



def test_manifest_mode_rechecks_source_hash_and_declared_row_count(tmp_path):
    path = write_rows(tmp_path, "manifest", [row(i * STEP) for i in range(5)])
    kline_file = ReplayKlineFile.inspect(tmp_path, path, "1m", symbol="BTCUSDT")
    path_5m = write_rows(tmp_path, "manifest-5m", [row(0, step_ms=5 * STEP)])
    kline_file_5m = ReplayKlineFile.inspect(tmp_path, path_5m, "5m", symbol="BTCUSDT")
    manifest = ReplayDatasetManifest(
        symbol="BTCUSDT", start_open_time_ms=START, end_open_time_ms=END,
        files=(kline_file, kline_file_5m), metadata=metadata(),
    )
    clean = audit_replay_manifest_quality(
        manifest, dataset_root=tmp_path, independent_evidence_ref="archive:metadata",
    )
    assert clean["quality_summary"]["quality_status"] == "PASS"
    assert clean["dataset_id"] == manifest.dataset_id
    with (tmp_path / path).open("a", encoding="utf-8") as handle:
        handle.write("\n")
    revised = audit_replay_manifest_quality(
        manifest, dataset_root=tmp_path, independent_evidence_ref="archive:metadata",
    )
    assert "SOURCE_HASH_MISMATCH" in revised["quality_summary"]["failure_codes"]
    assert revised["quality_summary"]["failure_count"] >= 1


def test_missing_source_is_reported_as_failed_report_not_unhandled_error(tmp_path):
    report = audit_replay_dataset_quality(
        dataset_root=tmp_path, symbol="BTCUSDT", start_open_time_ms=START,
        end_open_time_ms_exclusive=END,
        sources=[ReplayQualitySource("1m", "not-found.csv")], metadata=metadata(),
        independent_evidence_ref="archive:metadata",
    )
    assert report["quality_summary"]["quality_status"] == "FAIL"
    assert "SOURCE_MISSING" in report["quality_summary"]["failure_codes"]
    Draft202012Validator(json.loads(SCHEMA.read_text())).validate(report)
