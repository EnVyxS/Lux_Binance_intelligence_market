from __future__ import annotations

import pytest

from divatrading.execution.binance_private import LIVE_BASE_URL
from divatrading.execution.live_preflight import BinanceLiveReadOnlyPreflight

pytestmark = pytest.mark.usefixtures("isolated_cli_environment")

class FakeClient:
    environment = "LIVE"; base_url = LIVE_BASE_URL; last_time_sync_rtt_ms = 12
    def ping(self): return {}
    def sync_server_time(self): return 0
    def get_exchange_info(self):
        return {"symbols": [{"symbol":"BTCUSDT","status":"TRADING","contractType":"PERPETUAL","quoteAsset":"USDT"}]}
    def get_exchange_account(self): return {"totalWalletBalance":"25","availableBalance":"20"}
    def get_account_config(self): return {"canTrade":True,"multiAssetsMargin":False}
    def get_position_mode(self): return {"dualSidePosition":False}
    def get_position_risk(self): return [{"symbol":"BTCUSDT","positionAmt":"0"}]
    def get_open_orders(self): return []
    def get_open_algo_orders(self): return []
    def get_leverage_brackets(self, symbol): return [{"symbol":symbol,"brackets":[{"bracket":1,"initialLeverage":20,"notionalFloor":"0","notionalCap":"50000","maintMarginRatio":"0.004","cum":"0"}]}]
    def get_commission_rate(self, symbol): return {"makerCommissionRate":"0.0002","takerCommissionRate":"0.0005"}
    def get_symbol_config(self, symbol): return [{"symbol":symbol,"marginType":"isolated","leverage":20}]

def test_live_read_only_preflight_passes_only_clean_account_and_never_mutates():
    report = BinanceLiveReadOnlyPreflight(FakeClient(), symbols=("BTCUSDT",)).run()
    assert report.ready_for_next_stage
    assert report.environment == "LIVE"
    assert report.order_submission_performed is False
    assert report.account_mutation_performed is False
    assert any(x.code == "LEVERAGE_BRACKETS_BTCUSDT" and x.status == "PASS" for x in report.checks)

def test_live_read_only_preflight_blocks_external_position():
    class External(FakeClient):
        def get_position_risk(self): return [{"symbol":"BTCUSDT","positionAmt":"0.001"}]
    report = BinanceLiveReadOnlyPreflight(External()).run()
    assert not report.ready_for_next_stage
    assert any(x.code == "POSITIONS" and x.status == "FAIL" for x in report.checks)

def test_live_read_only_preflight_blocks_endpoint_mismatch_without_requests():
    class Wrong(FakeClient):
        base_url = "https://demo-fapi.binance.com"
        def ping(self): raise AssertionError("must not make a request")
    report = BinanceLiveReadOnlyPreflight(Wrong()).run()
    assert report.status == "BLOCKED_LIVE_PREFLIGHT"
    assert report.checks[0].code == "ENDPOINT_PINNING"

def test_live_preflight_cli_requires_explicit_read_only_opt_in(tmp_path, monkeypatch, capsys):
    from divatrading import cli
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=LIVE\nDIVA_LIVE_TRADING_ENABLED=false\n"
        "BINANCE_API_KEY=local-key\nBINANCE_API_SECRET=local-secret\n",
        encoding="utf-8",
    )
    rc = cli.main(["live-read-only-preflight"])
    out = capsys.readouterr().out
    assert rc == 2 and "BLOCKED_OPT_IN" in out
    assert "local-secret" not in out

def test_live_preflight_cli_invokes_only_read_only_report(tmp_path, monkeypatch, capsys):
    from divatrading import cli
    class Report:
        ready_for_next_stage = True
        def to_dict(self): return {"status":"READ_ONLY_PREFLIGHT_PASSED","order_submission_performed":False,"account_mutation_performed":False}
    class Client:
        def __init__(self, key, secret, *, environment):
            assert (key, secret, environment) == ("k", "s", "LIVE")
        def close(self): pass
    class Preflight:
        def __init__(self, client, *, symbols): assert symbols == ("BTCUSDT",)
        def run(self): return Report()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=LIVE\nDIVA_LIVE_TRADING_ENABLED=false\nDIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true\nBINANCE_API_KEY=k\nBINANCE_API_SECRET=s\n", encoding="utf-8")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", Client)
    monkeypatch.setattr(cli, "BinanceLiveReadOnlyPreflight", Preflight)
    rc = cli.main(["live-read-only-preflight"])
    out = capsys.readouterr().out
    assert rc == 0 and "READ_ONLY_PREFLIGHT_PASSED" in out
    assert "\"order_submission_performed\": false" in out
