import asyncio
from decimal import Decimal as D
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.position_lifecycle import LifecycleAction, ManagedPositionState, PositionLifecycleEngine
from divatrading.execution.position_lifecycle_execution import PositionLifecycleExecutionAdapter
from divatrading.execution.position_supervisor import ManagedPositionSupervisor, PositionSupervisorConfig

NOW = 1_800_000_000_000


def ready_ledger(path: Path) -> ExecutionLedger:
    ledger = ExecutionLedger(path)
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=NOW, updated_at_ms=NOW)
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=NOW,
                                    detail={"test": True}, stream_event_watermark_ms=0)
    return ledger


def managed(ledger: ExecutionLedger, *, signal_id="sig-supervisor", symbol="BTCUSDT", side="LONG",
            position_side="BOTH", quantity="1", invalidation="90"):
    ledger.claim_intent(signal_id=signal_id, symbol=symbol, side=side,
                        client_order_id=ledger.deterministic_client_id(signal_id, "ENTRY"), payload={})
    stop = D("90") if side == "LONG" else D("110")
    take = D("120") if side == "LONG" else D("80")
    ledger.record_position(symbol=symbol, position_side=position_side, signal_id=signal_id,
                           quantity=quantity, entry_price="100", stop_loss=str(stop), take_profit=str(take))
    state = {
        "signal_id": signal_id, "symbol": symbol, "side": side,
        "quantity": quantity, "entry_price": "100", "initial_stop": str(stop),
        "current_stop": str(stop), "initial_risk_per_unit": "10",
        "partial_tp_fraction": "0.5", "partial_tp_done": False,
        "breakeven_done": False, "trailing_active": False,
        "favorable_extreme": None, "last_mark_price": None,
        "structural_invalidation_price": invalidation,
        "structural_invalidation_reason": "SMC OB invalidation boundary",
        "closed": False,
        "stop_algo_client_id": ledger.deterministic_client_id(signal_id, "STOP_LOSS"),
        "take_profit_algo_client_id": ledger.deterministic_client_id(signal_id, "TAKE_PROFIT"),
    }
    ledger.save_position_management_state(signal_id=signal_id, symbol=symbol, state=state)
    reserved = ledger.reserve_portfolio_risk(
        signal_id=signal_id, symbol=symbol, risk_usdt=D("10"), notional_usdt=D("100"),
        equity_usdt=D("1000"), exchange_open_risk_usdt=D("0"), exchange_active_position_count=0,
        max_positions=5, max_portfolio_open_risk_pct=D("5"),
        exchange_symbol_notional_usdt=D("0"), max_symbol_notional_usdt=D("10000"),
    )
    assert reserved.accepted
    return state


class FakeExecutionClient:
    environment = "TESTNET"

    def __init__(self, *, dual=False, quantity="1", fill_exit=False, partial_fill_qty=None,
                 positions=None):
        self.dual = dual
        self.positions = list(positions) if positions is not None else [
            {"symbol": "BTCUSDT", "positionSide": "LONG" if dual else "BOTH",
             "positionAmt": quantity if quantity else "0"}
        ]
        self.orders = {}
        self.algos = {}
        self.new_order_calls = []
        self.cancel_order_calls = []
        self.cancel_algo_calls = []
        self.fill_exit = fill_exit
        self.partial_fill_qty = partial_fill_qty

    def sync_server_time(self):
        return 0

    def get_position_mode(self):
        return {"dualSidePosition": self.dual}

    def get_position_risk(self, symbol=None):
        return [row for row in self.positions if symbol is None or row["symbol"] == symbol]

    def new_order(self, **params):
        self.new_order_calls.append(params)
        client_id = params["newClientOrderId"]
        qty = str(params["quantity"])
        partial = self.partial_fill_qty is not None
        filled = self.fill_exit or partial
        status = "PARTIALLY_FILLED" if partial else ("FILLED" if self.fill_exit else "NEW")
        executed = str(self.partial_fill_qty) if partial else (qty if self.fill_exit else "0")
        order = {"orderId": len(self.orders) + 10, "clientOrderId": client_id,
                 "symbol": params["symbol"], "status": status,
                 "executedQty": executed, "origQty": qty}
        self.orders[client_id] = order
        if filled:
            position = next(row for row in self.positions
                            if row["symbol"] == params["symbol"]
                            and row["positionSide"] == params["positionSide"])
            current = D(position["positionAmt"])
            position["positionAmt"] = str(max(D("0"), current - D(executed)))
        return dict(order)

    def get_order(self, symbol, *, order_id=None, client_order_id=None):
        return dict(self.orders[client_order_id])

    def cancel_order(self, symbol, *, order_id=None, client_order_id=None):
        self.cancel_order_calls.append(client_order_id)
        self.orders[client_order_id]["status"] = "CANCELED"
        return dict(self.orders[client_order_id])

    def get_open_orders(self, symbol=None):
        return [dict(row) for row in self.orders.values()
                if row["status"] in {"NEW", "PARTIALLY_FILLED"}
                and (symbol is None or row["symbol"] == symbol)]

    def new_algo_order(self, **params):
        client_id = params["clientAlgoId"]
        order = {"algoId": len(self.algos) + 100, "clientAlgoId": client_id,
                 "symbol": params["symbol"], "orderType": params["type"],
                 "algoStatus": "NEW", "triggerPrice": str(params["triggerPrice"]), **params}
        self.algos[client_id] = order
        return dict(order)

    def get_algo_order(self, *, algo_id=None, client_algo_id=None):
        if client_algo_id not in self.algos:
            from divatrading.execution.binance_private import BinancePrivateApiError
            raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
        return dict(self.algos[client_algo_id])

    def cancel_algo_order(self, *, algo_id=None, client_algo_id=None):
        self.cancel_algo_calls.append(client_algo_id)
        self.algos[client_algo_id]["algoStatus"] = "CANCELED"
        return {"clientAlgoId": client_algo_id, "code": "200"}

    def get_open_algo_orders(self, symbol=None):
        return [dict(row) for row in self.algos.values()
                if row["algoStatus"] in {"NEW", "PENDING_NEW"}
                and (symbol is None or row["symbol"] == symbol)]


class FakeMarkFeed:
    def __init__(self, event):
        self.queue = asyncio.Queue()
        self.event = event
        self.is_connected = False

    async def run(self, stop_event):
        self.is_connected = True
        await self.queue.put(self.event)
        try:
            await stop_event.wait()
        finally:
            self.is_connected = False

    async def get_event(self):
        return await self.queue.get()


def adapter(ledger, client):
    return PositionLifecycleExecutionAdapter(client=client, ledger=ledger, clock_ms=lambda: NOW)


def rules(_symbol):
    return {"market_step_size": D("0.1"), "market_min_qty": D("0.1"), "tick_size": D("0.1")}


def test_engine_emits_structural_exit_before_any_profit_management():
    state = ManagedPositionState(
        signal_id="s", symbol="BTCUSDT", side="LONG", quantity=D("1"),
        entry_price=D("100"), initial_stop=D("90"), current_stop=D("90"),
        initial_risk_per_unit=D("10"), structural_invalidation_price=D("91"),
        structural_invalidation_reason="OB invalidated",
    )
    decision = PositionLifecycleEngine().evaluate(state, D("90.5"))
    assert [item.kind for item in decision.actions] == ["STRUCTURAL_EXIT"]
    assert decision.actions[0].reason == "OB invalidated"


def test_supervisor_dispatches_structural_exit_and_releases_only_after_verified_flat(tmp_path):
    ledger = ready_ledger(tmp_path / "structural.sqlite")
    managed(ledger)
    client = FakeExecutionClient(fill_exit=True)
    lifecycle_adapter = adapter(ledger, client)
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=lifecycle_adapter, filter_provider=rules,
        feed_factory=lambda _symbol: None, clock_ms=lambda: NOW,
    )
    outcome = supervisor._process_mark_event(SimpleNamespace(
        symbol="BTCUSDT", mark_price=D("89"), event_time_ms=NOW,
    ))
    assert outcome[0]["status"] == "CLOSED_CONFIRMED"
    assert client.new_order_calls[0]["reduceOnly"] is True
    assert client.new_order_calls[0]["type"] == "MARKET"
    assert ledger.get_risk_reservation("sig-supervisor")["status"] == "RELEASED"
    assert ledger.get_position_management_state("sig-supervisor")["state"]["closed"] is True


def test_emergency_close_requires_explicit_reason_and_respects_hedge_mode(tmp_path):
    ledger = ready_ledger(tmp_path / "hedge-emergency.sqlite")
    managed(ledger, position_side="LONG")
    client = FakeExecutionClient(dual=True, fill_exit=True)
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=lambda _symbol: None,
    )
    outcome = supervisor.emergency_close("sig-supervisor", reason="Operator emergency flatten")
    params = client.new_order_calls[0]
    assert outcome["status"] == "CLOSED_CONFIRMED"
    assert params["side"] == "SELL" and params["positionSide"] == "LONG"
    assert "reduceOnly" not in params
    assert ledger.get_risk_reservation("sig-supervisor")["status"] == "RELEASED"


def test_partial_emergency_exit_keeps_reservation_and_halts_entries(tmp_path):
    ledger = ready_ledger(tmp_path / "partial-exit.sqlite")
    managed(ledger)
    client = FakeExecutionClient(partial_fill_qty="0.4")
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=lambda _symbol: None,
    )
    result = supervisor.emergency_close("sig-supervisor", reason="Manual emergency test")
    assert result["status"] == "PARTIAL_EXIT_REMAINS"
    assert result["remaining_quantity"] == "0.6"
    assert ledger.get_risk_reservation("sig-supervisor")["status"] == "ACTIVE"
    assert ledger.get_position_management_state("sig-supervisor")["state"]["quantity"] == "0.6"
    assert ledger.entries_halted()[0] is True


def test_supervisor_accepts_multiple_signal_lots_for_one_position_side(tmp_path):
    ledger = ready_ledger(tmp_path / "multi-lot-position.sqlite")
    managed(ledger, signal_id="sig-one")
    managed(ledger, signal_id="sig-two")
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, FakeExecutionClient(quantity="2")),
        filter_provider=rules, feed_factory=lambda _symbol: None,
        clock_ms=lambda: NOW,
    )
    assert supervisor._active_symbols() == ("BTCUSDT",)
    assert ledger.entries_halted()[0] is False


@pytest.mark.parametrize(("dual", "position_side"), [(False, "BOTH"), (True, "LONG")])
def test_supervisor_manages_and_closes_two_signal_lots_independently(tmp_path, dual, position_side):
    ledger = ready_ledger(tmp_path / f"multi-lot-supervision-{position_side}.sqlite")
    managed(ledger, signal_id="sig-one", position_side=position_side)
    managed(ledger, signal_id="sig-two", position_side=position_side)
    client = FakeExecutionClient(dual=dual, quantity="2", fill_exit=True)
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=lambda _symbol: None, clock_ms=lambda: NOW,
    )

    results = supervisor._process_mark_event(
        SimpleNamespace(symbol="BTCUSDT", mark_price=D("89"), event_time_ms=NOW)
    )

    assert [result["status"] for result in results] == ["CLOSED_CONFIRMED", "CLOSED_CONFIRMED"]
    assert [call["quantity"] for call in client.new_order_calls] == [D("1"), D("1")]
    assert D(client.positions[0]["positionAmt"]) == D("0")
    for signal_id in ("sig-one", "sig-two"):
        assert ledger.get_position_management_state(signal_id)["state"]["closed"] is True
        assert ledger.get_risk_reservation(signal_id)["status"] == "RELEASED"


def test_async_supervisor_starts_per_symbol_feed_and_dispatches_actions(tmp_path):
    async def run_case():
        ledger = ready_ledger(tmp_path / "async-supervisor.sqlite")
        managed(ledger)
        client = FakeExecutionClient(fill_exit=True)
        event = SimpleNamespace(symbol="BTCUSDT", mark_price=D("89"), event_time_ms=NOW)
        supervisor = ManagedPositionSupervisor(
            ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
            feed_factory=lambda _symbol: FakeMarkFeed(event),
            config=PositionSupervisorConfig(refresh_interval_seconds=0.02,
                worker_restart_seconds=0.02, event_poll_seconds=0.01, max_mark_age_ms=5_000),
            clock_ms=lambda: NOW,
        )
        stop = asyncio.Event()
        task = asyncio.create_task(supervisor.run(stop))
        for _ in range(100):
            if supervisor.snapshot and supervisor.snapshot[0].event_count >= 1:
                break
            await asyncio.sleep(0.01)
        stop.set()
        await task
        assert ledger.get_position_management_state("sig-supervisor")["state"]["closed"] is True
        assert supervisor.snapshot[0].event_count >= 1
    asyncio.run(run_case())



def test_supervisor_runs_isolated_workers_for_multiple_symbols(tmp_path):
    ledger = ready_ledger(tmp_path / "multi-symbol.sqlite")
    managed(ledger, signal_id="sig-btc", symbol="BTCUSDT")
    managed(ledger, signal_id="sig-eth", symbol="ETHUSDT")
    client = FakeExecutionClient(fill_exit=True, positions=[
        {"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "1"},
        {"symbol": "ETHUSDT", "positionSide": "BOTH", "positionAmt": "1"},
    ])
    feeds = {}

    def feed_factory(symbol):
        event = SimpleNamespace(symbol=symbol, mark_price=D("110"), event_time_ms=NOW)
        feed = FakeMarkFeed(event)
        feeds[symbol] = feed
        return feed

    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=feed_factory,
        config=PositionSupervisorConfig(refresh_interval_seconds=0.01, max_active_symbols=2),
        clock_ms=lambda: NOW,
    )

    async def run_case():
        stop = asyncio.Event()
        task = asyncio.create_task(supervisor.run(stop))
        for _ in range(200):
            statuses = {item.symbol: item for item in supervisor.snapshot}
            if (len(statuses) == 2 and all(item.event_count >= 1 for item in statuses.values())):
                break
            await asyncio.sleep(0.01)
        stop.set()
        await task
        statuses = {item.symbol: item for item in supervisor.snapshot}
        assert set(statuses) == {"BTCUSDT", "ETHUSDT"}
        assert all(item.event_count >= 1 for item in statuses.values())

    asyncio.run(run_case())
    for signal_id in ("sig-btc", "sig-eth"):
        state = ledger.get_position_management_state(signal_id)["state"]
        assert state["partial_tp_done"] is True
        assert D(state["quantity"]) == D("0.5")
    assert {"BTCUSDT", "ETHUSDT"} == set(feeds)

def test_supervisor_dispatches_partial_tp_then_trailing_stop_from_mark_price(tmp_path):
    ledger = ready_ledger(tmp_path / "tp-trailing.sqlite")
    managed(ledger)
    client = FakeExecutionClient(fill_exit=True)
    old_stop = ledger.deterministic_client_id("sig-supervisor", "STOP_LOSS")
    client.algos[old_stop] = {"algoId": 99, "clientAlgoId": old_stop, "symbol": "BTCUSDT",
                              "side": "SELL", "positionSide": "BOTH",
                              "orderType": "STOP_MARKET", "algoStatus": "NEW",
                              "triggerPrice": "90"}
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=lambda _symbol: None, clock_ms=lambda: NOW,
    )
    first = supervisor._process_mark_event(SimpleNamespace(
        symbol="BTCUSDT", mark_price=D("110"), event_time_ms=NOW,
    ))
    assert first[0]["status"] == "CONFIRMED", first
    current = ledger.get_position_management_state("sig-supervisor")["state"]
    assert current["quantity"] == "0.5" and current["partial_tp_done"] is True

    second = supervisor._process_mark_event(SimpleNamespace(
        symbol="BTCUSDT", mark_price=D("115"), event_time_ms=NOW + 1000,
    ))
    assert second[0]["status"] == "CONFIRMED"
    current = ledger.get_position_management_state("sig-supervisor")["state"]
    assert D(current["current_stop"]) == D("105")
    assert current["trailing_active"] is True
    assert old_stop in client.cancel_algo_calls
    assert ledger.get_risk_reservation("sig-supervisor")["status"] == "ACTIVE"
