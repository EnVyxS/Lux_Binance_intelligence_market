from decimal import Decimal as D
import pytest
from divatrading.trading.exchange_feasibility import (
    SymbolCommission, parse_leverage_brackets, assess_margin_feasibility,
)


def payload():
    return [{"symbol":"BTCUSDT","brackets":[
        {"bracket":1,"initialLeverage":50,"notionalFloor":"0","notionalCap":"50000","maintMarginRatio":"0.004","cum":"0"},
        {"bracket":2,"initialLeverage":25,"notionalFloor":"50000","notionalCap":"250000","maintMarginRatio":"0.005","cum":"50"},
    ]}]


def test_bracket_parse_and_maintenance_margin():
    tiers = parse_leverage_brackets(payload(), "BTCUSDT")
    assert tiers[0].initial_leverage == 50
    assert tiers[0].maintenance_margin(D("10000")) == D("40")
    assert tiers[1].maintenance_margin(D("60000")) == D("250")


def test_fee_reserve_and_margin_feasibility():
    fees = SymbolCommission.from_binance({"makerCommissionRate":"0.0002","takerCommissionRate":"0.0005"})
    assert fees.round_trip_reserve(D("1000")) == D("1.0000")
    result = assess_margin_feasibility(notional=D("1000"), available_margin=D("60"),
        brackets=parse_leverage_brackets(payload(), "BTCUSDT"), commission=fees,
        max_leverage=20, slippage_reserve=D("1"), funding_reserve=D("0.2"))
    assert result.accepted and result.leverage == 18  # lowest feasible leverage
    assert result.total_required_margin == D("1000") / D("18") + D("1.2") + D("1.2")
    assert result.liquidation_price_estimated is False


def test_reject_notional_outside_account_tiers():
    fees = SymbolCommission(D("0.0002"), D("0.0005"))
    result = assess_margin_feasibility(notional=D("300000"), available_margin=D("10000"),
        brackets=parse_leverage_brackets(payload(), "BTCUSDT"), commission=fees, max_leverage=20)
    assert not result.accepted and result.reason == "NOTIONAL_OUTSIDE_ACCOUNT_BRACKETS"


def test_higher_exchange_tier_does_not_raise_the_bot_leverage_cap():
    response = payload()
    response[0]["brackets"][0]["initialLeverage"] = 200
    inputs = dict(notional=D("125"), available_margin=D("1"),
                  brackets=parse_leverage_brackets(response, "BTCUSDT"),
                  commission=SymbolCommission(D("0"), D("0")))

    result = assess_margin_feasibility(**inputs, max_leverage=125)
    assert result.accepted and result.leverage == 125
    assert assess_margin_feasibility(**inputs, max_leverage=125, fixed_leverage=126).reason == (
        "FIXED_LEVERAGE_EXCEEDS_BRACKET"
    )
    assert not assess_margin_feasibility(**inputs, max_leverage=200).accepted


def test_invalid_bracket_rejected():
    bad = [{"symbol":"BTCUSDT","brackets":[{"bracket":1,"initialLeverage":50,
        "notionalFloor":"10","notionalCap":"5","maintMarginRatio":".01","cum":"0"}]}]
    with pytest.raises(ValueError): parse_leverage_brackets(bad, "BTCUSDT")
