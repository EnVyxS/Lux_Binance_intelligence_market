"""Entry cancellation must reconcile fills that race the cancel request."""
from decimal import Decimal as D
import time

import pytest
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.trading.models import QualifiedSignal, TradePlan


class RacingClient:
    environment = 'TESTNET'

    def __init__(self, final_status='CANCELED', final_qty='0.08'):
        self.canceled = False
        self.posts = 0
        self.final_status = final_status
        self.final_qty = final_qty

    def sync_server_time(self): pass
    def get_position_mode(self): return {'dualSidePosition': False}
    def new_order(self, **params):
        self.posts += 1
        return self.get_order('BTCUSDT')
    def get_order(self, symbol, **kwargs):
        return {'symbol': symbol, 'orderId': 123, 'clientOrderId': 'DIVA-RACE',
                'status': self.final_status if self.canceled else 'PARTIALLY_FILLED',
                'executedQty': self.final_qty if self.canceled else '0.04',
                'origQty': '0.1', 'avgPrice': '50010' if self.canceled else '50000'}
    def cancel_order(self, symbol, **kwargs):
        self.canceled = True
        return self.get_order(symbol)


def setup_service(tmp_path, monkeypatch, client):
    ledger = ExecutionLedger(tmp_path / 'race.sqlite')
    now = time.time_ns() // 1_000_000
    ledger.set_user_stream_state('CONNECTED', connected_at_ms=now, updated_at_ms=now)
    ledger.set_reconciliation_state(True, status='READY', captured_at_ms=now, stream_event_watermark_ms=0)
    signal = QualifiedSignal('race', 'BTCUSDT', 'LONG', 'LIMIT', D('50000'), D('49900'), D('50300'), '5m', 'SMC_V2', now)
    plan = TradePlan(signal, D('0.1'), D('5000'), D('10'), D('1666.67'), 3, 'DIVA-RACE')
    ledger.reserve_portfolio_risk(signal_id='race', symbol='BTCUSDT', risk_usdt=plan.risk_usdt,
        notional_usdt=plan.notional_usdt, equity_usdt=D('10000'), exchange_open_risk_usdt=D('0'),
        exchange_active_position_count=0, max_positions=1, max_portfolio_open_risk_pct=D('1'),
        exchange_symbol_notional_usdt=D('0'), max_symbol_notional_usdt=D('60000'))
    service = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET,
        enable_testnet_orders=True, enable_testnet_stage_c=True), client=client)
    monkeypatch.setattr(service, '_prepare_symbol_settings', lambda **kwargs: None)
    quantities = []
    def protect(plan, side, *, quantity):
        quantities.append(quantity)
        return {}, {}
    monkeypatch.setattr(service, '_ensure_protection', protect)
    return service, ledger, plan, quantities


@pytest.mark.parametrize('recovery', [False, True])
@pytest.mark.parametrize('terminal,qty', [('CANCELED','0.08'), ('FILLED','0.1')])
def test_cancel_race_protects_final_fill_and_records_final_average(tmp_path, monkeypatch, recovery, terminal, qty):
    client = RacingClient(terminal, qty)
    service, ledger, plan, quantities = setup_service(tmp_path, monkeypatch, client)
    if recovery:
        ledger.claim_intent(signal_id='race', symbol='BTCUSDT', side='LONG', client_order_id='DIVA-RACE', payload=service._payload(plan))
        ledger.update_intent('race', 'ENTRY_PENDING')
        service.reconcile_pending_entries()
    else:
        service.submit(plan)
    assert quantities == [D(qty)]
    position = ledger.list_managed_positions(status='OPEN')[0]
    assert D(position['quantity']) == D(qty)
    assert D(position['entry_price']) == D('50010')
    assert client.posts == (0 if recovery else 1)


@pytest.mark.parametrize('status,quantity', [('PARTIALLY_FILLED','0.08'), ('CANCELED','0.02'), ('CANCELED','NaN'), ('CANCELED','0.2')])
def test_ambiguous_or_regressing_cancel_does_not_claim_protected(tmp_path, monkeypatch, status, quantity):
    service, ledger, plan, quantities = setup_service(tmp_path, monkeypatch, RacingClient(status, quantity))
    with pytest.raises((RuntimeError, ValueError)):
        service.submit(plan)
    assert quantities == []
    assert ledger.entries_halted()[0]
    assert ledger.get_intent('race')['status'] != 'PROTECTED'


def test_account_supervisor_halt_during_pre_post_preflight_prevents_new_entry(tmp_path, monkeypatch):
    """A delayed synchronous REST phase must not outrun the durable emergency latch."""
    client = RacingClient()
    service, ledger, plan, protected = setup_service(tmp_path, monkeypatch, client)
    monkeypatch.setattr(service, '_prepare_symbol_settings',
                        lambda **kwargs: ledger.set_entries_halted(True, 'ACCOUNT_RUNTIME_FAILED'))
    # Simulate a stale/erroneously still-ready reconciliation view. The durable
    # halt latch remains an independent final protection before order submission.
    monkeypatch.setattr(ledger, 'execution_readiness', lambda **kwargs: (True, ()))
    result = service.submit(plan)
    assert result.status == 'ENTRY_BLOCKED_HALTED_BEFORE_POST'
    assert client.posts == 0
    assert protected == []
    assert ledger.get_risk_reservation('race')['status'] == 'RELEASED'
    assert ledger.get_intent('race')['status'] == 'ENTRY_BLOCKED_HALTED_BEFORE_POST'
