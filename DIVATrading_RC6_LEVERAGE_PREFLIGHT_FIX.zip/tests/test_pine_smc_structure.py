from __future__ import annotations

from dataclasses import replace
from decimal import Decimal

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcReplayError,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
    parse_candle_extremes,
)


BASE_TIME_MS = 1_700_000_000_000


def _kline(
    index: int,
    *,
    interval: str = "1m",
    open_price: str = "100",
    high: str = "101",
    low: str = "99",
    close: str = "100",
    symbol: str = "BTCUSDT",
    exchange: str = "BINANCE_UM",
) -> Kline:
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    candle = Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            "10",
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol=symbol,
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )
    if exchange == "BINANCE_UM":
        return candle
    return Kline(
        exchange=exchange,
        symbol=candle.symbol,
        interval=candle.interval,
        open_time_ms=candle.open_time_ms,
        open=candle.open,
        high=candle.high,
        low=candle.low,
        close=candle.close,
        volume=candle.volume,
        close_time_ms=candle.close_time_ms,
        quote_asset_volume=candle.quote_asset_volume,
        trade_count=candle.trade_count,
        taker_buy_base_volume=candle.taker_buy_base_volume,
        taker_buy_quote_volume=candle.taker_buy_quote_volume,
        ignore_value=candle.ignore_value,
        source_endpoint=candle.source_endpoint,
    )


def _range_candles(ranges: list[str], *, interval: str = "1m") -> list[Kline]:
    result: list[Kline] = []
    for index, range_text in enumerate(ranges):
        half = Decimal(range_text) / Decimal("2")
        center = Decimal("100")
        result.append(
            _kline(
                index,
                interval=interval,
                open_price=str(center),
                high=str(center + half),
                low=str(center - half),
                close=str(center),
            )
        )
    return result


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 2,
        "internal_len": 1,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def test_config_enforces_pine_input_ranges_and_supported_timeframes() -> None:
    assert _config(symbol="btcusdt").symbol == "BTCUSDT"
    with pytest.raises(PineSmcReplayError, match="timeframe"):
        _config(timeframe="3m")
    with pytest.raises(PineSmcReplayError, match="warmup_bars"):
        _config(warmup_bars=299)
    with pytest.raises(PineSmcReplayError, match="swing_len"):
        _config(swing_len=1)
    with pytest.raises(PineSmcReplayError, match="internal_len"):
        _config(internal_len=26)
    with pytest.raises(PineSmcReplayError, match="confluence_filter"):
        _config(confluence_filter=1)


def test_reset_boundary_uses_last_bar_index_minus_warmup_plus_one() -> None:
    candles = _range_candles(["2"] * 305)
    result = PineSmcStructureEngine(_config()).replay(candles)

    assert result.last_bar_index == 304
    assert result.reset_start_index == 5
    assert result.processed_bar_count == 300
    assert result.trace[0].source_bar_index == 5
    assert result.trace[0].local_index == 0
    assert result.trace[-1].source_bar_index == 304
    assert result.trace[-1].local_index == 299


def test_reset_start_index_is_clamped_to_zero_when_history_is_shorter_than_warmup() -> None:
    result = PineSmcStructureEngine(_config()).replay(_range_candles(["1"] * 20))

    assert result.reset_start_index == 0
    assert result.processed_bar_count == 20
    assert result.trace[0].local_index == 0


def test_pre_reset_history_does_not_leak_into_local_state_or_first_true_range() -> None:
    baseline = _range_candles(["2"] * 305)
    changed_prefix = list(baseline)
    for index in range(5):
        changed_prefix[index] = _kline(
            index,
            open_price="900",
            high="1000",
            low="800",
            close="950",
        )

    first = PineSmcStructureEngine(_config()).replay(baseline)
    second = PineSmcStructureEngine(_config()).replay(changed_prefix)

    # SMC state is reset at source index 5 and must ignore the altered prefix.
    # Built-in TA traces are intentionally different because Pine evaluates
    # ATR/RSI/SMA/DMI on the complete loaded history before that reset boundary.
    for first_bar, second_bar in zip(first.trace, second.trace, strict=True):
        # Stage-7 prior-sweep series use the full loaded prefix (`low[1]` and
        # `high[1]`), just like Pine's ta.lowest/ta.highest calls. The SMC
        # structure and active OB state remain reset-local; indicator and score
        # pre-roll traces are allowed to differ when that prefix changes.
        assert replace(
            first_bar,
            indicators=second_bar.indicators,
            ob_scoring=second_bar.ob_scoring,
        ) == second_bar
    assert first.trace[0].ob_scoring.prior_lowest_sweep != second.trace[0].ob_scoring.prior_lowest_sweep
    assert first.trace[8].indicators.atr_fast_now != second.trace[8].indicators.atr_fast_now
    assert first.trace[0].true_range == 2.0
    assert first.trace[0].atr200 == 2.0
    assert first.trace[0].swing_leg == 0
    assert not first.trace[0].swing_high.valid
    assert not first.trace[0].swing_low.valid


def test_true_range_uses_previous_close_only_after_first_local_bar() -> None:
    candles = [
        _kline(0, open_price="100", high="102", low="98", close="100"),
        _kline(1, open_price="110", high="112", low="109", close="111"),
    ]
    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    assert trace[0].true_range == 4.0
    assert trace[1].true_range == 12.0  # max(3, |112-100|, |109-100|)
    assert trace[1].atr200 == 8.0


def test_custom_atr200_initialization_and_wilder_recurrence_at_boundary_indices() -> None:
    ranges = [str(1 + (index % 7) / 10) for index in range(202)]
    candles = _range_candles(ranges)
    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    expected_sum = 0.0
    expected_atr: dict[int, float] = {}
    pine_float_ranges = [float(candle.high) - float(candle.low) for candle in candles]
    for index, candle_range in enumerate(pine_float_ranges):
        if index < 200:
            expected_sum += candle_range
            atr = expected_sum / (index + 1)
        else:
            atr = (expected_atr[index - 1] * 199.0 + candle_range) / 200.0
        expected_atr[index] = atr

    for index in (0, 1, 199, 200, 201):
        assert trace[index].atr200 == expected_atr[index]
    assert trace[199].tr_sum == sum(pine_float_ranges[:200])
    assert trace[200].tr_sum == trace[199].tr_sum


def test_parsed_candle_threshold_is_inclusive_and_high_volatility_swaps_extremes() -> None:
    below = parse_candle_extremes(high=101.999, low=100.0, atr200=1.0)
    equal = parse_candle_extremes(high=102.0, low=100.0, atr200=1.0)
    above = parse_candle_extremes(high=102.001, low=100.0, atr200=1.0)

    assert below.high_volatility is False
    assert (below.parsed_high, below.parsed_low) == (101.999, 100.0)
    assert equal.high_volatility is True
    assert (equal.parsed_high, equal.parsed_low) == (100.0, 102.0)
    assert above.high_volatility is True
    assert (above.parsed_high, above.parsed_low) == (100.0, 102.001)


def test_swing_and_internal_pivots_use_delayed_candidate_offsets_and_independent_states() -> None:
    candles = [
        _kline(0, open_price="95", high="101", low="90", close="96"),
        _kline(1, open_price="97", high="102", low="92", close="98"),
        _kline(2, open_price="98", high="103", low="93", close="99"),
        _kline(3, open_price="100", high="111", low="96", close="101"),
        _kline(4, open_price="102", high="110", low="97", close="103"),
        _kline(5, open_price="103", high="109", low="98", close="104"),
    ]
    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    # Swing low candidate is candle 0 and becomes observable on source bar 2.
    assert trace[2].swing_leg == 1
    assert trace[2].swing_low.valid
    assert trace[2].swing_low.current == 90.0
    assert trace[2].swing_low.local_index == 0
    assert trace[2].swing_low.source_time_ms == candles[0].open_time_ms

    # Internal structure uses len=1 and therefore transitions before swing len=2.
    assert trace[1].internal_leg == 1
    assert trace[1].internal_low.valid
    assert trace[1].internal_low.local_index == 0
    assert trace[4].internal_leg == 0
    assert trace[4].internal_high.valid
    assert trace[4].internal_high.current == 111.0
    assert trace[4].internal_high.local_index == 3

    # Swing high candidate is candle 3 and becomes observable on source bar 5.
    assert trace[5].swing_leg == 0
    assert trace[5].swing_high.valid
    assert trace[5].swing_high.current == 111.0
    assert trace[5].swing_high.local_index == 3
    assert trace[5].swing_high.source_time_ms == candles[3].open_time_ms


def test_high_candidate_branch_wins_when_both_high_and_low_candidates_are_true() -> None:
    candles = [
        _kline(0, open_price="95", high="101", low="90", close="96"),
        _kline(1, open_price="97", high="102", low="92", close="98"),
        # Candle 1 is both strictly higher and strictly lower than candle 2.
        _kline(2, open_price="98", high="101", low="93", close="99"),
    ]
    trace = PineSmcStructureEngine(_config(swing_len=2, internal_len=1)).replay(candles).trace

    assert trace[1].internal_leg == 1
    assert trace[2].internal_leg == 0
    assert trace[2].internal_high.valid
    assert trace[2].internal_high.current == 102.0
    assert trace[2].internal_low.current == 90.0


def test_equal_high_and_low_disqualify_both_pivot_candidates() -> None:
    candles = [
        _kline(0, open_price="95", high="101", low="90", close="96"),
        _kline(1, open_price="95", high="101", low="90", close="96"),
    ]
    trace = PineSmcStructureEngine(_config(swing_len=2, internal_len=1)).replay(candles).trace

    assert trace[1].internal_leg == 0
    assert not trace[1].internal_high.valid
    assert not trace[1].internal_low.valid


def test_pivot_state_preserves_previous_level_when_a_new_pivot_is_confirmed() -> None:
    candles = [
        _kline(0, high="101", low="90", open_price="95", close="96"),
        _kline(1, high="102", low="92", open_price="97", close="98"),
        _kline(2, high="103", low="93", open_price="98", close="99"),
        _kline(3, high="111", low="96", open_price="100", close="101"),
        _kline(4, high="110", low="97", open_price="102", close="103"),
        _kline(5, high="109", low="98", open_price="103", close="104"),
        _kline(6, high="108", low="99", open_price="104", close="105"),
        _kline(7, high="112", low="100", open_price="105", close="106"),
        _kline(8, high="110", low="100.5", open_price="105", close="106"),
        _kline(9, high="111", low="101", open_price="106", close="107"),
    ]
    trace = PineSmcStructureEngine(_config(swing_len=2, internal_len=1)).replay(candles).trace

    # A later confirmed high replaces swHCur while retaining the prior high.
    assert trace[9].swing_high.current == 112.0
    assert trace[9].swing_high.previous == 111.0
    assert trace[9].swing_high.local_index == 7
    assert trace[9].swing_high.crossed is False


def _internal_break_sequence() -> list[Kline]:
    """Build an internal low, internal high, bullish break, then bearish break."""

    return [
        _kline(0, open_price="95", high="100", low="90", close="95"),
        _kline(1, open_price="96", high="101", low="92", close="97"),
        # Equal lows preserve the earlier extreme while high-branch priority
        # confirms the internal high at source/local index 1.
        _kline(2, open_price="97", high="100", low="92", close="98"),
        _kline(3, open_price="98", high="99", low="95", close="98"),
        _kline(4, open_price="100", high="114", low="98", close="112"),
        _kline(5, open_price="100", high="115", low="90", close="92"),
    ]


def test_internal_breaks_emit_bos_then_choch_and_scan_event_extremes_exactly() -> None:
    candles = _internal_break_sequence()
    trace = PineSmcStructureEngine(
        _config(swing_len=10, internal_len=1)
    ).replay(candles).trace

    bullish = trace[4]
    assert bullish.internal_trend == 1
    assert bullish.structure_events.bull_bos is True
    assert bullish.structure_events.bull_choch is False
    assert bullish.structure_events.bear_bos is False
    assert bullish.internal_high.crossed is True
    assert bullish.structure_events.extreme == 92.0
    # Equal minimum at local index 2 does not replace the earlier pivot candle.
    assert bullish.structure_events.extreme_local_index == 1
    assert bullish.structure_events.extreme_source_time_ms == candles[1].open_time_ms

    bearish = trace[5]
    assert bearish.internal_trend == -1
    assert bearish.structure_events.bear_choch is True
    assert bearish.structure_events.bear_bos is False
    assert bearish.internal_low.crossed is True
    assert bearish.structure_events.extreme == 115.0
    assert bearish.structure_events.extreme_local_index == 5
    assert bearish.structure_events.extreme_source_time_ms == candles[5].open_time_ms


def test_internal_crossed_flag_suppresses_repeat_until_a_new_pivot_rearms_it() -> None:
    candles = _internal_break_sequence()
    # Break above the old high again after the bearish CHoCH. The old high's
    # crossed flag remains set until a new internal high pivot is confirmed.
    candles.extend(
        [
            # Keep the bar-5 high candidate from becoming a new pivot: both
            # current high and low reach/exceed the candidate extremes.
            _kline(6, open_price="93", high="115", low="89", close="94"),
            _kline(7, open_price="100", high="116", low="90", close="102"),
            _kline(8, open_price="102", high="117", low="89", close="103"),
        ]
    )
    trace = PineSmcStructureEngine(
        _config(swing_len=10, internal_len=1)
    ).replay(candles).trace

    assert trace[7].internal_high.current == 101.0
    assert trace[7].internal_high.crossed is True
    assert not trace[7].structure_events.bull_bos
    assert not trace[7].structure_events.bull_choch
    # The old high remains crossed, so recrossing it does not emit a second event.
    assert trace[8].internal_high.crossed is True


def test_new_internal_pivot_resets_crossed_flag_and_next_break_is_choch() -> None:
    candles = _internal_break_sequence()
    candles.extend(
        [
            # At local index 6, bar 5 is the delayed high candidate: bar 6 has
            # a lower high and a higher low, confirming a new internal high.
            _kline(6, open_price="94", high="100", low="92", close="95"),
            _kline(7, open_price="105", high="118", low="91", close="116"),
        ]
    )
    trace = PineSmcStructureEngine(
        _config(swing_len=10, internal_len=1)
    ).replay(candles).trace

    # The bar 6 candidate is a new high pivot at 115, and pivot update clears
    # its crossed flag before any subsequent break event is processed.
    assert trace[6].internal_high.current == 115.0
    assert trace[6].internal_high.crossed is False
    assert trace[7].internal_high.crossed is True
    assert trace[7].internal_trend == 1
    assert trace[7].structure_events.bull_choch is True
    assert trace[7].structure_events.bull_bos is False


def test_swing_breaks_update_swing_trend_and_cross_flags_without_internal_events() -> None:
    candles = [
        _kline(0, open_price="95", high="100", low="90", close="95"),
        _kline(1, open_price="96", high="102", low="92", close="97"),
        _kline(2, open_price="97", high="101", low="93", close="98"),
        _kline(3, open_price="98", high="99", low="94", close="98"),
        _kline(4, open_price="100", high="110", low="95", close="105"),
        _kline(5, open_price="97", high="100", low="94", close="98"),
        _kline(6, open_price="102", high="103", low="96", close="101"),
        _kline(7, open_price="103", high="104", low="97", close="102"),
        _kline(8, open_price="95", high="105", low="90", close="92"),
    ]
    trace = PineSmcStructureEngine(
        _config(swing_len=2, internal_len=5)
    ).replay(candles).trace

    assert trace[3].swing_high.current == 102.0
    assert trace[3].range_top == 102.0
    assert trace[4].swing_trend == 1
    assert trace[4].swing_high.crossed is True
    # trTop follows the actual running high after it becomes valid.
    assert trace[4].range_top == 110.0
    assert trace[4].internal_trend == 0
    assert not trace[4].structure_events.bull_bos
    assert trace[7].swing_low.current == 94.0
    assert trace[7].range_bottom == 94.0
    assert trace[8].swing_trend == -1
    assert trace[8].swing_low.crossed is True


def test_confluence_filter_uses_exact_source_expression_and_strict_comparison() -> None:
    candles = _internal_break_sequence()
    # At the break bar: a=high-max(close,open)=2 and
    # b=min(close,open-low)=2. Strict a>b rejects the bullish event.
    candles[4] = _kline(4, open_price="110", high="114", low="108", close="112")
    result = PineSmcStructureEngine(
        _config(swing_len=10, internal_len=1, confluence_filter=True)
    ).replay(candles)
    trace = result.trace

    assert result.confluence_filter is True
    assert trace[4].structure_events.bullish_bar is False
    assert trace[4].structure_events.bearish_bar is False
    assert not trace[4].structure_events.bull_bos
    assert trace[4].internal_trend == 0
    assert trace[4].internal_high.crossed is False


def test_structure_event_trace_is_deterministic_and_includes_per_bar_flags() -> None:
    candles = _internal_break_sequence()
    engine = PineSmcStructureEngine(_config(swing_len=10, internal_len=1))
    first = engine.replay(candles).to_jsonl()
    second = engine.replay(candles).to_jsonl()

    assert first == second
    assert '"structure_events"' in first
    assert '"internal_trend":1' in first
    assert '"bull_bos":true' in first


def test_timeframe_replays_have_independent_last_bar_reset_boundaries() -> None:
    m1 = PineSmcStructureEngine(_config(timeframe="1m")).replay(
        _range_candles(["2"] * 310, interval="1m")
    )
    m5 = PineSmcStructureEngine(_config(timeframe="5m")).replay(
        _range_candles(["2"] * 305, interval="5m")
    )
    m15 = PineSmcStructureEngine(_config(timeframe="15m")).replay(
        _range_candles(["2"] * 20, interval="15m")
    )

    assert (m1.reset_start_index, m1.processed_bar_count) == (10, 300)
    assert (m5.reset_start_index, m5.processed_bar_count) == (5, 300)
    assert (m15.reset_start_index, m15.processed_bar_count) == (0, 20)
    assert {m1.timeframe, m5.timeframe, m15.timeframe} == {"1m", "5m", "15m"}


def test_trace_jsonl_is_byte_stable_for_identical_input() -> None:
    candles = _range_candles(["1.5", "2", "2.5", "3", "3.5"])
    engine = PineSmcStructureEngine(_config())

    first = engine.replay(candles).to_jsonl()
    second = engine.replay(candles).to_jsonl()

    assert first == second
    assert first.endswith("\n")
    assert '"timeframe":"1m"' in first


def test_replay_rejects_empty_gapped_mismatched_or_non_binance_series() -> None:
    engine = PineSmcStructureEngine(_config())
    with pytest.raises(PineSmcReplayError, match="at least one"):
        engine.replay([])

    with pytest.raises(PineSmcReplayError, match="contiguous"):
        engine.replay([_kline(0), _kline(2)])

    with pytest.raises(PineSmcReplayError, match="symbol"):
        engine.replay([_kline(0, symbol="ETHUSDT")])

    with pytest.raises(PineSmcReplayError, match="Binance USD-M"):
        engine.replay([_kline(0, exchange="BINANCE_SPOT")])

    with pytest.raises(PineSmcReplayError, match="timeframe"):
        PineSmcStructureEngine(_config(timeframe="5m")).replay([_kline(0, interval="1m")])


def test_parser_rejects_invalid_nonfinite_or_negative_atr_values() -> None:
    with pytest.raises(PineSmcReplayError, match="finite"):
        parse_candle_extremes(high=float("nan"), low=1.0, atr200=1.0)
    with pytest.raises(PineSmcReplayError, match="cannot be below"):
        parse_candle_extremes(high=1.0, low=2.0, atr200=1.0)
    with pytest.raises(PineSmcReplayError, match="cannot be negative"):
        parse_candle_extremes(high=2.0, low=1.0, atr200=-1.0)
