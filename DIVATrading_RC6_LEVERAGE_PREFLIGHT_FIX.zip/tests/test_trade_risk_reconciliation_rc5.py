from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal

from divatrading.core.database import Database
from divatrading.execution.trade_risk_ledger import CompletedTradeRiskLedger
from divatrading.execution.trade_risk_reconciliation import CompletedTradeRiskReconciler


class FakeExecutionLedger:
    def __init__(self, positions, fills, projections, income):
        self.positions, self.fills = positions, fills
        self.projections, self.income = projections, income
    def apply_position_fill_allocations(self): return []
    def position_fill_allocation_counts(self): return {"ATTRIBUTED": len(self.fills), "UNATTRIBUTED": 0, "EXTERNAL": 0}
    def list_managed_positions(self, *, status=None):
        return self.positions if status is None else [p for p in self.positions if p["status"] == status]
    def list_position_fill_allocations(self, *, signal_id=None, allocation_status=None):
        rows = self.fills
        if signal_id is not None: rows = [r for r in rows if r["signal_id"] == signal_id]
        if allocation_status is not None: rows = [r for r in rows if r["allocation_status"] == allocation_status]
        return rows
    def list_income_rows(self, *, start_time_ms=None, end_time_ms=None):
        rows = self.income
        if start_time_ms is not None: rows = [r for r in rows if r["time_ms"] >= start_time_ms]
        if end_time_ms is not None: rows = [r for r in rows if r["time_ms"] <= end_time_ms]
        return rows
    def get_position_fill_projection(self, signal_id): return self.projections.get(signal_id)


def _position(signal, opened, closed):
    return {"signal_id": signal, "symbol": "BTCUSDT", "position_side": "LONG",
            "status": "CLOSED", "opened_at_utc": opened.isoformat(),
            "updated_at_utc": closed.isoformat()}


def _fill(signal, effect, qty, price, stamp):
    return {"signal_id": signal, "effect": effect, "quantity": str(qty), "price": str(price),
            "event_time_ms": int(stamp.timestamp() * 1000), "allocation_status": "ATTRIBUTED"}


def test_reconciler_allocates_funding_proportionally_and_records_completed_trades(tmp_path):
    opened = datetime(2026, 11, 15, 0, 0, tzinfo=UTC)
    funding_at = opened + timedelta(hours=1)
    closed = opened + timedelta(hours=2)
    closed_later = closed + timedelta(minutes=1)
    positions = [_position("lot-a", opened, closed_later), _position("lot-b", opened, closed)]
    fills = [
        _fill("lot-a", "OPEN", "2", "100", opened),
        _fill("lot-a", "CLOSE", "2", "100", closed_later),
        _fill("lot-b", "OPEN", "1", "100", opened),
        _fill("lot-b", "CLOSE", "1", "100", closed),
    ]
    projections = {
        "lot-a": {"net_quantity": "0", "commissions": {"USDT": "0.2"}, "realized_pnl": {"USDT": "-3"}},
        "lot-b": {"net_quantity": "0", "commissions": {"USDT": "0.1"}, "realized_pnl": {"USDT": "1"}},
    }
    income = [{"income_type": "FUNDING_FEE", "asset": "USDT", "income": "-0.3",
               "symbol": "BTCUSDT", "time_ms": int(funding_at.timestamp() * 1000)}]
    execution = FakeExecutionLedger(positions, fills, projections, income)
    risk = CompletedTradeRiskLedger(Database(tmp_path / "risk.sqlite"))
    reconciler = CompletedTradeRiskReconciler(execution_ledger=execution, risk_ledger=risk)
    ready, reason = reconciler.reconcile(now=closed_later)
    assert ready and reason is None
    snap = risk.snapshot(closed_later)
    assert snap.reconciliation_ready
    assert snap.consecutive_losses == 1
    rows = risk.db.transaction  # the persisted net results are checked through snapshot totals
    assert snap.daily_net_pnl == Decimal("-2.6")
    assert reconciler.daily_realized_net_pnl(closed_later) == Decimal("-0.3")  # funding income is signed by the exchange


def test_reconciler_blocks_unknown_fill_and_non_usdt_commission(tmp_path):
    now = datetime(2026, 11, 15, tzinfo=UTC)
    position = _position("lot-a", now - timedelta(hours=1), now)
    fills = [_fill("lot-a", "OPEN", "1", "100", now - timedelta(hours=1)),
             _fill("lot-a", "CLOSE", "1", "100", now)]
    execution = FakeExecutionLedger([position], fills,
        {"lot-a": {"net_quantity": "0", "commissions": {"BNB": "0.001"}, "realized_pnl": {"USDT": "1"}}}, [])
    risk = CompletedTradeRiskLedger(Database(tmp_path / "risk-nonusdt.sqlite"))
    reconciler = CompletedTradeRiskReconciler(execution_ledger=execution, risk_ledger=risk)
    ready, reason = reconciler.reconcile(now=now)
    assert not ready and "NON_USDT_COMMISSION" in reason
    assert not risk.snapshot(now).reconciliation_ready


def test_daily_realized_net_uses_exchange_income_rows_and_jakarta_day(tmp_path):
    now = datetime(2026, 11, 15, 2, 0, tzinfo=UTC)  # 09:00 Jakarta
    start = datetime(2026, 11, 14, 17, 0, tzinfo=UTC)  # 00:00 Jakarta
    execution = FakeExecutionLedger([], [], {}, [
        {"income_type": "REALIZED_PNL", "asset": "USDT", "income": "2", "time_ms": int((start + timedelta(minutes=1)).timestamp() * 1000)},
        {"income_type": "COMMISSION", "asset": "USDT", "income": "-0.2", "time_ms": int((start + timedelta(minutes=2)).timestamp() * 1000)},
        {"income_type": "FUNDING_FEE", "asset": "USDT", "income": "-0.1", "time_ms": int((start + timedelta(minutes=3)).timestamp() * 1000)},
        {"income_type": "REALIZED_PNL", "asset": "USDT", "income": "100", "time_ms": int((start - timedelta(seconds=1)).timestamp() * 1000)},
    ])
    risk = CompletedTradeRiskLedger(Database(tmp_path / "daily.sqlite"))
    reconciler = CompletedTradeRiskReconciler(execution_ledger=execution, risk_ledger=risk)
    assert reconciler.daily_realized_net_pnl(now) == Decimal("1.7")


def test_reconciler_blocks_unknown_nonzero_income_type(tmp_path):
    now = datetime(2026, 11, 15, tzinfo=UTC)
    execution = FakeExecutionLedger([], [], {}, [
        {"income_type": "INSURANCE_CLEAR", "asset": "USDT", "income": "0.25",
         "time_ms": int(now.timestamp() * 1000)},
    ])
    risk = CompletedTradeRiskLedger(Database(tmp_path / "risk-unknown-income.sqlite"))
    reconciler = CompletedTradeRiskReconciler(execution_ledger=execution, risk_ledger=risk)
    ready, reason = reconciler.reconcile(now=now)
    assert not ready and "UNSUPPORTED_NONZERO_INCOME_TYPE" in reason
    assert not risk.snapshot(now).reconciliation_ready


def test_day_start_equity_reconstructs_realized_and_floating_pnl():
    from divatrading.execution.trade_risk_reconciliation import derive_day_start_equity
    assert derive_day_start_equity(
        flow_neutral_current_equity=Decimal("990"),
        daily_realized_net_pnl=Decimal("-5"),
        current_floating_pnl=Decimal("-5"),
    ) == Decimal("1000")
