from pathlib import Path

import pytest

from divatrading.core.database import Database, SCHEMA_VERSION


def test_database_migrates_and_is_idempotent(tmp_path: Path) -> None:
    db = Database(tmp_path / "state" / "diva.db")
    assert db.initialize() == SCHEMA_VERSION
    assert db.initialize() == SCHEMA_VERSION
    assert db.schema_version() == SCHEMA_VERSION


def test_settings_round_trip_json(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    db.set_setting("universe", {"mode": "MANUAL", "symbols": ["BTCUSDT"]})
    assert db.get_setting("universe") == {"mode": "MANUAL", "symbols": ["BTCUSDT"]}
    assert db.get_setting("missing", "fallback") == "fallback"


def test_runtime_events_round_trip(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    event_id = db.record_event("info", "unit-test", "test_event", "hello", {"n": 1})
    events = db.recent_events()
    assert events[0]["id"] == event_id
    assert events[0]["details"] == {"n": 1}
    assert events[0]["level"] == "INFO"


def test_invalid_event_and_limit_are_rejected(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    with pytest.raises(ValueError):
        db.record_event("INFO", "", "event", "message")
    with pytest.raises(ValueError):
        db.recent_events(0)


def test_exchange_metadata_snapshot_storage_and_integrity(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    payload = {"serverTime": 123, "symbols": [{"symbol": "BTCUSDT"}]}
    snapshot_id = db.save_exchange_metadata_snapshot(
        source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo",
        fetched_at_utc="2026-11-10T00:00:00.000Z",
        server_time_ms=123,
        symbol_count=1,
        payload=payload,
    )
    cached = db.latest_exchange_metadata_snapshot()
    assert snapshot_id == 1
    assert cached is not None
    assert cached["payload"] == payload
    assert cached["payload_sha256"]


def test_exchange_metadata_retention_keeps_newest_snapshots(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    for index in range(3):
        db.save_exchange_metadata_snapshot(
            source_endpoint="fixture",
            fetched_at_utc=f"2026-11-10T00:00:0{index}.000Z",
            server_time_ms=index,
            symbol_count=index,
            payload={"symbols": [], "index": index},
            retain=2,
        )
    cached = db.latest_exchange_metadata_snapshot()
    assert cached is not None
    assert cached["id"] == 3
    with db.connection() as connection:
        count = connection.execute("SELECT COUNT(*) FROM exchange_metadata_snapshots").fetchone()[0]
    assert count == 2


def test_existing_schema_v1_database_upgrades_to_latest_schema(tmp_path: Path) -> None:
    import sqlite3

    db_path = tmp_path / "legacy-v1.db"
    connection = sqlite3.connect(db_path)
    connection.executescript(
        """
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, applied_at_utc TEXT NOT NULL);
        INSERT INTO schema_migrations(version, applied_at_utc) VALUES (1, '2026-11-09T00:00:00Z');
        CREATE TABLE app_settings (setting_key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at_utc TEXT NOT NULL);
        CREATE TABLE runtime_events (id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_at_utc TEXT NOT NULL, level TEXT NOT NULL, component TEXT NOT NULL, event_name TEXT NOT NULL, message TEXT NOT NULL, details_json TEXT NOT NULL DEFAULT '{}');
        CREATE INDEX idx_runtime_events_time ON runtime_events(occurred_at_utc DESC);
        CREATE INDEX idx_runtime_events_component ON runtime_events(component, event_name);
        INSERT INTO app_settings(setting_key, value_json, updated_at_utc) VALUES ('preserve', '{"yes":true}', '2026-11-09T00:00:00Z');
        """
    )
    connection.commit()
    connection.close()

    db = Database(db_path)
    assert db.initialize() == SCHEMA_VERSION
    assert db.get_setting("preserve") == {"yes": True}
    assert db.latest_exchange_metadata_snapshot() is None


def test_exchange_metadata_snapshot_detects_payload_tampering(tmp_path: Path) -> None:
    import sqlite3

    db = Database(tmp_path / "diva.db")
    db.initialize()
    db.save_exchange_metadata_snapshot(
        source_endpoint="fixture",
        fetched_at_utc="2026-11-10T00:00:00.000Z",
        server_time_ms=None,
        symbol_count=0,
        payload={"symbols": []},
    )
    connection = sqlite3.connect(db.path)
    connection.execute("UPDATE exchange_metadata_snapshots SET payload_json = ?", ('{"symbols":[1]}',))
    connection.commit()
    connection.close()

    with pytest.raises(RuntimeError, match="SHA-256 integrity"):
        db.latest_exchange_metadata_snapshot()


def test_existing_schema_v3_migrates_to_v6_and_preserves_kline_data(tmp_path: Path) -> None:
    db = Database(tmp_path / "legacy-v3.db")
    db.initialize()
    with db.transaction() as connection:
        connection.execute(
            """INSERT INTO market_klines(
                exchange, symbol, interval, open_time_ms, open, high, low, close, volume,
                close_time_ms, quote_asset_volume, trade_count, taker_buy_base_volume,
                taker_buy_quote_volume, ignore_value, source_endpoint, first_seen_at_utc,
                last_fetched_at_utc, last_saved_at_utc
            ) VALUES ('BINANCE_UM', 'BTCUSDT', '1m', 0, '1', '1', '1', '1', '0',
                     59999, '0', 0, '0', '0', '0', 'fixture', '2026-11-10T00:00:00Z',
                     '2026-11-10T00:00:00Z', '2026-11-10T00:00:00Z')"""
        )
        connection.execute("DELETE FROM schema_migrations WHERE version>=4")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_evaluations")
        connection.execute("DROP TABLE IF EXISTS signal_forecast_links")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_forecasts")
        connection.execute("DROP TABLE IF EXISTS signal_publications")
        connection.execute("DROP TABLE IF EXISTS order_flow_buckets")
        connection.execute("DROP TABLE IF EXISTS order_flow_state")
        connection.execute("DROP TABLE aggregate_trade_gaps")
        connection.execute("DROP TABLE aggregate_trade_stream_state")
        connection.execute("DROP TABLE aggregate_trades")
    assert db.schema_version() == 3

    assert db.initialize() == 6
    with db.connection() as connection:
        row = connection.execute(
            "SELECT close FROM market_klines WHERE symbol='BTCUSDT' AND open_time_ms=0"
        ).fetchone()
        trade_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='aggregate_trades'"
        ).fetchone()
    assert row["close"] == "1"
    assert trade_table is not None


def test_existing_schema_v4_migrates_to_v6_without_touching_trade_rows(tmp_path: Path) -> None:
    db = Database(tmp_path / "legacy-v4.db")
    db.initialize()
    with db.transaction() as connection:
        connection.execute(
            """INSERT INTO aggregate_trades(
                exchange, symbol, aggregate_trade_id, price, quantity, normal_quantity,
                first_trade_id, last_trade_id, event_time_ms, trade_time_ms, buyer_is_maker,
                first_source_kind, last_source_kind, first_source_endpoint, last_source_endpoint,
                first_seen_at_utc, last_seen_at_utc
            ) VALUES ('BINANCE_UM', 'BTCUSDT', 10, '100', '0.1', NULL, 20, 21, 1000, 1000, 0,
                     'REST', 'REST', 'fixture', 'fixture', '2026-11-10T00:00:00Z', '2026-11-10T00:00:00Z')"""
        )
        connection.execute("DELETE FROM schema_migrations WHERE version>=5")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_evaluations")
        connection.execute("DROP TABLE IF EXISTS signal_forecast_links")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_forecasts")
        connection.execute("DROP TABLE IF EXISTS signal_publications")
        connection.execute("DROP TABLE order_flow_buckets")
        connection.execute("DROP TABLE order_flow_state")
    assert db.schema_version() == 4
    assert db.initialize() == 6
    with db.connection() as connection:
        trade = connection.execute(
            "SELECT aggregate_trade_id, price FROM aggregate_trades WHERE symbol='BTCUSDT'"
        ).fetchone()
        state_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='order_flow_state'"
        ).fetchone()
    assert trade["aggregate_trade_id"] == 10
    assert trade["price"] == "100"
    assert state_table is not None
