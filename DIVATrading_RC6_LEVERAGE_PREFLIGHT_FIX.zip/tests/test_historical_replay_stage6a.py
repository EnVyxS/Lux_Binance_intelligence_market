from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.replay import (
    HistoricalReplayRunner,
    ReplayConfig,
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayManifestError,
    ReplayMetadataSnapshot,
    ReplayRunnerError,
    iter_binance_kline_rows,
    iter_kline_chunks,
    iter_rest_klines,
)

ROOT = Path(__file__).parent
FIXTURE = ROOT / "fixtures" / "exchange_info_valid.json"
SCHEMA = ROOT.parent / "reference" / "replay" / "replay_dataset_manifest.schema.json"


def symbol_payload():
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    return next(item for item in payload["symbols"] if item["symbol"] == "BTCUSDT")


def write_csv(
    root: Path, interval: str, opens: list[int], *, base: int = 100,
    future_perturb_after_ms: int | None = None,
) -> ReplayKlineFile:
    path = root / f"BTCUSDT-{interval}.csv"
    step = INTERVAL_MILLISECONDS[interval]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        for index, open_time in enumerate(opens):
            # Values lie exactly on the fixture's 0.10 tick grid.
            offset = 50 if future_perturb_after_ms is not None and open_time >= future_perturb_after_ms else 0
            op = base + offset + (index % 3) * 0.1
            hi = op + 0.5
            lo = op - 0.5
            cl = op + (0.1 if index % 2 else -0.1)
            writer.writerow([
                open_time, f"{op:.1f}", f"{hi:.1f}", f"{lo:.1f}", f"{cl:.1f}",
                "10", open_time + step - 1, "1000", 10, "5", "500", "0",
            ])
    return ReplayKlineFile.inspect(
        root, path.name, interval, symbol="BTCUSDT", source_url="https://data.binance.vision/test.csv.zip"
    )


def manifest_for(
    root: Path, *, gap_m1: bool = False, metadata_quality: str = "HISTORICAL_EFFECTIVE",
    future_perturb_after_ms: int | None = None,
):
    m1_opens = list(range(0, 20 * 60_000, 60_000))
    if gap_m1:
        m1_opens.remove(7 * 60_000)
    m5_opens = list(range(0, 20 * 60_000, 5 * 60_000))
    files = [
        write_csv(root, "1m", m1_opens, future_perturb_after_ms=future_perturb_after_ms),
        write_csv(root, "5m", m5_opens, future_perturb_after_ms=future_perturb_after_ms),
    ]
    metadata = ReplayMetadataSnapshot.from_symbol_payload(
        symbol_payload(), quality=metadata_quality,
        source_url="https://fapi.binance.com/fapi/v1/exchangeInfo",
        captured_at_ms=2_000_000,
        effective_from_ms=0 if metadata_quality == "HISTORICAL_EFFECTIVE" else None,
        effective_to_ms=2_000_000 if metadata_quality == "HISTORICAL_EFFECTIVE" else None,
    )
    return ReplayDatasetManifest(
        symbol="BTCUSDT", start_open_time_ms=0, end_open_time_ms=20 * 60_000,
        files=tuple(files), metadata=metadata,
    )


def test_manifest_hash_roundtrip_and_schema_meta_validation(tmp_path):
    manifest = manifest_for(tmp_path)
    path = manifest.write(tmp_path / "manifest.json")
    loaded = ReplayDatasetManifest.load(path)
    assert loaded.dataset_id == manifest.dataset_id
    assert loaded.validate(tmp_path).symbol == "BTCUSDT"
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(loaded.to_dict())


def test_manifest_requires_aligned_full_candle_window_for_each_interval(tmp_path):
    from dataclasses import replace

    manifest = manifest_for(tmp_path)
    with pytest.raises(ReplayManifestError, match="boundaries must align"):
        ReplayDatasetManifest(
            symbol=manifest.symbol, start_open_time_ms=0, end_open_time_ms=19 * 60_000,
            files=manifest.files, metadata=manifest.metadata,
        )

    shortened = tuple(
        replace(item, last_open_time_ms=item.last_open_time_ms - INTERVAL_MILLISECONDS[item.interval])
        if item.interval == "1m" else item
        for item in manifest.files
    )
    with pytest.raises(ReplayManifestError, match="final fully closed candle"):
        ReplayDatasetManifest(
            symbol=manifest.symbol, start_open_time_ms=manifest.start_open_time_ms,
            end_open_time_ms=manifest.end_open_time_ms, files=shortened, metadata=manifest.metadata,
        )


def test_strict_replay_rejects_current_exchange_snapshot_metadata(tmp_path):
    manifest = manifest_for(tmp_path, metadata_quality="CURRENT_SNAPSHOT_ONLY")
    with pytest.raises(ReplayManifestError, match="HISTORICAL_EFFECTIVE"):
        manifest.validate(tmp_path, strict_metadata=True)
    assert manifest.validate(tmp_path, strict_metadata=False).symbol == "BTCUSDT"


def test_manifest_detects_source_hash_change(tmp_path):
    manifest = manifest_for(tmp_path)
    with (tmp_path / "BTCUSDT-1m.csv").open("a", encoding="utf-8") as handle:
        handle.write("\n")
    with pytest.raises(ReplayManifestError, match="SHA-256 mismatch"):
        manifest.validate(tmp_path)


def test_runner_emits_deterministic_evidence_only_ledger_and_aligned_captures(tmp_path):
    manifest = manifest_for(tmp_path)
    config = ReplayConfig(max_history_candles=128)
    runner = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config)
    first, summary1 = runner.run_to_jsonl()
    second, summary2 = HistoricalReplayRunner(
        manifest, dataset_root=tmp_path, config=config
    ).run_to_jsonl()
    assert first == second
    assert summary1.replay_run_id == summary2.replay_run_id
    rows = [json.loads(line) for line in first.splitlines()]
    assert rows[0]["record_type"] == "REPLAY_RUN_HEADER"
    captures = [row for row in rows if row["record_type"] == "REPLAY_CAPTURE_SUMMARY"]
    assert captures
    same_close = next(row for row in captures if row["known_at_time_ms"] == 300_000)
    assert set(same_close["payload"]["updated_intervals"]) == {"1m", "5m"}
    assert all(row["known_at_time_ms"] > row["payload"].get("confirmation_time_ms", -1) for row in rows if row.get("stage") == "STAGE_2_MARKET_STRUCTURE")
    assert not any(row["record_type"] in {"FILL", "TRADE", "PNL", "ENTRY", "ORDER"} for row in rows)
    assert rows[-1]["record_type"] == "REPLAY_RUN_SUMMARY"
    assert summary1.capture_count == len(captures)


def test_gap_resets_only_affected_timeframe_and_is_recorded(tmp_path):
    manifest = manifest_for(tmp_path, gap_m1=True)
    config = ReplayConfig(max_history_candles=128)
    ledger, summary = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_jsonl()
    rows = [json.loads(line) for line in ledger.splitlines()]
    gaps = [row for row in rows if row["record_type"] == "REPLAY_DATA_GAP"]
    assert len(gaps) == 1
    assert gaps[0]["timeframe"] == "1m"
    assert gaps[0]["payload"]["missing_bar_count"] == 1
    assert summary.gap_count == 1


def test_resume_rebuilds_prefix_and_produces_same_ledger(tmp_path):
    manifest = manifest_for(tmp_path)
    config = ReplayConfig(max_history_candles=128, checkpoint_every_captures=2)
    expected, _ = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_jsonl()
    ledger_path = tmp_path / "replay.jsonl"
    checkpoint_path = tmp_path / "replay.checkpoint.json"
    runner = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config)
    runner.run_to_file(ledger_path, checkpoint_path=checkpoint_path, stop_after_captures=4)
    # Simulate an interrupted write after the last durable checkpoint.
    with ledger_path.open("ab") as handle:
        handle.write(b'{"partial":true}\n')
    HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
        ledger_path, checkpoint_path=checkpoint_path, resume_from_checkpoint=True
    )
    assert ledger_path.read_text(encoding="utf-8") == expected


def test_resume_rejects_corrupted_ledger_prefix_even_at_valid_line_boundary(tmp_path):
    manifest = manifest_for(tmp_path)
    config = ReplayConfig(max_history_candles=128, checkpoint_every_captures=2)
    ledger = tmp_path / "ledger.jsonl"
    checkpoint = tmp_path / "checkpoint.json"
    HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
        ledger, checkpoint_path=checkpoint, stop_after_captures=4
    )
    raw = ledger.read_bytes()
    needle = b'"open":"100.0"'
    assert needle in raw
    # Keep the JSONL valid and retain every newline/byte offset, but alter a
    # durable evidence value so the checkpoint's prefix digest must detect it.
    ledger.write_bytes(raw.replace(needle, b'"open":"100.1"', 1))
    with pytest.raises(ReplayRunnerError, match="prefix SHA-256"):
        HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
            ledger, checkpoint_path=checkpoint, resume_from_checkpoint=True
        )


def test_resume_rejects_changed_manifest_config_identity(tmp_path):
    manifest = manifest_for(tmp_path)
    config = ReplayConfig(max_history_candles=128, checkpoint_every_captures=2)
    ledger = tmp_path / "ledger.jsonl"
    checkpoint = tmp_path / "checkpoint.json"
    HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
        ledger, checkpoint_path=checkpoint, stop_after_captures=3
    )
    other_config = ReplayConfig(
        max_history_candles=64,
        market_data_config=__import__(
            "divatrading.strategy.scalping_market_data", fromlist=["ScalpingMarketDataConfig"]
        ).ScalpingMarketDataConfig(max_candles_per_interval=64),
    )
    with pytest.raises(ReplayRunnerError, match="replay_run_id"):
        HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=other_config).run_to_file(
            ledger, checkpoint_path=checkpoint, resume_from_checkpoint=True
        )


def test_prefix_invariance_future_ohlc_perturbation_does_not_change_prior_evidence(tmp_path):
    root_a = tmp_path / "baseline"
    root_b = tmp_path / "future_changed"
    root_a.mkdir()
    root_b.mkdir()
    manifest_a = manifest_for(root_a)
    manifest_b = manifest_for(root_b, future_perturb_after_ms=600_000)
    config = ReplayConfig(max_history_candles=128)
    ledger_a, _ = HistoricalReplayRunner(manifest_a, dataset_root=root_a, config=config).run_to_jsonl()
    ledger_b, _ = HistoricalReplayRunner(manifest_b, dataset_root=root_b, config=config).run_to_jsonl()

    def strip_capture_identity(value):
        if isinstance(value, dict):
            # Capture IDs and whole-file hashes are dataset-scoped provenance;
            # they must change when future source rows change. Compare the
            # strategy evidence payload independently from those identifiers.
            return {
                key: strip_capture_identity(item)
                for key, item in value.items()
                if key not in {"replay_capture_id", "source_file_hashes"}
            }
        if isinstance(value, list):
            return [strip_capture_identity(item) for item in value]
        return value

    def prefix_payloads(ledger: str):
        selected = []
        for line in ledger.splitlines():
            row = json.loads(line)
            if row.get("record_type") in {"REPLAY_RUN_HEADER", "REPLAY_RUN_SUMMARY"}:
                continue
            if row.get("known_at_time_ms", 0) <= 600_000:
                selected.append((row.get("record_type"), row.get("stage"), strip_capture_identity(row.get("payload"))))
        return selected

    assert prefix_payloads(ledger_a) == prefix_payloads(ledger_b)
    header_a = json.loads(ledger_a.splitlines()[0])
    header_b = json.loads(ledger_b.splitlines()[0])
    assert header_a["source_files"] != header_b["source_files"]


def test_m1_gap_does_not_reset_or_suppress_m5_trace_stream(tmp_path):
    manifest = manifest_for(tmp_path, gap_m1=True)
    ledger, summary = HistoricalReplayRunner(
        manifest, dataset_root=tmp_path, config=ReplayConfig(max_history_candles=128)
    ).run_to_jsonl()
    rows = [json.loads(line) for line in ledger.splitlines()]
    m5_traces = [row for row in rows if row.get("record_type") == "BAR_TRACE" and row.get("timeframe") == "5m"]
    m1_gaps = [row for row in rows if row.get("record_type") == "REPLAY_DATA_GAP" and row.get("timeframe") == "1m"]
    assert len(m1_gaps) == 1
    assert len(m5_traces) == 4
    assert [row["payload"]["bar_open_time_ms"] for row in m5_traces] == [0, 300_000, 600_000, 900_000]
    assert summary.gap_count == 1


def test_closed_bar_provenance_is_strict_for_every_structure_trace(tmp_path):
    manifest = manifest_for(tmp_path)
    ledger, _ = HistoricalReplayRunner(
        manifest, dataset_root=tmp_path, config=ReplayConfig(max_history_candles=128)
    ).run_to_jsonl()
    rows = [json.loads(line) for line in ledger.splitlines()]
    traces = [row for row in rows if row.get("record_type") == "BAR_TRACE"]
    assert traces
    assert all(row["known_at_time_ms"] > row["payload"]["confirmation_time_ms"] for row in traces)


def test_csv_reader_chunks_are_independent_of_chunk_size(tmp_path):
    manifest = manifest_for(tmp_path)
    entry = next(item for item in manifest.files if item.interval == "1m")
    source = list(iter_binance_kline_rows(
        tmp_path / entry.path, symbol="BTCUSDT", interval="1m", source_endpoint="fixture"
    ))
    for size in (1, 2, 5, 64):
        chunks = list(iter_kline_chunks(iter(source), chunk_size=size))
        assert [item for chunk in chunks for item in chunk] == source
        assert all(1 <= len(chunk) <= size for chunk in chunks)


def test_rest_kline_reader_uses_bounded_pages_and_preserves_typed_rows():
    class FakeRestClient:
        klines_endpoint = "https://fapi.binance.com/fapi/v1/klines"

        def __init__(self):
            self.rows = []
            step = INTERVAL_MILLISECONDS["1m"]
            for open_time in range(0, 6 * step, step):
                self.rows.append([
                    open_time, "100.0", "100.5", "99.5", "100.1", "10",
                    open_time + step - 1, "1000", 10, "5", "500", "0",
                ])

        def get_klines(self, *, symbol, interval, start_time_ms, end_time_ms, limit):
            return [row for row in self.rows if start_time_ms <= row[0] <= end_time_ms][:limit]

    rows = list(iter_rest_klines(
        FakeRestClient(), symbol="BTCUSDT", interval="1m", start_time_ms=0,
        end_time_ms=5 * 60_000, page_limit=2, pages_per_chunk=1,
        min_request_interval_seconds=0, sleep=lambda _: None,
    ))
    assert len(rows) == 6
    assert all(isinstance(item, Kline) for item in rows)
    assert [item.open_time_ms for item in rows] == list(range(0, 6 * 60_000, 60_000))


def test_compact_preroll_preserves_engine_state_and_commits_suppressed_records(tmp_path):
    manifest = manifest_for(tmp_path)
    boundary = 10 * 60_000
    config_full = ReplayConfig(max_history_candles=128)
    config_compact = ReplayConfig(max_history_candles=128, evidence_start_time_ms=boundary)
    full_text, _ = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config_full).run_to_jsonl()
    compact_text, compact_summary = HistoricalReplayRunner(
        manifest, dataset_root=tmp_path, config=config_compact
    ).run_to_jsonl()
    full_rows = [json.loads(line) for line in full_text.splitlines()]
    compact_rows = [json.loads(line) for line in compact_text.splitlines()]
    full_eval = [row for row in full_rows if row.get("known_at_time_ms", -1) >= boundary and row.get("record_type") not in {"REPLAY_RUN_HEADER", "REPLAY_RUN_SUMMARY"}]
    compact_eval = [row for row in compact_rows if row.get("known_at_time_ms", -1) >= boundary and row.get("record_type") not in {"REPLAY_RUN_HEADER", "REPLAY_RUN_SUMMARY"}]
    def normalize(value):
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items() if key not in {"replay_run_id", "replay_capture_id"}}
        if isinstance(value, list):
            return [normalize(item) for item in value]
        return value
    assert normalize(compact_eval) == normalize(full_eval)
    from hashlib import sha256
    from divatrading.replay.manifest import canonical_json
    digest_runner = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config_compact)
    digest_runner._reset_runtime()
    suppressed = []
    for _, captured_at, records in digest_runner._iter_capture_batches():
        if captured_at < boundary:
            suppressed.extend(records)
    expected_digest = sha256("".join(canonical_json(row) + "\n" for row in suppressed).encode()).hexdigest()
    compact_summary_row = compact_rows[-1]
    assert compact_summary_row["suppressed_pre_roll_record_count"] == len(suppressed)
    assert compact_summary_row["suppressed_pre_roll_records_sha256"] == expected_digest


def test_compact_preroll_checkpoint_resume_matches_uninterrupted_run(tmp_path):
    manifest = manifest_for(tmp_path)
    config = ReplayConfig(max_history_candles=128, evidence_start_time_ms=10 * 60_000, checkpoint_every_captures=2)
    expected, _ = HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_jsonl()
    ledger_path = tmp_path / "compact.jsonl"
    checkpoint_path = tmp_path / "compact.checkpoint.json"
    HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
        ledger_path, checkpoint_path=checkpoint_path, stop_after_captures=8
    )
    HistoricalReplayRunner(manifest, dataset_root=tmp_path, config=config).run_to_file(
        ledger_path, checkpoint_path=checkpoint_path, resume_from_checkpoint=True
    )
    assert ledger_path.read_text(encoding="utf-8") == expected
