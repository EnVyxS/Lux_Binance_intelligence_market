"""Keep exchange and operator CLI tests independent of live configuration."""

import ipaddress
import os
import socket

import pytest


@pytest.fixture(scope="session", autouse=True)
def block_external_network():
    def check_host(host):
        if host in (None, "", "localhost", b"localhost"):
            return
        try:
            if ipaddress.ip_address(host).is_loopback:
                return
        except ValueError:
            pass
        raise OSError("DIVATrading tests block external network access")

    original_lookup = socket.getaddrinfo

    def lookup(host, *args, **kwargs):
        check_host(host)
        return original_lookup(host, *args, **kwargs)

    def offline_connect(original):
        def connect(sock, address):
            if isinstance(address, tuple):
                check_host(address[0])
            return original(sock, address)

        return connect

    original_sendto = socket.socket.sendto

    def sendto(sock, data, *args):
        if args and isinstance(args[-1], tuple):
            check_host(args[-1][0])
        return original_sendto(sock, data, *args)

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(socket, "getaddrinfo", lookup)
        patch.setattr(socket.socket, "connect", offline_connect(socket.socket.connect))
        patch.setattr(socket.socket, "connect_ex", offline_connect(socket.socket.connect_ex))
        patch.setattr(socket.socket, "sendto", sendto)
        yield


@pytest.fixture
def isolated_cli_environment(monkeypatch):
    """Allow temporary .env fixtures and fake clients to exercise mode-specific paths."""
    for name in os.environ.copy():
        if name.startswith(("DIVA_", "BINANCE_", "TELEGRAM_")):
            monkeypatch.delenv(name)
