"""RC4 admission/protection safety contracts; all fixtures are offline."""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal as D
import json
from pathlib import Path
import time

import httpx
import pytest

from divatrading.trading.models import QualifiedSignal, TradePlan
from divatrading.trading.post_fill_risk import assess_post_fill_risk
from divatrading.trading.entry_quote_guard import (
    EntryQuoteGuardConfig, check_entry_quote,
)
from divatrading.execution.binance_private import (
    BinancePrivateApiError, BinancePrivateRestClient, BinancePrivateTransportError,
)
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService


def _plan(*, side="LONG", entry_type="MARKET", quantity="1"):
    signal = QualifiedSignal(
        signal_id="rc4-foo", symbol="BTCUSDT", side=side, entry_type=entry_type,
        entry_price=D("100"),
        stop_loss=D("90") if side == "LONG" else D("110"),
        take_profit=D("130") if side == "LONG" else D("70"),
        timeframe="5m", strategy_id="SMC_V2", created_at_ms=int(time.time() * 1000),
    )
    qty = D(quantity)
    return TradePlan(signal, qty, qty * D("100"), qty * D("11"), qty * D("20"),
                     5, "RC4ORDER", fee_reserve_usdt=qty * D("0.4"),
                     slippage_reserve_usdt=qty * D("0.4"),
                     funding_reserve_usdt=qty * D("0.2"))


@pytest.mark.parametrize("side,fill,status", [
    ("LONG", "100", "WITHIN_RESERVED_RISK"),
    ("LONG", "99.5", "WITHIN_RESERVED_RISK"),
    ("LONG", "102", "ACTUAL_FILL_RISK_EXCEEDS_RESERVATION"),
    ("SHORT", "98", "ACTUAL_FILL_RISK_EXCEEDS_RESERVATION"),
    ("SHORT", "101", "WITHIN_RESERVED_RISK"),
    ("LONG", "88", "FILL_PRICE_INVALIDATES_STOP_OR_TARGET"),
    ("SHORT", "65", "FILL_PRICE_INVALIDATES_STOP_OR_TARGET"),
    ("LONG", "0", "FILL_PRICE_UNVERIFIED"),
    ("LONG", "nan", "FILL_PRICE_UNVERIFIED"),
    ("LONG", None, "FILL_PRICE_UNVERIFIED"),
])
def test_postfill_risk_price_and_geometry(side, fill, status):
    plan = _plan(side=side)
    audit = assess_post_fill_risk(plan, executed_quantity=D("1"), avg_fill_price=fill)
    assert audit.status == status
    assert audit.safe_for_new_entries is (status == "WITHIN_RESERVED_RISK")
    assert audit.allocated_risk_usdt == D("11")


def test_partial_fill_risk_must_be_prorated_not_compared_to_full_reservation():
    audit = assess_post_fill_risk(_plan(), executed_quantity=D("0.1"), avg_fill_price="102")
    assert audit.status == "ACTUAL_FILL_RISK_EXCEEDS_RESERVATION"
    assert audit.allocated_risk_usdt == D("1.1")
    assert audit.actual_risk_usdt == D("1.3")


@pytest.mark.parametrize("invalid", [D("0"), D("-1"), D("1.01"), D("NaN")])
def test_invalid_fill_quantity_fail_closed(invalid):
    with pytest.raises(ValueError, match="POST_FILL_QUANTITY_INVALID"):
        assess_post_fill_risk(_plan(), executed_quantity=invalid, avg_fill_price="100")


def _book(now=1234567, bids=None, asks=None):
    return {
        "symbol": "BTCUSDT", "T": now,
        "bids": bids or [["99.99", "1"], ["99.98", "4"]],
        "asks": asks or [["100.01", "0.5"], ["100.02", "2"]],
    }


def test_market_quote_estimates_executable_vwap():
    v = check_entry_quote(_plan(), _book(), now_exchange_ms=1234568)
    assert v.allowed
    assert v.reason == "MARKET_QUOTE_ACCEPTED"
    assert v.estimated_fill_price == D("100.015")


def test_market_quote_blocks_insufficient_depth():
    v = check_entry_quote(_plan(quantity="5"), _book(), now_exchange_ms=1234567)
    assert not v.allowed and v.reason == "QUOTE_INSUFFICIENT_TOP_BOOK_DEPTH"


def test_market_quote_blocks_stale_timestamp():
    v = check_entry_quote(_plan(), _book(), now_exchange_ms=1239999)
    assert v.reason == "QUOTE_STALE_OR_FUTURE"


def test_market_quote_blocks_spread_and_adverse_slippage():
    wider = _book(bids=[["99", "5"]], asks=[["101", "5"]])
    assert check_entry_quote(_plan(), wider, now_exchange_ms=1234567).reason == "QUOTE_SPREAD_TOO_WIDE"
    guard = EntryQuoteGuardConfig(max_spread_bps=D("1000"), max_market_slippage_bps=D("10"))
    v = check_entry_quote(_plan(), wider, now_exchange_ms=1234567, config=guard)
    assert v.reason == "QUOTE_ESTIMATED_SLIPPAGE_TOO_HIGH"


def test_market_quote_short_consumes_bid_depth():
    v = check_entry_quote(_plan(side="SHORT"), _book(), now_exchange_ms=1234567)
    assert v.allowed
    assert v.estimated_fill_price == D("99.99")


def test_limit_order_does_not_require_current_quote_at_retracement_entry():
    plan = _plan(entry_type="LIMIT")
    far_book = _book(bids=[["150", "2"]], asks=[["150.01", "2"]])
    assert check_entry_quote(plan, far_book, now_exchange_ms=1234567).allowed


def _ioc_plan(*, side="LONG"):
    plan = _plan(side=side, entry_type="LIMIT_IOC")
    limit = D("100.02") if side == "LONG" else D("99.99")
    signal = replace(plan.signal, entry_price=limit, strategy_id="SWEEP_RECLAIM_V2")
    return replace(plan, signal=signal, notional_usdt=plan.quantity * limit,
                   risk_usdt=abs(limit - signal.stop_loss) + D("1"))


@pytest.mark.parametrize("side,expected", [("LONG", "100.015"), ("SHORT", "99.99")])
def test_ioc_quote_checks_all_quantity_at_or_inside_the_bound(side, expected):
    plan = _ioc_plan(side=side)
    verdict = check_entry_quote(plan, _book(), now_exchange_ms=1234567)
    assert verdict.allowed and verdict.reason == "IOC_QUOTE_ACCEPTED"
    assert verdict.estimated_fill_price == D(expected)


def test_ioc_quote_rejects_a_passive_or_unbounded_entry():
    plan = _ioc_plan()
    passive = _book(asks=[["100.03", "2"]])
    assert check_entry_quote(plan, passive, now_exchange_ms=1234567).reason == "IOC_LIMIT_NOT_MARKETABLE"
    thin = _book(asks=[["100.01", "0.5"], ["100.03", "5"]])
    verdict = check_entry_quote(plan, thin, now_exchange_ms=1234567)
    assert not verdict.allowed and verdict.reason == "IOC_INSUFFICIENT_DEPTH_WITHIN_LIMIT"
    drifted = _book(bids=[["99.70", "2"]], asks=[["99.71", "2"]])
    assert check_entry_quote(plan, drifted, now_exchange_ms=1234567).reason == "IOC_BOUND_TOO_FAR_FROM_EXECUTABLE_QUOTE"


def test_unsafe_crossed_or_corrupt_quote_blocks():
    assert not check_entry_quote(_plan(), _book(bids=[["101", "2"]]),
                                 now_exchange_ms=1234567).allowed
    assert check_entry_quote(_plan(), {**_book(), "symbol": "ETHUSDT"},
                             now_exchange_ms=1234567).reason == "QUOTE_SYMBOL_MISMATCH"
    assert check_entry_quote(_plan(), {**_book(), "T": None},
                             now_exchange_ms=1234567).reason == "QUOTE_TIMESTAMP_MISSING"


def test_transient_halt_cas_does_not_clear_risk_or_operator_halt(tmp_path):
    ledger = ExecutionLedger(tmp_path / "test.sqlite")
    ledger.set_entries_halted(True, "TRADE_HISTORY_BACKFILL_IN_PROGRESS")
    ledger.set_entries_halted(True, "POST_FILL_RISK:BTCUSDT:ACTUAL_FILL_RISK_EXCEEDS_RESERVATION")
    assert not ledger.clear_entries_halt_if_reason("TRADE_HISTORY_BACKFILL_IN_PROGRESS")
    assert ledger.entries_halted()[0]
    ledger.set_entries_halted(True, "TRADE_HISTORY_BACKFILL_IN_PROGRESS")
    assert ledger.clear_entries_halt_if_reason("TRADE_HISTORY_BACKFILL_IN_PROGRESS")
    assert not ledger.entries_halted()[0]


def test_resume_refuses_postfill_risk_with_open_managed_position(tmp_path):
    ledger = ExecutionLedger(tmp_path / "test.sqlite")
    ledger.claim_intent(signal_id="held", symbol="BTCUSDT", side="LONG",
                        client_order_id="RC4HELD", payload={})
    ledger.record_position(symbol="BTCUSDT", position_side="BOTH", signal_id="held",
                           quantity="1", entry_price="100", stop_loss="90", take_profit="130")
    ledger.set_entries_halted(True, "POST_FILL_RISK:BTCUSDT:ACTUAL_FILL_RISK_EXCEEDS_RESERVATION")
    service = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    with pytest.raises(RuntimeError, match="remains open"):
        service.resume_new_entries(explicit_operator_confirmation=True)
    assert ledger.entries_halted()[0]


def test_live_requires_quote_guard_in_addition_to_two_existing_confirmations():
    with pytest.raises(ValueError, match="quote guard"):
        ExecutionConfig(mode=ExecutionMode.LIVE, enable_live_trading=True,
                        live_confirmation="I_ACCEPT_REAL_MONEY_RISK")
    cfg = ExecutionConfig(mode=ExecutionMode.LIVE, enable_live_trading=True,
                          live_confirmation="I_ACCEPT_REAL_MONEY_RISK",
                          enforce_entry_quote_guard=True)
    assert cfg.enforce_entry_quote_guard


def test_private_depth_query_uses_own_environment_without_signed_request():
    seen = []
    def handler(request):
        seen.append(request)
        return httpx.Response(200, json={"T": 1234567, "bids": [["99.9", "1"]],
                                         "asks": [["100.1", "1"]]})
    http = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinancePrivateRestClient("fake-key", "fake-secret", environment="TESTNET",
                                      http_client=http, wall_clock_ms=lambda: 1234567)
    try:
        data = client.get_order_book_top("BTCUSDT")
    finally:
        http.close()
    assert data["symbol"] == "BTCUSDT"
    assert len(seen) == 1 and seen[0].method == "GET"
    assert str(seen[0].url).startswith("https://demo-fapi.binance.com/fapi/v1/depth?symbol=BTCUSDT&limit=5")
    assert "signature" not in str(seen[0].url)


class _QuoteExecutionClient:
    environment = "TESTNET"

    def __init__(self, *, avg_fill_price="100", book=None, fail_quote=False):
        self.avg_fill_price = avg_fill_price
        self.book = book if book is not None else _book(now=1234567)
        self.fail_quote = fail_quote
        self.posts = 0
        self.get_book_calls = 0
        self.protections = 0

    def sync_server_time(self):
        return 0

    def get_position_mode(self):
        return {"dualSidePosition": False}

    def get_order_book_top(self, symbol):
        self.get_book_calls += 1
        if self.fail_quote:
            raise TimeoutError("fixture quote read timeout")
        return self.book

    def exchange_now_ms(self):
        return 1234568

    def new_order(self, **params):
        self.posts += 1
        return {"symbol": params["symbol"], "orderId": self.posts,
                "status": "FILLED", "executedQty": str(params["quantity"]),
                "avgPrice": self.avg_fill_price}


def _quote_service(tmp_path, monkeypatch, client, *, plan=None, enforce_quote=True, stub_protection=True):
    ledger = ExecutionLedger(tmp_path / "execution.sqlite")
    now = time.time_ns() // 1_000_000
    ledger.set_user_stream_state("CONNECTED", connected_at_ms=now, updated_at_ms=now)
    ledger.set_reconciliation_state(True, status="READY", captured_at_ms=now,
                                    stream_event_watermark_ms=0)
    plan = plan or _plan()
    reserve = ledger.reserve_portfolio_risk(
        signal_id=plan.signal.signal_id, symbol=plan.signal.symbol,
        risk_usdt=plan.risk_usdt, notional_usdt=plan.notional_usdt,
        equity_usdt=D("1000"), exchange_open_risk_usdt=D("0"),
        exchange_active_position_count=0, max_positions=2,
        max_portfolio_open_risk_pct=D("3"),
        exchange_symbol_notional_usdt=D("0"), max_symbol_notional_usdt=D("1000"),
    )
    assert reserve.accepted
    service = ExecutionService(ledger, config=ExecutionConfig(
        mode=ExecutionMode.TESTNET, enable_testnet_orders=True,
        enable_testnet_stage_c=True, enforce_entry_quote_guard=enforce_quote,
    ), client=client)
    monkeypatch.setattr(service, "_prepare_symbol_settings", lambda **kwargs: None)
    def protect(*args, **kwargs):
        client.protections += 1
        return ({"algoStatus": "NEW"}, {"algoStatus": "NEW"})
    if stub_protection:
        monkeypatch.setattr(service, "_ensure_protection", protect)
    return service, plan, ledger


def test_entry_quote_gate_blocks_before_exchange_post(tmp_path, monkeypatch):
    client = _QuoteExecutionClient(book=_book(bids=[["99", "5"]], asks=[["101", "5"]]))
    service, plan, ledger = _quote_service(tmp_path, monkeypatch, client)
    result = service.submit(plan)
    assert result.status == "ENTRY_BLOCKED_EXECUTABLE_QUOTE"
    assert "SPREAD_TOO_WIDE" in result.detail
    assert client.get_book_calls == 1 and client.posts == 0 and client.protections == 0
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "RELEASED"


def test_entry_quote_unavailable_never_posts_order(tmp_path, monkeypatch):
    client = _QuoteExecutionClient(fail_quote=True)
    service, plan, ledger = _quote_service(tmp_path, monkeypatch, client)
    result = service.submit(plan)
    assert result.status == "ENTRY_BLOCKED_EXECUTABLE_QUOTE"
    assert "QUOTE_GUARD_READ_FAILED" in result.detail
    assert client.posts == 0
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "RELEASED"


@pytest.mark.parametrize("fill,halt", [("100", False), ("102", True), ("0", True)])
def test_protected_fill_risk_halt_never_cancels_protection(tmp_path, monkeypatch, fill, halt):
    client = _QuoteExecutionClient(avg_fill_price=fill)
    service, plan, ledger = _quote_service(tmp_path, monkeypatch, client)
    result = service.submit(plan)
    assert result.status == "PROTECTED"
    assert client.posts == 1 and client.protections == 1
    assert ledger.entries_halted()[0] is halt
    assert len(ledger.list_managed_positions(status="OPEN")) == 1
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "ACTIVE"


def test_ioc_quote_is_mandatory_even_in_testnet(tmp_path, monkeypatch):
    client = _QuoteExecutionClient(book=_book(asks=[["100.03", "2"]]))
    service, plan, _ = _quote_service(tmp_path, monkeypatch, client, plan=_ioc_plan(), enforce_quote=False)
    result = service.submit(plan)
    assert result.status == "ENTRY_BLOCKED_EXECUTABLE_QUOTE"
    assert result.detail == "IOC_LIMIT_NOT_MARKETABLE"
    assert client.get_book_calls == 1 and client.posts == 0


@pytest.mark.parametrize("lost_ack", [False, True])
def test_ioc_terminal_partial_fill_is_protected_without_cancelling_or_retrying(tmp_path, monkeypatch, lost_ack):
    client = _QuoteExecutionClient()
    service, plan, ledger = _quote_service(
        tmp_path, monkeypatch, client, plan=_ioc_plan(), stub_protection=False,
    )
    response = {
        "symbol": "BTCUSDT", "status": "EXPIRED", "orderId": 42,
        "type": "LIMIT", "timeInForce": "IOC", "clientOrderId": plan.client_order_id,
        "executedQty": "0.5", "avgPrice": "100.01",
    }
    protection_posts = {}

    def new_order(**params):
        client.posts += 1
        assert ledger.get_intent(plan.signal.signal_id)["status"] == "SUBMISSION_UNKNOWN"
        assert params["type"] == "LIMIT" and params["timeInForce"] == "IOC"
        assert params["price"] == D("100.02") and params["newOrderRespType"] == "RESULT"
        if lost_ack:
            raise TimeoutError("fixture lost response")
        return response

    def get_order(symbol, *, client_order_id):
        assert (symbol, client_order_id) == ("BTCUSDT", plan.client_order_id)
        return response

    def get_algo_order(*, client_algo_id):
        if client_algo_id not in protection_posts:
            raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")
        return protection_posts[client_algo_id]

    def new_algo_order(**params):
        client_id = params["clientAlgoId"]
        assert client_id not in protection_posts
        protection_posts[client_id] = {**params, "algoStatus": "NEW"}
        return {"algoStatus": "NEW"}

    monkeypatch.setattr(client, "new_order", new_order)
    monkeypatch.setattr(client, "get_order", get_order, raising=False)
    monkeypatch.setattr(client, "get_algo_order", get_algo_order, raising=False)
    monkeypatch.setattr(client, "new_algo_order", new_algo_order, raising=False)
    if lost_ack:
        with pytest.raises(TimeoutError):
            service.submit(plan)
        assert service.reconcile_pending_entries()[0].status == "PROTECTED"
    else:
        assert service.submit(plan).status == "PROTECTED"
    assert {row["type"]: row["triggerPrice"] for row in protection_posts.values()} == {
        "STOP_MARKET": plan.signal.stop_loss, "TAKE_PROFIT_MARKET": plan.signal.take_profit,
    }
    assert all(
        row["quantity"] == D("0.5") and row["reduceOnly"] is True and row["side"] == "SELL"
        for row in protection_posts.values()
    )
    assert client.posts == 1
    assert ledger.get_intent(plan.signal.signal_id)["status"] == "PROTECTED"
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "ACTIVE"


def test_ioc_zero_fill_expiry_releases_reserved_risk(tmp_path, monkeypatch):
    client = _QuoteExecutionClient()
    service, plan, ledger = _quote_service(tmp_path, monkeypatch, client, plan=_ioc_plan())
    monkeypatch.setattr(client, "new_order", lambda **params: {
        "symbol": "BTCUSDT", "clientOrderId": params["newClientOrderId"],
        "status": "EXPIRED_IN_MATCH", "executedQty": "0",
    })
    assert service.submit(plan).status == "ENTRY_EXPIRED_IN_MATCH"
    assert not ledger.list_managed_positions(status="OPEN")
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "RELEASED"


@pytest.mark.parametrize("lost_close_ack", [False, True])
def test_ioc_definitive_initial_stop_rejection_closes_exact_owned_lot_once(tmp_path, monkeypatch, lost_close_ack):
    client = _QuoteExecutionClient()
    service, plan, ledger = _quote_service(
        tmp_path, monkeypatch, client, plan=_ioc_plan(), stub_protection=False,
    )
    entry = {
        "symbol": "BTCUSDT", "clientOrderId": plan.client_order_id, "type": "LIMIT",
        "timeInForce": "IOC", "status": "EXPIRED", "executedQty": "0.5", "avgPrice": "100.01",
    }
    position_amount = D("0.5")
    close_by_id = {}
    algo_posts = []

    def new_order(**params):
        nonlocal position_amount
        if params["type"] == "LIMIT":
            ledger.set_reconciliation_state(False, status="ACCOUNT_EVENT_PENDING_RECONCILIATION",
                                            captured_at_ms=time.time_ns() // 1_000_000,
                                            stream_event_watermark_ms=0)
            return entry
        assert params["type"] == "MARKET" and params["side"] == "SELL"
        assert params["quantity"] == position_amount == D("0.5") and params["reduceOnly"] is True
        assert params["positionSide"] == "BOTH" and not close_by_id
        action = ledger.list_position_management_actions(signal_id=plan.signal.signal_id)[0]
        assert action["status"] == "SUBMITTING" and action["action_kind"] == "EMERGENCY_CLOSE"
        close_id = params["newClientOrderId"]
        close_by_id[close_id] = {**params, "clientOrderId": close_id, "status": "FILLED", "executedQty": "0.5"}
        position_amount = D("0")
        if lost_close_ack:
            raise BinancePrivateTransportError("fixture lost close acknowledgement")
        return close_by_id[close_id]

    def get_order(symbol, *, client_order_id):
        assert symbol == "BTCUSDT"
        return entry if client_order_id == plan.client_order_id else close_by_id[client_order_id]

    def get_algo_order(*, client_algo_id):
        raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")

    def reject_stop(**params):
        algo_posts.append(params)
        assert params["type"] == "STOP_MARKET"
        raise BinancePrivateApiError(400, -2021, "Order would immediately trigger", "/fapi/v1/algoOrder")

    fixture = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"
    monkeypatch.setattr(client, "new_order", new_order)
    monkeypatch.setattr(client, "get_order", get_order, raising=False)
    monkeypatch.setattr(client, "get_algo_order", get_algo_order, raising=False)
    monkeypatch.setattr(client, "new_algo_order", reject_stop, raising=False)
    monkeypatch.setattr(client, "get_exchange_info", lambda: json.loads(fixture.read_text()), raising=False)
    monkeypatch.setattr(client, "get_open_orders", lambda symbol: [], raising=False)
    monkeypatch.setattr(client, "get_open_algo_orders", lambda symbol: [], raising=False)
    monkeypatch.setattr(client, "get_position_risk", lambda symbol: [{
        "symbol": symbol, "positionSide": "BOTH", "positionAmt": str(position_amount),
    }], raising=False)

    if lost_close_ack:
        with pytest.raises(BinancePrivateTransportError):
            service.submit(plan)
        assert ledger.get_intent(plan.signal.signal_id)["status"] == "PROTECTION_INCOMPLETE"
        assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "ACTIVE"
        assert service.reconcile_pending_entries()[0].status == "IOC_EMERGENCY_CLOSED"
    else:
        assert service.submit(plan).status == "IOC_EMERGENCY_CLOSED"
    assert not service.reconcile_pending_entries()
    assert len(algo_posts) == len(close_by_id) == 1
    assert ledger.get_intent(plan.signal.signal_id)["status"] == "CLOSED"
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "RELEASED"
    assert ledger.entries_halted()[0]


def test_ioc_unknown_initial_stop_is_not_reposted_or_closed_blindly(tmp_path, monkeypatch):
    client = _QuoteExecutionClient()
    service, plan, ledger = _quote_service(
        tmp_path, monkeypatch, client, plan=_ioc_plan(), stub_protection=False,
    )
    entry = {
        "symbol": "BTCUSDT", "clientOrderId": plan.client_order_id,
        "status": "EXPIRED", "executedQty": "0.5", "avgPrice": "100.01",
    }
    algo_posts = []

    def new_order(**params):
        assert params["type"] == "LIMIT"
        return entry

    def get_algo_order(*, client_algo_id):
        raise BinancePrivateApiError(400, -2013, "Order does not exist", "/fapi/v1/algoOrder")

    def new_algo_order(**params):
        algo_posts.append(params)
        raise BinancePrivateTransportError("fixture lost stop acknowledgement")

    monkeypatch.setattr(client, "new_order", new_order)
    monkeypatch.setattr(client, "get_order", lambda *args, **kwargs: entry, raising=False)
    monkeypatch.setattr(client, "get_algo_order", get_algo_order, raising=False)
    monkeypatch.setattr(client, "new_algo_order", new_algo_order, raising=False)
    with pytest.raises(BinancePrivateTransportError):
        service.submit(plan)
    with pytest.raises(RuntimeError, match="PROTECTION_ORDER_MISSING_REQUIRES_POSITION_RECONCILIATION"):
        service.reconcile_pending_entries()
    assert len(algo_posts) == 1
    assert ledger.get_risk_reservation(plan.signal.signal_id)["status"] == "ACTIVE"
    assert ledger.entries_halted()[0]
