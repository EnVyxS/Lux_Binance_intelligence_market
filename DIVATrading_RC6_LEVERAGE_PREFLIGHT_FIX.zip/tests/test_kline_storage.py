from __future__ import annotations

import sqlite3
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.core.database import Database, MIGRATIONS
from divatrading.market_data.klines import Kline
from divatrading.market_data.storage import KlineRepository, KlineStorageError


SOURCE = "https://fapi.binance.com/fapi/v1/klines"


def make_kline(
    *,
    symbol: str = "BTCUSDT",
    interval: str = "1m",
    open_time_ms: int = 0,
    close: str = "100.50",
    high: str = "103.00",
) -> Kline:
    interval_ms = {"1m": 60_000, "5m": 300_000, "15m": 900_000}[interval]
    row = [
        open_time_ms,
        "100.000000000000000001",
        high,
        "99.000000000000000001",
        close,
        "12.250000000000000001",
        open_time_ms + interval_ms - 1,
        "1234.500000000000000001",
        42,
        "5.250000000000000001",
        "530.000000000000000001",
        "0",
    ]
    return Kline.from_binance_row(
        row,
        symbol=symbol,
        interval=interval,
        source_endpoint=SOURCE,
    )


def make_v2_database(path: Path) -> Database:
    """Create a real schema-v2 database using the released migration definitions."""
    connection = sqlite3.connect(path)
    connection.execute(
        """CREATE TABLE schema_migrations (
            version INTEGER PRIMARY KEY, applied_at_utc TEXT NOT NULL
        )"""
    )
    for version, statements in MIGRATIONS:
        if version > 2:
            break
        for statement in statements:
            connection.execute(statement)
        connection.execute(
            "INSERT INTO schema_migrations(version, applied_at_utc) VALUES (?, ?)",
            (version, f"2026-11-09T00:00:0{version}Z"),
        )
    connection.execute(
        "INSERT INTO app_settings(setting_key, value_json, updated_at_utc) VALUES (?, ?, ?)",
        ("keep", '{"version":2}', "2026-11-09T00:00:00Z"),
    )
    connection.execute(
        """INSERT INTO exchange_metadata_snapshots(
            source_endpoint, fetched_at_utc, saved_at_utc, server_time_ms,
            symbol_count, payload_sha256, payload_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            "fixture",
            "2026-11-09T00:00:00Z",
            "2026-11-09T00:00:00Z",
            123,
            1,
            "unused-digest-for-migration-test",
            '{"symbols":[]}',
        ),
    )
    connection.commit()
    connection.close()
    return Database(path)


def test_migration_from_schema_v2_is_forward_only_and_preserves_data(tmp_path: Path) -> None:
    db = make_v2_database(tmp_path / "legacy-v2.db")

    assert db.schema_version() == 2
    assert db.initialize() == 6
    assert db.initialize() == 6
    assert db.get_setting("keep") == {"version": 2}

    with db.connection() as connection:
        candle_table = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='market_klines'"
        ).fetchone()
        snapshot_count = connection.execute(
            "SELECT COUNT(*) FROM exchange_metadata_snapshots"
        ).fetchone()[0]
    assert candle_table is not None
    assert snapshot_count == 1


def test_upsert_is_idempotent_and_updates_same_identity(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    original = make_kline()
    revised = make_kline(close="100.75", high="104.00")

    assert repository.upsert_many([original], fetched_at_utc="2026-11-10T00:00:00Z") == 1
    first_record = repository.read(symbol="BTCUSDT", interval="1m")[0]
    assert repository.upsert_many([original], fetched_at_utc="2026-11-10T00:01:00Z") == 1
    duplicate_record = repository.read(symbol="BTCUSDT", interval="1m")[0]
    assert repository.upsert_many([revised], fetched_at_utc="2026-11-10T00:02:00Z") == 1
    updated_record = repository.read(symbol="BTCUSDT", interval="1m")[0]

    with db.connection() as connection:
        count = connection.execute("SELECT COUNT(*) FROM market_klines").fetchone()[0]
    assert count == 1
    assert duplicate_record.first_seen_at_utc == first_record.first_seen_at_utc
    assert duplicate_record.last_fetched_at_utc == "2026-11-10T00:01:00.000Z"
    assert updated_record.kline.close == Decimal("100.75")
    assert updated_record.last_fetched_at_utc == "2026-11-10T00:02:00.000Z"


def test_primary_key_isolated_by_exchange_symbol_and_interval(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    rows = [
        make_kline(symbol="BTCUSDT", interval="1m", open_time_ms=0),
        make_kline(symbol="ETHUSDT", interval="1m", open_time_ms=0),
        make_kline(symbol="BTCUSDT", interval="5m", open_time_ms=0),
    ]
    assert repository.upsert_many(rows) == 3
    assert repository.exists(symbol="BTCUSDT", interval="1m", open_time_ms=0)
    assert repository.exists(symbol="ETHUSDT", interval="1m", open_time_ms=0)
    assert repository.exists(symbol="BTCUSDT", interval="5m", open_time_ms=0)
    assert len(repository.read(symbol="BTCUSDT", interval="1m")) == 1
    assert len(repository.read(symbol="BTCUSDT", interval="5m")) == 1


def test_decimal_values_round_trip_without_float_conversion(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    source = make_kline()
    repository.upsert_many([source], fetched_at_utc="2026-11-10T00:00:00Z")

    stored = repository.read(symbol="BTCUSDT", interval="1m")[0].kline
    assert stored.open == source.open
    assert str(stored.open) == "100.000000000000000001"
    assert stored.volume == source.volume
    assert str(stored.quote_asset_volume) == "1234.500000000000000001"
    assert str(stored.taker_buy_quote_volume) == "530.000000000000000001"

    with db.connection() as connection:
        raw_open = connection.execute("SELECT open FROM market_klines").fetchone()[0]
    assert raw_open == "100.000000000000000001"


def test_bounded_reads_are_ascending_and_inclusive(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    repository.upsert_many(
        [make_kline(open_time_ms=value) for value in (120_000, 0, 60_000, 180_000)]
    )

    result = repository.read(
        symbol="BTCUSDT",
        interval="1m",
        start_open_time_ms=60_000,
        end_open_time_ms=180_000,
        limit=2,
    )
    assert [item.kline.open_time_ms for item in result] == [60_000, 120_000]


def test_existing_open_times_returns_only_matching_candles(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    repository.upsert_many(
        [make_kline(open_time_ms=value) for value in (0, 60_000, 120_000)]
    )

    assert repository.existing_open_times(
        symbol="BTCUSDT",
        interval="1m",
        open_times_ms=[0, 60_000, 180_000, 60_000],
    ) == {0, 60_000}
    assert repository.existing_open_times(
        symbol="BTCUSDT", interval="1m", open_times_ms=[]
    ) == set()


def test_empty_upsert_is_noop_and_utc_metadata_is_preserved(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    assert repository.upsert_many([]) == 0
    repository.upsert_many([make_kline()], fetched_at_utc="2026-11-10T07:00:00+00:00")

    stored = repository.read(symbol="BTCUSDT", interval="1m")[0]
    assert stored.first_seen_at_utc.endswith("Z")
    assert stored.last_fetched_at_utc == "2026-11-10T07:00:00.000Z"
    assert stored.last_saved_at_utc.endswith("Z")


@pytest.mark.parametrize(
    "kwargs",
    [
        {"limit": 0},
        {"limit": 5_001},
        {"start_open_time_ms": 60_000, "end_open_time_ms": 0},
    ],
)
def test_invalid_read_bounds_and_limits_are_rejected(tmp_path: Path, kwargs: dict) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    with pytest.raises(KlineStorageError):
        repository.read(symbol="BTCUSDT", interval="1m", **kwargs)


def test_non_utc_fetch_timestamp_and_wrong_exchange_are_rejected(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    with pytest.raises(KlineStorageError, match="UTC"):
        repository.upsert_many([make_kline()], fetched_at_utc="2026-11-10T07:00:00+07:00")

    wrong_exchange = make_kline()
    wrong_exchange = Kline(
        exchange="OTHER",
        symbol=wrong_exchange.symbol,
        interval=wrong_exchange.interval,
        open_time_ms=wrong_exchange.open_time_ms,
        open=wrong_exchange.open,
        high=wrong_exchange.high,
        low=wrong_exchange.low,
        close=wrong_exchange.close,
        volume=wrong_exchange.volume,
        close_time_ms=wrong_exchange.close_time_ms,
        quote_asset_volume=wrong_exchange.quote_asset_volume,
        trade_count=wrong_exchange.trade_count,
        taker_buy_base_volume=wrong_exchange.taker_buy_base_volume,
        taker_buy_quote_volume=wrong_exchange.taker_buy_quote_volume,
        ignore_value=wrong_exchange.ignore_value,
        source_endpoint=wrong_exchange.source_endpoint,
    )
    with pytest.raises(KlineStorageError, match="BINANCE_UM"):
        repository.upsert_many([wrong_exchange])


def test_read_tail_returns_latest_bounded_rows_in_ascending_order(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    repository.upsert_many([make_kline(open_time_ms=value) for value in (0, 60_000, 120_000, 180_000)])

    rows = repository.read_tail(symbol="BTCUSDT", interval="1m", limit=2)
    assert [item.kline.open_time_ms for item in rows] == [120_000, 180_000]

    bounded = repository.read_tail(
        symbol="BTCUSDT", interval="1m", limit=10, end_open_time_ms=120_000
    )
    assert [item.kline.open_time_ms for item in bounded] == [0, 60_000, 120_000]


def test_read_tail_rejects_invalid_limit_and_unaligned_bound(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    repository = KlineRepository(db)
    with pytest.raises(KlineStorageError):
        repository.read_tail(symbol="BTCUSDT", interval="1m", limit=0)
    with pytest.raises(KlineStorageError):
        repository.read_tail(symbol="BTCUSDT", interval="1m", end_open_time_ms=1)
