from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from divatrading.market_data.klines import INTERVAL_MILLISECONDS
from divatrading.replay import (
    HistoricalReplayRunner,
    ReplayConfig,
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayMetadataSnapshot,
    WarmupConvergenceError,
    analyze_warmup_convergence,
    write_warmup_convergence_report,
)

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "docs" / "schemas" / "stage6b_warmup_convergence_report.schema.json"
EXCHANGE_FIXTURE = ROOT / "tests" / "fixtures" / "exchange_info_valid.json"


def _metadata() -> ReplayMetadataSnapshot:
    payload = json.loads(EXCHANGE_FIXTURE.read_text(encoding="utf-8"))
    symbol = next(item for item in payload["symbols"] if item["symbol"] == "BTCUSDT")
    return ReplayMetadataSnapshot.from_symbol_payload(
        symbol,
        quality="HISTORICAL_EFFECTIVE",
        source_url="https://fapi.binance.com/fapi/v1/exchangeInfo",
        captured_at_ms=2_000_000,
        effective_from_ms=0,
        effective_to_ms=2_000_000,
    )


def _write_source(root: Path, interval: str, start: int, end: int) -> ReplayKlineFile:
    step = INTERVAL_MILLISECONDS[interval]
    path = root / f"BTCUSDT-{interval}.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        for opened in range(start, end, step):
            absolute_index = opened // step
            op = 100.0 + (absolute_index % 5) * 0.1
            writer.writerow([
                opened, f"{op:.1f}", f"{op + 0.5:.1f}", f"{op - 0.5:.1f}",
                f"{op + (0.1 if absolute_index % 2 else -0.1):.1f}", "10",
                opened + step - 1, "1000", 10, "5", "500", "0",
            ])
    return ReplayKlineFile.inspect(
        root, path.name, interval, symbol="BTCUSDT", source_url="fixture://native-kline"
    )


def _build_trials(tmp_path: Path, starts=(0, 300_000, 600_000)) -> Path:
    end = 1_200_000
    trials = []
    for index, start in enumerate(starts):
        root = tmp_path / f"trial_{index}"
        root.mkdir()
        files = (
            _write_source(root, "1m", start, end),
            _write_source(root, "5m", start, end),
        )
        manifest = ReplayDatasetManifest(
            symbol="BTCUSDT",
            start_open_time_ms=start,
            end_open_time_ms=end,
            files=files,
            metadata=_metadata(),
        )
        manifest_path = manifest.write(root / "manifest.json")
        ledger = root / "replay.jsonl"
        HistoricalReplayRunner(
            manifest,
            dataset_root=root,
            config=ReplayConfig(max_history_candles=128, include_m15=False),
        ).run_to_file(ledger)
        trials.append({
            "trial_id": ("short", "medium", "long")[index],
            "manifest": str(manifest_path.relative_to(tmp_path)),
            "ledger": str(ledger.relative_to(tmp_path)),
        })
    plan = {
        "plan_schema_version": 1,
        "evaluation_window": {"start_ms": 600_000, "end_ms_exclusive": end},
        "trials": trials,
    }
    plan_path = tmp_path / "convergence_plan.json"
    plan_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return plan_path


def test_warmup_convergence_three_trials_freezes_and_compares_exact_evaluation_slice(tmp_path):
    plan_path = _build_trials(tmp_path)
    ledger_paths = [tmp_path / item / "replay.jsonl" for item in ("trial_0", "trial_1", "trial_2")]
    original_hashes = [hashlib.sha256(path.read_bytes()).hexdigest() for path in ledger_paths]

    report = analyze_warmup_convergence(plan_path)
    repeated = analyze_warmup_convergence(plan_path)
    assert repeated["report_sha256"] == report["report_sha256"]
    assert repeated == report

    assert report["comparison_mode"] == "THREE_PLUS_TRIAL_COMPARISON"
    assert len(report["trials"]) == 3
    assert len(report["comparisons"]) == 3 * 4 * 2
    assert len({item["evaluation_slice_sha256"] for item in report["trials"]}) == 1
    assert report["trials"][0]["pre_roll_bars"]["1m"] == 10
    assert report["trials"][1]["pre_roll_bars"]["1m"] == 5
    assert report["trials"][2]["pre_roll_bars"]["1m"] == 0
    assert report["trials"][2]["warmup_readiness_summary"]
    assert all(item["divergence_count"] >= 0 for item in report["comparisons"])
    assert report["comparison_payload_policy"].startswith("EXCLUDE_REPLAY_RELATIVE_")
    # Relative bar indices differ by pre-roll construction and must not create
    # false state divergence when all timestamp-anchored structure evidence agrees.
    short_medium_m1 = next(
        item for item in report["comparisons"]
        if item["left_trial_id"] == "short"
        and item["right_trial_id"] == "medium"
        and item["stage"] == "STAGE_2_MARKET_STRUCTURE"
        and item["timeframe"] == "1m"
    )
    assert short_medium_m1["record_counts"]["exact_payload_matches"] == 10
    assert short_medium_m1["divergence_count"] == 0
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(report)
    write_warmup_convergence_report(report, tmp_path / "report.json")
    assert [hashlib.sha256(path.read_bytes()).hexdigest() for path in ledger_paths] == original_hashes



def test_ob_lifecycle_trace_stable_key_uses_transition_identity_not_parent_event():
    from divatrading.replay.convergence import _stable_evidence_key

    base = {
        "candidate_id": "candidate-1",
        "event_id": "parent-structure-event",
        "observed_time_ms": 1_700_000_060_000,
    }
    created = _stable_evidence_key(
        "OB_LIFECYCLE_TRACE",
        {**base, "transition": "CANDIDATE_CREATED", "to_status": "CANDIDATE"},
        1_700_000_060_000,
    )
    activated = _stable_evidence_key(
        "OB_LIFECYCLE_TRACE",
        {**base, "transition": "ACTIVATED", "to_status": "ACTIVE_FRESH"},
        1_700_000_060_000,
    )
    assert created == "lifecycle:candidate-1|CANDIDATE_CREATED|1700000060000|CANDIDATE"
    assert activated == "lifecycle:candidate-1|ACTIVATED|1700000060000|ACTIVE_FRESH"
    assert created != activated
    assert created == _stable_evidence_key(
        "OB_LIFECYCLE_TRACE",
        {**base, "transition": "CANDIDATE_CREATED", "to_status": "CANDIDATE"},
        1_700_000_060_000,
    )


def test_ob_lifecycle_trace_requires_transition_fields_for_unique_identity():
    from divatrading.replay.convergence import _stable_evidence_key

    assert _stable_evidence_key(
        "OB_LIFECYCLE_TRACE", {"event_id": "shared-parent-event"}, 1_700_000_060_000
    ) is None

def test_two_trial_mode_is_explicitly_limited(tmp_path):
    plan_path = _build_trials(tmp_path, starts=(0, 600_000))
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    plan["trials"] = plan["trials"][:2]
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    report = analyze_warmup_convergence(plan_path)
    assert report["comparison_mode"] == "LIMITED_TWO_TRIAL_COMPARISON"


def test_rejects_different_evaluation_slice_fingerprint(tmp_path):
    plan_path = _build_trials(tmp_path)
    # Mutate only one shared evaluation M1 candle and rebuild the manifest identity,
    # replay ledger pair. This creates a valid trial but not a common evaluation slice.
    root = tmp_path / "trial_1"
    source = root / "BTCUSDT-1m.csv"
    rows = list(csv.reader(source.open(encoding="utf-8")))
    for row in rows:
        if int(row[0]) == 600_000:
            row[1] = "110.0"
            row[2] = "110.5"
            row[3] = "109.5"
            row[4] = "110.1"
            break
    with source.open("w", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerows(rows)
    old = ReplayDatasetManifest.load(root / "manifest.json")
    files = (
        ReplayKlineFile.inspect(root, "BTCUSDT-1m.csv", "1m", symbol="BTCUSDT"),
        old.files[1],
    )
    changed = ReplayDatasetManifest(
        symbol=old.symbol, start_open_time_ms=old.start_open_time_ms,
        end_open_time_ms=old.end_open_time_ms, files=files, metadata=old.metadata,
    )
    changed.write(root / "manifest.json")
    HistoricalReplayRunner(
        changed, dataset_root=root,
        config=ReplayConfig(max_history_candles=128, include_m15=False),
    ).run_to_file(root / "replay.jsonl")
    with pytest.raises(WarmupConvergenceError, match="identical per-timeframe"):
        analyze_warmup_convergence(plan_path)


def test_replay_convergence_cli_writes_schema_valid_report(tmp_path, capsys):
    from divatrading.cli import main

    plan_path = _build_trials(tmp_path, starts=(0, 600_000))
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    plan["trials"] = plan["trials"][:2]
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    destination = tmp_path / "cli_report.json"
    assert main(["replay-convergence", "--plan", str(plan_path), "--report", str(destination)]) == 0
    assert "LIMITED_TWO_TRIAL_COMPARISON" in capsys.readouterr().out
    report = json.loads(destination.read_text(encoding="utf-8"))
    Draft202012Validator(json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))).validate(report)


def test_duplicate_preroll_durations_are_rejected(tmp_path):
    plan_path = _build_trials(tmp_path, starts=(0, 0, 600_000))
    with pytest.raises(WarmupConvergenceError, match="distinct pre-roll duration"):
        analyze_warmup_convergence(plan_path)
