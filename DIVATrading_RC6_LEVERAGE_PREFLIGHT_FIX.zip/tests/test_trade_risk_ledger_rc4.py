from datetime import datetime, timezone, timedelta
from decimal import Decimal
from divatrading.core.database import Database
from divatrading.execution.trade_risk_ledger import CompletedTradeRiskLedger, entry_reconciliation_gate


def test_completed_lifecycle_idempotency_and_streak_across_partial_exits(tmp_path):
    ledger = CompletedTradeRiskLedger(Database(tmp_path / "ledger.db"))
    close = datetime(2026, 11, 15, 1, 0, tzinfo=timezone.utc)
    # The caller supplies one aggregate result only after the whole lifecycle closes.
    assert ledger.record_completed_lifecycle(lifecycle_id="trade-1", symbol="BTCUSDT", closed_at=close,
        realized_pnl="-1.5", commission="0.1", funding="0.02")
    assert not ledger.record_completed_lifecycle(lifecycle_id="trade-1", symbol="BTCUSDT", closed_at=close,
        realized_pnl="-1.5", commission="0.1", funding="0.02")
    ledger.record_completed_lifecycle(lifecycle_id="trade-2", symbol="ETHUSDT", closed_at=close + timedelta(minutes=1),
        realized_pnl="-2", commission="0.1", funding="0")
    snap = ledger.snapshot(close + timedelta(hours=1))
    assert snap.consecutive_losses == 2
    assert snap.completed_trades == 2
    assert snap.daily_net_pnl == Decimal("-3.68")
    assert not snap.reconciliation_ready
    assert entry_reconciliation_gate(snap)[0] is False
    ledger.set_reconciliation(True)
    assert entry_reconciliation_gate(ledger.snapshot(close))[0] is True


def test_jakarta_day_boundary_is_used(tmp_path):
    ledger = CompletedTradeRiskLedger(Database(tmp_path / "ledger.db"))
    # 16:59:59 UTC = 23:59:59 Jakarta; one second later is the next Jakarta day.
    before = datetime(2026, 11, 14, 16, 59, 59, tzinfo=timezone.utc)
    after = before + timedelta(seconds=1)
    assert ledger.jakarta_day(before) == "2026-11-14"
    assert ledger.jakarta_day(after) == "2026-11-15"
