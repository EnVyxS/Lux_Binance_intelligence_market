from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.strategy.scalping_market_data import ScalpingMarketDataAdapter
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureEngine,
    StructurePivot,
    StructurePivotState,
)
from divatrading.strategy.scalping_liquidity_fvg import (
    ScalpingLiquidityFVGCapacityError,
    ScalpingLiquidityFVGConfig,
    ScalpingLiquidityFVGContinuityError,
    ScalpingLiquidityFVGEngine,
    ScalpingLiquidityFVGInputError,
)

NOW = 1_800_000_000_000


def instrument():
    payload = json.loads((Path(__file__).parent / "fixtures" / "exchange_info_valid.json").read_text())
    return SymbolInfo.from_payload(next(item for item in payload["symbols"] if item["symbol"] == "BTCUSDT"))


def candle(interval, open_time, values, symbol="BTCUSDT"):
    op, hi, lo, cl = values
    span = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, op, hi, lo, cl, "10", open_time + span - 1, "1000", 10, "5", "500", "0"],
        symbol=symbol, interval=interval, source_endpoint="https://fixture/klines",
    )


def view_for(*, m1_values=None, m5_values=None, m15_values=None, now_ms=NOW):
    series = []
    for interval, values in (("1m", m1_values), ("5m", m5_values), ("15m", m15_values)):
        if values is None:
            continue
        span = INTERVAL_MILLISECONDS[interval]
        last_open = (now_ms // span - 1) * span
        first_open = last_open - (len(values) - 1) * span
        rows = tuple(candle(interval, first_open + i * span, row) for i, row in enumerate(values))
        series.append(KlineSeriesInput(
            symbol="BTCUSDT", interval=interval, candles=rows,
            source_observed_at_ms=now_ms - 100, source_healthy=True, source_complete=True,
        ))
    return ScalpingMarketDataAdapter().build_view(
        symbol="BTCUSDT", now_ms=now_ms, symbol_info=instrument(), kline_series=tuple(series)
    )


def structure_for(view):
    return ScalpingMarketStructureEngine(config=ScalpingMarketStructureConfig(
        swing_left_bars=1, swing_right_bars=1, internal_left_bars=1, internal_right_bars=1,
    )).process(view)


def with_pivots(structure, view, pivots):
    updated = []
    for tf in structure.timeframes:
        if tf.timeframe == "1m":
            updated.append(replace(tf, pivots=tuple(StructurePivotState(p, False) for p in pivots)))
        elif tf.timeframe == "5m":
            updated.append(replace(tf, pivots=()))
        else:
            updated.append(tf)
    return replace(structure, timeframes=tuple(updated))


def pivot(view, *, kind="HIGH", price="110.0", source_index=0, confirmation_index=1, layer="SWING", suffix="a"):
    c = view.m1.candles
    return StructurePivot(
        pivot_id=f"pivot-{suffix}", symbol="BTCUSDT", timeframe="1m",
        layer=layer, kind=kind, price=Decimal(price),
        source_open_time_ms=c[source_index].open_time_ms,
        confirmation_close_time_ms=c[confirmation_index].close_time_ms,
        source_index=source_index, confirmation_index=confirmation_index,
    )


def run_engine(rows, *, config=None, pivots=None, m15=None):
    view = view_for(m1_values=rows, m5_values=rows, m15_values=m15)
    structure = structure_for(view)
    if pivots is not None:
        structure = with_pivots(structure, view, pivots)
    result = ScalpingLiquidityFVGEngine(config=config).process(structure, view)
    return view, structure, result


def test_bullish_fvg_uses_exact_three_candle_index_and_boundaries():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    _, _, result = run_engine(rows)
    fvg = next(item for item in result.timeframe("1m").fvgs if item.direction == 1)
    assert (fvg.zone_top, fvg.zone_bottom) == (Decimal("107.0"), Decimal("105.0"))
    tf_candles = result.timeframe("1m")
    assert fvg.first_bar_open_time_ms < fvg.middle_bar_open_time_ms < fvg.confirmation_bar_open_time_ms
    assert fvg.confirmation_time_ms > fvg.confirmation_bar_open_time_ms
    assert fvg.status == "ACTIVE"


def test_bearish_fvg_uses_exact_three_candle_index_and_boundaries():
    rows = [
        ("108.0", "110.0", "105.0", "107.0"),
        ("107.0", "109.0", "104.0", "105.0"),
        ("103.0", "104.0", "99.0", "100.0"),
    ]
    _, _, result = run_engine(rows)
    fvg = next(item for item in result.timeframe("1m").fvgs if item.direction == -1)
    assert (fvg.zone_top, fvg.zone_bottom) == (Decimal("105.0"), Decimal("104.0"))
    assert fvg.status == "ACTIVE"


def test_fvg_does_not_touch_on_its_formation_candle():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    _, _, result = run_engine(rows)
    fvg = next(item for item in result.fvgs if item.direction == 1)
    assert fvg.first_touch_time_ms is None
    assert fvg.maximum_fill_ratio == 0


def test_bullish_fvg_partial_fill_and_full_fill_are_separate_states():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
        ("109.0", "110.0", "106.0", "108.0"),
        ("106.0", "108.0", "104.0", "105.0"),
    ]
    _, _, result = run_engine(rows)
    fvg = next(item for item in result.fvgs if item.direction == 1)
    assert fvg.status == "FILLED"
    assert fvg.maximum_fill_ratio == Decimal("1")
    assert fvg.first_touch_time_ms is not None and fvg.fill_time_ms is not None


def test_bearish_fvg_partial_fill():
    rows = [
        ("108.0", "110.0", "105.0", "107.0"),
        ("107.0", "109.0", "104.0", "105.0"),
        ("103.0", "104.0", "99.0", "100.0"),
        ("103.0", "104.5", "100.0", "104.0"),
    ]
    _, _, result = run_engine(rows)
    fvg = next(item for item in result.fvgs if item.direction == -1)
    assert fvg.status == "PARTIALLY_FILLED"
    assert fvg.maximum_fill_ratio == Decimal("0.5")


def test_equal_levels_are_grouped_using_exact_tick_tolerance():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "110.1", "101.0", "106.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    p1 = pivot(view, price="110.0", source_index=0, confirmation_index=1, suffix="one")
    p2 = pivot(view, price="110.1", source_index=1, confirmation_index=2, suffix="two")
    structure = with_pivots(structure, view, (p1, p2))
    result = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        equal_level_tolerance_ticks=1,
    )).process(structure, view)
    equal = [ref for ref in result.timeframe("1m").references if ref.kind == "EQUAL_HIGH"]
    assert equal
    assert set(equal[-1].pivot_ids) == {p1.pivot_id, p2.pivot_id}


def test_equal_levels_outside_tick_tolerance_remain_separate():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "110.2", "101.0", "106.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    p1 = pivot(view, price="110.0", source_index=0, confirmation_index=1, suffix="one")
    p2 = pivot(view, price="110.2", source_index=1, confirmation_index=2, suffix="two")
    structure = with_pivots(structure, view, (p1, p2))
    result = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        equal_level_tolerance_ticks=1,
    )).process(structure, view)
    assert not [ref for ref in result.timeframe("1m").references if ref.kind == "EQUAL_HIGH"]


def test_confirmed_pivot_is_not_available_to_its_confirmation_candle():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "112.0", "101.0", "111.0"),
        ("111.0", "113.0", "102.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    p = pivot(view, price="110.0", source_index=0, confirmation_index=1)
    structure = with_pivots(structure, view, (p,))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    # The only bar after pivot confirmation is bar 2; it can be referenced.
    refs = result.timeframe("1m").references
    assert any(item.pivot_ids == (p.pivot_id,) for item in refs)


def test_high_sweep_close_back_is_qualified_bearish_evidence():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweep = next(item for item in result.timeframe("1m").sweeps if item.close_back)
    assert sweep.direction == -1
    assert sweep.qualifies_as_sweep is True
    assert sweep.outcome == "CLOSE_BACK"


def test_low_sweep_close_back_is_qualified_bullish_evidence():
    rows = [
        ("108.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "102.0", "106.0"),
        ("106.0", "109.0", "98.0", "101.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (
        pivot(view, kind="LOW", price="100.0", confirmation_index=1),
    ))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweep = next(item for item in result.timeframe("1m").sweeps if item.close_back)
    assert sweep.direction == 1
    assert sweep.qualifies_as_sweep is True


def test_close_through_is_distinguished_and_not_qualified_by_default():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweep = next(item for item in result.timeframe("1m").sweeps if item.close_through)
    assert sweep.outcome == "CLOSE_THROUGH"
    assert sweep.close_back is False
    assert sweep.qualifies_as_sweep is False


def test_close_through_can_be_recorded_as_sweep_when_close_back_not_required():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        require_sweep_close_back=False,
    )).process(structure, view)
    sweep = next(item for item in result.sweeps if item.close_through)
    assert sweep.qualifies_as_sweep is True


def test_wick_breach_and_close_back_are_separately_exposed():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweep = next(item for item in result.sweeps if item.wick_breach)
    assert sweep.wick_breach is True
    assert sweep.close_through is False
    assert sweep.close_back is True


def test_sweep_does_not_use_unconfirmed_future_pivot():
    rows = [
        ("102.0", "112.0", "100.0", "111.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "113.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    p = pivot(view, price="108.0", source_index=1, confirmation_index=2)
    structure = with_pivots(structure_for(view), view, (p,))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    # The first candle crossed the future level before it existed; the final
    # candle is the pivot-confirmation candle and cannot sweep itself.
    assert not result.sweeps


def test_duplicate_pivot_identity_does_not_create_duplicate_reference():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "109.0", "102.0", "107.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    p = pivot(view, confirmation_index=1)
    structure = with_pivots(structure_for(view), view, (p, p))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    assert len([x for x in result.timeframe("1m").references if x.pivot_ids == (p.pivot_id,)]) == 1


def test_m1_m5_are_independent_and_m15_is_advisory_only():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    _, _, result = run_engine(rows, m15=rows)
    assert result.timeframe("1m").fvgs
    assert result.timeframe("5m").fvgs
    assert result.timeframe("15m").status == "ADVISORY_ONLY"
    assert not result.timeframe("15m").fvgs


def test_m1_evidence_survives_unavailable_m5_without_cross_suppression():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows)
    result = ScalpingLiquidityFVGEngine().process(structure_for(view), view)
    assert result.timeframe("1m").fvgs
    assert result.timeframe("5m").status == "UNAVAILABLE"


def test_duplicate_capture_is_idempotent_and_jsonl_deterministic():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    engine = ScalpingLiquidityFVGEngine()
    first = engine.process(structure, view)
    second = engine.process(structure, view)
    assert first.to_jsonl() == second.to_jsonl()
    assert first.to_jsonl() == engine.process(structure, view).to_jsonl()


def test_gap_in_closed_kline_series_fails_closed():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    bad = replace(view.m1, candles=(view.m1.candles[0], view.m1.candles[2]))
    bad_view = replace(view, m1=bad)
    with pytest.raises(ScalpingLiquidityFVGContinuityError):
        ScalpingLiquidityFVGEngine().process(structure, bad_view)


def test_revised_last_candle_fails_closed_on_incremental_replay():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    engine = ScalpingLiquidityFVGEngine()
    engine.process(structure, view)
    revised_candles = view.m1.candles[:-1] + (
        replace(view.m1.candles[-1], close=Decimal("109.0")),
    )
    revised = replace(view.m1, candles=revised_candles)
    bad_view = replace(view, m1=revised)
    with pytest.raises(ScalpingLiquidityFVGContinuityError):
        engine.process(structure_for(bad_view), bad_view)


def test_reset_clears_symbol_state():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    engine = ScalpingLiquidityFVGEngine()
    engine.process(structure, view)
    engine.reset(symbol="BTCUSDT")
    result = engine.process(structure, view)
    assert result.timeframe("1m").processed_candle_count == 3


def test_trace_and_evidence_ids_are_stable_across_fresh_replay():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    a = ScalpingLiquidityFVGEngine().process(structure, view)
    b = ScalpingLiquidityFVGEngine().process(structure, view)
    assert a.to_jsonl() == b.to_jsonl()


def test_invalid_pivot_time_provenance_is_rejected():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    p = replace(pivot(view), confirmation_close_time_ms=view.m1.candles[0].close_time_ms)
    structure = with_pivots(structure_for(view), view, (p,))
    with pytest.raises(ScalpingLiquidityFVGInputError):
        ScalpingLiquidityFVGEngine().process(structure, view)


def test_equal_cluster_references_keep_tick_aligned_canonical_price():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "110.1", "101.0", "106.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "109.0", "103.0", "108.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    p1 = pivot(view, price="110.0", source_index=0, confirmation_index=1, suffix="a")
    p2 = pivot(view, price="110.1", source_index=1, confirmation_index=2, suffix="b")
    structure = with_pivots(structure_for(view), view, (p1, p2))
    result = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        equal_level_tolerance_ticks=1,
    )).process(structure, view)
    refs = [x for x in result.timeframe("1m").references if x.kind == "EQUAL_HIGH"]
    assert refs and refs[0].price == Decimal("110.0")


def test_fvg_is_optional_evidence_and_does_not_mutate_structure_events():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    before = structure.to_jsonl()
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    assert result.fvgs
    assert structure.to_jsonl() == before


def test_fvg_evidence_does_not_create_or_change_ob_lifecycle_state():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    assert result.fvgs
    # Stage 5 accepts no Stage-4 lifecycle argument and therefore cannot mutate it.
    assert not hasattr(result, "order_blocks")


def test_fvg_capacity_fails_when_only_nonterminal_records_remain():
    rows = []
    for group in range(10):
        offset = Decimal(group * 20)
        rows.extend([
            tuple(str(x + offset) for x in (Decimal("100"), Decimal("102"), Decimal("99"), Decimal("101"))),
            tuple(str(x + offset) for x in (Decimal("104"), Decimal("106"), Decimal("103"), Decimal("105"))),
            tuple(str(x + offset) for x in (Decimal("108"), Decimal("110"), Decimal("107"), Decimal("109"))),
        ])
    rows = [tuple(format(Decimal(value), "f") for value in row) for row in rows]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    engine = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        max_fvgs_per_timeframe=8,
    ))
    with pytest.raises(ScalpingLiquidityFVGCapacityError):
        engine.process(structure, view)


def test_unclosed_forming_candle_is_not_used_for_fvg_confirmation():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    # The adapter exposes only closed candles; a forming candle is not part of
    # the Stage-5 input series and therefore cannot create another FVG.
    assert view.m1.forming_candle is None
    structure = structure_for(view)
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    assert len([item for item in result.timeframe("1m").fvgs if item.direction == 1]) == 1


def test_m5_preflight_failure_does_not_commit_m1_partition():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    engine = ScalpingLiquidityFVGEngine()
    # Corrupt only M5 continuity. The engine validates both partitions before
    # committing either one.
    bad_m5 = replace(view.m5, candles=(view.m5.candles[0], view.m5.candles[2]))
    bad_view = replace(view, m5=bad_m5)
    with pytest.raises(ScalpingLiquidityFVGContinuityError):
        engine.process(structure, bad_view)
    assert engine._states == {}


def test_incremental_replay_uses_previous_two_candles_for_fvg():
    initial = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
    ]
    next_bar = ("108.0", "111.0", "107.0", "110.0")
    first_view = view_for(m1_values=initial, m5_values=initial)
    structure_engine = ScalpingMarketStructureEngine(config=ScalpingMarketStructureConfig(
        swing_left_bars=1, swing_right_bars=1, internal_left_bars=1, internal_right_bars=1,
    ))
    first_structure = structure_engine.process(first_view)
    evidence_engine = ScalpingLiquidityFVGEngine()
    evidence_engine.process(first_structure, first_view)

    second_view = view_for(
        m1_values=initial + [next_bar], m5_values=initial,
        now_ms=NOW + INTERVAL_MILLISECONDS["1m"],
    )
    second_structure = structure_engine.process(second_view)
    result = evidence_engine.process(second_structure, second_view)
    assert any(item.direction == 1 for item in result.timeframe("1m").fvgs)



def test_close_exactly_at_liquidity_level_is_not_close_back_through():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "110.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweep = next(item for item in result.sweeps if item.wick_breach)
    assert sweep.close_back is False
    assert sweep.close_through is False
    assert sweep.outcome == "WICK_BREACH"
    assert sweep.qualifies_as_sweep is False


def test_revision_to_older_overlapping_candle_fails_closed():
    rows = [
        ("102.0", "105.0", "100.0", "103.0"),
        ("103.0", "108.0", "102.0", "106.0"),
        ("108.0", "111.0", "107.0", "110.0"),
        ("109.0", "112.0", "108.0", "111.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    engine = ScalpingLiquidityFVGEngine()
    engine.process(structure_for(view), view)
    revised_candles = (
        replace(view.m1.candles[0], volume=Decimal("11")),
        *view.m1.candles[1:],
    )
    revised_view = replace(view, m1=replace(view.m1, candles=revised_candles))
    with pytest.raises(ScalpingLiquidityFVGContinuityError):
        engine.process(structure_for(revised_view), revised_view)


def test_sweep_history_is_bounded():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
    ] + [("106.0", "112.0", "103.0", "109.0")] * 12
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine(config=ScalpingLiquidityFVGConfig(
        max_sweeps_per_timeframe=8,
    )).process(structure, view)
    assert len(result.timeframe("1m").sweeps) <= 8



def test_qualified_sweep_consumes_reference_and_is_not_repeated():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
        ("107.0", "113.0", "104.0", "108.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = with_pivots(structure_for(view), view, (pivot(view, confirmation_index=1),))
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    sweeps = [item for item in result.timeframe("1m").sweeps if item.close_back]
    assert len(sweeps) == 1


def test_close_through_break_event_retires_pivot_for_later_candles():
    rows = [
        ("102.0", "108.0", "100.0", "105.0"),
        ("105.0", "110.0", "101.0", "106.0"),
        ("106.0", "108.0", "102.0", "107.0"),
        ("107.0", "112.0", "103.0", "111.0"),
        ("108.0", "114.0", "104.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    structure = structure_for(view)
    m1 = structure.timeframe("1m")
    assert m1 is not None
    assert any(event.pivot_id for event in m1.events)
    result = ScalpingLiquidityFVGEngine().process(structure, view)
    high_breaks = [
        item for item in result.timeframe("1m").sweeps
        if item.close_through and item.bar_open_time_ms == view.m1.candles[3].open_time_ms
    ]
    assert high_breaks
    assert not [
        item for item in result.timeframe("1m").sweeps
        if item.bar_open_time_ms == view.m1.candles[4].open_time_ms
    ]



def test_conflicting_reuse_of_pivot_id_fails_closed():
    rows = [
        ("102.0", "110.0", "100.0", "105.0"),
        ("105.0", "108.0", "101.0", "106.0"),
        ("106.0", "112.0", "103.0", "109.0"),
    ]
    view = view_for(m1_values=rows, m5_values=rows)
    p1 = pivot(view, price="110.0", source_index=0, confirmation_index=1, suffix="same")
    p2 = pivot(view, price="108.0", source_index=1, confirmation_index=2, suffix="same")
    structure = with_pivots(structure_for(view), view, (p1, p2))
    with pytest.raises(ScalpingLiquidityFVGInputError):
        ScalpingLiquidityFVGEngine().process(structure, view)
