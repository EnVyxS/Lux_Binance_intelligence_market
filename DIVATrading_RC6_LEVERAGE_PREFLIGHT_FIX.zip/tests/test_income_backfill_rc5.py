from __future__ import annotations

from divatrading.execution.income_backfill import BinanceIncomeHistoryBackfillService
from divatrading.execution.ledger import ExecutionLedger


class FakeIncomeClient:
    def __init__(self, handler):
        self.handler = handler
        self.calls = []

    def get_income_history(self, **kwargs):
        self.calls.append(kwargs)
        return self.handler(kwargs, len(self.calls))


def income(tran_id, time_ms, amount="-0.1", kind="COMMISSION", asset="USDT", symbol="BTCUSDT"):
    return {"tranId": tran_id, "time": time_ms, "income": amount,
            "incomeType": kind, "asset": asset, "symbol": symbol}


def test_income_backfill_splits_full_pages_and_persists_idempotently(tmp_path):
    start, end = 1_700_000_000_000, 1_700_000_000_010
    def handler(params, _call):
        left, right = params["start_time_ms"], params["end_time_ms"]
        if left == start and right == end:
            return [income("1", start), income("2", end)]
        if left == start:
            return [income("1", start)]
        return [income("2", end)]
    ledger = ExecutionLedger(tmp_path / "income.sqlite")
    client = FakeIncomeClient(handler)
    service = BinanceIncomeHistoryBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: end,
        sleep=lambda _: None, request_pause_seconds=0, page_limit=2,
    )
    result = service.backfill(start_time_ms=start, end_time_ms=end)
    assert result.requests == 3
    assert result.received_rows == 2
    assert result.inserted_rows == 2
    assert ledger.get_income_backfill_state()["watermark_ms"] == end
    replay = service.backfill(start_time_ms=start, end_time_ms=end)
    assert replay.inserted_rows == 0
    assert len(ledger.list_income_rows()) == 2
    assert ledger.list_income_rows()[0]["income_type"] == "COMMISSION"


def test_income_backfill_does_not_advance_watermark_when_late_window_fails(tmp_path):
    start, end = 1_700_000_000_000, 1_700_000_000_000 + 7 * 24 * 60 * 60 * 1000 + 5
    def handler(params, call):
        if call == 1:
            return [income("1", start)]
        raise RuntimeError("income outage")
    ledger = ExecutionLedger(tmp_path / "income-fail.sqlite")
    service = BinanceIncomeHistoryBackfillService(
        client=FakeIncomeClient(handler), ledger=ledger, clock_ms=lambda: end,
        sleep=lambda _: None, request_pause_seconds=0, page_limit=2,
    )
    import pytest
    with pytest.raises(RuntimeError, match="income outage"):
        service.backfill(start_time_ms=start, end_time_ms=end)
    assert ledger.get_income_backfill_state()["watermark_ms"] == 0
    assert ledger.get_income_backfill_state()["last_error"]
    assert len(ledger.list_income_rows()) == 1  # committed page is safe to replay


def test_transfer_cashflow_adjustment_is_idempotent_and_exact_decimal(tmp_path):
    ledger = ExecutionLedger(tmp_path / "income-transfer.sqlite")
    rows = [income("t1", 1, "100.12345678", "TRANSFER"),
            income("t2", 2, "-20.00000001", "TRANSFER"),
            income("c1", 3, "-1", "COMMISSION")]
    assert ledger.store_income_rows(rows) == 3
    assert ledger.income_cashflow_adjustment_usdt() == __import__("decimal").Decimal("80.12345677")
    assert ledger.store_income_rows(rows) == 0
    assert ledger.income_cashflow_adjustment_usdt() == __import__("decimal").Decimal("80.12345677")
