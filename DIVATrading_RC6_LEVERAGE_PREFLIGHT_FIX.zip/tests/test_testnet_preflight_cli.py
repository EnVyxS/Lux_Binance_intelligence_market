from __future__ import annotations

import json
from pathlib import Path

import pytest

from divatrading import cli

pytestmark = pytest.mark.usefixtures("isolated_cli_environment")


def test_testnet_preflight_parser_exposes_read_only_command():
    args = cli.build_parser().parse_args(["testnet-preflight", "--symbols", "BTCUSDT,ETHUSDT"])
    assert args.command == "testnet-preflight"
    assert args.symbols == "BTCUSDT,ETHUSDT"


def test_testnet_preflight_cli_blocks_paper_or_live_configuration_without_network(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=PAPER\nBINANCE_API_KEY=hidden-key\nBINANCE_API_SECRET=hidden-secret\n",
        encoding="utf-8",
    )
    rc = cli.main(["testnet-preflight"])
    output = capsys.readouterr().out
    payload = json.loads(output)
    assert rc == 2
    assert payload["status"] == "BLOCKED_CONFIGURATION"
    assert "hidden-key" not in output and "hidden-secret" not in output


def test_testnet_preflight_cli_requires_local_credentials(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text("DIVA_EXECUTION_MODE=TESTNET\n", encoding="utf-8")
    rc = cli.main(["testnet-preflight"])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_CREDENTIALS"


def test_testnet_preflight_cli_uses_testnet_client_and_reports_without_secrets(tmp_path, monkeypatch, capsys):
    class FakeReport:
        ready_for_test_order = True
        def to_dict(self):
            return {"status": "READY_FOR_TEST_ORDER_VALIDATION", "order_submission_performed": False}

    class FakeClient:
        def __init__(self, api_key, api_secret, *, environment):
            assert api_key == "local-key"
            assert api_secret == "local-secret"
            assert environment == "TESTNET"
            self.closed = False
        def close(self):
            self.closed = True

    class FakePreflight:
        def __init__(self, client, *, symbols):
            assert symbols == ("BTCUSDT",)
        def run(self):
            return FakeReport()

    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=TESTNET\nBINANCE_API_KEY=local-key\nBINANCE_API_SECRET=local-secret\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(cli, "BinancePrivateRestClient", FakeClient)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakePreflight)
    rc = cli.main(["testnet-preflight"])
    output = capsys.readouterr().out
    assert rc == 0
    assert "READY_FOR_TEST_ORDER_VALIDATION" in output
    assert "local-secret" not in output


def test_testnet_preflight_cli_blocks_live_opt_in_even_if_testnet_selected(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=TESTNET\nDIVA_LIVE_TRADING_ENABLED=true\n"
        "BINANCE_API_KEY=hidden-key\nBINANCE_API_SECRET=hidden-secret\n",
        encoding="utf-8",
    )
    rc = cli.main(["testnet-preflight"])
    output = capsys.readouterr().out
    payload = json.loads(output)
    assert rc == 2
    assert payload["status"] == "BLOCKED_CONFIGURATION"
    assert "hidden-secret" not in output


def test_mark_price_endpoint_selects_demo_futures_stream_without_legacy_testnet_host(monkeypatch):
    monkeypatch.delenv("DIVA_MARK_PRICE_WS_ENDPOINT", raising=False)
    assert cli._mark_price_endpoint("TESTNET") == "wss://demo-fstream.binance.com/market/stream"
    assert cli._mark_price_endpoint("LIVE") == "wss://fstream.binance.com/market/stream"
