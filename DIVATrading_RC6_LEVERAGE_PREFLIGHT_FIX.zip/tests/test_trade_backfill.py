from __future__ import annotations

from decimal import Decimal

import httpx
import pytest

from divatrading.execution.binance_private import BinancePrivateRestClient
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.trade_backfill import (
    BinanceUserTradesBackfillService,
    SEVEN_DAYS_MS,
    THREE_MONTHS_MS,
)


class FakeTradesClient:
    def __init__(self, pages=None, *, on_call=None):
        self.pages = list(pages or [])
        self.calls = []
        self.on_call = on_call

    def get_user_trades(self, symbol, **kwargs):
        self.calls.append((symbol, kwargs))
        if self.on_call:
            return self.on_call(symbol, kwargs, len(self.calls))
        if self.pages:
            return self.pages.pop(0)
        return []


def trade(trade_id: int, *, symbol="BTCUSDT", order_id=777, qty="0.01", price="50000", time_ms=1_700_000_000_000):
    return {
        "symbol": symbol, "id": trade_id, "orderId": order_id,
        "price": price, "qty": qty, "commission": "0.0001",
        "commissionAsset": "BNB", "realizedPnl": "0", "side": "BUY",
        "positionSide": "LONG", "time": time_ms, "maker": False,
    }


def linked_ledger(tmp_path):
    ledger = ExecutionLedger(tmp_path / "fills.sqlite")
    assert ledger.claim_intent(
        signal_id="sig-1", symbol="BTCUSDT", side="LONG", client_order_id="DIVAENTRY1", payload={}
    )
    ledger.record_order(
        client_id="DIVAENTRY1", signal_id="sig-1", symbol="BTCUSDT", role="ENTRY",
        order_kind="STANDARD", status="FILLED", exchange_order_id=777,
        payload={"positionSide": "LONG"},
    )
    return ledger


def test_rest_backfill_attributes_fill_and_advances_watermark_after_completion(tmp_path):
    ledger = linked_ledger(tmp_path)
    rows = [trade(10, time_ms=1_700_000_000_000), trade(11, time_ms=1_700_000_000_100)]
    client = FakeTradesClient([rows])
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: 1_700_000_010_000,
        sleep=lambda _: None, request_pause_seconds=0,
    )

    result = service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)

    assert result.received_trades == 2
    assert result.inserted_trades == 2
    assert result.max_trade_id == 11
    assert result.watermark["last_trade_id"] == 11
    assert result.watermark["completed_through_ms"] == 1_700_000_010_000
    fills = ledger.list_position_fill_allocations(signal_id="sig-1")
    assert len(fills) == 2
    assert {row["source"] for row in fills} == {"REST_USER_TRADES"}
    projections = ledger.apply_position_fill_allocations(signal_id="sig-1")
    assert Decimal(projections[0]["entry_quantity"]) == Decimal("0.02")


def test_stream_and_rest_merge_by_symbol_trade_id_without_double_count(tmp_path):
    ledger = linked_ledger(tmp_path)
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(42)]]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    stream_payload = {
        "e": "ORDER_TRADE_UPDATE", "E": 1_700_000_000_000,
        "o": {"x": "TRADE", "c": "DIVAENTRY1", "s": "BTCUSDT", "t": 42,
              "i": 777, "ps": "LONG", "l": "0.01", "L": "50000",
              "n": "0.0001", "N": "BNB", "rp": "0", "S": "BUY", "m": False},
    }
    ledger.record_user_stream_event(stream_payload, received_at_ms=1_700_000_000_200)
    fills = ledger.list_position_fill_allocations(signal_id="sig-1")
    assert len(fills) == 1
    assert fills[0]["source"] == "REST+USER_STREAM"
    projection = ledger.apply_position_fill_allocations(signal_id="sig-1")[0]
    assert Decimal(projection["entry_quantity"]) == Decimal("0.01")
    assert projection["fill_count"] == 1


def test_backfill_failure_does_not_advance_watermark(tmp_path):
    ledger = linked_ledger(tmp_path)
    calls = 0
    def fail_after_first_page(symbol, params, call_no):
        nonlocal calls
        calls += 1
        if call_no == 1:
            return [trade(100)]
        raise RuntimeError("simulated REST outage")
    client = FakeTradesClient(on_call=fail_after_first_page)
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: 1_700_000_000_100 + SEVEN_DAYS_MS + 10,
        sleep=lambda _: None, request_pause_seconds=0, page_limit=2,
    )
    with pytest.raises(RuntimeError, match="simulated REST outage"):
        service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    assert ledger.get_trade_backfill_watermark("BTCUSDT") is None
    fills = ledger.list_position_fill_allocations()
    assert len(fills) == 1  # committed page is safe to replay; watermark remains unchanged


def test_time_backfill_splits_full_pages_into_bounded_windows(tmp_path):
    ledger = linked_ledger(tmp_path)
    start = 1_700_000_000_000
    end = start + 100
    def dense(symbol, params, call_no):
        if params["start_time_ms"] == start and params["end_time_ms"] == end:
            return [trade(i, time_ms=start + (i % 2)) for i in range(1, 4)]
        return [trade(100 + call_no, time_ms=params["start_time_ms"])]
    client = FakeTradesClient(on_call=dense)
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: end + 1,
        sleep=lambda _: None, request_pause_seconds=0, page_limit=3,
    )
    result = service.backfill_symbol("BTCUSDT", start_time_ms=start, end_time_ms=end)
    assert result.pages >= 3
    assert result.watermark["completed_through_ms"] == end
    assert all(
        "from_id" not in params and params["end_time_ms"] - params["start_time_ms"] <= SEVEN_DAYS_MS
        for _, params in client.calls
    )


def test_private_client_user_trades_parameters_and_validation():
    seen = []
    def handler(request: httpx.Request):
        seen.append(request.url)
        return httpx.Response(200, json=[trade(1)])
    http = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinancePrivateRestClient("key", "secret", environment="TESTNET", http_client=http,
                                      wall_clock_ms=lambda: 1_700_000_000_000)
    rows = client.get_user_trades("btcusdt", from_id=8, limit=1000)
    assert rows[0]["id"] == 1
    assert seen[0].path == "/fapi/v1/userTrades"
    assert seen[0].params["symbol"] == "BTCUSDT"
    assert seen[0].params["fromId"] == "8"
    with pytest.raises(ValueError, match="cannot be combined"):
        client.get_user_trades("BTCUSDT", from_id=1, start_time_ms=1, end_time_ms=2)
    with pytest.raises(ValueError, match="seven days"):
        client.get_user_trades("BTCUSDT", start_time_ms=0, end_time_ms=SEVEN_DAYS_MS + 1)
    http.close()


def test_contradictory_duplicate_fill_is_rejected(tmp_path):
    ledger = linked_ledger(tmp_path)
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(77)]]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    client = FakeTradesClient([[trade(77, qty="0.02")]])
    replay = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: 1_700_000_000_200,
        sleep=lambda _: None, request_pause_seconds=0,
    )
    # Explicit overlap is allowed, but conflicting immutable facts fail closed.
    with pytest.raises(RuntimeError, match="CONTRADICTORY_QUANTITY_OR_PRICE"):
        replay.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)


def test_stream_first_then_rest_preserves_owner_and_enriches_source(tmp_path):
    ledger = linked_ledger(tmp_path)
    stream_payload = {
        "e": "ORDER_TRADE_UPDATE", "E": 1_700_000_000_000,
        "o": {"x": "TRADE", "c": "DIVAENTRY1", "s": "BTCUSDT", "t": 91,
              "i": 777, "ps": "LONG", "l": "0.01", "L": "50000",
              "n": "0", "N": "", "rp": "0", "S": "BUY", "m": False},
    }
    ledger.record_user_stream_event(stream_payload, received_at_ms=1_700_000_000_010)
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(91)]]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    fills = ledger.list_position_fill_allocations(signal_id="sig-1")
    assert len(fills) == 1
    assert fills[0]["client_order_id"] == "DIVAENTRY1"
    assert fills[0]["source"] == "REST+USER_STREAM"
    assert fills[0]["commission_asset"] == "BNB"


def test_cursor_recovery_uses_from_id_only_and_advances_after_all_pages(tmp_path):
    ledger = linked_ledger(tmp_path)
    seed = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(200)]]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    seed.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    client = FakeTradesClient([[trade(201)], [trade(202)], []])
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: 1_700_000_000_500,
        sleep=lambda _: None, request_pause_seconds=0, page_limit=1,
    )
    result = service.backfill_symbol("BTCUSDT")
    assert result.received_trades == 2
    assert [params for _, params in client.calls] == [
        {"limit": 1, "from_id": 201}, {"limit": 1, "from_id": 202},
        {"limit": 1, "from_id": 203},
    ]
    assert result.watermark["last_trade_id"] == 202


def test_rest_fill_recovered_before_order_link_is_attributed_when_link_arrives(tmp_path):
    ledger = ExecutionLedger(tmp_path / "late-rest-ownership.sqlite")
    assert ledger.claim_intent(
        signal_id="sig-late", symbol="BTCUSDT", side="LONG",
        client_order_id="DIVA-LATE", payload={},
    )
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(501, order_id=9001)]]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    assert ledger.list_position_fill_allocations(allocation_status="EXTERNAL")
    ledger.record_order(
        client_id="DIVA-LATE", signal_id="sig-late", symbol="BTCUSDT", role="ENTRY",
        order_kind="STANDARD", status="FILLED", exchange_order_id=9001,
        payload={"positionSide": "LONG"},
    )
    attributed = ledger.list_position_fill_allocations(signal_id="sig-late")
    assert len(attributed) == 1 and attributed[0]["allocation_status"] == "ATTRIBUTED"
    projection = ledger.apply_position_fill_allocations(signal_id="sig-late")[0]
    assert Decimal(projection["net_quantity"]) == Decimal("0.01")


def test_multi_lot_rest_backfill_conserves_quantity_fees_and_realized_pnl(tmp_path):
    ledger = ExecutionLedger(tmp_path / "multi-lot-trade-projection.sqlite")
    order_map = (
        ("sig-a", "DIVA-A-ENTRY", "ENTRY", 1001),
        ("sig-a", "DIVA-A-EXIT", "TAKE_PROFIT", 1002),
        ("sig-b", "DIVA-B-ENTRY", "ENTRY", 2001),
        ("sig-b", "DIVA-B-EXIT", "TAKE_PROFIT", 2002),
    )
    for signal_id, client_id in (("sig-a", "DIVA-A-ENTRY"), ("sig-b", "DIVA-B-ENTRY")):
        assert ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side="LONG",
                                   client_order_id=client_id, payload={})
        reservation = ledger.reserve_portfolio_risk(
            signal_id=signal_id, symbol="BTCUSDT", risk_usdt=Decimal("5"),
            notional_usdt=Decimal("80"), equity_usdt=Decimal("1000"),
            exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
            max_positions=5, max_portfolio_open_risk_pct=Decimal("5"),
            exchange_symbol_notional_usdt=Decimal("0"), max_symbol_notional_usdt=Decimal("10000"),
        )
        assert reservation.accepted
    for signal_id, client_id, role, exchange_id in order_map:
        ledger.record_order(
            client_id=client_id, signal_id=signal_id, symbol="BTCUSDT", role=role,
            order_kind="STANDARD", status="FILLED", exchange_order_id=exchange_id,
            payload={"positionSide": "BOTH"},
        )

    rows = [
        {**trade(1, order_id=1001, qty="0.8", price="100", time_ms=1_700_000_000_001),
         "commission": "0.0008"},
        {**trade(2, order_id=1002, qty="0.3", price="110", time_ms=1_700_000_000_002),
         "side": "SELL", "commission": "0.00033", "realizedPnl": "3"},
        {**trade(3, order_id=2001, qty="0.4", price="105", time_ms=1_700_000_000_003),
         "commission": "0.00042"},
        {**trade(4, order_id=2002, qty="0.1", price="108", time_ms=1_700_000_000_004),
         "side": "SELL", "commission": "0.000108", "realizedPnl": "0.3"},
    ]
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([rows]), ledger=ledger,
        clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    result = service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    assert result.inserted_trades == 4

    projections = {row["signal_id"]: row for row in ledger.list_position_fill_projections()}
    assert Decimal(projections["sig-a"]["entry_quantity"]) == Decimal("0.8")
    assert Decimal(projections["sig-a"]["close_quantity"]) == Decimal("0.3")
    assert Decimal(projections["sig-a"]["net_quantity"]) == Decimal("0.5")
    assert Decimal(projections["sig-a"]["weighted_entry_price"]) == Decimal("100")
    assert Decimal(projections["sig-a"]["commissions"]["BNB"]) == Decimal("0.00113")
    assert Decimal(projections["sig-a"]["realized_pnl"]["USDT"]) == Decimal("3")

    assert Decimal(projections["sig-b"]["entry_quantity"]) == Decimal("0.4")
    assert Decimal(projections["sig-b"]["close_quantity"]) == Decimal("0.1")
    assert Decimal(projections["sig-b"]["net_quantity"]) == Decimal("0.3")
    assert Decimal(projections["sig-b"]["weighted_entry_price"]) == Decimal("105")
    assert Decimal(projections["sig-b"]["commissions"]["BNB"]) == Decimal("0.000528")
    assert Decimal(projections["sig-b"]["realized_pnl"]["USDT"]) == Decimal("0.3")

    # Per-lot fill projections conserve the same aggregate quantity that the
    # multi-lot supervisor and exchange reconciliation expect to see.
    aggregate_net = sum((Decimal(item["net_quantity"]) for item in projections.values()), Decimal("0"))
    assert aggregate_net == Decimal("0.8")
    assert all(ledger.get_risk_reservation(signal_id)["status"] == "ACTIVE"
               for signal_id in ("sig-a", "sig-b"))


def test_rest_then_late_order_ack_attributes_fill_and_rebuilds_projection_once(tmp_path):
    ledger = ExecutionLedger(tmp_path / "rest-late-ack-projection.sqlite")
    assert ledger.claim_intent(
        signal_id="sig-late-ack", symbol="BTCUSDT", side="LONG",
        client_order_id="DIVA-LATE-ACK", payload={},
    )
    service = BinanceUserTradesBackfillService(
        client=FakeTradesClient([[trade(808, order_id=8808, qty="0.2", price="51000")]]),
        ledger=ledger, clock_ms=lambda: 1_700_000_000_100, sleep=lambda _: None,
        request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    assert ledger.list_position_fill_allocations(allocation_status="EXTERNAL")
    assert ledger.get_position_fill_projection("sig-late-ack") is None

    # The order acknowledgement is delayed until after REST history recovery. Its
    # exchangeOrderId link must retroactively attribute and project the same fill.
    ledger.record_order(
        client_id="DIVA-LATE-ACK", signal_id="sig-late-ack", symbol="BTCUSDT",
        role="ENTRY", order_kind="STANDARD", status="FILLED", exchange_order_id=8808,
        payload={"positionSide": "BOTH"},
    )
    projection = ledger.get_position_fill_projection("sig-late-ack")
    assert projection is not None
    assert Decimal(projection["entry_quantity"]) == Decimal("0.2")
    assert Decimal(projection["net_quantity"]) == Decimal("0.2")
    assert projection["fill_count"] == 1



def test_verified_protective_child_link_retroactively_attributes_rest_fill(tmp_path):
    ledger = ExecutionLedger(tmp_path / "protective-child-late-link.sqlite")
    assert ledger.claim_intent(
        signal_id="sig-protective", symbol="BTCUSDT", side="LONG",
        client_order_id="DIVA-PROTECTIVE-ENTRY", payload={},
    )
    ledger.record_order(
        client_id="DIVA-PROTECTIVE-ENTRY", signal_id="sig-protective",
        symbol="BTCUSDT", role="ENTRY", order_kind="STANDARD", status="FILLED",
        exchange_order_id=9908, payload={"positionSide": "BOTH"},
    )
    client = FakeTradesClient([[
        {**trade(908, order_id=9908, qty="0.2", price="100"),
         "side": "BUY", "positionSide": "BOTH", "realizedPnl": "0",
         "commission": "0.0002", "commissionAsset": "USDT"},
        {**trade(909, order_id=9909, qty="0.2", price="90"),
         "side": "SELL", "positionSide": "BOTH", "realizedPnl": "-2",
         "commission": "0.00018", "commissionAsset": "USDT"},
    ]])
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: 1_700_000_000_100,
        sleep=lambda _: None, request_pause_seconds=0,
    )
    result = service.backfill_symbol("BTCUSDT", start_time_ms=1_700_000_000_000)
    assert result.inserted_trades == 2
    before_link = ledger.get_position_fill_projection("sig-protective")
    assert before_link is not None
    assert Decimal(before_link["entry_quantity"]) == Decimal("0.2")
    assert Decimal(before_link["close_quantity"]) == Decimal("0")
    assert len(ledger.list_position_fill_allocations(allocation_status="EXTERNAL")) == 1

    # The Algo trigger is reconciled later. Only after the child MARKET order is
    # REST-verified may its actualOrderId be assigned to this signal lot.
    ledger.link_exchange_order_to_signal(
        symbol="BTCUSDT", exchange_order_id=9909, client_order_id="DIVASL-TRIGGERED",
        signal_id="sig-protective", position_side="BOTH", role="STOP_LOSS",
    )
    projection = ledger.get_position_fill_projection("sig-protective")
    assert projection is not None
    assert Decimal(projection["entry_quantity"]) == Decimal("0.2")
    assert Decimal(projection["close_quantity"]) == Decimal("0.2")
    assert Decimal(projection["net_quantity"]) == Decimal("0")
    assert Decimal(projection["realized_pnl"]["USDT"]) == Decimal("-2")
    assert ledger.get_exchange_order_link(
        symbol="BTCUSDT", exchange_order_id=9909,
    )["signal_id"] == "sig-protective"
    assert not ledger.list_position_fill_allocations(allocation_status="EXTERNAL")

def test_current_binance_user_trades_retention_is_limited_to_three_months(tmp_path):
    ledger = linked_ledger(tmp_path)
    now = 1_800_000_000_000
    client = FakeTradesClient([[]])
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: now,
        sleep=lambda _: None, request_pause_seconds=0,
    )
    service.backfill_symbol("BTCUSDT")
    assert client.calls[0][1]["start_time_ms"] == now - THREE_MONTHS_MS
    assert client.calls[-1][1]["end_time_ms"] == now
    assert all("from_id" not in params for _, params in client.calls)


def test_explicit_trade_backfill_window_over_three_months_is_rejected(tmp_path):
    ledger = linked_ledger(tmp_path)
    now = 1_800_000_000_000
    client = FakeTradesClient([[]])
    service = BinanceUserTradesBackfillService(
        client=client, ledger=ledger, clock_ms=lambda: now,
        sleep=lambda _: None, request_pause_seconds=0,
    )
    with pytest.raises(ValueError, match="three months"):
        service.backfill_symbol("BTCUSDT", start_time_ms=now - THREE_MONTHS_MS - 1)
    assert client.calls == []
