import httpx
import pytest

from divatrading.exchange.binance.client import BinanceResponseError, BinanceUsdMFuturesRestClient


def test_get_aggregate_trades_sends_inclusive_from_id_and_limit():
    requests = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json=[{"a": 10}])

    http_client = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinanceUsdMFuturesRestClient(http_client=http_client)
    try:
        payload = client.get_aggregate_trades(symbol="btcusdt", from_id=10, limit=1000)
    finally:
        client.close()
        http_client.close()
    assert payload == [{"a": 10}]
    assert requests[0].url.path == "/fapi/v1/aggTrades"
    assert requests[0].url.params["symbol"] == "BTCUSDT"
    assert requests[0].url.params["fromId"] == "10"
    assert requests[0].url.params["limit"] == "1000"


def test_get_aggregate_trades_latest_omits_from_id():
    requests = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json=[])

    http_client = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinanceUsdMFuturesRestClient(http_client=http_client)
    try:
        assert client.get_aggregate_trades(symbol="ETHUSDT") == []
    finally:
        client.close()
        http_client.close()
    assert "fromId" not in requests[0].url.params
    assert requests[0].url.params["limit"] == "1000"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"symbol": ""},
        {"symbol": "BTC/USDT"},
        {"symbol": "BTCUSDT", "from_id": -1},
        {"symbol": "BTCUSDT", "from_id": True},
        {"symbol": "BTCUSDT", "limit": 0},
        {"symbol": "BTCUSDT", "limit": 1001},
    ],
)
def test_get_aggregate_trades_validates_arguments(kwargs):
    client = BinanceUsdMFuturesRestClient()
    try:
        with pytest.raises(ValueError):
            client.get_aggregate_trades(**kwargs)
    finally:
        client.close()


def test_get_aggregate_trades_rejects_non_array_and_non_object_rows():
    for payload in ({"code": 1}, [5]):
        http_client = httpx.Client(
            transport=httpx.MockTransport(lambda request, data=payload: httpx.Response(200, json=data))
        )
        client = BinanceUsdMFuturesRestClient(http_client=http_client)
        try:
            with pytest.raises(BinanceResponseError):
                client.get_aggregate_trades(symbol="BTCUSDT")
        finally:
            http_client.close()
