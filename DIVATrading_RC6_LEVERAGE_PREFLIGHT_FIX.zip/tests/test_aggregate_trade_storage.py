from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.core.database import Database, SCHEMA_VERSION
from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord, parse_aggregate_trade_rest_row
from divatrading.market_data.aggregate_trade_storage import (
    AggregateTradeIdentityConflict,
    AggregateTradeRepository,
    AggregateTradeStorageError,
    AggregateTradeStreamStateError,
)

NOW = datetime(2026, 11, 10, 1, 0, tzinfo=UTC)
BASE_MS = 1_800_000_000_000


def record(agg_id: int, *, source: str = "REST", time_ms: int = BASE_MS) -> AggregateTradeRecord:
    row = {
        "a": agg_id, "p": "100.000000000000000001", "q": "0.100000000000000001",
        "nq": "0.090000000000000001", "f": agg_id * 2, "l": agg_id * 2 + 1,
        "T": time_ms, "m": (agg_id % 2 == 0),
    }
    rec = parse_aggregate_trade_rest_row(row, symbol="BTCUSDT", received_at_utc=NOW)
    if source == "REST":
        return rec
    return AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=rec.aggregate_trade_id,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=time_ms, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="wss://fstream.binance.com/market/ws", received_at_utc=rec.received_at_utc,
    )


@pytest.fixture
def repo(tmp_path: Path):
    database = Database(tmp_path / "state.db")
    assert database.initialize() == SCHEMA_VERSION == 6
    return AggregateTradeRepository(database)


def test_schema_v6_preserves_trade_and_order_flow_tables_and_indexes(repo):
    with repo.database.connection() as connection:
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        indexes = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert {"aggregate_trades", "aggregate_trade_stream_state", "aggregate_trade_gaps", "order_flow_state", "order_flow_buckets"} <= tables
    assert "idx_aggregate_trades_symbol_time" in indexes


def test_decimal_persistence_round_trip_and_exact_primary_key(repo):
    assert repo.upsert_many([record(100)]) == 1
    assert repo.upsert_many([record(100)]) == 0
    saved = repo.read(symbol="BTCUSDT", from_id=100, through_id=100)[0].record
    assert str(saved.price) == "100.000000000000000001"
    assert str(saved.quantity) == "0.100000000000000001"
    assert saved.normal_quantity == Decimal("0.090000000000000001")
    assert saved.aggregate_trade_id == 100


def test_duplicate_identity_merges_rest_metadata_into_websocket_record(repo):
    repo.upsert_many([record(100, source="WEBSOCKET")])
    assert repo.upsert_many([record(100, source="REST")]) == 0
    saved = repo.read(symbol="BTCUSDT", from_id=100, through_id=100)[0].record
    assert saved.normal_quantity == Decimal("0.090000000000000001")
    assert saved.event_time_ms == BASE_MS
    with repo.database.connection() as connection:
        row = connection.execute("SELECT first_source_kind, last_source_kind FROM aggregate_trades").fetchone()
    assert row["first_source_kind"] == "WEBSOCKET"
    assert row["last_source_kind"] == "REST"


def test_immutable_payload_conflict_is_rejected_and_transaction_rolls_back(repo):
    repo.upsert_many([record(100)])
    conflicting = record(100)
    conflicting = AggregateTradeRecord(
        exchange=conflicting.exchange, symbol=conflicting.symbol,
        aggregate_trade_id=conflicting.aggregate_trade_id, price=Decimal("101"),
        quantity=conflicting.quantity, normal_quantity=conflicting.normal_quantity,
        first_trade_id=conflicting.first_trade_id, last_trade_id=conflicting.last_trade_id,
        event_time_ms=conflicting.event_time_ms, trade_time_ms=conflicting.trade_time_ms,
        buyer_is_maker=conflicting.buyer_is_maker, source_kind=conflicting.source_kind,
        source_endpoint=conflicting.source_endpoint, received_at_utc=conflicting.received_at_utc,
    )
    with pytest.raises(AggregateTradeIdentityConflict):
        repo.upsert_many([record(101), conflicting])
    assert [r.record.aggregate_trade_id for r in repo.read(symbol="BTCUSDT")] == [100]


def test_batches_are_bounded_and_single_symbol(repo):
    with pytest.raises(AggregateTradeStorageError, match="one exchange/symbol"):
        repo.upsert_many([record(1), AggregateTradeRecord(
            exchange="BINANCE_UM", symbol="ETHUSDT", aggregate_trade_id=2,
            price=Decimal("1"), quantity=Decimal("1"), normal_quantity=None,
            first_trade_id=2, last_trade_id=2, event_time_ms=None, trade_time_ms=BASE_MS,
            buyer_is_maker=False, source_kind="REST", source_endpoint="fixture",
            received_at_utc="2026-11-10T01:00:00.000Z",
        )])
    with pytest.raises(AggregateTradeStorageError, match="cannot exceed"):
        repo.upsert_many([record(i) for i in range(5001)])


def test_latest_bootstrap_creates_healthy_explicit_baseline(repo):
    state = repo.bootstrap_latest([record(100), record(101), record(102)])
    assert state.last_contiguous_aggregate_trade_id == 102
    assert state.latest_observed_aggregate_trade_id == 102
    assert state.status == "HEALTHY"
    with pytest.raises(AggregateTradeStreamStateError, match="cannot reset"):
        repo.bootstrap_latest([record(200), record(201)])


def test_from_id_registration_is_explicit_and_idempotent(repo):
    state = repo.register_from_id(symbol="btcusdt", start_from_id=500)
    assert state.last_contiguous_aggregate_trade_id == 499
    assert state.status == "BOOTSTRAPPING"
    assert repo.register_from_id(symbol="BTCUSDT", start_from_id=500).status == "BOOTSTRAPPING"
    with pytest.raises(AggregateTradeStreamStateError, match="different cursor"):
        repo.register_from_id(symbol="BTCUSDT", start_from_id=501)


def test_stream_rejects_websocket_ingestion_before_bootstrap(repo):
    from divatrading.market_data.aggregate_trade_storage import AggregateTradeStreamStateError
    with pytest.raises(AggregateTradeStreamStateError, match="must be bootstrapped"):
        repo.record_observed(record(1, source="WEBSOCKET"))


def test_record_observed_tracks_gap_then_advances_when_backfill_arrives(repo):
    repo.bootstrap_latest([record(100), record(101), record(102)])
    state = repo.record_observed(record(105, source="WEBSOCKET"))
    assert state.status == "DEGRADED"
    assert state.last_contiguous_aggregate_trade_id == 102
    assert state.unresolved_gap_from_id == 103
    assert state.unresolved_gap_to_id == 104
    state = repo.persist_recovered([record(103), record(104)], symbol="BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 105
    with repo.database.connection() as connection:
        gaps = connection.execute("SELECT status FROM aggregate_trade_gaps").fetchall()
    assert [row["status"] for row in gaps] == ["RESOLVED"]


def test_duplicate_and_out_of_order_observed_events_do_not_regress_cursor(repo):
    repo.bootstrap_latest([record(100), record(101), record(102)])
    state = repo.record_observed(record(101, source="WEBSOCKET"))
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 102


def test_unresolved_state_is_not_auto_cleared_by_later_event(repo):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(104, source="WEBSOCKET"))
    unresolved = repo.mark_unresolved(symbol="BTCUSDT", status="UNRESOLVED_RETENTION", reason="expired")
    assert unresolved.status == "UNRESOLVED"
    state = repo.record_observed(record(105, source="WEBSOCKET"))
    assert state.status == "UNRESOLVED"


def test_bounded_read_order_and_inclusive_range(repo):
    repo.upsert_many([record(i) for i in range(100, 110)])
    values = repo.read(symbol="BTCUSDT", from_id=103, through_id=107, limit=3)
    assert [r.record.aggregate_trade_id for r in values] == [103, 104, 105]
    with pytest.raises(AggregateTradeStorageError):
        repo.read(symbol="BTCUSDT", limit=5001)


def test_non_utc_received_timestamp_is_rejected(repo):
    source = record(1)
    invalid = AggregateTradeRecord(
        exchange=source.exchange, symbol=source.symbol,
        aggregate_trade_id=source.aggregate_trade_id, price=source.price,
        quantity=source.quantity, normal_quantity=source.normal_quantity,
        first_trade_id=source.first_trade_id, last_trade_id=source.last_trade_id,
        event_time_ms=source.event_time_ms, trade_time_ms=source.trade_time_ms,
        buyer_is_maker=source.buyer_is_maker, source_kind=source.source_kind,
        source_endpoint=source.source_endpoint, received_at_utc="2026-11-10T08:00:00+07:00",
    )
    with pytest.raises(AggregateTradeStorageError, match="UTC"):
        repo.upsert_many([invalid])


def test_contiguous_cursor_and_trade_rows_survive_database_reopen(repo, tmp_path: Path):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(102, source="WEBSOCKET"))
    reopened = AggregateTradeRepository(Database(tmp_path / "state.db"))
    state = reopened.get_stream_state("BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 102
    assert [row.record.aggregate_trade_id for row in reopened.read(symbol="BTCUSDT")] == [100, 101, 102]


def test_manual_retention_prunes_only_oldest_rows_on_healthy_stream(repo):
    repo.bootstrap_latest([record(i) for i in range(100, 110)])
    removed = repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=4)
    assert removed == 6
    assert [r.record.aggregate_trade_id for r in repo.read(symbol="BTCUSDT")] == [106, 107, 108, 109]
    state = repo.get_stream_state("BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 109


def test_retention_pruning_is_blocked_when_stream_has_a_gap(repo):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(104, source="WEBSOCKET"))
    with pytest.raises(AggregateTradeStreamStateError, match="not HEALTHY"):
        repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=1)


def test_retention_pruning_validates_bound(repo):
    repo.bootstrap_latest([record(100)])
    with pytest.raises(AggregateTradeStorageError, match="keep_latest_rows"):
        repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=0)
