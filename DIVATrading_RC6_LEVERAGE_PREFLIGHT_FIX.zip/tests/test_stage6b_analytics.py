import hashlib
import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from divatrading.replay.analytics import ReplayAnalyticsError, analyze_replay_ledger


SHA_A = hashlib.sha256(b"A").hexdigest()
SHA_B = hashlib.sha256(b"B").hexdigest()
SHA_C = hashlib.sha256(b"C").hexdigest()
SHA_D = hashlib.sha256(b"D").hexdigest()
SHA_E = hashlib.sha256(b"E").hexdigest()


def _ledger_record(record_type, sequence, known_at, payload, timeframe="1m", stage="STAGE_TEST"):
    return {
        "record_schema_version": 1,
        "record_type": record_type,
        "replay_run_id": SHA_A,
        "replay_capture_id": hashlib.sha256(f"{sequence}".encode()).hexdigest(),
        "capture_sequence": sequence,
        "dataset_id": SHA_B,
        "symbol": "BTCUSDT",
        "timeframe": timeframe,
        "stage": stage,
        "known_at_time_ms": known_at,
        "metadata_sha256": SHA_C,
        "payload": {"record_type": record_type, **payload},
    }


def _build_ledger(path: Path):
    start, end = 0, 5_400_000
    header = {
        "record_schema_version": 1,
        "record_type": "REPLAY_RUN_HEADER",
        "replay_run_id": SHA_A,
        "dataset_id": SHA_B,
        "symbol": "BTCUSDT",
        "software_version": "0.32.0",
        "config_sha256": SHA_D,
        "code_sha256": SHA_E,
        "metadata_sha256": SHA_C,
        "metadata_quality": "HISTORICAL_EFFECTIVE",
        "dataset_window": {"start_open_time_ms": start, "end_open_time_ms_exclusive": end},
        "strict_metadata": True,
        "max_history_candles": 1000,
        "clock_policy": "UTC_KLINE_CLOSE_PLUS_1MS_V1",
        "closed_bar_rule": "close_time_ms < captured_at_ms",
        "stages": ["STAGE_1_ADAPTER", "STAGE_2_STRUCTURE", "STAGE_3_OB_FORMATION", "STAGE_4_OB_LIFECYCLE", "STAGE_5_LIQUIDITY_FVG"],
        "config": {},
        "source_files": [
            {"interval": "1m", "path": "M1.csv", "sha256": SHA_B, "row_count": 90},
            {"interval": "5m", "path": "M5.csv", "sha256": SHA_D, "row_count": 18},
        ],
    }
    rows = [header]
    captures = [(1, 60_000, ["1m"]), (2, 3_300_000, ["1m"]), (3, 4_500_000, ["1m", "5m"]), (4, end, ["1m", "5m"])]
    for sequence, timestamp, updated in captures:
        if sequence == 1:
            rows.append(_ledger_record("BAR_TRACE", sequence, timestamp, {
                "bar_open_time_ms": timestamp - 60_000,
                "new_pivots": [{"pivot_id": "p1"}],
                "events": [{"event_type": "BOS", "layer": "SWING"}],
            }))
        if sequence == 2:
            rows.append(_ledger_record("OB_FORMATION_TRACE", sequence, timestamp, {
                "outcome": "REJECTED", "reason_codes": ["DISPLACEMENT_TOO_WEAK"],
                "displacement": {"break_body_range_ratio": "0.5", "close_extension_ticks": "4", "leg_body_range_ratio": "0.6", "directional_leg_candle_count": 3},
            }))
        if sequence == 3:
            rows.append(_ledger_record("OB_FORMATION_TRACE", sequence, timestamp, {
                "outcome": "CREATED", "reason_codes": ["OB_CANDIDATE_CREATED"],
                "candidate_id": "ob-1", "displacement": {"break_body_range_ratio": "0.7", "close_extension_ticks": "6", "leg_body_range_ratio": "0.8", "directional_leg_candle_count": 4},
            }))
            rows.append(_ledger_record("ORDER_BLOCK_CANDIDATE", sequence, timestamp, {"candidate_id": "ob-1"}))
            rows.append(_ledger_record("ORDER_BLOCK_LIFECYCLE", sequence, timestamp, {
                "candidate": {"candidate_id": "ob-1"}, "status": "ACTIVE_FRESH", "age_bars": 2,
                "maximum_mitigation_depth_ratio": "0.1",
            }))
            rows.append(_ledger_record("LIQUIDITY_REFERENCE", sequence, timestamp, {"reference_id": "ref-1", "kind": "SWING_HIGH"}, "5m", "STAGE_5_LIQUIDITY_FVG"))
            rows.append(_ledger_record("LIQUIDITY_SWEEP", sequence, timestamp, {
                "evidence_id": "sw-1", "outcome": "CLOSE_BACK", "qualifies_as_sweep": True,
            }, "5m", "STAGE_5_LIQUIDITY_FVG"))
            rows.append(_ledger_record("FVG", sequence, timestamp, {
                "fvg_id": "fvg-1", "direction": 1, "status": "ACTIVE", "maximum_fill_ratio": "0.2",
                "confirmation_time_ms": timestamp - 300_000, "first_touch_time_ms": None, "fill_time_ms": None,
            }, "5m", "STAGE_5_LIQUIDITY_FVG"))
        if sequence == 4:
            rows.append(_ledger_record("OB_LIFECYCLE_TRACE", sequence, timestamp, {
                "candidate_id": "ob-1", "transition": "TOUCH", "to_status": "TOUCHED", "reason_code": "ZONE_TOUCH", "age_bars": 4,
            }))
            rows.append(_ledger_record("ORDER_BLOCK_LIFECYCLE", sequence, timestamp, {
                "candidate": {"candidate_id": "ob-1"}, "status": "TOUCHED", "age_bars": 4,
                "maximum_mitigation_depth_ratio": "0.3",
            }))
            rows.append(_ledger_record("FVG", sequence, timestamp, {
                "fvg_id": "fvg-1", "direction": 1, "status": "PARTIALLY_FILLED", "maximum_fill_ratio": "0.75",
                "confirmation_time_ms": 4_200_000, "first_touch_time_ms": 4_500_000, "fill_time_ms": None,
            }, "5m", "STAGE_5_LIQUIDITY_FVG"))
        capture_id = hashlib.sha256(f"{sequence}".encode()).hexdigest()
        rows.append(_ledger_record("REPLAY_CAPTURE_SUMMARY", sequence, timestamp, {
            "updated_intervals": updated, "capture_sequence": sequence,
            "captured_at_ms": timestamp, "replay_capture_id": capture_id,
        }, None, "REPLAY_CONTROL"))
    rows.append({
        "record_schema_version": 1,
        "record_type": "REPLAY_RUN_SUMMARY",
        "replay_run_id": SHA_A,
        "dataset_id": SHA_B,
        "capture_count": len(captures),
        "gap_count": 0,
        "last_capture_time_ms": end,
        "right_censored_ob_count": 1,
        "right_censored_fvg_count": 1,
        "interpretation": "EVIDENCE_ONLY_NO_FILL_PNL_OR_PROFITABILITY_INFERENCE",
    })
    path.write_text("".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows), encoding="utf-8")


def test_analytics_validates_ledger_splits_and_entity_snapshots(tmp_path):
    ledger = tmp_path / "replay.jsonl"
    _build_ledger(ledger)
    original = ledger.read_bytes()
    report = analyze_replay_ledger(ledger)
    assert ledger.read_bytes() == original
    assert report["analysis_window"]["end_ms_exclusive"] == 5_400_001
    assert report["split_plan"]["target_ratios"] == ["0.60", "0.20", "0.20"]
    assert report["split_plan"]["splits"][2]["test_status"] == "OPENED_AFTER_FREEZE"
    assert report["state_policy"] == "ONE_CONTINUOUS_REPLAY_NO_SPLIT_RESET"
    train, validation, test = report["metrics_by_split"]
    assert train["market_structure"]["pivot_count"] == 1
    assert validation["rejection_reason_counts"] == [{"reason_code": "DISPLACEMENT_TOO_WEAK", "count": 1}]
    assert test["ob_lifecycle"]["unique_entities_observed_by_split_end"] == 1
    assert test["ob_lifecycle"]["status_counts_at_split_end"] == {"TOUCHED": 1}
    assert test["liquidity_fvg"]["status_counts_at_split_end"] == {"PARTIALLY_FILLED": 1}
    assert test["liquidity_fvg"]["unique_fvgs_observed_in_split"] == 1
    assert test["right_censored"] == {
        "ob_count": 1, "fvg_count": 1,
        "censoring_policy": "ADMINISTRATIVE_AT_SPLIT_END_NOT_TRADE_FAILURE",
    }
    assert test["closed_bars_by_timeframe"] == {"1m": 2, "5m": 2}
    schema_path = Path(__file__).resolve().parents[1] / "docs" / "schemas" / "stage6b_evidence_analytics_report.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(report)
    hash_value = report.pop("report_sha256")
    from divatrading.replay.manifest import canonical_json, sha256_text
    assert hash_value == sha256_text(canonical_json(report))


def test_analytics_rejects_truncated_and_reordered_ledgers(tmp_path):
    ledger = tmp_path / "replay.jsonl"
    _build_ledger(ledger)
    rows = ledger.read_text(encoding="utf-8").splitlines()
    ledger.write_text("\n".join(rows[:-1]) + "\n", encoding="utf-8")
    with pytest.raises(ReplayAnalyticsError, match="end with REPLAY_RUN_SUMMARY"):
        analyze_replay_ledger(ledger)
    _build_ledger(ledger)
    rows = ledger.read_text(encoding="utf-8").splitlines()
    first = json.loads(rows[1])
    second = json.loads(rows[2])
    first["capture_sequence"] = 3
    second["capture_sequence"] = 2
    rows[1], rows[2] = json.dumps(first), json.dumps(second)
    ledger.write_text("\n".join(rows) + "\n", encoding="utf-8")
    with pytest.raises(ReplayAnalyticsError, match="gap|reordered"):
        analyze_replay_ledger(ledger)


def test_analytics_rejects_mixed_run_identity(tmp_path):
    ledger = tmp_path / "replay.jsonl"
    _build_ledger(ledger)
    rows = ledger.read_text(encoding="utf-8").splitlines()
    item = json.loads(rows[1])
    item["replay_run_id"] = SHA_D
    rows[1] = json.dumps(item)
    ledger.write_text("\n".join(rows) + "\n", encoding="utf-8")
    with pytest.raises(ReplayAnalyticsError, match="mixed replay_run_id"):
        analyze_replay_ledger(ledger)


def test_replay_analyze_cli_writes_schema_validated_report(tmp_path, capsys):
    from divatrading.cli import main

    ledger = tmp_path / "replay.jsonl"
    report_path = tmp_path / "analytics.json"
    _build_ledger(ledger)
    assert main(["replay-analyze", "--ledger", str(ledger), "--report", str(report_path)]) == 0
    assert "Replay evidence analytics completed" in capsys.readouterr().out
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["report_type"] == "REPLAY_EVIDENCE_ANALYTICS"
    assert report["provenance"]["ledger_sha256"] == hashlib.sha256(ledger.read_bytes()).hexdigest()


def test_replay_analyze_cli_rejects_non_frozen_split_ratios(tmp_path, capsys):
    from divatrading.cli import main

    ledger = tmp_path / "replay.jsonl"
    _build_ledger(ledger)
    code = main([
        "replay-analyze", "--ledger", str(ledger), "--report", str(tmp_path / "report.json"),
        "--split-ratios", "70/15/15",
    ])
    assert code == 2
    assert "only the frozen 60/20/20" in capsys.readouterr().err
