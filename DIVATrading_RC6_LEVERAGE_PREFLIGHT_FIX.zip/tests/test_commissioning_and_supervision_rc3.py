"""Regression tests for effective Stage C risk and account-task failure isolation."""
from __future__ import annotations

import asyncio
import json
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.strategy.scalping_market_data import InstrumentSpec
from divatrading.trading.commissioning import TestnetCommissioningCaps
from divatrading.trading.coordinator import MultiPairExecutionCoordinator, PortfolioSnapshot
from divatrading.trading.models import QualifiedSignal
from divatrading.trading.risk import PortfolioRiskManager, PortfolioRiskConfig
from divatrading.core.runtime_supervision import run_with_account_supervision

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def _trade_signal() -> QualifiedSignal:
    return QualifiedSignal(
        signal_id="rc3-risk-test", symbol="BTCUSDT", side="LONG", entry_type="LIMIT",
        entry_price=Decimal("50000"), stop_loss=Decimal("49900"),
        take_profit=Decimal("50300"), timeframe="5m", strategy_id="SMC_V2",
        created_at_ms=1794400000000,
    )


def _stage_c(tmp_path: Path, risk_config: PortfolioRiskConfig) -> tuple[ExecutionLedger, MultiPairExecutionCoordinator]:
    metadata = parse_exchange_info(json.loads(FIXTURE.read_text()), source_endpoint="fixture")
    info = metadata.get_symbol("BTCUSDT")
    assert info is not None
    ledger = ExecutionLedger(tmp_path / "stage-c-rc3.sqlite")

    class NoNetworkClient:
        environment = "TESTNET"
        def __getattr__(self, name):
            raise AssertionError("No exchange I/O permitted before risk admission")

    execution = ExecutionService(
        ledger, config=ExecutionConfig(
            mode=ExecutionMode.TESTNET, enable_testnet_orders=True,
            enable_testnet_stage_c=True,
        ), client=NoNetworkClient(),
    )
    manager = PortfolioRiskManager(risk_config)
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": InstrumentSpec.from_symbol_info(info)},
        risk_manager=manager, execution_service=execution, ledger=ledger,
        testnet_commissioning_caps=TestnetCommissioningCaps(),
    )
    return ledger, coordinator


def _snapshot(equity: str = "1000") -> PortfolioSnapshot:
    return PortfolioSnapshot(
        equity_usdt=Decimal(equity), open_risk_usdt=Decimal("0"),
        active_position_count=0, symbol_notional_usdt={},
        captured_at_ms=1794400000000, source="TESTNET_READ_ONLY",
        available_margin_usdt=Decimal(equity),
    )


def test_default_operator_percent_above_testnet_cap_is_rejected_before_order(tmp_path):
    ledger, coordinator = _stage_c(tmp_path, PortfolioRiskConfig())
    outcome = coordinator.route(_trade_signal(), _snapshot())
    assert not outcome.risk.accepted
    assert outcome.risk.reason == "TESTNET_COMMISSIONING_PORTFOLIO_RISK_CAP_EXCEEDED"
    assert ledger.get_intent("rc3-risk-test") is None
    assert ledger.get_risk_reservation("rc3-risk-test") is None


def test_persisted_percent_change_checked_at_route_not_just_startup(tmp_path):
    config = PortfolioRiskConfig(risk_per_trade_pct=Decimal("0.05"), max_portfolio_open_risk_pct=Decimal("0.25"))
    ledger, coordinator = _stage_c(tmp_path, config)
    # Simulates a Telegram persisted override after the initial CLI argument check.
    coordinator.risk_manager.config = PortfolioRiskConfig(
        risk_per_trade_pct=Decimal("0.20"), max_portfolio_open_risk_pct=Decimal("0.25"),
    )
    outcome = coordinator.route(_trade_signal(), _snapshot())
    assert outcome.risk.reason == "TESTNET_COMMISSIONING_TRADE_RISK_CAP_EXCEEDED"
    assert ledger.get_intent("rc3-risk-test") is None


def test_fixed_usdt_risk_must_fit_fresh_equity_before_order(tmp_path):
    config = PortfolioRiskConfig(
        risk_per_trade_pct=Decimal("0.01"), risk_per_trade_fixed_usdt=Decimal("2"),
        max_portfolio_open_risk_pct=Decimal("0.25"),
    )
    ledger, coordinator = _stage_c(tmp_path, config)
    assert TestnetCommissioningCaps().violation(config, equity_usdt=None) == \
        "TESTNET_COMMISSIONING_FIXED_RISK_EQUITY_REQUIRED"
    assert TestnetCommissioningCaps().violation(config, equity_usdt=Decimal("3000")) is None
    outcome = coordinator.route(_trade_signal(), _snapshot("1000"))
    assert outcome.risk.reason == "TESTNET_COMMISSIONING_FIXED_RISK_CAP_EXCEEDED"
    assert ledger.get_intent("rc3-risk-test") is None


@pytest.mark.asyncio
async def test_account_supervisor_exception_halts_new_entries_and_stops_market():
    stop = asyncio.Event()
    halted = []
    market_finished = asyncio.Event()

    async def market_runner(stop_event):
        try:
            await stop_event.wait()
        finally:
            market_finished.set()

    async def account_runner():
        await asyncio.sleep(0.005)
        raise OSError("simulated user stream failure")

    account_task = asyncio.create_task(account_runner())
    with pytest.raises(RuntimeError, match="Account supervisor failed") as exc:
        await asyncio.wait_for(run_with_account_supervision(
            market_runner, account_task, stop, halted.append,
        ), timeout=1)
    assert isinstance(exc.value.__cause__, OSError)
    assert stop.is_set() and market_finished.is_set()
    assert halted == ["AUTONOMOUS_ACCOUNT_SUPERVISOR_STOPPED"]


@pytest.mark.asyncio
async def test_account_supervisor_clean_early_return_also_halts_market():
    stop = asyncio.Event()
    halted = []

    async def market_runner(stop_event):
        await stop_event.wait()

    async def account_runner():
        await asyncio.sleep(0.005)

    account_task = asyncio.create_task(account_runner())
    with pytest.raises(RuntimeError, match="stopped unexpectedly"):
        await asyncio.wait_for(run_with_account_supervision(
            market_runner, account_task, stop, halted.append,
        ), timeout=1)
    assert stop.is_set()
    assert len(halted) == 1


@pytest.mark.asyncio
async def test_graceful_market_shutdown_does_not_latch_account_failure():
    stop = asyncio.Event()
    halted = []

    async def market_runner(stop_event):
        stop_event.set()

    async def account_runner():
        await stop.wait()

    account_task = asyncio.create_task(account_runner())
    try:
        await asyncio.wait_for(run_with_account_supervision(
            market_runner, account_task, stop, halted.append,
        ), timeout=1)
    finally:
        await asyncio.gather(account_task, return_exceptions=True)
    assert halted == []
