from __future__ import annotations

import asyncio
import threading
import time
from collections import deque
from decimal import Decimal
from types import SimpleNamespace

import pytest

from divatrading.market_data.order_book import (
    DepthEvent, DepthLevel, DepthSnapshot, OrderBookNotReady, OrderBookQueueFullError,
)
from divatrading.market_data.order_book_supervisor import BinanceOrderBookSupervisor

NOW = 1_800_000_000_000


def event(symbol: str = "BTCUSDT", *, first: int = 99, final: int = 101,
          previous: int | None = None, t: int = NOW) -> DepthEvent:
    return DepthEvent(
        symbol, first, final, previous, t, t,
        (DepthLevel(Decimal("100"), Decimal("2")),),
        (), f"{symbol.lower()}@depth@100ms",
        __import__("datetime").datetime.now(__import__("datetime").UTC),
    )


def snapshot(symbol: str = "BTCUSDT", last: int = 100) -> DepthSnapshot:
    return DepthSnapshot(
        symbol, last,
        (DepthLevel(Decimal("99"), Decimal("2")),),
        (DepthLevel(Decimal("101"), Decimal("3")),),
    )


class FakeFeed:
    def __init__(self, symbols=("BTCUSDT",), *, queue_capacity=16):
        self.symbols = tuple(symbols)
        self.events = asyncio.Queue(maxsize=queue_capacity)
        self.max_event_age_ms = 3000
        self.is_connected = False
        self.stats = SimpleNamespace(connection_count=0, queue_overflows=0)
        self.fail: Exception | None = None

    async def get_event(self):
        return await self.events.get()

    async def run(self, stop_event):
        self.is_connected = True
        self.stats.connection_count += 1
        try:
            await stop_event.wait()
            if self.fail is not None:
                raise self.fail
        finally:
            self.is_connected = False


class FakeSnapshots:
    def __init__(self, values=None, *, delay=0.0, error=None):
        self.values = deque(values or [snapshot()])
        self.delay = delay
        self.error = error
        self.calls = []
        self.active = 0
        self.max_active = 0
        self.lock = threading.Lock()

    def fetch(self, symbol):
        with self.lock:
            self.active += 1
            self.max_active = max(self.max_active, self.active)
            self.calls.append(symbol)
        try:
            if self.delay:
                time.sleep(self.delay)
            if self.error:
                raise self.error
            if self.values:
                value = self.values.popleft()
                if isinstance(value, Exception):
                    raise value
                return DepthSnapshot(symbol, value.last_update_id, value.bids, value.asks,
                                     value.event_time_ms, value.transaction_time_ms)
            return snapshot(symbol)
        finally:
            with self.lock:
                self.active -= 1


async def wait_until(predicate, timeout=1.5):
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        if predicate():
            return
        await asyncio.sleep(0.005)
    raise AssertionError("condition not reached before timeout")


async def start_supervisor(feed=None, snapshots=None, **kwargs):
    feed = feed or FakeFeed()
    snapshots = snapshots or FakeSnapshots()
    clock = [NOW]
    supervisor = BinanceOrderBookSupervisor(
        feed=feed, snapshot_client=snapshots, wall_clock_ms=lambda: clock[0], **kwargs
    )
    stop = asyncio.Event()
    task = asyncio.create_task(supervisor.run(stop))
    await wait_until(lambda: feed.is_connected)
    return supervisor, feed, snapshots, clock, stop, task


async def stop_supervisor(stop, task):
    stop.set()
    await asyncio.wait_for(task, timeout=1.5)


@pytest.mark.asyncio
async def test_cold_start_buffers_before_snapshot_and_exposes_ready_metrics():
    supervisor, feed, rest, _, stop, task = await start_supervisor()
    try:
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        health = supervisor.health("BTCUSDT")
        assert health.connection_state == "CONNECTED"
        assert health.snapshot_state == "READY"
        assert health.sequence_integrity and health.event_fresh and health.queue_healthy
        assert supervisor.metrics("BTCUSDT").update_id == 101
        assert rest.calls == ["BTCUSDT"]
    finally:
        await stop_supervisor(stop, task)
    assert not supervisor.health("BTCUSDT").ready
    assert supervisor.health("BTCUSDT").invalid_reason == "SUPERVISOR_STOPPED"


@pytest.mark.asyncio
async def test_sequence_gap_invalidates_metrics_then_resynchronizes():
    rest = FakeSnapshots([snapshot(last=100), snapshot(last=200), snapshot(last=200)])
    supervisor, feed, _, _, stop, task = await start_supervisor(snapshots=rest)
    try:
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        await feed.events.put(event(first=102, final=103, previous=99))
        await wait_until(lambda: not supervisor.health("BTCUSDT").ready)
        with pytest.raises(OrderBookNotReady):
            supervisor.metrics("BTCUSDT")
        await feed.events.put(event(first=199, final=201))
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        assert supervisor.metrics("BTCUSDT").update_id == 201
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_disconnect_and_reconnect_immediately_invalidate_every_symbol():
    feed = FakeFeed(("BTCUSDT", "ETHUSDT"))
    rest = FakeSnapshots([snapshot(last=100), snapshot(last=100), snapshot(last=200), snapshot(last=200)])
    supervisor, _, _, _, stop, task = await start_supervisor(feed=feed, snapshots=rest)
    try:
        await feed.events.put(event("BTCUSDT"))
        await feed.events.put(event("ETHUSDT"))
        await wait_until(lambda: supervisor.is_ready)
        feed.is_connected = False
        assert not supervisor.health("BTCUSDT").ready
        assert not supervisor.health("ETHUSDT").ready
        feed.stats.connection_count += 1
        feed.is_connected = True
        assert not supervisor.health("BTCUSDT").ready
        assert not supervisor.health("ETHUSDT").ready
        await feed.events.put(event("BTCUSDT", first=199, final=201))
        await feed.events.put(event("ETHUSDT", first=199, final=201))
        await wait_until(lambda: supervisor.is_ready)
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_stale_book_is_invalidated_and_metrics_are_blocked():
    supervisor, feed, _, clock, stop, task = await start_supervisor()
    try:
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        clock[0] += 4000
        health = supervisor.health("BTCUSDT")
        assert not health.ready
        assert not health.event_fresh
        with pytest.raises(OrderBookNotReady):
            supervisor.metrics("BTCUSDT")
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_queue_high_watermark_blocks_readiness_until_drained():
    feed = FakeFeed(queue_capacity=4)
    supervisor, _, _, _, stop, task = await start_supervisor(feed=feed)
    try:
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        for _ in range(3):
            await feed.events.put(event(first=101, final=101, previous=101))
        health = supervisor.health("BTCUSDT")
        assert not health.queue_healthy
        assert not health.ready
        with pytest.raises(OrderBookNotReady):
            supervisor.metrics("BTCUSDT")
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_snapshot_calls_are_serialized_across_symbols():
    feed = FakeFeed(("BTCUSDT", "ETHUSDT"))
    rest = FakeSnapshots([snapshot("BTCUSDT"), snapshot("ETHUSDT")], delay=0.03)
    supervisor, _, _, _, stop, task = await start_supervisor(feed=feed, snapshots=rest)
    try:
        await feed.events.put(event("BTCUSDT"))
        await feed.events.put(event("ETHUSDT"))
        await wait_until(lambda: supervisor.is_ready)
        assert rest.max_active == 1
        assert set(rest.calls) == {"BTCUSDT", "ETHUSDT"}
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_snapshot_failure_budget_is_bounded_and_new_event_rearms_resync():
    rest = FakeSnapshots([TimeoutError("snapshot timeout"), TimeoutError("snapshot timeout"), snapshot()])
    supervisor, feed, _, _, stop, task = await start_supervisor(
        snapshots=rest, max_resync_attempts=2, resync_retry_seconds=0.05
    )
    try:
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").snapshot_state == "ERROR")
        assert len(rest.calls) == 2
        assert not supervisor.health("BTCUSDT").ready
        await feed.events.put(event())
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        assert len(rest.calls) == 3
    finally:
        await stop_supervisor(stop, task)


@pytest.mark.asyncio
async def test_feed_failure_invalidates_all_symbols_and_propagates():
    class CrashFeed(FakeFeed):
        def __init__(self):
            super().__init__()
            self.crash = asyncio.Event()

        async def run(self, stop_event):
            self.is_connected = True
            self.stats.connection_count += 1
            try:
                await self.crash.wait()
                raise OrderBookQueueFullError("overflow")
            finally:
                self.is_connected = False

    feed = CrashFeed()
    supervisor = BinanceOrderBookSupervisor(feed=feed, snapshot_client=FakeSnapshots(), wall_clock_ms=lambda: NOW)
    stop = asyncio.Event()
    task = asyncio.create_task(supervisor.run(stop))
    await wait_until(lambda: feed.is_connected)
    await feed.events.put(event())
    await wait_until(lambda: supervisor.health("BTCUSDT").ready)
    feed.crash.set()
    with pytest.raises(Exception, match="Depth feed terminated"):
        await asyncio.wait_for(task, timeout=1.5)
    assert not supervisor.health("BTCUSDT").ready


@pytest.mark.asyncio
async def test_initial_buffer_overflow_discards_old_batch_and_rebuilds():
    class BlockingSnapshots:
        def __init__(self):
            self.started = threading.Event()
            self.release = threading.Event()
            self.calls = 0

        def fetch(self, symbol):
            self.calls += 1
            self.started.set()
            self.release.wait(timeout=1.0)
            return snapshot(symbol)

    rest = BlockingSnapshots()
    supervisor, feed, _, _, stop, task = await start_supervisor(
        snapshots=rest, max_buffered_events=1
    )
    try:
        await feed.events.put(event())
        await wait_until(rest.started.is_set)
        await feed.events.put(event())
        await wait_until(lambda: "overflow" in (supervisor.health("BTCUSDT").last_error or "").lower())
        assert supervisor.health("BTCUSDT").buffered_events <= 1
        rest.release.set()
        await wait_until(lambda: supervisor.health("BTCUSDT").ready)
        assert rest.calls == 1
    finally:
        rest.release.set()
        await stop_supervisor(stop, task)


def test_constructor_rejects_unbounded_or_invalid_limits():
    feed = FakeFeed()
    with pytest.raises(ValueError):
        BinanceOrderBookSupervisor(feed=feed, snapshot_client=FakeSnapshots(), max_buffered_events=10001)
    with pytest.raises(ValueError):
        BinanceOrderBookSupervisor(feed=feed, snapshot_client=FakeSnapshots(), max_resync_attempts=21)
    with pytest.raises(ValueError):
        BinanceOrderBookSupervisor(feed=feed, snapshot_client=FakeSnapshots(), resync_retry_seconds=0)
