from __future__ import annotations

from dataclasses import FrozenInstanceError, asdict
from decimal import Decimal
import json

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcObScoreTrace,
    PineSmcObScoringTrace,
    PineSmcReplayError,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
)
from divatrading.strategy.pine_smc_structure import (
    PineSmcIndicatorTrace,
    PineSmcTriggerSweepTrace,
    _PineOrderBlockState,
    _PineSmcState,
)

BASE_TIME_MS = 1_700_000_000_000


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 10,
        "internal_len": 1,
        "use_volatility_regime": False,
        "use_trend_filter": False,
        "use_pd_filter": False,
        "tick_size": Decimal("0.1"),
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def _kline(
    index: int,
    *,
    open_price: str,
    high: str,
    low: str,
    close: str,
    volume: str = "10",
) -> Kline:
    interval = "1m"
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            volume,
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def _ob(
    index: int = 0,
    *,
    bias: int = 1,
    top: float = 105.0,
    bottom: float = 95.0,
    break_index: int = 1,
    used: bool = False,
    has_fvg: bool = True,
) -> _PineOrderBlockState:
    return _PineOrderBlockState(
        top=top,
        bottom=bottom,
        bar_local_index=index,
        break_local_index=break_index,
        source_time_ms=BASE_TIME_MS + index * 60_000,
        break_time_ms=BASE_TIME_MS + break_index * 60_000,
        bias=bias,
        has_fvg=has_fvg,
        used=used,
    )


def _indicators(
    *,
    atr_fast: float | None = 10.0,
    rsi: float | None = 58.0,
    volume_avg: float | None = 10.0,
) -> PineSmcIndicatorTrace:
    return PineSmcIndicatorTrace(
        atr_fast_now=atr_fast,
        rsi_now=rsi,
        volume_avg_now=volume_avg,
        di_plus_now=20.0,
        di_minus_now=10.0,
        adx_now=25.0,
        atr200_ratio_base=1.0,
        atr_ratio_now=1.0,
        volatility_extreme=False,
        volatility_choppy=False,
    )


def _history() -> list[Kline]:
    return [
        _kline(0, open_price="103", high="105", low="95", close="97"),
        _kline(1, open_price="108", high="116", low="106", close="115"),
        _kline(2, open_price="99", high="103", low="97", close="101"),
    ]


def _score(
    *,
    bias: int = 1,
    near: float = 0.50,
    deep: float = 0.80,
    tick_size: float = 0.1,
    atr_slow: float = 10.0,
    atr_fast: float | None = 10.0,
    rsi: float | None = 58.0,
    volume_avg: float | None = 10.0,
    swing_trend: int = 1,
    internal_trend: int = 0,
    has_fvg: bool = True,
    prior_lowest: float | None = 98.0,
    prior_highest: float | None = 102.0,
) -> PineSmcObScoreTrace:
    engine = PineSmcStructureEngine(_config(entry_depth_near=near, entry_depth_deep=deep, tick_size=tick_size))
    history = _history()
    state_ob = _ob(bias=bias, has_fvg=has_fvg)
    return engine._score_order_block(
        active_array_index=0,
        ob=state_ob,
        history=history,
        current=history[-1],
        local_index=2,
        max_age=300,
        swing_trend=swing_trend,
        internal_trend=internal_trend,
        atr_slow=atr_slow,
        atr_fast=atr_fast,
        rsi_now=rsi,
        volume_average=volume_avg,
        prior_lowest_sweep=prior_lowest,
        prior_highest_sweep=prior_highest,
        tick_size=tick_size,
    )


def test_stage7_config_tick_size_is_optional_but_validated_and_depths_match_pine_inputs() -> None:
    assert _config().tick_size == 0.1
    assert _config(tick_size=None).tick_size is None
    assert _config(entry_depth_near=0.75, entry_depth_deep=0.95).entry_depth_deep == 0.95

    for invalid in (0, -1, True, float("nan"), float("inf"), "0.1"):
        with pytest.raises(PineSmcReplayError, match="tick_size"):
            _config(tick_size=invalid)
    for name, invalid in (
        ("entry_depth_near", 0.19),
        ("entry_depth_near", 0.76),
        ("entry_depth_deep", 0.24),
        ("entry_depth_deep", 0.96),
        ("entry_depth_deep", True),
    ):
        with pytest.raises(PineSmcReplayError, match=name):
            _config(**{name: invalid})


def test_missing_tick_size_fails_closed_for_scoring_but_does_not_break_prior_stages() -> None:
    engine = PineSmcStructureEngine(_config(tick_size=None))
    history = _history()
    state = _PineSmcState(local_index=2)
    state.active_order_blocks.append(_ob())
    trigger = PineSmcTriggerSweepTrace(
        trigger_mode="Either",
        require_sweep=False,
        chosen_active_array_index=0,
        chosen_trigger_code=1,
    )
    result = engine._evaluate_ob_scoring(
        state=state,
        history=history,
        candle=history[-1],
        indicators=_indicators(),
        trigger_sweep=trigger,
        prior_lowest_sweep=98.0,
        prior_highest_sweep=102.0,
    )
    assert result.available is False
    assert result.unavailable_reason and "PRICE_FILTER.tickSize" in result.unavailable_reason
    assert result.active_order_block_scores == ()
    assert result.chosen_active_array_index == 0
    assert result.chosen_score is None


def test_bullish_entry_band_and_source_derived_quality_weights_are_exact() -> None:
    result = _score()
    # Bullish entry band is measured downward from the OB's top.
    assert result.entry_band_low == pytest.approx(97.0)
    assert result.entry_band_high == pytest.approx(100.0)

    assert result.volatility_score == pytest.approx(100.0)
    assert result.displacement_score == pytest.approx(50.0)
    # Source candle: 60% body + 20% lower rejection wick.
    assert result.source_candle_score == pytest.approx(48.0)
    assert result.rsi_score == pytest.approx(100.0)
    assert result.trend_score == pytest.approx(75.25)
    assert result.fvg_score == pytest.approx(100.0)
    assert result.volume_score == pytest.approx(50.0)
    assert result.freshness_score == pytest.approx(100.0 - 70.0 / 300.0)
    assert result.swept_current_candle is True
    assert result.sweep_score == pytest.approx(100.0)
    assert result.current_candle_score == pytest.approx(50.0 * (4.0 / 6.0) + 50.0)
    assert result.proximity_score == pytest.approx(90.0)

    expected_quality = (
        50.0 * 16.0
        + 48.0 * 12.0
        + 100.0 * 10.0
        + 100.0 * 12.0
        + 75.25 * 12.0
        + 100.0 * 8.0
        + 50.0 * 6.0
        + (100.0 - 70.0 / 300.0) * 6.0
        + 100.0 * 8.0
    ) / 90.0
    expected_timing = result.current_candle_score * 0.45 + 90.0 * 0.55
    assert result.ob_quality_score == pytest.approx(expected_quality)
    assert result.timing_score == pytest.approx(expected_timing)
    assert result.setup_score == pytest.approx(expected_quality * 0.80 + expected_timing * 0.20)


def test_bearish_entry_band_uses_bottom_and_directional_sweep_score() -> None:
    result = _score(
        bias=-1,
        swing_trend=-1,
        internal_trend=-1,
        prior_lowest=96.0,
        prior_highest=102.0,
    )
    assert result.entry_band_low == pytest.approx(100.0)
    assert result.entry_band_high == pytest.approx(103.0)
    # Current bar high=103 > prior highest=102 and close=101 < 102.
    assert result.swept_current_candle is True
    assert result.sweep_score == 100.0
    assert result.trend_score == 100.0


def test_entry_band_uses_pine_safe_deep_fallback_when_deep_not_greater_than_near() -> None:
    result = _score(near=0.60, deep=0.55)
    # Pine uses min(0.95, near + 0.10) => 0.70.
    assert result.entry_band_low == pytest.approx(98.0)
    assert result.entry_band_high == pytest.approx(99.0)


def test_tick_size_caps_zero_width_zone_source_and_current_ranges() -> None:
    history = [
        _kline(0, open_price="100", high="100", low="100", close="100"),
        _kline(1, open_price="100", high="101", low="99", close="100"),
        _kline(2, open_price="100", high="100", low="100", close="100"),
    ]
    engine = PineSmcStructureEngine(_config(tick_size=0.5))
    result = engine._score_order_block(
        active_array_index=0,
        ob=_ob(top=100.0, bottom=100.0),
        history=history,
        current=history[-1],
        local_index=2,
        max_age=300,
        swing_trend=0,
        internal_trend=0,
        atr_slow=0.0,
        atr_fast=0.0,
        rsi_now=None,
        volume_average=None,
        prior_lowest_sweep=None,
        prior_highest_sweep=None,
        tick_size=0.5,
    )
    assert result.entry_band_low == pytest.approx(99.6)
    assert result.entry_band_high == pytest.approx(99.75)
    assert result.volatility_score == 100.0  # ATR ratio fallback 1.0
    assert result.displacement_score == 0.0  # slow ATR unavailable/zero fallback
    assert result.rsi_score == 50.0
    assert result.volume_score == 50.0
    assert result.sweep_score == 45.0
    # Current close is 100, band high is 99.75: distance is 0.25. With
    # atrFast=0 the Pine fallback returns 0 for non-zero distance.
    assert result.proximity_score == 0.0
    assert 0.0 <= result.setup_score <= 100.0


def test_fvg_credit_is_partial_when_absent_and_volume_fallback_is_neutral() -> None:
    result = _score(has_fvg=False, volume_avg=None, rsi=None)
    assert result.fvg_score == 40.0
    assert result.volume_score == 50.0
    assert result.rsi_score == 50.0


def test_relative_volume_score_clamps_to_zero_and_one_hundred() -> None:
    high = _score(volume_avg=1.0)
    low = _score(volume_avg=1000.0)
    assert high.volume_score == 100.0
    # The Pine formula has a mathematical floor of 10 when volume ratio tends
    # to zero: 50 + (0 - 1) * 40.
    assert low.volume_score == pytest.approx(10.4)


def test_current_candle_sweep_score_uses_strict_cross_and_close_back() -> None:
    # Equality to the prior low is not a sweep; a close on the boundary is not
    # a successful reclaim. This is distinct from Stage-6 requireSweep.
    equal_low = _score(prior_lowest=97.0)
    equal_close = _score(prior_lowest=101.0)
    no_level = _score(prior_lowest=None)
    assert equal_low.swept_current_candle is False
    assert equal_close.swept_current_candle is False
    assert no_level.swept_current_candle is False
    assert equal_low.sweep_score == 45.0
    assert equal_close.sweep_score == 45.0


def test_active_ob_scores_keep_array_order_and_chosen_candidate_is_not_reselected() -> None:
    engine = PineSmcStructureEngine(_config())
    history = _history()
    state = _PineSmcState(local_index=2)
    older = _ob(index=0, bias=1)
    newer = _ob(index=0, bias=-1, top=110.0, bottom=100.0, used=True)
    state.active_order_blocks.extend([older, newer])
    trigger = PineSmcTriggerSweepTrace(
        trigger_mode="Either",
        require_sweep=False,
        chosen_active_array_index=0,
        chosen_trigger_code=2,
    )

    result = engine._evaluate_ob_scoring(
        state=state,
        history=history,
        candle=history[-1],
        indicators=_indicators(),
        trigger_sweep=trigger,
        prior_lowest_sweep=98.0,
        prior_highest_sweep=102.0,
    )

    assert result.available is True
    assert [row.active_array_index for row in result.active_order_block_scores] == [0, 1]
    assert result.chosen_active_array_index == 0
    assert result.chosen_score is result.active_order_block_scores[0]
    assert [ob.used for ob in state.active_order_blocks] == [False, True]
    assert [ob.bias for ob in state.active_order_blocks] == [1, -1]
    with pytest.raises(FrozenInstanceError):
        result.active_order_block_scores[0].setup_score = 99.0  # type: ignore[misc]


def test_scoring_is_diagnostic_and_does_not_change_stage6_chosen_index() -> None:
    engine = PineSmcStructureEngine(_config())
    history = _history()
    state = _PineSmcState(local_index=2)
    state.active_order_blocks.extend(
        [
            _ob(index=0, bias=1),
            _ob(index=0, bias=-1, top=110.0, bottom=100.0),
        ]
    )
    trigger = PineSmcTriggerSweepTrace(
        trigger_mode="Either",
        require_sweep=False,
        chosen_active_array_index=1,
        chosen_trigger_code=1,
    )
    scores = engine._evaluate_ob_scoring(
        state=state,
        history=history,
        candle=history[-1],
        indicators=_indicators(),
        trigger_sweep=trigger,
        prior_lowest_sweep=98.0,
        prior_highest_sweep=102.0,
    )
    assert scores.chosen_active_array_index == trigger.chosen_active_array_index == 1
    assert scores.chosen_score is scores.active_order_block_scores[1]


def test_prior_sweep_levels_use_full_loaded_history_prefix_not_smc_reset_window() -> None:
    rows = [
        _kline(0, open_price="100", high="110", low="90", close="100"),
    ]
    for index in range(1, 301):
        rows.append(
            _kline(
                index,
                open_price="100",
                high="101",
                low="99",
                close="100",
            )
        )
    result = PineSmcStructureEngine(_config(warmup_bars=300, sweep_lookback=20)).replay(rows)
    first_active_bar = result.trace[0]
    assert first_active_bar.source_bar_index == 1
    assert first_active_bar.local_index == 0
    assert first_active_bar.ob_scoring.available is True
    assert first_active_bar.ob_scoring.prior_lowest_sweep == 90.0
    assert first_active_bar.ob_scoring.prior_highest_sweep == 110.0


def test_prior_sweep_window_excludes_current_bar_and_uses_only_sweep_lookback_values() -> None:
    engine = PineSmcStructureEngine(_config(sweep_lookback=2))
    rows = [
        _kline(0, open_price="100", high="110", low="90", close="100"),
        _kline(1, open_price="100", high="105", low="98", close="100"),
        _kline(2, open_price="100", high="104", low="97", close="100"),
        _kline(3, open_price="100", high="103", low="96", close="100"),
    ]
    result = engine.replay(rows)
    last = result.trace[-1].ob_scoring
    assert last.prior_lowest_sweep == 97.0
    assert last.prior_highest_sweep == 105.0


def test_replay_scores_are_available_when_tick_size_is_supplied_and_null_when_missing() -> None:
    candles = [
        _kline(i, open_price="100", high="101", low="99", close="100")
        for i in range(300)
    ]
    with_tick = PineSmcStructureEngine(_config(tick_size=0.1)).replay(candles)
    without_tick = PineSmcStructureEngine(_config(tick_size=None)).replay(candles)
    assert all(row.ob_scoring.available for row in with_tick.trace)
    assert all(row.ob_scoring.active_order_block_scores == () for row in with_tick.trace)
    assert all(not row.ob_scoring.available for row in without_tick.trace)
    payload = json.loads(without_tick.to_jsonl().splitlines()[0])
    assert payload["ob_scoring"]["tick_size"] is None
    assert payload["ob_scoring"]["chosen_score"] is None


def test_score_trace_json_serialization_contains_all_diagnostic_fields() -> None:
    result = _score()
    payload = json.loads(json.dumps(asdict(result)))
    assert payload["ob_quality_score"] > 0.0
    assert payload["entry_band_low"] == pytest.approx(97.0)
    assert payload["order_block"]["bias"] == 1
    assert payload["swept_current_candle"] is True


def test_stage7_scoring_trace_models_are_publicly_importable() -> None:
    assert PineSmcObScoreTrace.__name__ == "PineSmcObScoreTrace"
    assert PineSmcObScoringTrace.__name__ == "PineSmcObScoringTrace"
