from decimal import Decimal as D
from types import SimpleNamespace as NS

from divatrading.execution.near_tp_protection import NearTakeProfitProtection
from divatrading.execution.position_supervisor import ManagedPositionSupervisor, PositionSupervisorConfig
from test_position_supervisor import NOW, FakeExecutionClient, adapter, managed, ready_ledger, rules


def view(ts, index, bid, ask, *, direction=1, generation=0, source_age=0, healthy=True):
    symbol = "BTCUSDT"
    flow = NS(
        symbol=symbol, status="HEALTHY", continuity_valid=True, is_fresh=True,
        trade_count=4, last_trade_time_ms=ts - source_age,
        cvd_quote=direction * D(index * 300), last_processed_aggregate_trade_id=100 + index * 4,
    )
    book = NS(
        symbol=symbol, best_bid=D(bid), best_ask=D(ask), synchronized=True,
        update_id=200 + index, last_event_time_ms=ts - source_age,
    )
    health = NS(symbol=symbol, ready=healthy, sequence_integrity=True, event_fresh=True,
                queue_healthy=True, update_id=book.update_id)
    readiness = NS(
        symbol=symbol, status="READY", ready=True, queues_healthy=True,
        aggregate_trade_connected=True, aggregate_trade_continuity=True,
        delta_cvd_ready=True, order_book_ready=True, aggregate_trade_reconnect_generation=generation,
        depth_reconnect_generation=0,
    )
    return NS(symbol=symbol, order_book_metrics=book, order_book_health=health, flow=flow,
              instrument=NS(tick_size=D("0.1")), orchestrator_readiness=readiness, captured_at_ms=ts)


def observe_stalls(consumer, *, direction=1, reset_at=None):
    for second in range(11):
        now = NOW - (11 - second) * 1_000
        bid, ask = ("117.0", "117.1") if direction == 1 else ("82.9", "83.0")
        consumer(view(now, second, bid, ask, direction=direction,
                      generation=int(reset_at is not None and second >= reset_at)), now)


def long_reversal(protection, *, now=NOW, opened_at=NOW - 12_000):
    return protection.reversal(symbol="BTCUSDT", side="LONG", opened_at=opened_at,
                               entry=D("100"), stop=D("108"), target=D("120"), mark_at=now, now=now)


def test_protection_needs_two_completed_stalls_and_break_on_both_quotes():
    protection = NearTakeProfitProtection()
    observe_stalls(protection.observe)
    protection.observe(view(NOW, 11, "116.6", "117.1"), NOW)
    assert not long_reversal(protection)
    protection.observe(view(NOW + 1_000, 12, "116.6", "116.7"), NOW + 1_000)
    assert long_reversal(protection, now=NOW + 1_000)
    assert not long_reversal(protection, now=NOW + 3_001)
    assert not long_reversal(protection, now=NOW + 1_000, opened_at=NOW - 5_000)


def test_book_or_trade_continuity_loss_invalidates_existing_windows():
    protection = NearTakeProfitProtection()
    observe_stalls(protection.observe, reset_at=7)
    protection.observe(view(NOW, 11, "116.6", "116.7"), NOW)
    assert not long_reversal(protection)

    protection = NearTakeProfitProtection()
    observe_stalls(protection.observe)
    protection.observe(view(NOW, 11, "116.6", "116.7", healthy=False), NOW)
    assert not long_reversal(protection)


def test_short_requires_bearish_aggression_and_adverse_break():
    protection = NearTakeProfitProtection()
    observe_stalls(protection.observe, direction=-1)
    protection.observe(view(NOW, 11, "83.3", "83.4", direction=-1), NOW)
    assert protection.reversal(symbol="BTCUSDT", side="SHORT", opened_at=NOW - 12_000,
                               entry=D("100"), stop=D("92"), target=D("80"), mark_at=NOW, now=NOW)


def test_supervisor_exits_only_remaining_lot_after_confirmed_partial(tmp_path):
    ledger = ready_ledger(tmp_path / "near-tp.sqlite")
    state = managed(ledger, quantity="0.5")
    state.update({"partial_tp_done": True, "initial_quantity": "1", "partial_tp_target_quantity": "0.5",
                  "partial_tp_filled_quantity": "0.5", "breakeven_done": True,
                  "favorable_extreme": "118", "current_stop": "108"})
    ledger.update_managed_position(signal_id="sig-supervisor", symbol="BTCUSDT", position_side="BOTH",
                                   stop_loss="108")
    ledger.save_position_management_state(signal_id="sig-supervisor", symbol="BTCUSDT", state=state)
    client = FakeExecutionClient(fill_exit=True, quantity="0.5")
    clock = [NOW]
    supervisor = ManagedPositionSupervisor(
        ledger=ledger, adapter=adapter(ledger, client), filter_provider=rules,
        feed_factory=lambda _symbol: None, clock_ms=lambda: clock[0],
        config=PositionSupervisorConfig(early_exit_protection=True),
    )

    def ingest(sample, now):
        clock[0] = now
        supervisor.observe_market(sample)

    observe_stalls(ingest)
    ingest(view(NOW, 11, "116.6", "116.7"), NOW)
    assert client.new_order_calls == []
    event = NS(symbol="BTCUSDT", mark_price=D("116.6"), event_time_ms=NOW)
    outcome = supervisor._process_mark_event(event)
    assert outcome[0]["status"] == "CLOSED_CONFIRMED"
    assert client.new_order_calls[0]["quantity"] == D("0.5")
    assert client.new_order_calls[0]["reduceOnly"] is True
    assert ledger.get_risk_reservation("sig-supervisor")["status"] == "RELEASED"
    assert supervisor._process_mark_event(event) == []
