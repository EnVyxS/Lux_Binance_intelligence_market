from pathlib import Path

import pytest

from divatrading.core.config import ConfigurationError, Settings


def test_load_defaults_and_relative_paths(tmp_path: Path) -> None:
    settings = Settings.load(tmp_path, environ={})
    assert settings.trading_mode == "PAPER"
    assert settings.live_trading_enabled is False
    assert settings.database_path == (tmp_path / "data" / "divatrading.db").resolve()
    assert settings.log_dir == (tmp_path / "logs").resolve()


def test_process_environment_overrides_env_file(tmp_path: Path) -> None:
    (tmp_path / ".env").write_text("DIVA_LOG_LEVEL=DEBUG\nDIVA_TRADING_MODE=PAPER\n", encoding="utf-8")
    settings = Settings.load(tmp_path, environ={"DIVA_LOG_LEVEL": "WARNING"})
    assert settings.log_level == "WARNING"


def test_live_enable_flag_alone_does_not_change_legacy_foundation_mode(tmp_path: Path) -> None:
    settings = Settings.load(tmp_path, environ={"DIVA_LIVE_TRADING_ENABLED": "true"})
    assert settings.trading_mode == "PAPER"
    assert settings.live_trading_enabled is True


def test_non_paper_mode_is_blocked(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="PAPER-only"):
        Settings.load(tmp_path, environ={"DIVA_TRADING_MODE": "LIVE"})


def test_invalid_boolean_is_rejected(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="must be true/false"):
        Settings.load(tmp_path, environ={"DIVA_LIVE_TRADING_ENABLED": "sometimes"})
