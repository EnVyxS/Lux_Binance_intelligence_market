from decimal import Decimal as D
import random

import pytest

from divatrading.execution.position_accounting import (
    allocate_close_fill,
    build_position_groups,
    validate_protection_coverage,
)
from divatrading.execution.ledger import ExecutionLedger
from divatrading.core.reliability import operator_status


def _row(signal_id, quantity, entry, *, stop="90", take="120", opened="2026-01-01T00:00:00Z"):
    return {
        "signal_id": signal_id,
        "symbol": "BTCUSDT",
        "position_side": "BOTH",
        "signal_side": "LONG",
        "quantity": str(quantity),
        "entry_price": str(entry),
        "stop_loss": stop,
        "take_profit": take,
        "status": "OPEN",
        "updated_at_utc": opened,
    }


def test_aggregates_multiple_signal_lots_with_exact_weighted_entry_and_protection_slices():
    groups = build_position_groups([
        _row("sig-a", "2", "100", opened="2026-01-01T00:00:00Z"),
        _row("sig-b", "1", "130", stop="110", take="160", opened="2026-01-02T00:00:00Z"),
    ])
    assert len(groups) == 1
    group = groups[0]
    assert (group.symbol, group.position_side, group.side) == ("BTCUSDT", "BOTH", "LONG")
    assert group.quantity == D("3")
    assert group.weighted_entry_price == D("110")
    assert group.planned_stop_coverage == D("3")
    assert group.planned_take_profit_coverage == D("3")
    assert [item.signal_id for item in group.protection_allocations] == ["sig-a", "sig-b"]
    assert group.as_dict()["protection_is_exchange_verified"] is False


def test_close_fill_prefers_exact_signal_attribution_and_rejects_cross_lot_overfill():
    group = build_position_groups([_row("sig-a", "2", "100"), _row("sig-b", "1", "130")])[0]
    allocations = allocate_close_fill(group, D("0.4"), signal_id="sig-b")
    assert [(item.signal_id, item.quantity) for item in allocations] == [("sig-b", D("0.4"))]
    with pytest.raises(ValueError, match="exceeds that signal"):
        allocate_close_fill(group, D("1.1"), signal_id="sig-b")


def test_untagged_external_reduction_uses_stable_fifo_allocation():
    group = build_position_groups([
        _row("sig-b", "1", "130", opened="2026-01-02T00:00:00Z"),
        _row("sig-a", "2", "100", opened="2026-01-01T00:00:00Z"),
    ])[0]
    allocations = allocate_close_fill(group, D("2.5"))
    assert [(item.signal_id, item.quantity) for item in allocations] == [
        ("sig-a", D("2")), ("sig-b", D("0.5")),
    ]


def test_protection_coverage_requires_stop_and_tp_quantity_per_signal():
    group = build_position_groups([_row("sig-a", "2", "100"), _row("sig-b", "1", "130")])[0]
    ok, reasons = validate_protection_coverage(
        group,
        stop_quantity_by_signal={"sig-a": "2", "sig-b": "1"},
        take_profit_quantity_by_signal={"sig-a": "2", "sig-b": "1"},
    )
    assert ok and reasons == ()
    ok, reasons = validate_protection_coverage(
        group,
        stop_quantity_by_signal={"sig-a": "3", "sig-b": "0"},
        take_profit_quantity_by_signal={"sig-a": "2"},
    )
    assert not ok
    assert "STOP_LOSS_QUANTITY_MISMATCH:sig-a" in reasons
    assert "TAKE_PROFIT_ALLOCATION_SET_MISMATCH" in reasons


def test_rejects_conflicting_direction_within_one_way_position_group():
    short = _row("sig-short", "1", "100")
    short["signal_side"] = "SHORT"
    with pytest.raises(ValueError, match="conflicting directions"):
        build_position_groups([_row("sig-long", "1", "100"), short])


def test_ledger_exposes_read_only_aggregated_position_groups(tmp_path):
    ledger = ExecutionLedger(tmp_path / "aggregates.sqlite")
    for signal_id, quantity, entry in (("sig-a", "2", "100"), ("sig-b", "1", "130")):
        ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side="LONG",
                            client_order_id=f"DIVA{signal_id}", payload={})
        ledger.record_position(symbol="BTCUSDT", position_side="BOTH", signal_id=signal_id,
                               quantity=quantity, entry_price=entry, stop_loss="90", take_profit="120")
    groups = ledger.list_managed_position_groups()
    assert len(groups) == 1
    assert groups[0]["quantity"] == "3"
    assert groups[0]["allocation_count"] == 2
    snapshot = operator_status(ledger)
    assert snapshot["aggregated_position_groups"][0]["quantity"] == "3"
    assert snapshot["position_fill_allocation_counts"] == {
        "ATTRIBUTED": 0, "UNATTRIBUTED": 0, "EXTERNAL": 0,
    }


def test_existing_ledger_schema_is_migrated_for_immutable_lot_open_time(tmp_path):
    import sqlite3

    path = tmp_path / "legacy-managed-position.sqlite"
    with sqlite3.connect(path) as db:
        db.executescript("""
            CREATE TABLE trade_intents (
                signal_id TEXT PRIMARY KEY, symbol TEXT NOT NULL, side TEXT NOT NULL,
                client_order_id TEXT NOT NULL UNIQUE, status TEXT NOT NULL,
                payload_json TEXT NOT NULL, created_at_utc TEXT NOT NULL,
                updated_at_utc TEXT NOT NULL, last_error TEXT
            );
            CREATE TABLE managed_positions (
                symbol TEXT NOT NULL, position_side TEXT NOT NULL,
                signal_id TEXT NOT NULL REFERENCES trade_intents(signal_id),
                quantity TEXT NOT NULL, entry_price TEXT NOT NULL,
                stop_loss TEXT NOT NULL, take_profit TEXT NOT NULL,
                status TEXT NOT NULL, updated_at_utc TEXT NOT NULL,
                PRIMARY KEY(symbol,position_side,signal_id)
            );
            INSERT INTO trade_intents VALUES
                ('legacy-signal','BTCUSDT','LONG','DIVA-LEGACY','PROTECTED','{}',
                 '2026-01-01T00:00:00Z','2026-01-01T00:00:00Z',NULL);
            INSERT INTO managed_positions VALUES
                ('BTCUSDT','BOTH','legacy-signal','1','100','90','120','OPEN',
                 '2026-01-02T00:00:00Z');
        """)
    ledger = ExecutionLedger(path)
    row = ledger.list_managed_positions()[0]
    assert row["opened_at_utc"] == "2026-01-02T00:00:00Z"
    ledger.record_position(symbol="BTCUSDT", position_side="BOTH", signal_id="legacy-signal",
                           quantity="0.5", entry_price="101", stop_loss="90", take_profit="120")
    updated = ledger.list_managed_positions()[0]
    assert updated["opened_at_utc"] == "2026-01-02T00:00:00Z"
    assert updated["quantity"] == "0.5"


def test_position_management_action_claim_is_serialized_across_sibling_lots(tmp_path):
    ledger = ExecutionLedger(tmp_path / "multi-lot-action-lock.sqlite")
    for signal_id in ("sig-a", "sig-b"):
        ledger.claim_intent(signal_id=signal_id, symbol="BTCUSDT", side="LONG",
                            client_order_id=f"DIVA-{signal_id}", payload={})
        ledger.record_position(symbol="BTCUSDT", position_side="BOTH", signal_id=signal_id,
                               quantity="1", entry_price="100", stop_loss="90", take_profit="120")

    assert ledger.claim_position_management_action(
        action_id="action-a", signal_id="sig-a", action_kind="PARTIAL_TP", payload={},
    )
    assert ledger.update_position_management_action(action_id="action-a", status="SUBMITTED")
    assert not ledger.claim_position_management_action(
        action_id="action-b", signal_id="sig-b", action_kind="PARTIAL_TP", payload={},
    )


def test_seeded_multi_lot_quantity_conservation_for_one_way_and_hedge_sides():
    rng = random.Random(20261114)
    for position_side, direction in (("BOTH", "LONG"), ("LONG", "LONG"), ("SHORT", "SHORT")):
        for case_index in range(60):
            source_rows = []
            for lot_index in range(1, 6):
                quantity = D(rng.randint(1, 100)) / D("100")
                entry = D(rng.randint(50_000, 70_000))
                source_rows.append({
                    "signal_id": f"{position_side}-{case_index}-{lot_index}",
                    "symbol": "BTCUSDT",
                    "position_side": position_side,
                    "signal_side": direction,
                    "quantity": str(quantity),
                    "entry_price": str(entry),
                    "stop_loss": str(entry - 500 if direction == "LONG" else entry + 500),
                    "take_profit": str(entry + 1000 if direction == "LONG" else entry - 1000),
                    "status": "OPEN",
                    "opened_at_utc": f"2026-11-14T00:00:{lot_index:02d}Z",
                })

            group = build_position_groups(source_rows)[0]
            # Random aggregate close must remain bounded by the exchange-side group.
            close_units = rng.randint(0, int(group.quantity * 100))
            close_quantity = D(close_units) / D("100")
            allocations = allocate_close_fill(group, close_quantity)
            assert sum((item.quantity for item in allocations), D("0")) == close_quantity

            allocated = {item.signal_id: item.quantity for item in allocations}
            residual_rows = []
            for row in source_rows:
                remaining = D(row["quantity"]) - allocated.get(row["signal_id"], D("0"))
                assert remaining >= 0
                if remaining > 0:
                    residual_rows.append({**row, "quantity": str(remaining)})

            residual_total = sum((D(row["quantity"]) for row in residual_rows), D("0"))
            assert residual_total == group.quantity - close_quantity
            if residual_rows:
                residual_group = build_position_groups(residual_rows)[0]
                assert residual_group.quantity == residual_total
                stop_coverage = {row["signal_id"]: row["quantity"] for row in residual_rows}
                take_coverage = dict(stop_coverage)
                valid, reasons = validate_protection_coverage(
                    residual_group,
                    stop_quantity_by_signal=stop_coverage,
                    take_profit_quantity_by_signal=take_coverage,
                )
                assert valid and reasons == ()
            else:
                assert residual_total == 0
