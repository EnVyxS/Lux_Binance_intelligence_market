from __future__ import annotations

import asyncio
import json
from decimal import Decimal

import httpx
import pytest

from divatrading.market_data.order_book import (
    BinanceDepthSnapshotClient, BinanceDepthWebSocketFeed, DepthEvent, DepthLevel,
    DepthSnapshot, LocalOrderBook, OrderBookNotReady, OrderBookQueueFullError,
    OrderBookSequenceError, OrderBookStaleEventError, normalize_depth_subscriptions,
    parse_depth_stream_message,
)

NOW = 1_800_000_000_000


def ev(u: int, *, U: int | None = None, pu: int | None = None, bids=(), asks=(), t: int = NOW) -> DepthEvent:
    return DepthEvent("BTCUSDT", U if U is not None else u, u, pu, t, t,
                      tuple(DepthLevel(Decimal(str(p)), Decimal(str(q))) for p,q in bids),
                      tuple(DepthLevel(Decimal(str(p)), Decimal(str(q))) for p,q in asks),
                      "btcusdt@depth@100ms", __import__("datetime").datetime.now(__import__("datetime").UTC))


def snapshot(last=100):
    return DepthSnapshot("BTCUSDT", last,
        (DepthLevel(Decimal("99"),Decimal("2")),DepthLevel(Decimal("98"),Decimal("3"))),
        (DepthLevel(Decimal("101"),Decimal("1")),DepthLevel(Decimal("102"),Decimal("4"))))


def book(**kw): return LocalOrderBook("BTCUSDT", wall_clock_ms=lambda: NOW, **kw)


def test_normalize_exact_symbols_and_streams():
    assert normalize_depth_subscriptions(["btcusdt","BTCUSDT"])[1] == ("btcusdt@depth@100ms",)
    with pytest.raises(ValueError): normalize_depth_subscriptions([])
    with pytest.raises(ValueError): normalize_depth_subscriptions(["BTC/USDT"])


def test_parse_depth_decimal_pu_and_combined():
    raw={"stream":"btcusdt@depth@100ms","data":{"e":"depthUpdate","E":NOW,"T":NOW,"s":"BTCUSDT","U":100,"u":101,"pu":99,"b":[["100.10","2.5"]],"a":[["101.10","0"]]}}
    parsed=parse_depth_stream_message(json.dumps(raw),allowed_symbols=["BTCUSDT"],now_ms=NOW,max_event_age_ms=100)
    assert parsed and parsed.previous_final_update_id == 99
    assert parsed.bids[0].price == Decimal("100.10") and parsed.asks[0].quantity == 0


def test_acknowledgement_returns_none():
    assert parse_depth_stream_message('{"id":1,"result":null}') is None


def test_parser_rejects_wrong_symbol_and_bad_sequence():
    payload={"e":"depthUpdate","E":NOW,"s":"ETHUSDT","U":1,"u":1,"b":[],"a":[]}
    with pytest.raises(Exception): parse_depth_stream_message(json.dumps(payload),allowed_symbols=["BTCUSDT"],now_ms=NOW)
    payload["s"]="BTCUSDT"; payload["U"]=2
    with pytest.raises(Exception): parse_depth_stream_message(json.dumps(payload),now_ms=NOW)


def test_parser_rejects_stale_event():
    payload={"e":"depthUpdate","E":NOW-1000,"s":"BTCUSDT","U":1,"u":1,"b":[],"a":[]}
    with pytest.raises(OrderBookStaleEventError): parse_depth_stream_message(json.dumps(payload),now_ms=NOW,max_event_age_ms=10)


def test_sync_snapshot_bridge_and_metrics():
    b=book(depth_levels=2)
    count=b.synchronize(snapshot(),[ev(102,U=99,pu=None,bids=[("100", "5")])])
    assert count==1
    m=b.metrics()
    assert m.best_bid==Decimal("100") and m.best_ask==Decimal("101")
    assert m.spread==Decimal("1") and m.imbalance==Decimal(2)/Decimal(12)


def test_sync_accepts_overlap_then_pu_chain():
    b=book()
    b.synchronize(snapshot(),[ev(101,U=99),ev(103,U=101,pu=101,bids=[("100","1")])])
    assert b.update_id==103


def test_sync_rejects_no_snapshot_bridge_and_stays_unready():
    b=book()
    assert b.synchronize(snapshot(),[ev(102,U=101)])==0
    with pytest.raises(OrderBookNotReady): b.metrics()


def test_sync_rejects_pu_gap():
    b=book()
    with pytest.raises(OrderBookSequenceError): b.synchronize(snapshot(),[ev(101,U=99),ev(103,U=102,pu=100)])
    assert not b.synchronized


def test_apply_rejects_missing_pu_and_invalidates():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookSequenceError): b.apply(ev(102,U=102,pu=None))
    assert not b.synchronized


def test_apply_rejects_pu_gap():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookSequenceError): b.apply(ev(102,pu=99))
    assert not b.synchronized


def test_duplicate_old_event_is_ignored():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    b.apply(ev(100,U=98))
    assert b.update_id==101 and b.synchronized


def test_crossed_book_invalidates_atomically():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookSequenceError): b.apply(ev(102,pu=101,bids=[("102","9")]))
    assert not b.synchronized


def test_empty_side_invalidates():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookSequenceError): b.apply(ev(102,pu=101,bids=[("99","0"),("98","0")]))
    assert not b.synchronized


def test_stale_apply_invalidates():
    b=book(max_event_age_ms=10); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookStaleEventError): b.apply(ev(102,pu=101,t=NOW-100))
    assert not b.synchronized


def test_metrics_stale_invalidates():
    clock=[NOW]; b=LocalOrderBook("BTCUSDT",wall_clock_ms=lambda:clock[0],max_event_age_ms=10)
    b.synchronize(snapshot(),[ev(101,U=99)])
    clock[0]+=100
    with pytest.raises(OrderBookNotReady): b.metrics()
    assert not b.synchronized


def test_book_levels_are_bounded():
    b=book(max_levels=2,depth_levels=2)
    b.synchronize(snapshot(),[ev(101,U=99,bids=[("100","1"),("97","2")])])
    assert len(b._bids)<=2 and len(b._asks)<=2


def test_snapshot_limit_and_rest_request_params():
    requests=[]
    def handler(request):
        requests.append(request)
        return httpx.Response(200,json={"lastUpdateId":10,"bids":[["1","2"]],"asks":[["2","3"]]})
    client=BinanceDepthSnapshotClient(limit=50,min_request_interval_seconds=0,http_client=httpx.Client(transport=httpx.MockTransport(handler)))
    result=client.fetch("BTCUSDT")
    assert result.last_update_id==10 and requests[0].url.params["limit"]=="50"
    client.close()


def test_rest_rejects_invalid_limit():
    with pytest.raises(ValueError): BinanceDepthSnapshotClient(limit=99)


def test_feed_subscription_is_exact_and_bounded():
    feed=BinanceDepthWebSocketFeed(symbols=["BTCUSDT"],queue_capacity=2)
    assert feed.subscription_request()["params"]==["btcusdt@depth@100ms"]
    with pytest.raises(ValueError): BinanceDepthWebSocketFeed(symbols=[f"S{i}USDT" for i in range(40)])


class FakeWS:
    def __init__(self, messages): self.messages=iter(messages); self.sent=[]
    async def __aenter__(self): return self
    async def __aexit__(self,*args): return False
    async def send(self,value): self.sent.append(value)
    async def recv(self):
        try: return next(self.messages)
        except StopIteration: await asyncio.sleep(0.01); raise ConnectionError("closed")


def test_feed_queue_overflow_is_fatal():
    payload=json.dumps({"e":"depthUpdate","E":NOW,"s":"BTCUSDT","U":1,"u":1,"b":[],"a":[]})
    fake=FakeWS([payload,payload])
    feed=BinanceDepthWebSocketFeed(symbols=["BTCUSDT"],queue_capacity=1,max_reconnect_attempts=0,connector=lambda *a,**k:fake,wall_clock_ms=lambda:NOW)
    with pytest.raises(OrderBookQueueFullError): asyncio.run(feed.run(asyncio.Event()))
    assert feed.stats.queue_overflows==1


def test_book_can_resynchronize_after_gap_invalidation():
    b=book(); b.synchronize(snapshot(),[ev(101,U=99)])
    with pytest.raises(OrderBookSequenceError): b.apply(ev(102,pu=999))
    assert not b.synchronized
    assert b.synchronize(snapshot(200),[ev(201,U=199)])==1
    assert b.synchronized and b.update_id==201


def test_sync_checks_pu_even_when_bridge_event_does_not_advance_snapshot():
    b=book()
    with pytest.raises(OrderBookSequenceError):
        b.synchronize(snapshot(),[ev(100,U=99),ev(102,U=101,pu=99)])
    assert not b.synchronized


def test_feed_reconnects_and_resubscribes_after_disconnect():
    async def scenario():
        stop=asyncio.Event(); calls=[]
        class First(FakeWS):
            async def recv(self): raise ConnectionError("simulated disconnect")
        class Second(FakeWS):
            async def recv(self):
                stop.set()
                return '{"id":1,"result":null}'
        def connector(*args,**kwargs):
            calls.append(1)
            return First([]) if len(calls)==1 else Second([])
        feed=BinanceDepthWebSocketFeed(symbols=["BTCUSDT"],max_reconnect_attempts=2,connector=connector)
        await feed.run(stop)
        assert len(calls)==2 and feed.stats.reconnect_attempts==1
        assert feed.stats.connection_count==2
    asyncio.run(scenario())


def test_crossed_rest_snapshot_never_becomes_healthy():
    b=book()
    bad=DepthSnapshot("BTCUSDT",100,
        (DepthLevel(Decimal("102"),Decimal("1")),),
        (DepthLevel(Decimal("101"),Decimal("1")),))
    with pytest.raises(OrderBookSequenceError): b.synchronize(bad,[ev(101,U=99)])
    assert not b.synchronized


def test_stale_rest_snapshot_is_rejected():
    b=book(max_event_age_ms=10)
    old=DepthSnapshot("BTCUSDT",100,snapshot().bids,snapshot().asks,event_time_ms=NOW-100)
    with pytest.raises(OrderBookStaleEventError): b.synchronize(old,[ev(101,U=99)])
    assert not b.synchronized
