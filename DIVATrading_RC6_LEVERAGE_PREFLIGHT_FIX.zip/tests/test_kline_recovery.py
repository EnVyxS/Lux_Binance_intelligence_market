from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import httpx
import pytest

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceHttpError, BinanceUsdMFuturesRestClient
from divatrading.market_data.history import HistoricalKlineService
from divatrading.market_data.klines import Kline
from divatrading.market_data.recovery import (
    FeedHealth,
    KlineRecoveryService,
    RecoveryConfigurationError,
    RecoveryIncompleteError,
    RecoveryNotConnectedError,
)
from divatrading.market_data.storage import KlineRepository
from divatrading.market_data.websocket import MarketKlineEvent


SOURCE_REST = "https://fapi.binance.com/fapi/v1/klines"
SOURCE_WS = "wss://fstream.binance.com/market/stream"


def _row(open_time_ms: int, *, interval: str = "1m") -> list[object]:
    interval_ms = {"1m": 60_000, "5m": 300_000, "15m": 900_000}[interval]
    return [
        open_time_ms,
        "100.000000000000000001",
        "102.00",
        "99.00",
        "101.250000000000000001",
        "1.500000000000000001",
        open_time_ms + interval_ms - 1,
        "150.000000000000000001",
        7,
        "0.750000000000000001",
        "75.000000000000000001",
        "0",
    ]


def _kline(open_time_ms: int, *, interval: str = "1m", source: str = SOURCE_WS) -> Kline:
    return Kline.from_binance_row(
        _row(open_time_ms, interval=interval),
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint=source,
    )


def _make_service(
    tmp_path: Path,
    handler,
    *,
    interval: str = "1m",
    page_limit: int = 2,
    max_pages: int = 5,
    recovery_pages: int | None = None,
    target_open_time_ms: int = 180_000,
):
    client = BinanceUsdMFuturesRestClient(
        base_url="https://fixture.local",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )
    history = HistoricalKlineService(
        client,
        page_limit=page_limit,
        max_pages=max_pages,
        min_request_interval_seconds=0,
    )
    db = Database(tmp_path / "recovery.db")
    db.initialize()
    repository = KlineRepository(db)
    interval_ms = {"1m": 60_000, "5m": 300_000, "15m": 900_000}[interval]
    now_ms = target_open_time_ms + interval_ms + 1
    service = KlineRecoveryService(
        history,
        repository,
        max_pages_per_recovery=max_pages if recovery_pages is None else recovery_pages,
        audit_window_candles=100,
        now_ms=lambda: now_ms,
    )
    return client, db, repository, service, now_ms


def _request_starts(requests: list[httpx.Request]) -> list[int]:
    return [int(request.url.params["startTime"]) for request in requests]


def test_bootstrap_backfill_persists_confirmed_rows_and_marks_ready(tmp_path: Path) -> None:
    requests: list[httpx.Request] = []

    def handler(request):
        requests.append(request)
        start = int(request.url.params["startTime"])
        if start == 0:
            return httpx.Response(200, json=[_row(0), _row(60_000)])
        if start == 120_000:
            return httpx.Response(200, json=[_row(120_000)])
        return httpx.Response(200, json=[])

    client, _, repo, service, _ = _make_service(tmp_path, handler)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        assert service.health is FeedHealth.DISCONNECTED
        service.mark_feed_connected()
        assert service.health is FeedHealth.RECOVERING

        result = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000
        )

        assert result.complete is True
        assert result.candles_fetched == 3
        assert result.candles_persisted == 3
        assert result.pages_fetched == 2
        assert service.is_ready is True
        assert [item.kline.open_time_ms for item in repo.read_tail(
            symbol="BTCUSDT", interval="1m", limit=10
        )] == [0, 60_000, 120_000]
        assert _request_starts(requests) == [0, 120_000]
    finally:
        client.close()


def test_recovery_fills_gap_between_existing_candles(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=[_row(start), _row(start + 60_000)])

    client, _, repo, service, _ = _make_service(tmp_path, handler)
    try:
        repo.upsert_many([_kline(0, source=SOURCE_REST), _kline(180_000, source=SOURCE_REST)])
        service.register_stream(symbol="BTCUSDT", interval="1m")
        service.mark_feed_connected()

        result = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=180_000
        )

        assert result.complete is True
        assert result.gaps_detected[0].start_open_time_ms == 60_000
        assert result.gaps_detected[0].end_open_time_ms == 120_000
        assert result.candles_persisted == 2
        assert [item.kline.open_time_ms for item in repo.read_tail(
            symbol="BTCUSDT", interval="1m", limit=10
        )] == [0, 60_000, 120_000, 180_000]
        assert service.is_ready
    finally:
        client.close()


def test_missing_rest_candle_is_not_synthesized_and_health_stays_degraded(tmp_path: Path) -> None:
    responses = {0: [_row(0), _row(120_000)], 60_000: [_row(60_000)]}

    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=responses.get(start, []))

    client, db, repo, service, _ = _make_service(tmp_path, handler)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        first = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000
        )
        assert first.complete is False
        assert first.missing_open_times_ms == (60_000,)
        assert service.health is FeedHealth.DEGRADED
        assert repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=0)
        assert not repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=60_000)
        assert repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=120_000)

        second = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000
        )
        assert second.complete is True
        assert second.candles_persisted == 1
        assert service.is_ready
        assert repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=60_000)
        with db.connection() as connection:
            count = connection.execute("SELECT COUNT(*) FROM market_klines").fetchone()[0]
        assert count == 3
    finally:
        client.close()


def test_page_budget_returns_resume_cursor_and_persists_partial_progress(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=[_row(start)])

    client, _, repo, service, _ = _make_service(
        tmp_path,
        handler,
        page_limit=1,
        max_pages=3,
        recovery_pages=1,
        target_open_time_ms=180_000,
    )
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        result = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=180_000
        )

        assert result.complete is False
        assert result.pages_fetched == 1
        assert result.next_start_open_time_ms == 60_000
        assert repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=0)
        assert service.health is FeedHealth.DEGRADED
    finally:
        client.close()


def test_repeated_recovery_is_idempotent(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=[_row(value) for value in (start, start + 60_000)])

    client, db, repo, service, _ = _make_service(tmp_path, handler, target_open_time_ms=60_000)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        first = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=60_000
        )
        second = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=60_000
        )
        assert first.complete and second.complete
        assert second.candles_persisted == 0
        with db.connection() as connection:
            count = connection.execute("SELECT COUNT(*) FROM market_klines").fetchone()[0]
        assert count == 2
    finally:
        client.close()


def test_forming_websocket_event_is_never_persisted(tmp_path: Path) -> None:
    client, _, repo, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        event = MarketKlineEvent(
            kline=_kline(0),
            event_time_ms=59_000,
            is_closed=False,
            stream_name="btcusdt@kline_1m",
            received_at_utc=datetime(2026, 11, 10, 0, 1, tzinfo=UTC),
        )
        assert service.ingest_websocket_event(event) is False
        assert repo.read(symbol="BTCUSDT", interval="1m") == []
    finally:
        client.close()


def test_closed_websocket_event_backfills_previous_gap_before_persisting(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        if start == 0:
            return httpx.Response(200, json=[_row(0), _row(60_000)])
        return httpx.Response(200, json=[])

    client, _, repo, service, _ = _make_service(tmp_path, handler, target_open_time_ms=180_000)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        event = MarketKlineEvent(
            kline=_kline(120_000),
            event_time_ms=179_000,
            is_closed=True,
            stream_name="btcusdt@kline_1m",
            received_at_utc=datetime(2026, 11, 10, 0, 3, tzinfo=UTC),
        )
        assert service.ingest_websocket_event(event) is True
        assert [item.kline.open_time_ms for item in repo.read_tail(
            symbol="BTCUSDT", interval="1m", limit=10
        )] == [0, 60_000, 120_000]
        assert service.is_ready
    finally:
        client.close()


def test_closed_websocket_event_is_held_when_backfill_is_incomplete(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        if start == 0:
            return httpx.Response(200, json=[_row(0)])
        return httpx.Response(200, json=[])

    client, _, repo, service, _ = _make_service(tmp_path, handler, target_open_time_ms=180_000)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        event = MarketKlineEvent(
            kline=_kline(120_000),
            event_time_ms=179_000,
            is_closed=True,
            stream_name="btcusdt@kline_1m",
            received_at_utc=datetime(2026, 11, 10, 0, 3, tzinfo=UTC),
        )
        with pytest.raises(RecoveryIncompleteError):
            service.ingest_websocket_event(event)
        assert not repo.exists(symbol="BTCUSDT", interval="1m", open_time_ms=120_000)
        assert service.health is FeedHealth.DEGRADED
    finally:
        client.close()


def test_cannot_recover_while_disconnected(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        with pytest.raises(RecoveryNotConnectedError):
            service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=0)
    finally:
        client.close()


def test_target_must_be_closed_and_aligned(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.mark_feed_connected()
        with pytest.raises(RecoveryConfigurationError, match="aligned"):
            service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=1)
        service._now_ms = lambda: 239_999
        with pytest.raises(RecoveryConfigurationError, match="not confirmed closed"):
            service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=180_000)
        assert service.health is FeedHealth.DEGRADED
    finally:
        client.close()


def test_first_recovery_requires_explicit_bootstrap_start(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m")
        service.mark_feed_connected()
        with pytest.raises(RecoveryConfigurationError, match="bootstrap_start"):
            service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000)
        assert service.health is FeedHealth.DEGRADED
    finally:
        client.close()


def test_reconnect_marks_all_streams_unhealthy_until_all_are_recovered(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=[_row(start)])

    client, _, _, service, _ = _make_service(tmp_path, handler, target_open_time_ms=60_000)
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.register_stream(symbol="ETHUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.mark_feed_connected()
        results = service.recover_registered_streams(
            {("BTCUSDT", "1m"): 0, ("ETHUSDT", "1m"): 0}
        )
        assert len(results) == 2
        assert service.is_ready

        service.mark_feed_disconnected("test disconnect")
        assert service.health is FeedHealth.DISCONNECTED
        assert not service.is_ready
        service.mark_feed_connected()
        assert service.health is FeedHealth.RECOVERING
        service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=0)
        assert service.is_ready is False
        service.recover_stream(symbol="ETHUSDT", interval="1m", target_end_open_time_ms=0)
        assert service.is_ready is True
    finally:
        client.close()


def test_missing_registered_target_degrades_readiness(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.register_stream(symbol="ETHUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.mark_feed_connected()
        results = service.recover_registered_streams({("BTCUSDT", "1m"): 0})
        assert len(results) == 1
        assert service.health is FeedHealth.DEGRADED
        assert service.stream_error(symbol="ETHUSDT", interval="1m") is not None
    finally:
        client.close()


def test_rest_failure_keeps_stream_degraded_and_propagates_error(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(
        tmp_path,
        lambda request: httpx.Response(503, text="temporarily unavailable"),
        target_open_time_ms=60_000,
    )
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.mark_feed_connected()
        with pytest.raises(BinanceHttpError):
            service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=0)
        assert service.health is FeedHealth.DEGRADED
        assert "Binance HTTP 503" in (service.stream_error(symbol="BTCUSDT", interval="1m") or "")
    finally:
        client.close()


@pytest.mark.parametrize("interval, interval_ms", [("1m", 60_000), ("5m", 300_000), ("15m", 900_000)])
def test_recovery_supports_each_project_interval(tmp_path: Path, interval: str, interval_ms: int) -> None:
    target = interval_ms

    def handler(request):
        start = int(request.url.params["startTime"])
        return httpx.Response(200, json=[_row(start, interval=interval), _row(start + interval_ms, interval=interval)])

    client, _, repo, service, _ = _make_service(
        tmp_path,
        handler,
        interval=interval,
        page_limit=2,
        max_pages=5,
        target_open_time_ms=target,
    )
    try:
        service.register_stream(
            symbol="BTCUSDT", interval=interval, bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        result = service.recover_stream(
            symbol="BTCUSDT", interval=interval, target_end_open_time_ms=target
        )
        assert result.complete
        assert repo.exists(symbol="BTCUSDT", interval=interval, open_time_ms=0)
        assert repo.exists(symbol="BTCUSDT", interval=interval, open_time_ms=target)
    finally:
        client.close()


def test_feed_disconnect_clears_global_readiness_after_success(tmp_path: Path) -> None:
    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[_row(0)]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        service.mark_feed_connected()
        assert service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=0
        ).complete
        assert service.is_ready
        service.mark_feed_disconnected("socket closed")
        assert service.is_ready is False
        assert service.stream_health(symbol="BTCUSDT", interval="1m") is FeedHealth.DISCONNECTED
    finally:
        client.close()


def test_observe_websocket_feed_detects_connection_and_fast_internal_reconnect(tmp_path: Path) -> None:
    from divatrading.market_data.websocket import BinanceKlineWebSocketFeed

    client, _, _, service, _ = _make_service(
        tmp_path, lambda request: httpx.Response(200, json=[_row(0)])
    )
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        feed = BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], intervals=["1m"])
        # Simulate the observable fields updated by the real Unit 03C feed task.
        feed._connected = True
        feed.stats.connection_count = 1
        assert service.observe_websocket_feed(feed) is FeedHealth.RECOVERING
        service.recover_stream(symbol="BTCUSDT", interval="1m", target_end_open_time_ms=0)
        assert service.is_ready

        # A reconnect can happen between supervisor polls. A rising connection
        # counter invalidates readiness even if is_connected is already True.
        feed.stats.connection_count = 2
        assert service.observe_websocket_feed(feed) is FeedHealth.RECOVERING
        assert not service.is_ready
    finally:
        client.close()


def test_observe_websocket_feed_marks_disconnect(tmp_path: Path) -> None:
    from divatrading.market_data.websocket import BinanceKlineWebSocketFeed

    client, _, _, service, _ = _make_service(tmp_path, lambda request: httpx.Response(200, json=[]))
    try:
        service.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0)
        feed = BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], intervals=["1m"])
        feed._connected = True
        feed.stats.connection_count = 1
        service.observe_websocket_feed(feed)
        feed._connected = False
        feed.stats.last_error = "simulated link loss"
        assert service.observe_websocket_feed(feed) is FeedHealth.DISCONNECTED
        assert service.stream_error(symbol="BTCUSDT", interval="1m") == "simulated link loss"
    finally:
        client.close()


def test_leading_bootstrap_gap_is_detected_after_partial_rest_response(tmp_path: Path) -> None:
    calls = {"missing_lead": [_row(60_000), _row(120_000)], "repair_lead": [_row(0)]}

    def handler(request):
        start = int(request.url.params["startTime"])
        if start == 0:
            # First pass deliberately omits the bootstrap candle; second pass
            # must detect it using the repository's earliest-open-time query.
            existing = repo.earliest_open_time_ms(symbol="BTCUSDT", interval="1m")
            payload = calls["missing_lead"] if existing is None else calls["repair_lead"]
            return httpx.Response(200, json=payload)
        return httpx.Response(200, json=[])

    client, _, repo, service, _ = _make_service(tmp_path, handler, target_open_time_ms=120_000)
    try:
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        first = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000
        )
        assert first.complete is False
        assert first.missing_open_times_ms == (0,)
        assert repo.earliest_open_time_ms(symbol="BTCUSDT", interval="1m") == 60_000

        second = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=120_000
        )
        assert second.complete is True
        assert second.gaps_detected[0].start_open_time_ms == 0
        assert second.gaps_detected[0].end_open_time_ms == 0
        assert repo.earliest_open_time_ms(symbol="BTCUSDT", interval="1m") == 0
    finally:
        client.close()


def test_recovery_candle_budget_is_bounded_by_audit_window(tmp_path: Path) -> None:
    def handler(request):
        start = int(request.url.params["startTime"])
        end = int(request.url.params["endTime"])
        rows = [_row(value) for value in (start, start + 60_000, start + 120_000) if value <= end]
        return httpx.Response(200, json=rows)

    client, _, repo, service, _ = _make_service(
        tmp_path, handler, target_open_time_ms=180_000, page_limit=5, max_pages=5
    )
    try:
        service.audit_window_candles = 3
        service.register_stream(
            symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=0
        )
        service.mark_feed_connected()
        first = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=180_000
        )
        assert first.complete is False
        assert first.next_start_open_time_ms == 120_000
        assert first.candles_persisted == 2
        assert [item.kline.open_time_ms for item in repo.read_tail(
            symbol="BTCUSDT", interval="1m", limit=10
        )] == [0, 60_000]

        second = service.recover_stream(
            symbol="BTCUSDT", interval="1m", target_end_open_time_ms=180_000
        )
        assert second.complete is True
        assert [item.kline.open_time_ms for item in repo.read_tail(
            symbol="BTCUSDT", interval="1m", limit=10
        )] == [0, 60_000, 120_000, 180_000]
    finally:
        client.close()
