from __future__ import annotations

from dataclasses import FrozenInstanceError
from decimal import Decimal

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcReplayError,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
)
from divatrading.strategy.pine_smc_structure import (
    _PineOrderBlockState,
    _PineSmcState,
)

BASE_TIME_MS = 1_700_000_000_000


def _kline(
    index: int,
    *,
    open_price: str,
    high: str,
    low: str,
    close: str,
    interval: str = "1m",
) -> Kline:
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            "10",
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 10,
        "internal_len": 1,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def _bullish_fvg_sequence(*, break_low: str = "98") -> list[Kline]:
    # Internal high at local 1; bullish break at local 4. At off=1 Pine tests
    # low[0]-high[2] = break-low - 97.
    return [
        _kline(0, open_price="95", high="100", low="90", close="95"),
        _kline(1, open_price="96", high="101", low="92", close="97"),
        _kline(2, open_price="95", high="97", low="93", close="96"),
        _kline(3, open_price="98", high="99", low="95", close="98"),
        _kline(4, open_price="100", high="114", low=break_low, close="112"),
    ]


def _bearish_fvg_sequence() -> list[Kline]:
    # Internal low at local 1; bearish break at local 4. At off=1 Pine tests
    # low[2]-high[0] = low(local 2) - high(local 4).
    return [
        _kline(0, open_price="95", high="100", low="92", close="95"),
        _kline(1, open_price="94", high="98", low="90", close="93"),
        _kline(2, open_price="95", high="99", low="94", close="96"),
        _kline(3, open_price="96", high="98", low="93", close="95"),
        _kline(4, open_price="90", high="92", low="88", close="89"),
    ]


def _bullish_mitigation_sequence() -> list[Kline]:
    # OB source is local 1 (bottom 95), then the break bar trades below 95 but
    # closes above it. High/low mitigation deletes it; close mitigation keeps it.
    return [
        _kline(0, open_price="100", high="110", low="90", close="100"),
        _kline(1, open_price="105", high="112", low="95", close="107"),
        _kline(2, open_price="105", high="111", low="96", close="108"),
        _kline(3, open_price="106", high="110", low="100", close="108"),
        _kline(4, open_price="112", high="120", low="94", close="118"),
    ]


def _ob(
    index: int,
    *,
    bias: int,
    top: float,
    bottom: float,
) -> _PineOrderBlockState:
    return _PineOrderBlockState(
        top=top,
        bottom=bottom,
        bar_local_index=index,
        break_local_index=index + 1,
        source_time_ms=BASE_TIME_MS + index * 60_000,
        break_time_ms=BASE_TIME_MS + (index + 1) * 60_000,
        bias=bias,
        has_fvg=False,
    )


def test_config_records_pine_fvg_and_mitigation_defaults_and_validates_overrides() -> None:
    config = _config()
    assert config.fvg_min_atr == 0.10
    assert config.mitigate_close is False
    assert _config(fvg_min_atr=0, mitigate_close=True).fvg_min_atr == 0.0
    assert _config(fvg_min_atr=0.25, mitigate_close=True).mitigate_close is True

    for invalid in (-0.01, float("nan"), float("inf"), True, "0.1"):
        with pytest.raises(PineSmcReplayError, match="fvg_min_atr"):
            _config(fvg_min_atr=invalid)
    with pytest.raises(PineSmcReplayError, match="mitigate_close"):
        _config(mitigate_close=1)


def test_bullish_break_selects_lowest_parsed_low_with_oldest_tie_and_records_times() -> None:
    candles = [
        _kline(0, open_price="95", high="100", low="90", close="95"),
        _kline(1, open_price="96", high="101", low="92", close="97"),
        _kline(2, open_price="97", high="100", low="92", close="98"),
        _kline(3, open_price="98", high="99", low="95", close="98"),
        _kline(4, open_price="100", high="114", low="98", close="112"),
    ]
    trace = PineSmcStructureEngine(_config()).replay(candles).trace[4]

    assert trace.structure_events.bull_bos
    assert len(trace.ob_lifecycle.created) == 1
    ob = trace.ob_lifecycle.created[0]
    assert (ob.bias, ob.top, ob.bottom) == (1, 101.0, 92.0)
    assert ob.bar_local_index == 1  # index 2 ties; strict '<' retains oldest.
    assert ob.break_local_index == 4
    assert ob.source_time_ms == candles[1].open_time_ms
    assert ob.break_time_ms == candles[4].open_time_ms
    assert trace.active_order_blocks == (ob,)


def test_bearish_break_selects_highest_parsed_high_and_normalizes_bounds() -> None:
    candles = _bearish_fvg_sequence()
    trace = PineSmcStructureEngine(_config()).replay(candles).trace[4]

    assert trace.structure_events.bear_bos
    assert len(trace.ob_lifecycle.created) == 1
    ob = trace.ob_lifecycle.created[0]
    assert (ob.bias, ob.top, ob.bottom) == (-1, 99.0, 94.0)
    assert ob.bar_local_index == 2
    assert ob.source_time_ms == candles[2].open_time_ms
    assert ob.break_time_ms == candles[4].open_time_ms
    assert trace.active_order_blocks == (ob,)


def test_bullish_fvg_uses_exact_directional_offsets_and_current_atr_threshold() -> None:
    yes = PineSmcStructureEngine(_config(fvg_min_atr=0.10)).replay(
        _bullish_fvg_sequence()
    ).trace[4]
    boundary = PineSmcStructureEngine(_config(fvg_min_atr=1.0 / 8.6)).replay(
        _bullish_fvg_sequence()
    ).trace[4]
    no = PineSmcStructureEngine(_config(fvg_min_atr=0.50)).replay(
        _bullish_fvg_sequence()
    ).trace[4]

    assert yes.atr200 == pytest.approx(8.6)
    assert yes.ob_lifecycle.created[0].has_fvg is True
    assert boundary.ob_lifecycle.created[0].has_fvg is True  # gap >= fvgMinAtr * ATR
    assert no.ob_lifecycle.created[0].has_fvg is False


def test_bearish_fvg_uses_inverse_directional_offsets_and_atr_threshold() -> None:
    yes = PineSmcStructureEngine(_config(fvg_min_atr=0.10)).replay(
        _bearish_fvg_sequence()
    ).trace[4]
    boundary = PineSmcStructureEngine(_config(fvg_min_atr=2.0 / 6.8)).replay(
        _bearish_fvg_sequence()
    ).trace[4]
    no = PineSmcStructureEngine(_config(fvg_min_atr=0.50)).replay(
        _bearish_fvg_sequence()
    ).trace[4]

    assert yes.atr200 == pytest.approx(6.8)
    assert yes.ob_lifecycle.created[0].has_fvg is True
    assert boundary.ob_lifecycle.created[0].has_fvg is True  # gap >= fvgMinAtr * ATR
    assert no.ob_lifecycle.created[0].has_fvg is False


def test_span_one_pine_loop_descends_but_unavailable_future_fvg_reference_is_ignored() -> None:
    engine = PineSmcStructureEngine(_config())
    assert list(engine._pine_loop_range(1, 0)) == [1, 0]
    # The offset-zero branch uses low[-1] / high[-1]. It cannot form a valid
    # historical FVG; the valid offset-one branch has no three-bar gap here.
    candles = _bullish_fvg_sequence()[:4] + [
        _kline(4, open_price="100", high="114", low="98", close="112")
    ]
    # This sequence has span 3, so directly test the helper's span-one boundary.
    assert engine._has_directional_fvg(
        history=candles,
        local_index=4,
        span=1,
        bias=1,
        atr_threshold=2.0,
    ) is False


def test_high_low_mitigation_deletes_new_ob_on_creation_bar_but_close_mode_keeps_it() -> None:
    candles = _bullish_mitigation_sequence()
    wick_mode = PineSmcStructureEngine(_config(mitigate_close=False)).replay(candles).trace[4]
    close_mode = PineSmcStructureEngine(_config(mitigate_close=True)).replay(candles).trace[4]

    assert len(wick_mode.ob_lifecycle.created) == 1
    assert wick_mode.ob_lifecycle.created[0].bottom == 95.0
    assert wick_mode.ob_lifecycle.mitigated == wick_mode.ob_lifecycle.created
    assert wick_mode.active_order_blocks == ()

    assert close_mode.ob_lifecycle.created == wick_mode.ob_lifecycle.created
    assert close_mode.ob_lifecycle.mitigated == ()
    assert close_mode.active_order_blocks == close_mode.ob_lifecycle.created


def test_mitigation_comparisons_are_strict_at_the_ob_boundary() -> None:
    state = _PineSmcState()
    state.active_order_blocks.extend(
        [
            _ob(0, bias=1, top=100.0, bottom=95.0),
            _ob(1, bias=-1, top=105.0, bottom=100.0),
        ]
    )
    removed = PineSmcStructureEngine._mitigate_order_blocks(
        state.active_order_blocks,
        high=105.0,
        low=95.0,
        close=100.0,
        mitigate_close=False,
    )
    assert removed == ()
    assert len(state.active_order_blocks) == 2


def test_mitigation_uses_reverse_index_removal_order_and_selected_source() -> None:
    state = _PineSmcState()
    state.active_order_blocks.extend(
        [
            _ob(0, bias=1, top=100.0, bottom=95.0),
            _ob(1, bias=-1, top=105.0, bottom=100.0),
            _ob(2, bias=1, top=110.0, bottom=98.0),
            _ob(3, bias=-1, top=102.0, bottom=97.0),
        ]
    )
    removed = PineSmcStructureEngine._mitigate_order_blocks(
        state.active_order_blocks,
        high=111.0,
        low=90.0,
        close=100.0,
        mitigate_close=False,
    )
    assert [row.bar_local_index for row in removed] == [3, 2, 1, 0]
    assert state.active_order_blocks == []

    state.active_order_blocks.extend(
        [
            _ob(4, bias=1, top=100.0, bottom=95.0),
            _ob(5, bias=-1, top=105.0, bottom=100.0),
        ]
    )
    removed_close = PineSmcStructureEngine._mitigate_order_blocks(
        state.active_order_blocks,
        high=111.0,
        low=90.0,
        close=100.0,
        mitigate_close=True,
    )
    assert removed_close == ()
    assert len(state.active_order_blocks) == 2


def test_active_ob_collection_uses_100_item_oldest_first_fifo() -> None:
    active: list[_PineOrderBlockState] = []
    evicted: list[_PineOrderBlockState] = []
    for index in range(101):
        removed = PineSmcStructureEngine._push_order_block(
            active,
            _ob(index, bias=1, top=200.0 + index, bottom=100.0 + index),
        )
        if removed is not None:
            evicted.append(removed)

    assert len(active) == 100
    assert [row.bar_local_index for row in evicted] == [0]
    assert active[0].bar_local_index == 1
    assert active[-1].bar_local_index == 100


def test_ob_trace_is_immutable_and_jsonl_includes_lifecycle_snapshots() -> None:
    result = PineSmcStructureEngine(_config()).replay(_bullish_fvg_sequence())
    trace = result.trace[-1]
    ob = trace.active_order_blocks[0]
    assert isinstance(trace.active_order_blocks, tuple)
    with pytest.raises(FrozenInstanceError):
        ob.used = True  # type: ignore[misc]
    serialized = result.to_jsonl()
    assert '"active_order_blocks"' in serialized
    assert '"ob_lifecycle"' in serialized
    assert '"has_fvg":true' in serialized
    assert result.fvg_min_atr == 0.10
    assert result.mitigate_close is False
