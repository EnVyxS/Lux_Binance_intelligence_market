from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import MetadataParseError, parse_exchange_info
from divatrading.exchange.binance.resolver import (
    SymbolNotFoundError,
    SymbolNotTradableError,
    SymbolResolver,
)


FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def load_snapshot():
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    return parse_exchange_info(payload, source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo")


def test_parser_extracts_usdt_perpetual_and_filters():
    snapshot = load_snapshot()
    assert len(snapshot.symbols) == 5
    assert {item.symbol for item in snapshot.tradable_usdt_perpetuals} == {"BTCUSDT", "ETHUSDT"}

    btc = snapshot.get_symbol("btcusdt")
    assert btc is not None
    assert btc.price_filter is not None
    assert btc.price_filter.tick_size == Decimal("0.10")
    assert btc.lot_size is not None
    assert btc.lot_size.step_size == Decimal("0.001")
    assert btc.market_lot_size is not None
    assert btc.market_lot_size.max_qty == Decimal("500")
    assert btc.min_notional_filter is not None
    assert btc.min_notional_filter.min_notional == Decimal("5")
    assert btc.min_notional_filter.apply_to_market is True
    assert "NEW_EXPERIMENTAL_FILTER" in btc.unknown_filter_types
    assert btc.raw_filters[-1]["exampleField"] == "preserve-me"
    assert btc.price_precision == 2  # retained, but never used as tickSize


def test_missing_filters_are_tolerated_and_retained_as_empty():
    payload = {"symbols": [{
        "symbol": "NOFILTERUSDT", "contractType": "PERPETUAL", "status": "TRADING",
        "baseAsset": "NOFILTER", "quoteAsset": "USDT", "marginAsset": "USDT"
    }]}
    snapshot = parse_exchange_info(payload, source_endpoint="fixture")
    symbol = snapshot.symbols[0]
    assert symbol.price_filter is None
    assert symbol.lot_size is None
    assert symbol.market_lot_size is None
    assert symbol.raw_filters == ()
    assert symbol.is_tradable_usdt_perpetual


def test_malformed_known_filter_does_not_crash_and_raw_is_preserved():
    payload = {"symbols": [{
        "symbol": "TESTUSDT", "contractType": "PERPETUAL", "status": "TRADING",
        "baseAsset": "TEST", "quoteAsset": "USDT", "marginAsset": "USDT",
        "filters": [{"filterType": "PRICE_FILTER", "tickSize": "not-a-number"}]
    }]}
    symbol = parse_exchange_info(payload, source_endpoint="fixture").symbols[0]
    assert symbol.price_filter is not None
    assert symbol.price_filter.tick_size is None
    assert symbol.raw_filters[0]["tickSize"] == "not-a-number"


def test_resolver_requires_exact_contract_symbol():
    resolver = SymbolResolver(load_snapshot())
    assert resolver.resolve("btcusdt").symbol == "BTCUSDT"
    with pytest.raises(SymbolNotFoundError, match="Exact Binance symbol"):
        resolver.resolve("BTC")
    assert resolver.contains_exact("BTCUSDT")


def test_resolver_rejects_inactive_and_non_usdt_perpetual_contracts():
    resolver = SymbolResolver(load_snapshot())
    with pytest.raises(SymbolNotTradableError, match="status=SETTLING"):
        resolver.resolve("OLDUSDT")
    with pytest.raises(SymbolNotTradableError, match="quoteAsset=USD"):
        resolver.resolve("BTCUSD_PERP")
    with pytest.raises(SymbolNotTradableError, match="contractType=CURRENT_QUARTER"):
        resolver.resolve("BTCUSDT_260925")
    assert resolver.resolve("OLDUSDT", tradable_only=False).status == "SETTLING"


def test_top_level_malformed_exchange_info_is_rejected():
    with pytest.raises(MetadataParseError, match="symbols array"):
        parse_exchange_info({"symbols": "not-an-array"}, source_endpoint="fixture")
    with pytest.raises(MetadataParseError, match="JSON object"):
        parse_exchange_info([], source_endpoint="fixture")


def test_malformed_symbol_does_not_silently_enter_universe():
    with pytest.raises(MetadataParseError, match=r"symbols\[0\]"):
        parse_exchange_info({"symbols": [{"symbol": "BTCUSDT"}]}, source_endpoint="fixture")


def test_non_object_filter_is_retained_for_diagnostics():
    payload = {"symbols": [{
        "symbol": "TESTUSDT", "contractType": "PERPETUAL", "status": "TRADING",
        "baseAsset": "TEST", "quoteAsset": "USDT", "marginAsset": "USDT",
        "filters": ["unexpected-filter-payload"]
    }]}
    symbol = parse_exchange_info(payload, source_endpoint="fixture").symbols[0]
    assert symbol.raw_filters == ("unexpected-filter-payload",)
    assert "filters[0] is not an object" in symbol.filter_parse_warnings


def test_duplicate_contract_symbols_are_rejected():
    one = {
        "symbol": "BTCUSDT", "contractType": "PERPETUAL", "status": "TRADING",
        "baseAsset": "BTC", "quoteAsset": "USDT", "marginAsset": "USDT"
    }
    with pytest.raises(MetadataParseError, match="Duplicate contract symbol"):
        parse_exchange_info({"symbols": [one, dict(one)]}, source_endpoint="fixture")
