from __future__ import annotations

from pathlib import Path

import pytest

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.market_data.live_feed_graph import (
    BinanceFeedGraphConfig,
    BinanceFeedGraphError,
    BinancePublicFeedFactory,
)

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def test_feed_graph_config_enforces_canonical_timeframes_and_bounds():
    assert BinanceFeedGraphConfig().intervals == ("1m", "5m", "15m")
    with pytest.raises(ValueError, match="canonical production or Demo"):
        BinanceFeedGraphConfig(ws_endpoint="wss://untrusted.example/stream")
    with pytest.raises(ValueError, match="canonical order"):
        BinanceFeedGraphConfig(intervals=("1m", "15m", "5m"))
    with pytest.raises(ValueError, match="bootstrap_candles"):
        BinanceFeedGraphConfig(bootstrap_candles=10)
    with pytest.raises(ValueError, match="snapshot_interval_seconds"):
        BinanceFeedGraphConfig(snapshot_interval_seconds=0.01)


def test_feed_factory_requires_exact_exchange_metadata(tmp_path):
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("BTCUSDT")
    finally:
        client.close()


def test_feed_factory_accepts_only_exchange_info_symbols(tmp_path):
    payload = __import__("json").loads(FIXTURE.read_text(encoding="utf-8"))
    snapshot = parse_exchange_info(
        payload, source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo"
    )
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        factory.set_metadata(snapshot)
        stream = factory("BTCUSDT")
        assert hasattr(stream, "__aiter__")
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("NOTAREALCONTRACT")
    finally:
        client.close()


@pytest.mark.parametrize(("rest_url", "ws_origin"), [
    ("https://fapi.binance.com", "wss://fstream.binance.com"),
    ("https://demo-fapi.binance.com", "wss://demo-fstream.binance.com"),
], ids=["paper", "demo"])
def test_market_feed_graph_routes_depth_on_same_hosts_public_channel(tmp_path, rest_url, ws_origin):
    import asyncio
    import json

    from divatrading.market_data.live_feed_graph import _BinanceSymbolFeedGraph

    market_endpoint = ws_origin + "/market/stream"
    snapshot = parse_exchange_info(
        json.loads(FIXTURE.read_text(encoding="utf-8")),
        source_endpoint=rest_url + "/fapi/v1/exchangeInfo",
    )
    symbol_info = snapshot.get_symbol("BTCUSDT")
    assert symbol_info is not None
    client = BinanceUsdMFuturesRestClient(base_url=rest_url)
    database = Database(tmp_path / "test.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(
        rest_client=client, database=database,
        config=BinanceFeedGraphConfig(ws_endpoint=market_endpoint),
    )
    try:
        graph = _BinanceSymbolFeedGraph(
            symbol="BTCUSDT", symbol_info=symbol_info,
            rest_client=client, history_rest_client=factory._history_rest,
            depth_snapshot_client=factory._depth_snapshot,
            database=database, config=factory.config, bootstrap_lock=asyncio.Lock(),
        )
        assert factory.rest_client.base_url == rest_url
        assert factory._depth_snapshot._client.endpoint == rest_url + "/fapi/v1/depth"
        for feed in (graph.kline_feed, graph.mark_feed, graph.aggregate_feed):
            assert feed.endpoint == market_endpoint
        assert graph.depth_feed.endpoint == ws_origin + "/public/stream"
    finally:
        factory.close()
        client.close()


def test_capture_key_changes_when_flow_advances_or_a_feed_reconnects():
    from types import SimpleNamespace

    from divatrading.market_data.live_feed_graph import _BinanceSymbolFeedGraph

    candles = SimpleNamespace(latest_closed_candle=SimpleNamespace(open_time_ms=5))
    flow = SimpleNamespace(last_processed_aggregate_trade_id=10, window_end_ms=20)
    sources = SimpleNamespace(aggregate_trade_reconnect_generation=0, depth_reconnect_generation=0)
    view = SimpleNamespace(
        m1=candles, m5=candles, m15=candles, flow=flow, orchestrator_readiness=sources,
        mark_price=SimpleNamespace(event_time_ms=6),
        order_book_metrics=SimpleNamespace(update_id=7),
        readiness=SimpleNamespace(entry_quote_ready=True, delta_cvd_available=True),
    )
    capture = _BinanceSymbolFeedGraph._capture_key
    initial = capture(view)
    assert capture(view) == initial

    flow.last_processed_aggregate_trade_id += 1
    after_trade = capture(view)
    assert after_trade != initial

    sources.depth_reconnect_generation += 1
    after_reconnect = capture(view)
    assert after_reconnect != after_trade

    view.readiness.entry_quote_ready = False
    assert capture(view) != after_reconnect


def test_autonomous_environment_selection_has_no_mainnet_testnet_mixing():
    from divatrading.cli import _autonomous_market_endpoints
    from divatrading.execution.service import ExecutionMode
    from divatrading.execution.binance_private import TESTNET_BASE_URL
    from divatrading.exchange.binance.client import DEFAULT_BASE_URL
    from divatrading.market_data.websocket import (
        BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )

    assert _autonomous_market_endpoints(ExecutionMode.TESTNET) == (
        TESTNET_BASE_URL, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )
    assert _autonomous_market_endpoints(ExecutionMode.PAPER) == (
        DEFAULT_BASE_URL, BINANCE_UM_MARKET_WS_ENDPOINT,
    )
