from __future__ import annotations

import json
from pathlib import Path

import httpx

from divatrading.execution.binance_private import TESTNET_BASE_URL
from divatrading.execution.testnet_qualification import BinanceTestnetPreflight

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


class FakeTestnetClient:
    environment = "TESTNET"
    base_url = TESTNET_BASE_URL
    last_time_sync_rtt_ms = 120
    last_server_time_ms = 1_800_000_000_000

    def __init__(self, *, account=None, account_config=None, mode=None, positions=None, standard=None, algo=None,
                 exchange_info=None, rtt=120, fail=None):
        self.account = account if account is not None else {
            "totalWalletBalance": "1000", "availableBalance": "900",
        }
        self.account_config = account_config if account_config is not None else {
            "canTrade": True, "multiAssetsMargin": False,
        }
        self.mode = mode if mode is not None else {"dualSidePosition": False}
        self.positions = positions if positions is not None else []
        self.standard = standard if standard is not None else []
        self.algo = algo if algo is not None else []
        self.exchange_info = exchange_info if exchange_info is not None else json.loads(FIXTURE.read_text())
        self.last_time_sync_rtt_ms = rtt
        self.fail = fail
        self.calls = []

    def _call(self, name, value):
        self.calls.append(name)
        if self.fail == name:
            raise RuntimeError("private fixture error")
        return value

    def sync_server_time(self):
        self.calls.append("sync_server_time")
        if self.fail == "sync_server_time":
            raise RuntimeError("time sync failed")
        return 12

    def ping(self): return self._call("ping", {})
    def get_exchange_info(self): return self._call("get_exchange_info", self.exchange_info)
    def get_exchange_account(self): return self._call("get_exchange_account", self.account)
    def get_account_config(self): return self._call("get_account_config", self.account_config)
    def get_position_mode(self): return self._call("get_position_mode", self.mode)
    def get_position_risk(self, symbol=None): return self._call("get_position_risk", self.positions)
    def get_open_orders(self, symbol=None): return self._call("get_open_orders", self.standard)
    def get_open_algo_orders(self, symbol=None): return self._call("get_open_algo_orders", self.algo)


def test_testnet_preflight_ready_for_test_order_validation_without_order_submission():
    client = FakeTestnetClient()
    report = BinanceTestnetPreflight(client, symbols=("BTCUSDT",)).run()
    assert report.status == "READY_FOR_TEST_ORDER_VALIDATION"
    assert report.ready_for_test_order
    assert report.environment == "TESTNET"
    assert report.account_position_mode == "ONE_WAY"
    assert report.symbols == ("BTCUSDT",)
    assert report.order_submission_performed is False
    assert "new_order" not in client.calls
    assert "new_algo_order" not in client.calls
    assert any(item.code == "TRADE_PERMISSION" and item.status == "WARN" for item in report.checks)


def test_testnet_preflight_rejects_live_or_custom_endpoint_before_network_io():
    client = FakeTestnetClient()
    client.base_url = "https://fapi.binance.com"
    report = BinanceTestnetPreflight(client).run()
    assert report.status == "BLOCKED_ENDPOINT_ISOLATION"
    assert client.calls == []
    assert report.order_submission_performed is False


def test_testnet_preflight_rejects_unknown_or_inactive_symbol():
    report = BinanceTestnetPreflight(FakeTestnetClient(), symbols=("NOPEUSDT",)).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    check = next(item for item in report.checks if item.code == "SYMBOL_METADATA")
    assert check.status == "FAIL"
    assert "NOT_LISTED" in check.detail


def test_testnet_preflight_rejects_incomplete_contract_filters():
    payload = json.loads(FIXTURE.read_text())
    btc = next(row for row in payload["symbols"] if row["symbol"] == "BTCUSDT")
    btc["filters"] = [row for row in btc["filters"] if row["filterType"] != "PRICE_FILTER"]
    report = BinanceTestnetPreflight(FakeTestnetClient(exchange_info=payload)).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert "REQUIRED_FILTERS_INCOMPLETE" in next(
        item.detail for item in report.checks if item.code == "SYMBOL_METADATA"
    )


def test_testnet_preflight_rejects_account_with_open_positions_or_orders():
    client = FakeTestnetClient(
        positions=[{"symbol": "BTCUSDT", "positionAmt": "0.01"}],
        standard=[{"symbol": "ETHUSDT", "status": "NEW"}],
        algo=[{"symbol": "BTCUSDT", "algoStatus": "NEW"}],
    )
    report = BinanceTestnetPreflight(client).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert report.active_positions == 1
    assert report.open_standard_orders == 1
    assert report.open_algo_orders == 1


def test_testnet_preflight_rejects_multi_asset_margin_mode():
    account_config = {"canTrade": True, "multiAssetsMargin": True}
    report = BinanceTestnetPreflight(FakeTestnetClient(account_config=account_config)).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert any(item.code == "MARGIN_MODE" and item.status == "FAIL" for item in report.checks)


def test_testnet_preflight_rejects_disabled_exchange_trading_or_empty_balance():
    account = {"totalWalletBalance": "0", "availableBalance": "0"}
    account_config = {"canTrade": False, "multiAssetsMargin": False}
    report = BinanceTestnetPreflight(FakeTestnetClient(account=account, account_config=account_config)).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert any(item.code == "ACCOUNT_TRADING_STATUS" and item.status == "FAIL" for item in report.checks)
    assert any(item.code == "TEST_USDT_BALANCE" and item.status == "FAIL" for item in report.checks)



def test_testnet_preflight_reads_configuration_from_account_config_not_account_v3():
    # Binance's V3 account response intentionally omits configuration fields.
    account_v3 = {"totalWalletBalance": "2500", "availableBalance": "2100"}
    account_config = {"canTrade": True, "multiAssetsMargin": False}
    report = BinanceTestnetPreflight(
        FakeTestnetClient(account=account_v3, account_config=account_config)
    ).run()
    assert report.status == "READY_FOR_TEST_ORDER_VALIDATION"
    assert report.can_trade is True
    assert report.multi_assets_mode is False
    assert report.wallet_balance_usdt == "2500"
    assert report.available_balance_usdt == "2100"


def test_testnet_preflight_fails_closed_when_account_config_cannot_be_read():
    client = FakeTestnetClient(fail="get_account_config")
    report = BinanceTestnetPreflight(client).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert any(item.code == "ACCOUNT_CONFIG" and item.status == "FAIL" for item in report.checks)
    assert any(item.code == "ACCOUNT_TRADING_STATUS" and item.status == "FAIL" for item in report.checks)
    assert any(item.code == "MARGIN_MODE" and item.status == "FAIL" for item in report.checks)

def test_testnet_preflight_rejects_time_sync_rtt_above_bound():
    report = BinanceTestnetPreflight(FakeTestnetClient(rtt=2501)).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert any(item.code == "SERVER_TIME_SYNC" and item.status == "FAIL" for item in report.checks)


def test_testnet_preflight_fails_closed_on_signed_account_auth_error():
    client = FakeTestnetClient(fail="get_exchange_account")
    report = BinanceTestnetPreflight(client).run()
    assert report.status == "BLOCKED_PREFLIGHT"
    assert any(item.code == "SIGNED_ACCOUNT_AUTH" and item.status == "FAIL" for item in report.checks)


def test_testnet_preflight_parses_hedge_mode():
    report = BinanceTestnetPreflight(FakeTestnetClient(mode={"dualSidePosition": "true"})).run()
    assert report.account_position_mode == "HEDGE"
    assert report.status == "READY_FOR_TEST_ORDER_VALIDATION"


def test_real_private_rest_client_preflight_uses_only_signed_gets_on_demo_host():
    from divatrading.execution.binance_private import BinancePrivateRestClient

    seen = []
    fixture = json.loads(FIXTURE.read_text())

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.url.path == "/fapi/v1/ping":
            return httpx.Response(200, json={})
        if request.url.path == "/fapi/v1/time":
            return httpx.Response(200, json={"serverTime": 1_800_000_000_000})
        if request.url.path == "/fapi/v1/exchangeInfo":
            return httpx.Response(200, json=fixture)
        if request.url.path == "/fapi/v3/account":
            return httpx.Response(200, json={
                "totalWalletBalance": "1000", "availableBalance": "900",
            })
        if request.url.path == "/fapi/v1/accountConfig":
            return httpx.Response(200, json={"canTrade": True, "multiAssetsMargin": False})
        if request.url.path == "/fapi/v1/positionSide/dual":
            return httpx.Response(200, json={"dualSidePosition": False})
        if request.url.path in {"/fapi/v3/positionRisk", "/fapi/v1/openOrders", "/fapi/v1/openAlgoOrders"}:
            return httpx.Response(200, json=[])
        return httpx.Response(404, json={"code": -404, "msg": "unexpected endpoint"})

    http = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinancePrivateRestClient(
        "demo-api-key", "demo-api-secret", environment="TESTNET",
        http_client=http, wall_clock_ms=lambda: 1_800_000_000_000,
    )
    try:
        report = BinanceTestnetPreflight(client, symbols=("BTCUSDT",)).run()
    finally:
        client.close()

    assert report.status == "READY_FOR_TEST_ORDER_VALIDATION"
    assert all(request.url.host == "demo-fapi.binance.com" for request in seen)
    assert all(request.method == "GET" for request in seen)
    assert not any(request.url.path.endswith("/order") or "/algoOrder" in request.url.path for request in seen)
    # Signed account reads carry a signature; public reads do not.
    account_request = next(request for request in seen if request.url.path == "/fapi/v3/account")
    config_request = next(request for request in seen if request.url.path == "/fapi/v1/accountConfig")
    assert "signature" in account_request.url.query.decode()
    assert "signature" in config_request.url.query.decode()
    assert "demo-api-secret" not in repr(report.to_dict())
