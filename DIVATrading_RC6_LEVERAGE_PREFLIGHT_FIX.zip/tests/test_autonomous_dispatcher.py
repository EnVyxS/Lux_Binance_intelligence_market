from __future__ import annotations

import json
from decimal import Decimal

import pytest
from pathlib import Path

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.execution.account_state import AccountSnapshot, PositionSnapshot
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.strategy.scalping_market_data import InstrumentSpec
from divatrading.trading.coordinator import MultiPairExecutionCoordinator
from divatrading.trading.dispatcher import (
    AutonomousDispatcherConfig, AutonomousEntryDispatcher,
    BinancePortfolioSnapshotProvider, PaperPortfolioSnapshotProvider,
)
from divatrading.trading.models import QualifiedSignal
from divatrading.trading.risk import PortfolioRiskManager

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"
FIXED_NOW = 1794400000000


def _signal(signal_id: str = "auto-signal-1", *, created_at_ms: int = FIXED_NOW) -> QualifiedSignal:
    return QualifiedSignal(
        signal_id=signal_id, symbol="BTCUSDT", side="LONG", entry_type="LIMIT",
        entry_price=Decimal("50000.00"), stop_loss=Decimal("49900.00"),
        take_profit=Decimal("50300.00"), timeframe="5m", strategy_id="SMC_V2",
        created_at_ms=created_at_ms, reason_codes=("OB_ACTIVE", "ABSORPTION_ALIGNED"), score=82,
    )


def _coordinator(tmp_path: Path, *, simulate: bool = False):
    metadata = parse_exchange_info(json.loads(FIXTURE.read_text()), source_endpoint="fixture")
    info = metadata.get_symbol("BTCUSDT")
    assert info is not None
    instrument = InstrumentSpec.from_symbol_info(info)
    ledger = ExecutionLedger(tmp_path / "auto-dispatch.sqlite")
    execution = ExecutionService(
        ledger,
        config=ExecutionConfig(mode=ExecutionMode.PAPER, paper_simulate_fills=simulate),
    )
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": instrument}, risk_manager=PortfolioRiskManager(),
        execution_service=execution, ledger=ledger,
    )
    return ledger, execution, coordinator


class _CountingPaperProvider:
    def __init__(self, ledger: ExecutionLedger, *, captured_at_ms: int = FIXED_NOW):
        self.ledger = ledger
        self.captured_at_ms = captured_at_ms
        self.calls = 0
        self.claim_seen = False

    def capture(self):
        self.calls += 1
        row = self.ledger.get_signal_dispatch("auto-signal-1")
        self.claim_seen = row is not None and row["status"] == "SNAPSHOT_PENDING"
        return PaperPortfolioSnapshotProvider(
            Decimal("10000"), clock_ms=lambda: self.captured_at_ms,
        ).capture()


def test_dispatch_claim_is_durable_before_snapshot_provider_io_and_deduplicates(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)
    provider = _CountingPaperProvider(ledger)
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator, snapshot_provider=provider, ledger=ledger,
        config=AutonomousDispatcherConfig(), clock_ms=lambda: FIXED_NOW,
    )
    first = dispatcher.dispatch(_signal())
    assert first.status == "DISPATCHED"
    assert provider.claim_seen
    assert provider.calls == 1
    dispatch = ledger.get_signal_dispatch("auto-signal-1")
    assert dispatch is not None and dispatch["status"] == "DISPATCHED"
    assert dispatch["result"]["risk_accepted"] is True

    duplicate = dispatcher.dispatch(_signal())
    assert duplicate.duplicate
    assert duplicate.status == "DISPATCHED"
    assert provider.calls == 1


def test_dispatch_rejects_stale_portfolio_snapshot_without_risk_or_entry_intent(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)
    provider = _CountingPaperProvider(ledger, captured_at_ms=FIXED_NOW - 60_000)
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator, snapshot_provider=provider, ledger=ledger,
        config=AutonomousDispatcherConfig(max_snapshot_age_ms=5_000),
        clock_ms=lambda: FIXED_NOW,
    )
    result = dispatcher.dispatch(_signal())
    assert result.status == "REQUIRES_RECONCILIATION"
    assert "PORTFOLIO_SNAPSHOT_STALE" in result.reason
    assert ledger.get_intent("auto-signal-1") is None
    assert ledger.get_risk_reservation("auto-signal-1") is None
    assert ledger.get_signal_dispatch("auto-signal-1")["status"] == "REQUIRES_RECONCILIATION"


def test_dispatch_rejects_expired_signal_before_snapshot_io(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)
    provider = _CountingPaperProvider(ledger)
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator, snapshot_provider=provider, ledger=ledger,
        config=AutonomousDispatcherConfig(max_signal_age_ms=2_000),
        clock_ms=lambda: FIXED_NOW,
    )
    result = dispatcher.dispatch(_signal(created_at_ms=FIXED_NOW - 10_000))
    assert result.status == "REQUIRES_RECONCILIATION"
    assert result.reason.endswith("SIGNAL_EXPIRED_BEFORE_DISPATCH")
    assert provider.calls == 0


def test_paper_simulation_creates_deterministic_fill_and_quantity_scoped_virtual_protection(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path, simulate=True)
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator,
        snapshot_provider=PaperPortfolioSnapshotProvider(Decimal("10000"), clock_ms=lambda: FIXED_NOW),
        ledger=ledger, clock_ms=lambda: FIXED_NOW,
    )
    result = dispatcher.dispatch(_signal())
    assert result.status == "DISPATCHED"
    assert result.route is not None and result.route.execution is not None
    assert result.route.execution.status == "PAPER_PROTECTED"
    assert result.route.execution.entry_order["paper"] is True
    positions = ledger.list_managed_positions(status="OPEN")
    assert len(positions) == 1
    assert positions[0]["signal_id"] == "auto-signal-1"
    assert Decimal(positions[0]["quantity"]) == result.route.risk.plan.quantity
    assert ledger.get_risk_reservation("auto-signal-1")["status"] == "ACTIVE"
    roles = {"STOP_LOSS", "TAKE_PROFIT"}
    assert {row["role"] for row in ledger.list_orders("auto-signal-1")} >= roles


def test_binance_snapshot_provider_maps_exchange_truth_fields():
    class FakeAccountState:
        def capture(self):
            return AccountSnapshot(
                wallet_balance=Decimal("1000"), equity=Decimal("950"),
                available_balance=Decimal("700"), margin_balance=Decimal("950"),
                open_risk_usdt=Decimal("250"),
                positions=(PositionSnapshot(
                    "BTCUSDT", "BOTH", Decimal("0.01"), Decimal("50000"),
                    Decimal("51000"), Decimal("10"), Decimal("510"), False,
                ),),
                open_standard_orders=(), open_algo_orders=(),
            )
    provider = BinancePortfolioSnapshotProvider(FakeAccountState(), clock_ms=lambda: FIXED_NOW)
    snapshot = provider.capture()
    assert snapshot.equity_usdt == Decimal("950")
    assert snapshot.open_risk_usdt == Decimal("250")
    assert snapshot.active_position_count == 1
    assert snapshot.symbol_notional_usdt == {"BTCUSDT": Decimal("510")}
    assert snapshot.source == "BINANCE_REST_CONSERVATIVE_UNATTRIBUTED"


def test_empty_coordinator_universe_is_allowed_only_when_explicit(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "empty-universe.sqlite")
    execution = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    try:
        MultiPairExecutionCoordinator(
            instruments={}, risk_manager=PortfolioRiskManager(),
            execution_service=execution, ledger=ledger,
        )
        assert False, "expected default empty universe rejection"
    except ValueError:
        pass
    coordinator = MultiPairExecutionCoordinator(
        instruments={}, risk_manager=PortfolioRiskManager(),
        execution_service=execution, ledger=ledger, allow_empty_instruments=True,
    )
    assert coordinator.symbols == ()


def test_binance_snapshot_provider_does_not_double_count_fully_owned_reserved_position(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "owned-account.sqlite")
    signal = _signal("owned-signal")
    ledger.claim_intent(
        signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side,
        client_order_id=ledger.deterministic_client_id(signal.signal_id, "ENTRY"),
        payload={"signal": {"signal_id": signal.signal_id}},
    )
    ledger.update_intent(signal.signal_id, "PROTECTED")
    ledger.record_position(
        symbol="BTCUSDT", position_side="BOTH", signal_id=signal.signal_id,
        quantity="0.10", entry_price="50000", stop_loss="49900", take_profit="50300",
    )
    reservation = ledger.reserve_portfolio_risk(
        signal_id=signal.signal_id, symbol="BTCUSDT", risk_usdt=Decimal("10"),
        notional_usdt=Decimal("5000"), equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
        max_positions=5, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"), max_symbol_notional_usdt=Decimal("60000"),
    )
    assert reservation.accepted

    class FakeAccountState:
        def capture(self):
            return AccountSnapshot(
                wallet_balance=Decimal("10000"), equity=Decimal("10000"),
                available_balance=Decimal("9000"), margin_balance=Decimal("10000"),
                open_risk_usdt=Decimal("5000"),
                positions=(PositionSnapshot(
                    "BTCUSDT", "BOTH", Decimal("0.10"), Decimal("50000"),
                    Decimal("50000"), Decimal("0"), Decimal("5000"), False,
                ),), open_standard_orders=(), open_algo_orders=(),
            )

    snapshot = BinancePortfolioSnapshotProvider(
        FakeAccountState(), ledger=ledger, clock_ms=lambda: FIXED_NOW,
    ).capture()
    assert snapshot.open_risk_usdt == Decimal("0")
    assert snapshot.active_position_count == 0
    assert snapshot.symbol_notional_usdt == {}
    assert snapshot.source == "BINANCE_REST_WITH_DIVA_OWNERSHIP_NETTING"


def test_binance_snapshot_provider_treats_unmatched_local_quantity_as_external(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "mismatch-account.sqlite")
    signal = _signal("mismatch-signal")
    ledger.claim_intent(
        signal_id=signal.signal_id, symbol=signal.symbol, side=signal.side,
        client_order_id=ledger.deterministic_client_id(signal.signal_id, "ENTRY"),
        payload={"signal": {"signal_id": signal.signal_id}},
    )
    ledger.update_intent(signal.signal_id, "PROTECTED")
    ledger.record_position(
        symbol="BTCUSDT", position_side="BOTH", signal_id=signal.signal_id,
        quantity="0.05", entry_price="50000", stop_loss="49900", take_profit="50300",
    )
    ledger.reserve_portfolio_risk(
        signal_id=signal.signal_id, symbol="BTCUSDT", risk_usdt=Decimal("5"),
        notional_usdt=Decimal("2500"), equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=0,
        max_positions=5, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"), max_symbol_notional_usdt=Decimal("60000"),
    )

    class FakeAccountState:
        def capture(self):
            return AccountSnapshot(
                wallet_balance=Decimal("10000"), equity=Decimal("10000"),
                available_balance=Decimal("9000"), margin_balance=Decimal("10000"),
                open_risk_usdt=Decimal("5000"),
                positions=(PositionSnapshot(
                    "BTCUSDT", "BOTH", Decimal("0.10"), Decimal("50000"),
                    Decimal("50000"), Decimal("0"), Decimal("5000"), False,
                ),), open_standard_orders=(), open_algo_orders=(),
            )

    snapshot = BinancePortfolioSnapshotProvider(
        FakeAccountState(), ledger=ledger, clock_ms=lambda: FIXED_NOW,
    ).capture()
    assert snapshot.open_risk_usdt == Decimal("5000")
    assert snapshot.active_position_count == 1
    assert snapshot.symbol_notional_usdt == {"BTCUSDT": Decimal("5000")}


def test_binance_snapshot_provider_counts_unattributed_open_limit_orders_as_risk(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "external-order-account.sqlite")

    class FakeAccountState:
        def capture(self):
            return AccountSnapshot(
                wallet_balance=Decimal("10000"), equity=Decimal("10000"),
                available_balance=Decimal("9000"), margin_balance=Decimal("10000"),
                open_risk_usdt=Decimal("0"), positions=(),
                open_standard_orders=({
                    "symbol": "ETHUSDT", "clientOrderId": "manual-order-1",
                    "origQty": "0.5", "executedQty": "0.1", "price": "2000",
                    "reduceOnly": False,
                },),
                open_algo_orders=(),
            )

    snapshot = BinancePortfolioSnapshotProvider(
        FakeAccountState(), ledger=ledger, clock_ms=lambda: FIXED_NOW,
    ).capture()
    assert snapshot.open_risk_usdt == Decimal("800")
    assert snapshot.active_position_count == 1
    assert snapshot.symbol_notional_usdt == {"ETHUSDT": Decimal("800.0")}


def test_binance_snapshot_provider_fails_closed_on_unpriced_external_open_order(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "unpriced-external-order.sqlite")

    class FakeAccountState:
        def capture(self):
            return AccountSnapshot(
                wallet_balance=Decimal("10000"), equity=Decimal("10000"),
                available_balance=Decimal("9000"), margin_balance=Decimal("10000"),
                open_risk_usdt=Decimal("0"), positions=(), open_standard_orders=(),
                open_algo_orders=({
                    "symbol": "BTCUSDT", "clientAlgoId": "manual-algo-1",
                    "quantity": "0.01", "triggerPrice": "0",
                    "closePosition": False,
                },),
            )

    with pytest.raises(RuntimeError, match="UNPRICED_EXTERNAL_OPEN_ORDER:BTCUSDT"):
        BinancePortfolioSnapshotProvider(
            FakeAccountState(), ledger=ledger, clock_ms=lambda: FIXED_NOW,
        ).capture()


def test_snapshot_captured_after_dispatch_start_is_aged_against_post_request_clock(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)
    decision_times = iter((FIXED_NOW, FIXED_NOW + 8_000))
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator,
        snapshot_provider=_CountingPaperProvider(ledger, captured_at_ms=FIXED_NOW + 8_000),
        ledger=ledger, clock_ms=lambda: next(decision_times),
    )
    result = dispatcher.dispatch(_signal())
    assert result.status == "DISPATCHED"
    row = ledger.get_signal_dispatch("auto-signal-1")
    assert row["result"]["snapshot_age_ms"] == 0
    assert row["result"]["signal_age_at_risk_routing_ms"] == 8_000


def test_signal_that_expires_during_slow_snapshot_is_not_routed(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)
    decision_times = iter((FIXED_NOW, FIXED_NOW + 31_000))
    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator,
        snapshot_provider=_CountingPaperProvider(ledger, captured_at_ms=FIXED_NOW + 31_000),
        ledger=ledger, clock_ms=lambda: next(decision_times),
    )
    result = dispatcher.dispatch(_signal())
    assert result.status == "REQUIRES_RECONCILIATION"
    assert result.reason.endswith("SIGNAL_EXPIRED_DURING_PORTFOLIO_SNAPSHOT")
    assert ledger.get_intent("auto-signal-1") is None
    assert ledger.get_risk_reservation("auto-signal-1") is None


def test_entry_halt_set_during_snapshot_prevents_risk_routing(tmp_path: Path):
    ledger, _, coordinator = _coordinator(tmp_path)

    class HaltingProvider(_CountingPaperProvider):
        def capture(self):
            self.ledger.set_entries_halted(True, "TEST_HALT_DURING_SNAPSHOT")
            return super().capture()

    dispatcher = AutonomousEntryDispatcher(
        coordinator=coordinator,
        snapshot_provider=HaltingProvider(ledger),
        ledger=ledger, clock_ms=lambda: FIXED_NOW,
    )
    result = dispatcher.dispatch(_signal())
    assert result.status == "REQUIRES_RECONCILIATION"
    assert "ENTRIES_HALTED_AFTER_SNAPSHOT" in result.reason
    assert ledger.get_intent("auto-signal-1") is None
    assert ledger.get_risk_reservation("auto-signal-1") is None
