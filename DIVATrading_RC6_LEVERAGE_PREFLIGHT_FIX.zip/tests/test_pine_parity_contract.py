from decimal import Decimal
from pathlib import Path
import json

import pytest

from divatrading.strategy.parity_contract import (
    ParityContractError,
    ParitySignal,
    compare_signal_sets,
)

ROOT = Path(__file__).resolve().parents[1]


def _signal(**overrides: object) -> ParitySignal:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "5m",
        "event_time_ms": 1_700_000_000_000,
        "evaluation_time_ms": 1_700_000_060_000,
        "direction": "BUY",
        "trigger": "REJECTION",
        "ob_source_time_ms": 1_699_999_700_000,
        "entry_proxy": Decimal("100.00"),
        "stop_loss": Decimal("99.00"),
        "take_profit": Decimal("102.00"),
        "ob_top": Decimal("100.50"),
        "ob_bottom": Decimal("99.50"),
        "entry_band_low": Decimal("99.70"),
        "entry_band_high": Decimal("100.20"),
        "setup_score": Decimal("82.5"),
        "ob_quality_score": Decimal("80.0"),
        "timing_score": Decimal("92.5"),
    }
    values.update(overrides)
    if "event_time_ms" in overrides and "evaluation_time_ms" not in overrides:
        values["evaluation_time_ms"] = int(values["event_time_ms"]) + 60_000
    return ParitySignal(**values)  # type: ignore[arg-type]


def test_parity_signal_is_frozen_and_has_stable_key() -> None:
    signal = _signal()
    assert signal.key == ("BTCUSDT", "5m", 1_700_000_000_000, "BUY")
    with pytest.raises((AttributeError, TypeError)):
        signal.setup_score = Decimal("90")  # type: ignore[misc]


def test_parity_signal_rejects_invalid_timeframe_and_direction() -> None:
    with pytest.raises(ParityContractError, match="timeframe"):
        _signal(timeframe="3m")
    with pytest.raises(ParityContractError, match="direction"):
        _signal(direction="LONG")


def test_parity_signal_rejects_inconsistent_price_levels() -> None:
    with pytest.raises(ParityContractError, match="BUY levels"):
        _signal(stop_loss=Decimal("100.10"))
    with pytest.raises(ParityContractError, match="OB bottom"):
        _signal(ob_bottom=Decimal("100.50"))


def test_compare_signal_sets_exact_match_is_passed() -> None:
    report = compare_signal_sets([_signal()], [_signal()])
    assert report.passed
    assert report.expected_count == 1
    assert report.actual_count == 1
    assert report.matched_count == 1
    assert report.mismatches == ()


def test_compare_signal_sets_reports_missing_and_unexpected_deterministically() -> None:
    expected = [_signal(), _signal(event_time_ms=1_700_000_300_000)]
    actual = [_signal(event_time_ms=1_700_000_600_000)]
    report = compare_signal_sets(expected, actual)
    assert not report.passed
    assert [item.kind for item in report.mismatches] == ["MISSING", "MISSING", "UNEXPECTED"]


def test_compare_signal_sets_uses_only_explicit_price_and_score_tolerances() -> None:
    expected = _signal()
    actual = _signal(
        entry_proxy=Decimal("100.01"),
        setup_score=Decimal("82.6"),
    )
    strict = compare_signal_sets([expected], [actual])
    assert not strict.passed
    assert {item.field_name for item in strict.mismatches} == {"entry_proxy", "setup_score"}

    tolerant = compare_signal_sets(
        [expected],
        [actual],
        price_tolerance=Decimal("0.01"),
        score_tolerance=Decimal("0.1"),
    )
    assert tolerant.passed
    assert tolerant.matched_count == 1


def test_compare_signal_sets_keeps_trigger_and_source_time_exact() -> None:
    expected = _signal()
    actual = _signal(trigger="STRUCTURE", ob_source_time_ms=1_699_999_400_000)
    report = compare_signal_sets([expected], [actual], price_tolerance=Decimal("1"))
    assert {item.field_name for item in report.mismatches} == {"trigger", "ob_source_time_ms"}


def test_compare_signal_sets_rejects_duplicate_keys_and_negative_tolerance() -> None:
    with pytest.raises(ParityContractError, match="duplicate expected"):
        compare_signal_sets([_signal(), _signal()], [])
    with pytest.raises(ParityContractError, match="cannot be negative"):
        compare_signal_sets([], [], price_tolerance=Decimal("-0.01"))


def test_pine_source_manifest_and_fixture_schema_are_parseable_and_explicit() -> None:
    manifest = json.loads((ROOT / "reference/pine_smc/PINE_SOURCE_MANIFEST.json").read_text())
    schema = json.loads((ROOT / "reference/pine_smc/reference_fixture.schema.json").read_text())
    template = json.loads((ROOT / "reference/pine_smc/reference_fixture.template.json").read_text())

    assert manifest["pine_language_version"] == 6
    assert manifest["source_lines"] == 905
    assert manifest["candidate_contents_byte_identical"] is True
    assert len(manifest["sha256"]) == 64
    assert schema["required"] == [
        "fixture_version", "provenance", "replay", "candle_series", "coverage", "reference_signals"
    ]
    assert template["reference_signals"] == []
    assert template["coverage"]["complete"] is False
    assert len(schema["properties"]["provenance"]["properties"]["effective_inputs"]["required"]) == 49
    assert len(template["provenance"]["effective_inputs"]) == 49


def test_compare_signal_sets_reports_shifted_evaluation_time_separately() -> None:
    expected = _signal(evaluation_time_ms=1_700_000_060_000)
    actual = _signal(evaluation_time_ms=1_700_000_120_000)
    report = compare_signal_sets([expected], [actual])
    assert [item.field_name for item in report.mismatches] == ["evaluation_time_ms"]


def test_parity_signal_rejects_evaluation_time_before_source_event() -> None:
    with pytest.raises(ParityContractError, match="cannot precede"):
        _signal(evaluation_time_ms=1_699_999_999_999)
