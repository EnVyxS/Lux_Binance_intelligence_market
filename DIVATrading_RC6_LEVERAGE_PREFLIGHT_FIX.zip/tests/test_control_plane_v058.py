from decimal import Decimal

import pytest

from divatrading.core.database import Database
from divatrading.trading.control_plane import (
    OperatorControlStore, LossState, evaluate_loss_limits, choose_leverage,
    enforce_bot_only_account,
)


def store(tmp_path):
    db = Database(tmp_path / "controls.db")
    return OperatorControlStore(db)


def test_persistent_risk_fixed_and_percent(tmp_path):
    s = store(tmp_path)
    assert s.set_risk("fixed", "2.75")["risk"] == {"mode": "FIXED", "value": "2.75"}
    # New store instance sees same persisted config after process restart.
    assert OperatorControlStore(Database(tmp_path / "controls.db")).get()["risk"]["value"] == "2.75"
    s.set_risk("percent", "3")
    assert s.get()["risk"] == {"mode": "PERCENT", "value": "3"}


def test_risk_rejects_nonfinite_and_out_of_range(tmp_path):
    s = store(tmp_path)
    for value in ("NaN", "Infinity", "0", "-1"):
        with pytest.raises(ValueError): s.set_risk("fixed", value)
    with pytest.raises(ValueError): s.set_risk("percent", "100.01")


def test_loss_limits_block_new_entries(tmp_path):
    s = store(tmp_path)
    s.set_maxloss("daily", "1", "USDT")
    s.set_maxloss("streak", "3")
    s.set_maxloss("drawdown", "5", "PERCENT")
    state = LossState(Decimal("-0.8"), Decimal("-0.3"), 3,
                      Decimal("100"), Decimal("94"), "2026-11-14")
    gate = evaluate_loss_limits(s.get(), state)
    assert not gate.allow_new_entries
    assert set(gate.reasons) == {"DAILY_MAX_LOSS_REACHED", "CONSECUTIVE_LOSS_LIMIT_REACHED", "MAX_DRAWDOWN_REACHED"}


def test_leverage_chooses_lowest_feasible_and_never_expands_notional():
    result = choose_leverage(
        notional_usdt=Decimal("20"), available_margin_usdt=Decimal("7"),
        max_leverage=10, min_liquidation_buffer_pct=Decimal("10"),
        estimated_liquidation_buffer_by_leverage={1: Decimal("80"), 2: Decimal("40"), 3: Decimal("20"), 4: Decimal("5")},
        fee_reserve_usdt=Decimal("0.1"),
    )
    assert result.accepted and result.leverage == 3
    assert result.required_margin_usdt == Decimal("20") / Decimal("3") + Decimal("0.1")


def test_bot_only_detects_external_position_and_order():
    ok, reasons = enforce_bot_only_account(
        exchange_positions=[{"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "0.01"}],
        managed_positions=[], managed_orders=[],
        open_standard_orders=[{"symbol": "ETHUSDT", "orderId": 123, "clientOrderId": "manual"}],
        open_algo_orders=[],
    )
    assert not ok
    assert set(reasons) == {"EXTERNAL_POSITION_DETECTED", "EXTERNAL_OPEN_ORDER_DETECTED"}


def test_bot_only_accepts_exactly_owned_state():
    ok, reasons = enforce_bot_only_account(
        exchange_positions=[{"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "0.01"}],
        managed_positions=[{"symbol": "BTCUSDT", "position_side": "BOTH", "signal_side": "LONG", "quantity": "0.01"}],
        open_standard_orders=[{"symbol": "BTCUSDT", "orderId": 123}],
        open_algo_orders=[{"symbol": "BTCUSDT", "algoId": 123, "clientAlgoId": "diva-stop"}],
        managed_orders=[
            {"symbol": "BTCUSDT", "order_kind": "STANDARD", "exchange_order_id": "123", "client_id": "diva-entry"},
            {"symbol": "BTCUSDT", "order_kind": "ALGO", "exchange_order_id": None, "client_id": "diva-stop"},
        ],
    )
    assert ok and not reasons


@pytest.mark.parametrize(("standard", "algo"), [
    ([{"symbol": "ETHUSDT", "orderId": 123}], []),
    ([{"symbol": "ETHUSDT", "clientOrderId": "diva-entry"}], []),
    ([], [{"symbol": "BTCUSDT", "algoId": 123}]),
    ([], [{"symbol": "BTCUSDT", "clientAlgoId": "diva-entry"}]),
    ([{"symbol": "BTCUSDT", "orderId": 123, "clientOrderId": "manual"}], []),
    ([{"symbol": "BTCUSDT", "orderId": 987, "clientOrderId": "diva-entry"}], []),
])
def test_bot_only_rejects_orders_with_scoped_id_collisions(standard, algo):
    ok, reasons = enforce_bot_only_account(
        exchange_positions=[], managed_positions=[],
        open_standard_orders=standard, open_algo_orders=algo,
        managed_orders=[
            {"symbol": "BTCUSDT", "order_kind": "STANDARD", "exchange_order_id": "123", "client_id": "diva-entry"},
        ],
    )
    assert not ok and reasons == ("EXTERNAL_OPEN_ORDER_DETECTED",)


def test_telegram_owner_only_and_config_persistence(tmp_path):
    from divatrading.trading.control_plane import TelegramControlBot
    s = store(tmp_path)
    bot = TelegramControlBot("dummy-token", "12345", s)
    assert bot.handle("999", "/risk fixed 2") == "Unauthorized."
    assert "Risk saved" in bot.handle("12345", "/risk fixed 2")
    assert s.get()["risk"]["value"] == "2"
    assert "KILL LATCHED" in bot.handle("12345", "/kill")
    assert s.get()["runtime"]["killed"] is True


def test_bot_only_detects_same_symbol_manual_scale_in_by_quantity_mismatch():
    ok, reasons = enforce_bot_only_account(
        exchange_positions=[{"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "0.03"}],
        managed_positions=[{"symbol": "BTCUSDT", "position_side": "BOTH", "signal_side": "LONG", "quantity": "0.01"}],
        open_standard_orders=[], open_algo_orders=[], managed_orders=[],
    )
    assert not ok and reasons == ("POSITION_QUANTITY_MISMATCH",)


def test_bot_only_distinguishes_one_way_short_from_same_sized_long():
    managed = {"symbol": "BTCUSDT", "position_side": "BOTH", "signal_side": "SHORT", "quantity": "0.01"}
    exchange = {"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": "-0.01"}
    for amount, expected in (
        ("-0.01", (True, ())),
        ("0.01", (False, ("POSITION_DIRECTION_MISMATCH",))),
    ):
        assert enforce_bot_only_account(
            exchange_positions=[{**exchange, "positionAmt": amount}],
            managed_positions=[managed],
            open_standard_orders=[], open_algo_orders=[], managed_orders=[],
        ) == expected


def test_daily_percent_limit_uses_persisted_day_start_equity():
    from divatrading.trading.control_plane import DEFAULTS
    settings = {**DEFAULTS, "max_loss": {**DEFAULTS["max_loss"], "daily_mode": "PERCENT", "daily_value": "2"}}
    state = LossState(Decimal("-2.1"), Decimal("0"), 0,
                      Decimal("200"), Decimal("80"), "2026-11-14", Decimal("100"))
    gate = evaluate_loss_limits(settings, state)
    assert not gate.allow_new_entries
    assert gate.reasons == ("DAILY_MAX_LOSS_REACHED",)


def test_telegram_offset_persists_across_bot_restart_and_is_monotonic(tmp_path):
    from divatrading.trading.control_plane import TelegramControlBot
    s = store(tmp_path)
    s.set_telegram_offset(42)
    bot = TelegramControlBot("dummy-token", "12345", s)
    assert bot.offset == 42
    s.set_telegram_offset(50)
    s.set_telegram_offset(47)
    restarted = TelegramControlBot("dummy-token", "12345", s)
    assert restarted.offset == 50


def test_kill_latch_requires_explicit_confirmed_reset(tmp_path):
    from divatrading.trading.control_plane import TelegramControlBot
    s = store(tmp_path)
    bot = TelegramControlBot("dummy-token", "12345", s)
    bot.handle("12345", "/kill")
    assert s.get()["runtime"] == {"paused": True, "killed": True}
    assert "Invalid command" in bot.handle("12345", "/resetkill")
    assert s.get()["runtime"] == {"paused": True, "killed": True}
    assert "KILL LATCH CLEARED" in bot.handle("12345", "/resetkill confirm")
    assert s.get()["runtime"] == {"paused": False, "killed": False}
