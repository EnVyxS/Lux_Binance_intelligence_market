from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from decimal import Decimal

import pytest

from divatrading.market_data.aggregate_trade_fanout import (
    AggregateTradeEventFanout,
    AggregateTradeFanoutQueueFullError,
    AggregateTradeFanoutSubscriptionError,
)
from divatrading.market_data.aggregate_trades import AggregateTradeEvent


def event(symbol="BTCUSDT", aggregate_id=1):
    return AggregateTradeEvent(
        symbol=symbol, aggregate_trade_id=aggregate_id, price=Decimal("100"),
        quantity=Decimal("0.1"), first_trade_id=1, last_trade_id=1,
        event_time_ms=1_800_000_000_000, trade_time_ms=1_800_000_000_000,
        buyer_is_maker=False, source_endpoint="wss://test", stream_name=f"{symbol.lower()}@aggTrade",
        received_at_utc=datetime.now(UTC),
    )


def test_subscriptions_receive_same_immutable_event_and_symbol_filtering():
    fanout = AggregateTradeEventFanout(default_queue_capacity=4)
    all_symbols = fanout.subscribe()
    btc_only = fanout.subscribe(symbol="btcusdt")
    eth_only = fanout.subscribe(symbol="ETHUSDT")
    value = event()
    assert fanout.publish(value) == 2
    assert all_symbols.get_nowait() is value
    assert btc_only.get_nowait() is value
    with pytest.raises(asyncio.QueueEmpty):
        eth_only.get_nowait()
    assert fanout.stats.subscriber_count == 3
    assert fanout.stats.events_published == 1
    assert fanout.stats.events_delivered == 2


def test_fanout_overflow_is_atomic_across_all_matching_subscribers():
    fanout = AggregateTradeEventFanout(default_queue_capacity=2)
    fast = fanout.subscribe(symbol="BTCUSDT", queue_capacity=2)
    slow = fanout.subscribe(symbol="BTCUSDT", queue_capacity=1)
    fanout.publish(event(aggregate_id=1))
    with pytest.raises(AggregateTradeFanoutQueueFullError):
        fanout.publish(event(aggregate_id=2))
    assert fast.queue_depth == 1
    assert slow.queue_depth == 1
    assert fast.get_nowait().aggregate_trade_id == 1
    assert slow.get_nowait().aggregate_trade_id == 1
    assert fanout.stats.events_published == 1
    assert fanout.stats.events_delivered == 2
    assert fanout.stats.queue_overflows == 1


def test_unsubscribe_stops_future_delivery():
    fanout = AggregateTradeEventFanout(default_queue_capacity=2)
    subscription = fanout.subscribe(symbol="BTCUSDT")
    assert subscription.unsubscribe()
    assert not subscription.unsubscribe()
    assert fanout.publish(event()) == 0
    assert subscription.queue_depth == 0


def test_fanout_capacity_and_subscription_limits_are_hard_bounded():
    with pytest.raises(ValueError):
        AggregateTradeEventFanout(default_queue_capacity=8193)
    with pytest.raises(ValueError):
        AggregateTradeEventFanout(max_subscribers=33)
    with pytest.raises(ValueError):
        AggregateTradeEventFanout(default_queue_capacity=True)
    fanout = AggregateTradeEventFanout(max_subscribers=1)
    fanout.subscribe()
    with pytest.raises(AggregateTradeFanoutSubscriptionError):
        fanout.subscribe()


def test_publish_rejects_non_event_objects():
    fanout = AggregateTradeEventFanout()
    with pytest.raises(TypeError):
        fanout.publish(object())
