from __future__ import annotations

import json
from pathlib import Path
import pytest

from divatrading.core.database import Database
from divatrading.exchange.binance.models import MetadataParseError
from divatrading.exchange.binance.service import BinanceMetadataService


FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


class FakeRestClient:
    exchange_info_endpoint = "https://fixture.local/fapi/v1/exchangeInfo"

    def __init__(self, payload):
        self.payload = payload

    def get_exchange_info(self):
        return self.payload


def test_metadata_refresh_persists_snapshot_and_loads_it(tmp_path):
    db = Database(tmp_path / "state.db")
    assert db.initialize() == 6
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    service = BinanceMetadataService(FakeRestClient(payload), db)

    result = service.refresh()
    cached = service.load_latest_cached()

    assert result.all_symbol_count == 5
    assert result.tradable_symbol_count == 2
    assert result.database_snapshot_id == 1
    assert cached is not None
    assert cached.fetched_at_utc == result.snapshot.fetched_at_utc
    assert cached.get_symbol("BTCUSDT") is not None
    events = db.recent_events()
    assert events[0]["event_name"] == "exchange_info_refreshed"
    assert events[0]["details"]["tradable_symbol_count"] == 2


def test_failed_parse_does_not_overwrite_last_good_snapshot(tmp_path):
    db = Database(tmp_path / "state.db")
    db.initialize()
    valid = json.loads(FIXTURE.read_text(encoding="utf-8"))
    service = BinanceMetadataService(FakeRestClient(valid), db)
    service.refresh()

    service.client.payload = {"symbols": "bad"}
    with pytest.raises(MetadataParseError):
        service.refresh()

    cached = service.load_latest_cached()
    assert cached is not None
    assert len(cached.symbols) == 5
