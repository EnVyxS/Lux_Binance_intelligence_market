from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.market_data.aggregate_trades import (
    BINANCE_UM_AGG_TRADE_WS_ENDPOINT,
    DEFAULT_AGG_TRADE_MAX_AGE_MS,
    AggregateTradeQueueFullError,
    AggregateTradeReconnectExhausted,
    AggregateTradeStaleEventError,
    AggregateTradeWebSocketParseError,
    AggregateTradeWebSocketProtocolError,
    BinanceAggregateTradeWebSocketFeed,
    normalize_aggregate_trade_subscriptions,
    parse_aggregate_trade_stream_message,
)

FIXTURE_DIR = Path(__file__).parent / "fixtures"
AGG_TRADE_EVENT = (FIXTURE_DIR / "ws_agg_trade_btcusdt.json").read_text(encoding="utf-8")
EVENT_TIME_MS = 1760000000000


def _event(
    *,
    symbol: str = "BTCUSDT",
    aggregate_trade_id: int = 123456789,
    event_time_ms: int = EVENT_TIME_MS,
    buyer_is_maker: bool = True,
) -> str:
    payload = json.loads(AGG_TRADE_EVENT)
    payload["stream"] = f"{symbol.lower()}@aggTrade"
    payload["data"].update(
        s=symbol,
        a=aggregate_trade_id,
        E=event_time_ms,
        T=event_time_ms,
        m=buyer_is_maker,
    )
    return json.dumps(payload)


def test_normalize_aggregate_trade_subscriptions_deduplicates_exact_symbols() -> None:
    symbols, streams = normalize_aggregate_trade_subscriptions(
        [" btcusdt ", "BTCUSDT", "ETHUSDT"]
    )
    assert symbols == ("BTCUSDT", "ETHUSDT")
    assert streams == ("btcusdt@aggTrade", "ethusdt@aggTrade")


@pytest.mark.parametrize("symbols", [[], ["BTC/USDT"], [None], [""], ["BTC USDT"]])
def test_normalize_aggregate_trade_subscriptions_rejects_invalid_symbols(symbols) -> None:
    with pytest.raises(ValueError):
        normalize_aggregate_trade_subscriptions(symbols)


def test_parser_preserves_decimal_values_and_maps_buyer_maker_to_sell_aggressor() -> None:
    event = parse_aggregate_trade_stream_message(
        AGG_TRADE_EVENT,
        allowed_symbols=("BTCUSDT",),
        now_ms=EVENT_TIME_MS + 1000,
        max_event_age_ms=DEFAULT_AGG_TRADE_MAX_AGE_MS,
    )
    assert event is not None
    assert event.symbol == "BTCUSDT"
    assert event.aggregate_trade_id == 123456789
    assert event.price == Decimal("11794.15000000000001")
    assert event.quantity == Decimal("0.01250000")
    assert event.first_trade_id == 123456780
    assert event.last_trade_id == 123456783
    assert event.buyer_is_maker is True
    assert event.aggressor_side == "SELL"
    assert event.is_sell_initiated is True
    assert event.is_buy_initiated is False
    assert event.signed_quantity == Decimal("-0.01250000")
    assert event.quote_quantity == Decimal("147.4268750000000001250000")
    assert event.signed_quote_quantity == Decimal("-147.4268750000000001250000")
    assert event.underlying_trade_count == 4
    assert event.stream_name == "btcusdt@aggTrade"


def test_parser_maps_buyer_taker_to_buy_aggressor() -> None:
    event = parse_aggregate_trade_stream_message(_event(buyer_is_maker=False))
    assert event is not None
    assert event.buyer_is_maker is False
    assert event.aggressor_side == "BUY"
    assert event.signed_quantity == Decimal("0.01250000")
    assert event.signed_quote_quantity > 0


def test_parser_accepts_raw_json_and_utf8_bytes() -> None:
    raw = json.loads(AGG_TRADE_EVENT)["data"]
    event = parse_aggregate_trade_stream_message(json.dumps(raw).encode("utf-8"))
    assert event is not None
    assert event.stream_name == "btcusdt@aggTrade"


def test_parser_exposes_utc_times_and_normalizes_receive_time() -> None:
    received = datetime(2026, 2, 1, 12, tzinfo=UTC)
    event = parse_aggregate_trade_stream_message(
        AGG_TRADE_EVENT, received_at_utc=received
    )
    assert event is not None
    assert event.event_time_utc.tzinfo is UTC
    assert event.trade_time_utc.tzinfo is UTC
    assert event.received_at_utc == received


def test_parser_returns_none_for_subscription_acknowledgement() -> None:
    assert parse_aggregate_trade_stream_message('{"result":null,"id":1}') is None


def test_parser_rejects_binance_protocol_error() -> None:
    with pytest.raises(AggregateTradeWebSocketProtocolError):
        parse_aggregate_trade_stream_message('{"code":-1,"msg":"bad request"}')


@pytest.mark.parametrize(
    "mutate",
    [
        lambda p: p["data"].update(e="trade"),
        lambda p: p["data"].update(s="BAD SYMBOL"),
        lambda p: p["data"].update(a=True),
        lambda p: p["data"].update(E="NaN"),
        lambda p: p["data"].update(T=-1),
        lambda p: p["data"].update(p="NaN"),
        lambda p: p["data"].update(p="0"),
        lambda p: p["data"].update(q="Infinity"),
        lambda p: p["data"].update(q="0"),
        lambda p: p["data"].update(f=100, l=99),
        lambda p: p["data"].update(m="true"),
        lambda p: p.update(stream="ethusdt@aggTrade"),
        lambda p: p["data"].pop("a"),
    ],
)
def test_parser_rejects_invalid_or_mismatched_payloads(mutate) -> None:
    payload = json.loads(AGG_TRADE_EVENT)
    mutate(payload)
    with pytest.raises(AggregateTradeWebSocketParseError):
        parse_aggregate_trade_stream_message(json.dumps(payload))


def test_parser_rejects_unsubscribed_symbol() -> None:
    with pytest.raises(AggregateTradeWebSocketParseError, match="unsubscribed"):
        parse_aggregate_trade_stream_message(AGG_TRADE_EVENT, allowed_symbols=("ETHUSDT",))


def test_parser_rejects_stale_and_future_event_timestamps() -> None:
    with pytest.raises(AggregateTradeStaleEventError, match="stale"):
        parse_aggregate_trade_stream_message(
            AGG_TRADE_EVENT, now_ms=EVENT_TIME_MS + 20_000, max_event_age_ms=10_000
        )
    with pytest.raises(AggregateTradeStaleEventError, match="future"):
        parse_aggregate_trade_stream_message(
            AGG_TRADE_EVENT,
            now_ms=EVENT_TIME_MS - 10_000,
            max_event_age_ms=10_000,
            max_future_skew_ms=5_000,
        )
    payload = json.loads(AGG_TRADE_EVENT)
    payload["data"]["T"] = EVENT_TIME_MS - 20_000
    payload["data"]["E"] = EVENT_TIME_MS + 1000
    with pytest.raises(AggregateTradeStaleEventError, match="stale"):
        parse_aggregate_trade_stream_message(
            json.dumps(payload),
            now_ms=EVENT_TIME_MS + 1000,
            max_event_age_ms=10_000,
        )


def test_parser_requires_now_ms_for_freshness_check() -> None:
    with pytest.raises(ValueError, match="now_ms"):
        parse_aggregate_trade_stream_message(AGG_TRADE_EVENT, max_event_age_ms=1000)


def test_parser_requires_timezone_aware_receive_time() -> None:
    with pytest.raises(AggregateTradeWebSocketParseError, match="timezone-aware"):
        parse_aggregate_trade_stream_message(
            AGG_TRADE_EVENT, received_at_utc=datetime(2026, 1, 1)
        )


class _FakeWebSocket:
    def __init__(self, messages, stop_event, *, stop_on_send=False):
        self.messages = list(messages)
        self.stop_event = stop_event
        self.stop_on_send = stop_on_send
        self.sent: list[str] = []
        self.connected_seen_on_send: bool | None = None
        self.feed = None

    async def send(self, message: str) -> None:
        self.sent.append(message)
        if self.feed is not None:
            self.connected_seen_on_send = self.feed.is_connected
        if self.stop_on_send:
            self.stop_event.set()

    async def recv(self) -> str:
        if self.messages:
            message = self.messages.pop(0)
            if not self.messages:
                self.stop_event.set()
            return message
        await self.stop_event.wait()
        await asyncio.sleep(0)
        raise RuntimeError("recv called after stop")


class _FakeContext:
    def __init__(self, websocket):
        self.websocket = websocket
        self.closed = False

    async def __aenter__(self):
        return self.websocket

    async def __aexit__(self, exc_type, exc, tb):
        self.closed = True
        return False


class _FakeConnector:
    def __init__(self, contexts):
        self.contexts = list(contexts)
        self.calls: list[tuple[str, dict]] = []

    def __call__(self, uri: str, **kwargs):
        self.calls.append((uri, kwargs))
        if not self.contexts:
            raise RuntimeError("No fake connection context remains")
        item = self.contexts.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def test_feed_subscribes_only_selected_symbols_and_emits_events() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket(
            ['{"result":null,"id":1}', AGG_TRADE_EVENT], stop
        )
        context = _FakeContext(websocket)
        connector = _FakeConnector([context])
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"], connector=connector,
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        websocket.feed = feed
        await feed.run(stop)
        request = json.loads(websocket.sent[0])
        assert request == {
            "method": "SUBSCRIBE", "params": ["btcusdt@aggTrade"], "id": 1
        }
        assert connector.calls[0][0] == BINANCE_UM_AGG_TRADE_WS_ENDPOINT
        assert connector.calls[0][1]["max_queue"] == 16
        assert connector.calls[0][1]["max_size"] == 64 * 1024
        assert websocket.connected_seen_on_send is True
        assert context.closed is True
        assert feed.is_connected is False
        assert feed.stats.acknowledgements_received == 1
        assert feed.stats.events_emitted == 1
        event = await feed.get_event()
        assert event.aggressor_side == "SELL"

    asyncio.run(scenario())


def test_feed_skips_malformed_and_stale_messages() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket(
            ["not-json", _event(event_time_ms=EVENT_TIME_MS - 20_000), AGG_TRADE_EVENT],
            stop,
        )
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([_FakeContext(websocket)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        await feed.run(stop)
        assert feed.stats.malformed_messages == 1
        assert feed.stats.stale_messages == 1
        assert feed.stats.events_emitted == 1

    asyncio.run(scenario())


def test_feed_skips_duplicate_and_out_of_order_ids_and_marks_sequence_gaps() -> None:
    async def scenario():
        stop = asyncio.Event()
        messages = [
            _event(aggregate_trade_id=100),
            _event(aggregate_trade_id=100),
            _event(aggregate_trade_id=99),
            _event(aggregate_trade_id=103),
        ]
        ws = _FakeWebSocket(messages, stop)
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([_FakeContext(ws)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        await feed.run(stop)
        event = await feed.get_event()
        assert event.aggregate_trade_id == 100
        next_event = await feed.get_event()
        assert next_event.aggregate_trade_id == 103
        assert next_event.missed_aggregate_trades_before == 2
        assert feed.stats.duplicate_or_out_of_order_messages == 2
        assert feed.stats.aggregate_id_gaps == 2
        assert feed.stats.events_emitted == 2

    asyncio.run(scenario())


def test_feed_queue_overflow_raises_instead_of_silently_dropping() -> None:
    async def scenario():
        stop = asyncio.Event()
        ws = _FakeWebSocket([_event(aggregate_trade_id=1), _event(aggregate_trade_id=2)], stop)
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"], queue_capacity=1,
            connector=_FakeConnector([_FakeContext(ws)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        with pytest.raises(AggregateTradeQueueFullError):
            await feed.run(stop)
        assert feed.stats.queue_overflows == 1
        assert feed.stats.events_emitted == 1

    asyncio.run(scenario())


def test_feed_reconnects_and_resubscribes_exact_selected_symbols() -> None:
    async def scenario():
        stop = asyncio.Event()
        first = _FakeWebSocket([_event(aggregate_trade_id=1)], asyncio.Event())
        second = _FakeWebSocket(['{"result":null,"id":2}', _event(aggregate_trade_id=2)], stop)
        connector = _FakeConnector([_FakeContext(first), _FakeContext(second)])
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"], connector=connector,
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
            reconnect_base_delay_seconds=0, reconnect_max_delay_seconds=0,
            stable_connection_reset_seconds=1000,
        )
        await feed.run(stop)
        assert feed.stats.connection_count == 2
        assert feed.stats.reconnect_attempts == 1
        assert feed.stats.subscription_messages_sent == 2
        assert len(connector.calls) == 2
        assert connector.calls[0][0] == connector.calls[1][0]
        expected_streams = ["btcusdt@aggTrade", "ethusdt@aggTrade"]
        assert json.loads(first.sent[0])["params"] == expected_streams
        assert json.loads(second.sent[0])["params"] == expected_streams
        assert (await feed.get_event()).aggregate_trade_id == 1
        assert (await feed.get_event()).aggregate_trade_id == 2

    asyncio.run(scenario())


def test_feed_preserves_last_id_across_reconnect_to_filter_replayed_event() -> None:
    async def scenario():
        stop = asyncio.Event()
        first = _FakeWebSocket([_event(aggregate_trade_id=10)], asyncio.Event())
        second = _FakeWebSocket(
            [_event(aggregate_trade_id=10), _event(aggregate_trade_id=11)], stop
        )
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"],
            connector=_FakeConnector([_FakeContext(first), _FakeContext(second)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
            reconnect_base_delay_seconds=0, reconnect_max_delay_seconds=0,
            stable_connection_reset_seconds=1000,
        )
        await feed.run(stop)
        assert feed.stats.duplicate_or_out_of_order_messages == 1
        assert feed.stats.events_emitted == 2
        assert (await feed.get_event()).aggregate_trade_id == 10
        assert (await feed.get_event()).aggregate_trade_id == 11

    asyncio.run(scenario())


def test_feed_validation_enforces_resource_and_retry_caps() -> None:
    with pytest.raises(ValueError, match="exceeds configured cap"):
        BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"], max_subscriptions=1
        )
    with pytest.raises(ValueError):
        BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"], max_subscriptions=49)
    with pytest.raises(ValueError):
        BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"], queue_capacity=32769)
    with pytest.raises(ValueError):
        BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"], max_reconnect_attempts=21)
    with pytest.raises(ValueError):
        BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"], max_event_age_ms=-1)


def test_feed_reconnect_exhaustion_is_bounded() -> None:
    async def scenario():
        connector = _FakeConnector([RuntimeError("connect-1"), RuntimeError("connect-2")])
        feed = BinanceAggregateTradeWebSocketFeed(
            symbols=["BTCUSDT"], connector=connector,
            max_reconnect_attempts=1,
            reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        with pytest.raises(AggregateTradeReconnectExhausted):
            await feed.run(asyncio.Event())
        assert feed.stats.reconnect_attempts == 1

    asyncio.run(scenario())
