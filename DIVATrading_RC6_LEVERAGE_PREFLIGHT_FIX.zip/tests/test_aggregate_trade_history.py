from datetime import UTC, datetime
from decimal import Decimal

import pytest

from divatrading.market_data.aggregate_trade_history import (
    AggregateTradeHistoryContinuityError,
    AggregateTradeHistoryParseError,
    BinanceAggregateTradeHistoryService,
    parse_aggregate_trade_rest_row,
)

NOW = datetime(2026, 11, 10, 1, 0, tzinfo=UTC)


def rest_row(agg_id: int, *, time_ms: int = 1_800_000_000_000) -> dict:
    return {
        "a": agg_id,
        "p": "100.000000000000000001",
        "q": "0.125000000000000001",
        "nq": "0.120000000000000001",
        "f": agg_id * 2,
        "l": agg_id * 2 + 1,
        "T": time_ms,
        "m": False,
    }


class FakeClient:
    aggregate_trades_endpoint = "https://fapi.binance.com/fapi/v1/aggTrades"

    def __init__(self, pages):
        self.pages = pages
        self.calls = []

    def get_aggregate_trades(self, *, symbol, from_id=None, limit=1000):
        self.calls.append((symbol, from_id, limit))
        key = from_id
        return self.pages.get(key, [])


def test_parse_rest_row_preserves_decimal_and_aggressor_direction():
    record = parse_aggregate_trade_rest_row(rest_row(5), symbol="btcusdt", received_at_utc=NOW)
    assert record.symbol == "BTCUSDT"
    assert record.price == Decimal("100.000000000000000001")
    assert record.quantity == Decimal("0.125000000000000001")
    assert record.normal_quantity == Decimal("0.120000000000000001")
    assert record.aggressor_side == "BUY"
    assert record.signed_quantity == record.quantity
    assert record.signed_quote_quantity == record.price * record.quantity
    assert record.event_time_ms is None  # REST endpoint does not return event time E.


def test_parse_rest_row_marks_sell_aggression_and_allows_zero_normal_quantity():
    row = rest_row(5)
    row["m"] = True
    row["nq"] = "0"
    record = parse_aggregate_trade_rest_row(row, symbol="BTCUSDT", received_at_utc=NOW)
    assert record.aggressor_side == "SELL"
    assert record.signed_quantity == -record.quantity
    assert record.normal_quantity == Decimal("0")


@pytest.mark.parametrize(
    "mutation",
    [
        lambda row: row.pop("a"),
        lambda row: row.update({"p": "NaN"}),
        lambda row: row.update({"q": "0"}),
        lambda row: row.update({"nq": "2"}),
        lambda row: row.update({"m": 1}),
        lambda row: row.update({"l": row["f"] - 1}),
        lambda row: row.update({"T": 0}),
    ],
)
def test_parse_rest_row_rejects_invalid_payload(mutation):
    row = rest_row(5)
    mutation(row)
    with pytest.raises(AggregateTradeHistoryParseError):
        parse_aggregate_trade_rest_row(row, symbol="BTCUSDT", received_at_utc=NOW)


def test_fetch_latest_validates_and_returns_latest_contiguous_page():
    client = FakeClient({None: [rest_row(10), rest_row(11), rest_row(12)]})
    service = BinanceAggregateTradeHistoryService(client, page_limit=3, now=lambda: NOW)
    batch = service.fetch_latest(symbol="btcusdt")
    assert batch.complete is True
    assert [row.aggregate_trade_id for row in batch.records] == [10, 11, 12]
    assert client.calls == [("BTCUSDT", None, 3)]


def test_fetch_latest_rejects_id_gaps():
    client = FakeClient({None: [rest_row(10), rest_row(12)]})
    service = BinanceAggregateTradeHistoryService(client, page_limit=3, now=lambda: NOW)
    with pytest.raises(AggregateTradeHistoryContinuityError):
        service.fetch_latest(symbol="BTCUSDT")


def test_fetch_range_paginates_with_inclusive_from_id_and_next_id_cursor():
    client = FakeClient({
        10: [rest_row(10), rest_row(11)],
        12: [rest_row(12), rest_row(13)],
    })
    service = BinanceAggregateTradeHistoryService(
        client, page_limit=2, max_pages_per_pass=2, page_pause_seconds=0, now=lambda: NOW
    )
    batch = service.fetch_range(symbol="BTCUSDT", from_id=10, through_id=13)
    assert batch.complete is True
    assert batch.next_from_id is None
    assert [r.aggregate_trade_id for r in batch.records] == [10, 11, 12, 13]
    assert client.calls == [("BTCUSDT", 10, 2), ("BTCUSDT", 12, 2)]


def test_fetch_range_returns_resume_cursor_when_page_cap_reached():
    client = FakeClient({10: [rest_row(10), rest_row(11)]})
    service = BinanceAggregateTradeHistoryService(
        client, page_limit=2, max_pages_per_pass=1, page_pause_seconds=0, now=lambda: NOW
    )
    batch = service.fetch_range(symbol="BTCUSDT", from_id=10, through_id=15)
    assert batch.complete is False
    assert batch.next_from_id == 12
    assert batch.missing_id is None


def test_fetch_range_stops_at_missing_id_without_fabricating_rows():
    client = FakeClient({10: [rest_row(10), rest_row(12)]})
    service = BinanceAggregateTradeHistoryService(
        client, page_limit=5, max_pages_per_pass=1, page_pause_seconds=0, now=lambda: NOW
    )
    batch = service.fetch_range(symbol="BTCUSDT", from_id=10, through_id=12)
    assert batch.complete is False
    assert [r.aggregate_trade_id for r in batch.records] == [10]
    assert batch.missing_id == 11
    assert batch.next_from_id == 11


def test_fetch_range_empty_response_marks_first_missing_id():
    client = FakeClient({10: []})
    service = BinanceAggregateTradeHistoryService(client, page_pause_seconds=0, now=lambda: NOW)
    batch = service.fetch_range(symbol="BTCUSDT", from_id=10, through_id=11)
    assert batch.complete is False
    assert batch.records == ()
    assert batch.missing_id == 10


def test_fetch_range_rejects_out_of_order_or_duplicated_page():
    client = FakeClient({10: [rest_row(10), rest_row(10)]})
    service = BinanceAggregateTradeHistoryService(
        client, page_pause_seconds=0, now=lambda: NOW
    )
    with pytest.raises(AggregateTradeHistoryContinuityError):
        service.fetch_range(symbol="BTCUSDT", from_id=10, through_id=11)


def test_fetch_range_validates_range_and_page_cap():
    client = FakeClient({})
    service = BinanceAggregateTradeHistoryService(client)
    with pytest.raises(ValueError):
        service.fetch_range(symbol="BTCUSDT", from_id=2, through_id=1)
    with pytest.raises(ValueError):
        service.fetch_range(symbol="BTCUSDT", from_id=1, through_id=2, max_pages=0)
