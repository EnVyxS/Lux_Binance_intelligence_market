from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.market_data.mark_price import (
    DEFAULT_MARK_PRICE_MAX_AGE_MS,
    BinanceMarkPriceWebSocketFeed,
    MarkPriceQueueFullError,
    MarkPriceReconnectExhausted,
    MarkPriceStaleEventError,
    MarkPriceWebSocketParseError,
    MarkPriceWebSocketProtocolError,
    normalize_mark_price_subscriptions,
    parse_mark_price_stream_message,
)
from divatrading.market_data.websocket import BINANCE_UM_MARKET_WS_ENDPOINT


FIXTURE_DIR = Path(__file__).parent / "fixtures"
MARK_EVENT = (FIXTURE_DIR / "ws_mark_price_btcusdt.json").read_text(encoding="utf-8")
EVENT_TIME_MS = 1760000000000


def _event(*, symbol: str = "BTCUSDT", event_time_ms: int = EVENT_TIME_MS) -> str:
    payload = json.loads(MARK_EVENT)
    payload["stream"] = f"{symbol.lower()}@markPrice@1s"
    payload["data"]["s"] = symbol
    payload["data"]["E"] = event_time_ms
    payload["data"]["T"] = event_time_ms + 3_600_000
    return json.dumps(payload)


def test_normalize_mark_price_subscriptions_deduplicates_exact_symbols() -> None:
    symbols, streams = normalize_mark_price_subscriptions(
        [" btcusdt ", "BTCUSDT", "ETHUSDT"], update_speed="3s"
    )
    assert symbols == ("BTCUSDT", "ETHUSDT")
    assert streams == ("btcusdt@markPrice@3s", "ethusdt@markPrice@3s")


@pytest.mark.parametrize(
    ("symbols", "speed"),
    [([], "1s"), (["BTC/USDT"], "1s"), (["BTCUSDT"], "5s"), ([None], "1s")],
)
def test_normalize_mark_price_subscriptions_rejects_invalid_values(symbols, speed) -> None:
    with pytest.raises(ValueError):
        normalize_mark_price_subscriptions(symbols, update_speed=speed)


def test_parser_reads_raw_or_combined_payload_and_preserves_decimal_precision() -> None:
    payload = json.loads(MARK_EVENT)
    payload.pop("stream")
    event = parse_mark_price_stream_message(
        json.dumps(payload), allowed_symbols=("BTCUSDT",), now_ms=EVENT_TIME_MS + 1000,
        max_event_age_ms=DEFAULT_MARK_PRICE_MAX_AGE_MS,
    )
    assert event is not None
    assert event.symbol == "BTCUSDT"
    assert event.mark_price == Decimal("11794.15000000000001")
    assert event.index_price == Decimal("11784.62659091")
    assert event.funding_rate == Decimal("0.00038167")
    assert event.next_funding_time_ms == EVENT_TIME_MS + 3_600_000
    assert event.estimated_settle_price == Decimal("11784.25641265")
    assert event.mark_price_moving_average == Decimal("11794.15000000")
    assert event.symbol_type == 1
    assert event.mark_index_basis == Decimal("9.52340909000001")
    assert event.stream_name == "btcusdt@markPrice@1s"


def test_parser_exposes_utc_event_and_funding_times_and_normalizes_receive_time() -> None:
    receive = datetime(2026, 2, 1, 12, tzinfo=UTC)
    event = parse_mark_price_stream_message(MARK_EVENT, received_at_utc=receive)
    assert event is not None
    assert event.event_time_utc.tzinfo is UTC
    assert event.next_funding_time_utc.tzinfo is UTC
    assert event.received_at_utc == receive


def test_parser_accepts_negative_funding_rate_and_optional_fields() -> None:
    payload = json.loads(MARK_EVENT)
    payload["data"]["r"] = "-0.00012500"
    payload["data"].pop("P")
    payload["data"].pop("ap")
    payload["data"].pop("st")
    event = parse_mark_price_stream_message(json.dumps(payload))
    assert event is not None
    assert event.funding_rate == Decimal("-0.00012500")
    assert event.estimated_settle_price is None
    assert event.mark_price_moving_average is None
    assert event.symbol_type is None


def test_parser_returns_none_for_subscription_acknowledgement() -> None:
    assert parse_mark_price_stream_message('{"result":null,"id":1}') is None


def test_parser_rejects_binance_protocol_error() -> None:
    with pytest.raises(MarkPriceWebSocketProtocolError):
        parse_mark_price_stream_message('{"code":-1,"msg":"bad request"}')


@pytest.mark.parametrize(
    "mutate",
    [
        lambda p: p["data"].update(e="ticker"),
        lambda p: p["data"].update(s="ETHUSDT"),
        lambda p: p["data"].update(p="NaN"),
        lambda p: p["data"].update(p="0"),
        lambda p: p["data"].update(i="Infinity"),
        lambda p: p["data"].update(r="not-a-rate"),
        lambda p: p["data"].update(E=True),
        lambda p: p["data"].update(T=1),
        lambda p: p["data"].update(st=2),
        lambda p: p.update(stream="btcusdt@markPrice@3s"),
        lambda p: p["data"].pop("i"),
    ],
)
def test_parser_rejects_invalid_or_mismatched_payloads(mutate) -> None:
    payload = json.loads(MARK_EVENT)
    mutate(payload)
    with pytest.raises(MarkPriceWebSocketParseError):
        parse_mark_price_stream_message(json.dumps(payload), allowed_symbols=("BTCUSDT",))


def test_parser_rejects_unsubscribed_symbol() -> None:
    with pytest.raises(MarkPriceWebSocketParseError, match="unsubscribed"):
        parse_mark_price_stream_message(MARK_EVENT, allowed_symbols=("ETHUSDT",))


def test_parser_rejects_stale_and_future_timestamp() -> None:
    with pytest.raises(MarkPriceStaleEventError, match="stale"):
        parse_mark_price_stream_message(
            MARK_EVENT, now_ms=EVENT_TIME_MS + 20_000, max_event_age_ms=10_000
        )
    with pytest.raises(MarkPriceStaleEventError, match="future"):
        parse_mark_price_stream_message(
            MARK_EVENT, now_ms=EVENT_TIME_MS - 10_000, max_event_age_ms=10_000,
            max_future_skew_ms=5_000,
        )


def test_parser_requires_now_ms_for_freshness_check() -> None:
    with pytest.raises(ValueError, match="now_ms"):
        parse_mark_price_stream_message(MARK_EVENT, max_event_age_ms=1000)


def test_parser_requires_timezone_aware_receive_time() -> None:
    with pytest.raises(MarkPriceWebSocketParseError, match="timezone-aware"):
        parse_mark_price_stream_message(
            MARK_EVENT, received_at_utc=datetime(2026, 1, 1, 0, 0)
        )


def test_feed_enforces_subscription_queue_and_reconnect_caps() -> None:
    with pytest.raises(ValueError, match="exceeds configured cap"):
        BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"], max_subscriptions=1
        )
    with pytest.raises(ValueError):
        BinanceMarkPriceWebSocketFeed(symbols=["BTCUSDT"], max_subscriptions=129)
    with pytest.raises(ValueError):
        BinanceMarkPriceWebSocketFeed(symbols=["BTCUSDT"], queue_capacity=8193)
    with pytest.raises(ValueError):
        BinanceMarkPriceWebSocketFeed(symbols=["BTCUSDT"], max_reconnect_attempts=21)
    with pytest.raises(ValueError):
        BinanceMarkPriceWebSocketFeed(symbols=["BTCUSDT"], max_event_age_ms=-1)


class _FakeWebSocket:
    def __init__(self, messages: list[str], stop_event: asyncio.Event, *, stop_on_send=False):
        self.messages = list(messages)
        self.stop_event = stop_event
        self.stop_on_send = stop_on_send
        self.sent: list[str] = []
        self.connected_seen_on_send: bool | None = None
        self.feed = None

    async def send(self, message: str) -> None:
        self.sent.append(message)
        if self.feed is not None:
            self.connected_seen_on_send = self.feed.is_connected
        if self.stop_on_send:
            self.stop_event.set()

    async def recv(self) -> str:
        if self.messages:
            message = self.messages.pop(0)
            if not self.messages:
                self.stop_event.set()
            return message
        await self.stop_event.wait()
        await asyncio.sleep(0)
        raise RuntimeError("recv called after stop")


class _FakeContext:
    def __init__(self, websocket):
        self.websocket = websocket
        self.closed = False

    async def __aenter__(self):
        return self.websocket

    async def __aexit__(self, exc_type, exc, tb):
        self.closed = True
        return False


class _FakeConnector:
    def __init__(self, contexts):
        self.contexts = list(contexts)
        self.calls: list[tuple[str, dict]] = []

    def __call__(self, uri: str, **kwargs):
        self.calls.append((uri, kwargs))
        if not self.contexts:
            raise RuntimeError("No fake connection context remains")
        return self.contexts.pop(0)


def test_feed_subscribes_only_selected_symbols_and_emits_mark_price_events() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket(
            ['{"result":null,"id":1}', MARK_EVENT], stop
        )
        context = _FakeContext(websocket)
        connector = _FakeConnector([context])
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], connector=connector,
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        websocket.feed = feed
        await feed.run(stop)
        request = json.loads(websocket.sent[0])
        assert request == {
            "method": "SUBSCRIBE", "params": ["btcusdt@markPrice@1s"], "id": 1
        }
        assert connector.calls[0][0] == BINANCE_UM_MARKET_WS_ENDPOINT
        assert connector.calls[0][1]["max_queue"] == 16
        assert connector.calls[0][1]["max_size"] == 64 * 1024
        assert websocket.connected_seen_on_send is True
        assert context.closed is True
        assert feed.is_connected is False
        assert feed.stats.acknowledgements_received == 1
        assert feed.stats.events_emitted == 1
        assert (await feed.get_event()).mark_price == Decimal("11794.15000000000001")

    asyncio.run(scenario())


def test_feed_skips_malformed_and_stale_messages() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket(
            ["not-json", _event(event_time_ms=EVENT_TIME_MS - 20_000), MARK_EVENT], stop
        )
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([_FakeContext(websocket)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        await feed.run(stop)
        assert feed.stats.malformed_messages == 1
        assert feed.stats.stale_messages == 1
        assert feed.stats.events_emitted == 1

    asyncio.run(scenario())


def test_feed_skips_duplicate_or_out_of_order_event_times() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket(
            [MARK_EVENT, MARK_EVENT, _event(event_time_ms=EVENT_TIME_MS - 100)], stop
        )
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([_FakeContext(websocket)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 1000,
        )
        await feed.run(stop)
        assert feed.stats.events_emitted == 1
        assert feed.stats.stale_messages == 2
        assert feed.events.qsize() == 1

    asyncio.run(scenario())


def test_feed_rejects_queue_overflow_without_silent_drop() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket([MARK_EVENT, _event(event_time_ms=EVENT_TIME_MS + 1000)], stop)
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], queue_capacity=1,
            connector=_FakeConnector([_FakeContext(websocket)]),
            wall_clock_ms=lambda: EVENT_TIME_MS + 2000,
        )
        with pytest.raises(MarkPriceQueueFullError):
            await feed.run(stop)
        assert feed.stats.queue_overflows == 1
        assert feed.events.qsize() == 1

    asyncio.run(scenario())


def test_feed_resubscribes_after_disconnect() -> None:
    class _DropAfterAck(_FakeWebSocket):
        async def recv(self):
            if self.messages:
                return self.messages.pop(0)
            raise OSError("connection dropped")

    async def scenario():
        stop = asyncio.Event()
        first = _DropAfterAck(['{"result":null,"id":1}'], stop)
        second = _FakeWebSocket([], stop, stop_on_send=True)
        connector = _FakeConnector([_FakeContext(first), _FakeContext(second)])
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"], connector=connector,
            max_reconnect_attempts=1, reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        await feed.run(stop)
        assert json.loads(first.sent[0])["params"] == json.loads(second.sent[0])["params"]
        assert json.loads(first.sent[0])["params"] == [
            "btcusdt@markPrice@1s", "ethusdt@markPrice@1s"
        ]
        assert feed.stats.connection_count == 2
        assert feed.stats.reconnect_attempts == 1
        assert feed.stats.subscription_messages_sent == 2

    asyncio.run(scenario())


def test_feed_raises_when_reconnect_limit_is_exhausted() -> None:
    class _FailedContext:
        async def __aenter__(self):
            raise OSError("network unavailable")

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def scenario():
        stop = asyncio.Event()
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([_FailedContext(), _FailedContext()]),
            max_reconnect_attempts=1, reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        with pytest.raises(MarkPriceReconnectExhausted):
            await feed.run(stop)
        assert feed.stats.reconnect_attempts == 1

    asyncio.run(scenario())


def test_feed_stops_cleanly_and_resets_connection_state() -> None:
    async def scenario():
        stop = asyncio.Event()
        websocket = _FakeWebSocket([], stop, stop_on_send=True)
        context = _FakeContext(websocket)
        feed = BinanceMarkPriceWebSocketFeed(
            symbols=["BTCUSDT"], connector=_FakeConnector([context])
        )
        await feed.run(stop)
        assert context.closed is True
        assert feed.is_connected is False

    asyncio.run(scenario())


def test_feed_supports_three_second_update_streams() -> None:
    feed = BinanceMarkPriceWebSocketFeed(
        symbols=["BTCUSDT", "ETHUSDT"], update_speed="3s"
    )
    assert feed.update_speed == "3s"
    assert feed.stream_names == (
        "btcusdt@markPrice@3s",
        "ethusdt@markPrice@3s",
    )
