from __future__ import annotations

from dataclasses import FrozenInstanceError
import json

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcObCandidateEvaluation,
    PineSmcObEligibilityTrace,
    PineSmcOrderBlockTrace,
    PineSmcReplayError,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
    PineSmcStructureEvents,
    PineSmcTriggerSweepTrace,
)

BASE_TIME_MS = 1_700_000_000_000


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 10,
        "internal_len": 1,
        "use_volatility_regime": False,
        "use_trend_filter": False,
        "use_pd_filter": False,
        "fresh_only": False,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def _kline(
    index: int,
    *,
    open_price: str = "10",
    high: str = "12",
    low: str = "8",
    close: str = "10",
) -> Kline:
    interval = "1m"
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            "10",
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def _ob(
    index: int,
    *,
    bias: int = 1,
    top: float = 105.0,
    bottom: float = 95.0,
    break_index: int = 1,
    used: bool = False,
    has_fvg: bool = True,
) -> PineSmcOrderBlockTrace:
    interval_ms = INTERVAL_MILLISECONDS["1m"]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    return PineSmcOrderBlockTrace(
        top=top,
        bottom=bottom,
        bar_local_index=max(0, index - 1),
        break_local_index=break_index,
        source_time_ms=base_time + max(0, index - 1) * interval_ms,
        break_time_ms=base_time + break_index * interval_ms,
        bias=bias,
        has_fvg=has_fvg,
        used=used,
    )


def _candidate(
    index: int,
    *,
    bias: int = 1,
    top: float = 105.0,
    bottom: float = 95.0,
    break_index: int = 1,
) -> PineSmcObCandidateEvaluation:
    return PineSmcObCandidateEvaluation(
        active_array_index=index,
        order_block=_ob(
            index,
            bias=bias,
            top=top,
            bottom=bottom,
            break_index=break_index,
        ),
        eligible=True,
    )


def _events(
    *,
    bull_choch: bool = False,
    bear_choch: bool = False,
    bull_bos: bool = False,
    bear_bos: bool = False,
    extreme: float = 0.0,
    extreme_index: int = -1,
) -> PineSmcStructureEvents:
    return PineSmcStructureEvents(
        bullish_bar=True,
        bearish_bar=True,
        bull_choch=bull_choch,
        bear_choch=bear_choch,
        bull_bos=bull_bos,
        bear_bos=bear_bos,
        extreme=extreme,
        extreme_local_index=extreme_index,
        extreme_source_time_ms=None,
    )


def _evaluate(
    *,
    config: PineSmcStructureConfig,
    history: list[Kline],
    candidates: tuple[PineSmcObCandidateEvaluation, ...],
    events: PineSmcStructureEvents | None = None,
) -> PineSmcTriggerSweepTrace:
    local_index = len(history) - 1
    eligibility = PineSmcObEligibilityTrace(
        max_age=300,
        scanned_newest_to_oldest=candidates,
        eligible_candidates=candidates,
    )
    return PineSmcStructureEngine(config)._evaluate_trigger_sweep(
        history=history,
        candle=history[-1],
        structure_events=_events() if events is None else events,
        eligibility=eligibility,
        local_index=local_index,
    )


def _neutral_history(count: int) -> list[Kline]:
    return [_kline(i) for i in range(count)]


def test_stage6_config_defaults_validation_and_metadata_contract() -> None:
    config = _config()
    assert config.trigger_mode == "Either"
    assert config.struct_allow_bos is True
    assert config.min_wick_pct == 20.0
    assert config.require_sweep is False
    assert config.sweep_lookback == 20
    assert config.sweep_window == 5

    for invalid in ("rejection", "Both", "", None):
        with pytest.raises(PineSmcReplayError, match="trigger_mode"):
            _config(trigger_mode=invalid)
    with pytest.raises(PineSmcReplayError, match="struct_allow_bos"):
        _config(struct_allow_bos=1)
    for invalid in (-0.1, 100.1, float("nan"), float("inf"), True):
        with pytest.raises(PineSmcReplayError, match="min_wick_pct"):
            _config(min_wick_pct=invalid)
    with pytest.raises(PineSmcReplayError, match="require_sweep"):
        _config(require_sweep=1)
    for name, invalid_values in (
        ("sweep_lookback", (1, 101, True, 2.5, "20")),
        ("sweep_window", (0, 21, True, 1.5, "5")),
    ):
        for invalid in invalid_values:
            with pytest.raises(PineSmcReplayError, match=name):
                _config(**{name: invalid})


def test_bullish_rejection_uses_exact_touch_midpoint_and_lower_wick_formula() -> None:
    history = _neutral_history(3)
    history[-1] = _kline(2, open_price="100", high="110", low="90", close="105")
    candidate = _candidate(7, top=105.0, bottom=95.0, break_index=1)

    passes_at_exact_50 = _evaluate(
        config=_config(trigger_mode="Rejection", min_wick_pct=50.0),
        history=history,
        candidates=(candidate,),
    )
    assert passes_at_exact_50.scanned_candidates[0].rejection_trigger is True
    assert passes_at_exact_50.scanned_candidates[0].trigger_code == 1
    assert passes_at_exact_50.chosen_active_array_index == 7

    fails_above_50 = _evaluate(
        config=_config(trigger_mode="Rejection", min_wick_pct=50.0001),
        history=history,
        candidates=(candidate,),
    )
    assert fails_above_50.scanned_candidates[0].rejection_trigger is False
    assert fails_above_50.chosen_active_array_index is None


def test_bearish_rejection_uses_mirrored_upper_wick_formula() -> None:
    history = _neutral_history(3)
    history[-1] = _kline(2, open_price="108", high="110", low="88", close="98")
    candidate = _candidate(4, bias=-1, top=105.0, bottom=95.0, break_index=1)

    passes = _evaluate(
        config=_config(trigger_mode="Rejection", min_wick_pct=9.09),
        history=history,
        candidates=(candidate,),
    )
    assert passes.scanned_candidates[0].rejection_trigger is True
    assert passes.chosen_trigger_code == 1

    fails = _evaluate(
        config=_config(trigger_mode="Rejection", min_wick_pct=9.1),
        history=history,
        candidates=(candidate,),
    )
    assert fails.scanned_candidates[0].rejection_trigger is False


def test_rejection_requires_positive_range_and_correct_ob_touch_candle_direction_midpoint() -> None:
    candidate = _candidate(0, top=105.0, bottom=95.0)
    non_rejection_candles = (
        _kline(2, open_price="100", high="100", low="100", close="100"),
        _kline(2, open_price="110", high="112", low="106", close="111"),  # no low touch
        _kline(2, open_price="100", high="110", low="90", close="99"),  # red
        _kline(2, open_price="100", high="110", low="90", close="100"),  # not above midpoint
    )
    for candle in non_rejection_candles:
        history = _neutral_history(3)
        history[-1] = candle
        result = _evaluate(
            config=_config(trigger_mode="Rejection"),
            history=history,
            candidates=(candidate,),
        )
        assert result.scanned_candidates[0].rejection_trigger is False


def test_trigger_mode_disables_the_unselected_trigger_family() -> None:
    history = _neutral_history(3)
    history[-1] = _kline(2, open_price="100", high="110", low="90", close="105")
    candidate = _candidate(2, break_index=1)
    structure_events = _events(bull_choch=True, extreme=90.0, extreme_index=2)

    rejection_only = _evaluate(
        config=_config(trigger_mode="Rejection"),
        history=history,
        candidates=(candidate,),
        events=structure_events,
    )
    assert rejection_only.scanned_candidates[0].rejection_trigger is True
    assert rejection_only.scanned_candidates[0].structure_trigger is False
    assert rejection_only.chosen_trigger_code == 1

    structure_only = _evaluate(
        config=_config(trigger_mode="Structure"),
        history=history,
        candidates=(candidate,),
        events=structure_events,
    )
    assert structure_only.scanned_candidates[0].rejection_trigger is False
    assert structure_only.scanned_candidates[0].structure_trigger is True
    assert structure_only.chosen_trigger_code == 2


def test_structure_trigger_uses_post_break_event_extreme_and_inclusive_ob_boundary() -> None:
    history = _neutral_history(8)
    bullish = _candidate(5, bias=1, top=105.0, bottom=95.0, break_index=4)
    bearish = _candidate(6, bias=-1, top=105.0, bottom=95.0, break_index=4)

    bull = _evaluate(
        config=_config(trigger_mode="Structure"),
        history=history,
        candidates=(bullish,),
        events=_events(bull_choch=True, extreme=105.0, extreme_index=5),
    )
    assert bull.scanned_candidates[0].structure_trigger is True  # <= OB top
    assert bull.chosen_trigger_code == 2

    bear = _evaluate(
        config=_config(trigger_mode="Structure"),
        history=history,
        candidates=(bearish,),
        events=_events(bear_choch=True, extreme=95.0, extreme_index=5),
    )
    assert bear.scanned_candidates[0].structure_trigger is True  # >= OB bottom

    # An event on the OB break bar is not a valid post-break structure trigger.
    same_bar = _evaluate(
        config=_config(trigger_mode="Structure"),
        history=history,
        candidates=(bullish,),
        events=_events(bull_choch=True, extreme=90.0, extreme_index=4),
    )
    assert same_bar.scanned_candidates[0].structure_trigger is False


def test_bos_requires_struct_allow_bos_while_choch_always_qualifies() -> None:
    history = _neutral_history(7)
    bullish = _candidate(3, break_index=2)
    bos_events = _events(bull_bos=True, extreme=90.0, extreme_index=3)

    allowed = _evaluate(
        config=_config(trigger_mode="Structure", struct_allow_bos=True),
        history=history,
        candidates=(bullish,),
        events=bos_events,
    )
    assert allowed.scanned_candidates[0].structure_trigger is True

    blocked = _evaluate(
        config=_config(trigger_mode="Structure", struct_allow_bos=False),
        history=history,
        candidates=(bullish,),
        events=bos_events,
    )
    assert blocked.scanned_candidates[0].structure_trigger is False

    choch = _evaluate(
        config=_config(trigger_mode="Structure", struct_allow_bos=False),
        history=history,
        candidates=(bullish,),
        events=_events(bull_choch=True, extreme=90.0, extreme_index=3),
    )
    assert choch.scanned_candidates[0].structure_trigger is True


def test_rejection_has_priority_when_rejection_and_structure_are_both_true() -> None:
    history = _neutral_history(3)
    history[-1] = _kline(2, open_price="100", high="110", low="90", close="105")
    candidate = _candidate(8, break_index=1)
    both_events = _events(bull_choch=True, extreme=90.0, extreme_index=2)

    result = _evaluate(
        config=_config(trigger_mode="Either"),
        history=history,
        candidates=(candidate,),
        events=both_events,
    )
    row = result.scanned_candidates[0]
    assert row.rejection_trigger is True
    assert row.structure_trigger is True
    assert row.trigger_code == 1
    assert result.chosen_trigger_code == 1


def test_scan_preserves_stage5_candidate_order_and_stops_at_first_accepted() -> None:
    history = _neutral_history(3)
    history[-1] = _kline(2, open_price="100", high="110", low="90", close="105")
    # Newest candidate is bearish and has no matching trigger. The older
    # bullish candidate rejects; the scan must choose it without score sorting.
    newest = _candidate(9, bias=-1, top=105.0, bottom=95.0, break_index=1)
    older = _candidate(2, bias=1, top=105.0, bottom=95.0, break_index=1)

    result = _evaluate(
        config=_config(trigger_mode="Rejection"),
        history=history,
        candidates=(newest, older),
    )
    assert [row.active_array_index for row in result.scanned_candidates] == [9, 2]
    assert result.scanned_candidates[0].trigger_code == 0
    assert result.scanned_candidates[1].trigger_code == 1
    assert result.chosen_active_array_index == 2

    # Once the newest candidate succeeds, older candidates are not evaluated.
    newest_bullish = _candidate(9, bias=1, top=105.0, bottom=95.0, break_index=1)
    stopped = _evaluate(
        config=_config(trigger_mode="Rejection"),
        history=history,
        candidates=(newest_bullish, older),
    )
    assert len(stopped.scanned_candidates) == 1
    assert stopped.chosen_active_array_index == 9


def test_bullish_sweep_uses_strict_new_low_and_close_back_above_prior_range() -> None:
    history = [
        _kline(0, open_price="12", high="15", low="12", close="13"),
        _kline(1, open_price="11", high="14", low="11", close="12"),
        _kline(2, open_price="10", high="13", low="10", close="11"),
        _kline(3, open_price="9", high="12", low="9", close="10"),
        _kline(4, open_price="10", high="13", low="10", close="11"),
        _kline(5, open_price="10", high="13", low="10", close="11"),
        _kline(6, open_price="9", high="12", low="8", close="10.5"),
    ]
    engine = PineSmcStructureEngine(_config(require_sweep=True, sweep_lookback=3, sweep_window=1))
    assert engine._has_directional_sweep(history=history, local_index=6, bias=1) is True

    equal_low = list(history)
    equal_low[6] = _kline(6, open_price="9", high="12", low="9", close="10.5")
    assert engine._has_directional_sweep(history=equal_low, local_index=6, bias=1) is False

    no_reclaim = list(history)
    no_reclaim[6] = _kline(6, open_price="8.5", high="12", low="8", close="9")
    assert engine._has_directional_sweep(history=no_reclaim, local_index=6, bias=1) is False


def test_bearish_sweep_uses_strict_new_high_and_close_back_below_prior_range() -> None:
    history = [
        _kline(0, open_price="12", high="12", low="9", close="10"),
        _kline(1, open_price="13", high="13", low="10", close="11"),
        _kline(2, open_price="14", high="14", low="11", close="12"),
        _kline(3, open_price="15", high="15", low="12", close="13"),
        _kline(4, open_price="14", high="14", low="11", close="12"),
        _kline(5, open_price="14", high="14", low="11", close="12"),
        _kline(6, open_price="15", high="16", low="12", close="13.5"),
    ]
    engine = PineSmcStructureEngine(_config(require_sweep=True, sweep_lookback=3, sweep_window=1))
    assert engine._has_directional_sweep(history=history, local_index=6, bias=-1) is True

    equal_high = list(history)
    equal_high[6] = _kline(6, open_price="15", high="15", low="12", close="13.5")
    assert engine._has_directional_sweep(history=equal_high, local_index=6, bias=-1) is False

    no_reclaim = list(history)
    no_reclaim[6] = _kline(6, open_price="16", high="17", low="12", close="15.5")
    assert engine._has_directional_sweep(history=no_reclaim, local_index=6, bias=-1) is False


def test_sweep_window_scans_recent_prior_bars_with_pine_history_offsets() -> None:
    history = [
        _kline(0, open_price="12", high="15", low="12", close="13"),
        _kline(1, open_price="11", high="14", low="11", close="12"),
        _kline(2, open_price="10", high="13", low="10", close="11"),
        _kline(3, open_price="9", high="12", low="9", close="10"),
        _kline(4, open_price="10", high="13", low="10", close="11"),
        _kline(5, open_price="10", high="13", low="10", close="11"),
        _kline(6, open_price="9", high="12", low="8", close="10.5"),  # sweep one bar ago
        _kline(7, open_price="10", high="13", low="9", close="11"),
    ]
    engine = PineSmcStructureEngine(_config(require_sweep=True, sweep_lookback=3, sweep_window=2))
    assert engine._has_directional_sweep(history=history, local_index=7, bias=1) is True


def test_sweep_insufficient_lookback_is_skipped_and_sweep_disabled_bypasses() -> None:
    history = [
        _kline(0, open_price="10", high="13", low="8", close="11"),
        _kline(1, open_price="10", high="13", low="9", close="11"),
        _kline(2, open_price="10", high="13", low="9", close="11"),
        _kline(3, open_price="10", high="13", low="9", close="11"),
    ]
    require = PineSmcStructureEngine(_config(require_sweep=True, sweep_lookback=3, sweep_window=5))
    assert require._has_directional_sweep(history=history, local_index=3, bias=1) is False

    bypass = _evaluate(
        config=_config(require_sweep=False),
        history=[_kline(0, open_price="100", high="110", low="90", close="105")],
        candidates=(_candidate(4, break_index=0),),
    )
    assert bypass.scanned_candidates[0].sweep_passed is True
    assert bypass.chosen_active_array_index == 4


def test_sweep_gate_causes_scan_to_continue_to_older_candidate() -> None:
    # For the current bullish rejection the bullish sweep passes; a newer
    # bearish candidate has no bearish sweep and is bypassed. The older bullish
    # candidate can then be selected, proving sweep is evaluated per OB bias.
    history = [
        _kline(0, open_price="12", high="15", low="12", close="13"),
        _kline(1, open_price="11", high="14", low="11", close="12"),
        _kline(2, open_price="10", high="13", low="10", close="11"),
        _kline(3, open_price="9", high="12", low="9", close="10"),
        _kline(4, open_price="10", high="13", low="10", close="11"),
        _kline(5, open_price="10", high="13", low="10", close="11"),
        _kline(6, open_price="9", high="12", low="8", close="10.5"),
    ]
    bearish_newest = _candidate(9, bias=-1, top=11.0, bottom=9.0, break_index=1)
    bullish_older = _candidate(2, bias=1, top=11.0, bottom=9.0, break_index=1)
    result = _evaluate(
        config=_config(
            trigger_mode="Rejection",
            require_sweep=True,
            sweep_lookback=3,
            sweep_window=1,
            min_wick_pct=0,
        ),
        history=history,
        candidates=(bearish_newest, bullish_older),
    )
    assert result.scanned_candidates[0].sweep_passed is False
    assert result.scanned_candidates[1].sweep_passed is True
    assert result.chosen_active_array_index == 2


def test_trigger_sweep_trace_is_immutable_and_replay_serializes_stage6_metadata() -> None:
    history = [_kline(0, open_price="100", high="110", low="90", close="105")]
    config = _config(trigger_mode="Rejection", min_wick_pct=50.0)
    engine = PineSmcStructureEngine(config)
    # A normal replay with no active OB still emits a deterministic empty Stage-6 trace.
    result = engine.replay(history)
    row = result.trace[0]
    assert row.trigger_sweep.trigger_mode == "Rejection"
    assert row.trigger_sweep.require_sweep is False
    assert row.trigger_sweep.scanned_candidates == ()
    assert row.trigger_sweep.chosen_trigger_code == 0
    with pytest.raises(FrozenInstanceError):
        row.trigger_sweep.chosen_trigger_code = 1  # type: ignore[misc]

    serialized = json.loads(result.to_jsonl().splitlines()[0])
    assert serialized["trigger_sweep"]["chosen_active_array_index"] is None
    assert result.trigger_mode == "Rejection"
    assert result.struct_allow_bos is True
    assert result.min_wick_pct == 50.0
    assert result.require_sweep is False
    assert result.sweep_lookback == 20
    assert result.sweep_window == 5


def test_direct_stage6_scan_rejects_inconsistent_history_index() -> None:
    engine = PineSmcStructureEngine(_config())
    with pytest.raises(PineSmcReplayError, match="retained source history"):
        engine._evaluate_trigger_sweep(
            history=[],
            candle=_kline(0),
            structure_events=_events(),
            eligibility=PineSmcObEligibilityTrace(max_age=300),
            local_index=0,
        )
