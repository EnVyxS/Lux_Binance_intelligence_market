from __future__ import annotations

import hashlib
import json
from pathlib import Path

import httpx
import pytest

from divatrading.cli import build_parser, main
import divatrading.cli as cli_module
from divatrading.exchange.binance.client import BinanceRawKlinePage, BinanceUsdMFuturesRestClient
from divatrading.replay import (
    BinanceIntakeError,
    capture_current_binance_um_metadata,
    collect_binance_um_klines_rest,
)

ROOT = Path(__file__).resolve().parents[1]
EXCHANGE_INFO = ROOT / "tests" / "fixtures" / "exchange_info_valid.json"
INTERVAL_MS = 60_000
BASE = 1_760_000_040_000
BASE -= BASE % INTERVAL_MS


def _row(open_time: int) -> list[str | int]:
    return [
        open_time, "100.0", "101.0", "99.0", "100.5", "10.0",
        open_time + INTERVAL_MS - 1, "1000.0", 5, "5.0", "500.0", "0",
    ]


class _FakeRestClient:
    klines_endpoint = "https://fapi.binance.com/fapi/v1/klines"

    def __init__(self, rows: list[list[str | int]], server_time_ms: int) -> None:
        self.rows = rows
        self.server_time_ms = server_time_ms
        self.requests: list[dict[str, int | str]] = []

    def get_server_time_ms(self) -> int:
        return self.server_time_ms

    def get_klines_page_with_evidence(self, **kwargs) -> BinanceRawKlinePage:
        self.requests.append(kwargs.copy())
        selected = [
            row for row in self.rows
            if kwargs["start_time_ms"] <= int(row[0]) <= kwargs["end_time_ms"]
        ][: kwargs["limit"]]
        raw = json.dumps(selected, separators=(",", ":")).encode("utf-8")
        return BinanceRawKlinePage(
            rows=tuple(tuple(row) for row in selected),
            raw_body=raw,
            endpoint=self.klines_endpoint,
            request_params=tuple(sorted({
                "symbol": kwargs["symbol"], "interval": kwargs["interval"],
                "startTime": kwargs["start_time_ms"], "endTime": kwargs["end_time_ms"],
                "limit": kwargs["limit"],
            }.items())),
            response_headers=(("content-type", "application/json"),),
        )

    def close(self) -> None:
        pass


def test_rest_kline_intake_retains_exact_pages_and_derived_native_csv(tmp_path):
    end = BASE + 4 * INTERVAL_MS
    client = _FakeRestClient([_row(BASE + i * INTERVAL_MS) for i in range(4)], end + 1000)
    result = collect_binance_um_klines_rest(
        symbol="btcusdt", interval="1m", start_open_time_ms=BASE,
        end_open_time_ms_exclusive=end, dataset_root=tmp_path, capture_id="test-four-bars",
        page_limit=2, max_pages=10, request_interval_seconds=0, client=client,
    )

    assert result.complete is True
    assert result.symbol == "BTCUSDT"
    assert result.row_count == 4
    assert result.page_count == 2
    assert result.gap_count == 0
    assert result.first_open_time_ms == BASE
    assert result.last_open_time_ms == BASE + 3 * INTERVAL_MS
    assert result.csv_path.suffix == ".csv"
    csv_lines = result.csv_path.read_text(encoding="utf-8").splitlines()
    assert len(csv_lines) == 4
    assert len(csv_lines[0].split(",")) == 12

    raw_files = sorted(result.raw_capture_dir.glob("pages/*.json"))
    assert len(raw_files) == 2
    raw_bytes = raw_files[0].read_bytes()
    assert hashlib.sha256(raw_bytes).hexdigest() == json.loads(result.pages_index_path.read_text().splitlines()[0])["raw_sha256"]
    provenance = json.loads(result.provenance_path.read_text(encoding="utf-8"))
    assert provenance["capture_status"] == "COMPLETE"
    assert provenance["source_bytes_modified"] is False
    assert provenance["gap_policy"] == "REPORT_ONLY_NO_INTERPOLATION_OR_SYNTHESIS"
    assert provenance["strict_historical_calibration_eligible"] is False
    assert provenance["metadata_quality"].startswith("NOT_INCLUDED")


def test_rest_kline_intake_reports_gaps_without_synthesis(tmp_path):
    end = BASE + 5 * INTERVAL_MS
    rows = [_row(BASE), _row(BASE + 2 * INTERVAL_MS), _row(BASE + 3 * INTERVAL_MS)]
    client = _FakeRestClient(rows, end + 1000)
    result = collect_binance_um_klines_rest(
        symbol="BTCUSDT", interval="1m", start_open_time_ms=BASE,
        end_open_time_ms_exclusive=end, dataset_root=tmp_path, capture_id="with-gap",
        page_limit=10, request_interval_seconds=0, client=client,
    )
    assert result.complete is True
    assert result.row_count == 3
    assert result.gap_count == 2  # one internal and one trailing missing interval
    assert result.gap_sample_open_times_ms == (BASE + INTERVAL_MS, BASE + 4 * INTERVAL_MS)
    assert len(result.csv_path.read_text(encoding="utf-8").splitlines()) == 3


def test_rest_kline_intake_stops_at_page_cap_and_retains_partial_csv(tmp_path):
    end = BASE + 3 * INTERVAL_MS
    rows = [_row(BASE + i * INTERVAL_MS) for i in range(3)]
    client = _FakeRestClient(rows, end + 1000)
    result = collect_binance_um_klines_rest(
        symbol="BTCUSDT", interval="1m", start_open_time_ms=BASE,
        end_open_time_ms_exclusive=end, dataset_root=tmp_path, capture_id="partial-cap",
        page_limit=1, max_pages=1, request_interval_seconds=0, client=client,
    )
    assert result.complete is False
    assert result.page_count == 1
    assert result.gap_count == 0  # unrequested remainder is not mislabeled as a source gap
    assert result.csv_path.name.endswith(".partial.csv")
    provenance = json.loads(result.provenance_path.read_text(encoding="utf-8"))
    assert provenance["capture_status"] == "PARTIAL_PAGE_CAP"
    assert provenance["gap_assessment_complete"] is False


def test_rest_kline_intake_rejects_unclosed_windows_and_unaligned_bounds(tmp_path):
    client = _FakeRestClient([], BASE + 2 * INTERVAL_MS - 1)
    with pytest.raises(BinanceIntakeError, match="not-yet-closed"):
        collect_binance_um_klines_rest(
            symbol="BTCUSDT", interval="1m", start_open_time_ms=BASE,
            end_open_time_ms_exclusive=BASE + 2 * INTERVAL_MS,
            dataset_root=tmp_path, client=client,
        )
    with pytest.raises(BinanceIntakeError, match="interval-aligned"):
        collect_binance_um_klines_rest(
            symbol="BTCUSDT", interval="1m", start_open_time_ms=BASE + 1,
            end_open_time_ms_exclusive=BASE + 2 * INTERVAL_MS,
            dataset_root=tmp_path, client=client,
        )


def test_rest_kline_intake_rejects_capture_overwrite(tmp_path):
    end = BASE + INTERVAL_MS
    client = _FakeRestClient([_row(BASE)], end + 1000)
    kwargs = dict(
        symbol="BTCUSDT", interval="1m", start_open_time_ms=BASE,
        end_open_time_ms_exclusive=end, dataset_root=tmp_path,
        capture_id="immutable-capture", request_interval_seconds=0, client=client,
    )
    collect_binance_um_klines_rest(**kwargs)
    with pytest.raises(BinanceIntakeError, match="refusing overwrite"):
        collect_binance_um_klines_rest(**kwargs)


def test_rest_client_raw_kline_page_retains_exact_body_and_headers():
    raw = b'[[1760000040000,"100","101","99","100.5","10",1760000099999,"1000",5,"5","500","0"]]'

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/klines"):
            return httpx.Response(200, content=raw, headers={"content-type": "application/json", "etag": '"abc"'})
        if request.url.path.endswith("/time"):
            return httpx.Response(200, json={"serverTime": BASE + 2 * INTERVAL_MS})
        return httpx.Response(404)

    with httpx.Client(transport=httpx.MockTransport(handler)) as http_client:
        client = BinanceUsdMFuturesRestClient(http_client=http_client)
        page = client.get_klines_page_with_evidence(
            symbol="BTCUSDT", interval="1m", start_time_ms=BASE,
            end_time_ms=BASE, limit=10,
        )
        server_time = client.get_server_time_ms()
    assert page.raw_body == raw
    assert page.rows[0][0] == BASE
    assert dict(page.response_headers)["etag"] == '"abc"'
    assert server_time == BASE + 2 * INTERVAL_MS


def test_capture_current_metadata_is_explicitly_not_historical_evidence(tmp_path):
    raw_exchange_info = EXCHANGE_INFO.read_bytes()
    fixture = json.loads(raw_exchange_info)
    server_time = fixture["serverTime"] + 12345

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/exchangeInfo"):
            return httpx.Response(200, content=raw_exchange_info, headers={"date": "Wed, 12 Nov 2026 00:00:00 GMT"})
        if request.url.path.endswith("/time"):
            return httpx.Response(200, json={"serverTime": server_time})
        return httpx.Response(404)

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        result = capture_current_binance_um_metadata(
            symbol="BTCUSDT", output_dir=tmp_path, client=client,
        )

    assert result.symbol == "BTCUSDT"
    assert result.tick_size == "0.10"
    assert result.server_time_ms == server_time
    assert result.captured_at_ms > 0
    assert result.raw_exchange_info_path.read_bytes() == raw_exchange_info
    snapshot = json.loads(result.replay_snapshot_path.read_text(encoding="utf-8"))
    assert snapshot["quality"] == "CURRENT_SNAPSHOT_ONLY"
    assert snapshot["effective_from_ms"] is None
    assert snapshot["effective_to_ms"] is None
    assert snapshot["captured_at_ms"] == result.captured_at_ms
    provenance = json.loads(result.provenance_path.read_text(encoding="utf-8"))
    assert provenance["strict_historical_calibration_eligible"] is False


def test_stage6c_rest_intake_cli_help_is_registered():
    parser = build_parser()
    subcommands = parser._subparsers._group_actions[0].choices
    assert "binance-rest-kline-intake" in subcommands
    assert "binance-current-metadata" in subcommands
    assert "--end-open-time-ms-exclusive" in subcommands["binance-rest-kline-intake"].format_help()
    assert "--output-dir" in subcommands["binance-current-metadata"].format_help()
    assert "binance-archive-intake" not in subcommands


def test_rest_intake_cli_accepts_documented_page_cap(monkeypatch, tmp_path):
    monkeypatch.setattr(cli_module, "command_binance_rest_kline_intake", lambda args: 0)
    status = main([
        "binance-rest-kline-intake", "--symbol", "BTCUSDT", "--interval", "1m",
        "--start-open-time-ms", str(BASE),
        "--end-open-time-ms-exclusive", str(BASE + INTERVAL_MS),
        "--dataset-root", str(tmp_path), "--max-pages", "1000",
    ])
    assert status == 0
