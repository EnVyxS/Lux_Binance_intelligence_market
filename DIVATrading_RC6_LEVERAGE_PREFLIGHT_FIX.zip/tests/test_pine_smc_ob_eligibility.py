from __future__ import annotations

from dataclasses import FrozenInstanceError
import json

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import (
    PineSmcReplayError,
    PineSmcStructureConfig,
    PineSmcStructureEngine,
)
from divatrading.strategy.pine_smc_structure import (
    PineSmcIndicatorTrace,
    _PineOrderBlockState,
    _PineSmcState,
)

BASE_TIME_MS = 1_700_000_000_000


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 10,
        "internal_len": 1,
        "use_volatility_regime": False,
        "use_trend_filter": False,
        "use_pd_filter": False,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def _ob(
    index: int,
    *,
    bias: int = 1,
    top: float = 105.0,
    bottom: float = 95.0,
    break_index: int | None = None,
    used: bool = False,
    has_fvg: bool = False,
) -> _PineOrderBlockState:
    return _PineOrderBlockState(
        top=top,
        bottom=bottom,
        bar_local_index=index,
        break_local_index=index + 1 if break_index is None else break_index,
        source_time_ms=BASE_TIME_MS + index * 60_000,
        break_time_ms=BASE_TIME_MS + (index + 1) * 60_000,
        bias=bias,
        has_fvg=has_fvg,
        used=used,
    )


def _indicators(*, extreme: bool = False, choppy: bool = False) -> PineSmcIndicatorTrace:
    return PineSmcIndicatorTrace(
        atr_fast_now=1.0,
        rsi_now=50.0,
        volume_avg_now=10.0,
        di_plus_now=20.0,
        di_minus_now=20.0,
        adx_now=10.0,
        atr200_ratio_base=1.0,
        atr_ratio_now=1.0,
        volatility_extreme=extreme,
        volatility_choppy=choppy,
    )


def _evaluate(
    config: PineSmcStructureConfig,
    state: _PineSmcState,
    indicators: PineSmcIndicatorTrace | None = None,
):
    return PineSmcStructureEngine(config)._evaluate_ob_eligibility(
        state, _indicators() if indicators is None else indicators
    )


def _kline(index: int, *, open_price: str, high: str, low: str, close: str) -> Kline:
    interval = "1m"
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            "10",
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def test_stage5_config_defaults_validation_and_source_timeframe_max_age_mapping() -> None:
    defaults = _config()
    assert defaults.max_age_m5 == 300
    assert defaults.max_age_m15 == 150
    assert defaults.fresh_only is True
    assert defaults.use_trend_filter is False  # overridden by this test helper
    assert defaults.use_pd_filter is False
    assert defaults.require_fvg is False

    assert PineSmcStructureEngine(_config(timeframe="1m"))._max_age_for_timeframe() == 300
    assert PineSmcStructureEngine(_config(timeframe="5m"))._max_age_for_timeframe() == 300
    assert PineSmcStructureEngine(_config(timeframe="15m"))._max_age_for_timeframe() == 150
    assert PineSmcStructureEngine(
        _config(timeframe="1m", max_age_m5=77, max_age_m15=33)
    )._max_age_for_timeframe() == 77
    assert PineSmcStructureEngine(
        _config(timeframe="15m", max_age_m5=77, max_age_m15=33)
    )._max_age_for_timeframe() == 33

    for name in ("max_age_m5", "max_age_m15"):
        for invalid in (0, -1, True, 1.5, "10"):
            with pytest.raises(PineSmcReplayError, match=name):
                _config(**{name: invalid})
    for name in ("fresh_only", "use_trend_filter", "use_pd_filter", "require_fvg"):
        with pytest.raises(PineSmcReplayError, match=name):
            _config(**{name: 1})

    pine_defaults = PineSmcStructureConfig(symbol="BTCUSDT", timeframe="1m")
    assert pine_defaults.fresh_only is True
    assert pine_defaults.use_trend_filter is True
    assert pine_defaults.use_pd_filter is True
    assert pine_defaults.require_fvg is False


def test_candidates_scan_newest_to_oldest_and_preserve_original_array_indices() -> None:
    state = _PineSmcState(local_index=10)
    state.active_order_blocks.extend(
        [
            _ob(0, break_index=4),  # age 6: outside maxAgeM5=5
            _ob(1, break_index=7),  # age 3: eligible
            _ob(2, break_index=9),  # age 1: eligible and newest
        ]
    )
    result = _evaluate(_config(max_age_m5=5), state)

    assert [row.active_array_index for row in result.scanned_newest_to_oldest] == [2, 1, 0]
    assert [row.active_array_index for row in result.eligible_candidates] == [2, 1]
    assert result.scanned_newest_to_oldest[-1].rejection_reasons == ("age_window",)
    # Eligibility is a read-only view; the oldest-to-newest active array is intact.
    assert [row.break_local_index for row in state.active_order_blocks] == [4, 7, 9]


def test_age_gate_is_strict_after_break_and_inclusive_at_max_age() -> None:
    state = _PineSmcState(local_index=10)
    state.active_order_blocks.extend(
        [
            _ob(0, break_index=10),  # localIndex <= breakIndex
            _ob(1, break_index=9),   # age 1
            _ob(2, break_index=5),   # age exactly maxAge
            _ob(3, break_index=4),   # age maxAge + 1
        ]
    )
    result = _evaluate(_config(max_age_m5=5), state)

    by_index = {row.active_array_index: row for row in result.scanned_newest_to_oldest}
    assert by_index[0].eligible is False
    assert by_index[1].eligible is True
    assert by_index[2].eligible is True
    assert by_index[3].eligible is False
    assert by_index[0].rejection_reasons == ("age_window",)
    assert by_index[3].rejection_reasons == ("age_window",)


def test_fresh_only_rejects_used_ob_without_mutating_used_state() -> None:
    state = _PineSmcState(local_index=8)
    used = _ob(0, break_index=4, used=True)
    state.active_order_blocks.append(used)

    reject = _evaluate(_config(fresh_only=True), state)
    assert reject.eligible_candidates == ()
    assert reject.scanned_newest_to_oldest[0].rejection_reasons == ("fresh_only_used",)
    assert used.used is True

    allow = _evaluate(_config(fresh_only=False), state)
    assert len(allow.eligible_candidates) == 1
    assert used.used is True


def test_trend_filter_requires_matching_swing_trend_for_each_ob_direction() -> None:
    state = _PineSmcState(local_index=8, swing_trend=1)
    state.active_order_blocks.extend([_ob(0, bias=1, break_index=4), _ob(1, bias=-1, break_index=4)])
    result = _evaluate(_config(use_trend_filter=True), state)

    by_index = {row.active_array_index: row for row in result.scanned_newest_to_oldest}
    assert by_index[0].eligible is True
    assert by_index[1].eligible is False
    assert by_index[1].rejection_reasons == ("swing_trend_mismatch",)

    state.swing_trend = -1
    reverse = _evaluate(_config(use_trend_filter=True), state)
    reverse_by_index = {row.active_array_index: row for row in reverse.scanned_newest_to_oldest}
    assert reverse_by_index[0].eligible is False
    assert reverse_by_index[1].eligible is True

    state.swing_trend = 0
    neutral = _evaluate(_config(use_trend_filter=True), state)
    assert neutral.eligible_candidates == ()


def test_premium_discount_filter_uses_midpoint_and_strict_equilibrium_boundary() -> None:
    state = _PineSmcState(
        local_index=8,
        range_top=120.0,
        range_top_valid=True,
        range_bottom=80.0,
        range_bottom_valid=True,
    )
    state.active_order_blocks.extend(
        [
            _ob(0, bias=1, top=102.0, bottom=100.0, break_index=4),  # bullish midpoint 101 > 100
            _ob(1, bias=1, top=101.0, bottom=99.0, break_index=4),   # equal 100
            _ob(2, bias=-1, top=100.0, bottom=98.0, break_index=4),  # bearish midpoint 99 < 100
            _ob(3, bias=-1, top=101.0, bottom=99.0, break_index=4),  # equal 100
        ]
    )
    result = _evaluate(_config(use_pd_filter=True), state)
    by_index = {row.active_array_index: row for row in result.scanned_newest_to_oldest}

    assert by_index[0].rejection_reasons == ("premium_discount_mismatch",)
    assert by_index[1].eligible is True
    assert by_index[2].rejection_reasons == ("premium_discount_mismatch",)
    assert by_index[3].eligible is True

    # Pine bypasses the PD gate unless both range endpoints are valid and top > bottom.
    state.range_top = state.range_bottom = 100.0
    bypass = _evaluate(_config(use_pd_filter=True), state)
    assert all(row.eligible for row in bypass.eligible_candidates)


def test_require_fvg_gate_uses_stored_flag_only() -> None:
    state = _PineSmcState(local_index=8)
    state.active_order_blocks.extend(
        [
            _ob(0, break_index=4, has_fvg=False),
            _ob(1, break_index=4, has_fvg=True),
        ]
    )
    result = _evaluate(_config(require_fvg=True), state)
    by_index = {row.active_array_index: row for row in result.scanned_newest_to_oldest}

    assert by_index[0].eligible is False
    assert by_index[0].rejection_reasons == ("fvg_required_missing",)
    assert by_index[1].eligible is True

    disabled = _evaluate(_config(require_fvg=False), state)
    assert len(disabled.eligible_candidates) == 2


def test_extreme_and_choppy_regimes_both_reject_without_recomputing_regime() -> None:
    state = _PineSmcState(local_index=8)
    state.active_order_blocks.append(_ob(0, break_index=4))

    extreme = _evaluate(
        _config(), state, _indicators(extreme=True, choppy=False)
    )
    assert extreme.scanned_newest_to_oldest[0].rejection_reasons == ("volatility_extreme",)

    choppy = _evaluate(
        _config(), state, _indicators(extreme=False, choppy=True)
    )
    assert choppy.scanned_newest_to_oldest[0].rejection_reasons == ("volatility_choppy",)

    both = _evaluate(
        _config(), state, _indicators(extreme=True, choppy=True)
    )
    assert both.scanned_newest_to_oldest[0].rejection_reasons == (
        "volatility_extreme",
        "volatility_choppy",
    )


def test_all_gate_rejections_are_recorded_in_pine_condition_order() -> None:
    state = _PineSmcState(
        local_index=8,
        swing_trend=-1,
        range_top=120.0,
        range_top_valid=True,
        range_bottom=80.0,
        range_bottom_valid=True,
    )
    used_ob = _ob(0, bias=1, top=110.0, bottom=108.0, break_index=4, used=True)
    state.active_order_blocks.append(used_ob)

    result = _evaluate(
        _config(
            fresh_only=True,
            use_trend_filter=True,
            use_pd_filter=True,
            require_fvg=True,
        ),
        state,
        _indicators(extreme=True, choppy=True),
    )
    assert result.scanned_newest_to_oldest[0].rejection_reasons == (
        "fresh_only_used",
        "swing_trend_mismatch",
        "premium_discount_mismatch",
        "fvg_required_missing",
        "volatility_extreme",
        "volatility_choppy",
    )


def test_eligibility_snapshots_are_immutable_and_jsonl_serializable() -> None:
    state = _PineSmcState(local_index=8)
    state.active_order_blocks.extend([_ob(0, break_index=4), _ob(1, break_index=4)])
    trace = _evaluate(_config(), state)

    assert [row.active_array_index for row in trace.eligible_candidates] == [1, 0]
    assert trace.eligible_candidates[0].order_block.break_local_index == 4
    with pytest.raises(FrozenInstanceError):
        trace.eligible_candidates[0].eligible = False  # type: ignore[misc]

    # Replay output uses asdict + stable sorted JSON; the stage-5 record appears
    # on each processed bar and preserves all candidate snapshots.
    replay = PineSmcStructureEngine(_config()).replay(
        [_kline(0, open_price="100", high="101", low="99", close="100")]
    )
    payload = json.loads(replay.to_jsonl().splitlines()[0])
    assert payload["ob_eligibility"]["max_age"] == 300
    assert payload["ob_eligibility"]["scanned_newest_to_oldest"] == []
    assert replay.max_age_m5 == 300
    assert replay.max_age_m15 == 150


def test_replay_evaluates_new_ob_after_same_bar_mitigation_phase_on_later_bar() -> None:
    candles = [
        _kline(0, open_price="100", high="110", low="90", close="100"),
        _kline(1, open_price="105", high="112", low="95", close="107"),
        _kline(2, open_price="105", high="111", low="96", close="108"),
        _kline(3, open_price="106", high="110", low="100", close="108"),
        _kline(4, open_price="112", high="120", low="94", close="118"),
        _kline(5, open_price="110", high="113", low="103", close="110"),
    ]
    result = PineSmcStructureEngine(_config(mitigate_close=True)).replay(candles)

    assert result.trace[4].ob_lifecycle.created
    same_bar = result.trace[4].ob_eligibility.scanned_newest_to_oldest
    assert len(same_bar) == 1
    assert same_bar[0].eligible is False
    assert same_bar[0].rejection_reasons == ("age_window",)
    later = result.trace[5].ob_eligibility
    assert len(later.scanned_newest_to_oldest) == 1
    candidate = later.scanned_newest_to_oldest[0]
    assert candidate.active_array_index == 0
    assert candidate.order_block.break_local_index == 4
    assert candidate.eligible is True
    assert later.eligible_candidates == (candidate,)
