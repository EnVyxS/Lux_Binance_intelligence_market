from __future__ import annotations

import tomllib
from pathlib import Path

from divatrading import __version__


def test_package_version_matches_pyproject_metadata() -> None:
    project_root = Path(__file__).resolve().parents[1]
    metadata = tomllib.loads((project_root / "pyproject.toml").read_text(encoding="utf-8"))
    assert __version__ == metadata["project"]["version"]
    assert __version__ == "0.59.0rc6"
