from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

import pytest

from divatrading.market_data.klines import Kline, KlineParseError


def row(open_time=0, *, close_time=None):
    return [
        open_time, "100.00", "103.00", "99.00", "101.50", "12.25",
        open_time + 59_999 if close_time is None else close_time,
        "1234.50", 42, "5.25", "530.00", "0",
    ]


def test_kline_parser_preserves_decimal_precision_and_utc_identity():
    candle = Kline.from_binance_row(
        row(60_000), symbol="btcusdt", interval="1m",
        source_endpoint="https://fapi.binance.com/fapi/v1/klines",
    )
    assert candle.exchange == "BINANCE_UM"
    assert candle.symbol == "BTCUSDT"
    assert candle.open == Decimal("100.00")
    assert candle.volume == Decimal("12.25")
    assert candle.open_time_utc == datetime(1970, 1, 1, 0, 1, tzinfo=UTC)
    assert candle.close_time_ms == 119_999


def test_kline_parser_rejects_wrong_shape_unaligned_time_and_invalid_ohlc():
    with pytest.raises(KlineParseError, match="12 fields"):
        Kline.from_binance_row([1, 2], symbol="BTCUSDT", interval="1m", source_endpoint="x")

    with pytest.raises(KlineParseError, match="not aligned"):
        Kline.from_binance_row(row(1), symbol="BTCUSDT", interval="1m", source_endpoint="x")

    bad = row()
    bad[2] = "98"
    with pytest.raises(KlineParseError, match="high is below"):
        Kline.from_binance_row(bad, symbol="BTCUSDT", interval="1m", source_endpoint="x")

    bad_time = row(close_time=60_000)
    with pytest.raises(KlineParseError, match="does not match the interval boundary"):
        Kline.from_binance_row(bad_time, symbol="BTCUSDT", interval="1m", source_endpoint="x")
