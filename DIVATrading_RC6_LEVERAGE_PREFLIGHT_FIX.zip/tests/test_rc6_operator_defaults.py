"""RC6 acceptance: operator risk policy and Telegram offline safety contract."""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json
from pathlib import Path

import pytest

from divatrading.cli import _autonomous_max_positions, build_parser, command_telegram_check, main
from divatrading.core.config import _parse_env_file
from divatrading.core.database import Database
from divatrading.execution.service import ExecutionConfig, ExecutionMode
from divatrading.trading.control_plane import OperatorControlStore, LossState, evaluate_loss_limits
from divatrading.trading.commissioning import LiveFirstCommissioningCaps
from divatrading.trading.risk import PortfolioRiskConfig
from divatrading.trading.telegram_ops import TelegramOperationalNotifier

PROJECT = Path(__file__).resolve().parents[1]


def test_new_db_default_bullet_one_dollar_loss_and_auto_leverage(tmp_path):
    store = OperatorControlStore(Database(tmp_path / "fresh.db"))
    state = store.get()
    assert state["risk"] == {"mode": "FIXED", "value": "0.20"}
    assert state["max_loss"]["daily_mode"] == "USDT"
    assert Decimal(state["max_loss"]["daily_value"]) == Decimal("1")
    assert state["leverage"] == {"mode": "AUTO", "max": 125}
    loss_state = LossState(Decimal("-0.80"), Decimal("-0.22"), 0,
                           Decimal("20"), Decimal("19"), "2026-11-15")
    assert "DAILY_MAX_LOSS_REACHED" in evaluate_loss_limits(state, loss_state).reasons


def test_previous_unconfigured_rc5_db_migrates_but_operator_overrides_survive(tmp_path):
    db = Database(tmp_path / "existing.db")
    db.initialize()
    from divatrading.trading.control_plane import CONTROL_KEY
    db.set_setting(CONTROL_KEY, {
        "risk": {"mode": "UNCONFIGURED", "value": None},
        "max_loss": {"daily_mode": "UNCONFIGURED", "daily_value": None,
                     "streak": 3, "drawdown_pct": "7", "timezone": "Asia/Jakarta"},
        "leverage": {"mode": "FIXED", "max": 8},
        "margin_mode": "ISOLATED", "runtime": {"paused": True, "killed": False},
        "account_policy": "BOT_ONLY", "revision": 1,
    })
    store = OperatorControlStore(db)
    state = store.get()
    assert state["risk"] == {"mode": "FIXED", "value": "0.20"}
    assert state["max_loss"]["daily_value"] == "1.00"
    assert state["max_loss"]["streak"] == 3
    assert state["leverage"] == {"mode": "FIXED", "max": 8}
    assert state["runtime"]["paused"] is True
    store.set_risk("percent", "2")
    store.set_maxloss("daily", "3", "USDT")
    restarted = OperatorControlStore(Database(tmp_path / "existing.db"))
    assert restarted.get()["risk"]["mode"] == "PERCENT"
    assert restarted.get()["max_loss"]["daily_value"] == "3"


def test_release_env_only_needs_binance_keys_for_optional_real_order_launcher():
    template = _parse_env_file(PROJECT / ".env.example")
    assert template["BINANCE_API_KEY"] == ""
    assert template["BINANCE_API_SECRET"] == ""
    assert template["DIVA_EXECUTION_MODE"] == "LIVE"
    assert template["DIVA_ENFORCE_ENTRY_QUOTE_GUARD"] == "true"
    assert template["DIVA_ENABLE_PROTECTION_RECOVERY"] == "true"
    config = ExecutionConfig.from_env(template)
    assert config.mode == ExecutionMode.LIVE
    args = build_parser().parse_args(["auto-trade-runtime", "--activate-live", "--mode", "AUTO"])
    assert args.max_symbols >= 2
    assert Decimal(args.max_portfolio_risk_pct) == Decimal("20")
    assert args.live_max_daily_loss_pct is None  # persisted USDT limit, not RC5 1%
    assert args.live_max_drawdown_pct is None
    assert "START LIVE TRADING" in (PROJECT / "START_LIVE_WINDOWS.bat").read_text()


def test_live_fixed_bullet_respects_account_equity_and_exchange_can_reject_minimum():
    config = PortfolioRiskConfig(risk_per_trade_fixed_usdt=Decimal("0.20"),
                                 max_portfolio_open_risk_pct=Decimal("20"),
                                 max_positions=2, leverage=3, max_leverage=125)
    cap = LiveFirstCommissioningCaps()
    assert cap.violation(config, equity_usdt=Decimal("10")) is None
    assert cap.violation(config, equity_usdt=Decimal("1")) == "LIVE_FIRST_COMMISSIONING_FIXED_RISK_CAP_EXCEEDED"
    assert cap.violation(
        replace(config, max_positions=3), equity_usdt=Decimal("10"),
    ) == "LIVE_FIRST_COMMISSIONING_POSITION_CAP_EXCEEDED"
    assert config.max_positions == 2
    assert config.max_leverage == 125


def test_autonomous_position_cap_defaults_to_one_on_live():
    parser = build_parser()
    args = parser.parse_args(["auto-trade-runtime"])
    assert _autonomous_max_positions(ExecutionMode.LIVE, args.max_positions) == 1
    assert _autonomous_max_positions(ExecutionMode.PAPER, args.max_positions) == 5
    assert _autonomous_max_positions(ExecutionMode.TESTNET, args.max_positions) == 5
    args = parser.parse_args(["auto-trade-runtime", "--max-positions", "2"])
    assert _autonomous_max_positions(ExecutionMode.LIVE, args.max_positions) == 2
    with pytest.raises(SystemExit):
        parser.parse_args(["auto-trade-runtime", "--max-positions", "3"])


def test_risk_config_uses_the_selected_sqlite_profile(monkeypatch, tmp_path, capsys):
    previous = OperatorControlStore(Database(tmp_path / "previous.sqlite"))
    previous.set_risk("percent", "3")
    trial = tmp_path / "trial.sqlite"
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("DIVA_DATABASE_PATH", str(trial))

    assert main(["risk-config"]) == 0
    assert json.loads(capsys.readouterr().out) == {
        "database_path": str(trial),
        "risk": {"mode": "FIXED", "value": "0.20"},
    }
    assert main(["risk-config", "--mode", "percent", "--value", "0.5"]) == 0
    assert json.loads(capsys.readouterr().out)["risk"] == {"mode": "PERCENT", "value": "0.5"}
    assert OperatorControlStore(Database(trial)).get()["risk"] == {"mode": "PERCENT", "value": "0.5"}
    assert previous.get()["risk"] == {"mode": "PERCENT", "value": "3"}

    assert main(["risk-config", "--mode", "fixed"]) == 2
    assert "must be provided together" in capsys.readouterr().err
    assert main(["risk-config", "--mode", "fixed", "--value", "0.30"]) == 0
    assert json.loads(capsys.readouterr().out)["risk"] == {"mode": "FIXED", "value": "0.30"}


def test_telegram_notifier_validates_private_owner_and_never_posts_on_rejected(monkeypatch):
    calls = []
    bot = TelegramOperationalNotifier("secret-placeholder", "123")

    def fake_invoke(method, *, params=None, payload=None):
        calls.append((method, params, payload))
        if method == "getMe":
            return {"ok": True, "result": {"is_bot": True, "username": "divatest"}}
        if method == "getChat":
            return {"ok": True, "result": {"id": 123, "type": "private"}}
        if method == "getWebhookInfo":
            return {"ok": True, "result": {"url": ""}}
        return {"ok": True, "result": {"message_id": 1}}

    monkeypatch.setattr(bot, "_invoke", fake_invoke)
    assert bot.verify_connection() == {"ok": True, "bot_username": "divatest", "owner_chat_valid": True}
    bot.notify_dispatch(symbol="BTCUSDT", timeframe="1m", side="LONG", status="REJECTED",
                        reason="MIN_QTY", signal_id="sg1")
    assert len(calls) == 3
    bot.notify_dispatch(symbol="BTCUSDT", timeframe="1m", side="LONG", status="DISPATCHED",
                        reason="ENTRY_PENDING", signal_id="sg1")
    assert len(calls) == 4
    assert calls[-1][0] == "sendMessage"
    assert calls[-1][2]["chat_id"] == "123"
    assert "ENTRY_PENDING" in calls[-1][2]["text"]


def test_telegram_runtime_errors_never_include_token(monkeypatch):
    token = "never-leak-this-secret"
    bot = TelegramOperationalNotifier(token, "123")

    class ExplodingClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *_args): return False
        def get(self, url, **kwargs):
            raise RuntimeError(url)

    from divatrading.trading import telegram_ops
    monkeypatch.setattr(telegram_ops.httpx, "Client", ExplodingClient)
    with pytest.raises(RuntimeError) as exc:
        bot.verify_connection()
    assert token not in str(exc.value)
    assert "redacted" in str(exc.value)


def test_cli_telegram_diagnostic_without_keys_never_connects(monkeypatch, capsys):
    from divatrading import cli
    class EmptySettings:
        telegram_bot_token = None
        telegram_owner_id = None
    monkeypatch.setattr(cli, "_settings", lambda: EmptySettings())
    assert command_telegram_check(None) == 2
    assert "NOT_CONFIGURED" in capsys.readouterr().err


def test_auto_leverage_respects_symbol_bracket_and_lowest_margin_feasible():
    from divatrading.trading.exchange_feasibility import (
        assess_margin_feasibility, LeverageBracket, SymbolCommission,
    )
    brackets = (LeverageBracket(1, 50, Decimal("0"), Decimal("100000"),
                                Decimal("0.004"), Decimal("0")),)
    commission = SymbolCommission(Decimal("0"), Decimal("0"))
    result = assess_margin_feasibility(notional=Decimal("100"),
                                       available_margin=Decimal("4"),
                                       brackets=brackets, commission=commission,
                                       max_leverage=125)
    assert result.accepted and result.leverage == 25
    assert not assess_margin_feasibility(notional=Decimal("100"),
                                        available_margin=Decimal("4"),
                                        brackets=brackets, commission=commission,
                                        max_leverage=125, fixed_leverage=60).accepted


def test_telegram_webhook_conflict_is_detected_before_start(monkeypatch):
    bot = TelegramOperationalNotifier("secret", "123")
    def fake_invoke(method, *, params=None, payload=None):
        if method == "getMe": return {"ok": True, "result": {"is_bot": True}}
        if method == "getChat": return {"ok": True, "result": {"id": 123, "type": "private"}}
        if method == "getWebhookInfo": return {"ok": True, "result": {"url": "https://example.invalid/hook"}}
    monkeypatch.setattr(bot, "_invoke", fake_invoke)
    with pytest.raises(RuntimeError, match="WEBHOOK_CONFLICT"):
        bot.verify_connection()
