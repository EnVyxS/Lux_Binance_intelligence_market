from __future__ import annotations

import json
from pathlib import Path

import pytest

from divatrading import cli
from divatrading.execution.binance_private import BinancePrivateApiError

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"
pytestmark = pytest.mark.usefixtures("isolated_cli_environment")


class FakeReadyPreflight:
    def __init__(self, client, *, symbols):
        assert symbols == ("BTCUSDT",)
        self.ready_for_test_order = True
        self.status = "READY_FOR_TEST_ORDER_VALIDATION"
        self.checks = []

    def run(self):
        return self


class FakeBlockedPreflight(FakeReadyPreflight):
    def __init__(self, client, *, symbols):
        super().__init__(client, symbols=symbols)
        self.ready_for_test_order = False
        self.status = "BLOCKED_PREFLIGHT"
        self.checks = [type("Check", (), {"code": "ACCOUNT_POSITIONS", "status": "FAIL"})()]


class FakeDemoClient:
    def __init__(self, api_key, api_secret, *, environment):
        assert api_key == "local-demo-key"
        assert api_secret == "local-demo-secret"
        assert environment == "TESTNET"
        self.closed = False
        self.test_order_calls = []
        self.position_mode = {"dualSidePosition": False}

    def close(self):
        self.closed = True

    def get_exchange_info(self):
        return json.loads(FIXTURE.read_text(encoding="utf-8"))

    def get_position_mode(self):
        return self.position_mode

    def new_test_order(self, **params):
        self.test_order_calls.append(params)
        return {"orderId": 111, "symbol": params["symbol"]}




class FakeRejectedDemoClient(FakeDemoClient):
    def new_test_order(self, **params):
        self.test_order_calls.append(params)
        raise BinancePrivateApiError(400, -1022, "signed error must not be printed", "/fapi/v1/order/test")


class FakeServerErrorDemoClient(FakeDemoClient):
    def new_test_order(self, **params):
        self.test_order_calls.append(params)
        raise BinancePrivateApiError(502, None, "proxy failure must not be printed", "/fapi/v1/order/test")


def _write_env(tmp_path: Path, *, enabled: bool = True):
    (tmp_path / ".env").write_text(
        "DIVA_EXECUTION_MODE=TESTNET\n"
        "DIVA_ENABLE_TESTNET_ORDERS=false\n"
        f"DIVA_ENABLE_TESTNET_ORDER_TEST={'true' if enabled else 'false'}\n"
        "DIVA_LIVE_TRADING_ENABLED=false\n"
        "BINANCE_API_KEY=local-demo-key\n"
        "BINANCE_API_SECRET=local-demo-secret\n",
        encoding="utf-8",
    )


def test_testnet_order_test_cli_parser_requires_explicit_order_details():
    args = cli.build_parser().parse_args([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    assert args.command == "testnet-order-test"
    assert args.symbol == "BTCUSDT"
    assert args.order_type == "MARKET"
    assert args.confirm_test_order is True


def test_testnet_order_test_cli_requires_separate_local_opt_in(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=False)
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: (_ for _ in ()).throw(AssertionError("must not connect")))
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_EXPLICIT_OPT_IN"
    assert payload["matching_engine_submission"] is False


def test_testnet_order_test_cli_blocks_actual_order_execution_flag(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    env = (tmp_path / ".env").read_text(encoding="utf-8").replace(
        "DIVA_ENABLE_TESTNET_ORDERS=false", "DIVA_ENABLE_TESTNET_ORDERS=true"
    )
    (tmp_path / ".env").write_text(env, encoding="utf-8")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: (_ for _ in ()).throw(AssertionError("must not connect")))
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_CONFIGURATION"
    assert payload["matching_engine_submission"] is False


def test_testnet_order_test_cli_requires_cli_confirmation_even_when_env_enabled(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: (_ for _ in ()).throw(AssertionError("must not connect")))
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001",
    ])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_EXPLICIT_OPT_IN"


def test_testnet_order_test_cli_reruns_preflight_then_submits_validation_only(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    client = FakeDemoClient("local-demo-key", "local-demo-secret", environment="TESTNET")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: client)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakeReadyPreflight)
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    output = capsys.readouterr().out
    payload = json.loads(output)
    assert rc == 0
    assert payload["status"] == "TEST_ORDER_ACCEPTED"
    assert payload["validation_only"] is True
    assert payload["trade_permission_validated"] is True
    assert payload["matching_engine_submission"] is False
    assert payload["order_created"] is False
    assert payload["actual_execution"] is False
    assert len(client.test_order_calls) == 1
    assert client.test_order_calls[0] == {
        "symbol": "BTCUSDT", "side": "BUY", "type": "MARKET",
        "quantity": "0.001", "positionSide": "BOTH",
    }
    assert "local-demo-key" not in output
    assert "local-demo-secret" not in output
    assert client.closed is True


def test_testnet_order_test_cli_redacts_api_rejection_details(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    client = FakeRejectedDemoClient("local-demo-key", "local-demo-secret", environment="TESTNET")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: client)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakeReadyPreflight)
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    output = capsys.readouterr().out
    payload = json.loads(output)
    assert rc == 3
    assert payload["status"] == "EXCHANGE_REJECTED"
    assert payload["exchange_code"] == -1022
    assert "signed error must not be printed" not in output
    assert "local-demo-key" not in output
    assert "local-demo-secret" not in output
    assert client.closed is True


def test_testnet_order_test_cli_classifies_server_error_without_retry(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    client = FakeServerErrorDemoClient("local-demo-key", "local-demo-secret", environment="TESTNET")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: client)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakeReadyPreflight)
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    output = capsys.readouterr().out
    payload = json.loads(output)
    assert rc == 4
    assert payload["status"] == "EXCHANGE_RESPONSE_ERROR"
    assert payload["automatic_retry"] is False
    assert "proxy failure must not be printed" not in output
    assert len(client.test_order_calls) == 1
    assert client.closed is True


def test_testnet_order_test_cli_blocks_when_preflight_not_ready(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    client = FakeDemoClient("local-demo-key", "local-demo-secret", environment="TESTNET")
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: client)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakeBlockedPreflight)
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_PREFLIGHT"
    assert payload["failed_checks"] == [{"code": "ACCOUNT_POSITIONS", "status": "FAIL"}]
    assert client.test_order_calls == []
    assert client.closed is True


def test_testnet_order_test_cli_requires_explicit_hedge_position_side(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_env(tmp_path, enabled=True)
    client = FakeDemoClient("local-demo-key", "local-demo-secret", environment="TESTNET")
    client.position_mode = {"dualSidePosition": True}
    monkeypatch.setattr(cli, "BinancePrivateRestClient", lambda *a, **k: client)
    monkeypatch.setattr(cli, "BinanceTestnetPreflight", FakeReadyPreflight)
    rc = cli.main([
        "testnet-order-test", "--symbol", "BTCUSDT", "--side", "BUY",
        "--order-type", "MARKET", "--quantity", "0.001", "--confirm-test-order",
    ])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["status"] == "BLOCKED_ORDER_PARAMETERS"
    assert "position_side LONG or SHORT is required" in payload["reason"]
    assert client.test_order_calls == []
