from decimal import Decimal

import pytest

from divatrading.market_data.absorption import (
    AbsorptionConfig,
    AbsorptionInputError,
    DepthAggressorAlignmentService,
)
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot

NOW = 1_800_000_000_000


def flow(*, t: int, cvd: str, delta: str = "100", status: str = "HEALTHY",
         fresh: bool = True, continuity: bool = True, cursor: int = 10) -> OrderFlowSnapshot:
    return OrderFlowSnapshot(
        symbol="BTCUSDT", status=status, continuity_valid=continuity, is_fresh=fresh,
        data_age_ms=0, baseline_aggregate_trade_id=1, last_processed_aggregate_trade_id=cursor,
        last_trade_time_ms=t, cvd_base=Decimal(cvd) / Decimal("100"), cvd_quote=Decimal(cvd),
        bucket_interval="1s", lookback_buckets=1, window_start_ms=t-1000,
        window_end_ms=t, buy_volume_base=Decimal("2"), sell_volume_base=Decimal("1"),
        delta_base=Decimal("1"), buy_volume_quote=Decimal("200"),
        sell_volume_quote=Decimal("100"), delta_quote=Decimal(delta),
        buy_imbalance_base=Decimal("0.33"), buy_imbalance_quote=Decimal("0.33"),
        trade_count=3, integrity_reason=None,
    )


def health(*, ready: bool = True) -> OrderBookSymbolHealth:
    return OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED" if ready else "DISCONNECTED",
        snapshot_state="READY" if ready else "RESYNC_REQUIRED", sequence_integrity=ready,
        event_fresh=ready, queue_healthy=ready, ready=ready, update_id=100,
        event_age_ms=0, queue_depth=0, queue_capacity=100, buffered_events=0,
        invalid_reason="NONE" if ready else "FEED_DISCONNECTED", last_error=None,
    )


def book(*, t: int, ask_depth: str = "10", bid_depth: str = "12",
         mid: str = "100.5", update_id: int = 100) -> OrderBookMetrics:
    mid_d = Decimal(mid)
    return OrderBookMetrics(
        symbol="BTCUSDT", update_id=update_id,
        best_bid=mid_d-Decimal("0.5"), best_ask=mid_d+Decimal("0.5"),
        spread=Decimal("1"), spread_bps=Decimal("99.5"),
        bid_depth=Decimal(bid_depth), ask_depth=Decimal(ask_depth),
        imbalance=(Decimal(bid_depth)-Decimal(ask_depth))/(Decimal(bid_depth)+Decimal(ask_depth)),
        level_count_bid=20, level_count_ask=20, synchronized=True, last_event_time_ms=t,
    )


def config(**kwargs):
    values = {"min_net_aggression_quote": Decimal("500")}
    values.update(kwargs)
    return AbsorptionConfig(**values)


def observe(service, t, cvd, *, ask="10", bid="12", mid="100.5", delta="100"):
    return service.observe(
        symbol="BTCUSDT", flow=flow(t=t, cvd=cvd, delta=delta),
        book_health=health(), book=book(t=t, ask_depth=ask, bid_depth=bid, mid=mid),
        observed_at_ms=t,
    )


def test_buy_aggression_with_limited_upside_and_persistent_ask_depth_is_candidate():
    service = DepthAggressorAlignmentService(config=config())
    for i, ask in enumerate(("10", "9.8", "9.6", "10.1", "10.2")):
        result = observe(service, NOW + i*1000, str(i*400), ask=ask)
    assert result.status == "CANDIDATE"
    assert result.absorbed_aggressor == "BUY"
    assert result.cvd_change_quote == Decimal("1600")
    assert result.price_progress_bps == Decimal("0")
    assert result.opposing_depth_min_ratio == Decimal("0.96")
    assert "BUY_AGGRESSION_AT_ASK" in result.reason_codes


def test_sell_aggression_with_limited_downside_and_persistent_bid_depth_is_symmetric_candidate():
    service = DepthAggressorAlignmentService(config=config())
    for i, bid in enumerate(("12", "11.8", "11.6", "12.1", "12.2")):
        result = service.observe(
            symbol="BTCUSDT", flow=flow(t=NOW+i*1000, cvd=str(-i*400), delta="-100"),
            book_health=health(), book=book(t=NOW+i*1000, bid_depth=bid),
            observed_at_ms=NOW+i*1000,
        )
    assert result.status == "CANDIDATE"
    assert result.absorbed_aggressor == "SELL"
    assert result.cvd_change_quote == Decimal("-1600")


def test_candidate_can_use_observed_depth_replenishment_after_a_dip():
    service = DepthAggressorAlignmentService(config=config())
    for i, ask in enumerate(("10", "7", "8", "10", "10.2")):
        result = observe(service, NOW+i*1000, str(i*400), ask=ask)
    assert result.status == "CANDIDATE"
    assert result.opposing_depth_min_ratio == Decimal("0.7")
    assert result.opposing_depth_end_ratio >= Decimal("1")


def test_large_directional_price_progress_blocks_absorption_candidate():
    service = DepthAggressorAlignmentService(config=config())
    for i, mid in enumerate(("100.5", "100.6", "100.8", "101", "101.2")):
        result = observe(service, NOW+i*1000, str(i*400), mid=mid)
    assert result.status == "NO_CANDIDATE"
    assert "PRICE_PROGRESS_EXCEEDS_ABSORPTION_LIMIT" in result.reason_codes


def test_misaligned_latest_delta_and_cvd_change_do_not_form_candidate():
    service = DepthAggressorAlignmentService(config=config())
    for i in range(5):
        result = observe(service, NOW+i*1000, str(i*400), delta="-100" if i == 4 else "100")
    assert result.status == "NO_CANDIDATE"
    assert result.reason_codes == ("AGGRESSOR_FLOW_NOT_DIRECTIONALLY_ALIGNED",)


def test_invalid_flow_or_book_returns_unavailable_and_clears_window():
    service = DepthAggressorAlignmentService(config=config())
    observe(service, NOW, "0")
    result = service.observe(
        symbol="BTCUSDT", flow=flow(t=NOW+1000, cvd="400", fresh=False),
        book_health=health(), book=book(t=NOW+1000), observed_at_ms=NOW+1000,
    )
    assert result.status == "UNAVAILABLE"
    assert "DELTA_CVD_NOT_FRESH" in result.reason_codes
    assert len(service._windows["BTCUSDT"].samples) == 0


def test_supervisor_not_ready_blocks_evidence():
    service = DepthAggressorAlignmentService(config=config())
    result = service.observe(
        symbol="BTCUSDT", flow=flow(t=NOW, cvd="0"), book_health=health(ready=False),
        book=book(t=NOW), observed_at_ms=NOW,
    )
    assert result.status == "UNAVAILABLE"
    assert "ORDER_BOOK_NOT_READY" in result.reason_codes


def test_source_timestamp_skew_is_unavailable_and_resets_continuity():
    service = DepthAggressorAlignmentService(config=config())
    result = service.observe(
        symbol="BTCUSDT", flow=flow(t=NOW, cvd="0"), book_health=health(),
        book=book(t=NOW+5000), observed_at_ms=NOW+5000,
    )
    assert result.status == "UNAVAILABLE"
    assert result.reason_codes == ("SOURCE_TIMESTAMP_SKEW",)


def test_sample_gap_resets_window_and_restarts_warmup():
    service = DepthAggressorAlignmentService(config=config())
    observe(service, NOW, "0")
    result = observe(service, NOW+5000, "400")
    assert result.status == "WARMING_UP"
    assert result.sample_count == 1


def test_clock_regression_invalidates_and_requires_new_samples():
    service = DepthAggressorAlignmentService(config=config())
    observe(service, NOW+1000, "0")
    result = observe(service, NOW, "400")
    assert result.status == "UNAVAILABLE"
    assert result.reason_codes == ("CLOCK_REGRESSION_OR_DUPLICATE_SAMPLE",)


def test_manual_reset_clears_continuity():
    service = DepthAggressorAlignmentService(config=config())
    observe(service, NOW, "0")
    service.reset_symbol("BTCUSDT", "DEPTH_RECONNECTED")
    assert len(service._windows["BTCUSDT"].samples) == 0
    result = observe(service, NOW+1000, "400")
    assert result.status == "WARMING_UP"


def test_sample_count_is_bounded():
    service = DepthAggressorAlignmentService(config=config(max_samples_per_symbol=3))
    for i in range(6):
        result = observe(service, NOW+i*500, str(i*100))
    assert result.sample_count == 3


def test_symbol_mismatch_is_rejected():
    service = DepthAggressorAlignmentService(config=config())
    bad = flow(t=NOW, cvd="0")
    with pytest.raises(AbsorptionInputError, match="symbol mismatch"):
        service.observe(symbol="ETHUSDT", flow=bad, book_health=health(),
                        book=book(t=NOW), observed_at_ms=NOW)


def test_invalid_configuration_is_rejected():
    with pytest.raises(ValueError, match="min_window_ms"):
        AbsorptionConfig(window_ms=1000, min_window_ms=2000)


def test_health_and_metrics_must_reference_same_depth_update():
    service = DepthAggressorAlignmentService(config=config())
    mismatched = OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED", snapshot_state="READY",
        sequence_integrity=True, event_fresh=True, queue_healthy=True, ready=True,
        update_id=101, event_age_ms=0, queue_depth=0, queue_capacity=100,
        buffered_events=0, invalid_reason="NONE", last_error=None,
    )
    result = service.observe(
        symbol="BTCUSDT", flow=flow(t=NOW, cvd="0"), book_health=mismatched,
        book=book(t=NOW, update_id=100), observed_at_ms=NOW,
    )
    assert result.status == "UNAVAILABLE"
    assert "ORDER_BOOK_HEALTH_METRICS_MISMATCH" in result.reason_codes


def test_symbol_window_capacity_is_bounded():
    service = DepthAggressorAlignmentService(config=config(max_symbols=1))
    observe(service, NOW, "0")
    with pytest.raises(AbsorptionInputError, match="capacity exceeded"):
        service.observe(
            symbol="ETHUSDT", flow=flow(t=NOW, cvd="0"),
            book_health=OrderBookSymbolHealth(
                symbol="ETHUSDT", connection_state="CONNECTED", snapshot_state="READY",
                sequence_integrity=True, event_fresh=True, queue_healthy=True, ready=True,
                update_id=100, event_age_ms=0, queue_depth=0, queue_capacity=100,
                buffered_events=0, invalid_reason="NONE", last_error=None,
            ),
            book=OrderBookMetrics(
                symbol="ETHUSDT", update_id=100, best_bid=Decimal("100"),
                best_ask=Decimal("101"), spread=Decimal("1"), spread_bps=Decimal("99.5"),
                bid_depth=Decimal("10"), ask_depth=Decimal("10"), imbalance=Decimal("0"),
                level_count_bid=10, level_count_ask=10, synchronized=True,
                last_event_time_ms=NOW,
            ), observed_at_ms=NOW,
        )


def test_aggregate_trade_cursor_regression_resets_evidence():
    service = DepthAggressorAlignmentService(config=config())
    observe(service, NOW, "0")
    result = service.observe(
        symbol="BTCUSDT", flow=flow(t=NOW+1000, cvd="400", cursor=9),
        book_health=health(), book=book(t=NOW+1000), observed_at_ms=NOW+1000,
    )
    assert result.status == "UNAVAILABLE"
    assert result.reason_codes == ("AGGREGATE_TRADE_CURSOR_REGRESSION",)


def test_hard_resource_caps_cannot_be_raised():
    with pytest.raises(ValueError, match="max_symbols"):
        AbsorptionConfig(max_symbols=33)
    with pytest.raises(ValueError, match="max_samples_per_symbol"):
        AbsorptionConfig(max_samples_per_symbol=121)
