from __future__ import annotations

from dataclasses import FrozenInstanceError
from decimal import Decimal
import json

import pytest

from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.strategy import PineSmcReplayError, PineSmcStructureConfig, PineSmcStructureEngine

BASE_TIME_MS = 1_700_000_000_000


def _kline(
    index: int,
    *,
    open_price: str,
    high: str,
    low: str,
    close: str,
    volume: str = "10",
) -> Kline:
    interval = "1m"
    interval_ms = INTERVAL_MILLISECONDS[interval]
    base_time = BASE_TIME_MS // interval_ms * interval_ms
    open_time = base_time + index * interval_ms
    return Kline.from_binance_row(
        [
            open_time,
            open_price,
            high,
            low,
            close,
            volume,
            open_time + interval_ms - 1,
            "1000",
            25,
            "5",
            "500",
            "0",
        ],
        symbol="BTCUSDT",
        interval=interval,
        source_endpoint="/fapi/v1/klines",
    )


def _rising_candles(count: int) -> list[Kline]:
    return [
        _kline(
            index,
            open_price=str(100 + index),
            high=str(102 + index),
            low=str(100 + index),
            close=str(101 + index),
        )
        for index in range(count)
    ]


def _flat_candles(count: int) -> list[Kline]:
    return [
        _kline(index, open_price="100", high="101", low="99", close="100")
        for index in range(count)
    ]


def _config(**overrides: object) -> PineSmcStructureConfig:
    values: dict[str, object] = {
        "symbol": "BTCUSDT",
        "timeframe": "1m",
        "warmup_bars": 300,
        "swing_len": 2,
        "internal_len": 1,
    }
    values.update(overrides)
    return PineSmcStructureConfig(**values)  # type: ignore[arg-type]


def test_builtin_ta_first_valid_indices_and_rising_market_values() -> None:
    trace = PineSmcStructureEngine(_config()).replay(_rising_candles(35)).trace
    indicators = [bar.indicators for bar in trace]

    assert indicators[12].atr_fast_now is None
    assert indicators[13].atr_fast_now == pytest.approx(2.0)
    assert indicators[12].rsi_now is None
    assert indicators[13].rsi_now == pytest.approx(100.0)
    assert indicators[18].volume_avg_now is None
    assert indicators[19].volume_avg_now == pytest.approx(10.0)

    # DMI uses ta.tr (na on the first source bar) and 14 non-na DM/TR values.
    assert indicators[13].di_plus_now is None
    assert indicators[14].di_plus_now == pytest.approx(50.0)
    assert indicators[14].di_minus_now == pytest.approx(0.0)
    assert indicators[26].adx_now is None
    assert indicators[27].adx_now == pytest.approx(100.0)


def test_rsi_falling_run_seeds_at_bar_13_with_zero_value() -> None:
    candles = [
        _kline(
            index,
            open_price=str(102 - index),
            high=str(103 - index),
            low=str(101 - index),
            close=str(102 - index),
        )
        for index in range(20)
    ]
    trace = PineSmcStructureEngine(_config()).replay(candles).trace
    assert trace[12].indicators.rsi_now is None
    assert trace[13].indicators.rsi_now == pytest.approx(0.0)


def test_rsi_flat_zero_gain_and_zero_loss_remains_unavailable() -> None:
    trace = PineSmcStructureEngine(_config()).replay(_flat_candles(35)).trace
    indicators = [bar.indicators for bar in trace]

    # With both Wilder averages at zero, Pine's relative-strength division is 0/0.
    assert indicators[12].rsi_now is None
    assert indicators[13].rsi_now is None


def test_volume_sma_20_rolls_forward_after_initial_seed() -> None:
    candles = [
        _kline(
            index,
            open_price="100",
            high="101",
            low="99",
            close="100",
            volume=str(index + 1),
        )
        for index in range(22)
    ]
    trace = PineSmcStructureEngine(_config()).replay(candles).trace
    assert trace[18].indicators.volume_avg_now is None
    assert trace[19].indicators.volume_avg_now == pytest.approx(10.5)
    assert trace[20].indicators.volume_avg_now == pytest.approx(11.5)


def test_dmi_zero_directional_movement_yields_zero_di_and_adx_after_seed() -> None:
    trace = PineSmcStructureEngine(_config()).replay(_flat_candles(35)).trace
    indicators = [bar.indicators for bar in trace]

    assert indicators[14].di_plus_now == pytest.approx(0.0)
    assert indicators[14].di_minus_now == pytest.approx(0.0)
    assert indicators[27].adx_now == pytest.approx(0.0)


def test_builtin_ta_pre_roll_uses_prefix_before_smc_reset() -> None:
    candles = _rising_candles(320)
    result = PineSmcStructureEngine(_config(warmup_bars=300)).replay(candles)

    assert result.reset_start_index == 20
    assert result.trace[0].source_bar_index == 20
    # ATR14/RSI/SMA have already accumulated their full loaded-history prefix.
    assert result.trace[0].indicators.atr_fast_now == pytest.approx(2.0)
    assert result.trace[0].indicators.rsi_now == pytest.approx(100.0)
    assert result.trace[0].indicators.volume_avg_now == pytest.approx(10.0)
    # In contrast, SMC custom ATR200 was reset at the first processed bar.
    assert result.trace[0].local_index == 0
    assert result.trace[0].atr200 == pytest.approx(2.0)
    assert result.trace[0].indicators.atr200_ratio_base == 0.0
    assert result.trace[0].indicators.atr_ratio_now == pytest.approx(1.0)


def test_atr_ratio_uses_previous_bar_custom_atr200_not_current_update() -> None:
    candles = _rising_candles(20)
    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    assert trace[0].indicators.atr200_ratio_base == 0.0
    assert trace[0].indicators.atr_ratio_now == pytest.approx(1.0)
    assert trace[1].indicators.atr200_ratio_base == pytest.approx(trace[0].atr200)
    assert trace[1].indicators.atr_ratio_now is None  # ATR(14) has not seeded yet.
    assert trace[14].indicators.atr200_ratio_base == pytest.approx(trace[13].atr200)
    assert trace[14].indicators.atr_ratio_now == pytest.approx(
        trace[14].indicators.atr_fast_now / trace[13].atr200
    )


def test_volatility_regime_flags_follow_exact_input_thresholds_and_adx() -> None:
    trace = PineSmcStructureEngine(
        _config(extreme_vol_ratio=0.8, choppy_adx_max=16.0)
    ).replay(_flat_candles(35)).trace
    regime = trace[27].indicators

    assert regime.atr_ratio_now == pytest.approx(1.0)
    assert regime.adx_now == pytest.approx(0.0)
    assert regime.volatility_extreme is True
    assert regime.volatility_choppy is True

    disabled = PineSmcStructureEngine(
        _config(use_volatility_regime=False, extreme_vol_ratio=0.8)
    ).replay(_flat_candles(35)).trace[27].indicators
    assert disabled.volatility_extreme is False
    assert disabled.volatility_choppy is False


def test_regime_boundaries_are_strict_for_choppy_and_inclusive_for_extreme() -> None:
    candles = _flat_candles(35)
    at_low = PineSmcStructureEngine(
        _config(low_vol_ratio=1.0, extreme_vol_ratio=1.0)
    ).replay(candles).trace[27].indicators
    assert at_low.atr_ratio_now == pytest.approx(1.0)
    assert at_low.volatility_extreme is True  # >= extreme ratio
    assert at_low.volatility_choppy is False  # strictly > low ratio

    at_high = PineSmcStructureEngine(
        _config(high_vol_ratio=1.0, extreme_vol_ratio=1.0)
    ).replay(candles).trace[27].indicators
    assert at_high.volatility_choppy is False  # strictly < high ratio


def test_indicator_na_values_serialize_as_json_null_and_trace_is_immutable() -> None:
    result = PineSmcStructureEngine(_config()).replay(_rising_candles(5))
    first = result.trace[0]
    assert first.indicators.atr_fast_now is None
    assert first.indicators.rsi_now is None
    assert first.indicators.volume_avg_now is None

    encoded = result.to_jsonl().splitlines()[0]
    parsed = json.loads(encoded)
    assert parsed["indicators"]["atr_fast_now"] is None
    assert parsed["indicators"]["rsi_now"] is None
    assert parsed["indicators"]["volume_avg_now"] is None
    with pytest.raises(FrozenInstanceError):
        first.indicators.adx_now = 1.0  # type: ignore[misc]


def test_regime_config_matches_pine_input_ranges() -> None:
    defaults = _config()
    assert defaults.use_volatility_regime is True
    assert defaults.low_vol_ratio == pytest.approx(0.70)
    assert defaults.high_vol_ratio == pytest.approx(1.60)
    assert defaults.extreme_vol_ratio == pytest.approx(2.40)
    assert defaults.choppy_adx_max == pytest.approx(16.0)

    with pytest.raises(PineSmcReplayError, match="use_volatility_regime"):
        _config(use_volatility_regime=1)
    for field, values in {
        "low_vol_ratio": (0.09, 2.01, float("nan"), True),
        "high_vol_ratio": (0.49, 4.01, float("inf"), True),
        "extreme_vol_ratio": (0.79, 6.01, float("nan"), True),
        "choppy_adx_max": (4.99, 40.01, float("inf"), True),
    }.items():
        for value in values:
            with pytest.raises(PineSmcReplayError, match=field):
                _config(**{field: value})


def test_atr_uses_true_range_gap_to_previous_close_in_seed_window() -> None:
    candles = _flat_candles(13)
    candles.append(
        _kline(
            13,
            open_price="104",
            high="106",
            low="104",
            close="105",
        )
    )

    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    # Thirteen ranges are 2.0; the last bar's gap from previous close 100 to
    # high 106 expands true range to 6.0. ATR seed is their arithmetic mean.
    assert trace[13].indicators.atr_fast_now == pytest.approx(32.0 / 14.0)


def test_dmi_falling_directional_run_populates_minus_di_and_adx() -> None:
    candles = [
        _kline(
            index,
            open_price=str(102 - index),
            high=str(103 - index),
            low=str(101 - index),
            close=str(102 - index),
        )
        for index in range(30)
    ]

    trace = PineSmcStructureEngine(_config()).replay(candles).trace
    indicators = trace[14].indicators

    assert indicators.di_plus_now == pytest.approx(0.0)
    assert indicators.di_minus_now == pytest.approx(50.0)
    assert trace[27].indicators.adx_now == pytest.approx(100.0)


def test_dmi_equal_up_and_down_moves_produce_zero_directional_movement() -> None:
    candles = [
        _kline(
            index,
            open_price="100",
            high=str(101 + index),
            low=str(99 - index),
            close="100",
        )
        for index in range(30)
    ]

    trace = PineSmcStructureEngine(_config()).replay(candles).trace

    assert trace[14].indicators.di_plus_now == pytest.approx(0.0)
    assert trace[14].indicators.di_minus_now == pytest.approx(0.0)
    assert trace[27].indicators.adx_now == pytest.approx(0.0)
