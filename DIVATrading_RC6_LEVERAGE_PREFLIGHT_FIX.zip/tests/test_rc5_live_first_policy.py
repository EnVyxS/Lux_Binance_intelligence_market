"""No network/order tests: strict LIVE_FIRST operator opt-in and capital gates."""
from decimal import Decimal
import argparse
from pathlib import Path

import pytest

from divatrading.trading.commissioning import LiveFirstCommissioningCaps
from divatrading.trading.risk import PortfolioRiskConfig
from divatrading.execution.service import ExecutionMode, ExecutionConfig
from divatrading.cli import build_parser, command_autonomous_runtime


def test_live_first_caps_refuse_persisted_risk_override_and_fixed_risk():
    caps = LiveFirstCommissioningCaps()
    # Operator's 0.20 USDT bullet must not be subject to RC5's 0.10% hard cap.
    config = PortfolioRiskConfig(risk_per_trade_pct=Decimal("5"), max_portfolio_open_risk_pct=Decimal("21"),
                                 max_positions=1)
    assert caps.violation(config, equity_usdt=Decimal("100")) == "LIVE_FIRST_COMMISSIONING_PORTFOLIO_RISK_CAP_EXCEEDED"
    fixed = PortfolioRiskConfig(risk_per_trade_fixed_usdt=Decimal("0.20"), max_portfolio_open_risk_pct=Decimal("20"),
                                max_positions=1)
    assert caps.violation(fixed, equity_usdt=None) == "LIVE_FIRST_COMMISSIONING_FIXED_RISK_EQUITY_REQUIRED"
    assert caps.violation(fixed, equity_usdt=Decimal("1")) == "LIVE_FIRST_COMMISSIONING_FIXED_RISK_CAP_EXCEEDED"
    assert caps.violation(fixed, equity_usdt=Decimal("10")) is None
    ok = PortfolioRiskConfig(risk_per_trade_pct=Decimal("1"), max_portfolio_open_risk_pct=Decimal("20"),
                             max_positions=1)
    assert caps.violation(ok, equity_usdt=Decimal("10")) is None


def test_live_cannot_be_activated_only_by_mode_or_key():
    cfg = {
        "DIVA_EXECUTION_MODE":"LIVE", "DIVA_LIVE_TRADING_ENABLED":"true",
        "DIVA_LIVE_CONFIRMATION":"I_ACCEPT_REAL_MONEY_RISK",
        "DIVA_ENFORCE_ENTRY_QUOTE_GUARD":"true",
    }
    assert ExecutionConfig.from_env(cfg).mode == ExecutionMode.LIVE
    args = build_parser().parse_args(["auto-trade-runtime", "--mode", "MANUAL", "--symbols", "BTCUSDT", "--max-symbols", "1"])
    assert args.activate_live is False


def test_live_activation_requires_explicit_cli_and_manual_mode_before_network(tmp_path, monkeypatch, capsys):
    # Use the production configuration object but a client-free service: failures
    # must occur before private market-data calls or order endpoints are created.
    class FakeService:
        config = ExecutionConfig(mode=ExecutionMode.LIVE, enable_live_trading=True,
                                 live_confirmation="I_ACCEPT_REAL_MONEY_RISK",
                                 enforce_entry_quote_guard=True, enable_protection_recovery=True)
        client = None
    class FakeSettings:
        database_path = tmp_path / "test.sqlite"
    from divatrading import cli
    monkeypatch.setattr(cli, "_settings", lambda: FakeSettings())
    monkeypatch.setattr(cli, "validate_runtime", lambda: None)
    monkeypatch.setattr(cli, "_configure", lambda settings: __import__("logging").getLogger("rc5-test"))
    monkeypatch.setattr(cli.ExecutionService, "from_environment", lambda path: FakeService())
    args = build_parser().parse_args(["auto-trade-runtime", "--mode", "MANUAL", "--symbols", "BTCUSDT", "--max-symbols", "1"])
    assert command_autonomous_runtime(args) == 9
    assert "LIVE_FIRST_REQUIRES_EXPLICIT_--activate-live" in capsys.readouterr().err
    # AUTO universe is now a supported LIVE mode. Invalid manual worker count
    # and portfolio cap still fail before touching the exchange.
    args = build_parser().parse_args(["auto-trade-runtime", "--activate-live", "--mode", "MANUAL", "--symbols", "BTCUSDT,ETHUSDT", "--max-symbols", "1"])
    assert command_autonomous_runtime(args) == 9
    assert "LIVE_MANUAL_SYMBOL_COUNT_EXCEEDS_WORKER_CAP" in capsys.readouterr().err
    args = build_parser().parse_args(["auto-trade-runtime", "--activate-live", "--mode", "MANUAL", "--symbols", "BTCUSDT", "--max-symbols", "1", "--max-portfolio-risk-pct", "21"])
    assert command_autonomous_runtime(args) == 9
    assert "LIVE_PORTFOLIO_PERCENT_RISK_CAP_20" in capsys.readouterr().err
