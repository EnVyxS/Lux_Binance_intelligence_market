"""Regression evidence for corrections to SMC confirmation contracts."""
from __future__ import annotations
from dataclasses import replace
from decimal import Decimal
from types import SimpleNamespace

from divatrading.trading.signal_planner import SMCV2TradePlanner, SMCTradePlannerConfig
from test_smc_v2_trade_planner import CAPTURE_MS, _evidence


def _evaluate(evidence, *, model="CONFIRMATION_MARKET", **cfg):
    return SMCV2TradePlanner(config=SMCTradePlannerConfig(entry_model=model, min_candidate_score=50, **cfg)).evaluate(
        evidence, equity_usdt=Decimal("1000")
    ).evaluations[0]


def test_fresh_ob_without_touch_cannot_trigger_market_entry():
    result = _evaluate(_evidence())
    assert result.status == "REJECTED"
    assert "MARKET_RETEST_NOT_CONFIRMED" in result.reason_codes


def test_verified_retest_may_trigger_market_after_a_later_closed_candle():
    result = _evaluate(_evidence(include_retest=True))
    assert result.status == "PLANNED"
    assert result.signal and result.signal.entry_type == "MARKET"


def test_confirmation_on_retest_bar_is_rejected():
    ev = _evidence(include_retest=True)
    original_tf = ev.ob_lifecycle.timeframe("1m")
    rows = tuple(replace(row, first_touch_time_ms=CAPTURE_MS-1) for row in original_tf.order_blocks)
    ev = replace(ev, ob_lifecycle=SimpleNamespace(timeframe=lambda tf: SimpleNamespace(order_blocks=rows) if tf == "1m" else None))
    result = _evaluate(ev)
    assert result.status == "REJECTED"
    assert "CONFIRMATION_PRECEDES_OR_EQUALS_RETEST" in result.reason_codes


def test_market_mark_price_fractional_tick_uses_adverse_grid_reference():
    result = _evaluate(_evidence(include_retest=True, mark="50100.001"))
    assert result.status == "PLANNED"
    assert result.signal and result.signal.entry_price == Decimal("50100.10")


def test_qualification_does_not_consume_signal_before_durable_dispatch():
    planner = SMCV2TradePlanner(config=SMCTradePlannerConfig())
    a = planner.evaluate(_evidence(), equity_usdt=Decimal("1000"), qualification_only=True,
                         mark_qualified_emitted=False)
    b = planner.evaluate(_evidence(), equity_usdt=Decimal("1000"), qualification_only=True,
                         mark_qualified_emitted=False)
    assert a.evaluations[0].status == b.evaluations[0].status == "QUALIFIED"
    assert a.evaluations[0].signal.signal_id == b.evaluations[0].signal.signal_id


def test_full_mitigation_is_rejected_but_partial_retest_is_eligible():
    ev = _evidence(include_retest=True)
    rows = ev.ob_lifecycle.timeframe("1m").order_blocks
    replaced = replace(rows[0], status="MITIGATED", maximum_mitigation_depth_ratio=Decimal("0.35"))
    ev = replace(ev, ob_lifecycle=SimpleNamespace(timeframe=lambda tf: SimpleNamespace(order_blocks=(replaced,)) if tf == "1m" else None))
    assert _evaluate(ev).status == "PLANNED"
    full = replace(replaced, maximum_mitigation_depth_ratio=Decimal("1"))
    ev = replace(ev, ob_lifecycle=SimpleNamespace(timeframe=lambda tf: SimpleNamespace(order_blocks=(full,)) if tf == "1m" else None))
    assert "OB_FULLY_MITIGATED" in _evaluate(ev).reason_codes


def test_invalid_sweep_does_not_add_bonus_to_smc_score():
    from divatrading.strategy.scalping_liquidity_fvg import LiquiditySweepEvidence
    ev = _evidence()
    baseline = _evaluate(ev, model="LIMIT_RETRACEMENT").score
    ancient = LiquiditySweepEvidence(
        evidence_id="ancient", reference_id="wrong-zone", symbol="BTCUSDT", timeframe="1m",
        direction=1, reference_price=Decimal("1000"),
        bar_open_time_ms=CAPTURE_MS - 86_400_000,
        confirmation_time_ms=CAPTURE_MS - 86_399_000,
        wick_price=Decimal("900"), close_price=Decimal("1020"),
        wick_breach=True, close_through=False, close_back=True, qualifies_as_sweep=True,
    )
    ev = replace(ev, liquidity_fvg=SimpleNamespace(timeframe=lambda tf: SimpleNamespace(
        fvgs=(), sweeps=(ancient,)) if tf == "1m" else None))
    observed = _evaluate(ev, model="LIMIT_RETRACEMENT")
    assert observed.score == baseline
    assert "DIRECTIONAL_LIQUIDITY_SWEEP" not in observed.reason_codes


def _m5_retest_evidence(*, m1_ready=True, m1_open="50050", m1_close="50100", m1_close_time=None):
    ev = _evidence(include_retest=True)
    old = ev.ob_lifecycle.timeframe("1m").order_blocks[0]
    ob = replace(old.candidate, timeframe="5m")
    life = replace(old, candidate=ob)
    tf = ev.structure.timeframe("1m")
    event = replace(tf.events[0], timeframe="5m")
    m5 = SimpleNamespace(status="READY", events=(event,), pivots=(),
                         swing=SimpleNamespace(direction=1), internal=SimpleNamespace(direction=1))
    old_m15 = ev.structure.timeframe("15m")
    ev = replace(ev, structure=SimpleNamespace(timeframe=lambda name: {
        "5m": m5, "15m": old_m15,
    }.get(name)), ob_lifecycle=SimpleNamespace(timeframe=lambda name: SimpleNamespace(order_blocks=(life,)) if name == "5m" else None))
    m1 = SimpleNamespace(open=Decimal(m1_open), close=Decimal(m1_close),
                         close_time_ms=CAPTURE_MS-1 if m1_close_time is None else m1_close_time)
    m5_candle = SimpleNamespace(open=Decimal("50000"), close=Decimal("50100"),
                                close_time_ms=CAPTURE_MS - 1)
    view = ev.market_view
    view = SimpleNamespace(
        symbol=view.symbol, captured_at_ms=view.captured_at_ms,
        instrument=view.instrument, readiness=SimpleNamespace(m1_setup_ready=True, m5_setup_ready=True,
            m5_m1_confirmation_ready=m1_ready), mark_price=view.mark_price,
        kline=lambda name: SimpleNamespace(latest_closed_candle=m1 if name == "1m" else m5_candle)
            if name in {"1m", "5m"} else None,
        flow=None, order_book_metrics=None, absorption=None)
    return replace(ev, market_view=view)


def test_m5_market_requires_m1_closed_candle_readiness_and_rejection():
    missing = _evaluate(_m5_retest_evidence(m1_ready=False))
    assert "M5_M1_CONFIRMATION_NOT_READY" in missing.reason_codes
    bearish_m1 = _evaluate(_m5_retest_evidence(m1_open="50120", m1_close="50100"))
    assert "BULLISH_MARKET_CONFIRMATION_NOT_MET" in bearish_m1.reason_codes
    bullish_m1 = _evaluate(_m5_retest_evidence())
    assert bullish_m1.status == "PLANNED"
    assert "M5_SETUP_M1_ENTRY_CONFIRMATION" in bullish_m1.reason_codes


def test_m5_market_rejects_m1_confirmation_that_precedes_ob_touch():
    event = _evaluate(_m5_retest_evidence(m1_close_time=CAPTURE_MS - 120_000))
    assert event.status == "REJECTED"
    assert "CONFIRMATION_PRECEDES_OR_EQUALS_RETEST" in event.reason_codes
