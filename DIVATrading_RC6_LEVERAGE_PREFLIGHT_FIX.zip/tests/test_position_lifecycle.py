from decimal import Decimal as D
import pytest

from divatrading.execution.position_lifecycle import ManagedPositionState, PositionLifecycleEngine


def state(side="LONG", **changes):
    base = dict(signal_id="sig-1", symbol="BTCUSDT", side=side, quantity=D("1"),
                entry_price=D("100"), initial_stop=D("90") if side == "LONG" else D("110"),
                current_stop=D("90") if side == "LONG" else D("110"),
                initial_risk_per_unit=D("10"))
    base.update(changes)
    return ManagedPositionState(**base)


def test_partial_tp_at_one_r_long():
    result = PositionLifecycleEngine().evaluate(state(), D("110"))
    assert [a.kind for a in result.actions] == ["PARTIAL_TP"]
    assert result.actions[0].quantity == D("0.5")
    assert result.current_r == D("1")


def test_partial_tp_at_one_r_short():
    result = PositionLifecycleEngine().evaluate(state("SHORT"), D("90"))
    assert [a.kind for a in result.actions] == ["PARTIAL_TP"]


def test_no_partial_before_threshold():
    assert PositionLifecycleEngine().evaluate(state(), D("109.99")).actions == ()


def test_be_only_after_partial_fill_confirmed():
    s = state(partial_tp_done=True)
    result = PositionLifecycleEngine().evaluate(s, D("105"))
    assert len(result.actions) == 1
    assert result.actions[0].kind == "MOVE_STOP"
    assert result.actions[0].stop_price == D("100")


def test_trailing_long_uses_favorable_high_watermark():
    engine = PositionLifecycleEngine()
    first = engine.evaluate(state(), D("120"))
    assert first.proposed_state.favorable_extreme == D("120")
    second = engine.evaluate(first.proposed_state, D("115"))
    assert second.proposed_state.favorable_extreme == D("120")
    stop_actions = [a for a in second.actions if a.kind == "MOVE_STOP"]
    assert stop_actions[0].stop_price == D("110")


def test_trailing_short_uses_favorable_low_watermark():
    result = PositionLifecycleEngine().evaluate(state("SHORT"), D("80"))
    assert result.actions[0].kind == "PARTIAL_TP"
    assert result.actions[1].stop_price == D("90")


def test_be_and_trailing_emit_only_one_stop_update():
    s = state(partial_tp_done=True)
    result = PositionLifecycleEngine().evaluate(s, D("120"))
    stop_actions = [a for a in result.actions if a.kind == "MOVE_STOP"]
    assert len(stop_actions) == 1
    assert stop_actions[0].stop_price == D("110")


def test_closed_position_emits_nothing():
    result = PositionLifecycleEngine().evaluate(state(closed=True), D("130"))
    assert result.actions == ()


def test_mark_must_be_positive():
    with pytest.raises(ValueError):
        PositionLifecycleEngine().evaluate(state(), D("0"))


def test_nonfinite_mark_rejected():
    with pytest.raises(ValueError):
        PositionLifecycleEngine().evaluate(state(), "NaN")


def test_invalid_initial_risk_rejected():
    with pytest.raises(ValueError):
        state(initial_risk_per_unit=D("9"))


def test_invalid_partial_fraction_rejected():
    with pytest.raises(ValueError):
        state(partial_tp_fraction=D("1"))


def test_action_id_is_deterministic():
    engine = PositionLifecycleEngine()
    a = engine.evaluate(state(), D("110")).actions[0]
    b = engine.evaluate(state(), D("110")).actions[0]
    assert a.action_id == b.action_id


def test_trailing_stop_never_loosened_for_long():
    s = state(current_stop=D("112"))
    result = PositionLifecycleEngine().evaluate(s, D("120"))
    stop_actions = [a for a in result.actions if a.kind == "MOVE_STOP"]
    assert stop_actions == []


def test_trailing_stop_never_loosened_for_short():
    s = state("SHORT", current_stop=D("88"))
    result = PositionLifecycleEngine().evaluate(s, D("80"))
    stop_actions = [a for a in result.actions if a.kind == "MOVE_STOP"]
    assert stop_actions == []


def test_partial_quantity_uses_configured_fraction():
    s = state(quantity=D("2"), partial_tp_fraction=D("0.25"))
    result = PositionLifecycleEngine().evaluate(s, D("110"))
    assert result.actions[0].quantity == D("0.50")


def test_lifecycle_state_persists_and_uses_compare_and_swap(tmp_path):
    from divatrading.execution.ledger import ExecutionLedger
    ledger = ExecutionLedger(tmp_path / "ledger.db")
    ledger.claim_intent(signal_id="sig-1", symbol="BTCUSDT", side="LONG",
                        client_order_id="entry-1", payload={})
    snapshot = {"side": "LONG", "entry_price": "100", "partial_tp_done": False}
    version = ledger.save_position_management_state(signal_id="sig-1", symbol="BTCUSDT", state=snapshot)
    assert version == 1
    loaded = ledger.get_position_management_state("sig-1")
    assert loaded["state"] == snapshot
    assert ledger.save_position_management_state(signal_id="sig-1", symbol="BTCUSDT",
                                                  state={**snapshot, "partial_tp_done": True},
                                                  expected_version=1) == 2
    with pytest.raises(RuntimeError, match="VERSION_CONFLICT"):
        ledger.save_position_management_state(signal_id="sig-1", symbol="BTCUSDT",
                                               state=snapshot, expected_version=1)


def test_management_action_claim_is_idempotent(tmp_path):
    from divatrading.execution.ledger import ExecutionLedger
    ledger = ExecutionLedger(tmp_path / "ledger.db")
    ledger.claim_intent(signal_id="sig-1", symbol="BTCUSDT", side="LONG",
                        client_order_id="entry-1", payload={})
    args = dict(action_id="action-1", signal_id="sig-1", action_kind="PARTIAL_TP", payload={"qty": "0.5"})
    assert ledger.claim_position_management_action(**args) is True
    assert ledger.claim_position_management_action(**args) is False
    assert ledger.update_position_management_action(action_id="action-1", status="SUBMITTED") is True
