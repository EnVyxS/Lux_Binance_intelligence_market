import logging
from pathlib import Path

from divatrading.core.logging_setup import SecretRedactionFilter, configure_logging


def test_secret_filter_redacts_message() -> None:
    record = logging.LogRecord("test", logging.INFO, __file__, 1, "api=%s", ("abcd1234",), None)
    filter_ = SecretRedactionFilter(["abcd1234"])
    assert filter_.filter(record)
    assert "abcd1234" not in record.getMessage()
    assert "[REDACTED]" in record.getMessage()


def test_configure_logging_creates_log_file(tmp_path: Path) -> None:
    logger = configure_logging(tmp_path, "DEBUG", ["secret-token-123"])
    logger.info("foundation test")
    for handler in logger.handlers:
        handler.flush()
    assert (tmp_path / "divatrading.log").exists()
