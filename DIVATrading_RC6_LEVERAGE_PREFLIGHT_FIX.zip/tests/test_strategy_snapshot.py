from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
from decimal import Decimal

import pytest

from divatrading.market_data.absorption import AbsorptionEvidence
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.mark_price import MarkPriceEvent
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot
from divatrading.market_data.orchestrator import MarketDataReadiness
from divatrading.market_data.strategy_snapshot import (
    KlineSeriesInput,
    StrategyMarketDataAdapter,
    StrategyMarketDataConfig,
    StrategyMarketDataInputError,
)
from divatrading.market_data.websocket import MarketKlineEvent

NOW = 1_800_000_000_000


def make_kline(interval: str, open_time: int) -> Kline:
    interval_ms = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, "100", "102", "99", "101", "12.5", open_time + interval_ms - 1,
         "1250", 25, "7", "700", "0"],
        symbol="BTCUSDT", interval=interval, source_endpoint="https://test/klines",
    )


def series(interval: str, *, healthy=True, complete=True, candles=None, forming=None,
           observed=None) -> KlineSeriesInput:
    step = INTERVAL_MILLISECONDS[interval]
    latest_open = (NOW // step - 1) * step
    rows = candles if candles is not None else (make_kline(interval, latest_open - step), make_kline(interval, latest_open))
    return KlineSeriesInput(
        symbol="BTCUSDT", interval=interval, candles=rows,
        source_observed_at_ms=NOW - 100 if observed is None else observed,
        source_healthy=healthy, source_complete=complete, forming_event=forming,
    )


def flow(*, status="HEALTHY", fresh=True, time_ms=NOW - 300) -> OrderFlowSnapshot:
    return OrderFlowSnapshot(
        symbol="BTCUSDT", status=status, continuity_valid=status == "HEALTHY",
        is_fresh=fresh, data_age_ms=NOW-time_ms, baseline_aggregate_trade_id=1,
        last_processed_aggregate_trade_id=100, last_trade_time_ms=time_ms,
        cvd_base=Decimal("1"), cvd_quote=Decimal("100"), bucket_interval="1s",
        lookback_buckets=5, window_start_ms=NOW-5000, window_end_ms=NOW,
        buy_volume_base=Decimal("2"), sell_volume_base=Decimal("1"), delta_base=Decimal("1"),
        buy_volume_quote=Decimal("200"), sell_volume_quote=Decimal("100"), delta_quote=Decimal("100"),
        buy_imbalance_base=Decimal("0.33"), buy_imbalance_quote=Decimal("0.33"),
        trade_count=3, integrity_reason=None,
    )


def book_health(*, ready=True, update_id=123, age=300) -> OrderBookSymbolHealth:
    return OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED" if ready else "DISCONNECTED",
        snapshot_state="READY" if ready else "RESYNC_REQUIRED", sequence_integrity=ready,
        event_fresh=ready, queue_healthy=ready, ready=ready, update_id=update_id,
        event_age_ms=age, queue_depth=0, queue_capacity=100, buffered_events=0,
        invalid_reason="NONE" if ready else "NOT_READY", last_error=None,
    )


def book_metrics(*, update_id=123, time_ms=NOW-300) -> OrderBookMetrics:
    return OrderBookMetrics(
        symbol="BTCUSDT", update_id=update_id, best_bid=Decimal("100"), best_ask=Decimal("101"),
        spread=Decimal("1"), spread_bps=Decimal("99.5"), bid_depth=Decimal("10"),
        ask_depth=Decimal("12"), imbalance=Decimal("-0.09"), level_count_bid=20,
        level_count_ask=20, synchronized=True, last_event_time_ms=time_ms,
    )


def absorption(status="WARMING_UP") -> AbsorptionEvidence:
    return AbsorptionEvidence(
        symbol="BTCUSDT", status=status, absorbed_aggressor=None, reason_codes=(),
        window_start_ms=NOW-1000, window_end_ms=NOW-100, sample_count=2,
        window_duration_ms=900, aggressive_buy_quote=Decimal("10"),
        aggressive_sell_quote=Decimal("5"), latest_delta_quote=Decimal("5"),
        cvd_change_quote=Decimal("5"), price_progress_bps=Decimal("0.1"),
        start_mid=Decimal("100.5"), end_mid=Decimal("100.5"),
        start_opposing_depth=Decimal("10"), min_opposing_depth=Decimal("9"),
        end_opposing_depth=Decimal("10"), opposing_depth_min_ratio=Decimal("0.9"),
        opposing_depth_end_ratio=Decimal("1"), start_imbalance=Decimal("0"),
        end_imbalance=Decimal("0"), start_best_bid=Decimal("100"),
        end_best_bid=Decimal("100"), start_best_ask=Decimal("101"),
        end_best_ask=Decimal("101"), source_update_id=123,
    )


def readiness(*, flow_value=None, depth_ready=True, evidence_value=None, updated=NOW-100,
              ready=True) -> MarketDataReadiness:
    f = flow_value or flow()
    h = book_health(ready=depth_ready)
    e = evidence_value or absorption()
    return MarketDataReadiness(
        symbol="BTCUSDT", status="READY" if ready else "DEGRADED", ready=ready,
        reason_codes=() if ready else ("TEST_DEGRADED",), aggregate_trade_connected=True,
        aggregate_trade_continuity=True, delta_cvd_ready=f.status == "HEALTHY" and f.is_fresh,
        order_book_ready=depth_ready, queues_healthy=True,
        aggregate_trade_reconnect_generation=0, depth_reconnect_generation=0,
        aggregate_event_queue_depth=0, aggregate_event_queue_capacity=100,
        internal_queue_depth=0, internal_queue_capacity=100,
        order_book_health=h, flow=f, evidence_status=e.status, evidence=e, updated_at_ms=updated,
    )


def mark(*, time_ms=NOW-500, symbol="BTCUSDT") -> MarkPriceEvent:
    return MarkPriceEvent(
        symbol=symbol, mark_price=Decimal("100.5"), index_price=Decimal("100.4"),
        funding_rate=Decimal("0.0001"), next_funding_time_ms=NOW+3_600_000,
        event_time_ms=time_ms, estimated_settle_price=None, mark_price_moving_average=None,
        symbol_type=1, source_endpoint="wss://test", stream_name=f"{symbol.lower()}@markPrice@1s",
        received_at_utc=datetime.fromtimestamp(time_ms / 1000, tz=UTC),
    )


def build(**overrides):
    args = {
        "symbol": "BTCUSDT", "now_ms": NOW,
        "kline_series": tuple(series(i) for i in ("1m", "5m", "15m")),
        "mark_price": mark(), "mark_price_connected": True,
        "readiness": readiness(), "order_book_metrics": book_metrics(),
    }
    args.update(overrides)
    return StrategyMarketDataAdapter().build_snapshot(**args)


def test_builds_ready_immutable_snapshot_with_all_required_sources():
    snapshot = build()
    assert snapshot.ready is True
    assert snapshot.status == "READY"
    assert tuple(item.interval for item in snapshot.klines) == ("1m", "5m", "15m")
    assert snapshot.kline("5m").latest_closed_candle.interval == "5m"
    assert snapshot.component("ABSORPTION").status == "WARMING_UP"
    with pytest.raises(FrozenInstanceError):
        snapshot.ready = False


def test_missing_required_kline_interval_fails_closed():
    snapshot = build(kline_series=(series("1m"), series("5m")))
    assert not snapshot.ready
    assert "KLINE_INTERVAL_MISSING" in snapshot.reason_codes


def test_kline_gap_fails_closed():
    step = INTERVAL_MILLISECONDS["1m"]
    last_open = (NOW // step - 1) * step
    bad = series("1m", candles=(make_kline("1m", last_open - 2*step), make_kline("1m", last_open)))
    snapshot = build(kline_series=(bad, series("5m"), series("15m")))
    assert not snapshot.ready
    assert "KLINE_CANDLE_GAP" in snapshot.reason_codes


def test_kline_source_and_history_health_are_hard_gates():
    bad = series("1m", healthy=False, complete=False)
    snapshot = build(kline_series=(bad, series("5m"), series("15m")))
    assert not snapshot.ready
    assert "KLINE_SOURCE_UNHEALTHY" in snapshot.reason_codes
    assert "KLINE_HISTORY_INCOMPLETE" in snapshot.reason_codes


def test_stale_kline_source_fails_closed():
    bad = series("1m", observed=NOW-200_000)
    snapshot = build(kline_series=(bad, series("5m"), series("15m")))
    assert not snapshot.ready
    assert "KLINE_SOURCE_STALE" in snapshot.reason_codes


def test_current_open_candle_is_not_misrepresented_as_closed():
    step = INTERVAL_MILLISECONDS["1m"]
    current_open = (NOW // step) * step
    forming_kline = make_kline("1m", current_open)
    event = MarketKlineEvent(
        kline=forming_kline, event_time_ms=NOW-100, is_closed=False,
        stream_name="btcusdt@kline_1m", received_at_utc=datetime.fromtimestamp(NOW/1000, tz=UTC),
    )
    snapshot = build(kline_series=(series("1m", forming=event), series("5m"), series("15m")))
    one_minute = snapshot.kline("1m")
    assert one_minute.forming_candle is forming_kline
    assert all(c.close_time_ms < NOW for c in one_minute.candles)
    assert snapshot.ready


def test_forming_event_must_be_contiguous_with_closed_history():
    step = INTERVAL_MILLISECONDS["1m"]
    current_open = (NOW // step) * step + step
    event = MarketKlineEvent(
        kline=make_kline("1m", current_open), event_time_ms=NOW-100, is_closed=False,
        stream_name="btcusdt@kline_1m", received_at_utc=datetime.fromtimestamp(NOW/1000, tz=UTC),
    )
    snapshot = build(kline_series=(series("1m", forming=event), series("5m"), series("15m")))
    assert not snapshot.ready
    assert "KLINE_FORMING_EVENT_NOT_CONTIGUOUS" in snapshot.reason_codes


def test_mark_price_stale_or_disconnected_fails_closed():
    stale = build(mark_price=mark(time_ms=NOW-20_000))
    assert not stale.ready
    assert "MARK_PRICE_STALE" in stale.reason_codes
    disconnected = build(mark_price_connected=False)
    assert not disconnected.ready
    assert "MARK_PRICE_FEED_DISCONNECTED" in disconnected.reason_codes


def test_mark_price_symbol_mismatch_is_rejected():
    with pytest.raises(StrategyMarketDataInputError, match="Mark Price symbol"):
        build(mark_price=mark(symbol="ETHUSDT"))


def test_delta_cvd_stale_or_discontinuous_fails_closed():
    stale_flow = flow(time_ms=NOW-20_000)
    snap = build(readiness=readiness(flow_value=stale_flow))
    assert not snap.ready
    assert "DELTA_CVD_STALE" in snap.reason_codes
    discontinuous = flow(status="DEGRADED")
    snap2 = build(readiness=readiness(flow_value=discontinuous))
    assert not snap2.ready
    assert "DELTA_CVD_CONTINUITY_INVALID" in snap2.reason_codes


def test_depth_requires_matching_health_and_metrics_update_id():
    snapshot = build(order_book_metrics=book_metrics(update_id=124))
    assert not snapshot.ready
    assert "DEPTH_UPDATE_ID_MISMATCH" in snapshot.reason_codes


def test_depth_staleness_fails_closed():
    h = book_health(age=10_000)
    snapshot = build(readiness=readiness(), order_book_metrics=book_metrics(time_ms=NOW-10_000))
    # Depth age is checked against both the supervisor and metrics timestamps.
    assert not snapshot.ready
    assert "DEPTH_METRICS_STALE" in snapshot.reason_codes


def test_unavailable_absorption_fails_closed_but_no_candidate_is_valid():
    unavailable = absorption("UNAVAILABLE")
    snap = build(readiness=readiness(evidence_value=unavailable))
    assert not snap.ready
    assert snap.component("ABSORPTION").status == "UNAVAILABLE"
    no_candidate = build(readiness=readiness(evidence_value=absorption("NO_CANDIDATE")))
    assert no_candidate.ready


def test_orchestrator_readiness_staleness_and_degraded_state_fail_closed():
    stale = build(readiness=readiness(updated=NOW-5000))
    assert not stale.ready
    assert "ORCHESTRATOR_READINESS_STALE" in stale.reason_codes
    degraded = build(readiness=readiness(ready=False))
    assert not degraded.ready
    assert "ORCHESTRATOR_NOT_READY" in degraded.reason_codes


def test_wrong_kline_symbol_and_wrong_exchange_are_rejected():
    step = INTERVAL_MILLISECONDS["1m"]
    open_time = (NOW // step - 1) * step
    other = Kline.from_binance_row(
        [open_time, "100", "102", "99", "101", "12", open_time+step-1,
         "1200", 10, "6", "600", "0"],
        symbol="ETHUSDT", interval="1m", source_endpoint="test",
    )
    with pytest.raises(StrategyMarketDataInputError, match="Kline series symbol"):
        build(kline_series=(KlineSeriesInput("ETHUSDT", "1m", (other,), NOW-10), series("5m"), series("15m")))


def test_snapshot_bounds_candle_memory():
    config = StrategyMarketDataConfig(max_candles_per_interval=1)
    adapter = StrategyMarketDataAdapter(config=config)
    with pytest.raises(StrategyMarketDataInputError, match="candle count exceeds"):
        adapter.build_snapshot(
            symbol="BTCUSDT", now_ms=NOW,
            kline_series=(series("1m"), series("5m"), series("15m")),
            mark_price=mark(), mark_price_connected=True, readiness=readiness(),
            order_book_metrics=book_metrics(),
        )


def test_input_type_and_uppercase_symbol_contracts_are_enforced():
    with pytest.raises(StrategyMarketDataInputError, match="uppercase"):
        StrategyMarketDataAdapter().build_snapshot(
            symbol="btcusdt", now_ms=NOW, kline_series=(), mark_price=None,
            mark_price_connected=False, readiness=None, order_book_metrics=None,
        )
    with pytest.raises(StrategyMarketDataInputError, match="kline_series must contain"):
        build(kline_series=(object(),))


def test_snapshot_with_no_source_data_is_unavailable():
    snapshot = StrategyMarketDataAdapter().build_snapshot(
        symbol="BTCUSDT", now_ms=NOW, kline_series=(), mark_price=None,
        mark_price_connected=False, readiness=None, order_book_metrics=None,
    )
    assert snapshot.status == "UNAVAILABLE"
    assert not snapshot.ready


def test_absorption_evidence_must_match_current_depth_snapshot():
    evidence = absorption("NO_CANDIDATE")
    evidence = evidence.__class__(
        **{**{field: getattr(evidence, field) for field in evidence.__dataclass_fields__},
           "source_update_id": 999}
    )
    snapshot = build(readiness=readiness(evidence_value=evidence))
    assert not snapshot.ready
    assert "ABSORPTION_DEPTH_UPDATE_ID_MISMATCH" in snapshot.reason_codes


def test_absorption_evidence_staleness_fails_closed():
    evidence = absorption("NO_CANDIDATE")
    evidence = evidence.__class__(
        **{**{field: getattr(evidence, field) for field in evidence.__dataclass_fields__},
           "window_end_ms": NOW-20_000}
    )
    snapshot = build(readiness=readiness(evidence_value=evidence))
    assert not snapshot.ready
    assert "ABSORPTION_EVIDENCE_STALE" in snapshot.reason_codes


def test_strategy_adapter_is_exported_from_market_data_package():
    from divatrading.market_data import StrategyMarketDataAdapter as ExportedAdapter
    assert ExportedAdapter is StrategyMarketDataAdapter


def test_non_uppercase_series_symbol_is_normalized_at_input_boundary():
    values = series("1m")
    normalized = KlineSeriesInput(
        symbol=" btcusdt ", interval=values.interval, candles=values.candles,
        source_observed_at_ms=values.source_observed_at_ms,
    )
    assert normalized.symbol == "BTCUSDT"
