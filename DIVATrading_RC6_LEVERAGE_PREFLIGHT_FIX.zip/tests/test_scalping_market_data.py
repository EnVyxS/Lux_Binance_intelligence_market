from __future__ import annotations

import json
from datetime import UTC, datetime
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.absorption import AbsorptionEvidence
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.mark_price import MarkPriceEvent
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot
from divatrading.market_data.orchestrator import MarketDataReadiness
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.market_data.websocket import MarketKlineEvent
from divatrading.strategy.scalping_market_data import (
    InstrumentSpec,
    ScalpingMarketDataAdapter,
    ScalpingMarketDataConfig,
    ScalpingMarketDataInputError,
)

NOW = 1_800_000_000_000
FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def instrument(symbol: str = "BTCUSDT", **overrides) -> SymbolInfo:
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    row = next(item for item in payload["symbols"] if item["symbol"] == symbol)
    row = dict(row)
    row.update(overrides)
    return SymbolInfo.from_payload(row)


def make_kline(interval: str, open_time: int) -> Kline:
    interval_ms = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, "100", "102", "99", "101", "12.5", open_time + interval_ms - 1,
         "1250", 25, "7", "700", "0"],
        symbol="BTCUSDT", interval=interval, source_endpoint="https://test/klines",
    )


def series(interval: str, *, healthy=True, complete=True, candles=None, observed=None,
           forming=None) -> KlineSeriesInput:
    step = INTERVAL_MILLISECONDS[interval]
    latest_open = (NOW // step - 1) * step
    rows = candles if candles is not None else (
        make_kline(interval, latest_open - step), make_kline(interval, latest_open)
    )
    return KlineSeriesInput(
        symbol="BTCUSDT", interval=interval, candles=rows,
        source_observed_at_ms=NOW - 100 if observed is None else observed,
        source_healthy=healthy, source_complete=complete, forming_event=forming,
    )


def book_health(*, ready=True, update_id=123, age=300) -> OrderBookSymbolHealth:
    return OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED" if ready else "DISCONNECTED",
        snapshot_state="READY" if ready else "RESYNC_REQUIRED", sequence_integrity=ready,
        event_fresh=ready, queue_healthy=ready, ready=ready, update_id=update_id,
        event_age_ms=age, queue_depth=0, queue_capacity=100, buffered_events=0,
        invalid_reason="NONE" if ready else "NOT_READY", last_error=None,
    )


def book_metrics(*, update_id=123, time_ms=NOW - 300) -> OrderBookMetrics:
    return OrderBookMetrics(
        symbol="BTCUSDT", update_id=update_id, best_bid=Decimal("100"), best_ask=Decimal("100.1"),
        spread=Decimal("0.1"), spread_bps=Decimal("9.995"), bid_depth=Decimal("10"),
        ask_depth=Decimal("12"), imbalance=Decimal("-0.09"), level_count_bid=20,
        level_count_ask=20, synchronized=True, last_event_time_ms=time_ms,
    )


def flow(*, status="HEALTHY", fresh=True, time_ms=NOW - 300) -> OrderFlowSnapshot:
    return OrderFlowSnapshot(
        symbol="BTCUSDT", status=status, continuity_valid=status == "HEALTHY",
        is_fresh=fresh, data_age_ms=NOW - time_ms, baseline_aggregate_trade_id=1,
        last_processed_aggregate_trade_id=100, last_trade_time_ms=time_ms,
        cvd_base=Decimal("1"), cvd_quote=Decimal("100"), bucket_interval="1s",
        lookback_buckets=5, window_start_ms=NOW - 5000, window_end_ms=NOW,
        buy_volume_base=Decimal("2"), sell_volume_base=Decimal("1"), delta_base=Decimal("1"),
        buy_volume_quote=Decimal("200"), sell_volume_quote=Decimal("100"), delta_quote=Decimal("100"),
        buy_imbalance_base=Decimal("0.33"), buy_imbalance_quote=Decimal("0.33"),
        trade_count=3, integrity_reason=None,
    )


def absorption(status="WARMING_UP") -> AbsorptionEvidence:
    return AbsorptionEvidence(
        symbol="BTCUSDT", status=status, absorbed_aggressor=None, reason_codes=(),
        window_start_ms=NOW - 1000, window_end_ms=NOW - 100, sample_count=2,
        window_duration_ms=900, aggressive_buy_quote=Decimal("10"),
        aggressive_sell_quote=Decimal("5"), latest_delta_quote=Decimal("5"),
        cvd_change_quote=Decimal("5"), price_progress_bps=Decimal("0.1"),
        start_mid=Decimal("100.05"), end_mid=Decimal("100.05"),
        start_opposing_depth=Decimal("10"), min_opposing_depth=Decimal("9"),
        end_opposing_depth=Decimal("10"), opposing_depth_min_ratio=Decimal("0.9"),
        opposing_depth_end_ratio=Decimal("1"), start_imbalance=Decimal("0"),
        end_imbalance=Decimal("0"), start_best_bid=Decimal("100"),
        end_best_bid=Decimal("100"), start_best_ask=Decimal("100.1"),
        end_best_ask=Decimal("100.1"), source_update_id=123,
    )


def readiness(*, ready=True, flow_value=None, depth_ready=True, evidence_value=None,
              delta_ready=True, updated=NOW - 100) -> MarketDataReadiness:
    f = flow_value or flow()
    h = book_health(ready=depth_ready)
    e = evidence_value or absorption()
    return MarketDataReadiness(
        symbol="BTCUSDT", status="READY" if ready else "DEGRADED", ready=ready,
        reason_codes=() if ready else ("OPTIONAL_COMPONENT_DEGRADED",),
        aggregate_trade_connected=True, aggregate_trade_continuity=True,
        delta_cvd_ready=delta_ready, order_book_ready=depth_ready, queues_healthy=True,
        aggregate_trade_reconnect_generation=0, depth_reconnect_generation=0,
        aggregate_event_queue_depth=0, aggregate_event_queue_capacity=100,
        internal_queue_depth=0, internal_queue_capacity=100, order_book_health=h,
        flow=f, evidence_status=e.status, evidence=e, updated_at_ms=updated,
    )


def mark(*, time_ms=NOW - 500) -> MarkPriceEvent:
    return MarkPriceEvent(
        symbol="BTCUSDT", mark_price=Decimal("100.05"), index_price=Decimal("100.04"),
        funding_rate=Decimal("0.0001"), next_funding_time_ms=NOW + 3_600_000,
        event_time_ms=time_ms, estimated_settle_price=None, mark_price_moving_average=None,
        symbol_type=1, source_endpoint="wss://test", stream_name="btcusdt@markPrice@1s",
        received_at_utc=datetime.fromtimestamp(time_ms / 1000, tz=UTC),
    )


def build_view(*, candles=("1m", "5m"), symbol_info=None, optional_data=False,
               readiness_value=None, overrides=None):
    items = tuple(series(interval) for interval in candles)
    args = {
        "symbol": "BTCUSDT", "now_ms": NOW,
        "symbol_info": symbol_info or instrument(),
        "kline_series": items,
        "mark_price": mark() if optional_data else None,
        "mark_price_connected": optional_data,
        "readiness": readiness_value if readiness_value is not None else (readiness() if optional_data else None),
        "order_book_metrics": book_metrics() if optional_data else None,
    }
    if overrides:
        args.update(overrides)
    return ScalpingMarketDataAdapter().build_view(**args)


def test_instrument_spec_uses_exact_price_filter_tick_and_lot_steps():
    spec = InstrumentSpec.from_symbol_info(instrument())
    assert spec.tick_size == Decimal("0.10")
    assert spec.lot_step_size == Decimal("0.001")
    assert spec.market_lot_step_size == Decimal("0.001")
    assert spec.price_grid_ready
    assert spec.quantity_grid_ready
    assert spec.is_price_on_tick(Decimal("100.10"))
    assert not spec.is_price_on_tick(Decimal("100.15"))
    with pytest.raises(ScalpingMarketDataInputError, match="not aligned"):
        spec.require_price_on_tick(Decimal("100.15"))


def test_missing_price_filter_never_falls_back_to_price_precision():
    row = {
        "symbol": "BTCUSDT", "contractType": "PERPETUAL", "status": "TRADING",
        "baseAsset": "BTC", "quoteAsset": "USDT", "marginAsset": "USDT",
        "pricePrecision": 2, "quantityPrecision": 3, "filters": [],
    }
    spec = InstrumentSpec.from_symbol_info(SymbolInfo.from_payload(row))
    assert spec.tick_size is None
    assert not spec.price_grid_ready
    assert not spec.is_price_on_tick(Decimal("100.00"))


def test_non_usdt_contract_or_non_trading_symbol_is_not_price_grid_ready():
    spec = InstrumentSpec.from_symbol_info(instrument(status="SETTLING"))
    assert not spec.is_trading
    assert not spec.price_grid_ready
    row = instrument().raw_symbol
    row["marginAsset"] = "BTC"
    assert not InstrumentSpec.from_symbol_info(SymbolInfo.from_payload(row)).is_usdt_perpetual


def test_m1_m5_are_required_setup_sources_but_m15_and_confluence_are_optional():
    view = build_view()
    assert view.status == "READY"
    assert view.readiness.can_scan_setups
    assert view.readiness.m1_setup_ready and view.readiness.m5_setup_ready
    assert not view.readiness.m15_context_available
    assert not view.readiness.delta_cvd_available
    assert not view.readiness.depth_confluence_available
    assert not view.readiness.absorption_available
    assert not view.readiness.entry_quote_ready
    assert view.component("KLINE_M15").status == "UNAVAILABLE"
    assert view.component("DELTA_CVD").status == "UNAVAILABLE"


def test_missing_m1_keeps_m5_setup_available_but_disables_m1_confirmation():
    view = build_view(candles=("5m",))
    assert view.status == "READY"
    assert not view.readiness.m1_setup_ready
    assert view.readiness.m5_setup_ready
    assert not view.readiness.m5_m1_confirmation_ready
    assert view.readiness.can_scan_setups


def test_missing_m5_keeps_independent_m1_scalp_setup_available():
    view = build_view(candles=("1m",))
    assert view.status == "READY"
    assert view.readiness.m1_setup_ready
    assert not view.readiness.m5_setup_ready
    assert view.readiness.can_scan_setups


def test_m1_gap_does_not_veto_valid_m5_setup():
    step = INTERVAL_MILLISECONDS["1m"]
    last_open = (NOW // step - 1) * step
    bad_m1 = series("1m", candles=(make_kline("1m", last_open - 2 * step), make_kline("1m", last_open)))
    view = build_view(overrides={"kline_series": (bad_m1, series("5m"))})
    assert not view.readiness.m1_setup_ready
    assert view.readiness.m5_setup_ready
    assert view.status == "READY"
    assert "KLINE_CANDLE_GAP" in view.component("KLINE_M1").reason_codes


def test_m15_staleness_is_context_only_and_does_not_veto_setup():
    view = build_view(overrides={
        "kline_series": (series("1m"), series("5m"), series("15m", observed=NOW - 2_000_000))
    })
    assert view.status == "READY"
    assert not view.readiness.m15_context_available
    assert view.readiness.m1_setup_ready and view.readiness.m5_setup_ready
    assert "KLINE_SOURCE_STALE" in view.component("KLINE_M15").reason_codes


def test_missing_tick_size_blocks_setup_even_when_candles_are_valid():
    row = dict(instrument().raw_symbol)
    row["filters"] = [f for f in row["filters"] if f["filterType"] != "PRICE_FILTER"]
    no_tick = SymbolInfo.from_payload(row)
    view = build_view(symbol_info=no_tick)
    assert view.status == "DEGRADED"
    assert not view.readiness.instrument_price_grid_ready
    assert not view.readiness.can_scan_setups
    assert "PRICE_FILTER_TICK_SIZE_MISSING" in view.reason_codes


def test_wrong_symbol_metadata_is_rejected():
    with pytest.raises(ScalpingMarketDataInputError, match="metadata symbol"):
        build_view(symbol_info=instrument("ETHUSDT"))


def test_optional_cvd_degradation_does_not_disable_healthy_depth_quote():
    degraded_flow = flow(status="DEGRADED", fresh=False)
    state = readiness(
        ready=False, flow_value=degraded_flow, delta_ready=False,
        evidence_value=absorption("UNAVAILABLE"),
    )
    view = build_view(optional_data=True, readiness_value=state)
    assert view.status == "READY"
    assert view.readiness.m1_setup_ready and view.readiness.m5_setup_ready
    assert not view.readiness.delta_cvd_available
    assert not view.readiness.absorption_available
    assert view.readiness.entry_quote_ready


def test_depth_update_id_mismatch_disables_entry_quote_not_structure_setup():
    state = readiness()
    view = build_view(optional_data=True, readiness_value=state,
                      overrides={"order_book_metrics": book_metrics(update_id=124)})
    assert view.status == "READY"
    assert view.readiness.m1_setup_ready and view.readiness.m5_setup_ready
    assert not view.readiness.entry_quote_ready
    assert "DEPTH_UPDATE_ID_MISMATCH" in view.component("DEPTH").reason_codes


def test_instrument_spec_rejects_non_finite_or_zero_tick():
    info = instrument()
    bad_filter = replace(info.price_filter, tick_size=Decimal("0"))
    bad_info = replace(info, price_filter=bad_filter)
    with pytest.raises(ScalpingMarketDataInputError, match="tick_size"):
        InstrumentSpec.from_symbol_info(bad_info)


def test_scalping_config_limits_history_and_freshness_bounds():
    with pytest.raises(ValueError):
        ScalpingMarketDataConfig(max_candles_per_interval=2001)
    with pytest.raises(ValueError):
        ScalpingMarketDataConfig(max_depth_age_ms=0)


def test_kline_prices_off_exact_tick_grid_block_only_that_timeframe():
    one_minute = series("1m")
    malformed_latest = replace(one_minute.candles[-1], close=Decimal("101.05"))
    bad_m1 = replace(one_minute, candles=one_minute.candles[:-1] + (malformed_latest,))
    view = build_view(overrides={"kline_series": (bad_m1, series("5m"))})
    assert not view.readiness.m1_setup_ready
    assert view.readiness.m5_setup_ready
    assert "KLINE_PRICE_OFF_TICK_GRID" in view.component("KLINE_M1").reason_codes


def test_depth_quote_must_match_exact_tick_grid_for_entry_readiness():
    state = readiness()
    off_grid = replace(book_metrics(), best_ask=Decimal("100.15"), spread=Decimal("0.15"))
    view = build_view(optional_data=True, readiness_value=state, overrides={"order_book_metrics": off_grid})
    assert view.status == "READY"
    assert view.readiness.m5_setup_ready
    assert not view.readiness.entry_quote_ready
    assert "DEPTH_QUOTE_OFF_TICK_GRID" in view.component("DEPTH").reason_codes


def test_orchestrator_order_book_gate_is_respected_independently_of_global_ready():
    state = readiness(ready=False)
    state = replace(state, order_book_ready=False)
    view = build_view(optional_data=True, readiness_value=state)
    assert view.status == "READY"
    assert view.readiness.m1_setup_ready and view.readiness.m5_setup_ready
    assert not view.readiness.entry_quote_ready
    assert "DEPTH_ORCHESTRATOR_GATE_CLOSED" in view.component("DEPTH").reason_codes


def test_missing_tick_size_disables_entry_quote_readiness_even_with_ready_depth():
    row = dict(instrument().raw_symbol)
    row["filters"] = [f for f in row["filters"] if f["filterType"] != "PRICE_FILTER"]
    no_tick = SymbolInfo.from_payload(row)
    view = build_view(symbol_info=no_tick, optional_data=True)
    assert not view.readiness.instrument_price_grid_ready
    assert not view.readiness.entry_quote_ready
    assert "DEPTH_TICK_SIZE_UNAVAILABLE" in view.component("DEPTH").reason_codes


def test_absorption_warming_status_is_preserved_without_becoming_a_hard_gate():
    view = build_view(optional_data=True)
    assert view.readiness.absorption_available
    assert view.component("ABSORPTION").status == "WARMING_UP"
    assert view.readiness.can_scan_setups
