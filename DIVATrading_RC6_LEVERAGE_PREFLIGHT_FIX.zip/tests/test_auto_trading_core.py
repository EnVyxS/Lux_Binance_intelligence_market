from __future__ import annotations

from dataclasses import replace
import hashlib
import hmac
import json
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.execution.binance_private import BinancePrivateRestClient, TESTNET_BASE_URL
from divatrading.execution.ledger import ExecutionLedger
from divatrading.execution.service import ExecutionConfig, ExecutionMode, ExecutionService
from divatrading.trading.models import QualifiedSignal, TradePlan
from divatrading.trading.risk import PortfolioRiskConfig, PortfolioRiskManager
from divatrading.trading.universe import SymbolUniverseConfig, SymbolUniverseSelector
from divatrading.trading.coordinator import MultiPairExecutionCoordinator, PortfolioSnapshot
from divatrading.strategy.scalping_market_data import InstrumentSpec

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def _snapshot():
    return parse_exchange_info(json.loads(FIXTURE.read_text()), source_endpoint="fixture")


def _signal(signal_id="sig-001"):
    return QualifiedSignal(
        signal_id=signal_id, symbol="BTCUSDT", side="LONG", entry_type="LIMIT",
        entry_price=Decimal("50000.00"), stop_loss=Decimal("49900.00"),
        take_profit=Decimal("50300.00"), timeframe="5m", strategy_id="SMC_V2",
        created_at_ms=1794400000000, reason_codes=("STRUCTURE_CONFIRMED", "OB_ACTIVE"),
    )


def _plan(signal=None):
    s = signal or _signal()
    return TradePlan(s, Decimal("0.100"), Decimal("5000.00"), Decimal("10.00"),
                     Decimal("1666.6666666667"), 3, "DIVATESTENTRY0000000000000000")


def test_auto_universe_selects_liquid_active_usdt_perpetuals():
    snapshot = _snapshot()
    selection = SymbolUniverseSelector(SymbolUniverseConfig(
        mode="AUTO", max_active_symbols=2,
        min_quote_volume_usdt=Decimal("1000000"), min_trade_count_24h=100,
    )).select(snapshot, [
        {"symbol": "BTCUSDT", "quoteVolume": "9000000", "count": 10000},
        {"symbol": "ETHUSDT", "quoteVolume": "5000000", "count": 9000},
        {"symbol": "OLDUSDT", "quoteVolume": "99999999", "count": 100000},
    ])
    assert selection.symbols == ("BTCUSDT", "ETHUSDT")
    assert selection.selected[0].rank == 1
    assert ("OLDUSDT", "NOT_ACTIVE_USDT_PERPETUAL") in selection.rejected


def test_manual_universe_rejects_unknown_and_excluded_symbols():
    selector = SymbolUniverseSelector(SymbolUniverseConfig(
        mode="MANUAL", manual_symbols=("BTCUSDT", "NOPEUSDT"), exclude_symbols=("BTCUSDT",),
    ))
    with pytest.raises(ValueError, match="No eligible symbols"):
        selector.select(_snapshot(), [{"symbol": "BTCUSDT", "quoteVolume": "1", "count": 1}])


def test_risk_manager_sizes_and_respects_portfolio_caps():
    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = InstrumentSpec.from_symbol_info(info)
    decision = PortfolioRiskManager(PortfolioRiskConfig()).size_signal(
        _signal(), instrument, equity_usdt=Decimal("10000"),
        open_risk_usdt=Decimal("20"), active_position_count=1,
        client_order_id="DIVA001",
    )
    assert decision.accepted
    assert decision.plan is not None
    assert decision.plan.quantity == Decimal("0.12")
    assert decision.plan.risk_usdt == Decimal("12.00")
    blocked = PortfolioRiskManager().size_signal(
        _signal("sig-002"), instrument, equity_usdt=Decimal("10000"),
        open_risk_usdt=Decimal("100"), client_order_id="DIVA002",
    )
    assert not blocked.accepted
    assert blocked.reason == "PORTFOLIO_RISK_BUDGET_EXHAUSTED"


def test_ioc_risk_needs_enabled_orders_and_a_protectable_partial_quantity():
    instrument = InstrumentSpec.from_symbol_info(_snapshot().get_symbol("BTCUSDT"))
    signal = replace(_signal(), entry_type="LIMIT_IOC", take_profit=Decimal("51000.00"))

    def size(spec, candidate=signal):
        return PortfolioRiskManager().size_signal(
            candidate, spec, equity_usdt=Decimal("10000"), client_order_id="ioc-risk",
        )

    assert size(instrument).reason == "IOC_ENTRY_OR_PROTECTION_NOT_ENABLED"
    instrument = replace(instrument, order_types=(*instrument.order_types, "TAKE_PROFIT_MARKET"))
    assert "IOC" in instrument.time_in_force
    assert size(replace(instrument, market_lot_step_size=Decimal("0.002"))).reason == (
        "IOC_PARTIAL_FILL_EXIT_GRID_INCOMPATIBLE"
    )
    sized = size(instrument)
    assert sized.accepted and sized.plan.fee_reserve_usdt > 0
    assert sized.plan.notional_usdt == sized.plan.quantity * signal.entry_price
    narrow = replace(signal, take_profit=Decimal("50200.00"), minimum_net_rr=Decimal("2"))
    assert size(instrument, narrow).reason == "IOC_REWARD_RISK_BELOW_MINIMUM_AFTER_COSTS"




def test_account_specific_fee_and_margin_inputs_reduce_quantity_and_respect_risk_budget():
    from divatrading.trading.exchange_feasibility import SymbolCommission, SymbolRiskInputs, parse_leverage_brackets
    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = InstrumentSpec.from_symbol_info(info)
    brackets = parse_leverage_brackets([{"symbol": "BTCUSDT", "brackets": [
        {"bracket": 1, "initialLeverage": 50, "notionalFloor": "0", "notionalCap": "10000000",
         "maintMarginRatio": "0.004", "cum": "0"},
    ]}], "BTCUSDT")
    inputs = SymbolRiskInputs("BTCUSDT", brackets, SymbolCommission(Decimal("0.0002"), Decimal("0.0005")), 1794400000000)
    decision = PortfolioRiskManager(PortfolioRiskConfig(
        risk_per_trade_pct=Decimal("1"), max_portfolio_open_risk_pct=Decimal("2"),
        max_leverage=20, slippage_reserve_bps=Decimal("5"), funding_reserve_bps=Decimal("10"),
    )).size_signal(_signal("fee-aware-size"), instrument,
        equity_usdt=Decimal("10000"), available_margin_usdt=Decimal("10000"),
        symbol_risk_inputs=inputs, client_order_id="DIVA-FEE-AWARE")
    assert decision.accepted and decision.plan is not None
    assert decision.plan.fee_reserve_usdt > 0
    assert decision.plan.slippage_reserve_usdt > 0
    assert decision.plan.funding_reserve_usdt > 0
    assert decision.plan.risk_usdt <= Decimal("100")
    assert decision.plan.leverage <= 20


def test_account_specific_sizing_never_inflates_quantity_for_minimum_notional():
    from dataclasses import replace
    from divatrading.trading.exchange_feasibility import SymbolCommission, SymbolRiskInputs, parse_leverage_brackets
    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = replace(InstrumentSpec.from_symbol_info(info), min_notional=Decimal("100000"))
    brackets = parse_leverage_brackets([{"symbol": "BTCUSDT", "brackets": [
        {"bracket": 1, "initialLeverage": 50, "notionalFloor": "0", "notionalCap": "10000000",
         "maintMarginRatio": "0.004", "cum": "0"},
    ]}], "BTCUSDT")
    inputs = SymbolRiskInputs("BTCUSDT", brackets, SymbolCommission(Decimal("0"), Decimal("0.0005")), 1794400000000)
    decision = PortfolioRiskManager(PortfolioRiskConfig(
        risk_per_trade_pct=Decimal("0.1"), max_portfolio_open_risk_pct=Decimal("1"), max_leverage=20,
    )).size_signal(_signal("min-notional-not-inflated"), instrument,
        equity_usdt=Decimal("10000"), available_margin_usdt=Decimal("10000"),
        symbol_risk_inputs=inputs, client_order_id="DIVA-MIN-NOTIONAL")
    assert not decision.accepted
    assert decision.reason.startswith("NOTIONAL_BELOW_EXCHANGE_MINIMUM")


def test_ledger_claim_is_idempotent_across_instances(tmp_path: Path):
    path = tmp_path / "exec.sqlite"
    first = ExecutionLedger(path)
    assert first.claim_intent(signal_id="s1", symbol="BTCUSDT", side="LONG",
                              client_order_id="DIVA1", payload={"n": 1})
    second = ExecutionLedger(path)
    assert not second.claim_intent(signal_id="s1", symbol="BTCUSDT", side="LONG",
                                   client_order_id="DIVA1", payload={"n": 1})
    first.update_intent("s1", "PAPER_ACCEPTED")
    assert second.get_intent("s1")["status"] == "PAPER_ACCEPTED"


def test_paper_execution_records_intent_but_never_calls_exchange(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "ledger.sqlite")
    service = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    result = service.submit(_plan())
    assert result.status == "PAPER_ACCEPTED"
    assert result.entry_order is None
    duplicate = service.submit(_plan())
    assert duplicate.duplicate
    assert duplicate.status == "PAPER_ACCEPTED"


def test_live_mode_is_fail_closed_without_double_confirmation():
    with pytest.raises(ValueError, match="enable_live_trading"):
        ExecutionConfig(mode=ExecutionMode.LIVE)
    with pytest.raises(ValueError, match="live_confirmation"):
        ExecutionConfig(mode=ExecutionMode.LIVE, enable_live_trading=True)


def test_signed_client_signs_post_and_does_not_retry(tmp_path: Path):
    seen = []
    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json={"orderId": 321, "status": "NEW"})
    http = httpx.Client(transport=httpx.MockTransport(handler))
    client = BinancePrivateRestClient("api-key", "secret-key", environment="TESTNET", http_client=http,
                                      wall_clock_ms=lambda: 1234567890000)
    response = client.new_order(symbol="BTCUSDT", side="BUY", type="MARKET", quantity=Decimal("0.01"))
    assert response["orderId"] == 321
    assert len(seen) == 1
    req = seen[0]
    assert req.url.host == "demo-fapi.binance.com"
    assert req.headers["X-MBX-APIKEY"] == "api-key"
    query = parse_qs(req.url.query.decode())
    assert query["timestamp"] == ["1234567890000"]
    signed_payload = req.url.query.decode().rsplit("&signature=", 1)[0]
    expected = hmac.new(b"secret-key", signed_payload.encode(), hashlib.sha256).hexdigest()
    assert query["signature"] == [expected]
    client.close()


def test_multi_pair_coordinator_routes_approved_signal_through_one_global_risk_manager(tmp_path: Path):
    snapshot = _snapshot()
    btc = snapshot.get_symbol("BTCUSDT")
    eth = snapshot.get_symbol("ETHUSDT")
    assert btc is not None and eth is not None
    instruments = {"BTCUSDT": InstrumentSpec.from_symbol_info(btc),
                   "ETHUSDT": InstrumentSpec.from_symbol_info(eth)}
    ledger = ExecutionLedger(tmp_path / "multi-pair.sqlite")
    execution = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    coordinator = MultiPairExecutionCoordinator(
        instruments=instruments, risk_manager=PortfolioRiskManager(),
        execution_service=execution, ledger=ledger,
    )
    portfolio = PortfolioSnapshot(
        equity_usdt=Decimal("10000"), open_risk_usdt=Decimal("0"),
        active_position_count=0, symbol_notional_usdt={}, captured_at_ms=1794400000000,
    )
    accepted = coordinator.route(_signal("multi-pair-signal"), portfolio)
    assert accepted.risk.accepted
    assert accepted.execution is not None and accepted.execution.status == "PAPER_ACCEPTED"
    # PAPER records the route but does not hold a live portfolio-risk reservation.
    assert ledger.active_reserved_risk_usdt() == Decimal("0")
    rejected = coordinator.route(
        QualifiedSignal("unknown-pair", "XRPUSDT", "LONG", "LIMIT", Decimal("1.00"),
                        Decimal("0.99"), Decimal("1.03"), "5m", "SMC_V2", 1794400000000),
        portfolio,
    )
    assert not rejected.risk.accepted
    assert rejected.risk.reason == "SYMBOL_NOT_IN_ACTIVE_UNIVERSE"


def test_execution_config_env_keeps_paper_as_safe_default():
    config = ExecutionConfig.from_env({})
    assert config.mode == ExecutionMode.PAPER
    assert config.enable_live_trading is False


def test_execution_service_factory_builds_paper_without_credentials(tmp_path: Path):
    service = ExecutionService.from_environment(tmp_path / "factory.sqlite", environ={})
    assert service.config.mode == ExecutionMode.PAPER
    assert service.client is None


def test_risk_manager_caps_quantity_to_exchange_maximum_notional():
    from dataclasses import replace

    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = replace(InstrumentSpec.from_symbol_info(info), max_notional=Decimal("100"))
    decision = PortfolioRiskManager().size_signal(
        _signal("max-notional-cap"), instrument, equity_usdt=Decimal("10000"),
        client_order_id="DIVA-MAX-NOTIONAL",
    )
    assert decision.accepted and decision.plan is not None
    assert decision.plan.notional_usdt <= Decimal("100")


def test_risk_manager_fails_closed_when_selected_quantity_filter_is_incomplete():
    from dataclasses import replace

    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = replace(InstrumentSpec.from_symbol_info(info), lot_step_size=None)
    decision = PortfolioRiskManager().size_signal(
        _signal("missing-lot-size"), instrument, equity_usdt=Decimal("10000"),
        client_order_id="DIVA-MISSING-LOT",
    )
    assert not decision.accepted
    assert decision.reason == "QUANTITY_FILTER_INCOMPLETE"


def test_risk_manager_fails_closed_when_minimum_notional_is_missing():
    from dataclasses import replace

    info = _snapshot().get_symbol("BTCUSDT")
    assert info is not None
    instrument = replace(InstrumentSpec.from_symbol_info(info), min_notional=None)
    decision = PortfolioRiskManager().size_signal(
        _signal("missing-min-notional"), instrument, equity_usdt=Decimal("10000"),
        client_order_id="DIVA-MISSING-NOTIONAL",
    )
    assert not decision.accepted
    assert decision.reason == "NOTIONAL_FILTER_MINIMUM_UNAVAILABLE"


def test_multi_pair_coordinator_blocks_plan_when_atomic_reservation_fails(tmp_path: Path):
    snapshot = _snapshot()
    btc = snapshot.get_symbol("BTCUSDT")
    assert btc is not None
    instrument = InstrumentSpec.from_symbol_info(btc)
    ledger = ExecutionLedger(tmp_path / "reserved.sqlite")
    held = ledger.reserve_portfolio_risk(
        signal_id="existing-live-reservation", symbol="BTCUSDT",
        risk_usdt=Decimal("95"), notional_usdt=Decimal("1000"),
        equity_usdt=Decimal("10000"), exchange_open_risk_usdt=Decimal("0"),
        exchange_active_position_count=0, max_positions=5,
        max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal("60000"),
    )
    assert held.accepted
    execution = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": instrument}, risk_manager=PortfolioRiskManager(),
        execution_service=execution, ledger=ledger,
    )
    portfolio = PortfolioSnapshot(
        equity_usdt=Decimal("10000"), open_risk_usdt=Decimal("0"),
        active_position_count=0, symbol_notional_usdt={}, captured_at_ms=1794400000000,
    )
    routed = coordinator.route(_signal("reservation-over-cap"), portfolio)
    assert not routed.risk.accepted
    assert routed.risk.reason == "PORTFOLIO_RISK_RESERVATION_EXCEEDS_CAP"
    assert routed.execution is None
    assert ledger.get_intent("reservation-over-cap") is None


def test_multi_pair_coordinator_blocks_duplicate_active_reservation_until_reconciled(tmp_path: Path):
    snapshot = _snapshot()
    btc = snapshot.get_symbol("BTCUSDT")
    assert btc is not None
    instrument = InstrumentSpec.from_symbol_info(btc)
    ledger = ExecutionLedger(tmp_path / "duplicate-reservation.sqlite")
    seeded = ledger.reserve_portfolio_risk(
        signal_id="duplicate-reservation", symbol="BTCUSDT",
        risk_usdt=Decimal("12"), notional_usdt=Decimal("6000"),
        equity_usdt=Decimal("10000"), exchange_open_risk_usdt=Decimal("0"),
        exchange_active_position_count=0, max_positions=5,
        max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal("60000"),
    )
    assert seeded.accepted
    execution = ExecutionService(ledger, config=ExecutionConfig(mode=ExecutionMode.PAPER))
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": instrument}, risk_manager=PortfolioRiskManager(),
        execution_service=execution, ledger=ledger,
    )
    portfolio = PortfolioSnapshot(
        equity_usdt=Decimal("10000"), open_risk_usdt=Decimal("0"),
        active_position_count=0, symbol_notional_usdt={}, captured_at_ms=1794400000000,
    )
    routed = coordinator.route(_signal("duplicate-reservation"), portfolio)
    assert not routed.risk.accepted
    assert routed.risk.reason == "ACTIVE_SIGNAL_RESERVATION_REQUIRES_RECONCILIATION"
    assert routed.execution is None
    assert ledger.get_intent("duplicate-reservation") is None


def test_testnet_execution_requires_matching_active_portfolio_reservation(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "testnet-reservation.sqlite")
    http = httpx.Client(transport=httpx.MockTransport(
        lambda request: (_ for _ in ()).throw(AssertionError("network must not be called"))
    ))
    client = BinancePrivateRestClient(
        "test-key", "test-secret", environment="TESTNET", http_client=http,
    )
    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=client,
    )
    try:
        with pytest.raises(RuntimeError, match="requires an active coordinator"):
            service.submit(_plan())
        assert ledger.get_intent("sig-001") is None

        plan = _plan()
        ledger.reserve_portfolio_risk(
            signal_id=plan.signal.signal_id, symbol=plan.signal.symbol,
            risk_usdt=plan.risk_usdt, notional_usdt=plan.notional_usdt,
            equity_usdt=Decimal("10000"), exchange_open_risk_usdt=Decimal("0"),
            exchange_active_position_count=0, max_positions=5,
            max_portfolio_open_risk_pct=Decimal("1"),
            exchange_symbol_notional_usdt=Decimal("0"),
            max_symbol_notional_usdt=Decimal("60000"),
        )
        mismatched = TradePlan(
            plan.signal, plan.quantity, plan.notional_usdt, Decimal("11.00"),
            plan.margin_estimate_usdt, plan.leverage, plan.client_order_id,
        )
        with pytest.raises(RuntimeError, match="does not match this TradePlan"):
            service.submit(mismatched)
        assert ledger.get_intent("sig-001") is None
    finally:
        client.close()


@pytest.mark.parametrize(
    ("existing_position_side", "new_signal_side", "expected_reason"),
    [
        ("BOTH", "LONG", "ONE_WAY_SYMBOL_POSITION_ALREADY_OPEN"),
        ("LONG", "LONG", "SAME_SIDE_SCALE_IN_DISABLED_PENDING_TESTNET_QUALIFICATION"),
    ],
)
def test_testnet_coordinator_blocks_unqualified_same_symbol_scale_in(
    tmp_path: Path, existing_position_side: str, new_signal_side: str, expected_reason: str,
):
    snapshot = _snapshot()
    btc = snapshot.get_symbol("BTCUSDT")
    assert btc is not None
    ledger = ExecutionLedger(tmp_path / f"entry-gate-{existing_position_side}.sqlite")
    ledger.claim_intent(signal_id="existing-lot", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAEXISTING", payload={})
    ledger.update_intent("existing-lot", "PROTECTED")
    ledger.record_position(
        symbol="BTCUSDT", position_side=existing_position_side, signal_id="existing-lot",
        quantity="0.01", entry_price="50000", stop_loss="49900", take_profit="50300",
    )

    class UnusedTestnetClient:
        environment = "TESTNET"

    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=UnusedTestnetClient(),
    )
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": InstrumentSpec.from_symbol_info(btc)},
        risk_manager=PortfolioRiskManager(), execution_service=service, ledger=ledger,
    )
    portfolio = PortfolioSnapshot(
        equity_usdt=Decimal("10000"), open_risk_usdt=Decimal("0"),
        active_position_count=1, symbol_notional_usdt={"BTCUSDT": Decimal("500")},
        captured_at_ms=1794400000000,
    )
    signal = _signal("new-scale-in")
    if new_signal_side != signal.side:
        signal = QualifiedSignal(
            signal_id=signal.signal_id, symbol=signal.symbol, side=new_signal_side,
            entry_type=signal.entry_type, entry_price=signal.entry_price,
            stop_loss=Decimal("50100") if new_signal_side == "SHORT" else signal.stop_loss,
            take_profit=Decimal("49700") if new_signal_side == "SHORT" else signal.take_profit,
            timeframe=signal.timeframe, strategy_id=signal.strategy_id,
            created_at_ms=signal.created_at_ms, reason_codes=signal.reason_codes,
        )
    result = coordinator.route(signal, portfolio)
    assert not result.risk.accepted
    assert result.risk.reason == expected_reason
    assert result.execution is None
    assert ledger.get_intent(signal.signal_id) is None
    assert ledger.get_risk_reservation(signal.signal_id) is None


def test_testnet_coordinator_blocks_symbol_with_unresolved_entry_intent(tmp_path: Path):
    btc = _snapshot().get_symbol("BTCUSDT")
    assert btc is not None
    ledger = ExecutionLedger(tmp_path / "pending-entry-gate.sqlite")
    ledger.claim_intent(signal_id="uncertain-entry", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAUNCERTAIN", payload={})

    class UnusedTestnetClient:
        environment = "TESTNET"

    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=UnusedTestnetClient(),
    )
    coordinator = MultiPairExecutionCoordinator(
        instruments={"BTCUSDT": InstrumentSpec.from_symbol_info(btc)},
        risk_manager=PortfolioRiskManager(), execution_service=service, ledger=ledger,
    )
    portfolio = PortfolioSnapshot(
        equity_usdt=Decimal("10000"), open_risk_usdt=Decimal("0"),
        active_position_count=0, symbol_notional_usdt={}, captured_at_ms=1794400000000,
    )
    result = coordinator.route(_signal("blocked-by-pending"), portfolio)
    assert not result.risk.accepted
    assert result.risk.reason == "SYMBOL_ENTRY_REQUIRES_RECONCILIATION"
    assert result.execution is None


def test_execution_service_second_line_guard_detects_unqualified_scale_in(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "execution-second-line.sqlite")
    ledger.claim_intent(signal_id="existing-lot", symbol="BTCUSDT", side="LONG",
                        client_order_id="DIVAEXISTING", payload={})
    ledger.update_intent("existing-lot", "PROTECTED")
    ledger.record_position(
        symbol="BTCUSDT", position_side="LONG", signal_id="existing-lot",
        quantity="0.01", entry_price="50000", stop_loss="49900", take_profit="50300",
    )

    class UnusedTestnetClient:
        environment = "TESTNET"

    service = ExecutionService(
        ledger, config=ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True),
        client=UnusedTestnetClient(),
    )
    assert service._existing_entry_conflict(
        symbol="BTCUSDT", position_side="LONG", signal_id="new-lot",
    ) == "SAME_SIDE_SCALE_IN_DISABLED_PENDING_TESTNET_QUALIFICATION"
    assert service._existing_entry_conflict(
        symbol="BTCUSDT", position_side="SHORT", signal_id="new-opposite-hedge-lot",
    ) is None


def test_testnet_execution_requires_separate_stage_c_opt_in():
    from divatrading.execution.service import ExecutionConfig, ExecutionMode
    import pytest
    with pytest.raises(ValueError, match="Stage C"):
        ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True)
    config = ExecutionConfig(mode=ExecutionMode.TESTNET, enable_testnet_orders=True, enable_testnet_stage_c=True)
    assert config.mode == ExecutionMode.TESTNET


def test_testnet_stage_c_opt_in_defaults_off_from_environment():
    from divatrading.execution.service import ExecutionConfig
    values = {
        "DIVA_EXECUTION_MODE": "TESTNET",
        "DIVA_ENABLE_TESTNET_ORDERS": "true",
        "BINANCE_API_KEY": "dummy",
        "BINANCE_API_SECRET": "dummy",
    }
    with pytest.raises(ValueError, match="Stage C"):
        ExecutionConfig.from_env(values)



def test_automatic_protection_recovery_requires_real_exchange_mode():
    assert ExecutionConfig().enable_protection_recovery is False
    live = ExecutionConfig(
        mode=ExecutionMode.LIVE,
        enable_live_trading=True,
        live_confirmation="I_ACCEPT_REAL_MONEY_RISK",
        enforce_entry_quote_guard=True,
        enable_protection_recovery=True,
    )
    assert live.enable_protection_recovery
    with pytest.raises(ValueError, match="only for TESTNET/LIVE"):
        ExecutionConfig(mode=ExecutionMode.PAPER, enable_protection_recovery=True)
    config = ExecutionConfig(
        mode=ExecutionMode.TESTNET,
        enable_testnet_orders=True,
        enable_testnet_stage_c=True,
        enable_protection_recovery=True,
    )
    assert config.enable_protection_recovery is True
