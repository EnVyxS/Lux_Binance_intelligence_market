from decimal import Decimal

import pytest

from divatrading.replay.splits import (
    ReplaySplitError,
    create_chronological_split_plan,
    interval_alignment_quantum,
    label_split,
)


def test_lcm_alignment_and_half_open_boundary_labels():
    plan = create_chronological_split_plan(0, 5_400_000, ("1m", "5m", "15m"))
    splits = plan["splits"]
    assert plan["alignment_quantum_ms"] == 900_000
    assert splits[0]["start_ms"] == 0
    assert splits[0]["end_ms_exclusive"] % 900_000 == 0
    assert splits[1]["start_ms"] == splits[0]["end_ms_exclusive"]
    assert label_split(splits[0]["end_ms_exclusive"] - 1, splits) == "TRAIN"
    assert label_split(splits[0]["end_ms_exclusive"], splits) == "VALIDATION"
    assert label_split(splits[1]["end_ms_exclusive"], splits) == "TEST"
    assert label_split(5_400_000, splits) is None
    assert plan["target_ratios"] == ["0.60", "0.20", "0.20"]


def test_terminal_clock_boundary_is_included_without_shifting_aligned_cuts():
    plan = create_chronological_split_plan(
        0, 5_400_001, ("1m", "5m"), terminal_boundary_ms=5_400_000
    )
    splits = plan["splits"]
    assert plan["alignment_quantum_ms"] == 300_000
    assert splits[-1]["end_ms_exclusive"] == 5_400_001
    assert label_split(5_400_000, splits) == "TEST"
    assert splits[0]["end_ms_exclusive"] % 300_000 == 0
    assert splits[1]["end_ms_exclusive"] % 300_000 == 0


def test_split_planner_rejects_short_windows_and_bad_ratios():
    with pytest.raises(ReplaySplitError):
        create_chronological_split_plan(0, 2_000_000, ("15m",))
    with pytest.raises(ReplaySplitError):
        create_chronological_split_plan(
            0, 5_400_000, ("1m",), target_ratios=(Decimal("0.5"), Decimal("0.2"), Decimal("0.2"))
        )


def test_interval_alignment_quantum_deduplicates_intervals():
    assert interval_alignment_quantum(("1m", "5m", "5m")) == 300_000
