from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.execution.ledger import ExecutionLedger


def _reserve(
    ledger: ExecutionLedger,
    signal_id: str,
    risk: str = "60",
    *,
    symbol: str | None = None,
    notional: str = "1000",
    symbol_cap: str = "50000",
):
    return ledger.reserve_portfolio_risk(
        signal_id=signal_id,
        symbol=symbol or f"PAIR{signal_id[:4].upper()}",
        risk_usdt=Decimal(risk),
        notional_usdt=Decimal(notional),
        equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"),
        exchange_active_position_count=0,
        max_positions=5,
        max_portfolio_open_risk_pct=Decimal("1.00"),
        exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal(symbol_cap),
    )


def test_reservation_uses_exact_decimal_budget_and_releases(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "risk.sqlite")
    first = _reserve(ledger, "signal-a", "60.01")
    assert first.accepted
    assert first.active_reserved_risk_usdt == Decimal("60.01")

    blocked = _reserve(ledger, "signal-b", "40.00")
    assert not blocked.accepted
    assert blocked.reason == "PORTFOLIO_RISK_RESERVATION_EXCEEDS_CAP"
    assert ledger.active_reserved_risk_usdt() == Decimal("60.01")

    assert ledger.release_risk_reservation("signal-a", "CONFIRMED_FLAT")
    assert not ledger.release_risk_reservation("signal-a", "DUPLICATE_RELEASE")
    accepted_after_release = _reserve(ledger, "signal-b", "100.00")
    assert accepted_after_release.accepted


def test_reservation_is_idempotent_for_same_active_signal(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "risk.sqlite")
    first = _reserve(ledger, "same-signal", "25")
    second = _reserve(ledger, "same-signal", "25")
    assert first.accepted
    assert second.accepted and second.duplicate
    assert second.reason == "RISK_ALREADY_RESERVED"
    assert ledger.active_reserved_risk_usdt() == Decimal("25")

    assert ledger.release_risk_reservation("same-signal", "CONFIRMED_TERMINAL")
    third = _reserve(ledger, "same-signal", "25")
    assert not third.accepted
    assert third.duplicate
    assert third.reason == "SIGNAL_RESERVATION_ALREADY_RELEASED"


def test_reservation_enforces_exchange_positions_plus_local_reservations(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "risk.sqlite")
    accepted = ledger.reserve_portfolio_risk(
        signal_id="signal-a", symbol="BTCUSDT", risk_usdt=Decimal("10"),
        notional_usdt=Decimal("1000"), equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=2,
        max_positions=3, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal("50000"),
    )
    assert accepted.accepted
    blocked = ledger.reserve_portfolio_risk(
        signal_id="signal-b", symbol="ETHUSDT", risk_usdt=Decimal("10"),
        notional_usdt=Decimal("1000"), equity_usdt=Decimal("10000"),
        exchange_open_risk_usdt=Decimal("0"), exchange_active_position_count=2,
        max_positions=3, max_portfolio_open_risk_pct=Decimal("1"),
        exchange_symbol_notional_usdt=Decimal("0"),
        max_symbol_notional_usdt=Decimal("50000"),
    )
    assert not blocked.accepted
    assert blocked.reason == "MAX_OPEN_POSITIONS_RESERVED"


def test_concurrent_pair_reservations_cannot_overspend_portfolio_cap(tmp_path: Path):
    path = tmp_path / "shared-risk.sqlite"
    ledgers = [ExecutionLedger(path) for _ in range(8)]

    def run(index: int):
        return _reserve(ledgers[index], f"parallel-{index}", "60")

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(run, range(8)))

    assert sum(result.accepted for result in results) == 1
    assert ledgers[0].active_reserved_risk_usdt() == Decimal("60")
    assert len(ledgers[0].active_risk_reservations()) == 1


@pytest.mark.parametrize(
    "field,value",
    [
        ("risk_usdt", Decimal("0")),
        ("equity_usdt", Decimal("NaN")),
        ("exchange_open_risk_usdt", Decimal("-1")),
        ("max_portfolio_open_risk_pct", Decimal("Infinity")),
    ],
)
def test_reservation_rejects_invalid_numeric_inputs(tmp_path: Path, field: str, value: Decimal):
    ledger = ExecutionLedger(tmp_path / "invalid.sqlite")
    kwargs = {
        "signal_id": "invalid-signal", "symbol": "BTCUSDT",
        "risk_usdt": Decimal("10"), "notional_usdt": Decimal("1000"),
        "equity_usdt": Decimal("10000"), "exchange_open_risk_usdt": Decimal("0"),
        "exchange_active_position_count": 0, "max_positions": 5,
        "max_portfolio_open_risk_pct": Decimal("1"),
        "exchange_symbol_notional_usdt": Decimal("0"),
        "max_symbol_notional_usdt": Decimal("50000"),
    }
    kwargs[field] = value
    with pytest.raises(ValueError):
        ledger.reserve_portfolio_risk(**kwargs)


def test_concurrent_same_symbol_reservations_cannot_exceed_symbol_notional_cap(tmp_path: Path):
    ledger = ExecutionLedger(tmp_path / "symbol-cap.sqlite")
    first = _reserve(ledger, "btc-a", "10", symbol="BTCUSDT", notional="4000", symbol_cap="6000")
    second = _reserve(ledger, "btc-b", "10", symbol="BTCUSDT", notional="3000", symbol_cap="6000")
    other_symbol = _reserve(ledger, "eth-a", "10", symbol="ETHUSDT", notional="3000", symbol_cap="6000")

    assert first.accepted
    assert not second.accepted
    assert second.reason == "SYMBOL_NOTIONAL_RESERVATION_EXCEEDS_CAP"
    assert second.active_reserved_symbol_notional_usdt == Decimal("4000")
    assert other_symbol.accepted


def test_concurrent_same_symbol_reservations_respect_notional_cap_atomically(tmp_path: Path):
    path = tmp_path / "shared-symbol-cap.sqlite"
    ledgers = [ExecutionLedger(path) for _ in range(8)]

    def run(index: int):
        return _reserve(
            ledgers[index], f"same-pair-{index}", "10", symbol="BTCUSDT",
            notional="2500", symbol_cap="5000",
        )

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(run, range(8)))

    assert sum(result.accepted for result in results) == 2
    assert ledgers[0].active_reserved_risk_usdt() == Decimal("20")
    active = ledgers[0].active_risk_reservations()
    assert sum((Decimal(row["notional_usdt"]) for row in active), Decimal("0")) == Decimal("5000")
