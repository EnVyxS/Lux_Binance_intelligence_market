from __future__ import annotations

from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

from divatrading.intelligence.kronos import (
    KronosConfig, KronosForecastError, KronosShadowAdapter,
)
from divatrading.market_data.klines import Kline


class FakePredictor:
    def __init__(self) -> None:
        self.calls = []

    def predict(self, **kwargs):
        self.calls.append(kwargs)
        last = float(kwargs["df"].iloc[-1]["close"])
        return pd.DataFrame([
            {"open": last + 1, "high": last + 2, "low": last + 0.5,
             "close": last + 1.5, "volume": 12.0, "amount": 1200.0}
            for _ in range(kwargs["pred_len"])
        ])


def _candles(symbol="BTCUSDT", count=80, offset=0):
    start = 1_800_000_000_000
    interval = 300_000
    rows = []
    for index in range(count):
        open_time = start + index * interval
        base = Decimal("100") + Decimal(offset)
        rows.append(Kline.from_binance_row(
            [open_time, str(base), str(base + 2), str(base - 1), str(base + 1), "10", open_time + interval - 1,
             str((base + 1) * 10), 100, "5", str((base + 1) * 5), "0"],
            symbol=symbol, interval="5m", source_endpoint="/fapi/v1/klines",
        ))
    return rows


def test_kronos_shadow_uses_valid_closed_contiguous_m5_and_returns_shadow_forecast():
    predictor = FakePredictor()
    adapter = KronosShadowAdapter(
        config=KronosConfig(context_bars=64, minimum_input_bars=64, horizon_bars=3),
        predictor=predictor,
    )
    rows = _candles(count=80)
    forecast = adapter.forecast(rows, now_ms=rows[-1].close_time_ms + 1000)
    assert forecast.symbol == "BTCUSDT"
    assert forecast.horizon_bars == 3
    assert forecast.direction == "UP"
    assert forecast.shadow_only is True
    assert len(forecast.forecast_bars) == 3
    assert len(predictor.calls) == 1
    assert len(predictor.calls[0]["df"]) == 64


def test_kronos_rejects_gap_and_forming_candles():
    adapter = KronosShadowAdapter(predictor=FakePredictor())
    rows = _candles(count=80)
    now_ms = rows[-1].close_time_ms + 1000
    with pytest.raises(KronosForecastError, match="gap"):
        adapter.forecast(rows[:30] + rows[31:], now_ms=now_ms)
    with pytest.raises(KronosForecastError, match="forming/future"):
        adapter.forecast(rows, now_ms=rows[-1].close_time_ms)


def test_kronos_respects_configured_minimum_input_bars():
    adapter = KronosShadowAdapter(
        config=KronosConfig(context_bars=128, minimum_input_bars=100),
        predictor=FakePredictor(),
    )
    rows = _candles(count=80)
    with pytest.raises(KronosForecastError, match="at least 100"):
        adapter.forecast(rows, now_ms=rows[-1].close_time_ms + 1)


def test_kronos_missing_install_does_not_import_model_or_torch(tmp_path: Path):
    adapter = KronosShadowAdapter(root=tmp_path)
    status = adapter.installed_status()
    assert status == {"installed": False, "reason": "KRONOS_INSTALL_MANIFEST_MISSING"}


def test_kronos_evaluator_uses_exact_future_m5_path_and_reports_metrics():
    from divatrading.intelligence.kronos_evaluation import evaluate_kronos_forecast

    rows = _candles(count=80)
    predictor = FakePredictor()
    adapter = KronosShadowAdapter(
        config=KronosConfig(context_bars=64, minimum_input_bars=64, horizon_bars=3),
        predictor=predictor,
    )
    forecast = adapter.forecast(rows, now_ms=rows[-1].close_time_ms + 1)
    future = []
    interval = 300_000
    start = rows[-1].open_time_ms + interval
    for index, close in enumerate((102, 103, 104)):
        open_time = start + index * interval
        future.append(Kline.from_binance_row(
            [open_time, str(close - 1), str(close + 1), str(close - 2), str(close), "8",
             open_time + interval - 1, "800", 50, "4", "400", "0"],
            symbol="BTCUSDT", interval="5m", source_endpoint="/fapi/v1/klines",
        ))
    result = evaluate_kronos_forecast(forecast, future)
    assert result.evaluated_bars == 3
    assert Decimal("0") <= result.directional_accuracy_pct <= Decimal("100")
    assert result.close_mae >= 0
    assert result.close_mape_pct >= 0
    assert result.range_containment_pct >= 0
    with pytest.raises(KronosForecastError, match="count"):
        evaluate_kronos_forecast(forecast, future[1:])


def test_kronos_forecast_identity_includes_exact_input_candle_content():
    config = KronosConfig(context_bars=64, minimum_input_bars=64, horizon_bars=3)
    rows_a = _candles(count=80, offset=0)
    rows_b = _candles(count=80, offset=1)
    first = KronosShadowAdapter(config=config, predictor=FakePredictor()).forecast(
        rows_a, now_ms=rows_a[-1].close_time_ms + 1,
    )
    same = KronosShadowAdapter(config=config, predictor=FakePredictor()).forecast(
        rows_a, now_ms=rows_a[-1].close_time_ms + 1,
    )
    changed = KronosShadowAdapter(config=config, predictor=FakePredictor()).forecast(
        rows_b, now_ms=rows_b[-1].close_time_ms + 1,
    )
    assert first.forecast_id == same.forecast_id
    assert first.forecast_id != changed.forecast_id


def test_kronos_installer_fails_closed_on_unsupported_python_without_download(tmp_path: Path, monkeypatch):
    from divatrading.intelligence import kronos_install

    monkeypatch.setattr(kronos_install, "sys", SimpleNamespace(version_info=(3, 12, 8), version="3.12.8"))
    with pytest.raises(kronos_install.KronosInstallError, match="Python 3.12.9"):
        kronos_install.install_kronos(tmp_path, install_dependencies=False)
    assert not (tmp_path / ".kronos" / "kronos_install_manifest.json").exists()


def test_forecast_fails_cleanly_when_optional_model_is_not_installed(tmp_path: Path):
    from divatrading.intelligence.kronos import KronosForecastUnavailable

    rows = _candles(count=80)
    adapter = KronosShadowAdapter(
        root=tmp_path,
        config=KronosConfig(context_bars=64, minimum_input_bars=64, horizon_bars=2),
    )
    with pytest.raises(KronosForecastUnavailable, match="kronos-install"):
        adapter.forecast(rows, now_ms=rows[-1].close_time_ms + 1)
