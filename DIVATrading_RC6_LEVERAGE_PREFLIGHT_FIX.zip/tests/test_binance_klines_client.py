from __future__ import annotations

import httpx
import pytest

from divatrading.exchange.binance.client import (
    BinanceApiError,
    BinanceHttpError,
    BinanceResponseError,
    BinanceUsdMFuturesRestClient,
)


def _client(handler, *, sleeps=None, max_attempts=3):
    transport = httpx.MockTransport(handler)
    http_client = httpx.Client(transport=transport)
    return BinanceUsdMFuturesRestClient(
        base_url="https://fixture.local",
        max_attempts=max_attempts,
        http_client=http_client,
        sleep=(sleeps.append if sleeps is not None else lambda _: None),
    )


def test_get_klines_uses_public_endpoint_and_inclusive_query_parameters():
    observed = {}

    def handler(request):
        observed["method"] = request.method
        observed["url"] = str(request.url)
        observed["headers"] = dict(request.headers)
        return httpx.Response(200, json=[])

    client = _client(handler)
    try:
        assert client.get_klines(
            symbol="btcusdt", interval="1m", start_time_ms=60_000,
            end_time_ms=120_000, limit=499,
        ) == []
    finally:
        client.close()

    request_url = httpx.URL(observed["url"])
    assert observed["method"] == "GET"
    assert request_url.path == "/fapi/v1/klines"
    assert request_url.params["symbol"] == "BTCUSDT"
    assert request_url.params["interval"] == "1m"
    assert request_url.params["startTime"] == "60000"
    assert request_url.params["endTime"] == "120000"
    assert request_url.params["limit"] == "499"
    assert "X-MBX-APIKEY" not in {key.upper() for key in observed["headers"]}


@pytest.mark.parametrize(
    "kwargs",
    [
        {"symbol": "", "interval": "1m", "start_time_ms": 0, "end_time_ms": 0},
        {"symbol": "BTCUSDT", "interval": "1h", "start_time_ms": 0, "end_time_ms": 0},
        {"symbol": "BTCUSDT", "interval": "1m", "start_time_ms": -1, "end_time_ms": 0},
        {"symbol": "BTCUSDT", "interval": "1m", "start_time_ms": 2, "end_time_ms": 1},
        {"symbol": "BTCUSDT", "interval": "1m", "start_time_ms": 0, "end_time_ms": 0, "limit": 1501},
    ],
)
def test_get_klines_rejects_invalid_parameters(kwargs):
    client = _client(lambda request: httpx.Response(200, json=[]))
    try:
        with pytest.raises(ValueError):
            client.get_klines(**kwargs)
    finally:
        client.close()


def test_get_klines_surfaces_api_http_and_json_errors():
    client = _client(lambda request: httpx.Response(200, json={"code": -1121, "msg": "invalid symbol"}))
    try:
        with pytest.raises(BinanceApiError):
            client.get_klines(
                symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=0
            )
    finally:
        client.close()

    client = _client(lambda request: httpx.Response(400, text="bad request"))
    try:
        with pytest.raises(BinanceHttpError):
            client.get_klines(
                symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=0
            )
    finally:
        client.close()

    client = _client(lambda request: httpx.Response(200, json={"unexpected": "object"}))
    try:
        with pytest.raises(BinanceResponseError):
            client.get_klines(
                symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=0
            )
    finally:
        client.close()


def test_get_klines_retries_http_429_with_bounded_retry_after():
    calls = {"value": 0}
    sleeps = []

    def handler(request):
        calls["value"] += 1
        if calls["value"] == 1:
            return httpx.Response(429, text="rate limited", headers={"Retry-After": "5"})
        return httpx.Response(200, json=[])

    client = _client(handler, sleeps=sleeps)
    try:
        assert client.get_klines(
            symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=0
        ) == []
    finally:
        client.close()
    assert calls["value"] == 2
    assert sleeps == [1.0]
