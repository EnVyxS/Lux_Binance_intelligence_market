from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.strategy.scalping_market_data import ScalpingMarketDataAdapter
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureContinuityError,
    ScalpingMarketStructureEngine,
    ScalpingMarketStructureInputError,
)

NOW = 1_800_000_000_000
FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def instrument(symbol: str = "BTCUSDT") -> SymbolInfo:
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    row = next(item for item in payload["symbols"] if item["symbol"] == symbol)
    return SymbolInfo.from_payload(row)


def make_candle(
    interval: str, open_time: int, values: tuple[str, str, str, str], symbol: str = "BTCUSDT"
) -> Kline:
    op, hi, lo, cl = values
    interval_ms = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, op, hi, lo, cl, "10", open_time + interval_ms - 1,
         "1000", 10, "5", "500", "0"],
        symbol=symbol, interval=interval, source_endpoint="https://fixture/klines",
    )


def view_for(
    *,
    m1_values: list[tuple[str, str, str, str]] | None = None,
    m5_values: list[tuple[str, str, str, str]] | None = None,
    m15_values: list[tuple[str, str, str, str]] | None = None,
    now_ms: int = NOW,
    fixed_history: bool = False,
    symbol: str = "BTCUSDT",
):
    items = []
    for interval, values in (("1m", m1_values), ("5m", m5_values), ("15m", m15_values)):
        if values is None:
            continue
        interval_ms = INTERVAL_MILLISECONDS[interval]
        last_open = (now_ms // interval_ms - 1) * interval_ms
        first_open = (
            last_open - 4 * interval_ms
            if fixed_history
            else last_open - (len(values) - 1) * interval_ms
        )
        candles = tuple(
            make_candle(interval, first_open + index * interval_ms, row, symbol)
            for index, row in enumerate(values)
        )
        items.append(KlineSeriesInput(
            symbol=symbol, interval=interval, candles=candles,
            source_observed_at_ms=now_ms - 100, source_healthy=True, source_complete=True,
        ))
    return ScalpingMarketDataAdapter().build_view(
        symbol=symbol, now_ms=now_ms, symbol_info=instrument(symbol), kline_series=tuple(items)
    )


BARS_BULL_THEN_BEAR = [
    ("102.0", "105.0", "101.0", "103.0"),
    ("104.0", "110.0", "100.0", "108.0"),
    ("106.0", "108.0", "102.0", "105.0"),
    ("109.0", "112.0", "104.0", "111.0"),
    ("100.0", "111.0", "98.0", "99.0"),
]


def fast_config(**overrides) -> ScalpingMarketStructureConfig:
    values = dict(
        swing_left_bars=1, swing_right_bars=1,
        internal_left_bars=1, internal_right_bars=1,
    )
    values.update(overrides)
    return ScalpingMarketStructureConfig(**values)


def test_config_rejects_unbounded_or_non_integer_pivot_lengths():
    with pytest.raises(ValueError):
        ScalpingMarketStructureConfig(swing_left_bars=0)
    with pytest.raises(ValueError):
        ScalpingMarketStructureConfig(internal_right_bars=True)
    with pytest.raises(ValueError):
        ScalpingMarketStructureConfig(max_bar_traces_per_timeframe=5001)


def test_confirmed_pivot_is_emitted_only_after_right_side_bars_close():
    values = BARS_BULL_THEN_BEAR[:3]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=values, m5_values=values)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    pivots = [item.pivot for item in m1.pivots]
    high = next(item for item in pivots if item.layer == "SWING" and item.kind == "HIGH")
    assert high.source_index == 1
    assert high.confirmation_index == 2
    assert high.source_open_time_ms < high.confirmation_close_time_ms


def test_no_pivot_is_used_before_its_confirmation_bar():
    # The high at index 1 is confirmed by index 2; only index 3 can break it.
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR[:3], m5_values=BARS_BULL_THEN_BEAR[:3])
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert not m1.events
    assert m1.bars_processed == 3


def test_strict_pivot_rule_rejects_equal_highs_and_equal_lows():
    rows = [
        ("101.0", "105.0", "100.0", "102.0"),
        ("102.0", "110.0", "99.0", "106.0"),
        ("106.0", "110.0", "99.0", "107.0"),
        ("107.0", "108.0", "101.0", "106.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert not [p for p in m1.pivots if p.pivot.kind in ("HIGH", "LOW") and p.pivot.source_index in (1, 2)]


def test_bullish_break_emits_bos_with_exact_pivot_provenance_and_protected_low():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR[:4], m5_values=BARS_BULL_THEN_BEAR[:4])
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    event = next(e for e in m1.events if e.layer == "SWING")
    assert event.event_type == "BOS"
    assert event.direction == 1
    assert event.broken_level == Decimal("110.0")
    assert event.pivot_source_open_time_ms < event.break_bar_open_time_ms
    assert event.confirmation_time_ms > event.break_bar_open_time_ms
    assert event.protected_kind == "LOW"
    assert event.protected_price == Decimal("100.0")
    assert m1.swing.direction_name == "BULLISH"
    assert m1.swing.protected_low is not None
    assert m1.swing.protected_low.price == Decimal("100.0")


def test_break_is_close_confirmed_and_wick_only_does_not_emit_event():
    rows = BARS_BULL_THEN_BEAR[:3] + [
        ("109.0", "112.0", "104.0", "109.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert not m1.events


def test_bearish_break_after_bullish_bias_is_choch():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    swing = [e for e in m1.events if e.layer == "SWING"]
    assert [(e.event_type, e.direction) for e in swing] == [("BOS", 1), ("CHoCH", -1)]
    assert swing[1].broken_level == Decimal("100.0")
    assert swing[1].protected_kind == "HIGH"
    assert swing[1].protected_price == Decimal("112.0")
    assert m1.swing.direction_name == "BEARISH"


def test_initial_bearish_break_establishes_bearish_bos():
    rows = [
        ("108.0", "110.0", "105.0", "107.0"),
        ("106.0", "109.0", "100.0", "102.0"),
        ("104.0", "108.0", "103.0", "105.0"),
        ("101.0", "106.0", "98.0", "99.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    event = next(e for e in m1.events if e.layer == "SWING")
    assert event.event_type == "BOS"
    assert event.direction == -1


def test_internal_and_swing_layers_keep_independent_pivot_and_trend_state():
    rows = BARS_BULL_THEN_BEAR
    config = fast_config(swing_left_bars=2, swing_right_bars=2, internal_left_bars=1, internal_right_bars=1)
    result = ScalpingMarketStructureEngine(config=config).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    swing_events = [e for e in m1.events if e.layer == "SWING"]
    internal_events = [e for e in m1.events if e.layer == "INTERNAL"]
    assert len(internal_events) >= len(swing_events)
    assert all(e.layer == "INTERNAL" for e in internal_events)


def test_one_candle_can_confirm_both_high_and_low_pivot():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR[:3], m5_values=BARS_BULL_THEN_BEAR[:3])
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    same_source = [
        item.pivot for item in m1.pivots
        if item.pivot.layer == "SWING" and item.pivot.source_index == 1
    ]
    assert {item.kind for item in same_source} == {"HIGH", "LOW"}


def test_latest_confirmed_crossed_pivot_is_selected_when_one_candle_breaks_multiple_levels():
    rows = [
        ("101.0", "105.0", "99.0", "102.0"),
        ("103.0", "110.0", "100.0", "108.0"),
        ("104.0", "108.0", "101.0", "106.0"),
        ("105.0", "109.0", "102.0", "107.0"),
        ("108.0", "115.0", "104.0", "114.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    event = next(e for e in m1.events if e.layer == "SWING" and e.direction == 1)
    assert event.pivot_source_open_time_ms < event.break_bar_open_time_ms
    assert event.broken_level in {Decimal("110.0"), Decimal("109.0")}


def test_m1_and_m5_states_are_independent():
    m5_rows = BARS_BULL_THEN_BEAR
    m1_rows = [
        ("102.0", "105.0", "101.0", "103.0"),
        ("104.0", "110.0", "100.0", "108.0"),
        ("106.0", "108.0", "102.0", "105.0"),
        ("107.0", "109.0", "103.0", "108.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=m1_rows, m5_values=m5_rows)
    )
    m1 = result.timeframe("1m")
    m5 = result.timeframe("5m")
    assert m1 is not None and m5 is not None
    assert m1.bars_processed == len(m1_rows)
    assert m5.bars_processed == len(m5_rows)
    assert m1.latest_bar_open_time_ms != m5.latest_bar_open_time_ms
    assert m1.swing.direction_name != m5.swing.direction_name or m1.events != m5.events


def test_m15_is_advisory_and_does_not_suppress_m1_or_m5():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR,
                 m15_values=BARS_BULL_THEN_BEAR)
    )
    assert result.m1_setup_ready and result.m5_setup_ready
    assert result.m15_context_available
    assert result.timeframe("1m") is not None
    assert result.timeframe("5m") is not None
    assert result.timeframe("15m") is not None


def test_missing_m1_does_not_veto_m5_structure_processing():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=None, m5_values=BARS_BULL_THEN_BEAR)
    )
    assert not result.m1_setup_ready
    assert result.m5_setup_ready
    assert result.timeframe("5m").events
    assert result.timeframe("1m").status == "UNAVAILABLE"


def test_missing_m5_does_not_veto_independent_m1_structure_processing():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=None)
    )
    assert result.m1_setup_ready
    assert not result.m5_setup_ready
    assert result.timeframe("1m").events
    assert result.timeframe("5m").status == "UNAVAILABLE"


def test_m15_can_be_disabled_without_changing_setup_sources():
    result = ScalpingMarketStructureEngine(
        config=fast_config(enable_m15_context=False)
    ).process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR,
                       m15_values=BARS_BULL_THEN_BEAR))
    assert result.m1_setup_ready and result.m5_setup_ready
    assert not result.m15_context_available
    assert result.timeframe("15m") is None


def test_incremental_update_processes_only_appended_closed_candles():
    engine = ScalpingMarketStructureEngine(config=fast_config())
    first = engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR[:4], m5_values=BARS_BULL_THEN_BEAR[:4], fixed_history=True))
    assert first.timeframe("1m").bars_processed == 4
    second = engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR, fixed_history=True))
    assert second.timeframe("1m").bars_processed == 5
    assert len(second.timeframe("1m").bar_traces) == 5


def test_reprocessing_identical_snapshot_does_not_duplicate_events_or_bars():
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    engine = ScalpingMarketStructureEngine(config=fast_config())
    first = engine.process(view)
    second = engine.process(view)
    assert second.timeframe("1m").bars_processed == first.timeframe("1m").bars_processed
    assert second.timeframe("1m").events == first.timeframe("1m").events
    assert second.timeframe("1m").bar_traces == first.timeframe("1m").bar_traces


def test_missing_incremental_overlap_requires_explicit_reset():
    engine = ScalpingMarketStructureEngine(config=fast_config())
    engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR))
    later = [
        ("103.0", "106.0", "102.0", "104.0"),
        ("104.0", "108.0", "103.0", "107.0"),
    ]
    with pytest.raises(ScalpingMarketStructureContinuityError, match="no longer overlaps"):
        engine.process(view_for(m1_values=later, m5_values=BARS_BULL_THEN_BEAR, now_ms=NOW + 120_000))


def test_revised_previously_processed_closed_candle_requires_reset():
    engine = ScalpingMarketStructureEngine(config=fast_config())
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    engine.process(view)
    changed_rows = list(BARS_BULL_THEN_BEAR)
    changed_rows[-1] = ("100.0", "111.0", "98.0", "99.5")
    with pytest.raises(ScalpingMarketStructureContinuityError, match="was revised"):
        engine.process(view_for(m1_values=changed_rows, m5_values=changed_rows))


def test_reset_one_symbol_timeframe_keeps_other_state():
    engine = ScalpingMarketStructureEngine(config=fast_config())
    engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR))
    engine.reset(symbol="BTCUSDT", timeframe="1m")
    result = engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR))
    assert result.timeframe("1m").bars_processed == len(BARS_BULL_THEN_BEAR)
    assert result.timeframe("5m").bars_processed == len(BARS_BULL_THEN_BEAR)


def test_invalid_timeframe_or_missing_symbol_reset_is_rejected():
    engine = ScalpingMarketStructureEngine(config=fast_config())
    with pytest.raises(ValueError):
        engine.reset(timeframe="3m")
    with pytest.raises(ValueError):
        engine.reset(timeframe="1m")


def test_incomplete_pivot_history_reports_warmup_without_fabricating_structure():
    short = BARS_BULL_THEN_BEAR[:2]
    result = ScalpingMarketStructureEngine(config=fast_config(swing_left_bars=2, swing_right_bars=2)).process(
        view_for(m1_values=short, m5_values=short)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert m1.status == "WARMING_UP"
    assert m1.warmup_remaining_bars > 0
    assert not m1.events


def test_data_must_be_closed_and_tick_aligned_before_processing():
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    m1 = view.m1
    invalid = replace(m1.candles[-1], close=Decimal("99.05"))
    bad_snapshot = replace(m1, candles=m1.candles[:-1] + (invalid,))
    bad_view = replace(view, m1=bad_snapshot)
    with pytest.raises(ValueError, match="not aligned"):
        ScalpingMarketStructureEngine(config=fast_config()).process(bad_view)


def test_forming_candle_is_never_used_as_confirmed_structure_input():
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    m1 = view.m1
    # Replace last close-time with a not-yet-closed timestamp while retaining snapshot type.
    bad_view = replace(view, captured_at_ms=NOW - 1)
    with pytest.raises(ScalpingMarketStructureInputError, match="not-yet-closed"):
        ScalpingMarketStructureEngine(config=fast_config()).process(bad_view)


def test_duplicate_structure_break_is_not_emitted_again_on_following_bar():
    rows = BARS_BULL_THEN_BEAR[:4] + [
        ("111.0", "113.0", "109.0", "112.0"),
        ("112.0", "114.0", "110.0", "113.0"),
    ]
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=rows, m5_values=rows)
    )
    m1 = result.timeframe("1m")
    assert m1 is not None
    events = [e for e in m1.events if e.layer == "SWING" and e.direction == 1]
    assert len(events) == 1


def test_event_id_pivot_id_and_jsonl_are_deterministic():
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    first = ScalpingMarketStructureEngine(config=fast_config()).process(view)
    second = ScalpingMarketStructureEngine(config=fast_config()).process(view)
    assert first == second
    assert first.to_jsonl() == second.to_jsonl()
    assert first.timeframe("1m").events[0].event_id == second.timeframe("1m").events[0].event_id
    assert first.to_jsonl().endswith("}")


def test_trace_serialization_contains_pivot_and_confirmation_times():
    result = ScalpingMarketStructureEngine(config=fast_config()).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    )
    records = [json.loads(line) for line in result.to_jsonl().splitlines()]
    event_rows = [event for record in records for event in record["events"]]
    assert event_rows
    assert event_rows[0]["pivot_source_open_time_ms"] < event_rows[0]["confirmation_time_ms"]
    assert "protected_price" in event_rows[0]


def test_retention_limits_are_enforced():
    rows = BARS_BULL_THEN_BEAR + [
        ("99.0", "110.0", "97.0", "108.0"),
        ("108.0", "109.0", "100.0", "102.0"),
        ("102.0", "111.0", "101.0", "110.0"),
        ("110.0", "112.0", "105.0", "111.0"),
        ("111.0", "113.0", "108.0", "112.0"),
    ]
    engine = ScalpingMarketStructureEngine(config=fast_config(
        max_pivots_per_layer=8, max_events_per_timeframe=8, max_bar_traces_per_timeframe=8
    ))
    result = engine.process(view_for(m1_values=rows, m5_values=rows))
    m1 = result.timeframe("1m")
    assert m1 is not None
    assert len(m1.pivots) <= 16
    assert len(m1.events) <= 8
    assert len(m1.bar_traces) <= 8


def test_all_timeframes_are_preflighted_before_any_structure_state_is_mutated():
    from divatrading.strategy.scalping_market_structure import ScalpingMarketStructureInputError

    engine = ScalpingMarketStructureEngine(config=fast_config())
    view = view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    bad_m5 = replace(view.m5.candles[-1], close=Decimal("99.05"))
    bad_view = replace(view, m5=replace(view.m5, candles=view.m5.candles[:-1] + (bad_m5,)))
    with pytest.raises(ScalpingMarketStructureInputError):
        engine.process(bad_view)

    # If M1 had been advanced before the M5 failure, the following valid call
    # would either duplicate or omit bars. Its count must be the initial batch.
    valid = engine.process(view)
    assert valid.timeframe("1m").bars_processed == len(BARS_BULL_THEN_BEAR)
    assert valid.timeframe("5m").bars_processed == len(BARS_BULL_THEN_BEAR)


def test_per_timeframe_pivot_sensitivity_can_be_overridden_independently():
    from divatrading.strategy.scalping_market_structure import StructureTimeframeSettings

    config = fast_config(
        swing_left_bars=3, swing_right_bars=3,
        timeframe_settings=(
            StructureTimeframeSettings("1m", 1, 1, 1, 1),
            StructureTimeframeSettings("5m", 2, 2, 1, 1),
        ),
    )
    result = ScalpingMarketStructureEngine(config=config).process(
        view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR)
    )
    assert result.timeframe("1m").warmup_required_bars == 3
    assert result.timeframe("5m").warmup_required_bars == 5


def test_symbol_state_budget_is_bounded():
    from divatrading.strategy.scalping_market_structure import ScalpingMarketStructureCapacityError

    engine = ScalpingMarketStructureEngine(config=fast_config(max_symbols=1))
    engine.process(view_for(m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR))
    with pytest.raises(ScalpingMarketStructureCapacityError, match="symbol cap"):
        engine.process(view_for(
            m1_values=BARS_BULL_THEN_BEAR, m5_values=BARS_BULL_THEN_BEAR, symbol="ETHUSDT"
        ))
