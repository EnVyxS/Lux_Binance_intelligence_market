from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json
from pathlib import Path

import pytest

from divatrading.exchange.binance.models import SymbolInfo
from divatrading.market_data.klines import INTERVAL_MILLISECONDS, Kline
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.strategy.scalping_market_data import ScalpingMarketDataAdapter
from divatrading.strategy.scalping_market_structure import (
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureEngine,
)
from divatrading.strategy.scalping_order_block_formation import (
    ScalpingOrderBlockFormationConfig,
    ScalpingOrderBlockFormationEngine,
    ScalpingOrderBlockFormationResult,
)
from divatrading.strategy.scalping_order_block_lifecycle import (
    ScalpingOrderBlockLifecycleConfig,
    ScalpingOrderBlockLifecycleCapacityError,
    ScalpingOrderBlockLifecycleContinuityError,
    ScalpingOrderBlockLifecycleEngine,
    ScalpingOrderBlockLifecycleInputError,
)

NOW = 1_800_000_000_000
BULL = [
    ("102.0", "105.0", "101.0", "103.0"),
    ("104.0", "110.0", "100.0", "108.0"),
    ("106.0", "108.0", "102.0", "105.0"),
    ("109.0", "112.0", "104.0", "111.0"),
]
BEAR = BULL + [("100.0", "111.0", "98.0", "99.0")]
NO_TOUCH = ("111.0", "114.0", "109.0", "112.0")
TOUCH_EDGE = ("109.0", "110.0", "108.0", "109.0")
PARTIAL = ("106.0", "109.0", "105.0", "107.0")
FULL_AND_INVALID = ("103.0", "107.0", "101.0", "105.0")


def instrument(symbol="BTCUSDT"):
    payload = json.loads((Path(__file__).parent / "fixtures" / "exchange_info_valid.json").read_text())
    return SymbolInfo.from_payload(next(item for item in payload["symbols"] if item["symbol"] == symbol))


def candle(interval, open_time, values, symbol="BTCUSDT"):
    op, hi, lo, cl = values
    span = INTERVAL_MILLISECONDS[interval]
    return Kline.from_binance_row(
        [open_time, op, hi, lo, cl, "10", open_time + span - 1, "1000", 10, "5", "500", "0"],
        symbol=symbol, interval=interval, source_endpoint="https://fixture/klines",
    )


def view_for(*, m1_values=None, m5_values=None, m15_values=None, now_ms=NOW, symbol="BTCUSDT"):
    series = []
    for interval, values in (("1m", m1_values), ("5m", m5_values), ("15m", m15_values)):
        if values is None:
            continue
        span = INTERVAL_MILLISECONDS[interval]
        last_open = (now_ms // span - 1) * span
        first_open = last_open - (len(values) - 1) * span
        rows = tuple(candle(interval, first_open + i * span, row, symbol) for i, row in enumerate(values))
        series.append(KlineSeriesInput(
            symbol=symbol, interval=interval, candles=rows,
            source_observed_at_ms=now_ms - 100, source_healthy=True, source_complete=True,
        ))
    return ScalpingMarketDataAdapter().build_view(
        symbol=symbol, now_ms=now_ms, symbol_info=instrument(symbol), kline_series=tuple(series)
    )


def structure_for(view):
    return ScalpingMarketStructureEngine(config=ScalpingMarketStructureConfig(
        swing_left_bars=1, swing_right_bars=1, internal_left_bars=1, internal_right_bars=1,
    )).process(view)


def formation_for(view):
    return ScalpingOrderBlockFormationEngine(config=ScalpingOrderBlockFormationConfig()).process(
        structure_for(view), view
    )


def m1_candidate(formation):
    tf = formation.timeframe("1m")
    assert tf is not None and tf.candidates
    return next(item for item in tf.candidates if item.direction == 1 and item.structure_layer == "SWING")


def only_candidate(formation, candidate):
    timeframes = tuple(
        replace(item, candidates=(candidate,) if item.timeframe == candidate.timeframe else ())
        for item in formation.timeframes
    )
    return ScalpingOrderBlockFormationResult(formation.symbol, formation.captured_at_ms, timeframes)


def test_candidate_starts_candidate_then_activates_on_first_post_break_bar():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "ACTIVE_FRESH"
    assert item.age_bars == 1
    assert [x.transition for x in result.timeframe("1m").traces if x.candidate_id == candidate.candidate_id] == [
        "CANDIDATE_CREATED", "ACTIVATED"
    ]


def test_touch_at_entry_edge_is_touched_but_not_mitigated():
    rows = BULL + [TOUCH_EDGE]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "TOUCHED"
    assert item.first_touch_time_ms == view.m1.candles[-1].close_time_ms
    assert item.maximum_mitigation_depth_ratio == 0
    assert item.mitigation_time_ms is None


def test_partial_mitigation_records_depth_without_fill_or_consumption():
    rows = BULL + [PARTIAL]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "MITIGATED"
    assert item.maximum_mitigation_depth_ratio == Decimal("0.5")
    assert item.maximum_mitigation_price == Decimal("105.0")
    assert item.is_filled is False and item.is_consumed is False
    assert item.to_dict()["filled"] is False and item.to_dict()["consumed"] is False


def test_full_penetration_then_wick_invalidation_records_ordered_evidence():
    rows = BULL + [FULL_AND_INVALID]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    tf = result.timeframe("1m")
    item = next(x for x in tf.order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "INVALIDATED"
    assert item.maximum_mitigation_depth_ratio == Decimal("1")
    assert item.invalidation_price == Decimal("101.0")
    assert item.invalidation_reason == "WICK_BEYOND_DISTAL_OB_BOUNDARY"
    transitions = [x.transition for x in tf.traces if x.candidate_id == candidate.candidate_id]
    assert transitions[-2:] == ["MITIGATION_STARTED", "INVALIDATED"]


@pytest.mark.parametrize("boundary,expected", [("STRICT", "MITIGATED"), ("INCLUSIVE", "INVALIDATED")])
def test_wick_invalidation_exact_boundary_strictness(boundary, expected):
    exact_bottom = ("103.0", "107.0", "102.0", "104.0")
    rows = BULL + [exact_bottom]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(
        invalidation_mode="WICK", invalidation_boundary=boundary,
    ))
    result = engine.process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == expected


@pytest.mark.parametrize("boundary,close,expected", [
    ("STRICT", "102.0", "MITIGATED"),
    ("INCLUSIVE", "102.0", "INVALIDATED"),
    ("STRICT", "101.0", "INVALIDATED"),
])
def test_close_invalidation_uses_close_not_wick(boundary, close, expected):
    row = ("103.0", "107.0", "101.0", close)
    rows = BULL + [row]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(
        invalidation_mode="CLOSE", invalidation_boundary=boundary,
    ))
    result = engine.process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == expected


def test_gap_completely_beyond_zone_invalidates_without_inventing_touch_or_depth():
    gap_below = ("100.0", "101.0", "99.0", "100.0")
    rows = BULL + [gap_below]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "INVALIDATED"
    assert item.first_touch_time_ms is None
    assert item.maximum_mitigation_depth_ratio == 0


def test_expiry_uses_source_timeframe_bars_and_expires_after_inclusive_age_limit():
    rows = BULL + [NO_TOUCH, NO_TOUCH, NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(max_age_bars=2))
    result = engine.process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "EXPIRED"
    assert item.age_bars == 3
    assert item.expiry_reason == "SOURCE_TIMEFRAME_AGE_EXCEEDED"


def test_age_is_counted_in_5m_source_bars_not_m1_bars():
    m1 = BULL + [NO_TOUCH] * 7
    m5 = BULL + [NO_TOUCH, NO_TOUCH]
    view = view_for(m1_values=m1, m5_values=m5)
    formation = formation_for(view)
    candidate = next(x for x in formation.timeframe("5m").candidates if x.direction == 1 and x.structure_layer == "SWING")
    result = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(max_age_bars=2)).process(
        only_candidate(formation, candidate), view
    )
    item = next(x for x in result.timeframe("5m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.age_bars == 2
    assert item.status == "ACTIVE_FRESH"


def test_candidate_break_candle_must_match_same_capture_kline():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    bad = replace(candidate, break_close=Decimal("110.0"))
    with pytest.raises(ScalpingOrderBlockLifecycleInputError):
        ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, bad), view)


def test_candidate_id_conflict_is_rejected():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    engine.process(only_candidate(formation, candidate), view)
    changed = replace(candidate, reason_codes=candidate.reason_codes + ("CONFLICT",))
    next_view = view_for(m1_values=rows + [NO_TOUCH], m5_values=rows + [NO_TOUCH], now_ms=NOW + 60_000)
    changed_formation = only_candidate(replace(formation, captured_at_ms=next_view.captured_at_ms), changed)
    with pytest.raises(ScalpingOrderBlockLifecycleInputError):
        engine.process(changed_formation, next_view)


def test_duplicate_candidate_delivery_is_idempotent_and_does_not_duplicate_traces():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    first = engine.process(only_candidate(formation, candidate), view)
    second = engine.process(only_candidate(formation, candidate), view)
    assert first.to_jsonl() == second.to_jsonl()


def test_m1_and_m5_lifecycle_are_independent_and_m15_is_advisory_only():
    m1 = BULL + [PARTIAL]
    m5 = BULL + [NO_TOUCH]
    m15 = BULL
    view = view_for(m1_values=m1, m5_values=m5, m15_values=m15)
    formation = formation_for(view)
    result = ScalpingOrderBlockLifecycleEngine().process(formation, view)
    m1_ob = next(x for x in result.timeframe("1m").order_blocks if x.candidate.direction == 1 and x.candidate.structure_layer == "SWING")
    m5_ob = next(x for x in result.timeframe("5m").order_blocks if x.candidate.direction == 1 and x.candidate.structure_layer == "SWING")
    assert m1_ob.status == "MITIGATED"
    assert m5_ob.status == "ACTIVE_FRESH"
    assert result.timeframe("15m").status == "ADVISORY_ONLY"
    assert result.timeframe("15m").order_blocks == ()


def test_overlapping_candidates_remain_distinct():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    tf = formation.timeframe("1m")
    candidates = tuple(x for x in tf.candidates if x.direction == 1)
    assert len(candidates) >= 1
    # If both swing and internal qualify, neither is coalesced by the lifecycle.
    result = ScalpingOrderBlockLifecycleEngine().process(formation, view)
    actual = [x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id in {c.candidate_id for c in candidates}]
    assert len(actual) == len(candidates)


def test_revised_processed_candle_fails_closed():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    engine.process(only_candidate(formation, candidate), view)
    revised = list(rows)
    revised[-1] = ("111.0", "115.0", "109.0", "113.0")
    revised_view = view_for(m1_values=revised + [NO_TOUCH], m5_values=rows + [NO_TOUCH], now_ms=NOW + 60_000)
    revised_formation = replace(formation, captured_at_ms=revised_view.captured_at_ms)
    with pytest.raises(ScalpingOrderBlockLifecycleContinuityError):
        engine.process(revised_formation, revised_view)


def test_missing_or_gapped_source_is_unavailable_and_does_not_advance_state():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    first = engine.process(only_candidate(formation, candidate), view)
    next_rows = rows + [NO_TOUCH]
    span = INTERVAL_MILLISECONDS["1m"]
    last_open = (NOW // span - 1) * span
    candles = tuple(candle("1m", last_open - (len(next_rows) - 1 - i) * span, row) for i, row in enumerate(next_rows))
    bad_series = KlineSeriesInput(
        symbol="BTCUSDT", interval="1m", candles=candles,
        source_observed_at_ms=NOW + 60_000 - 100, source_healthy=True,
        source_complete=False, missing_open_times_ms=(candles[-1].open_time_ms,),
    )
    good5 = KlineSeriesInput(
        symbol="BTCUSDT", interval="5m", candles=view.m5.candles + (candle("5m", view.m5.candles[-1].open_time_ms + INTERVAL_MILLISECONDS["5m"], NO_TOUCH),),
        source_observed_at_ms=NOW + 60_000 - 100, source_healthy=True, source_complete=True,
    )
    bad_view = ScalpingMarketDataAdapter().build_view(
        symbol="BTCUSDT", now_ms=NOW + 60_000, symbol_info=instrument(), kline_series=(bad_series, good5)
    )
    bad_formation = ScalpingOrderBlockFormationResult("BTCUSDT", bad_view.captured_at_ms, ())
    second = engine.process(bad_formation, bad_view)
    assert second.timeframe("1m").status == "UNAVAILABLE"
    assert second.timeframe("1m").order_blocks == first.timeframe("1m").order_blocks


def test_reset_clears_symbol_and_timeframe_state():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    engine.process(only_candidate(formation, candidate), view)
    engine.reset(symbol="BTCUSDT", timeframe="1m")
    empty = ScalpingOrderBlockFormationResult("BTCUSDT", view.captured_at_ms, ())
    result = engine.process(empty, view)
    assert result.timeframe("1m").order_blocks == ()


def test_lifecycle_jsonl_is_deterministic_and_contains_no_fill_claim():
    rows = BULL + [PARTIAL]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    first = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    second = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    assert first.to_jsonl() == second.to_jsonl()
    assert '"filled":false' in first.to_jsonl()
    assert '"consumed":false' in first.to_jsonl()


def test_config_rejects_invalid_modes_and_unbounded_age():
    with pytest.raises(ValueError):
        ScalpingOrderBlockLifecycleConfig(invalidation_mode="BODY")
    with pytest.raises(ValueError):
        ScalpingOrderBlockLifecycleConfig(invalidation_boundary="FUZZY")
    with pytest.raises(ValueError):
        ScalpingOrderBlockLifecycleConfig(max_age_bars=0)


def test_timeframe_result_has_no_m15_lifecycle_candidates_even_when_context_ready():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows, m15_values=rows)
    formation = formation_for(view)
    result = ScalpingOrderBlockLifecycleEngine().process(formation, view)
    assert result.timeframe("15m").status == "ADVISORY_ONLY"
    assert result.timeframe("15m").order_blocks == ()
    assert result.timeframe("15m").traces == ()


def test_bearish_ob_uses_bottom_entry_side_and_upward_mitigation_depth():
    rows = BEAR + [("102.0", "107.0", "100.0", "105.0")]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = next(x for x in formation.timeframe("1m").candidates if x.direction == -1 and x.structure_layer == "SWING")
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "MITIGATED"
    assert item.maximum_mitigation_depth_ratio == Decimal("0.375")
    assert item.maximum_mitigation_price == Decimal("107.0")


def test_bearish_wick_beyond_top_invalidates_after_recording_full_depth():
    rows = BEAR + [("110.0", "113.0", "108.0", "111.0")]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = next(x for x in formation.timeframe("1m").candidates if x.direction == -1 and x.structure_layer == "SWING")
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "INVALIDATED"
    assert item.maximum_mitigation_depth_ratio == Decimal("1")
    assert item.invalidation_price == Decimal("113.0")


def test_touch_time_is_first_confirmed_bar_and_later_depth_updates_do_not_replace_it():
    rows = BULL + [TOUCH_EDGE, PARTIAL]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.first_touch_bar_open_time_ms == view.m1.candles[-2].open_time_ms
    assert item.first_touch_time_ms == view.m1.candles[-2].close_time_ms
    assert item.mitigation_time_ms == view.m1.candles[-1].close_time_ms
    assert item.maximum_mitigation_depth_ratio == Decimal("0.5")


def test_new_candidate_late_after_lifecycle_has_advanced_fails_closed():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine()
    engine.process(ScalpingOrderBlockFormationResult("BTCUSDT", view.captured_at_ms, ()), view)
    next_view = view_for(m1_values=rows + [NO_TOUCH], m5_values=rows + [NO_TOUCH], now_ms=NOW + 60_000)
    late_formation = only_candidate(replace(formation, captured_at_ms=next_view.captured_at_ms), candidate)
    with pytest.raises(ScalpingOrderBlockLifecycleContinuityError):
        engine.process(late_formation, next_view)


def test_source_candle_revision_is_rejected_even_when_break_candle_matches():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    revised = replace(candidate, source_close=Decimal("106.0"))
    with pytest.raises(ScalpingOrderBlockLifecycleInputError):
        ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, revised), view)


def test_same_bar_touch_and_invalidation_trace_touch_before_terminal_transition():
    row = ("103.0", "107.0", "102.0", "104.0")
    rows = BULL + [row]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    engine = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(
        invalidation_mode="WICK", invalidation_boundary="INCLUSIVE",
    ))
    result = engine.process(only_candidate(formation, candidate), view)
    transitions = [x.transition for x in result.timeframe("1m").traces if x.candidate_id == candidate.candidate_id]
    assert transitions[-3:] == ["FIRST_ZONE_TOUCH", "MITIGATION_STARTED", "INVALIDATED"]


def test_terminal_lifecycle_records_are_evicted_oldest_first_to_keep_capacity_bounded():
    invalidates = ("107.0", "109.0", "101.0", "103.0")
    initial_rows = BULL + [invalidates]
    initial_view = view_for(m1_values=initial_rows, m5_values=initial_rows)
    initial_formation = formation_for(initial_view)
    base = m1_candidate(initial_formation)
    copies = tuple(replace(base, candidate_id=f"{i:024x}", event_id=f"event-{i}") for i in range(8))
    tf_results = tuple(
        replace(item, candidates=copies if item.timeframe == "1m" else ())
        for item in initial_formation.timeframes
    )
    first_formation = ScalpingOrderBlockFormationResult("BTCUSDT", initial_view.captured_at_ms, tf_results)
    engine = ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(
        max_order_blocks_per_timeframe=8,
    ))
    first = engine.process(first_formation, initial_view)
    assert len(first.timeframe("1m").order_blocks) == 8
    assert all(item.status == "INVALIDATED" for item in first.timeframe("1m").order_blocks)

    next_break = ("109.0", "113.0", "108.0", "112.0")
    next_rows = initial_rows + [next_break]
    next_view = view_for(m1_values=next_rows, m5_values=initial_rows, now_ms=NOW + 60_000)
    source = next_view.m1.candles[-2]
    broken = next_view.m1.candles[-1]
    fresh = replace(
        base,
        candidate_id="f" * 24,
        event_id="new-event-after-terminal-eviction",
        source_bar_index=4,
        source_open_time_ms=source.open_time_ms,
        source_confirmation_time_ms=source.close_time_ms,
        source_open=source.open,
        source_high=source.high,
        source_low=source.low,
        source_close=source.close,
        zone_top=source.high,
        zone_bottom=source.low,
        broken_structure_level=Decimal("110.0"),
        break_bar_index=5,
        break_bar_open_time_ms=broken.open_time_ms,
        break_confirmation_time_ms=broken.close_time_ms,
        break_open=broken.open,
        break_high=broken.high,
        break_low=broken.low,
        break_close=broken.close,
        displacement_leg_id="new-displacement-leg",
    )
    empty_tf = tuple(replace(item, candidates=(fresh,) if item.timeframe == "1m" else ()) for item in tf_results)
    second_formation = ScalpingOrderBlockFormationResult("BTCUSDT", next_view.captured_at_ms, empty_tf)
    second = engine.process(second_formation, next_view)
    items = second.timeframe("1m").order_blocks
    assert len(items) == 8
    assert sum(item.candidate.candidate_id == fresh.candidate_id for item in items) == 1
    assert sum(item.status == "INVALIDATED" for item in items) == 7
    assert all(item.candidate.candidate_id != "0" * 24 for item in items)


def test_capacity_fails_closed_when_all_retained_order_blocks_are_nonterminal():
    rows = BULL
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    base = m1_candidate(formation)
    copies = tuple(replace(base, candidate_id=f"{i:024x}", event_id=f"event-{i}") for i in range(9))
    tf_results = tuple(replace(item, candidates=copies if item.timeframe == "1m" else ()) for item in formation.timeframes)
    oversized = ScalpingOrderBlockFormationResult("BTCUSDT", view.captured_at_ms, tf_results)
    with pytest.raises(ScalpingOrderBlockLifecycleCapacityError):
        ScalpingOrderBlockLifecycleEngine(config=ScalpingOrderBlockLifecycleConfig(
            max_order_blocks_per_timeframe=8,
        )).process(oversized, view)


def test_break_bar_overlap_is_not_counted_as_post_formation_touch():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    candidate = m1_candidate(formation)
    break_candle = view.m1.candles[candidate.break_bar_index]
    assert break_candle.low <= candidate.zone_top and break_candle.high >= candidate.zone_bottom
    result = ScalpingOrderBlockLifecycleEngine().process(only_candidate(formation, candidate), view)
    item = next(x for x in result.timeframe("1m").order_blocks if x.candidate.candidate_id == candidate.candidate_id)
    assert item.status == "ACTIVE_FRESH"
    assert item.first_touch_time_ms is None


def test_mtf_preflight_is_atomic_when_second_timeframe_candidate_is_invalid():
    rows = BULL + [NO_TOUCH]
    view = view_for(m1_values=rows, m5_values=rows)
    formation = formation_for(view)
    m1 = m1_candidate(formation)
    m5 = next(x for x in formation.timeframe("5m").candidates if x.direction == 1 and x.structure_layer == "SWING")
    bad_m5 = replace(m5, break_close=Decimal("110.5"))
    mixed = tuple(
        replace(item, candidates=(m1,) if item.timeframe == "1m" else ((bad_m5,) if item.timeframe == "5m" else ()))
        for item in formation.timeframes
    )
    engine = ScalpingOrderBlockLifecycleEngine()
    with pytest.raises(ScalpingOrderBlockLifecycleContinuityError):
        engine.process(ScalpingOrderBlockFormationResult("BTCUSDT", view.captured_at_ms, mixed), view)
    clean = only_candidate(formation, m1)
    result = engine.process(clean, view)
    assert any(x.candidate.candidate_id == m1.candidate_id for x in result.timeframe("1m").order_blocks)
