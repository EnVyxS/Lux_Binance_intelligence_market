from __future__ import annotations

import pytest

from divatrading.cli import build_parser, main


def test_market_runtime_accepts_signal_only_with_kronos_shadow_flags():
    args = build_parser().parse_args([
        "market-runtime", "--mode", "MANUAL", "--symbols", "BTCUSDT", "--max-symbols", "1",
        "--telegram-signals", "--kronos-shadow", "--kronos-context-bars", "512",
        "--kronos-minimum-input-bars", "64", "--kronos-horizon-bars", "6",
    ])
    assert args.telegram_signals is True
    assert args.kronos_shadow is True
    assert args.kronos_context_bars == 512
    assert args.kronos_horizon_bars == 6


def test_kronos_shadow_requires_signal_publisher_before_runtime_starts():
    with pytest.raises(SystemExit):
        main([
            "market-runtime", "--mode", "MANUAL", "--symbols", "BTCUSDT",
            "--kronos-shadow",
        ])


def test_signal_history_cli_limit_is_bounded_to_store_contract():
    with pytest.raises(SystemExit):
        main(["signal-history", "--limit", "501"])
