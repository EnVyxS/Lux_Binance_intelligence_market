from __future__ import annotations

import hashlib
import hmac
import json
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlencode

import httpx
import pytest

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.execution.binance_private import (
    BinancePrivateApiError,
    BinancePrivateRestClient,
    BinancePrivateTransportError,
    TESTNET_BASE_URL,
)
from divatrading.execution.test_order import (
    TestOrderSpec,
    TestOrderValidationError,
    prepare_test_order,
)
from divatrading.strategy.scalping_market_data import InstrumentSpec

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def _instrument(symbol: str = "BTCUSDT") -> InstrumentSpec:
    payload = json.loads(FIXTURE.read_text(encoding="utf-8"))
    snapshot = parse_exchange_info(payload, source_endpoint=f"{TESTNET_BASE_URL}/fapi/v1/exchangeInfo")
    info = snapshot.get_symbol(symbol)
    assert info is not None
    return InstrumentSpec.from_symbol_info(info)


def test_prepare_market_test_order_uses_market_lot_size_and_exact_decimal_string():
    prepared = prepare_test_order(
        TestOrderSpec(
            symbol="btcusdt", side="buy", order_type="market", quantity="0.010",
            position_mode="ONE_WAY",
        ),
        _instrument(),
    )
    assert prepared.params == {
        "symbol": "BTCUSDT", "side": "BUY", "type": "MARKET",
        "quantity": "0.010", "positionSide": "BOTH",
    }
    assert prepared.quantity_step == "0.001"
    assert prepared.notional_reference_usdt is None
    assert prepared.summary()["notional_reference_usdt"] == "EXCHANGE_AUTHORITATIVE_FOR_MARKET"
    assert "price" not in prepared.params
    assert "timeInForce" not in prepared.params


def test_prepare_limit_test_order_enforces_tick_step_and_symbol_tif():
    prepared = prepare_test_order(
        TestOrderSpec(
            symbol="BTCUSDT", side="SELL", order_type="LIMIT", quantity="0.002",
            price="50000.10", time_in_force="GTC", position_mode="ONE_WAY",
        ),
        _instrument(),
    )
    assert prepared.params == {
        "symbol": "BTCUSDT", "side": "SELL", "type": "LIMIT", "quantity": "0.002",
        "positionSide": "BOTH", "price": "50000.10", "timeInForce": "GTC",
    }
    assert prepared.price_tick == "0.10"


def test_prepare_hedge_test_order_requires_explicit_position_side():
    instrument = _instrument()
    with pytest.raises(TestOrderValidationError, match="required in Hedge Mode"):
        prepare_test_order(
            TestOrderSpec(
                symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity="0.001",
                position_mode="HEDGE",
            ), instrument,
        )
    prepared = prepare_test_order(
        TestOrderSpec(
            symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity="0.001",
            position_mode="HEDGE", position_side="LONG",
        ), instrument,
    )
    assert prepared.params["positionSide"] == "LONG"


@pytest.mark.parametrize(
    "spec,match",
    [
        (dict(quantity="0.0015", order_type="MARKET"), "step size"),
        (dict(quantity="0.0005", order_type="MARKET"), "step size"),
        (dict(quantity="0.001", order_type="LIMIT", price="50000.01"), "tick size"),
        (dict(quantity="0.001", order_type="LIMIT", price="50000.10", time_in_force="RPI"), "not enabled"),
        (dict(quantity="0.001", order_type="LIMIT", price="50000.10", time_in_force="GTD"), "not supported by this Stage B"),
    ],
)
def test_prepare_test_order_rejects_invalid_exchange_filter_values(spec, match):
    kwargs = {"symbol": "BTCUSDT", "side": "BUY", "position_mode": "ONE_WAY", **spec}
    with pytest.raises(TestOrderValidationError, match=match):
        prepare_test_order(TestOrderSpec(**kwargs), _instrument())


def test_prepare_test_order_rejects_inactive_instrument_and_unsupported_order_type():
    inactive = InstrumentSpec(
        symbol="BTCUSDT", base_asset="BTC", quote_asset="USDT", margin_asset="USDT",
        contract_type="PERPETUAL", status="BREAK", tick_size=Decimal("0.1"),
        min_price=Decimal("0.1"), max_price=Decimal("1000000"), lot_step_size=Decimal("0.001"),
        min_qty=Decimal("0.001"), max_qty=Decimal("1000"), market_lot_step_size=Decimal("0.001"),
        market_min_qty=Decimal("0.001"), market_max_qty=Decimal("500"), min_notional=Decimal("5"),
        order_types=("LIMIT", "MARKET"), time_in_force=("GTC",), price_precision=1,
        quantity_precision=3,
    )
    with pytest.raises(TestOrderValidationError, match="active USDT-margined"):
        prepare_test_order(
            TestOrderSpec(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity="0.001",
                          position_mode="ONE_WAY"),
            inactive,
        )
    with pytest.raises(TestOrderValidationError, match="only supports LIMIT and MARKET"):
        TestOrderSpec(symbol="BTCUSDT", side="BUY", order_type="STOP_MARKET", quantity="0.001",
                      position_mode="ONE_WAY")


def test_signed_test_order_uses_demo_host_endpoint_and_hmac_signature():
    seen: list[httpx.Request] = []
    api_key = "local-demo-key"
    api_secret = "local-demo-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json={"orderId": 12345, "symbol": "BTCUSDT", "status": "NEW"})

    client = BinancePrivateRestClient(
        api_key, api_secret, environment="TESTNET",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
        wall_clock_ms=lambda: 1_800_000_000_000,
    )
    try:
        response = client.new_test_order(
            symbol="BTCUSDT", side="BUY", type="MARKET", quantity=Decimal("0.001"), positionSide="BOTH",
        )
    finally:
        client.close()

    assert response["orderId"] == 12345
    assert len(seen) == 1
    request = seen[0]
    assert request.method == "POST"
    assert request.url.scheme == "https"
    assert request.url.host == "demo-fapi.binance.com"
    assert request.url.path == "/fapi/v1/order/test"
    assert request.headers["X-MBX-APIKEY"] == api_key
    query = parse_qs(request.url.query.decode())
    signature = query.pop("signature")[0]
    canonical = urlencode([(key, values[0]) for key, values in query.items()])
    expected = hmac.new(api_secret.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    assert signature == expected
    assert query["timestamp"] == ["1800000000000"]
    assert "signature" not in response


def test_binance_api_errors_redact_key_secret_and_signature_from_message():
    api_key = "demo-key-that-must-not-leak"
    api_secret = "demo-secret-that-must-not-leak"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(400, json={
            "code": -1022,
            "msg": f"bad {api_key} {api_secret} signature=abcdef012345",
        })

    client = BinancePrivateRestClient(
        api_key, api_secret, environment="TESTNET",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )
    try:
        with pytest.raises(BinancePrivateApiError) as caught:
            client.new_test_order(symbol="BTCUSDT", side="BUY", type="MARKET", quantity="0.001")
    finally:
        client.close()
    message = str(caught.value)
    assert "-1022" in message
    assert api_key not in message
    assert api_secret not in message
    assert "abcdef012345" not in message
    assert "[REDACTED]" in message


def test_transport_error_does_not_echo_signed_url_or_signature():
    captured: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request.url.query.decode())
        raise httpx.ConnectError("connection failed", request=request)

    client = BinancePrivateRestClient(
        "demo-api-key", "demo-api-secret", environment="TESTNET",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )
    try:
        with pytest.raises(BinancePrivateTransportError) as caught:
            client.new_test_order(symbol="BTCUSDT", side="BUY", type="MARKET", quantity="0.001")
    finally:
        client.close()
    assert "signature=" in captured[0]
    assert "signature=" not in str(caught.value)
    assert "demo-api-secret" not in str(caught.value)
