from __future__ import annotations

import httpx
import pytest

from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.market_data.history import HistoricalKlineService, KlinePaginationError


def kline_row(open_time: int):
    return [
        open_time, "100", "102", "99", "101", "1.2",
        open_time + 59_999, "121.2", 7, "0.5", "50.5", "0",
    ]


def build_client(handler):
    http_client = httpx.Client(transport=httpx.MockTransport(handler))
    return BinanceUsdMFuturesRestClient(base_url="https://fixture.local", http_client=http_client)


def test_pagination_uses_next_interval_open_without_duplicate_or_skip():
    requested_starts = []

    def handler(request):
        requested_starts.append(int(request.url.params["startTime"]))
        page_start = int(request.url.params["startTime"])
        if page_start == 0:
            return httpx.Response(200, json=[kline_row(0), kline_row(60_000)])
        if page_start == 120_000:
            return httpx.Response(200, json=[kline_row(120_000), kline_row(180_000)])
        return httpx.Response(200, json=[])

    client = build_client(handler)
    try:
        batch = HistoricalKlineService(
            client, page_limit=2, max_pages=5, min_request_interval_seconds=0
        ).fetch(
            symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=180_000
        )
    finally:
        client.close()

    assert requested_starts == [0, 120_000]
    assert [c.open_time_ms for c in batch.candles] == [0, 60_000, 120_000, 180_000]
    assert len({c.open_time_ms for c in batch.candles}) == 4
    assert batch.pages_fetched == 2
    assert batch.complete is True
    assert batch.next_start_time_ms is None
    assert batch.missing_open_times_ms == ()


def test_max_page_cap_returns_explicit_resume_cursor():
    requested_starts = []

    def handler(request):
        requested_starts.append(int(request.url.params["startTime"]))
        return httpx.Response(200, json=[kline_row(0), kline_row(60_000)])

    client = build_client(handler)
    try:
        batch = HistoricalKlineService(
            client, page_limit=2, max_pages=1, min_request_interval_seconds=0
        ).fetch(
            symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=300_000
        )
    finally:
        client.close()

    assert requested_starts == [0]
    assert batch.complete is False
    assert batch.next_start_time_ms == 120_000
    assert len(batch.candles) == 2


def test_empty_page_finishes_without_fabricating_candles():
    client = build_client(lambda request: httpx.Response(200, json=[]))
    try:
        batch = HistoricalKlineService(
            client, min_request_interval_seconds=0
        ).fetch(
            symbol="BTCUSDT", interval="5m", start_time_ms=0, end_time_ms=300_000
        )
    finally:
        client.close()
    assert batch.complete is True
    assert batch.candles == ()


def test_missing_intervals_are_reported_not_synthesized():
    def handler(request):
        return httpx.Response(200, json=[kline_row(0), kline_row(120_000)])

    client = build_client(handler)
    try:
        batch = HistoricalKlineService(
            client, page_limit=10, min_request_interval_seconds=0
        ).fetch(
            symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=120_000
        )
    finally:
        client.close()
    assert [c.open_time_ms for c in batch.candles] == [0, 120_000]
    assert batch.missing_open_times_ms == (60_000,)


def test_duplicate_or_out_of_order_rows_fail_closed():
    def handler(request):
        return httpx.Response(200, json=[kline_row(60_000), kline_row(0)])

    client = build_client(handler)
    try:
        with pytest.raises(KlinePaginationError, match="duplicate or out-of-order"):
            HistoricalKlineService(
                client, page_limit=10, min_request_interval_seconds=0
            ).fetch(
                symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=60_000
            )
    finally:
        client.close()


def test_constructor_rejects_unbounded_or_invalid_configuration():
    client = build_client(lambda request: httpx.Response(200, json=[]))
    try:
        with pytest.raises(ValueError):
            HistoricalKlineService(client, page_limit=1501)
        with pytest.raises(ValueError):
            HistoricalKlineService(client, max_pages=101)
        with pytest.raises(ValueError):
            HistoricalKlineService(client, min_request_interval_seconds=-0.1)
    finally:
        client.close()


def test_inter_page_request_pacing_applies_minimum_delay():
    now = {"value": 0.0}
    sleeps = []
    calls = {"value": 0}

    def fake_sleep(seconds):
        sleeps.append(seconds)
        now["value"] += seconds

    def handler(request):
        calls["value"] += 1
        if calls["value"] == 1:
            return httpx.Response(200, json=[kline_row(0)])
        return httpx.Response(200, json=[])

    client = build_client(handler)
    try:
        batch = HistoricalKlineService(
            client,
            page_limit=1,
            max_pages=3,
            min_request_interval_seconds=0.1,
            sleep=fake_sleep,
            monotonic=lambda: now["value"],
        ).fetch(symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=60_000)
    finally:
        client.close()

    assert calls["value"] == 2
    assert sleeps == [pytest.approx(0.1)]
    assert batch.complete is True


def test_server_response_cannot_exceed_requested_page_limit():
    def handler(request):
        return httpx.Response(200, json=[kline_row(0), kline_row(60_000)])

    client = build_client(handler)
    try:
        with pytest.raises(KlinePaginationError, match="more rows than the requested page limit"):
            HistoricalKlineService(
                client, page_limit=1, min_request_interval_seconds=0
            ).fetch(
                symbol="BTCUSDT", interval="1m", start_time_ms=0, end_time_ms=60_000
            )
    finally:
        client.close()
