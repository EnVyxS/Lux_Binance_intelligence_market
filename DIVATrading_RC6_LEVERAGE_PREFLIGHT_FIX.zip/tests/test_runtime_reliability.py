from __future__ import annotations

import pytest

from divatrading.core.reliability import (
    ProcessLock, ProcessLockError, WorkerWatchdog, classify_discrepancy,
)


def test_process_lock_excludes_second_owner_and_releases(tmp_path):
    path = tmp_path / "runtime.lock"
    first = ProcessLock(path).acquire()
    try:
        with pytest.raises(ProcessLockError):
            ProcessLock(path).acquire()
    finally:
        first.release()
    with ProcessLock(path):
        pass


def test_unknown_discrepancy_fails_closed():
    policy = classify_discrepancy("new_exchange_mismatch")
    assert policy.category == "UNKNOWN_HARD_STOP"
    assert policy.halt_entries and policy.halt_management and policy.operator_action_required


def test_discrepancy_categories():
    assert classify_discrepancy("UNMANAGED_EXCHANGE_POSITION").category == "OPERATOR_ONLY"
    assert classify_discrepancy("STREAM_RECONNECTED").category == "RECOVERABLE"
    assert classify_discrepancy("POSITION_MISSING_PROTECTION").category == "HARD_STOP"


def test_watchdog_marks_stale_worker():
    now = [10.0]
    watchdog = WorkerWatchdog(stale_after_seconds=5, clock=lambda: now[0])
    watchdog.heartbeat("BTCUSDT")
    assert watchdog.stale_workers() == ()
    now[0] = 16.0
    assert watchdog.stale_workers() == ("BTCUSDT",)
    watchdog.heartbeat("BTCUSDT")
    assert watchdog.stale_workers() == ()
