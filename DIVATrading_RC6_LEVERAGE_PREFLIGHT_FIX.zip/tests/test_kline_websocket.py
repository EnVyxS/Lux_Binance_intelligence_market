from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.market_data.websocket import (
    BINANCE_UM_MARKET_WS_ENDPOINT,
    BinanceKlineWebSocketFeed,
    FeedQueueFullError,
    KlineWebSocketParseError,
    KlineWebSocketProtocolError,
    WebSocketReconnectExhausted,
    normalize_subscriptions,
    parse_kline_stream_message,
)


FIXTURE_DIR = Path(__file__).parent / "fixtures"
FORMING_EVENT = (FIXTURE_DIR / "ws_kline_forming.json").read_text(encoding="utf-8")


def _closed_event() -> str:
    payload = json.loads(FORMING_EVENT)
    payload["data"]["k"]["x"] = True
    payload["data"]["k"]["c"] = "100003.5"
    payload["data"]["k"]["h"] = "100004.0"
    return json.dumps(payload)


def test_normalize_subscriptions_uses_exact_symbols_and_deduplicates() -> None:
    symbols, intervals, streams = normalize_subscriptions(
        [" btcusdt ", "BTCUSDT", "ETHUSDT"], ["1m", "5m", "1m"]
    )
    assert symbols == ("BTCUSDT", "ETHUSDT")
    assert intervals == ("1m", "5m")
    assert streams == (
        "btcusdt@kline_1m",
        "btcusdt@kline_5m",
        "ethusdt@kline_1m",
        "ethusdt@kline_5m",
    )


@pytest.mark.parametrize(
    ("symbols", "intervals"),
    [([], ["1m"]), (["BTCUSDT"], []), (["BTC/USDT"], ["1m"]), (["BTCUSDT"], ["1h"])],
)
def test_normalize_subscriptions_rejects_invalid_inputs(symbols, intervals) -> None:
    with pytest.raises(ValueError):
        normalize_subscriptions(symbols, intervals)


def test_parse_forming_event_preserves_decimal_values_and_identity() -> None:
    received = datetime(2026, 11, 10, 0, 0, tzinfo=UTC)
    event = parse_kline_stream_message(
        FORMING_EVENT,
        allowed_symbols=("BTCUSDT",),
        allowed_intervals=("1m",),
        received_at_utc=received,
    )
    assert event is not None
    assert event.status == "FORMING"
    assert event.is_closed is False
    assert event.kline.symbol == "BTCUSDT"
    assert event.kline.interval == "1m"
    assert event.kline.exchange == "BINANCE_UM"
    assert event.kline.open == Decimal("100000.100000000000001")
    assert event.kline.volume == Decimal("12.345678900000000001")
    assert event.kline.source_endpoint == BINANCE_UM_MARKET_WS_ENDPOINT
    assert event.event_time_ms == 1760000045000
    assert event.received_at_utc == received


def test_parse_closed_event_is_explicitly_confirmed() -> None:
    event = parse_kline_stream_message(_closed_event())
    assert event is not None
    assert event.status == "CLOSED"
    assert event.is_closed is True


def test_parse_raw_event_without_combined_envelope() -> None:
    payload = json.loads(FORMING_EVENT)["data"]
    event = parse_kline_stream_message(json.dumps(payload))
    assert event is not None
    assert event.stream_name == "btcusdt@kline_1m"


def test_parse_binary_json_message() -> None:
    event = parse_kline_stream_message(FORMING_EVENT.encode("utf-8"))
    assert event is not None
    assert event.status == "FORMING"


def test_parse_subscription_acknowledgement_returns_none() -> None:
    assert parse_kline_stream_message('{"result":null,"id":1}') is None


def test_parse_binance_protocol_error_is_explicit() -> None:
    with pytest.raises(KlineWebSocketProtocolError):
        parse_kline_stream_message('{"code":-1100,"msg":"bad request"}')


@pytest.mark.parametrize(
    "mutate",
    [
        lambda p: p["data"].update(s="ETHUSDT"),
        lambda p: p["data"]["k"].update(x="false"),
        lambda p: p["data"]["k"].update(i="1h"),
        lambda p: p.update(stream="ethusdt@kline_1m"),
        lambda p: p["data"].pop("E"),
        lambda p: p["data"]["k"].pop("B"),
    ],
)
def test_parser_rejects_malformed_or_mismatched_events(mutate) -> None:
    payload = json.loads(FORMING_EVENT)
    mutate(payload)
    with pytest.raises(KlineWebSocketParseError):
        parse_kline_stream_message(json.dumps(payload), allowed_symbols=("BTCUSDT",))


def test_parser_rejects_unsubscribed_symbol_or_interval() -> None:
    with pytest.raises(KlineWebSocketParseError):
        parse_kline_stream_message(FORMING_EVENT, allowed_symbols=("ETHUSDT",))
    with pytest.raises(KlineWebSocketParseError):
        parse_kline_stream_message(FORMING_EVENT, allowed_intervals=("5m",))


def test_parser_requires_timezone_aware_receive_timestamp() -> None:
    with pytest.raises(KlineWebSocketParseError):
        parse_kline_stream_message(
            FORMING_EVENT, received_at_utc=datetime(2026, 11, 10, 0, 0)
        )


def test_feed_enforces_stream_queue_and_retry_caps() -> None:
    with pytest.raises(ValueError, match="exceeds configured cap"):
        BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"], intervals=["1m", "5m"], max_subscriptions=3
        )
    with pytest.raises(ValueError):
        BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], max_subscriptions=129)
    with pytest.raises(ValueError):
        BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], queue_capacity=8193)
    with pytest.raises(ValueError):
        BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], max_reconnect_attempts=21)


class _FakeWebSocket:
    def __init__(self, messages: list[str], stop_event: asyncio.Event, *, stop_on_send=False):
        self.messages = list(messages)
        self.stop_event = stop_event
        self.stop_on_send = stop_on_send
        self.sent: list[str] = []
        self.connected_seen_on_send: bool | None = None
        self.feed = None

    async def send(self, message: str) -> None:
        self.sent.append(message)
        if self.feed is not None:
            self.connected_seen_on_send = self.feed.is_connected
        if self.stop_on_send:
            self.stop_event.set()

    async def recv(self) -> str:
        if self.messages:
            message = self.messages.pop(0)
            if not self.messages:
                self.stop_event.set()
            return message
        await self.stop_event.wait()
        await asyncio.sleep(0)
        raise RuntimeError("recv called after stop")


class _FakeContext:
    def __init__(self, websocket):
        self.websocket = websocket
        self.closed = False

    async def __aenter__(self):
        return self.websocket

    async def __aexit__(self, exc_type, exc, tb):
        self.closed = True
        return False


class _FakeConnector:
    def __init__(self, contexts):
        self.contexts = list(contexts)
        self.calls: list[tuple[str, dict]] = []
        self.used_contexts = []

    def __call__(self, uri: str, **kwargs):
        self.calls.append((uri, kwargs))
        if not self.contexts:
            raise RuntimeError("No fake connection context remains")
        context = self.contexts.pop(0)
        self.used_contexts.append(context)
        return context



def test_run_sends_selected_subscription_and_emits_forming_and_closed_events() -> None:
    async def scenario():
        stop_event = asyncio.Event()
        websocket = _FakeWebSocket([FORMING_EVENT, _closed_event()], stop_event)
        context = _FakeContext(websocket)
        connector = _FakeConnector([context])
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"], intervals=["1m"], connector=connector
        )
        websocket.feed = feed
        await feed.run(stop_event)

        assert websocket.connected_seen_on_send is True
        assert feed.is_connected is False
        assert connector.calls[0][0] == BINANCE_UM_MARKET_WS_ENDPOINT
        assert connector.calls[0][1]["max_queue"] == 16
        assert connector.calls[0][1]["max_size"] == 64 * 1024
        request = json.loads(websocket.sent[0])
        assert request == {
            "method": "SUBSCRIBE",
            "params": ["btcusdt@kline_1m"],
            "id": 1,
        }
        assert context.closed is True
        assert feed.stats.connection_count == 1
        assert feed.stats.events_emitted == 2
        assert (await feed.get_event()).status == "FORMING"
        assert (await feed.get_event()).status == "CLOSED"

    asyncio.run(scenario())


def test_run_skips_malformed_message_and_counts_it() -> None:
    async def scenario():
        stop_event = asyncio.Event()
        websocket = _FakeWebSocket(["not-json", FORMING_EVENT], stop_event)
        connector = _FakeConnector([_FakeContext(websocket)])
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"], intervals=["1m"], connector=connector
        )
        await feed.run(stop_event)
        assert feed.stats.malformed_messages == 1
        assert feed.stats.events_emitted == 1

    asyncio.run(scenario())


def test_run_stops_cleanly_when_stop_is_requested_after_subscribe() -> None:
    async def scenario():
        stop_event = asyncio.Event()
        websocket = _FakeWebSocket([], stop_event, stop_on_send=True)
        context = _FakeContext(websocket)
        connector = _FakeConnector([context])
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"], intervals=["1m"], connector=connector
        )
        await feed.run(stop_event)
        assert context.closed is True
        assert feed.stats.subscription_messages_sent == 1

    asyncio.run(scenario())


def test_run_reconnects_and_resubscribes_after_connection_failure() -> None:
    class _FailedContext:
        async def __aenter__(self):
            raise OSError("temporary network failure")

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def scenario():
        stop_event = asyncio.Event()
        websocket = _FakeWebSocket([], stop_event, stop_on_send=True)
        connector = _FakeConnector(
            [_FailedContext(), _FailedContext(), _FakeContext(websocket)]
        )
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"],
            intervals=["1m"],
            connector=connector,
            max_reconnect_attempts=2,
            reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        await feed.run(stop_event)
        assert len(connector.calls) == 3
        assert feed.stats.reconnect_attempts == 2
        assert feed.stats.connection_count == 1
        assert feed.stats.subscription_messages_sent == 1

    asyncio.run(scenario())


def test_run_stops_after_reconnect_limit_is_exhausted() -> None:
    class _FailedContext:
        async def __aenter__(self):
            raise OSError("network unavailable")

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def scenario():
        stop_event = asyncio.Event()
        connector = _FakeConnector([_FailedContext(), _FailedContext()])
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"],
            intervals=["1m"],
            connector=connector,
            max_reconnect_attempts=1,
            reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        with pytest.raises(WebSocketReconnectExhausted):
            await feed.run(stop_event)
        assert len(connector.calls) == 2
        assert feed.stats.reconnect_attempts == 1

    asyncio.run(scenario())


def test_run_raises_on_queue_overflow_instead_of_dropping_events() -> None:
    async def scenario():
        stop_event = asyncio.Event()
        websocket = _FakeWebSocket([FORMING_EVENT, _closed_event()], stop_event)
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT"],
            intervals=["1m"],
            queue_capacity=1,
            connector=_FakeConnector([_FakeContext(websocket)]),
        )
        with pytest.raises(FeedQueueFullError):
            await feed.run(stop_event)
        assert feed.stats.queue_overflows == 1
        assert feed.events.qsize() == 1

    asyncio.run(scenario())


def test_run_resubscribes_same_stream_set_after_unexpected_disconnect() -> None:
    class _DropAfterOneMessageWebSocket(_FakeWebSocket):
        async def recv(self) -> str:
            if self.messages:
                return self.messages.pop(0)
            raise OSError("connection dropped")

    async def scenario():
        stop_event = asyncio.Event()
        first_ws = _DropAfterOneMessageWebSocket([FORMING_EVENT], stop_event)
        second_ws = _FakeWebSocket([], stop_event, stop_on_send=True)
        first_context = _FakeContext(first_ws)
        second_context = _FakeContext(second_ws)
        connector = _FakeConnector([first_context, second_context])
        feed = BinanceKlineWebSocketFeed(
            symbols=["BTCUSDT", "ETHUSDT"],
            intervals=["1m", "5m"],
            connector=connector,
            max_reconnect_attempts=1,
            reconnect_base_delay_seconds=0,
            reconnect_max_delay_seconds=0,
        )
        await feed.run(stop_event)

        first_request = json.loads(first_ws.sent[0])
        second_request = json.loads(second_ws.sent[0])
        assert first_request["params"] == second_request["params"] == [
            "btcusdt@kline_1m",
            "btcusdt@kline_5m",
            "ethusdt@kline_1m",
            "ethusdt@kline_5m",
        ]
        assert (first_request["id"], second_request["id"]) == (1, 2)
        assert feed.stats.connection_count == 2
        assert feed.stats.subscription_messages_sent == 2
        assert feed.stats.reconnect_attempts == 1
        assert first_context.closed is True
        assert second_context.closed is True

    asyncio.run(scenario())
