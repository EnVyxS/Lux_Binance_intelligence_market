# Next Task after v0.50.0

1. Aggregate same-symbol / same-positionSide position accounting across multiple signal IDs, with deterministic allocation of exchange fills and protection quantities.
2. End-to-end autonomous entry dispatcher: approved SMC TradePlan -> atomic risk reservation -> exchange-filter normalization -> idempotent entry -> fill confirmation -> protective orders -> reconciliation.
3. Add integration tests against Binance USD-M Futures TESTNET before considering LIVE.
4. Add Telegram notification transport and idempotent delivery; operator controls remain allow-listed and require explicit confirmation.
5. Wire watchdog heartbeats into runtime worker lifecycle; stale worker should halt entries and alert, not blindly restart order-producing tasks.
6. Windows 10 / Python 3.12.9 / 8GB deployment validation.
