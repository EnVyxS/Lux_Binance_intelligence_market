@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv is missing. Run INSTALL_WINDOWS.bat first.
  exit /b 2
)
echo DIVATrading Stage C - controlled TESTNET SMC entry qualification
echo Requires local .env flags DIVA_ENABLE_TESTNET_ORDERS=true and DIVA_ENABLE_TESTNET_STAGE_C=true.
echo Restriction: MANUAL BTCUSDT, one worker, maximum risk 0.10%% per trade, maximum portfolio risk 0.25%%.
echo This is a continuous runtime. It waits for a real SMC-qualified signal and may submit a Demo order.
echo Press Ctrl+C to stop. Do not leave unattended during initial qualification.
pause
.venv\Scripts\python.exe -m divatrading auto-trade-runtime --mode MANUAL --symbols BTCUSDT --max-symbols 1 --risk-per-trade-pct 0.10 --max-portfolio-risk-pct 0.25 --account-ready-timeout-seconds 180
endlocal
