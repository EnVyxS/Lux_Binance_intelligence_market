# Next Task — User Data Stream, Account Freshness & Reconciliation

1. Implement official Binance USD-M Futures listen-key create/keepalive/close operations using API-key authorization without signing unless required by the current official endpoint contract.
2. Add websocket lifecycle with bounded reconnect/backoff and listen-key renewal.
3. Normalize `ORDER_TRADE_UPDATE`, `ACCOUNT_UPDATE` and listen-key expiry events into immutable typed records.
4. Persist raw/normalized events idempotently in SQLite and track sequence/time provenance where the API provides it.
5. Build REST reconciliation after startup, disconnect and stream expiry: account, positions, standard orders and conditional/algo orders.
6. Add account snapshot age/freshness gate immediately before each submission; stale or inconsistent state blocks new entries.
7. Reconcile each local intent/reservation to exchange order IDs/client IDs and verify bracket protection against exchange-observed conditional orders.
8. Release reservations automatically only after a verified terminal no-fill entry or verified flat position with no remaining entry/protection orders.
9. Preserve PAPER default and keep TESTNET/LIVE opt-in. No live order until event/reconciliation invariants are test-covered.
