# Build State v0.45.0 — Atomic Portfolio Risk Reservation

Base: v0.44.0 Global Account State.

## Implemented

- Added durable SQLite `risk_reservations` table keyed by `signal_id`.
- Added atomic `BEGIN IMMEDIATE` reservation admission across ledger instances/processes sharing one database file.
- Added exact Decimal budget check combining exchange-reported open-risk input, active local reservations and requested TradePlan risk.
- Added global max-position admission using exchange active positions plus active local reservations.
- Added per-symbol notional admission using exchange symbol exposure plus same-symbol active reservations and the exact leverage-derived symbol cap.
- Added idempotent active reservation handling and terminal release semantics; coordinator blocks duplicate active reservations pending reconciliation to close reserve/claim/POST crash windows.
- Wired the multi-pair coordinator to reserve exact plan risk before execution; reservation failure blocks submission.
- PAPER releases reservations immediately; TESTNET/LIVE retain pending/protected reservations and ambiguous errors fail closed.
- Added explicit coordinator release API for later reconciliation/position lifecycle integration.
- TESTNET/LIVE execution service independently blocks direct submissions unless an ACTIVE reservation exactly matches signal symbol, planned risk and notional.

## Verification

- Full regression: 762 passed.
- Python compileall: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- Focused reservation/concurrency and coordinator tests: PASS.

## Not implemented yet

- Binance User Data Stream listen-key management, reconnect and event reducer.
- Account snapshot freshness/age gate and external manual-order detection.
- True stop-distance portfolio risk derived from verified exchange protection; v0.44 notional proxy remains conservative.
- Automated release of TESTNET/LIVE reservations after reconciled flat/terminal lifecycle.
- Complete order/position restart reconciliation, partial TP, breakeven, trailing, final exits and kill-switch orchestration.
- Dashboard/Telegram and Windows target verification.

Execution remains PAPER by default. No private Binance request or exchange order was sent during this build. Runtime tests were performed on Linux/Python 3.13.5; Windows 10/Python 3.12.9/8 GB remains unverified.
