# Build State — v0.58.0rc3

- Version: `0.58.0rc3`
- Baseline: v0.58.0rc2 verified archive.
- Added read-only LIVE onboarding preflight and account-specific leverage bracket retrieval.
- LIVE order routing remains disabled.
- Full test collection: 1,018 tests. The entire suite did not complete within the build execution window; no full-regression pass is claimed.
- Targeted RC3 + related regression: 23 passed.
- `compileall`: passed.
- CLI `live-read-only-preflight --help`: passed.
- No real Binance API credentials or exchange account were used.
- Windows 10 / Python 3.12.9 qualification remains pending.
