@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv is missing. Run INSTALL_WINDOWS.bat first.
  pause
  exit /b 2
)
if "%~1"=="" (
  ".venv\Scripts\python.exe" -m divatrading testnet-preflight
) else (
  ".venv\Scripts\python.exe" -m divatrading testnet-preflight --symbols "%~1"
)
set "RC=%ERRORLEVEL%"
echo.
echo TESTNET read-only preflight exit code: %RC%
pause
exit /b %RC%
