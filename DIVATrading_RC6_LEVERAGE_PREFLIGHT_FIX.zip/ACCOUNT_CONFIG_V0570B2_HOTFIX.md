# v0.57.0B2 — Binance Demo Account Configuration Compatibility Hotfix

## Finding

A user-provided read-only Demo preflight showed that signed account reads were working: the bot could retrieve a positive USDT available balance, One-way position mode, zero active positions, and zero standard/Algo open orders. The preflight remained blocked because the release expected `canTrade` and `multiAssetsMargin` in the `GET /fapi/v3/account` response.

That expectation is incompatible with Binance's account-information migration. Binance documents that configuration-related fields were removed from Account Information V3 and moved to `GET /fapi/v1/accountConfig`.

## Change

- Keep `GET /fapi/v3/account` as the read-only source for account wallet and available-balance figures.
- Read `canTrade` and `multiAssetsMargin` from signed, read-only `GET /fapi/v1/accountConfig`.
- Keep the existing independent `GET /fapi/v1/positionSide/dual` position-mode check.
- If account configuration cannot be retrieved or required fields are absent, preflight remains fail-closed.
- No account configuration is changed. No leverage/margin settings are modified. No order, Algo order, or test order is submitted by preflight.

## Safety boundary

- REST endpoint remains pinned to `https://demo-fapi.binance.com` in TESTNET mode.
- LIVE trading remains disabled.
- `DIVA_ENABLE_TESTNET_ORDERS=false` remains the required default for the upcoming read-only/preflight stage.
- Stage B `/fapi/v1/order/test` still requires its separate opt-in and explicit CLI confirmation. It is not part of this hotfix.
- This hotfix does not authorize actual Demo order entry (Stage C) or LIVE execution.

## Verification scope

The regression test models the current Binance response contract: the V3 account response omits `canTrade` and `multiAssetsMargin`, while Account Configuration returns those fields. HTTP transport tests verify both endpoints are signed GET requests to the Demo host. Live exchange authentication and real order requests are not performed during local build verification.

## Reference

Binance API migration notice (2024-08-06, updated 2024-08-29):
https://www.binance.com/en/support/announcement/detail/19d4e3cd0758426584dd9686eb56ec64
