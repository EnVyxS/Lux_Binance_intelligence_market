# Build State — DIVATrading v0.57.0B2

- Release: `0.57.0b2` (B2 account-configuration compatibility hotfix)
- Base: v0.57.0B signed Demo test-order validation release
- Target: Windows 10 / Python 3.12.9
- Build host: Linux / Python 3.13.5
- Scope: fix Stage A read-only preflight config lookup after Binance removed account configuration fields from `/fapi/v3/account`.
- Account wallet/available-balance data: `/fapi/v3/account`
- Account trading status and Multi-Assets mode: `/fapi/v1/accountConfig`
- Position mode: `/fapi/v1/positionSide/dual`
- All these qualification requests are read-only signed GETs (plus public market metadata/time calls).
- No real exchange key was used in build tests. No live or Demo trade/order was submitted during local verification.
- Windows target runtime remains untested in this build environment.

## Safety flags

- `DIVA_EXECUTION_MODE=TESTNET` for Demo qualification
- `DIVA_ENABLE_TESTNET_ORDERS=false`
- `DIVA_ENABLE_TESTNET_ORDER_TEST=false` by default
- `DIVA_LIVE_TRADING_ENABLED=false`
- PAPER remains the default execution mode in ordinary runtime configuration.
