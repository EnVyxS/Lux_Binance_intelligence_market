# DIVATrading Binance Bot — Release Handoff v0.41.0

**Release:** Multi-Pair Live Market Runtime Supervisor & SMC Handoff  
**Date:** 2026-11-12  
**Base:** v0.40.0 Multi-Pair Auto-Trading Core  
**Build:** Linux x86_64 / Python 3.13.5  
**Target:** Windows 10 / Python 3.12.9 / 64-bit / 8 GB RAM (not verified on user's PC)

## Delivered

- `MultiPairLiveMarketRuntime` continuously refreshes public ExchangeInfo and 24h tickers.
- Reuses AUTO/MANUAL `SymbolUniverseSelector` for exact eligible USDT perpetuals.
- Dynamically starts and stops isolated workers as the selected universe changes.
- Restarts failed/ended symbol feeds without resetting other symbol state.
- Accepts only `ScalpingMarketDataView` captures for the exact worker symbol.
- Routes captures through the existing `SMCV2EvidencePipeline` and exposes evidence callback.
- Exposes selected/rejected symbols and worker health/capture counts.
- Read-only by design; no private order calls.

## Verification

- 732 tests passed.
- compileall, CLI help, import/version 0.41.0 passed.
- Offline fixture-based runtime tests only.

## Important limitation

This release is a runtime supervisor and feed-to-SMC contract, not yet a fully wired production WebSocket graph. `feed_factory(symbol)` must be supplied by the next integration stage. No real Binance WebSocket connection or order was used/tested. Do not interpret this release as ready for unattended live trading.

## Continuation

Read `NEXT_TASK_v0.42.0.md`. Next implement the production per-symbol feed graph using existing Kline, Mark Price, aggregate-trade, depth/order-book, recovery and snapshot adapter services. Keep all order execution disabled in this stage.

## Product direction

The final product remains a FULL AUTO TRADING BOT for multiple Binance USDⓈ-M USDT perpetual pairs. Signal-only is not the target. Historical profitability validation remains deferred; software integrity, feed chronology and execution safety are not waived.
