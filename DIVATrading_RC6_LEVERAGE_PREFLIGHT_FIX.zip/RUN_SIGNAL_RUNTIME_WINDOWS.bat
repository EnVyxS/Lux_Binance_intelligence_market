@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Project virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 2
)
.venv\Scripts\python.exe -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT --max-symbols 1 --telegram-signals --kronos-shadow
exit /b %errorlevel%
