# Next Task after v0.52.0

Priority remains execution core, not dashboard/UI expansion.

1. **Protective trigger partial-fill reconciliation:** use User Data Stream plus REST trade/order evidence to detect a triggered protective Algo that only partially reduces the lot, update the exact signal quantity, and re-establish both remaining protections without leaving sibling orders oversized or creating duplicates.
2. **Transactional fill applier:** merge immutable `ORDER_TRADE_UPDATE` / `TRADE_LITE` evidence with REST trade history by exchange trade ID; atomically apply ENTRY/CLOSE deltas to the correct signal lot and reconcile fees/average fill price. Unknown DIVA fills stay hard-stop.
3. **Multi-lot supervisor:** allow multiple signal IDs on the same `(symbol, positionSide)` only after a per-lot supervisor routes mark events, partial exits, stop replacements and risk reservations without comparing each lot to the whole exchange position.
4. **Autonomous entry dispatcher:** approved SMC V2 TradePlan -> atomic global risk reservation -> exact exchange-filter normalization -> deterministic/idempotent entry -> fill confirmation -> quantity-scoped protection -> reconciliation. This is the highest-value missing full-auto path.
5. **TESTNET integration:** run controlled USDⓈ-M Futures TESTNET account-mode, entry, protective order, cancel/replace, partial-fill, stream reconnect and restart-recovery tests. Do not infer certification from local fakes.
6. Windows 10 / Python 3.12.9 / 8 GB deployment validation.
7. Telegram notifications and allow-listed operator controls only after execution/risk lifecycle is stable.

Keep PAPER as default. Never enable same-side scale-in or LIVE before steps 1–5 pass, and require explicit operator opt-in for TESTNET/LIVE.
