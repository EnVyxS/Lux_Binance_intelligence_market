# Build State — v0.56.0

- Release: `0.56.0`
- Scope: Autonomous SMC V2 to entry dispatcher
- Baseline: `DIVATrading_BinanceBot_TrueMultiLotSupervisor_0.55.0.zip`
- Build host: Linux / Python 3.13.5
- Project Python pin: `==3.12.9` (unchanged)
- Runtime target: Windows 10, 64-bit, 8 GB RAM (not yet validated)

## Included

- Durable `signal_dispatches` SQLite table and at-most-once signal claim before account snapshot I/O.
- Qualification-only SMC planner option; final sizing remains in the global coordinator.
- `AutonomousEntryDispatcher` with signal expiry, account snapshot freshness, universe membership, entry-halt, state transitions and no-blind-retry behavior.
- PAPER portfolio provider and environment-configured deterministic full-fill simulation.
- Binance REST portfolio provider with exact DIVA lot ownership netting, conservative unmatched position accounting, and external open-order exposure admission.
- `auto-trade-runtime` command wires public multi-pair market runtime, universe metadata, SMC planner, dispatcher, coordinator, execution service, plus TESTNET account/user-stream/reconciliation/lifecycle runtime.
- Autonomous LIVE routing blocked in this release. Same-side TESTNET/LIVE scale-in remains blocked until TESTNET qualification.

## Test / build state

- Full source regression: 906 passed.
- Focused dispatcher tests: 13 passed.
- `compileall`: PASS.
- CLI help: `auto-trade-runtime`, `market-runtime`, `account-runtime`, `runtime-status`: PASS.
- Clean extraction regression and packaging checks: recorded in `CLEAN_EXTRACTION_TEST_REPORT_v0.56.0.md`.

## Not validated

- No private Binance API session, TESTNET order, or LIVE order was executed.
- No actual exchange multi-lot scale-in / multi-lot Algo protection qualification.
- No Windows 10 / Python 3.12.9 test.
- PAPER simulation is plan-price full-fill only; no slippage, queue, latency or probabilistic partial fills.
