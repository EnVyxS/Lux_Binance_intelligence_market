@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Install the module with INSTALL_WINDOWS.bat first.
  exit /b 1
)
echo ======================================================
echo BINANCE LIVE READ-ONLY ACCOUNT PREFLIGHT
echo This queries account data but does NOT submit orders.
echo Requires local .env mode LIVE, read-only opt-in=true,
echo and DIVA_LIVE_TRADING_ENABLED=false.
echo ======================================================
.venv\Scripts\python.exe -m divatrading live-read-only-preflight --symbols BTCUSDT
exit /b %errorlevel%
