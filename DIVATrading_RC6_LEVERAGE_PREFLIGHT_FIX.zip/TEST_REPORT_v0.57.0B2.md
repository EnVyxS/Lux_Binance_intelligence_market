# Test Report — v0.57.0B2

## Summary

**Result: PASS — 950 tests passed across partitioned runs.**

| Test partition | Result |
|---|---:|
| Core, data, exchange, history and live-feed modules | 350 passed |
| Order book, SMC/Pine parity, position lifecycle and runtime modules | 274 passed |
| Scalping SMC V2, replay analytics, execution, TESTNET and user-stream modules | 319 passed |
| Stage 6B workflow module (`-p no:ddtrace`) | 7 passed |
| **Total** | **950 passed** |

`pytest --collect-only -q --ignore=tests/test_stage6b_workflow.py` collected 943 tests; those 943 passed in three independent partitions. The 7 workflow tests passed in a separate run with the ddtrace pytest plugin disabled. A single monolithic run exceeded the 120-second command window, so verification was completed in partitions rather than treating the timed-out monolithic invocation as a test failure.

## Focused regression

`tests/test_testnet_qualification.py`, `tests/test_testnet_preflight_cli.py`, `tests/test_testnet_order_cli.py`, and `tests/test_test_order_validation.py`:

- 40 passed.
- V3 account payload without configuration fields is accepted when `/fapi/v1/accountConfig` supplies `canTrade` and `multiAssetsMargin`.
- Missing/unavailable account configuration remains fail-closed.
- Account info and account config requests are signed GET calls.
- Requests remain pinned to `demo-fapi.binance.com` in TESTNET mode.
- No order or Algo-order creation path is called by preflight.

The 40 focused tests are included in the 950-test total, not additional tests.

## Static and CLI checks

- `python -m compileall -q src tests`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -m divatrading testnet-preflight --help`: PASS.
- `PYTHONPATH=src python -m divatrading testnet-order-test --help`: PASS.

## Boundaries

- Local test suite used fixtures and mocked HTTP; it did not use the user's Demo credentials.
- No real Binance `/fapi/v1/order/test`, `/fapi/v1/order`, or `/fapi/v1/algoOrder` request was made during this build.
- No live exchange request was made.
- Windows 10 / Python 3.12.9 runtime verification remains outstanding; build host is Linux / Python 3.13.5.
