@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
if not exist ".diva_temp\pytest" mkdir ".diva_temp\pytest"
set "TEMP=%CD%\.diva_temp"
set "TMP=%CD%\.diva_temp"
set "TMPDIR=%CD%\.diva_temp"
set "PIP_CACHE_DIR=%CD%\.diva_temp\pip-cache"
.venv\Scripts\python.exe -c "import sys,struct; assert sys.version_info[:3] == (3,12,9) and struct.calcsize('P')*8 == 64, 'Python 3.12.9 64-bit required'"
if errorlevel 1 exit /b 1
REM Explicitly suppress production execution while running tests even if .env is LIVE.
set "DIVA_EXECUTION_MODE=PAPER"
set "DIVA_LIVE_TRADING_ENABLED=false"
set "DIVA_ENABLE_TESTNET_ORDERS=false"
set "DIVA_ENABLE_PROTECTION_RECOVERY=false"
set "TELEGRAM_BOT_TOKEN="
set "TELEGRAM_OWNER_ID="
set "BINANCE_API_KEY=OFFLINE_TEST_DUMMY_KEY"
set "BINANCE_API_SECRET=OFFLINE_TEST_DUMMY_SECRET"
.venv\Scripts\python.exe -m pytest -q --basetemp "%CD%\.diva_temp\pytest"
exit /b %errorlevel%
