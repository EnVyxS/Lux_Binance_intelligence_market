# Windows Deployment — DIVATrading v0.58.0rc3

1. Extract ZIP into a new folder.
2. Install Python 3.12.9 x64.
3. Run `INSTALL_WINDOWS.bat`.
4. Run `TEST_WINDOWS.bat`; stop if any test fails.
5. Keep `DIVA_LIVE_TRADING_ENABLED=false`.

## Optional read-only LIVE account inspection
Only on a dedicated Binance USDⓈ-M Futures account, with withdrawals disabled and IP restrictions configured where supported:

- Put API credentials only in local `.env`; never send them in chat.
- Set `DIVA_EXECUTION_MODE=LIVE`.
- Keep `DIVA_LIVE_TRADING_ENABLED=false`.
- Set `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true`.
- Run `.venv\\Scripts\\python.exe -m divatrading live-read-only-preflight --symbols BTCUSDT`.

This command reads account and exchange metadata only. It does not place orders, change leverage, change margin mode, or cancel orders. Any active position or open standard/Algo order blocks the initial clean-account gate. Do not run this against an account containing manual exposure.

A successful read-only preflight is not permission to trade LIVE. Further risk-ledger and position-lifecycle validation is required.
