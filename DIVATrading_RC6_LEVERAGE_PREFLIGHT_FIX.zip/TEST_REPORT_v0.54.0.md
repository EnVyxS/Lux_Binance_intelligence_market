# Test Report — v0.54.0

## Environment

- Build OS: Linux.
- Python: 3.13.5 (project target remains pinned to Python 3.12.9).
- Test runner: pytest.
- Exchange interaction: mocked HTTP/client and local SQLite only.

## Results

- Full working-tree regression: **875 passed in 15.23s**.
- Final clean-extraction regression: **875 passed in 15.15s**.
- Focused REST backfill tests: **9 passed**.
- Focused User Data Stream/reconciliation + REST backfill tests: **39 passed in 2.39s**.
- `python -m compileall -q src`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- Package version check: `0.54.0`.
- `PYTHONPATH=src python -m divatrading account-runtime --help`: PASS.

## New coverage

- Signed `/fapi/v1/userTrades` request path, parameter validation and no `fromId` + time-bound combination.
- Initial seven-day bounded windows and recursive splitting of full pages.
- Cursor pagination from `last_trade_id + 1` with ID-only parameters.
- Durable page commits, watermark advancement only after complete runs, and unchanged watermark on failure.
- Idempotent REST/stream merge in both arrival orders, preservation of owner client ID, commission enrichment and single fill projection.
- Contradictory duplicate quantity/price/order/side rejection.
- Late REST fill ownership attribution after the matching-engine order link is persisted.
- Account reconciliation transient entry halt, 60-second backfill throttle, preservation of manual kill switch and fail-closed backfill failure.
- Reconciliation invokes backfill while transiently halting entries, throttles repeated calls, preserves manual kill switch and blocks readiness on backfill failure.

## Not tested

- Actual Binance TESTNET/LIVE account trade-history requests or API-key permissions.
- Production rate-limit behavior, real six-month history volume or concurrent exchange fills during live backfill.
- Windows 10 / Python 3.12.9 deployment or 8 GB resource ceiling.
- Same-side multi-lot supervisor and autonomous SMC-to-entry execution.

Local regression is not exchange certification or a profitability claim.
