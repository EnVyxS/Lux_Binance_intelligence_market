# Changelog — DIVATrading

## v0.59.0rc1 — Autonomous Execution & Risk Integration Candidate (2026-11-15)

- Connects typed account-specific USDⓈ-M leverage brackets, symbol commission rates and fresh available margin to non-PAPER coordinator/dispatcher sizing. The risk budget is calculated first; round-trip commission, slippage and funding reserves are included; quantity is never increased to satisfy minimum notional.
- Adds guarded per-symbol margin/leverage preparation: exact position/standard-order/Algo-order checks before mutation, `marginType`/leverage writes only for a flat and order-free symbol, and exact `symbolConfig` readback verification. This path is not reachable from autonomous LIVE runtime in this candidate.
- Integrates a restart-safe income-history backfill (90-day bootstrap, seven-day windows, recursive full-page splitting, idempotent rows and fail-closed watermark) with user-trade backfill and account reconciliation.
- Connects completed-lifecycle accounting to attributed fill projections, USDT commissions/realized PnL and funding allocations. Daily loss consumes exchange income rows; transfer cashflows are normalized out of the equity series; mid-day day-start anchors are reconstructed from account margin balance, realized PnL and floating PnL.
- Unknown non-zero income types, unsupported non-USDT fees/cashflows, unowned fills, ambiguous funding allocation and incomplete closed-lot projections keep the risk ledger unready and block new entries.
- Integrates persistent owner-only Telegram controls in the autonomous runtime with automatic reconnect, durable update offset, pre-candidate settings refresh, and confirmed `/resetkill confirm` handling. Pause/kill blocks new entries but does not blindly close managed positions.
- Full source regression: 1,038 passed; `compileall`: passed. Current build host: Linux / Python 3.13.5; project target remains Windows 10 / Python 3.12.9.
- No real exchange account was connected and no TESTNET/LIVE order was submitted. Autonomous LIVE remains explicitly disabled; the package is not permission to begin LIVE trading. Exact archive Windows qualification and supervised exchange lifecycle commissioning remain mandatory.

# Changelog

## 0.57.0D4 — Account Runtime Stream-Gap & Multi-Lot Recovery (2026-11-14)

- Forces bounded REST `/fapi/v1/userTrades` backfill after every newly established private User Data Stream connection, even when the normal periodic backfill interval has not elapsed. The forced request remains latched until all tracked symbols complete successfully.
- Keeps entries halted when a required backfill fails. A subsequent successful attempt may clear only the exact transient `TRADE_HISTORY_BACKFILL_FAILED` halt that this reconciler itself introduced, and only after the new sequential account snapshot has no discrepancies. Pre-existing operator/manual halts are preserved.
- Links each REST-verified protective Algo `actualOrderId` child MARKET order to its signal lot, side and STOP/TP role before remainder cancellation/fill reduction. This makes late `ORDER_TRADE_UPDATE` and REST userTrades fills attributable even though Binance's generated child `clientOrderId` is not the parent DIVA Algo ID.
- Adds an idempotent ledger API to inspect this durable exchange-order ownership mapping. Late fills already stored as EXTERNAL/UNATTRIBUTED are re-attributed and their immutable per-signal projections rebuilt when the exact child-order link becomes known.
- Adds an integrated mock lifecycle test spanning two same-side lots, protective Algo trigger, child partial fill, REST trade backfill, commission/realized-PnL projection, restart duplicate replay, aggregate-flat finalization and reservation release.
- Adds deterministic multi-lot accounting invariants across One-way/Hedge position-side cases, covering quantity conservation and FIFO close allocation.
- Full source regression: **986 passed** on Linux / Python 3.13.5. Focused stream-gap/backfill/accounting/lifecycle suite: **129 passed**. No real Binance Demo/LIVE private request, order, cancel or Algo mutation was executed.
- Python package version: `0.57.0rc5`; project interpreter pin remains `==3.12.9`. Exact D4 Windows 10 / Python 3.12.9 qualification remains pending.

## 0.57.0D3 — Triggered Algo Fill & Residual Recovery (2026-11-14)

- Reworks triggered protective Algo reconciliation to re-query the matching-engine child by `actualOrderId`, validate its symbol/order ID/MARKET type/origQty/side/positionSide/close semantics, cancel active unfilled remainder, then re-query and use the final REST `executedQty` for residual sizing. Stream cumulative quantities are observations only and cannot override final REST values.
- Handles fill-during-cancel races: final executed quantity may increase after the initial GET; the reducer derives residual lot and aggregate quantities from the post-cancel REST response and verifies them against the exchange position before local mutation.
- Supports terminal zero-fill triggered child orders. With explicit TESTNET-only `DIVA_ENABLE_PROTECTION_RECOVERY=true`, it re-establishes a complete STOP/TP pair at the unchanged confirmed quantity using deterministic resize action IDs. By default, zero-fill re-protection remains disabled, the action stays pending, and the entry halt remains latched.
- Adds REST startup backfill for current managed STOP/TP Algo IDs after each private-stream connection. A triggered order missed during `ALGO_UPDATE` disconnect is detected through the exact Algo REST query and routed through the same durable `actualOrderId` reducer. Unknown/missing source state is not treated as a safe cancellation.
- Makes parent trigger actions restart-safe across cancellation ambiguity: action state is persisted before remainder cancellation; restart re-queries the same child order and does not repeat an order POST. Duplicate and out-of-order trigger updates resolve through the durable action and REST query.
- Preserves per-lot residual accounting, One-way/Hedge close semantics, sibling lots, risk reservations, paired residual protections, and the separate account entry-halt release policy.
- Adds coverage for fill-during-cancel race, stale/out-of-order stream quantity, zero-fill re-protection with and without opt-in, REST backfill after stream gap, ambiguous cancel/restart recovery, duplicate updates, One-way/Hedge and multi-lot residuals.
- No actual Binance Demo/LIVE order or Algo mutation is executed by build tests. Exact D3 archive Windows 10 / Python 3.12.9 qualification remains separate from C1 PC evidence.
- Final full regression: **978 passed** on Linux / Python 3.13.5; focused triggered-protection suite **10 passed**; compileall and four CLI help checks passed. Python package `__version__` and `pyproject.toml` both report `0.57.0rc4`.

## 0.57.0D2 — Position-Aware Protective Recovery (2026-11-14)

- Adds opt-in, TESTNET-only recovery for an already-open managed lot whose quantity-scoped STOP/TP Algo order is missing from a fresh sequential REST reconciliation and whose original Algo is proven terminal with zero executed quantity.
- Requires a connected User Data Stream, fresh reconciliation snapshot, exact stream-event watermark, active risk reservation, unchanged per-lot state and exact aggregate `(symbol, positionSide)` quantity before recovery.
- Uses REST Query Algo Order as primary terminal evidence. If Binance returns `-2013`, the latest durable `ALGO_UPDATE` event is preferred; a hash-verified persisted source snapshot is the final restart fallback. A later triggered/fill stream update overrides older canceled evidence.
- Creates one deterministic replacement Algo ID per recovery action, queries before POST, marks the POST attempt durably before sending, and verifies the exact replacement by REST GET after acknowledgement. Ambiguous POST/query outcomes remain `SUBMISSION_UNKNOWN`; the same action is never blindly POSTed twice.
- Verifies all sibling protections, permits only explicitly reconciled terminal-no-fill gaps, preserves existing active siblings, and processes one missing protection leg per fresh reconciliation snapshot.
- A triggered/part-filled Algo is never replaced by this recovery path; it is deferred to the existing `actualOrderId`/`executedQty` fill reducer. An exchange-flat position is finalized only through the existing flat-position cleanup and reservation-release path.
- Recovery remains disabled by default (`DIVA_ENABLE_PROTECTION_RECOVERY=false`) and is restricted to TESTNET; it never clears the account entry halt. Operator reconciliation and explicit halt release remain separate.
- Adds tests for STOP recovery, triggered deferral, REST-not-found stream evidence, stale stream evidence precedence, full-flat finalization, ambiguous POST/no retry, multi-lot quantity isolation, Hedge Mode semantics, sibling protection integrity, and crash-window restart recovery.
- Build host: Linux / Python 3.13.5; project Python pin remains `==3.12.9`. No real Binance Demo/LIVE order or Algo mutation was executed. C1 Windows evidence remains 952/952 for C1; D2 requires its own PC qualification before actual use.
- Full regression: **972 passed** on Linux / Python 3.13.5; clean-extraction regression: **972 passed** from the final source tree before release-document insertion; the final archive is verified separately in the release report. Focused protective recovery/account-runtime tests: 19 passed; no failed/skipped tests. Project target remains Windows 10 / Python 3.12.9. No real Binance Demo or LIVE order/Algo mutation was performed by the build.

## 0.57.0D1 — Protective Order Integrity Hardening (2026-11-14)

- Hardens initial entry protection by querying every STOP/TP Algo order by deterministic `clientAlgoId`, regardless of whether the local ledger already records that role. Local persistence is no longer treated as proof that the exchange order remains active.
- Treats a previously-recorded protective order that is missing from Binance as a hard safety discrepancy: latches the entry halt, records a sanitized diagnostic event, and refuses a blind replacement POST. A separate position-aware recovery step is required before restoring missing protection.
- Treats a POST acknowledgement as non-authoritative. Newly submitted initial STOP/TP protection must be re-queried from Binance and verified before the position can be considered protected.
- Extends quantity-scoped Algo validation with optional exact symbol, clientAlgoId and trigger-price checks. Initial protection, protection resize, trailing STOP replacement and account reconciliation now supply these exact expectations.
- Account reconciliation now detects a STOP/TP whose trigger price differs from the durable managed stop/target, even when the symbol, side, quantity and client ID otherwise look valid. Legacy close-all orders are also trigger-checked during single-lot migration.
- Adds regression coverage for GET-after-POST verification, stale/missing locally-recorded protection, mismatched trigger prices, and exact symbol/clientAlgoId binding.
- Regression on build host: **956 passed**; compileall and focused protection/supervisor/reconciliation suite pass. Build host is Linux / Python 3.13.5; project runtime requirement remains `==3.12.9`. No real Binance Demo order, fill, Algo mutation, or LIVE request was executed.
- Scope is integrity verification and fail-closed behavior. Automatic repair of missing protection is not enabled in D1; unresolved missing protection requires position reconciliation and remains halted. C1's actual Demo Stage C evidence is still pending.


## 0.57.0C1 — Windows Qualification Hotfix (2026-11-14)

- Freezes the user-validated v0.57.0C source fixes into a separately versioned release candidate (`0.57.0c1`).
- Imports `MultiPairExecutionCoordinator` explicitly in the autonomous runtime CLI and corrects the Stage C Windows launcher text so CMD does not interpret comparison characters as redirection.
- Makes replay checkpoint writes Windows-compatible by writing, flushing and syncing the temporary file through a writable handle before atomic replacement.
- Corrects the Stage 6B workflow test helper so manifest and dataset-root paths are resolved independently relative to the workflow plan directory.
- Changes managed-position supervisor shutdown to set the stop signal and await worker completion, allowing in-flight thread-backed lifecycle work and feed shutdown to finish before the supervisor returns.
- Pins development tools to `pytest==9.2.0` and `pytest-asyncio==1.5.0`, sets `asyncio_default_fixture_loop_scope=function`, aligns `requirements-dev.txt`, and modernizes the proprietary license metadata.
- Directs Windows installer temporary/build files and pytest temporary directories to `.diva_temp` on the project drive; adds `.diva_temp` to ignore and checkpoint-exclusion rules.
- Windows 10 / Python 3.12.9 user validation on the included functional source: full regression **952 passed** in 904.90 seconds; Position Supervisor **10 passed**; Stage 6A checkpoint/replay **16 passed**; Stage 6B workflow **7 passed**; targeted SQLite lifecycle **2 passed**. No failed or skipped tests in the full-suite output.
- Release packaging metadata, installer/test launcher, and version identity are finalized in C1. The exact post-packaging C1 archive is additionally checked by archive integrity, source compilation, CLI help and wheel-build validation in the release environment. No actual Stage C Demo entry/fill/protection cycle or LIVE order is claimed by this release.

## 0.57.0b1 — Binance USDⓈ-M Demo Signed Test Order Validation (Stage B) (2026-11-14)

- Adds signed `POST /fapi/v1/order/test` and `testnet-order-test` CLI, restricted to the pinned Demo endpoint, LIMIT/MARKET request validation, live exchange metadata and account position-mode checks.
- Adds separate local opt-in (`DIVA_ENABLE_TESTNET_ORDER_TEST=true`) plus `--confirm-test-order`; actual order-placement flag remains false. No matching-engine submission, order creation, position or fill occurs in this stage.
- Adds exact Decimal filters, local LIMIT validation, exchange-authoritative MARKET notional validation, transport/API error classification, secret/signature redaction and no automatic retries.
- Regression: 948 passed across two runs (941 excluding the legacy workflow module plus 7 workflow tests separately); focused Stage B/Stage A tests: 38 passed. No real Binance authenticated session or test order was executed; user-PC Demo validation remains pending.


## 0.57.0 — Binance USDⓈ-M Demo Futures Qualification Harness (Stage A) (2026-11-14)

- Adds `testnet-preflight`, a strictly read-only qualification command that validates TESTNET endpoint isolation, REST reachability, server-time synchronization/RTT, active USDT perpetual symbol metadata, signed account access, `canTrade`, single-asset collateral mode, positive available USDT balance, One-way/Hedge position mode, and absence of open positions/standard orders/Algo orders. API keys and secrets are never emitted in CLI output.
- Pins USDⓈ-M Demo REST to `https://demo-fapi.binance.com`; pins Demo public market stream to `wss://demo-fstream.binance.com/market/stream` and Demo private stream to the `/private/ws?listenKey=...&events=...` route. Migrates LIVE private User Data Stream URL construction to the current `/private` route and subscribes to order, account, Algo, trade-lite, account-configuration, margin-call and listen-key-expiry events. Legacy private stream URL paths are removed.
- Adds a local `.env.testnet.example` and operational instructions. Stage A keeps `DIVA_ENABLE_TESTNET_ORDERS=false`; no create/cancel listenKey, account-setting write, WebSocket connection, or order request is performed by preflight.
- Corrects REST User Trades history bounds after Binance's 2026-08-26 USDⓈ-M change: current `GET /fapi/v1/userTrades` historical query window is 3 months, not six months. Default bootstrap is now 90 days and larger explicit time windows fail before making requests.
- Keeps LIVE and Demo endpoint configuration isolated. `testnet-preflight` reports `READY_FOR_TEST_ORDER_VALIDATION` only; trade permission, actual stream connectivity and order behavior are deferred to later qualification stages.
- Full regression: 927 passed from source and 927 passed from clean extraction; focused TESTNET/User Data Stream/backfill suite: 64 passed; compileall and CLI help pass; archive CRC/SHA/sensitive-file audit pass. Tests use local SQLite, fixture metadata and mocked HTTP only. No actual Binance API session, Demo WebSocket session or order was executed. Build host: Linux / Python 3.13.5; project Python pin remains `==3.12.9`.

## 0.56.0 — Autonomous SMC-to-Entry Dispatcher (2026-11-13)

- Adds `auto-trade-runtime`, integrating selected AUTO/MANUAL universe instruments, per-symbol SMC V2 candidate evaluation, qualification-only planner mode, a durable autonomous dispatcher, fresh account snapshot capture, global risk sizing/reservation, idempotent entry execution and existing per-lot lifecycle/account runtime services.
- Adds a durable `signal_dispatches` ledger table. Each signal is claimed before snapshot/provider I/O; repeated signals cannot create a second route, and ambiguous or failed dispatches remain `REQUIRES_RECONCILIATION` instead of retrying an entry POST blindly.
- Makes the portfolio coordinator authoritative for final sizing. Qualification-only SMC planning does not provisionally size/reserve risk, preventing duplicate risk calculations before the fresh account snapshot.
- Adds PAPER portfolio snapshot provider and deterministic paper full-fill-at-plan-price execution with local quantity-scoped virtual STOP/TP orders, managed-position state and retained risk reservations. The simulator does not model queue position, latency, slippage or real exchange fills. `DIVA_PAPER_SIMULATE_FILLS=false` disables simulated fills.
- Adds Binance REST account snapshot provider with ownership netting for fully matched, reserved DIVA lots; unmatched positions are charged conservatively at full notional. Unattributed external open standard/Algo orders are counted as pending exposure when price/quantity are known; unpriced or malformed external orders fail closed.
- TESTNET auto-runtime requires User Data Stream + REST reconciliation readiness before market dispatch. Same-side TESTNET/LIVE scale-in remains blocked pending controlled multi-lot Algo protection qualification. Autonomous LIVE routing is disabled in this release.
- Updates `runtime-status` CLI description and adds integration tests for durable claims, signal/snapshot freshness including post-capture revalidation, universe routing, PAPER simulation, ownership accounting, external pending orders and SMC planner qualification-only mode.
- Full regression: 906 passed; `compileall`, CLI help and local packaging checks pass. All tests use local SQLite and mocked/fake exchange/account providers. No actual Binance TESTNET/LIVE private request, stream session or order was executed. Build host: Linux / Python 3.13.5; project Python pin remains `==3.12.9`.

## 0.54.0 — REST User-Trades Backfill & Stream-Gap Recovery (2026-11-13)

- Adds signed USDⓈ-M `/fapi/v1/userTrades` retrieval with validated `symbol`, `fromId`, time-range and `limit` parameters; enforces the seven-day maximum time query and 1,000-row page cap.
- Adds bounded six-month (conservative 180-day) initial history recovery in seven-day windows; full pages are recursively split to avoid silent truncation at the API page cap. Cursor recovery uses `fromId` only, never combined with time parameters.
- Adds SQLite backfill run records and per-symbol recovery watermarks. Each REST page is durably committed before the final watermark advances; failed runs retain the previous watermark and are safe to replay.
- Merges REST and User Data Stream fills by `(symbol, tradeId)`, enriches provenance, resolves ownership by matching-engine `orderId`, rebuilds per-signal Decimal projections, and rejects contradictory immutable quantity/price/order/side facts.
- Wires bounded backfill into TESTNET/LIVE account reconciliation under a temporary entry halt; existing operator/safety halts are preserved, failures keep entries blocked, and successful reconciliations clear only the transient halt introduced by backfill. A 60-second interval throttle avoids polling trade history on every 10-second account snapshot.
- Adds focused REST client, pagination, recursive time splitting, cursor resume, idempotent merge, contradiction, failure watermark and reconciliation-gate tests. Full working-tree regression: 875 passed; focused backfill + User Data Stream/reconciliation suite: 39 passed; compileall and CLI checks pass. No actual Binance TESTNET/LIVE API or order was executed.
- Multi-lot supervisor and autonomous SMC-to-entry dispatcher remain pending; same-side multi-signal execution and LIVE remain blocked.

## 0.53.0 — Protective Partial-Fill Reconciliation & Transactional Fill Projection (2026-11-13)

- Adds deterministic reconciliation for partially executed protective USDⓈ-M Algo orders using `actualOrderId` to inspect the matching-engine order and its confirmed `executedQty`.
- Cancels a still-active remainder of a triggered protective market order, confirms terminal state, compares REST position quantity with the exact expected residual, and fails closed on mismatches.
- Recreates and verifies quantity-scoped STOP/TP protection for the residual lot before canceling the old sibling protection; supports One-way and Hedge Mode semantics and replay-safe parent/child lifecycle actions.
- Adds SQLite transactional per-signal fill projections from `ORDER_TRADE_UPDATE` and `TRADE_LITE`, including trade-ID deduplication, event enrichment, Decimal weighted-entry/close quantities, fee-asset accounting, and USDT realized-PnL accounting.
- Adds fill ownership fallback by exchange matching-engine order ID and backfill when order ownership arrives after the stream event; unknown or conflicting internal fills halt new entries.
- Adds startup projection rebuild and applies new stream fill evidence without mutating exchange-truth managed position quantities.
- Full regression: 863 passed; focused lifecycle execution + User Data Stream: 64 passed; compileall and CLI help pass. All exchange calls are mocked/local; no TESTNET/LIVE order or private-network integration was performed.
- Same-side multi-signal execution remains blocked. REST historical `userTrades` backfill, multi-lot supervisor, SMC TradePlan-to-entry dispatcher, TESTNET integration and Windows target validation remain pending.

## 0.51.0 — Aggregate Position Accounting & Fill Attribution (2026-11-13)

- Adds exact Decimal aggregate views of same-symbol/positionSide signal lots, weighted entry price and immutable lot-open timestamps.
- Adds deterministic per-signal fill ownership from `ORDER_TRADE_UPDATE` and `TRADE_LITE`, including trade-ID deduplication, race backfill and fail-closed handling for unknown DIVA-owned fills.
- Adds explicit close-fill allocation and per-lot protection quantity plans; does not yet enable same-side multi-signal execution.
- Extends `runtime-status` with aggregate position and fill-attribution diagnostics. Full regression: 850 passed. No TESTNET/LIVE request or order used.

## 0.48.0 — Managed Position Lifecycle Execution Adapter (2026-11-13)

- Adds Binance USDⓈ-M partial-close execution with deterministic client IDs, exchange lot/minimum quantity validation, One-way `reduceOnly` handling and Hedge Mode `positionSide` handling.
- Adds conditional Algo STOP create/verify/cancel replacement, with strict DIVA-owned stop-ID validation and no unsafe close-all request fields.
- Adds REST fill/position confirmation; POST acknowledgement alone never advances local lifecycle state.
- Adds event-triggered lifecycle reduction for ORDER_TRADE_UPDATE, TRADE_LITE, ALGO_UPDATE and ACCOUNT_UPDATE.
- Adds verified-flat finalization with linked-order cleanup, second position check and verified SQLite risk-reservation release.
- Adds reconnect/startup recovery for pending actions and flat managed positions. `account-runtime` CLI wires the reducer automatically in explicitly enabled TESTNET/LIVE modes. No blind POST retry; recovery queries deterministic IDs.
- Adds fail-closed handling for unowned stop IDs, post-cleanup REST errors and position changes during STOP replacement.
- Full regression: 824 passed; focused lifecycle execution: 27 passed; compileall and CLI help pass.
- No actual TESTNET/LIVE API, WebSocket or order test. PAPER default; Windows target not tested.


## 0.47.0 — Managed Position Lifecycle Foundation (2026-11-13)

- Adds deterministic Decimal-based LONG/SHORT lifecycle decisions: partial TP, confirmed-fill-gated breakeven and favorable-excursion trailing stop proposals.
- Adds stable action IDs, monotonic stop proposals, SQLite versioned lifecycle state and idempotent action claims/status updates.
- Adds 18 focused lifecycle/persistence tests. Full regression: 797 passed.
- Does not yet submit partial-close or stop-modification orders; exchange adapter, fill-confirmed reducer, verified-flat risk release and full exit recovery remain outstanding.
- No TESTNET/LIVE API request or order used.

## 0.46.0 — User Data Stream & Account Reconciliation (2026-11-13)

- Adds USDⓈ-M listenKey create, keepalive and close methods using API-key authorization without HMAC signing.
- Adds LIVE private WebSocket path and TESTNET endpoint configuration, 25-minute keepalive, 23-hour connection rotation, bounded reconnect/backoff and best-effort listen-key cleanup.
- Adds idempotent durable event capture for ACCOUNT_UPDATE, ORDER_TRADE_UPDATE, ALGO_UPDATE, TRADE_LITE and listenKeyExpired, with partial account/position/order projections.
- Adds exchange-vs-ledger reconciliation for positions, protective STOP/TP orders, pending intents, orphan DIVA orders and risk reservations.
- Adds event-watermark freshness validation: account/order/trade events invalidate READY, and events racing sequential REST capture/commit fail closed.
- Adds TESTNET/LIVE readiness gates to coordinator and direct ExecutionService submission, plus `account-runtime` CLI.
- Tightens protective-order verification to require the correct closing side.
- Full regression: 779 passed; focused suite: 17 passed; compileall and CLI help pass. No Binance TESTNET/LIVE request, stream session or order was used.
- Scope remains partial: automatic verified-flat risk release, partial TP, breakeven, trailing, full exit lifecycle and Windows target validation remain outstanding.

## 0.45.0 — Atomic Portfolio Risk Reservations (2026-11-13)

- Adds persistent SQLite risk reservations keyed by signal ID and serialized with `BEGIN IMMEDIATE` so concurrent multi-pair workers cannot spend the same local portfolio risk budget.
- Adds exact Decimal budget admission over exchange-reported open-risk input, active local reservations and requested trade risk; includes max-position admission.
- Wires reservation before execution in the multi-pair coordinator; rejected and duplicate-active reservations block order submission. TESTNET/LIVE `ExecutionService` independently requires a matching active reservation. PAPER reservations release after paper-only routing; uncertain TESTNET/LIVE outcomes retain reservations pending reconciliation.
- Adds idempotent release API and tests for concurrent admission, duplicate signals, release, invalid financial inputs and max-position limits. Full regression: 762 passed.
- Scope remains partial: account freshness, User Data Stream, exchange/local reconciliation and automated live reservation release are next. No private API or exchange order used.

## 0.43.0 — SMC V2 Signal Qualification & Dynamic Trade Planner (2026-11-12)

- Carries the exact same-capture `ScalpingMarketDataView` alongside SMC V2 Stage 2–5 evidence so strategy decisions use the same validated market snapshot.
- Adds immutable SMC candidates/evaluations and `SMCV2TradePlanner` to transform active OB lifecycle evidence into auditable candidate decisions, `QualifiedSignal` and risk-sized `TradePlan` records.
- Preserves independent M1/M5 setup evaluation and M15 advisory-only context; optional FVG, sweep, Delta/CVD, depth and absorption confluence remains configurable and non-mandatory by default.
- Adds separate LIMIT_RETRACEMENT midpoint entry and CONFIRMATION_MARKET closed-candle confirmation models; adds OB-boundary dynamic SL and configurable-R or confirmed structural-pivot TP.
- Extends exact instrument metadata with optional maximum notional; risk sizing caps quantity to exchange maximum notional and checks minimum notional. Missing min-notional or required bracket order-type metadata fails closed in the planner.
- Extends `market-runtime` with configurable trade-plan sizing and JSON candidate/plan logging. It remains public-data/PAPER planning only and submits no orders.
- Adds planner tests for entry separation, market confirmation, optional confluence, M15 advisory, invalidated OBs, structural targets, missing notional metadata and exchange max-notional caps. Full regression: 747 passed (including candidate ranking before risk allocation).
- Next: v0.44 account-truth reconciliation, global execution routing, User Data Stream, order/position lifecycle and protected fill management.

## 0.40.0 — Multi-Pair Auto-Trading Core (2026-11-12)

- Adds AUTO/MANUAL selection of eligible active Binance USDⓈ-M USDT perpetual contracts, 24h quote-volume/trade-count screening, active-symbol cap and explicit rejection reasons; adds read-only `universe` CLI.
- Adds `SMCV2EvidencePipeline` to compose the existing per-symbol Stage 2–5 structure, OB formation/lifecycle and liquidity/FVG evidence engines without introducing legacy nested M5/M15 priority.
- Adds immutable `QualifiedSignal` / `TradePlan` contracts and Decimal portfolio risk sizing using stop-distance budgets, global open-risk cap, per-symbol notional cap, leverage ceiling and exact exchange quantity/price filters.
- Adds `MultiPairExecutionCoordinator` with one global risk manager and execution service for independent symbol streams; only signals already qualified by the strategy layer can enter this boundary.
- Adds signed Binance USDⓈ-M Futures private REST support with fixed TESTNET/LIVE API base URLs, exchange time synchronization, account/balance/position/order/algo-order queries, write methods, leverage control and income-history retrieval. Signed write requests are never blindly retried after transport ambiguity.
- Adds a separate SQLite execution ledger with atomic unique signal claims, deterministic standard/algo client IDs, order/position/event records, deduplicated income history, and persistent new-entry halt state.
- Adds PAPER-default `ExecutionService`; TESTNET and LIVE require separate explicit local opt-ins. It protects observed fills with conditional STOP_MARKET and TAKE_PROFIT_MARKET Algo Orders, cancels unfilled LIMIT remainders after partial fills, and reconciles pending/ambiguous entry IDs without automatic resubmission.
- Adds tests for universe filtering, exact risk sizing, ledger idempotency, PAPER no-order behavior, execution-mode guards, HMAC request signing, and multi-pair coordination. Full suite: 729 passed.
- Scope boundary: this is the first trading-side core delivery, not yet the completed autonomous bot. Continuous multi-pair market-feed runtime, final SMC qualification/entry policy, account-level portfolio reconciliation, full position/order lifecycle worker (including trailing/partial exits and user-data stream), dashboard/Telegram and Windows deployment remain next implementation work. No TESTNET/LIVE credentials or real orders were used.

## 0.39.0 — Unit 05E Stage 6C.3B: Replay Runtime Optimization & Partial Lifecycle Diagnostics (2026-11-12)

- Replace recursive `deepcopy` of Stage 4/5 replay state with explicit transactional clones of mutable containers and mutable OB/FVG records; immutable Klines and evidence records are safely reused.
- Index Stage 5 pivot provenance lookups by candle open/close time instead of repeated linear scans.
- Stage 4 skips full candidate re-validation after an identical candidate fingerprint has already been validated and retained; conflicting reuse remains rejected.
- Preserve the Stage 4/5 atomic commit behavior and all strategy state-transition rules. A 180-capture full-ledger comparison produced 12,541 normalized-identical records before/after optimization.
- Profiling on the same 180-capture sample improved from 6.321s to 2.300s under cProfile (~2.75x); full regression: 719 passed.
- Real BTCUSDT compact partial diagnostic completed 600 captures (10h), zero replay gaps, 140,996 suppressed pre-roll records. At the endpoint, M1 retained 210 FVGs (19 nonterminal; 41.02% total retained occupancy of 512) and M5 retained 33 (6 nonterminal; 6.45%). This is not a 25h lifecycle validation.
- The requested 27h pre-roll + 60m evaluation replay did not complete within the execution window. Incomplete runs are not accepted as convergence evidence. No FVG expiry or strategy semantics were changed; no warm-up policy is approved.

## 0.37.0 — Stage 6C.2 Eligibility Gate Separation & Provisional Strategy Replay (2026-11-12)

- Split Stage 6B dataset quality output into independent market-data and execution-metadata eligibility gates.
- Preserve the combined strict quality summary and the existing strict replay behavior as the default.
- Add opt-in `PROVISIONAL_STRATEGY_EVIDENCE` workflow mode. It requires clean market data plus a valid exact candidate tick size, allows current-only metadata for deterministic strategy-evidence replay, and labels outputs as provisional.
- Provisional mode sets `strict_metadata=false` and cannot claim historical execution validation, strict calibration eligibility, or exchange-order validity.
- Market-data integrity warnings/failures (including internal gaps) continue to block provisional strategy replay. Metadata/tick-grid issues remain on the execution metadata gate.
- Fix Stage 6B.3 OB lifecycle trace stable identity to use candidate/transition/observed-time/resulting-status, matching the replay engine identity. The originating structure `event_id` is shared across multiple lifecycle transitions and is not a unique lifecycle-trace key.
- Quality report schema advances to v2; integrated workflow report schema advances to v2. Existing workflow plans default to `STRICT`.


## 0.36.0 — Unit 05E Stage 6C.1: Binance REST Kline Intake & Current Metadata Capture (2026-11-12)

- Adds `BinanceRawKlinePage` and read-only public REST client methods to retain exact `/fapi/v1/klines` response-body bytes, request parameters, selected response headers and Binance server time.
- Adds `collect_binance_um_klines_rest` with interval-aligned half-open closed-candle windows, page limit up to 1,500, bounded page count, configurable pacing, per-page raw JSON retention, SHA-256 page index and streamed native 12-column derived CSV.
- Reports leading/internal/trailing missing interval counts and bounded samples without sorting, deduplication, interpolation, repair, rounding or candle synthesis. Page-cap captures are explicit partial CSVs; failed captures retain raw pages and a failure provenance record. Existing capture IDs cannot be overwritten.
- Adds `binance-rest-kline-intake` CLI for 1m/5m/15m and keeps `binance-current-metadata` explicitly labeled `CURRENT_SNAPSHOT_ONLY`; no current `tickSize` is asserted as historically effective.
- Replaces the abandoned Binance Vision archive downloader. The official Vision dataset terms published 2026-08-26 restrict datasets to non-commercial use and disallow live proprietary trading execution/commercial trading-bot integration absent separate written licensing. REST collection is selected for eventual own-account use subject to the applicable Binance account/jurisdiction terms; this is not legal advice.
- Adds 8 focused mocked tests for raw-body retention, multi-page capture, gap reporting, no synthesis, page cap, closed-window and alignment guards, overwrite prevention, current-only metadata and CLI registration.
- No actual Binance data was acquired in this build environment. No 30-day smoke, historical tick-size timeline validation, real replay, strategy calibration, PnL, live/private API or execution is claimed.

## 0.34.0 — Unit 05E Stage 6B.3: Warm-up Convergence Runtime (2026-11-12)

- Adds `divatrading.replay.convergence` and read-only `replay-convergence` CLI to compare 2–10 distinct pre-roll histories against one identical, aligned evaluation window; three or more trials are the recommended comparison mode.
- Requires identical symbol, intervals, evaluation Kline content, code/config/metadata hashes and Stage 6A UTC close-plus-1ms clock policy. Manifest/source hashes, ledger sequence/clock/capture/terminal records and input immutability are validated before and after comparison.
- Compares Stage 2–5 evidence by stable keys and absolute timestamps. Replay-relative fields ending in `_index` are excluded from equality comparison only; raw payloads remain in bounded divergence samples.
- Reports per-timeframe evaluation-slice fingerprints/counts, pre-roll coverage, leading/internal/trailing gaps, replay gap events, warm-up readiness, pairwise evidence agreement and first divergence. No automatic convergence pass threshold is imposed.
- Uses streaming native Kline reads and a temporary SQLite spool; report output is Draft 2020-12 schema-validated and atomically written with deterministic SHA-256.
- Adds 5 focused synthetic convergence tests, including three-trial comparisons, limited two-trial mode, identical evaluation-window enforcement, relative-index normalization, duplicate pre-roll rejection, immutability and CLI output; 8 focused tests including design contracts pass.
- No real Binance historical warm-up convergence was measured. No calibration, scoring/qualification, entry, SL/TP, execution, PnL, CVD/Depth/Absorption replay, private API, Telegram/dashboard or DB migration is included.

## 0.33.0 — Unit 05E Stage 6B.2: Chronological Splits & Evidence Analytics (2026-11-11)

- Adds `divatrading.replay.splits` with deterministic chronological 60/20/20 half-open partitions; internal cut points align to the LCM of active timeframe durations, exact boundary events belong to the next partition, and short/invalid windows fail closed.
- Adds `divatrading.replay.analytics` with streaming Stage 6A JSONL validation, replay identity/sequence/clock validation, source SHA-256/byte provenance and before/after mutation checks. The ledger is never modified.
- Uses a temporary SQLite spool to bound Python memory; closed-bar denominators come only from capture `updated_intervals`. Reports event rates per 1,000 closed bars with exact numerator/denominator.
- Adds Stage 2 structure/readiness, Stage 3 displacement/OB formation, Stage 4 lifecycle and Stage 5 liquidity/sweep/FVG descriptive evidence metrics, Decimal nearest-rank distributions, unique OB/FVG end-of-split snapshots and administrative right-censoring.
- Handles Stage 6A close-plus-1ms terminal clock by assigning a final capture at manifest end to TEST without moving aligned internal split boundaries or changing nominal split proportions.
- Adds read-only `replay-analyze` CLI, Draft 2020-12 report validation, atomic output and deterministic report SHA-256. Only the frozen 60/20/20 ratio is accepted.
- Adds synthetic split/analytics tests; focused split/analytics/design-contract tests: 12 passed; full working-tree regression: 692 passed.
- Stage 6B.3 warm-up convergence remains pending. No real Binance dataset was replayed; no calibration, fills, PnL, profitability, strategy behavior change, private API, live order or DB migration is included.

## 0.32.0 — Unit 05E Stage 6B.1: Raw-Source Dataset Quality Auditor (2026-11-11)

- Adds `divatrading.replay.quality` with streaming raw CSV/TXT/ZIP inspection before strict Stage 6A manifest acceptance, plus manifest-backed source/hash/row-count revalidation.
- Preserves raw 12-column row identity and reports identical duplicate rows, conflicting revisions, decreasing timestamps, cross-file overlaps, malformed rows, out-of-window/misaligned timestamps, close-time mismatches, OHLC relationship defects and source symbol declaration mismatches. No sort, deduplicate, repair, rounding, interpolation or source mutation.
- Computes expected bars, parseable unique coverage, exact missing counts, leading/trailing gaps and chronological gap clusters. Gap cluster and issue sample output is bounded; aggregate counts remain complete.
- Audits OHLC `Decimal` values against exact declared `PRICE_FILTER.tickSize`; checks all available OHLC prices even when an unrelated volume field is malformed. No float tolerance or `pricePrecision` fallback.
- Records source file SHA-256, metadata SHA-256/quality/effective window, caller-supplied independent evidence reference and report SHA-256. Hashes are checked before/after scanning to detect concurrent source changes.
- Adds `replay-quality` raw-source and manifest CLI modes; output is schema-validated and atomically written. Exit codes: 0 PASS/WARN, 9 quality FAIL, 2 request/runtime error.
- Extends dataset quality schema with explicit leading/trailing missing counts, bounded gap-cluster truncation, symbol declaration mismatch counts and occurrence-based summary counters.
- Adds 20 focused synthetic quality tests including raw CSV/ZIP, duplicate/revision, gap boundaries, cross-file overlap, timestamp/OHLC/tick defects, metadata limitations, hashes, manifest verification and CLI output. Full regression: 683 passed.
- Stage 6B.2 temporal split/analytics and 6B.3 warm-up convergence remain design-only. No scoring, qualification, entries, fills/PnL, exchange write access, CVD/Depth/Absorption replay or DB migration.

## 0.31.1 — Unit 05E Stage 6B: Replay Quality & Analytics Design (2026-11-11)

- Documentation/schema-only checkpoint based on verified Stage 6A v0.31.0; replay runtime and SMC V2 strategy behavior are unchanged.
- Defines a raw-source quality audit that runs before strict manifest construction and distinguishes identical duplicates, conflicting revisions, non-monotonic rows, cross-file overlaps, missing bars, malformed/timestamp/OHLC issues and exact Decimal tick-grid violations. No silent deduplication, sorting, repair, rounding or synthetic candles.
- Defines warm-up convergence over at least three pre-roll windows where possible, with identical evaluation-slice fingerprints, frozen code/config/metadata identity, stable evidence-key comparisons and no engine reset at evaluation start. No automatic pass threshold.
- Defines chronological half-open train/validation/test labels targeting 60/20/20, aligned to the LCM of active timeframes and applied to one continuous replay without state resets.
- Defines immutable Stage 6A ledger analytics: per-1,000-closed-bar rates, rejection reasons, displacement/OB/lifecycle/liquidity/sweep/FVG distributions and administrative right-censoring; Decimal nearest-rank P50/P90/P95 policy.
- Adds three Draft 2020-12 report schemas and 3 synthetic design-contract tests. Full regression: 663 passed.
- No Stage 6B runtime scanner/comparator/analytics/CLI, strategy scoring, qualification, entry, fill/PnL, private API, live orders, CVD/Depth/Absorption replay or DB migration is implemented.

## 0.31.0 — Unit 05E Stage 6A: Deterministic Historical Replay Harness (2026-11-11)

- Adds immutable, content-addressed replay dataset manifests with exact native Kline source hashes, row counts/ranges, symbol/contract identity and explicit tick-size metadata quality.
- Adds streaming native Binance USDⓈ-M 12-column CSV/ZIP Kline ingestion and bounded typed REST-page adaptation using the existing historical Kline service. No candles are synthesized or filled.
- Adds UTC close-time replay clock, deterministic replay/capture identity, same-capture Stage 1–5 pipeline and evidence-only JSONL ledger with dataset/config/code/source provenance.
- Keeps bounded rolling histories and per-timeframe isolation. A detected data gap is recorded and resets only the affected timeframe across Stages 2–5; M1/M5 stay independent and M15 remains advisory-only.
- Adds durable JSON checkpoints and deterministic resume by rebuilding engine state from the beginning, validating run/dataset/config/code identity, durable ledger-prefix SHA-256 and complete JSONL record boundary.
- Adds 14 focused Stage 6A tests for metadata/hash/schema, closed-bar evidence, aligned captures, gap isolation, M1/M5 independence, restart determinism, future-perturbation prefix invariance, chunk-size invariance and bounded REST paging.
- Stage 6A focused tests: 14 passed; focused Stage 1–5 suite remains 158 passed; full regression suite: 660 passed.
- Important metadata limitation: a dataset currently supports one declared metadata snapshot covering its entire window; multiple historical tick-size effective intervals are not supported. The quality label is caller-supplied and must be backed by retained provenance.
- No scoring/qualification, entries, SL/TP, fee/slippage, fills, PnL, CVD/Depth/Absorption integration, private API, live orders, Telegram/dashboard or DB migration. Synthetic tests only; no real historical dataset calibration or profitability claim.

## 0.30.1 — Unit 05E Stage 6: Replay-Readiness Design Review (2026-11-11)

- Documentation-only design checkpoint; no strategy or market-data runtime logic changed.
- Defines the required USDⓈ-M M1/M5 Kline inputs and optional M15 context, plus later Aggregate Trade and historical L2 data tiers.
- Defines immutable dataset manifests, metadata-quality classification for historical `tickSize`, replay/capture identity, closed-bar provenance and UTC chronological scheduling.
- Specifies the Stage 1–5 replay pipeline, gap segmentation, warm-up convergence, chronological train/validation/test partitions and evidence-only output ledger.
- Adds explicit anti-look-ahead, chunk-size/restart determinism and right-censor acceptance criteria.
- Selects deterministic historical replay harness as the next implementation; scoring, candidate qualification, entries, PnL, fills, private API and live orders remain excluded.
- Verification is documentation/package metadata only; inherited suite remains 646 tests.

## 0.30.0 — Unit 05E Stage 5: Liquidity & FVG Evidence Engine (2026-11-11)

- Adds `strategy/scalping_liquidity_fvg.py` as an independent optional evidence engine over same-capture Stage-2 confirmed pivots and closed Binance Klines.
- Adds swing high/low, internal local high/low and equal-high/equal-low references. Equal-level grouping uses exact Binance tick-size multiples; default tolerance is 2 ticks and remains provisional pending replay.
- Enforces pivot causality: a pivot is available only after its confirmation candle has closed. Stage-2 break events retire pivots only after the break confirmation time; a qualified sweep consumes its pivot identities.
- Adds closed-candle sweep evidence with distinct wick breach, close-through and strict close-back semantics. Default close-back qualification is enabled; high-side sweeps are bearish and low-side sweeps bullish.
- Adds exact bullish/bearish three-candle FVG boundaries and C1/C2/C3 provenance. Tracks ACTIVE, TOUCHED, PARTIALLY_FILLED and FILLED independently from OB lifecycle; no minimum gap/ATR threshold is hard-coded.
- Adds immutable records, deterministic IDs/JSONL, duplicate idempotence, exact tick/provenance validation, incremental replay, revision/gap fail-closed checks, atomic M1/M5 preflight, reset and bounded state. Nonterminal FVGs are never silently evicted.
- Exposes Stage-5 public API from `divatrading.strategy`. M1/M5 remain independent; M15 advisory-only.
- Adds 36 focused Stage-5 tests; Unit 05E Stages 1–5 focused total: 158; full regression suite: 646 passed.
- No OB veto, retest/entry, scoring/ranking, Entry/SL/TP, risk, position management, CVD/Depth/Absorption integration, private API, live order, Telegram/dashboard or DB migration. SQLite remains schema v5.
- Synthetic tests validate mechanics only. Binance historical replay calibration, live Binance validation, Windows 10/Python 3.12.9 and Pine runtime parity remain unverified.

## 0.29.0 — Unit 05E Stage 4: OB Validation & Lifecycle (2026-11-11)

- Adds `scalping_order_block_lifecycle.py` to manage Stage-3 OB candidates through CANDIDATE, ACTIVE_FRESH, TOUCHED, MITIGATED, INVALIDATED and EXPIRED states.
- Separates zone touch from positive-depth mitigation; records first touch, first mitigation, maximum penetration depth and observed price.
- Adds explicit WICK/CLOSE invalidation and STRICT/INCLUSIVE distal-boundary equality semantics; defaults WICK/STRICT.
- Uses a provisional 300-bar age limit in each candidate's own source timeframe; expiry occurs only after the limit is exceeded and requires Binance replay calibration.
- Excludes the break candle from post-formation touch evaluation; same subsequent candle records touch/depth before invalidation. A gap candle entirely beyond the zone can invalidate but cannot invent a touch or mitigation.
- Verifies source and break OHLC against same-capture closed Klines; gaps, late candidates, revised candles, incomplete sources and invalid tick-grid data fail closed.
- Keeps M1/M5 lifecycle independent and M15 advisory-only; overlapping OBs remain distinct. MTF preflight is atomic.
- Bounds per-symbol/timeframe OBs, traces and candle/candidate fingerprints; evicts oldest terminal records only, otherwise raises at capacity. Lifecycle always reports filled/consumed false.
- Adds 33 focused Stage-4 tests; focused Unit 05E Stages 1–4 total: 122; full regression suite: 610 passed.
- No retest, entry, scoring, FVG/sweep, Entry/SL/TP, risk, position management, private API, live order, Telegram/dashboard or DB migration.

## 0.28.0 — Unit 05E Stage 3: Displacement Qualification & Initial OB Formation (2026-11-10)

- Preserves Stage 1–2 and all prior releases; adds a new SMC V2 initial Order Block formation engine without modifying legacy Unit 05D Pine modules.
- Consumes exact Stage-2 BOS/CHoCH events and requires matching immutable break-bar trace, previous-close provenance and same-capture Binance Kline identity where available.
- Measures break candle body/full range/body-range ratio, close extension beyond the broken level and tick-normalized extension, plus directional-leg start/count/body/range measurements.
- Defines the displacement leg as a bounded run of consecutive same-direction body candles ending at the break candle. Doji/opposite candle ends the leg; overlong legs fail closed.
- Selects the nearest last opposing candle within a bounded lookback (bearish source for bullish OB, bullish source for bearish OB), skips dojis, and uses full source wick as zone boundaries.
- Requires exact Binance tick-grid boundaries without rounding. Adds deterministic candidate/event/leg IDs, immutable candidate/trace records, bounded state, idempotent event handling and deterministic JSONL.
- M1/M5 candidates are independent; M15 is advisory-only. FVG evidence is marked `NOT_EVALUATED`; no FVG or sweep gate is added.
- Numeric displacement cutoffs default disabled until Binance historical replay calibration; ATR-normalized metrics remain deferred pending explicit ATR semantics.
- Adds 30 focused Stage-3 tests; Unit 05E Stages 1–3 focused total: 89; full regression suite: 577 passed. Tests validate mechanics only and do not establish profitability or parity.
- No OB lifecycle, retest, entry, SL/TP, risk, execution, private API, Telegram/dashboard or SQLite migration.

## 0.27.0 — Unit 05E Stage 2: SMC V2 Market Structure Engine (2026-11-10)

- Preserves Unit 05E Stage 1 and all prior releases; adds the new independent-per-symbol/timeframe SMC V2 structure engine without changing legacy Unit 05D Pine modules.
- Adds confirmed swing/internal pivots with configurable left/right windows, strict equal-high/low rejection, outside-bar dual pivots and right-side-close confirmation. Default swing 3/3 and internal 1/1 are provisional scaffolding, not calibrated settings; per-timeframe overrides are supported.
- Adds strict close-cross BOS/CHoCH events using confirmed pivots only. Wick-only breaks do not count. Initial/same-direction breaks classify BOS; opposite-direction breaks classify CHoCH. Swing and internal bias are independent.
- Adds deterministic pivot/event identities, source/confirmation timestamps, exact broken level, protected high/low landmarks, immutable per-bar/event trace and deterministic JSONL serialization.
- Adds incremental snapshot overlap/correction checks, explicit reset, per-timeframe warm-up, cross-timeframe preflight before state mutation, exact tick-grid/closed-candle checks and bounded symbol/pivot/event/trace/history state.
- M1/M5 run independently; M15 is optional advisory context and never suppresses a valid M1/M5 source. No legacy nested M5/M15 priority is implemented.
- Stage 2 focused tests: 32 passed; full inherited regression: 547 passed. Tests validate mechanics only; no Pine parity, profitability, live Binance or target Windows runtime claim is made.
- No OB/displacement/FVG/sweep, entry, risk, private API, order execution, Telegram/dashboard or SQLite migration.

## 0.26.0 — Unit 05E Stage 1: SMC V2 Scalping Data Contract (2026-11-10)

- Starts SMC Engine V2 as a new scalping strategy while preserving Unit 05D v0.25.0 as an immutable legacy Pine replay reference. The legacy nested M5/M15 arbitration plan is not used by V2.
- Adds `InstrumentSpec` mapped from exact Binance USDⓈ-M `SymbolInfo` and `PRICE_FILTER.tickSize`; price precision is never substituted for tick size.
- Adds `ScalpingMarketDataAdapter`, immutable `ScalpingMarketDataView`, and per-component readiness. M1/M5 setup-source readiness is independent; M15 is optional context.
- Keeps Mark Price, Delta/CVD, Depth, Absorption and orchestrator health as separately reported optional components. Entry quote readiness is separate from structure scan readiness.
- Validates candle and best bid/ask tick-grid alignment without rounding data into compliance.
- Adds bounded `AggregateTradeEventFanout`, symbol-filterable queues and optional `UnifiedMarketDataOrchestrator` integration. Fan-out overflow fails closed; the orchestrator remains sole owner of the source feed queue.
- Adds 27 focused tests; full regression suite: 515 passed.
- No SMC V2 structure/OB calculations, dynamic Entry/SL/TP, risk sizing, order execution, private API, Telegram/dashboard, or SQLite migration.
- Target Windows 10/Python 3.12.9 and live Binance connectivity remain untested; verification runtime is Python 3.13.5/Linux.

## 0.25.0 — Unit 05D Stage 8 (2026-11-10)

- Added exact Pine local entry/SL/TP proxy geometry after Stage-6 candidate selection and Stage-7 scoring; the selected candidate is never replaced or retried when its levels fail.
- Entry remains the source-candle `close` proxy, explicitly separate from Binance Bid/Ask and actual fills.
- Added exact spread estimate, max(spread/ATR) stop buffer, high-volatility SL multiplier, direction-specific OB structural stop, strict positive-stop check, minimum-stop adjustment, max-SL ATR and spread-to-stop percentage `levelsOK` gates.
- Added Pine `Fixed RR`, `Structure`, and `Hybrid OB/Liquidity` target modes, including directional structural target, oldest-to-newest opposing-OB scan, `minRR` behavior, fixed-RR fallback and opposing-OB obstacle rejection.
- Added immutable `PineSmcSignalProxy` and `PineSmcLevelEvaluationTrace`; trace records intermediate level values, ordered rejection reasons, selected Stage-6 candidate, Stage-7 score, target source and successful-only signal consumption proxy.
- `consumeOBOnSignal` changes the selected indicator OB `used` flag only after every Pine level check passes; this remains distinct from exchange-fill consumption.
- Added 21 Stage-8 tests; focused Unit 05D Stage 1–8 tests total 110; full regression suite: 488 passed.
- No one-source-bar output shift, MTF arbitration, dynamic trade management, private API, Binance order execution, Telegram/dashboard, risk sizing or SQLite migration.

## 0.24.0 — Unit 05D Stage 7 (2026-11-10)

- Implemented Pine `f_scoreOB()` with all nine weighted quality components, Pine clamp/fallback behavior, quality denominator 90, 45/55 timing score and 80/20 setup score.
- Added bullish/bearish ideal entry bands and the `deepDepth <= nearDepth` fallback.
- Added full-loaded-history prior-low/high series for score confluence, distinct from Stage-6 `requireSweep` qualification.
- Added exact `tick_size` dependency for `syminfo.mintick`, sourced from the matching Binance USD-M `PRICE_FILTER.tickSize`; missing tick size fails closed for scoring.
- Added immutable active-OB scoring snapshots and selected-score link while preserving Stage-6 chosen candidate and active-array order.
- Added 16 focused Stage-7 tests; focused Stage 1–7 tests total 89; full regression suite 467 passed.
- No final signal, proxy level geometry, `used` mutation, output shift, MTF arbitration or DB migration.

## 0.23.0 — Unit 05D Stage 6 (2026-11-10)

- Added Pine-compatible bullish/bearish rejection trigger with exact touch, candle direction, OB midpoint and wick-percent conditions.
- Added structure trigger using BOS/CHoCH flags, event-extreme-after-break validation, `structAllowBOS` and direction-specific OB-boundary checks.
- Preserved rejection-over-structure trigger priority and integer trigger codes.
- Added optional nested sweep-window/lookback scan with strict wick-through/close-back rules and exact historical offsets.
- Stage 6 consumes the Stage-5 newest-to-oldest candidate stream and stops on the first trigger-plus-sweep accepted candidate; it does not mutate OB `used`.
- Added immutable trigger/sweep trace and replay metadata plus 16 focused tests; Stage 1–6 focused tests total 73; full regression suite: 451 passed.
- No scoring, Pine level geometry, final signal output, one-source-bar shift, MTF arbitration, Dynamic Entry/SL/TP, private API, Telegram/dashboard or order execution. SQLite remains schema v5.

## 0.22.0 — Unit 05D Stage 5 (2026-11-10)

- Added ordered OB eligibility scanning for the exact `FindSignal()` gates: fresh-only/used, age window, swing-trend direction, premium/discount equilibrium, stored FVG flag, and Stage-4 volatility regime flags.
- Preserved Pine's timeframe max-age routing: M1 and M5 both receive `maxAgeM5`; M15 receives `maxAgeM15`.
- Preserved strict age and premium/discount boundary operators, gate evaluation order, and newest-to-oldest active-array traversal.
- Added immutable candidate evaluations with original active-array indices, OB snapshots, eligibility booleans, and ordered rejection reason codes. The scan never mutates `used` or reorders the active array.
- Added 11 focused Stage-5 tests; Stage 1–5 focused tests total 57; full regression suite: 436 passed.
- Updated public strategy exports, config/replay metadata and deterministic JSONL traces; SQLite remains schema v5 with no migration.
- No rejection/structure trigger, sweep, scoring, final signal emission, one-source-bar shift, MTF arbitration, Dynamic Entry/SL/TP, private API, Telegram/dashboard or Binance order execution.

## 0.21.0 — Unit 05D Stage 4 (2026-11-10)

- Added streaming Pine-compatible ATR(14), RSI(14), SMA(volume,20), and DMI(14,14) series with full loaded-history pre-roll independent of the SMC warmup reset.
- Preserved first-bar TR/DM distinctions, RMA seed points, RSI zero-gain/zero-loss behavior, DMI DI/ADX availability and unavailable values as JSON null.
- Added exact `atrRatioNow`, `volatilityExtreme` and `volatilityChoppy` trace fields, using the previous-bar custom ATR(200) value and Pine threshold operators.
- Added 14 focused Stage-4 tests; Stage 1–4 focused tests total 46; full regression suite: 424 tests pass.
- Updated replay API metadata and exported immutable `PineSmcIndicatorTrace`; no SQLite migration.
- No OB candidate eligibility, triggers, sweep, scoring, signal/MTF output, Dynamic Entry/SL/TP, private API, Telegram/dashboard or order execution.

## 0.20.0 — Unit 05D Stage 3 (2026-11-10)

- Implemented source-derived bullish/bearish OB source-candle selection from parsed candle extrema after internal structure breaks; strict comparisons preserve earliest equal extrema.
- Added exact directional FVG scans using Pine neighbor offsets and the current break-bar `fvgMinAtr * atr200` threshold.
- Added typed active OB records matching the original parallel arrays, 100-record capacity and oldest-first FIFO eviction.
- Added same-bar creation followed by reverse-index mitigation using exact `mitigateClose` high/low versus close selection and strict boundary comparisons.
- Added immutable created/mitigated/evicted/active OB trace snapshots and deterministic JSONL output.
- Added 11 focused OB/FVG lifecycle tests; Stage 1–3 focused tests total 32; full regression suite passes 410 tests.
- Updated package version to 0.20.0; no SQLite migration.
- No OB candidate scan, trigger, sweep, scoring, signal/MTF output, Dynamic Entry/SL/TP, private API, Telegram/dashboard or Binance execution.

## 0.19.0 — Unit 05D Stage 2 (2026-11-10)

- Added exact Pine `confluenceFilter` handling, preserving the unusual `min(close, open-low)` expression and strict comparisons.
- Added sequential internal bullish/bearish structure breaks, crossed-state consumption, separate internal trend and per-bar BOS/CHoCH event flags.
- Added strict raw event-extreme scans from the crossed internal pivot through the current bar, retaining the oldest source candle on equal extrema.
- Added swing-high then swing-low crossing, crossed flags and separate swing trend updates after internal event processing.
- Extended immutable per-bar traces and deterministic JSONL with confluence outcomes, independent trends, structure events and event-extreme index/time.
- Retained complete in-window candle history only within the Pine warmup bound (maximum 2,500 bars) to reproduce event-extreme scans.
- Added six focused tests; 21 focused structure tests and 399 full regression tests pass in the working tree.
- No OB/FVG lifecycle, signal candidate selection, scoring, signal output, MTF arbitration, Dynamic Entry/SL/TP, database migration, private API, Telegram/dashboard, or order execution.

## 0.18.0 — Unit 05D Stage 1 (2026-11-10)

- Added Pine-derived `PineSmcStructureEngine` for one independent timeframe context at a time.
- Implemented exact warmup reset, local source-bar index, True Range and custom ATR(200) initialization/Wilder-like recurrence.
- Implemented parsed candle high-volatility branch with the source's intentional high/low inversion.
- Implemented swing/internal pivot legs with delayed offsets, strict tie rejection, high-branch priority, pivot index/time capture and swing range extrema.
- Added immutable per-bar/pivot traces and deterministic JSONL serialization; consumes the existing validated Binance USD-M `Kline` model.
- Added 15 focused source-derived tests; full regression suite: 393 passed. These are implementation tests, not TradingView parity observations.
- Reframed TradingView CSV fixture intake as optional; source translation can proceed without paid chart export, while independent parity remains unmeasured.
- No OB/FVG, BOS/CHoCH event handling, signals, scoring, MTF arbitration, Dynamic Entry/SL/TP, DB migration, private API, Telegram/dashboard, or order execution.

## 0.17.0 — Unit 05C (2026-11-10)

- Added a separately hashed additive TradingView Pine capture patch with 47 Data Window plot outputs for M1/M5/M15 accepted signals and MTF arbitration flags. Original signal expressions are not changed.
- Added fixture v2 schema and capture manifest template with exact Pine/instrumentation identity, Binance USD-M perpetual ticker, all 49 effective inputs, full-history boundary, three raw CSV export hashes and coverage assertion.
- Added `build_fixture_from_capture_manifest()` and `validate_reference_fixture()` with CSV source hash/size/content verification, Decimal/tick-grid, OHLC, candle continuity, MTF boundary, signal event/OB timestamp, entry-proxy/source-close and arbitration-flag checks.
- Added `divatrading validate-pine-fixture` CLI and a capture guide.
- Added 47-plot capture overlay plus a ready-to-paste full Pine file; the original Pine source is recovered byte-for-byte when the patch is removed.
- Added 14 focused fixture-intake tests; full regression suite: 378 passed.
- No actual TradingView export bundle was supplied; zero real reference fixtures accepted, Pine parity not measured. No SMC engine or order execution added. SQLite remains schema v5.

# Changelog

## 0.47.0 — Managed Position Lifecycle Foundation (2026-11-13)

- Adds deterministic Decimal-based LONG/SHORT lifecycle decisions: partial TP, confirmed-fill-gated breakeven and favorable-excursion trailing stop proposals.
- Adds stable action IDs, monotonic stop proposals, SQLite versioned lifecycle state and idempotent action claims/status updates.
- Adds 18 focused lifecycle/persistence tests. Full regression: 797 passed.
- Does not yet submit partial-close or stop-modification orders; exchange adapter, fill-confirmed reducer, verified-flat risk release and full exit recovery remain outstanding.
- No TESTNET/LIVE API request or order used.

## 0.45.0 — Atomic Portfolio Risk Reservations (2026-11-13)

- Adds persistent SQLite risk reservations keyed by signal ID and serialized with `BEGIN IMMEDIATE` so concurrent multi-pair workers cannot spend the same local portfolio risk budget.
- Adds exact Decimal budget admission over exchange-reported open-risk input, active local reservations and requested trade risk; includes max-position admission.
- Wires reservation before execution in the multi-pair coordinator; rejected and duplicate-active reservations block order submission. TESTNET/LIVE `ExecutionService` independently requires a matching active reservation. PAPER reservations release after paper-only routing; uncertain TESTNET/LIVE outcomes retain reservations pending reconciliation.
- Adds idempotent release API and tests for concurrent admission, duplicate signals, release, invalid financial inputs and max-position limits. Full regression: 762 passed.
- Scope remains partial: account freshness, User Data Stream, exchange/local reconciliation and automated live reservation release are next. No private API or exchange order used.

## 0.39.0 — Unit 05E Stage 6C.3B: Replay Runtime Optimization & Partial Lifecycle Diagnostics (2026-11-12)

- Replace recursive `deepcopy` of Stage 4/5 replay state with explicit transactional clones of mutable containers and mutable OB/FVG records; immutable Klines and evidence records are safely reused.
- Index Stage 5 pivot provenance lookups by candle open/close time instead of repeated linear scans.
- Stage 4 skips full candidate re-validation after an identical candidate fingerprint has already been validated and retained; conflicting reuse remains rejected.
- Preserve the Stage 4/5 atomic commit behavior and all strategy state-transition rules. A 180-capture full-ledger comparison produced 12,541 normalized-identical records before/after optimization.
- Profiling on the same 180-capture sample improved from 6.321s to 2.300s under cProfile (~2.75x); full regression: 719 passed.
- Real BTCUSDT compact partial diagnostic completed 600 captures (10h), zero replay gaps, 140,996 suppressed pre-roll records. At the endpoint, M1 retained 210 FVGs (19 nonterminal; 41.02% total retained occupancy of 512) and M5 retained 33 (6 nonterminal; 6.45%). This is not a 25h lifecycle validation.
- The requested 27h pre-roll + 60m evaluation replay did not complete within the execution window. Incomplete runs are not accepted as convergence evidence. No FVG expiry or strategy semantics were changed; no warm-up policy is approved.

## 0.29.0 — Unit 05E Stage 4: OB Validation & Lifecycle (2026-11-11)

- Adds `scalping_order_block_lifecycle.py` to manage Stage-3 OB candidates through CANDIDATE, ACTIVE_FRESH, TOUCHED, MITIGATED, INVALIDATED and EXPIRED states.
- Separates zone touch from positive-depth mitigation; records first touch, first mitigation, maximum penetration depth and observed price.
- Adds explicit WICK/CLOSE invalidation and STRICT/INCLUSIVE distal-boundary equality semantics; defaults WICK/STRICT.
- Uses a provisional 300-bar age limit in each candidate's own source timeframe; expiry occurs only after the limit is exceeded and requires Binance replay calibration.
- Excludes the break candle from post-formation touch evaluation; same subsequent candle records touch/depth before invalidation. A gap candle entirely beyond the zone can invalidate but cannot invent a touch or mitigation.
- Verifies source and break OHLC against same-capture closed Klines; gaps, late candidates, revised candles, incomplete sources and invalid tick-grid data fail closed.
- Keeps M1/M5 lifecycle independent and M15 advisory-only; overlapping OBs remain distinct. MTF preflight is atomic.
- Bounds per-symbol/timeframe OBs, traces and candle/candidate fingerprints; evicts oldest terminal records only, otherwise raises at capacity. Lifecycle always reports filled/consumed false.
- Adds 33 focused Stage-4 tests; focused Unit 05E Stages 1–4 total: 122; full regression suite: 610 passed.
- No retest, entry, scoring, FVG/sweep, Entry/SL/TP, risk, position management, private API, live order, Telegram/dashboard or DB migration.


- Adds  to manage Stage-3 OB candidates through CANDIDATE, ACTIVE_FRESH, TOUCHED, MITIGATED, INVALIDATED and EXPIRED states.
- Separates zone touch from positive-depth mitigation; records first touch, first mitigation, maximum penetration depth and observed price.
- Adds explicit WICK/CLOSE invalidation and STRICT/INCLUSIVE distal-boundary equality semantics; defaults WICK/STRICT.
- Uses a provisional 300-bar age limit in each candidate's own source timeframe; expiry occurs only after the limit is exceeded and requires Binance replay calibration.
- Excludes the break candle from post-formation touch evaluation; same subsequent candle records touch/depth before invalidation. A gap candle entirely beyond the zone can invalidate but cannot invent a touch or mitigation.
- Verifies source and break OHLC against same-capture closed Klines; gaps, late candidates, revised candles, incomplete sources and invalid tick-grid data fail closed.
- Keeps M1/M5 lifecycle independent and M15 advisory-only; overlapping OBs remain distinct. MTF preflight is atomic.
- Bounds per-symbol/timeframe OBs, traces and candle/candidate fingerprints; evicts oldest terminal records only, otherwise raises at capacity. Lifecycle always reports filled/consumed false.
- Adds 33 focused Stage-4 tests; focused Unit 05E Stages 1–4 total: 122; full regression suite: 610 passed.
- No retest, entry, scoring, FVG/sweep, Entry/SL/TP, risk, position management, private API, live order, Telegram/dashboard or DB migration.

## 0.16.0 — Unit 05B (2026-11-10)

- Audited Pine v6 source and confirmed two Library candidates are byte-identical (SHA-256 recorded in `reference/pine_smc/PINE_SOURCE_MANIFEST.json`).
- Added complete input/default inventory and source-line audit for warmup, indicators, structure, OB/FVG, mitigation, scan priority, filters, trigger, sweep, scoring, levels and MTF arbitration.
- Added deterministic OHLCV replay and trusted reference fixture contract/schema/template. No expected signal values were fabricated; no trusted TradingView fixtures were available.
- Added immutable normalized `ParitySignal` records and deterministic `compare_signal_sets()` diff utility; this does not calculate strategy signals.
- No DB migration, market-data changes, Telegram/dashboard, private API or order execution.

## 0.15.0 — Unit 05A

- Added immutable, read-only `StrategyMarketDataSnapshot` and adapter.
- Added M1/M5/M15 closed-candle series contract with separate forming-candle field.
- Added bounded candle count, ordering/gap, closure-time, freshness and source-completeness gates.
- Added Mark Price, Delta/CVD, depth, absorption and Unit 04G orchestrator cross-source checks.
- Added exact symbol, timestamp, depth update-ID and absorption/depth update-ID coherence checks.
- Added 22 focused tests; full regression suite: 353 passed.
- SQLite remains schema v5; no SMC strategy, Pine parity or order-execution changes.

## 0.14.0 — Unit 04G

- Added bounded unified orchestration for Aggregate Trade ingestion/recovery, Delta/CVD, supervised depth and absorption evidence.
- Added immutable per-symbol readiness with reconnect generation, queue and source failure reporting.
- Kept REST/SQLite work off the event loop; startup event queue is bounded and fails closed on overflow.
- Full regression suite in the current verified source tree: 331 tests passed before Unit 05A.

## 0.13.0 — Unit 04F

- Added bounded read-only Delta/CVD and supervised depth alignment.
- Added symmetric BUY-at-ask / SELL-at-bid absorption candidate evidence.
- Added input readiness, freshness, timestamp-skew, clock-regression and sample-gap gates.
- Added displayed depth persistence/recovery measurements and auditable reason codes.
- Added 16 focused tests; full regression suite: 319 passed.
- SQLite schema remains v5; no strategy or execution integration.

## 0.12.0 — Unit 04E

- Added per-symbol order-book health and resynchronization supervisor.
- Full regression suite: 301 passed.

## 0.35.0 — Unit 05E Stage 6B.4 Integration & Final Review

- Added `replay-workflow` to orchestrate raw-source quality audit, strict manifest/source eligibility, deterministic Stage 6A replay, Stage 6B.2 chronological analytics and Stage 6B.3 warm-up comparison.
- Every integrated trial exercises a one-capture checkpoint followed by Stage 6A resume-to-completion before downstream analytics.
- Added Stage 6B integrated workflow plan/report Draft 2020-12 schemas, cross-stage provenance linking, artifact hashes and input immutability checks.
- Workflow fails closed when strict dataset-quality eligibility or historical-effective metadata validation fails. Raw source gaps are never repaired or interpolated.
- No strategy detection semantics, calibration parameters, private API or order execution were changed.

## v0.40.0 — Multi-Pair Auto-Trading Core (2026-11-12)

### Added
- AUTO/MANUAL eligible USDⓈ-M USDT perpetual universe selection with 24h liquidity rank, minimum quote-volume/trade-count filters, exclusions, manual allow-list and bounded active-symbol capacity.
- Public `/fapi/v1/ticker/24hr` access for current universe ranking.
- QualifiedSignal and TradePlan contracts with directional price-geometry validation.
- Decimal portfolio risk sizing with aggregate open-risk budget, per-symbol notional ceiling, leverage ceiling, exact tick alignment, and exchange quantity/min-notional constraints.
- Signed private Futures REST client with explicit TESTNET/LIVE base URL, server-time offset, account/balance/position/open-order queries, standard order endpoints, conditional Algo Order endpoints and income history.
- Separate SQLite execution ledger with atomic signal idempotency, deterministic client IDs, entry/SL/TP order records, managed positions, audit events, income-history deduplication and entry kill switch.
- Execution service with PAPER default, explicit TESTNET/LIVE opt-in, no blind retry of ambiguous POSTs, deterministic entry/protective client IDs, SL/TP algo-order attachment after an observed fill, pending-entry reconciliation, and kill-switch controls.
- Multi-symbol SMC V2 Stage 2–5 evidence pipeline and global multi-pair execution coordinator.
- `divatrading universe` read-only CLI for AUTO/MANUAL symbol universe inspection.

### Boundaries
- Existing SMC V2 Stage 1–5 rules were not modified.
- This delivery provides the trading-side execution core, not the final continuous signal-to-position runtime. Qualified signals still need to be produced by the strategy integration worker.
- No API credentials, TESTNET orders or LIVE orders were used.

## v0.42.0 — Production Multi-Pair Public Feed Graph (2026-11-12)

### Added
- Added `BinancePublicFeedFactory` and per-symbol production feed graphs for Kline M1/M5/M15, Mark Price, Aggregate Trades, depth snapshots/diffs, Delta/CVD, absorption and the SMC V2 market-data adapter.
- Added closed-candle REST bootstrap and reconnect/gap recovery through the existing Kline recovery service; forming candles are carried separately from closed-candle history.
- Added shared REST history request pacing and shared serialized depth snapshot pacing across active symbol workers.
- Added fail-closed complete-snapshot gating: all Kline timeframes, Mark Price, aggregate continuity/Delta-CVD, depth sequencing/freshness, absorption and orchestrator readiness must be valid before SMC V2 capture emission.
- Added read-only `divatrading market-runtime` AUTO/MANUAL CLI with bounded symbol count, liquidity filters, bootstrap history and snapshot controls.
- Added feed graph config/factory tests; full suite: 735 passed.

### Boundaries
- No SMC Stage 1–5 strategy rules were changed.
- This release composes public market-data feeds and routes complete captures into SMC V2. It does not qualify a final trading signal, calculate final entry/SL/TP or submit orders.
- No authenticated API, TESTNET or LIVE orders were used. `market-runtime` is read-only.
- Windows 10 / Python 3.12.9 / 8 GB and real Binance connectivity have not been verified in this build environment.

## v0.49.0 — Managed Position Supervisor (2026-11-13)

- Adds continuous per-symbol Mark Price workers and automatic managed-position lifecycle action dispatch.
- Connects position supervisor into `account-runtime` with User Data Stream and exchange reconciliation.
- Adds structural-invalidation market exit and explicit operator emergency-close flow.
- Adds exact market quantity and price tick filter lookup from ExchangeInfo.
- Tracks cumulative partial TP fills against original position size; no repeated 50%-of-residual compounding after terminal partial fills.
- Separates entry halt from existing-position management while requiring clean, fresh and watermark-consistent account reconciliation.
- Full regression: 832 passed. Local fakes/mocks only; no TESTNET/LIVE or Windows target validation.

## 0.52.0 — Quantity-Scoped Protection & Partial-Exit Resize (2026-11-13)

- Uses explicit per-signal quantity for initial STOP/TP Algo orders, with One-way `reduceOnly=true` and Hedge Mode `positionSide` semantics; `closePosition=true` is omitted.
- Reconciles every signal lot against exact protective order IDs, direction, positionSide and quantity.
- Adds durable query-first `RESIZE_PROTECTION` actions; after confirmed partial TP or partial market exits, both remaining STOP/TP orders are replaced and REST-verified before old protections are cancelled.
- Extends deterministic regression coverage for resize idempotency, partial exits and Hedge Mode behavior. Full suite: 855 passed; no TESTNET/LIVE API/order tests.

## v0.55.0 — True Multi-Lot Position Supervisor (2026-11-13)

- Removes the single-signal-per-`(symbol, positionSide)` supervisor refusal and evaluates every open signal lot independently on each symbol Mark Price event.
- Keeps per-signal lifecycle state, entry price, quantity, partial TP progress, protection IDs and risk reservation independent while checking aggregate local quantity against the live exchange position.
- Serializes pending lifecycle actions across all lots sharing the same `(symbol, positionSide)` group to prevent stale-snapshot concurrent reductions.
- Confirms partial TP, market exits and triggered Algo fills against aggregate residual quantity; closes/releases only the attributed lot when its own allocation reaches zero.
- Adds exchange-flat group finalization, per-lot protective-order reconciliation, replay-safe Algo trigger lookup, and restart/replay tests.
- Adds a pre-risk coordinator gate and a second ExecutionService gate: same-side TESTNET/LIVE scale-in stays disabled pending TESTNET qualification; One-way `BOTH` blocks additional exposure on the symbol. PAPER remains available for multi-lot simulation.
- Full regression and clean-extraction regression: 891 passed. Local deterministic tests only; no authenticated Binance TESTNET/LIVE requests or orders. Windows 10 / Python 3.12.9 target remains unvalidated.


## v0.57.0B2 — 2026-11-14

- Fixed TESTNET preflight account-configuration lookup to use signed `GET /fapi/v1/accountConfig` for `canTrade` and `multiAssetsMargin`.
- Kept `GET /fapi/v3/account` for wallet and available-balance data.
- Added regression coverage for Binance's split account-information/account-configuration response contract and signed Demo endpoint routing.
- No trade execution, account setting mutation, leverage change, or margin-mode change added.

## v0.57.0C — Controlled TESTNET SMC Entry Qualification
- Adds a second independent TESTNET actual-order authorization flag, `DIVA_ENABLE_TESTNET_STAGE_C`, default false; `DIVA_ENABLE_TESTNET_ORDERS=true` alone is no longer sufficient.
- Restricts Stage C TESTNET autonomous qualification to one manually selected symbol, one worker, max 0.10% risk per trade and max 0.25% portfolio risk.
- Reuses the existing autonomous SMC V2 → account readiness → risk reservation → idempotent entry → User Data Stream fill → REST reconciliation → protective Algo order → position supervisor path.
- Stage C waits for a genuine SMC-qualified signal; it does not force or synthesize an entry.
- LIVE remains disabled. No real exchange order/fill/protection was executed during local build tests.


## v0.58.0rc2 — Telegram Signal Center & Kronos-mini Shadow Forecast (2026-11-14)

- Adds durable Telegram `SIGNAL_ONLY` publication of SMC-qualified signals with PNG chart, Entry, SL, TP1 at 1R, final TP and gross RRR. Publisher is outbound-only and never submits Binance orders.
- Adds optional lazy Kronos-mini M5 shadow forecast, explicit CPU-only installer, local revision manifest, signal-linked forecast persistence and exact future-candle forecast evaluation. Model/source assets are not bundled in the release archive.
- Adds SQLite schema v6, forecast provenance identity, chart gap checks, bounded caches and Windows launchers.
- Source regression: 1,013 passed on Linux/Python 3.13.5. Windows 10/Python 3.12.9 and actual Kronos download/inference remain user-side qualification gates. LIVE routing remains disabled.

## v0.58.0rc3 — LIVE Read-Only Account Feasibility (2026-11-15)
- Added explicit opt-in read-only LIVE account preflight, pinned to official Binance USDⓈ-M REST.
- Added checks for account config, balances, position mode, clean account state, selected perpetual metadata and account-specific leverage brackets.
- Added read-only leverage bracket and commission rate client methods.
- No LIVE order routing or account mutations enabled.
