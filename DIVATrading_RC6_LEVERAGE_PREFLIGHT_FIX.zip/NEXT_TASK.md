# Next task — after audit candidate 0.59.0rc3

**Status:** Source candidate can be exercised in PAPER and qualified TESTNET under explicit opt-in; autonomous LIVE remains deliberately blocked. Do not bypass it. See `AUDIT_RC3_STATUS_DAN_HANDOFF.md` for detailed three-way classification of delivered / partial / planned.

1. **Exchange-readiness Stage C/Demo:** run clean Windows 10 + Python 3.12.9 `INSTALL_WINDOWS.bat`/`TEST_WINDOWS.bat`; confirm separate Binance Demo REST + WS connectivity, metadata, account User Data Stream, order/test. Keep TESTNET actual order flags off until readiness confirmed.
2. **Safety reconciliation:** actual fill price, quantity and protective stop risk must be compared against reserved risk after every partial fill. Overshoot and missing protection need proven fail-closed behavior.
3. **Model/plan execution discipline:** executable bid/ask quote, volatility stop buffer, maximum execution slippage/spread, net reward/risk, setup expiry/cancel controls; check against actual Binance filters and exchange mode.
4. **Controlled Demo matching engine:** one BTCUSDT or another manually selected supported symbol, tiny risk below 0.10%/trade, 0.25% aggregate; verify entry/cancel/race, STOP/TP, partial fills, stream loss/recovery, restart, manual/external orders, kill switch, trade attribution, no orphan orders and ledger invariants. Operator must explicitly consent on their own account.
5. **Risk and strategy validation:** chronological out-of-sample walk-forward + realistic fees, funding, spread, slippage, fill/nonfill, drawdown; reject strategies without robust verified economics. A successful unit suite is not a positive-profit claim.
6. **Only after evidence:** Windows release-qualification, exact ZIP checksum, local read-only LIVE preflight, separate LIVE risk/identity gate, time-limited one-symbol launch and independent abort criteria. Preserve hard LIVE gate until separate audited release.

No user credentials are in this ZIP. Do not send API secrets or Telegram tokens in chat.
