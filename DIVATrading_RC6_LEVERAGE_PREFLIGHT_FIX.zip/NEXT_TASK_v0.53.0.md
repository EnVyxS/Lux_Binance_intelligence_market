# Next Task after v0.53.0 — REST User-Trades Backfill & Stream-Gap Recovery

Execution reliability remains the priority; do not divert effort to dashboards or cosmetic interfaces.

1. **REST historical fill backfill:** implement bounded, paginated Binance USDⓈ-M `/fapi/v1/userTrades` retrieval using symbol, time and `fromId` cursors; respect endpoint query windows/rate limits and never assume a stream event was received.
2. **Immutable fill merge:** merge REST trades with `ORDER_TRADE_UPDATE` / `TRADE_LITE` by `(symbol, tradeId)`, enrich missing event fields, detect contradictory duplicates, and preserve provenance for REST vs stream.
3. **Recovery watermark:** persist per-symbol trade-history cursor/watermark, define overlap windows for safe repeated backfill, and only advance the watermark after all pages are durably committed.
4. **Account reconciliation integration:** during startup/reconnect, pause new entries, backfill fills, rebuild per-signal projections, compare position/order/account truth, and clear entry halt only through the existing full reconciliation policy.
5. **Multi-lot supervisor:** after fill recovery is trusted, support multiple signal IDs on the same `(symbol, positionSide)` while routing per-lot Mark Price events, exits, protection, reservations and aggregate exchange quantity safely.
6. **Autonomous entry dispatcher:** integrate approved SMC V2 TradePlan -> atomic global risk reservation -> exact exchange-filter validation -> deterministic/idempotent entry -> fill confirmation -> quantity-scoped protection -> REST/stream reconciliation.
7. **TESTNET qualification:** run controlled account-mode, entry, protective order, partial-fill, sibling resize, reconnect and restart-recovery tests. Keep same-side scale-in and LIVE blocked until passed.
8. **Windows 10 / Python 3.12.9 / 8 GB validation** and deployment runbook.

Keep PAPER as default. Do not enable same-side scale-in or LIVE based on local mocked tests. No user PC action is required for this software-only checkpoint.
