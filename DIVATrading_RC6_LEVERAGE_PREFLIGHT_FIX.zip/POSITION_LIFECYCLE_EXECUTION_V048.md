# Position Lifecycle Execution Adapter — v0.48.0

## Scope

v0.48.0 connects the v0.47.0 lifecycle decision model to Binance USDⓈ-M execution primitives. It adds a fail-closed execution adapter, REST-based fill/order confirmation, durable action recovery, verified-flat finalization, and User Data Stream event routing. It is an execution slice, not the completed autonomous position-management runtime.

## Partial take-profit

- Requires a persisted managed position, fresh User Data Stream + account reconciliation observations, and an exchange position quantity matching the local lifecycle state.
- Requested quantity is floored to the exchange market lot step and checked against minimum quantity. It must not close the entire position.
- One-way mode sends an opposite-side MARKET order with `positionSide=BOTH` and `reduceOnly=true`.
- Hedge Mode sends an opposite-side MARKET order with `positionSide=LONG|SHORT` and omits `reduceOnly`.
- Uses deterministic `newClientOrderId`. The action is claimed in SQLite before POST. Duplicate or concurrently pending actions cannot POST again.
- A POST acknowledgement is not a fill. REST order status and exchange position quantity must agree before local quantity is updated. Partial terminal fills update actual remaining quantity but do not mark the full partial-TP target complete.
- Ambiguous submission, nonterminal cancellation, zero-fill terminal result, overfill, or position mismatch halts new entries and retains the risk reservation.

## Breakeven / trailing stop replacement

- Stop replacement only accepts a `MOVE_STOP` action with a strictly tighter, positive, tick-aligned trigger that remains on the correct side of the current mark price.
- The adapter submits a new `STOP_MARKET` conditional Algo Order with `closePosition=true` before canceling the previous DIVA-owned stop.
- It omits `quantity` and `reduceOnly` from close-all STOP requests. It does not send `newOrderRespType` to the Algo Order endpoint.
- Hedge Mode uses the matching `positionSide`; One-way uses `BOTH`.
- The prior stop is canceled only after the new stop is observed active through REST. The previous stop ID must be a known DIVA-managed stop for the same signal; arbitrary/manual algo IDs are rejected.
- The adapter verifies that the old stop is no longer open. If the new stop is inactive, cancellation is uncertain, or a triggered stop leaves residual exchange quantity, entries halt and risk remains reserved.
- BE/trailing flags and current stop are advanced only after REST confirms the replacement state.

## Exchange truth and finalization

`ORDER_TRADE_UPDATE`, `TRADE_LITE`, `ALGO_UPDATE`, and zero-quantity `ACCOUNT_UPDATE` events are wake-up signals only. The reducer uses REST order status and position risk as authoritative state.

Risk reservation release requires all of the following:

1. Binance position quantity is zero.
2. DIVA-linked standard entry/partial-close orders are absent from open orders.
3. DIVA-linked initial/current/replacement STOP/TP algo orders are absent from open algo orders.
4. A second REST position query still reports zero.
5. Local lifecycle state, managed position and intent are marked CLOSED.
6. The ledger confirms the risk reservation status is RELEASED.

REST verification errors halt entries and retain the active reservation. Manual/unrelated orders are not canceled. The adapter does not automatically flatten a non-flat position.

## Restart and reconnect recovery

`PositionLifecycleExecutionAdapter.recover_on_startup()` first reconciles durable pending actions by their deterministic exchange IDs; it never blindly re-POSTs a previous action. It then checks managed records with an unreleased reservation and finalizes only those whose exchange position is REST-confirmed flat.

`ExecutionAccountRuntime` invokes this recovery once after each new successful User Data Stream connection (identified by `connected_at_ms`), before its next account reconciliation pass. The `account-runtime` CLI now constructs and wires the lifecycle adapter/reducer automatically for explicitly enabled TESTNET/LIVE modes. Recovery failure preserves/sets the entry halt. Recovery does not clear a pre-existing manual/safety halt.

## Position-mode request rules

Binance USDⓈ-M conditional close-all STOP requests are sent to `POST /fapi/v1/algoOrder`. For `closePosition=true`, this adapter does not send `quantity` or `reduceOnly`. Hedge Mode supplies `positionSide=LONG|SHORT`; One-way supplies `BOTH`. Partial close is a standard MARKET order; `reduceOnly=true` is used only in One-way mode.

References:
- [Binance USDⓈ-M New Algo Order](https://developers.binance.com/docs/derivatives/usds-margined-futures/trade/rest-api/New-Algo-Order)
- [Binance USDⓈ-M Cancel Algo Order](https://developers.binance.com/docs/derivatives/usds-margined-futures/trade/rest-api/Cancel-Algo-Order)
- [Binance USDⓈ-M New Order](https://developers.binance.com/docs/derivatives/usds-margined-futures/trade/rest-api/New-Order)

## Known limits

- No actual TESTNET/LIVE API call, WebSocket session, or exchange order was performed in this build. Validation uses deterministic local fakes/mocks and SQLite.
- The adapter's per-signal quantity check assumes one DIVA-managed position record per exchange symbol/position side. Multiple independent DIVA signals scaling into the same symbol/side are not supported by this slice; aggregate-position management must be implemented before enabling that behavior. Quantity mismatch fails closed.
- The lifecycle decision engine and adapter are available as components, but an autonomous mark-price-driven manager loop that continuously evaluates every open position and dispatches every action is not yet integrated end-to-end.
- Explicit structural-invalidation exits, emergency flattening, partial-exit retry policy beyond confirmed terminal fills, operator dashboard/Telegram, watchdog/process locking, and Windows deployment validation remain future work.
- PAPER remains default. Do not enable LIVE based on this checkpoint.
