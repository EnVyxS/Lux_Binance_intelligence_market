# v0.41.0 — Multi-Pair Live Market Runtime

## Scope

This delivery adds the continuous read-only runtime supervisor that refreshes the Binance USDⓈ-M exchange universe and 24-hour ticker statistics, applies the existing AUTO/MANUAL selector, starts/stops isolated per-symbol workers, restarts failed feeds, and forwards validated `ScalpingMarketDataView` captures into the existing `SMCV2EvidencePipeline`.

## Runtime API

`divatrading.trading.MultiPairLiveMarketRuntime`

- `run(stop_event=None)` runs initial discovery followed by periodic universe refresh.
- `refresh_universe()` performs public ExchangeInfo + 24h ticker retrieval and reconciles symbol workers.
- `snapshot` exposes selected/rejected symbols and per-symbol worker status/capture counts.
- `stop()` cancels all workers cleanly.
- `feed_factory(symbol)` must return an async iterable of validated `ScalpingMarketDataView` captures. Feed construction is injected so the worker lifecycle can use the existing Kline, Mark Price, aggregate-trade, depth and recovery supervisors without duplicating their transport or sequencing logic.
- `on_evidence(snapshot)` receives `SMCV2EvidenceSnapshot` for downstream qualification/trade planning.

## Safety and limitations

- Read-only: this runtime has no execution service dependency and never sends private API orders.
- Symbol worker failures are isolated; one failed symbol does not reset another symbol's SMC state.
- Symbol count and capture queue/worker capacities are bounded for the 8 GB target.
- Feed adapters must emit only validated, chronological market-data views. This release does not synthesize missing candles or manufacture a READY state.
- The feed factory is an explicit integration seam. This release supplies the lifecycle supervisor and feed-to-SMC contract; deployment-specific construction of the full Kline/Mark Price/aggregate-trade/depth supervisor graph remains a subsequent integration task, not a claim of verified live WebSocket operation.
- No exchange network call was made during automated tests.

## Configuration example

```python
from decimal import Decimal
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.trading import MultiPairLiveMarketRuntime, LiveMarketRuntimeConfig, SymbolUniverseConfig

config = LiveMarketRuntimeConfig(
    universe=SymbolUniverseConfig(
        mode="AUTO",
        max_active_symbols=12,
        min_quote_volume_usdt=Decimal("20000000"),
        min_trade_count_24h=1500,
        exclude_symbols=("BTCUSDT",),
    ),
    universe_refresh_seconds=300,
    max_concurrent_workers=12,
)
# Supply a feed_factory that composes the project's Binance websocket and recovery services.
```
