> Latest code safety candidate: **v0.59.0rc4**. Read [RC4_ROADMAP_AND_ACCEPTANCE_ID.md](RC4_ROADMAP_AND_ACCEPTANCE_ID.md). LIVE autonomous trading remains disabled until external acceptance evidence is complete.

> Prior checkpoint: v0.59.0rc3, 2026-11-15. See RC4_ROADMAP_AND_ACCEPTANCE_ID.md for current checkpoint. Historical milestones below are not evidence of exchange qualification.

# DIVATrading Full Auto Trading Roadmap — Current Checkpoint

- Latest consolidated source candidate: **v0.59.0rc1 — Autonomous Execution & Risk Integration Candidate**.
- Integrated in source: account-specific leverage/fee/margin inputs through risk sizing and dispatcher; guarded symbol-setting read/verify; income-history and user-trade reconciliation; completed-lifecycle risk ledger; Jakarta daily PnL and transfer-neutral anchors; persistent Telegram Control Center refresh inside autonomous runtime.
- Source verification: **1,038 tests passed** on Linux / Python 3.13.5; exact release archive clean-extraction verification is recorded in `CLEAN_EXTRACTION_TEST_REPORT_v0.59.0rc1.md`.
- Not yet qualified: exact ZIP on Windows 10 / Python 3.12.9; real Binance account read-only preflight from user's PC; private stream and matching-engine order/protection lifecycle; LIVE execution authorization.
- LIVE autonomous order routing remains explicitly rejected by `auto-trade-runtime`. All exchange order/LIVE flags remain false by default. PAPER remains the safe default.

# DIVATrading — Full Auto Trading Build Roadmap

**Product target:** fully automated, multi-pair Binance USDⓈ-M Futures bot. The deliverable is the complete autonomous trade lifecycle, not a signal generator.

## Fixed architecture decisions

- AUTO universe discovery and MANUAL symbol selection across eligible USDT-margined perpetuals.
- Independent market-data and SMC state per symbol; M1/M5 setup contexts remain independent; M15 is advisory only.
- Existing SMC V2 Stages 1–5 semantics are preserved; legacy nested M5/M15 OB priority is not reintroduced.
- Delta/CVD, Depth/Order Book, Absorption, FVG and sweep are aligned evidence/confluence, optional by default rather than hidden OB invalidation gates.
- One global risk/portfolio coordinator governs all active symbols.
- Exact Decimal price/quantity math, current exchange filters, SQLite idempotency and exchange-truth reconciliation.
- PAPER is default. TESTNET/LIVE require explicit local opt-in. Secrets never enter source or release ZIPs.
- Bounded feed workers/caches/queues target Windows 10 / Python 3.12.9 / 8 GB RAM; v0.57.0C1 source passed user-PC Windows regression, while final D2 package qualification remains pending.

## Delivery map

| Release | Scope | Status |
|---|---|---|
| v0.40.0 | AUTO/MANUAL multi-pair universe, Decimal risk sizing, private REST foundation, SQLite execution ledger, PAPER execution service and coordinator | Built |
| v0.41.0 | Continuous multi-pair public market runtime and independent symbol workers | Built |
| v0.42.0 | Public feed graph: M1/M5/M15 Klines, Mark Price, Aggregate Trades, Depth, Delta/CVD, Absorption, recovery and SMC snapshots | Built; offline/mocked validation, no live orders |
| v0.43.0 | SMC V2 candidate qualification, independent M1/M5 setups, M15 advisory, optional confluence, entry models and dynamic risk-sized TradePlans | Built; planning only |
| v0.44.0 | Exchange account snapshot and portfolio exposure view | Built; sequential REST snapshot |
| v0.45.0 | Atomic global portfolio-risk reservation across concurrent symbol workers | Built; reservation layer |
| v0.46.0 | User Data Stream, durable account/order events, account reconciliation, protection verification and TESTNET/LIVE freshness gate | Built; no live/testnet network validation |
| v0.47.0 | Managed-position decision engine: partial TP plan, fill-gated breakeven and trailing proposals with durable state | Built; decision layer |
| v0.48.0 | Partial-close adapter, safe conditional Algo STOP replacement, REST fill confirmation, verified-flat release and reconnect recovery | Built; deterministic local tests |
| v0.49.0 | Continuous Mark Price managed-position supervisor, lifecycle dispatch, structural/emergency exits, multi-pair worker isolation and recovery gates | Built; local deterministic tests |
| v0.50.0 | Reconciliation discrepancy policy, process locking, watchdog primitive and read-only operator status CLI | Built; watchdog not wired to all workers |
| v0.51.0 | Aggregate same-symbol position-group accounting, immutable fill attribution, per-signal allocation plans and operator diagnostics | Built; same-side multi-signal execution still blocked |
| v0.52.0 | Quantity-scoped STOP/TP protection, verified replacement-before-cancel ordering and residual-quantity resize after partial TP/market exits | Built; local mocked tests, no TESTNET orders |
| v0.53.0 | Protective Algo partial-fill reconciliation by `actualOrderId`; transactional per-signal fill projections from User Data Stream with deduplication, enrichment and late ownership backfill | Built; local SQLite/mocked tests |
| v0.54.0 | REST `/fapi/v1/userTrades` historical backfill and stream-gap recovery merged by exchange trade ID | Built; mock/local validation, no Binance private API session |
| v0.55.0 | True per-lot multi-signal supervisor, quantity-scoped lifecycle actions, per-lot protection reconciliation and aggregate exchange-position invariants | Built; same-side TESTNET/LIVE scale-in still gated pending qualification |
| v0.56.0 | Autonomous SMC V2 qualification → fresh portfolio snapshot → durable dispatcher → global risk reservation → idempotent entry → protected position runtime | Built; PAPER deterministic simulator and TESTNET path wired, no real exchange qualification |
| v0.57.0A | Demo endpoint isolation and read-only preflight for USDⓈ-M Futures | Built; 927 source/clean-extraction tests, no actual account session |
| v0.57.0B | Signed LIMIT/MARKET `/fapi/v1/order/test`, exact filter validation, endpoint isolation and credential redaction | Built locally; 944 source tests / user-PC Demo request pending |
| v0.57.0C | Explicitly authorized controlled Demo entry and exchange fill confirmation | Next; actual `/fapi/v1/order` remains disabled until separate Stage C opt-in |
| v0.57.0D1 | Conditional Algo STOP/TP exchange integrity: exact query/POST verification and fail-closed mismatch handling | Built; mock/fixture qualification only |
| v0.57.0D2 | Position-aware recovery of terminal no-fill STOP/TP gaps, deterministic one-POST replacement and restart-safe reconciliation | Built; 972 source and 972 clean-extraction tests on Linux/Python 3.13.5; Windows package qualification pending |
| v0.57.0D3 | Triggered Algo fill / residual quantity lifecycle, cancel-race and REST trigger backfill | Built; 978 source/clean-extraction tests on Linux/Python 3.13.5 |
| v0.57.0D4 | Account-runtime reconnect force-backfill, delayed child-fill attribution, multi-lot lifecycle/accounting invariants | Built; 986 source tests and 129 focused D4 tests on Linux/Python 3.13.5; exact Windows archive qualification pending |
| v0.57.0E | Supervised single-pair Demo E2E, reconnect, REST backfill, restart, multi-lot and kill-switch acceptance | Planned; actual Stage C entry remains deferred by user; same-side scale-in stays blocked until exchange evidence |
| v0.59.0rc1 | Integrated account-specific fee/margin risk sizing, income/trade reconciliation, completed-trade loss ledger, and runtime Telegram controls | Candidate built; 1,038 source tests pass; Windows/account/exchange qualification pending; LIVE disabled |
| v0.59.0rc2 | Entry cancel/partial-fill race reconciliation, source audit | Candidate built; 1,046 source tests passed; Windows/account qualification pending; LIVE disabled |
| v0.59.0rc3 | TESTNET effective risk caps, account-task fail-stop, pre-send durable gate, Demo public/private feed isolation, Kline recovery initialization fix | Candidate built; offline test result in AUDIT_TEST_RESULT_RC3.txt; Windows/account qualification pending; LIVE disabled |
| v0.59.0rc4 | Post-fill actual risk audit/halt, price zero fail safe, executable quote/depth veto, atomic transient halt clearing, guarded resume and Windows diagnostics | Source candidate; local regression and new offline tests; Demo/Windows/OOS qualification still pending; LIVE disabled |
| v0.58.0 | Windows 10 / Python 3.12.9 / 8 GB deployment validation, install/startup/shutdown, backup and operator runbook | Planned |

## Build-complete boundary

The full bot is not complete until one integrated runtime can: discover symbols; operate synchronized feeds and recover gaps; run independent SMC state; qualify/rank signals; calculate entry/SL/TP; reconcile account/positions/open orders against Binance; allocate global portfolio risk; submit idempotent orders; protect actual fills; manage partial fills, exits, breakeven and trailing; release risk only after exchange-confirmed flat/terminal states; recover after disconnect/restart; and expose safe operator controls.

## Historical v0.53.0 boundary

The v0.53.0 lifecycle adapter now reconciles protective Algo partial execution using the Algo's `actualOrderId` to query its matching-engine order and `executedQty`. If an order remainder is still active, it is canceled and checked terminal; the exact expected residual must match the REST position before local lot state is changed. Both residual quantity-scoped protections are created and verified before the prior sibling is canceled. One-way and Hedge Mode parameter semantics are tested with mocked clients.

The fill ledger now builds deterministic per-signal projections in a SQLite transaction from `ORDER_TRADE_UPDATE` and `TRADE_LITE`, deduplicates by symbol/trade ID, enriches Trade Lite rows with detailed events, resolves late fill ownership via client ID or exchange order ID, and separates commission asset from USDT realized PnL. Startup rebuilds these projections. These projections are evidence/accounting views; they do not directly mutate exchange-truth managed position quantity.

Important at v0.53.0: REST historical `/fapi/v1/userTrades` backfill, true multi-lot supervision and autonomous SMC V2 TradePlan-to-entry dispatch were still outstanding. They have since been addressed in v0.54.0 and v0.55.0 as detailed below. No real Binance TESTNET/LIVE private API, WebSocket or order was exercised in those local releases, and Windows 10 / Python 3.12.9 target validation remains outstanding.

## Deferred research (not build blockers)

- Extended 25h+ replay and warm-up convergence.
- 12-month historical calibration and cross-symbol statistical robustness.
- Walk-forward/out-of-sample and profitability validation.

These are deferred strategy-validation activities, not represented as completed. Basic software integrity, chronological/no-lookahead behavior, exact exchange filters, idempotency, reconciliation and execution safety remain mandatory for build completion.


## Current v0.56.0 boundary

v0.56.0 completes the first autonomous SMC-to-entry integration. `auto-trade-runtime` uses the live selected AUTO/MANUAL universe to refresh exact coordinator `InstrumentSpec` filters; runs SMC V2 in qualification-only mode; durably claims qualified signal IDs before account I/O; validates signal/snapshot freshness and entry-halt state; obtains a fresh PAPER or Binance REST account snapshot; and delegates final sizing, atomic portfolio risk reservation and idempotent entry submission to `MultiPairExecutionCoordinator` / `ExecutionService`. The TESTNET branch starts account User Data Stream, REST trade backfill/reconciliation and existing Mark Price position supervision in the same process, and waits for account readiness before market dispatch.

PAPER mode can create deterministic full fills at the planned entry price plus virtual quantity-scoped STOP/TP orders and managed-position/reservation state. It does not model queue position, spread, latency, slippage or stochastic partial fills. The provider treats fully matched DIVA lots with active per-lot reservations as locally reserved risk to avoid double counting; unmatched exchange positions and external open orders are counted conservatively, and unpriced external orders fail closed.

Remaining: v0.57.0C–E must qualify the integrated path against Binance USDⓈ-M TESTNET, including controlled entry order lifecycle, partial fills, quantity-scoped conditional Algo protection, multi-lot same-side execution, User Data Stream disconnect/reconnect, REST backfill, process restart, residual reconciliation and kill switch. Same-side TESTNET/LIVE scale-in remains blocked until those tests pass. Autonomous LIVE routing is disabled in v0.56.0. No actual Binance TESTNET/LIVE private request or order was used for v0.56.0. Windows 10 / Python 3.12.9 / 8 GB target validation remains pending.


## Current v0.57.0B boundary

v0.57.0B adds a signed validation-only `POST /fapi/v1/order/test` path with a separate local opt-in, explicit CLI confirmation, a fresh read-only preflight before every request, Decimal LIMIT/MARKET parameter preparation, and HMAC/API error sanitization. It does not call the actual order or Algo placement endpoints. MARKET quantity filters are checked locally; Binance remains authoritative for MARKET notional filter evaluation. All v0.57.0B exchange tests use mocks and fixtures (944 tests pass); a real authenticated Demo call remains pending because the target PC was unavailable during the build. The next deliverable is v0.57.0C controlled Demo entry, not a LIVE rollout.
