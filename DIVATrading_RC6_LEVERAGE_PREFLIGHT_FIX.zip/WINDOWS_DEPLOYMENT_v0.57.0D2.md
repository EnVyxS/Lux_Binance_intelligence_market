# Windows Deployment Notes — v0.57.0D2

## Target and qualification boundary

- Target: Windows 10 x64, Python **3.12.9 x64** exactly.
- Storage: keep the release, `.venv`, `.diva_temp`, logs and local database on the data drive when the system drive is space-constrained.
- The user validated the v0.57.0C1 source on Windows 10 / Python 3.12.9 with 952 passing tests and validated Demo preflight plus signed `/fapi/v1/order/test` on C1. The exact D2 release has **not** yet been installed or fully regression-tested on Windows.
- D2 build and clean-extraction tests were run on Linux / Python 3.13.5. No real Demo order or Algo mutation was performed during D2 development.

## Install

1. Extract the ZIP to a stable path such as `B:\DIVATrading_v0570D2`.
2. Run `INSTALL_WINDOWS.bat`; the installer checks Python 3.12.9 x64 and creates `.venv`.
3. Temporary build files are directed to `.diva_temp` under the project folder. The test launcher also uses this project-local temporary area, avoiding an unnecessary dependency on free space in `C:\`.
4. Copy any required local `.env` settings manually from a trusted local source. Never place credentials in the ZIP, source, logs, transcript, screenshots or chat.
5. Run `TEST_WINDOWS.bat` and inspect the complete output. Do not enable execution flags just to run unit tests.

## D2 recovery behavior

`DIVA_ENABLE_PROTECTION_RECOVERY=false` is the default in both environment templates. The feature is TESTNET-only; PAPER and LIVE configurations reject it. Enabling D2 recovery does not itself authorize TESTNET order placement: the independent TESTNET actual-order and Stage C opt-ins remain prerequisites. LIVE remains disabled.

D2 is intentionally fail-closed. It only replaces a protection that is proven terminal with zero executed quantity, against a fresh sequential REST snapshot and connected User Data Stream. Triggered or partially filled Algo orders are deferred to the existing fill-reconciliation path. An ambiguous POST is never automatically repeated. D2 never clears the account entry halt.

Do not enable `DIVA_ENABLE_PROTECTION_RECOVERY=true` on a real account until the D2 Windows package has passed deployment qualification and a separate supervised TESTNET recovery qualification has been explicitly approved.

## Storage and reports

- Temporary build/test workspace: `.diva_temp` under the project folder.
- Pytest output is printed by `TEST_WINDOWS.bat`; it does not itself create a full report file unless redirected/transcribed by the operator.
- Never include `.env`, `.venv`, local databases, logs, backups or `.diva_temp` in a source snapshot or release archive.
