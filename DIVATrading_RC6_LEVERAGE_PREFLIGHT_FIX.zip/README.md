# DIVATrading — Autonomous Binance Futures Scalping 0.59.0rc6

**Profil gabungan** memakai `START_MERGED_TRIAL_WINDOWS.bat`. Profil baru memakai risiko FIXED `0.20 USDT` dan satu slot posisi termasuk entry pending. Lihat [panduan profil gabungan](docs/MERGED_TRIAL_ID.md) untuk strategi, pengaturan risiko, dan cakupan validasi.

**Status:** executable LIVE-capable release candidate with 1,107 passing offline tests. **NOT production-exchange-qualified**. No exchange orders, LIVE position mutations, or private Binance account reads were conducted during RC6 development.

**Current operating manual:** [RC6 LIVE guide](docs/RC6_LIVE_OPERATOR_GUIDE.md).

## Install and run

1. Install Python **3.12.9 x64** on Windows 10/11. Extract into a new directory and run `INSTALL_WINDOWS.bat`.
2. Installer copies `.env.example` to `.env` if absent. Fill `BINANCE_API_KEY` and `BINANCE_API_SECRET` for LIVE (never share `.env`). LIVE flags, quote guard, protection recovery, and daily/risk defaults are already prepared.
3. Run `TEST_WINDOWS.bat` and `RUN_RC6_DIAGNOSTICS_WINDOWS.bat`; both override local LIVE settings to run offline with dummy credentials.
4. Start `START_LIVE_WINDOWS.bat` **only when ready for real-money autonomous orders**. Explicit confirmation `START LIVE TRADING` is required each run. Installing or editing `.env` does not send orders.
5. To activate Telegram control and dispatch alerts, ALSO provide **separate** `TELEGRAM_BOT_TOKEN` and `TELEGRAM_OWNER_ID`, send `/start` to your bot in a private chat and run `CHECK_TELEGRAM_WINDOWS.bat`. Telegram is optional when these credentials are both empty. They cannot be derived from Binance keys.

## RC6 defaults

- Strategy: independent SMC scalping M1/M5, M15 soft context; order-flow/CVD/depth/absorption optional confluence.
- Universe: live AUTO scan across up to 8 active pairs; **max 2 managed open positions** shared portfolio risk.
- Per-trade sizing: **Peluru FIXED 0.20 USDT** by default, alternative **PERCENT** via operator control. No forced quantity increase to meet exchange minimum.
- Daily realized+floating risk gate: **1.00 USDT**, configurable; legacy 1% hard override disabled by default.
- Leverage: **AUTO up to pair-specific Binance notional leverage bracket**, selecting the lowest leverage satisfying margin and symbol allocation. `FIXED` control is available as an alternate ceiling.
- Safety envelope: fixed/percent risk up to 10% equity per trade and 20% total open-risk percent maximum (hard stop for new entries); actual default is far lower for adequately funded accounts. Runtime requires fresh account reconciliation, quote protection, conditional orders, and operator consent.
- Telegram: owner-only `/status`, `/risk`, `/maxloss`, `/leverage`, `/pause`, `/resume`, `/kill`, `/resetkill confirm`. Dispatch-state alerts are **not** confirmation of a position fill or exit.

**Critical:** ZIP/installer/tests never place live orders by themselves. The RC6 launcher *will* attempt to place real orders once explicitly activated and qualified signals pass all gates. Windows deployment and Binance LIVE fills/STOP/TP/recovery have not been validated. This software is not guaranteed profitable or safe from liquidation and loss beyond software risk budgets.

---

## Archived release notes (RC5 and earlier)

# DIVATrading — LIVE-first operator candidate v0.59.0rc5 (15 November 2026)

**STATUS: CODE COMPLETE AS AN OFFLINE-TESTED CANDIDATE; NOT EXCHANGE-QUALIFIED.**
No Binance order or account mutation has been executed during RC5 construction.
LIVE activation is possible only through deliberate operator opt-in. It remains
unvalidated on a production Binance account and the target Windows machine.

**Start here:** [RC5 operator manual](docs/RC5_LIVE_FIRST_OPERATOR_GUIDE.md).

- `INSTALL_WINDOWS.bat` — Python 3.12.9 x64 virtual environment and pinned deps
- `TEST_WINDOWS.bat` — full offline regression suite
- `RUN_RC5_DIAGNOSTICS_WINDOWS.bat` — offline read-only Windows checks
- `START_LIVE_READ_ONLY_WINDOWS.bat` — *optional*, authenticated production GET checks; never sends orders
- `START_LIVE_FIRST_WINDOWS.bat` — **real-money order process** after local config + typed activation; NOT run automatically
- `RUN_WINDOWS.bat` — historical/default PAPER utility; not the LIVE launcher

The LIVE-first launcher intentionally restricts the initial runtime to BTCUSDT,
one managed position, 0.10% per-trade risk, 0.25% global open-risk budget,
maximum 5x leverage, 1% daily realized+floating loss, and 2% peak-equity drawdown.
These are conservative *software* limits, not guarantees of realized maximum loss.
Minimum order size, fees, slippage, liquidation and exchange connectivity may
make a trade infeasible or cause losses above the configured percentage.
No key or `.env` file is included in release archives.

---

# DIVATrading — audit candidate 0.59.0rc4 (15 November 2026)

> Current candidate: v0.59.0rc4. Offline safety improvements only; autonomous LIVE remains disabled. See [RC4_ROADMAP_AND_ACCEPTANCE_ID.md](RC4_ROADMAP_AND_ACCEPTANCE_ID.md).

# DIVATrading — audit candidate 0.59.0rc3 (15 November 2026)

**STATUS: BELUM SIAP MENJALANKAN ORDER LIVE.** Jangan menghapus pengunci pada jalur LIVE. Untuk laporan status terverifikasi dan langkah menuju deployment, buka [AUDIT_RC3_STATUS_DAN_HANDOFF.md](AUDIT_RC3_STATUS_DAN_HANDOFF.md). Untuk rencana penuh, buka [ROADMAP_FULL_AUTO_TRADING.md](ROADMAP_FULL_AUTO_TRADING.md).

Perubahan 0.59.0rc3: (1) batas risiko commissioning TESTNET memeriksa konfigurasi efektif dan ekuitas aktual sebelum entry; (2) kegagalan supervisor akun memblokir entry dan menghentikan market runtime; (3) fail-close bila jeda sebelum POST entry mendeteksi halt permanen; (4) seluruh REST/WebSocket market-data di autonomous TESTNET diarahkan ke Binance Demo, bukan mainnet; (5) batas halaman recovery kline diselaraskan sehingga graph bisa diinisialisasi. Tes lokal tidak setara dengan validasi matching engine Binance.

Gunakan `INSTALL_WINDOWS.bat`, `TEST_WINDOWS.bat`, lalu `RUN_WINDOWS.bat` pada Windows 10 dengan Python **tepat** 3.12.9 64-bit. Default `.env` adalah PAPER dan seluruh izin order real nonaktif. Simpan API key/secret di `.env` lokal; jangan bagikan atau mengunggahnya.

---

# Audit update — 0.59.0rc2 (15 November 2026)

**NOT LIVE READY.** Perbaikan race partial-fill entry; peta implementasi dan pekerjaan tersisa ada di [AUDIT_PROYEK_ID.md](AUDIT_PROYEK_ID.md). Catatan versi sebelumnya di bawah bersifat historis.

# DIVATrading Binance Bot — Multi-Pair Auto-Trading

**Release:** 0.59.0rc1 — Autonomous Execution & Risk Integration Candidate (package prerelease `0.59.0rc1`)  
**Target runtime:** Python 3.12.9, 64-bit  
**Target OS:** Windows 10  
**Operational mode:** PAPER by default; TESTNET/LIVE require separate explicit opt-in

Unit 05E preserves Units 01–05D and starts the new SMC V2 scalping strategy. Unit 05D remains the immutable legacy Pine replay reference; it is not silently modified or treated as the V2 strategy specification. The legacy Unit 05D stages reproduce the old Pine source-context replay: per-timeframe warmup reset, custom ATR(200), parsed candle behavior, independent swing/internal pivots, BOS/CHoCH, OB/FVG lifecycle, built-in TA, candidate eligibility, trigger/sweep, scoring and Pine-local proxy geometry. That legacy replay is kept separate from the new V2 strategy and its former nested M5/M15 arbitration is not used as the V2 MTF design.



**Stage 6A implementation:** `docs/SMC_V2_DETERMINISTIC_REPLAY_STAGE6A.md` documents the manifest, native Kline readers, UTC close-time replay, Stage 1–5 evidence ledger, gap isolation and restart/checkpoint semantics. Stage 6A adds the replay harness only; it does not change the SMC V2 Stage 1–5 detection rules and does not add scoring, trade qualification, entry, fill or PnL simulation. `docs/SMC_V2_REPLAY_READINESS_STAGE6.md` retains the full Stage 6 design and calibration protocol.

The Pine baseline is deliberately separate from future DIVATrading Dynamic Entry, exchange SL/TP, real fills, Position Management and Binance execution. Stage 8's `entry_proxy` is not a Binance fill, and `consumeOBOnSignal` is not fill-based consumption. The legacy Unit 05D Stage 9 plan (including nested M5/M15 priority) is not part of SMC V2 and must not be resumed as its MTF design. TradingView CSV export is optional; Basic can be used for exact selected Data Window spot checks, but no real TradingView observations or full fixtures have been accepted. Therefore independent Pine runtime parity remains unmeasured. Original Pine SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`. Units 04F and 04G provide absorption evidence and unified market-data orchestration; CVD remains based on the earliest locally retained aggregate-trade baseline, not lifetime exchange history.

## Install on Windows 10

1. Extract the release folder to a stable local path.
2. Confirm Python 3.12.9 64-bit is available through the Python Launcher (`py`).
3. Run `INSTALL_WINDOWS.bat`.
4. Run `TEST_WINDOWS.bat` and confirm all tests pass.
5. Run `RUN_WINDOWS.bat` to validate runtime and initialize/migrate the local database.

The installer and `TEST_WINDOWS.bat` place temporary build/test files under `.diva_temp` on the project drive. This is intended for machines where the Windows system drive has limited free space. See [Windows deployment and storage guide](WINDOWS_DEPLOYMENT_v0.59.0rc1.md).
6. Optionally run `EXCHANGE_INFO_WINDOWS.bat` to refresh public contract metadata, or `KLINES_HISTORY_WINDOWS.bat` for a bounded public historical-candle smoke test.

The installer creates `.venv`, installs pinned runtime dependencies including `httpx==0.28.1`, `websockets==16.0`, `jsonschema==4.26.0`, `numpy==1.26.4`, and `matplotlib==3.9.3` (required for Telegram PNG charts), copies `.env.example` to `.env` if needed, and creates local `data` and `logs` folders. Do not share `.env`.


## v0.59.0rc1 — Autonomous Execution & Risk Integration Candidate

This consolidated candidate connects account-specific USDⓈ-M leverage brackets, commission rates and available margin to the risk-sizing/dispatcher path. Quantity is sized from the configured risk budget first; fee, slippage and funding reserves reduce the affordable quantity, and the bot never increases quantity to meet exchange minimum notional. Exchange margin/leverage settings are read before mutation, writes are allowed only when the symbol has no open position or standard/Algo orders, and the final exchange `symbolConfig` is read back and verified. The current estimator reports initial/maintenance margin estimates only; it does not predict a liquidation price or guarantee liquidation safety.

The autonomous account runtime now runs the owner-only Telegram Control Center in its own retrying thread. Persisted risk, max-loss, leverage, margin, pause and kill settings are re-read before each candidate. Telegram update offsets survive restarts; `/resetkill confirm` is required to clear the kill latch. Pause/kill closes new-entry routing only; existing positions continue through the account/lifecycle supervisor. Supported controls: `/status`, `/risk fixed <USDT>`, `/risk percent <PCT>`, `/maxloss daily <USDT>`, `/maxloss daily percent <PCT>`, `/maxloss streak <N>`, `/maxloss drawdown percent <PCT>`, `/leverage auto [MAX]`, `/margin isolated|crossed`, `/pause`, `/resume`, `/kill`, and `/resetkill confirm`.

Risk-limit accounting uses bounded USDⓈ-M income history plus REST `userTrades`/fill attribution. Daily realized PnL includes USDT `REALIZED_PNL`, `COMMISSION`, and `FUNDING_FEE`; transfers are removed from the flow-neutral equity series. On a mid-day first start, the day-start anchor is reconstructed from flow-neutral margin balance, realized PnL and current floating PnL. Unknown non-zero income types, unsupported non-USDT cashflows/fees, external or unattributed fills, incomplete closed-lot projections, and funding events that cannot be attributed keep the risk ledger unready and block new entries. Historical trade streak state is only as complete as the bounded bootstrap history and persisted local ledger; do not erase the local database between runs.

**Important operational boundary:** this remains a release candidate, not LIVE authorization. `auto-trade-runtime` explicitly rejects `ExecutionMode.LIVE`; `.env.example` keeps all order/LIVE opt-ins false. This environment did not authenticate to a real Binance account, submit any TESTNET/LIVE matching-engine order, or validate private WebSocket/order/protection behavior. Windows 10 / Python 3.12.9 qualification of this exact archive is still required. See `RELEASE_HANDOFF_v0.59.0rc1.md` and `WINDOWS_DEPLOYMENT_v0.59.0rc1.md`.

## v0.58.0rc2 — Telegram Signal Center + Kronos-mini shadow integration

This release adds outbound-only Telegram signal publication from the read-only `market-runtime`. SMC qualification remains the signal authority; execution sizing is deliberately bypassed in `SIGNAL_ONLY`, so the reference PAPER equity does not suppress structurally qualified signals. Signal deduplication, publication outcomes, Kronos forecasts, signal/forecast links, and forecast evaluations are stored in SQLite schema v6.

Run `RUN_SIGNAL_RUNTIME_WINDOWS.bat` to stream one manual BTCUSDT pair and publish SMC-qualified signals to the Telegram Owner ID. The runner enables `--kronos-shadow`; if Kronos has not yet been installed, signal charts are still published with an explicit `KRONOS_INSTALL_MANIFEST_MISSING`/unavailable label. Run `INSTALL_KRONOS_WINDOWS.bat` once to install the optional CPU-only Kronos-mini source, tokenizer, model and pinned dependencies. This downloads the model assets into the ignored local `.kronos\` folder; they are intentionally not included in the release ZIP. Use `RUN_SIGNAL_RUNTIME_NO_KRONOS_WINDOWS.bat` to publish charted SMC signals without model inference.

`kronos-forecast --symbol BTCUSDT` creates a one-off shadow forecast from closed, contiguous Binance USD-M M5 candles. `kronos-evaluate --forecast-id ID` compares a stored forecast with the exact future closed M5 path once the entire horizon exists in the local database. `signal-history --limit 50` lists durable Telegram signal delivery records. Forecast metrics are not trade PnL, fill quality, trade success probability, or proof of profitability. With `sample_count=1`, the chart shows one deterministic sampled/averaged path only—not a confidence interval. Net RRR is intentionally not reported until the operator configures an actual fee-tier and slippage profile; gross RRR is labelled as such.

The Telegram publisher only calls `sendPhoto`; it does not poll or consume operator commands. Run `telegram-control` separately for owner-authenticated command polling if desired. The signal runtime has no order client or order submission path. `auto-trade-runtime` remains subject to the separate execution safety gates; LIVE routing remains disabled.

## Binance Demo Futures qualification (Stage A — read-only)

The current USDⓈ-M Demo REST endpoint is pinned to `https://demo-fapi.binance.com`. Demo market data uses `wss://demo-fstream.binance.com/market`, while the private User Data Stream uses `wss://demo-fstream.binance.com/private/ws?listenKey=...&events=...`. LIVE endpoints remain separate. The private stream uses Binance's post-2026-04-23 URL format; legacy USDⓈ-M paths are not used.

For a local read-only account/contract preflight, prepare `.env` from `.env.testnet.example` and fill Demo Trading API credentials locally. Keep `DIVA_ENABLE_TESTNET_ORDERS=false`, `DIVA_LIVE_TRADING_ENABLED=false`, and withdrawals disabled in the exchange key permissions. Never send the API secret through chat or commit `.env`.

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-preflight --symbols BTCUSDT
# or double-click TESTNET_PREFLIGHT_WINDOWS.bat
```

This command performs public GET checks and signed account GET checks only. It does not create/close a listenKey, change account settings, place/cancel orders, or open a WebSocket. `READY_FOR_TEST_ORDER_VALIDATION` means the read-only account/contract preflight passed; it does not establish TRADE permission or prove stream/order behavior. Stage B is implemented in this release and separately validates Binance's `/fapi/v1/order/test` endpoint.

## Binance Demo Futures test-order validation (Stage B — validation only)

Stage B adds `testnet-order-test` for signed `POST /fapi/v1/order/test`. The endpoint validates the submitted request but does **not** submit it to the matching engine or create an order/position. Only LIMIT and MARKET are supported. The command reruns the read-only preflight before each request, validates exact current LIMIT/MARKET quantity filters and LIMIT price/notional filters, and checks One-way/Hedge position mode. For MARKET notional, the exchange response remains authoritative rather than using a local last-price approximation.

Set the separate local flag `DIVA_ENABLE_TESTNET_ORDER_TEST=true` in `.env`, keep `DIVA_ENABLE_TESTNET_ORDERS=false` and `DIVA_LIVE_TRADING_ENABLED=false`, then also pass `--confirm-test-order`. This opt-in can call only `/fapi/v1/order/test`; it does not enable actual order placement. Example:

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-order-test --symbol BTCUSDT --side BUY --order-type MARKET --quantity <quantity-aligned-to-current-market-lot-filter> --confirm-test-order
```

Never place API credentials in chat, command-line arguments, screenshots, logs, source, or ZIPs. Keep credentials in the local `.env` and withdrawals disabled. The command does not automatically retry signed POST requests and sanitizes transport/API diagnostics. See [v0.57.0B Test Order Validation](TEST_ORDER_VALIDATION_V057B.md) and [v0.57.0B release handoff](RELEASE_HANDOFF_v0.57.0B.md). The user has separately validated Demo account authentication and a signed `/fapi/v1/order/test` request on Windows with v0.57.0C1. Those are validation-only checks; they do not create an order or position. The build tests in this repository still use mocks/fixtures and do not execute exchange writes.


## Stage D2 — Position-aware protective recovery (opt-in, TESTNET only)

Stage D2 can recover one missing quantity-scoped STOP/TP leg for an already-open managed lot only when a fresh sequential REST reconciliation and connected User Data Stream prove the exact group position, local per-lot allocation and terminal no-fill source Algo. It queries the deterministic replacement ID before POST, persists the one-POST attempt before sending, and verifies the replacement by REST GET. It processes one gap per fresh reconciliation snapshot.

## Stage D3 — Triggered Algo fill and residual recovery

D3 treats the User Data Stream `ALGO_UPDATE` as a wake-up signal, not a fill authority. It re-queries the Algo and its matching-engine `actualOrderId`, validates the child MARKET order identity/quantity/side/positionSide/close semantics, cancels an active unfilled remainder, and then uses the final REST `executedQty` after cancellation. This handles fills that race the cancel request and ignores stale/out-of-order stream cumulative quantities. Partial fills reduce only the affected managed lot and replace both residual protections; full fills finalize only that lot after aggregate REST position and linked-order cleanup checks. A terminal zero-fill child is re-protected at the unchanged quantity only when `DIVA_ENABLE_PROTECTION_RECOVERY=true` is explicitly enabled for TESTNET; otherwise the action remains pending and entries stay halted. On each private-stream connection, a REST backfill scan queries each open lot's current STOP/TP IDs to detect triggers whose `ALGO_UPDATE` event was lost during a disconnect. The D3 protective-trigger recovery path does not clear the entry halt; D4's separate backfill retry may clear only its own transient failure halt after a clean account snapshot, never a manual/operator halt. D3 build verification: 978 automated tests pass on Linux/Python 3.13.5; no real Demo/LIVE order or Algo mutation was performed. The exact D3 release still needs Windows 10/Python 3.12.9 qualification. See [Stage D3 technical specification](docs/TRIGGERED_ALGO_FILL_RESIDUAL_STAGE_D3.md), [D2 specification](docs/PROTECTIVE_ORDER_RECOVERY_STAGE_D2.md), and [D3 release handoff](RELEASE_HANDOFF_v0.57.0D3.md).

Set `DIVA_ENABLE_PROTECTION_RECOVERY=true` only as a separate, deliberate TESTNET authorization after the exact release is qualified. The default is `false`; PAPER and LIVE reject this feature. TESTNET's actual-order and Stage C flags remain separate prerequisites. Ambiguous child-order cancellation stays pending and is reconciled by deterministic `actualOrderId`; no new child order is blindly POSTed. A flat position is handled only by the existing verified flat-position finalizer.

## Stage D4 — Account-runtime stream-gap and multi-lot recovery

D4 forces REST `/fapi/v1/userTrades` recovery after every newly connected private User Data Stream, independently of the periodic backfill timer. The request remains pending until all tracked symbols backfill successfully. A failed backfill keeps entries halted; only the exact transient failure halt owned by the reconciler can clear after a successful retry and a clean sequential account snapshot. Existing manual/operator halts are never cleared by this path. For triggered protective Algo orders, D4 durably links the REST-verified child `actualOrderId` to its signal lot and STOP/TP role before cancellation/fill reduction, so delayed `ORDER_TRADE_UPDATE` or REST userTrades fills can be attributed by exchange order ID even when the generated client ID is not the original DIVA Algo ID. Previously external/unattributed fills are re-attributed and the per-lot projection rebuilt. The integrated mock scenario covers two same-side lots, partial trigger fill, REST backfill, fees/PnL, restart duplicate replay and exchange-flat finalization. D4 regression: **986 passed** on Linux/Python 3.13.5; focused stream-gap/backfill/accounting/lifecycle tests: **129 passed**. No real Binance Demo/LIVE request/order/cancel/Algo mutation was executed. Exact D4 Windows 10/Python 3.12.9 qualification remains pending. See [D4 technical specification](docs/ACCOUNT_RUNTIME_STREAM_GAP_STAGE_D4.md), [D4 release handoff](RELEASE_HANDOFF_v0.57.0D4.md) and [full auto-trading roadmap](ROADMAP_FULL_AUTO_TRADING.md).

## Manual commands

Run from the project folder:

```powershell
.\.venv\Scripts\python.exe -m divatrading check
.\.venv\Scripts\python.exe -m divatrading init-db
.\.venv\Scripts\python.exe -m divatrading status
.\.venv\Scripts\python.exe -m divatrading exchange-info
.\.venv\Scripts\python.exe -m divatrading instruments --limit 50
.\.venv\Scripts\python.exe -m divatrading instruments --symbol BTCUSDT
.\.venv\Scripts\python.exe -m divatrading klines-history --symbol BTCUSDT --interval 1m --start-time-ms 1760000000000 --end-time-ms 1760003600000
.\.venv\Scripts\python.exe -m divatrading validate-pine-fixture --fixture .\capture\reference_fixture.v2.json --source-dir .\capture
.\.venv\Scripts\python.exe -m pytest -q
# PAPER autonomous SMC-to-entry runtime (default; no private API credentials required)
\.venv\Scripts\python.exe -m divatrading auto-trade-runtime --mode AUTO --max-symbols 8
```

The current CLI includes diagnostics, historical utilities, AUTO/MANUAL universe selection, `market-runtime` for read-only multi-pair public feeds, `account-runtime` for explicitly enabled private account events/reconciliation/position supervision, and `auto-trade-runtime` for the integrated SMC V2 → durable dispatch → fresh account snapshot → global risk → idempotent entry → protective-order path. PAPER is the default and uses a deterministic full-fill-at-plan-price simulation when `DIVA_PAPER_SIMULATE_FILLS=true` (the default for the CLI environment); this is not an exchange fill/slippage model. The Stage B validation command requires `DIVA_ENABLE_TESTNET_ORDER_TEST=true` plus `--confirm-test-order` while keeping actual order placement disabled. Actual TESTNET trading runtime requires `DIVA_ENABLE_TESTNET_ORDERS=true`, local API credentials, User Data Stream and REST reconciliation readiness; this remains a distinct later authorization. Autonomous LIVE routing is explicitly disabled in v0.56.0. v0.40–v0.43 established multi-pair signal planning and SMC V2 TradePlans; v0.44–v0.46 added account snapshots, atomic portfolio reservations, User Data Stream ingestion, exchange reconciliation and readiness gates. v0.47–v0.49 added managed-position lifecycle and continuous Mark Price supervision. v0.50–v0.54 added runtime reliability, aggregate accounting, quantity-scoped protection, protective-trigger reconciliation, fill projections and REST trade backfill. v0.55 adds per-lot lifecycle and group action serialization. v0.56 wires qualified SMC signals into the global coordinator and durable automatic entry dispatcher; same-side TESTNET/LIVE scale-in remains gated pending exchange qualification. v0.57A/B now provide Demo preflight and signed validation-only test orders; v0.57C/E remain the actual controlled entry, protection and end-to-end qualification milestones; D1–D4 strengthen the offline protective-order and recovery path. Windows 10 / Python 3.12.9 full regression was validated by the user on the v0.57.0C1 source (952 passed); the exact D4 archive still requires its own Windows deployment qualification. User Demo preflight and `/fapi/v1/order/test` were validated on C1, but no actual Stage C entry/fill/protection cycle has been confirmed. D4 build tests use local SQLite and mocked providers/clients; no actual Binance TESTNET/LIVE private write, Algo mutation, or order was performed. Read [v0.56.0 release handoff](RELEASE_HANDOFF_v0.56.0.md), [v0.56.0 autonomous dispatcher design](AUTO_ENTRY_DISPATCHER_V056.md), [v0.55.0 release handoff](RELEASE_HANDOFF_v0.55.0.md), [v0.55.0 multi-lot supervisor design](MULTI_LOT_POSITION_SUPERVISOR_V055.md), [v0.54.0 release handoff](RELEASE_HANDOFF_v0.54.0.md), [v0.54.0 REST trade-backfill design](REST_TRADE_BACKFILL_V054.md), and [the full auto-trading roadmap](ROADMAP_FULL_AUTO_TRADING.md).


## Unit 05E — Historical Replay CLI (Stage 6A)

The replay CLI consumes a validated local dataset manifest and writes an evidence-only JSONL ledger. Every included timeframe must align to and fully cover the manifest start/end; internal gaps are permitted and emitted, while leading/trailing partial coverage is rejected. First validate the source files and metadata:

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-validate --manifest .\data\BTCUSDT\manifest.json --root .\data\BTCUSDT
.\.venv\Scripts\python.exe -m divatrading replay-run --manifest .\data\BTCUSDT\manifest.json --root .\data\BTCUSDT --ledger .\logs\BTCUSDT.jsonl --checkpoint .\logs\BTCUSDT.checkpoint.json
```

Resume with the same manifest, dataset root, ledger, checkpoint, software and configuration by adding `--resume`. Current-only tick-size metadata is diagnostic-only and requires the explicit `--allow-current-metadata` flag. See `docs/SMC_V2_DETERMINISTIC_REPLAY_STAGE6A.md` for manifest creation, metadata limits and output semantics. No live orders or fill/PnL simulation are performed.

## Unit 05E — Binance REST Historical Data Intake (Stage 6C.1, v0.36.0)

Stage 6C.1 adds `binance-rest-kline-intake` for public Binance USDⓈ-M `/fapi/v1/klines` acquisition. Each JSON response body is retained byte-for-byte in a page file with exact request parameters, response headers and SHA-256 in `pages.jsonl`. A derived native 12-column CSV is streamed for the existing replay-quality and replay pipeline. The capture records leading/internal/trailing missing intervals but never repairs, interpolates, sorts, deduplicates, rounds or synthesizes candles. Request windows are half-open, aligned to the selected interval, and may include only fully closed candles. Pagination is capped and rate-spaced; incomplete captures are retained as `.partial.csv` with explicit partial status.

Example (provide UTC Unix millisecond boundaries aligned to 1m; the end boundary is exclusive):

```powershell
.\.venv\Scripts\python.exe -m divatrading binance-rest-kline-intake `
  --symbol BTCUSDT --interval 1m `
  --start-open-time-ms <START_UTC_MS> `
  --end-open-time-ms-exclusive <END_UTC_MS_EXCLUSIVE> `
  --dataset-root .\data\BTCUSDT --capture-id btcusdt-m1-smoke
```

The capture layout is `raw/rest_klines/<symbol>/<interval>/<capture-id>/pages/*.json` plus `pages.jsonl` and `capture.provenance.json`; the derived CSV is under `derived/rest_klines/`. A complete API pagination status does **not** mean the dataset is gap-free; run `replay-quality` and the strict Stage 6B workflow before replay. No manifest is generated automatically.

`binance-current-metadata --symbol BTCUSDT --output-dir .\data\BTCUSDT\metadata\current` stores raw current `/fapi/v1/exchangeInfo`, a symbol snapshot and provenance. This snapshot is always `CURRENT_SNAPSHOT_ONLY`; its tick size is not evidence of the tick size effective in prior months and cannot pass strict historical calibration. No historical effective filter timeline is inferred. See [Stage 6C.1 intake protocol](docs/SMC_V2_HISTORICAL_DATA_INTAKE_STAGE6C1.md).

**Licensing boundary:** Binance Public Data Vision Terms (v1.0, 26 August 2026) restrict datasets to non-commercial use and exclude live proprietary trading execution and commercial trading-bot integration without separate written licensing. The Vision archive downloader is therefore not included in this release. The REST collector uses the documented public market-data endpoint and does not imply permission for third-party commercial services, resale or managing other people's funds; review the current Binance terms for the account/jurisdiction. The collector is read-only and has no private API or order placement.

Stage 6C.1 tests use mocked REST responses and synthetic Klines only. No real Binance data was downloaded in the build environment, no 30-day smoke or historical metadata audit was performed, and no strategy calibration/performance conclusion is claimed.

## Unit 05E — Replay Quality, Warm-up Convergence, Evidence Analytics & Integrated Workflow (Stage 6B, v0.35.0)

Stage 6B.1 now implements a read-only raw-source Kline quality auditor in `divatrading.replay.quality`. Run it **before strict manifest construction** to expose duplicate/revision defects that Stage 6A correctly rejects. The scanner streams native Binance 12-column CSV/TXT or ZIP-with-one-CSV sources, uses a temporary SQLite timestamp index, and never sorts, deduplicates, repairs, rounds, interpolates or modifies source files. It reports expected/observed bars, exact coverage, leading/trailing/internal gaps, identical duplicates, conflicting revisions, non-monotonic rows, cross-file overlap, malformed/timestamp/OHLC defects, exact Decimal `PRICE_FILTER.tickSize` violations, source hashes and metadata caveats. Issue samples and gap-cluster samples are bounded; aggregate counts remain complete.

Raw-source example (the metadata file uses the same object as the `metadata` section of a Stage 6A manifest):

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-quality --root .\data\BTCUSDT `
  --symbol BTCUSDT --start-open-time-ms 1760000000000 --end-open-time-ms 1760086400000 `
  --source 1m=BTCUSDT-1m.csv --source 5m=BTCUSDT-5m.csv `
  --metadata .\data\BTCUSDT\metadata.json --metadata-evidence-ref archive:exchange-info-2026-01 `
  --report .\data\BTCUSDT\quality-report.json
```

Add `--source-sha256 RELATIVE_PATH=SHA256` and `--source-row-count RELATIVE_PATH=COUNT` to compare independently retained expected hashes/counts. Manifest verification mode is `replay-quality --manifest .\data\BTCUSDT\manifest.json --root .\data\BTCUSDT --report .\data\BTCUSDT\quality-report.json`. CLI exit code is 0 for PASS/WARN, 9 for a generated quality FAIL report, and 2 for an invalid request/runtime error. An internal gap is WARN and remains explicit; leading/trailing coverage defects, duplicate/revision/order defects, malformed rows, hash mismatch, timestamp/OHLC defects and tick-grid violations are FAIL. Current metadata is diagnostic-only. A caller-provided evidence reference is retained but not independently authenticated by the bot.

Five Draft 2020-12 schemas are available for dataset quality, warm-up convergence and evidence analytics. Stage 6B.2 provides `replay-analyze`: strict immutable JSONL validation, chronological half-open 60/20/20 labels aligned to the LCM of active intervals, closed-bar denominators from `updated_intervals`, Stage 2–5 evidence metrics, unique OB/FVG split-end snapshots, Decimal nearest-rank distributions and administrative right-censoring. Stage 6B.3 now provides `replay-convergence` to compare 2–10 distinct pre-roll histories over one identical evaluation window, requiring identical code/config/metadata and native Kline content. It reports per-timeframe fingerprints, gap/readiness confounders and pairwise Stage 2–5 evidence divergences. Relative positional `*_index` fields are excluded from equality while raw payloads remain inspectable; no automatic convergence threshold is applied. Both tools validate immutable inputs and use a temporary SQLite spool. Stage 6B.4 adds `replay-workflow`, which runs quality audit → strict manifest/source eligibility → Stage 6A replay (including a one-capture checkpoint/resume recovery probe) → Stage 6B.2 analytics → Stage 6B.3 convergence in one deterministic run. The final report binds per-trial dataset, metadata, source, replay, config, code, ledger and report hashes and confirms that manifests and raw sources did not change. Internal gaps are reported but WARN datasets are not strict-eligible in the integrated workflow. Workflow plan/report Draft 2020-12 schemas are under `docs/schemas/`; see [Stage 6B.4 integrated workflow](docs/SMC_V2_REPLAY_WORKFLOW_STAGE6B4.md). Example: `replay-workflow --plan .\data\BTCUSDT\workflow-plan.json --report .\reports\BTCUSDT-stage6b-workflow.json`. Stage 6B.4 validation uses synthetic test fixtures only; no real Binance dataset replay, empirical convergence, calibration, scoring, qualification, entry, fills, PnL or profitability inference is established.


## Unit 05E — SMC V2 Scalping Data Contract (Stage 1)

The V2 adapter is separate from the legacy `StrategyMarketDataAdapter` and preserves its public behavior. `InstrumentSpec` is built from the exact Binance `SymbolInfo`; `PRICE_FILTER.tickSize` is authoritative and `pricePrecision` is never used as a substitute. `ScalpingMarketDataAdapter.build_view()` returns an immutable view with independent M1 and M5 setup-source readiness, optional M15 context, optional Mark Price/Delta-CVD/Depth/Absorption components, and separate entry-quote readiness. A valid M5 source can remain available when M1 is missing; an independent M1 source can remain available when M5 is missing. Optional confluence data does not veto structural scan readiness. Off-grid Kline and best bid/ask values are reported; the adapter never silently rounds them.

The optional `AggregateTradeEventFanout` can be attached to `UnifiedMarketDataOrchestrator`. The orchestrator remains the only consumer of the source feed queue. Fan-out uses bounded, symbol-filterable subscriber queues and fails closed if any matching queue is full. Consumers must continuously drain their queue and call `task_done()`. See [docs/SCALPING_MARKET_DATA_CONTRACT_STAGE1.md](docs/SCALPING_MARKET_DATA_CONTRACT_STAGE1.md), [docs/SMC_V2_SCALPING_SPEC_v0.1.md](docs/SMC_V2_SCALPING_SPEC_v0.1.md), and [docs/BINANCE_MARKET_DATA_V2_AUDIT_v0.1.md](docs/BINANCE_MARKET_DATA_V2_AUDIT_v0.1.md).

```python
from divatrading.strategy import ScalpingMarketDataAdapter

# `symbol_info` is the exact parsed Binance SymbolInfo for BTCUSDT.
# `series` contains validated KlineSeriesInput items for M1 and M5; M15 is optional.
view = ScalpingMarketDataAdapter().build_view(
    symbol="BTCUSDT", now_ms=now_ms, symbol_info=symbol_info,
    kline_series=series, mark_price=mark_price,
    mark_price_connected=mark_price_connected,
    readiness=market_data_readiness, order_book_metrics=depth_metrics,
)
if view.readiness.m5_setup_ready:
    # The M5 data source is healthy enough for the later structure engine.
    # This does not itself mean an OB or trade setup exists.
    pass
```

Stage 1 validates the Binance inputs; Stage 2 calculates only confirmed pivots, BOS/CHoCH and protected structure landmarks. It does not create OBs or trade signals.



## Unit 05E — SMC V2 Market Structure Engine (Stage 2)

`ScalpingMarketStructureEngine` consumes only validated, closed Klines from `ScalpingMarketDataView`. It maintains independent state for each symbol/timeframe: M1 and M5 are independent structure sources, while M15 is optional advisory context and cannot suppress them.

```python
from divatrading.strategy import (
    ScalpingMarketDataAdapter,
    ScalpingMarketStructureConfig,
    ScalpingMarketStructureEngine,
)

# Build `view` with ScalpingMarketDataAdapter from exact Binance SymbolInfo
# and validated, contiguous closed KlineSeriesInput objects.
structure = ScalpingMarketStructureEngine(
    config=ScalpingMarketStructureConfig()
).process(view)

m1 = structure.timeframe("1m")
m5 = structure.timeframe("5m")
if m1 and m1.ready:
    for event in m1.events:
        print(event.event_type, event.direction_name, event.broken_level)
trace_jsonl = structure.to_jsonl()
```

Stage 2 uses configurable symmetric swing/internal pivot windows. A pivot is known only after the right-side confirmation candles close; BOS/CHoCH requires a strict candle-close cross through an already confirmed pivot. Wick-only penetration is not a structure break. Provisional defaults are swing 3/3 and internal 1/1, with per-timeframe overrides; these are not replay-calibrated. See [docs/SMC_V2_MARKET_STRUCTURE_STAGE2.md](docs/SMC_V2_MARKET_STRUCTURE_STAGE2.md) for exact semantics, reset/continuity rules and exclusions.

Stage 2 does not yet implement displacement qualification, OB formation/lifecycle, FVG, sweep, setup ranking, Entry/SL/TP, risk or execution. Next is Unit 05E Stage 3 — Displacement Qualification & OB Formation.

## Unit 05D — Pine SMC source-context replay (stages 1–8)

The first slice is a deterministic source-context replay. It requires one complete contiguous loaded-history prefix per timeframe; it calculates the Pine reset index independently for that timeframe. It converts the existing `Kline` Decimal values to binary64 only at the Pine calculation boundary.

```python
from divatrading.market_data.klines import Kline
from divatrading.strategy import PineSmcStructureConfig, PineSmcStructureEngine

# `candles` is a chronological, contiguous tuple of closed Binance USD-M Kline objects.
engine = PineSmcStructureEngine(
    PineSmcStructureConfig(
        symbol="BTCUSDT", timeframe="1m", warmup_bars=1500,
        swing_len=50, internal_len=5,
    )
)
replay = engine.replay(candles)
trace_jsonl = replay.to_jsonl()
```

Create separate engines and pass each timeframe's own full loaded prefix for M1, M5 and M15. `confluence_filter` corresponds to Pine `confluenceFilter` (default `false`). Each trace row includes independent `swing_trend` and `internal_trend` state plus a nested `structure_events` record with BOS/CHoCH flags and event-extreme metadata. The trace is an implementation diagnostic, not a full strategy signal output or proof of TradingView parity. Current implementation scope and exclusions are documented in `docs/PINE_SMC_STRUCTURE_STAGE1.md`, `docs/PINE_SMC_STRUCTURE_STAGE2.md`, `docs/PINE_SMC_STRUCTURE_STAGE3.md`, `docs/PINE_SMC_BUILTIN_TA_STAGE4.md`, and `docs/PINE_SMC_STRUCTURE_STAGE5.md`.

## Unit 05D — Pine SMC structure, OB lifecycle, built-in TA, eligibility and signal levels (stages 1–8)

```python
from divatrading.strategy import PineSmcStructureConfig, PineSmcStructureEngine

engine = PineSmcStructureEngine(
    PineSmcStructureConfig(
        symbol="BTCUSDT",
        timeframe="1m",
        warmup_bars=1500,
        swing_len=50,
        internal_len=5,
        confluence_filter=False,
        fvg_min_atr=0.10,
        mitigate_close=False,
    )
)
replay = engine.replay(candles)  # contiguous Binance USD-M Kline sequence
for bar in replay.trace:
    active_obs = bar.active_order_blocks
    created_this_bar = bar.ob_lifecycle.created
    mitigated_this_bar = bar.ob_lifecycle.mitigated
    eligible_obs = bar.ob_eligibility.eligible_candidates
```

Use separate engines and full loaded-history prefixes for M1/M5/M15. The immutable active-OB tuple is ordered oldest to newest; lifecycle `mitigated` is recorded newest to oldest to reflect reverse-index removal. The `bar.indicators` record now exposes ATR(14), RSI(14), SMA(volume,20), +DI, -DI, ADX and volatility-regime data calculated from the full loaded prefix. Stages 5–8 add ordered candidate eligibility, rejection/structure triggers and sweep, OB scoring/ideal bands, then Pine-local entry/SL/TP proxy geometry. Inspect `bar.trigger_sweep`, `bar.ob_scoring`, and `bar.level_evaluation`; an accepted `bar.level_evaluation.signal` is still unshifted and uses source-bar close as an indicator proxy, not an exchange fill. Geometry fails closed if exact `tick_size` or ATR(14) is unavailable. `consumeOBOnSignal` is a Pine signal-use proxy, not fill consumption. Stage 9 will add the one-source-bar confirmed-output shift and MTF arbitration. See [docs/PINE_SMC_STRUCTURE_STAGE3.md](docs/PINE_SMC_STRUCTURE_STAGE3.md), [docs/PINE_SMC_BUILTIN_TA_STAGE4.md](docs/PINE_SMC_BUILTIN_TA_STAGE4.md), [docs/PINE_SMC_STRUCTURE_STAGE5.md](docs/PINE_SMC_STRUCTURE_STAGE5.md), [docs/PINE_SMC_STRUCTURE_STAGE6.md](docs/PINE_SMC_STRUCTURE_STAGE6.md), [docs/PINE_SMC_STRUCTURE_STAGE7.md](docs/PINE_SMC_STRUCTURE_STAGE7.md), and [docs/PINE_SMC_STRUCTURE_STAGE8.md](docs/PINE_SMC_STRUCTURE_STAGE8.md).

## WebSocket Kline feed contract

The feed uses the USDⓈ-M Market stream endpoint `wss://fstream.binance.com/market/stream` and sends a `SUBSCRIBE` request containing only configured exact symbols and intervals.

- Supported Kline intervals: `1m`, `5m`, `15m`.
- Default stream cap: 48; hard maximum: 128.
- Default event queue: 2,048; hard maximum: 8,192. Queue overflow raises `FeedQueueFullError` instead of silently dropping updates.
- WebSocket library frame buffer: 16; maximum incoming message: 64 KiB.
- `MarketKlineEvent.status` is `FORMING` when Binance `k.x` is `false` and `CLOSED` when it is `true`.
- Reconnect attempts use bounded exponential backoff and resubscribe to the same configured streams. `feed.is_connected` and `feed.stats.connection_count` expose connection state and successful connection count.
- The caller must drain `feed.events` continuously.

## Kline storage contract

- `Database.initialize()` applies forward-only migrations through schema v5.
- `market_klines` has composite primary key `(exchange, symbol, interval, open_time_ms)`.
- `KlineRepository.upsert_many()` atomically inserts or updates validated `Kline` objects. Repeated identities do not create duplicate rows.
- OHLCV and taker-volume fields are persisted as text decimal values and loaded as `Decimal`.
- `read()` returns bounded ascending ranges; `read_tail()` returns the latest bounded rows in ascending order; `earliest_open_time_ms()` returns the oldest stored open time for one stream.
- Read operations are bounded to at most 5,000 rows. Existence checks are bounded to at most 5,000 timestamps.

## Unit 03D — REST gap recovery

`KlineRecoveryService` orchestrates the existing WebSocket feed, Historical REST service and SQLite repository. It provides the following contract:

1. Register each exact `(symbol, interval)` stream. If no candle exists locally, provide an explicit interval-aligned `bootstrap_start_open_time_ms`; the service will not guess how much history to download.
2. Call `observe_websocket_feed(feed)` from the market-data supervisor. It reads `feed.is_connected` and `feed.stats.connection_count`, so a fast internal reconnect can invalidate readiness even if a polling loop did not observe a disconnected state.
3. After connection or reconnect, supply the latest *confirmed closed* open-time for every required stream to `recover_registered_streams()` or call `recover_stream()` individually.
4. REST backfill uses the existing bounded pagination and request pacing. Each pass is capped by the smaller of `page_limit × max_pages_per_recovery` and `audit_window_candles - 1`, retaining an audit anchor for the next pass.
5. Every recovered candle is checked as closed (`close_time_ms < now_ms`) before it is persisted. Missing REST intervals are reported and are never fabricated.
6. `ingest_websocket_event()` ignores FORMING updates. For a CLOSED event, it reconciles all earlier candles first; if recovery is incomplete, it raises `RecoveryIncompleteError` and does not persist the newer event.
7. Global `is_ready` becomes true only when the feed is connected and every registered stream has reached `HEALTHY`. Disconnects reset stream health and require recovery again.

Health states are `DISCONNECTED`, `RECOVERING`, `DEGRADED`, and `HEALTHY`. A REST error, missing interval, unclosed candle or exhausted recovery budget leaves the stream degraded. A later recovery pass resumes from the remaining local gap; UPSERT keeps repeated recovery idempotent.

Example service setup:

```python
from pathlib import Path
from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.market_data.history import HistoricalKlineService
from divatrading.market_data.recovery import KlineRecoveryService
from divatrading.market_data.storage import KlineRepository
from divatrading.market_data.websocket import BinanceKlineWebSocketFeed

# Build dependencies once and reuse their HTTP client for bounded REST calls.
database = Database(Path("data/divatrading.db"))
database.initialize()
repository = KlineRepository(database)
rest_client = BinanceUsdMFuturesRestClient()
history = HistoricalKlineService(rest_client)
recovery = KlineRecoveryService(history, repository)

feed = BinanceKlineWebSocketFeed(symbols=["BTCUSDT"], intervals=["1m", "5m"])
recovery.register_stream(symbol="BTCUSDT", interval="1m", bootstrap_start_open_time_ms=1760000100000)
recovery.register_stream(symbol="BTCUSDT", interval="5m", bootstrap_start_open_time_ms=1760000100000)

# In the market-data supervisor, call observe_websocket_feed(feed).
# Once connected, calculate the latest CLOSED candle open time per stream from
# a trusted clock/server-time source, then run recovery_registered_streams(...).
# Drain feed.get_event() continuously and pass CLOSED events to
# recovery.ingest_websocket_event(event). Keep is_ready as a hard strategy gate.
```

Recovery methods are synchronous because the underlying REST and SQLite layers are synchronous. A future async supervisor should run all recovery calls on one serialized worker/executor; do not run concurrent recovery calls for the same `(symbol, interval)` stream. Keep the WebSocket receive loop draining its bounded queue while recovery is running.

`now_ms` is injectable for deterministic tests. In operation, its system clock must be synchronized; an inaccurate local clock can incorrectly classify the newest candle as still open or already closed.


## Unit 04A — Aggregate Trade feed (preserved)

`BinanceAggregateTradeWebSocketFeed` provides real-time `<symbol>@aggTrade` events for exact configured USDⓈ-M contract symbols. It connects to the routed market WebSocket endpoint `wss://fstream.binance.com/market/ws` and sends a `SUBSCRIBE` request containing only those stream names.

- Default selected-symbol cap: 16; configurable hard maximum: 48. Start with only the instruments currently being analyzed.
- Event queue defaults to 8,192 records with a hard maximum of 32,768. The caller must drain the queue continuously; queue overflow raises `AggregateTradeQueueFullError` instead of silently discarding data.
- WebSocket library frame buffer: 16; incoming message limit: 64 KiB.
- Price and base quantity are stored as `Decimal`; timestamps and IDs are integer milliseconds/IDs.
- `buyer_is_maker=true` maps to SELL aggressor and negative signed quantity; `false` maps to BUY aggressor and positive signed quantity. Quote quantity is derived as exact Decimal price × base quantity.
- Aggregate trade IDs are tracked per symbol across reconnects. Duplicate/out-of-order IDs are skipped; forward ID gaps are retained on the next event as `missed_aggregate_trades_before` and counted in feed stats.
- Both event time and trade time are checked for stale/future skew. Keep the Windows system clock synchronized.
- Reconnect uses bounded exponential backoff and resubscribes to the same exact symbol list. Graceful shutdown uses an asyncio stop event.
- Binance `aggTrade` is an aggregated stream, not an unaggregated record of every individual match. No Delta/CVD windows, REST gap recovery, SQLite trade persistence, depth, absorption, SMC, Telegram, dashboard or order execution is included in this checkpoint.

Example:

```python
import asyncio
from divatrading.market_data.aggregate_trades import BinanceAggregateTradeWebSocketFeed

async def main():
    feed = BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"])
    stop = asyncio.Event()
    runner = asyncio.create_task(feed.run(stop))
    try:
        while True:
            event = await feed.get_event()
            # m=true: buyer is maker, seller is the taker/aggressor.
            # m=false: buyer is the taker/aggressor.
            print(event.symbol, event.aggressor_side, event.price, event.quantity,
                  event.signed_quantity, event.aggregate_trade_id)
            if event.missed_aggregate_trades_before:
                # Do not treat downstream cumulative flow as gap-free until reconciled.
                print("AGG TRADE ID GAP:", event.missed_aggregate_trades_before)
    finally:
        stop.set()
        await runner

asyncio.run(main())
```

## Safety boundary and current auto-trading status (v0.40.0)

- The foundation profile `DIVA_TRADING_MODE` remains `PAPER`; the new execution layer is independently controlled by `DIVA_EXECUTION_MODE`.
- `DIVA_EXECUTION_MODE` defaults to `PAPER`. The `ExecutionService` will not load a private Binance client in PAPER mode.
- TESTNET orders require `DIVA_EXECUTION_MODE=TESTNET` and `DIVA_ENABLE_TESTNET_ORDERS=true`.
- LIVE orders require `DIVA_EXECUTION_MODE=LIVE`, `DIVA_LIVE_TRADING_ENABLED=true`, and `DIVA_LIVE_CONFIRMATION=I_ACCEPT_REAL_MONEY_RISK`. These settings must not be enabled until the complete runtime and protective position lifecycle are finished and the operator explicitly accepts the risk.
- Never place API credentials in source code, chat, ZIP releases, logs or screenshots. Use a local `.env` or secret store, restrict API-key IPs/permissions, and disable withdrawal permission.
- This release adds signed private REST and execution primitives, but it does not provide a continuously running end-to-end auto-trading process. No order was submitted to Binance during this build.

## Current project state and continuation

- Units 01–04G and the Unit 05E SMC V2 Stage 1–5 foundation are retained.
- v0.40.0 adds the AUTO/MANUAL USDT-perpetual universe selector, per-symbol SMC evidence pipeline, Decimal global-risk sizing primitive, signed Binance USDⓈ-M Futures REST client, durable SQLite execution ledger, PAPER-default execution service and multi-pair execution coordinator.
- The full bot is still under construction: continuous multi-pair feed orchestration, final SMC signal qualification and dynamic trade planning, account/position reconciliation, continuously managed order/position lifecycle, Telegram/dashboard and Windows deployment remain to be integrated.
- Historical replay convergence, long-horizon calibration and profitability research are deferred from the build critical path. This does not waive software-integrity or execution-safety requirements.
- Automated suite for v0.40.0: see `TEST_REPORT_v0.40.0.md`. Target Windows 10 / Python 3.12.9 / 8 GB compatibility still requires a user-PC run.
- Continue from `RELEASE_HANDOFF_v0.40.0.md`, not from the older v0.39.0 historical-replay next-task note.

## Mark Price feed contract — Unit 03E

The public Mark Price feed uses Binance USDⓈ-M Market Streams at `wss://fstream.binance.com/market/stream`, with one configured stream per exact contract symbol: `<symbol>@markPrice@1s` or `<symbol>@markPrice@3s`. It does not subscribe to `!markPrice@arr` for all symbols.

- Default update speed: `1s`; supported speeds: `1s` and `3s`.
- The normalized `MarkPriceEvent` keeps `mark_price`, `index_price`, `funding_rate`, `next_funding_time_ms`, and `event_time_ms` as Decimal / integer fields, with UTC timestamp properties. Optional `estimated_settle_price` and `mark_price_moving_average` are retained when supplied.
- `MarkPriceEvent.mark_index_basis` is `mark_price - index_price`; it is not a last-trade premium or a Kline close. Last trade price and candle OHLC remain distinct data sources.
- If Binance includes symbol type `st`, only `st=1` (USDⓈ-M) is accepted. COIN-M (`st=2`) events are rejected.
- Defaults: 48 symbols, 2,048 event queue; hard caps: 128 symbols and 8,192 queued events. WebSocket frame/message buffers reuse the bounded Unit 03C settings.
- Stale events older than 10 seconds and events more than 5 seconds in the future relative to the local clock are discarded and counted. Duplicate/out-of-order event timestamps per symbol are also discarded. Keep the Windows system clock synchronized.
- Reconnect uses bounded exponential backoff and resubscribes the exact selected symbol set. Queue overflow raises `MarkPriceQueueFullError` rather than silently dropping data.
- This checkpoint is read-only and does not write Mark Price data to SQLite; the latest stream values remain in the bounded event queue for the future market-data supervisor to consume.
- Automated tests use fixtures and an injected connector. No live Binance connection, private endpoint, API signing or order execution was added.

Example:

```python
import asyncio
from divatrading.market_data.mark_price import BinanceMarkPriceWebSocketFeed

async def main():
    feed = BinanceMarkPriceWebSocketFeed(
        symbols=["BTCUSDT", "ETHUSDT"],
        update_speed="1s",
    )
    stop = asyncio.Event()
    runner = asyncio.create_task(feed.run(stop))
    try:
        while True:
            event = await feed.get_event()
            print(event.symbol, event.mark_price, event.index_price, event.funding_rate)
    finally:
        stop.set()
        await runner

asyncio.run(main())
```



## Unit 04B — Aggregate Trade persistence and REST gap recovery

The public history source is `GET /fapi/v1/aggTrades` from `https://fapi.binance.com`.

- `fromId` is inclusive and pagination advances from the prior page's last aggregate ID plus one.
- Maximum REST page size is 1,000. The default recovery pass is capped at 3 pages with 200 ms spacing between requests. Binance currently documents IP request weight 20 per request.
- Binance currently documents the endpoint as queryable only for trade histories within the preceding 48 hours. A missing ID older than that boundary is recorded as unresolved; the bot never generates a synthetic aggregate trade.
- REST payload `q` (total quantity) is retained separately from optional `nq` (normal quantity excluding RPI trades). The live WebSocket stream does not carry `nq`; do not replace `q` with `nq` in the live signed-volume path.
- Schema v4 adds `aggregate_trades`, `aggregate_trade_stream_state`, and `aggregate_trade_gaps`. The durable stream cursor advances only across consecutive IDs.
- `AggregateTradeRecoveryService.bootstrap_latest()` establishes a deliberate recent baseline from the latest contiguous REST page. It does not claim that all older history has been downloaded. Existing cursors must not be reset by rerunning bootstrap.
- `ingest_websocket_event()` persists live events and makes stream state DEGRADED on an ID gap. `recover_gap()` backfills the missing inclusive ID range, resumes after the per-pass cap, and returns HEALTHY only after continuity is restored.
- `AggregateTradeRepository.prune_oldest()` is an explicit retention operation (default keep count 250,000 when called); it is blocked unless the stream state is HEALTHY. No automatic history deletion runs in this checkpoint.
- REST/repository methods are synchronous. A market-data supervisor must keep draining the bounded WebSocket queue in a separate consumer while serialized REST recovery runs.

See [docs/AGG_TRADE_RECOVERY.md](docs/AGG_TRADE_RECOVERY.md) for bootstrap and recovery guidance. `HEALTHY` means ID continuity only; strategy readiness must also include WebSocket connection and event freshness health.


## Unit 04C — Delta & CVD Aggregation

Unit 04C provides a synchronous Python service over Unit 04B's persisted, continuity-checked Aggregate Trade records. It is not an always-running background feed by itself.

- Exact Decimal BUY/SELL base and quote volume, base/quote Delta, cumulative CVD and rolling imbalance.
- Default UTC buckets: `1s`, `5s`, `15s`, `1m`, `5m`; interval selection and rolling lookback are bounded.
- SQLite schema v5 persists per-symbol CVD cursor/state and bucket totals atomically.
- Processing is capped at 5,000 rows per call and 20 passes per catch-up call. Repeated processing is idempotent.
- CVD baseline starts at the earliest Aggregate Trade ID retained locally when the service first initializes; it is not full exchange/day/session CVD.
- The processor advances only through Unit 04B's contiguous ID cursor. DEGRADED/UNRESOLVED gaps are exposed as invalid continuity and never bridged.
- Freshness and sequence continuity are independent fields; strategy consumers must gate on both where required.
- `reset_for_replay()` can deterministically rebuild derived metrics from retained raw rows and requires a HEALTHY upstream stream.

See [docs/ORDER_FLOW_GUIDE.md](docs/ORDER_FLOW_GUIDE.md) for formulas, baseline semantics, replay and API examples.


## Unit 04D — Order Book Depth & Book Imbalance

`BinanceDepthWebSocketFeed` subscribes only to configured exact symbols using USDⓈ-M `<symbol>@depth@100ms` or `@500ms` streams. `BinanceDepthSnapshotClient` fetches `/fapi/v1/depth` with an explicit bounded limit and request pacing. `LocalOrderBook` performs the initial snapshot bridge and then validates the Futures `pu` chain before exposing metrics.

- Defaults: 8 selected symbols, 4,096 event queue, 100 REST snapshot levels, 100 local levels per side, top-20 metric depth. Hard caps: 32 symbols, 16,384 queued events, 1,000 snapshot/book levels.
- All prices and quantities use `Decimal`. A diff is copy-on-write; a sequence gap, stale event, crossed/invalid book or queue overflow invalidates readiness.
- Metrics: best bid/ask, spread, spread bps, top-N displayed bid/ask quantity and `(bid_qty - ask_qty) / (bid_qty + ask_qty)` imbalance.
- Futures synchronization uses the initial `U <= lastUpdateId <= u` bridge and then `pu == previous u`. Do not apply Spot's `U == previous u + 1` rule.
- See [docs/ORDER_BOOK_GUIDE.md](docs/ORDER_BOOK_GUIDE.md). Unit 04E adds the caller-managed supervisor; it is not started by the default CLI or connected to strategy execution. It does not infer absorption/exhaustion.


## Unit 04E — Depth Health & Resynchronization Supervisor

`BinanceOrderBookSupervisor` owns the Unit 04D feed, snapshot and local-book lifecycle for each configured symbol. It buffers live diffs before obtaining snapshots, serializes REST snapshot calls, and rebuilds any book invalidated by disconnect/reconnect, sequence failure, stale data or buffer overflow.

- Readiness requires connection, a bridged snapshot, valid Futures `pu` sequence, fresh event time and a healthy WebSocket queue. `health(symbol)` exposes each gate; `metrics(symbol)` raises `OrderBookNotReady` unless all gates pass.
- Snapshot HTTP calls run through `asyncio.to_thread`, so the consumer continues draining the feed queue during network latency. Snapshot requests are serialized across symbols.
- Defaults: 2,048 initial buffered events per symbol, 5 bounded snapshot attempts, 250 ms retry base and 75% queue high-water mark.
- Feed reconnects and feed-task failure invalidate every selected book. Stale metrics are not retained as ready data.
- No depth rows are persisted to SQLite: there is no historical replay consumer yet, and every process restart must establish a new snapshot/stream bridge. Schema remains v5.
- See [docs/ORDER_BOOK_SUPERVISOR_GUIDE.md](docs/ORDER_BOOK_SUPERVISOR_GUIDE.md). No absorption/exhaustion, SMC, Telegram, dashboard or execution integration is included.

- Ready-to-paste Pine capture copy: `reference/pine_smc/Sniper_SMC_MTF_Enhanced_Instrumented_v1.pine` (47 export-only plots). See `docs/TRADINGVIEW_REFERENCE_CAPTURE.md`.


## Unit 05D — Pine built-in TA pre-roll and volatility regime (stage 4)

Each `PineSmcBarTrace` now exposes an immutable `indicators` record containing Pine ATR(14), RSI(14), SMA(volume,20), +DI, -DI, ADX, ATR(200) ratio base, ATR ratio, and volatility regime flags. These built-ins advance over the complete loaded source-history prefix; only the SMC structure/OB state resets at `startIndex`. Unavailable Pine values are represented as `None` and serialized as JSON `null`.

```python
from divatrading.strategy import PineSmcStructureConfig, PineSmcStructureEngine

replay = PineSmcStructureEngine(
    PineSmcStructureConfig(symbol="BTCUSDT", timeframe="1m")
).replay(candles)
for bar in replay.trace:
    print(bar.source_time_ms, bar.indicators.atr_fast_now, bar.indicators.rsi_now, bar.indicators.adx_now)
```

The values are source-derived diagnostics consumed by the Stage-5 volatility eligibility gates. They do not yet produce final signals. See [docs/PINE_SMC_BUILTIN_TA_STAGE4.md](docs/PINE_SMC_BUILTIN_TA_STAGE4.md).


## Unit 05E — SMC V2 OB Validation & Lifecycle (Stage 4)

`ScalpingOrderBlockLifecycleEngine` consumes immutable Stage-3 `OrderBlockCandidate` records and same-capture closed Binance Klines. It maintains independent M1/M5 lifecycle states; M15 remains advisory-only. Lifecycle states are `CANDIDATE`, `ACTIVE_FRESH`, `TOUCHED`, `MITIGATED`, `INVALIDATED`, and `EXPIRED`.

Touch is an inclusive candle-range intersection with the OB zone. Positive penetration from the entry side begins mitigation; the engine stores maximum depth from 0 to 1, so partial and full mitigation remain distinguishable. A touch at exactly the entry edge has zero depth and remains `TOUCHED`. Invalidation is explicitly configurable as `WICK` or `CLOSE`, with `STRICT` or `INCLUSIVE` distal-boundary equality. Defaults are WICK/STRICT. The provisional age limit is 300 bars in the candidate's own source timeframe and expires only after the limit is exceeded; it must be calibrated by Binance replay.

The break candle is not treated as a post-formation touch because OHLC cannot establish the intrabar order of the break and a return to the zone. Lifecycle begins with the next closed source-timeframe candle. Gaps, late candidates, revised candles, source/break provenance mismatch and off-grid prices fail closed. Terminal records can be evicted oldest-first when capacity is needed; active/nonterminal records are never silently dropped. Lifecycle records always expose `filled=false` and `consumed=false`; an OB interaction is not an exchange fill. See [docs/SMC_V2_OB_VALIDATION_LIFECYCLE_STAGE4.md](docs/SMC_V2_OB_VALIDATION_LIFECYCLE_STAGE4.md).

```python
from divatrading.strategy import (
    ScalpingOrderBlockLifecycleConfig,
    ScalpingOrderBlockLifecycleEngine,
)

lifecycle = ScalpingOrderBlockLifecycleEngine(
    config=ScalpingOrderBlockLifecycleConfig(
        invalidation_mode="WICK",
        invalidation_boundary="STRICT",
        max_age_bars=300,  # provisional; calibrate with Binance replay
    )
)
# `formation` is the same-capture Stage-3 result; `view` is the same-capture
# ScalpingMarketDataView. No orders or fills are created by this call.
result = lifecycle.process(formation, view)
```


## Unit 05E — SMC V2 Liquidity & FVG Evidence (Stage 5, v0.30.0)

`ScalpingLiquidityFVGEngine` consumes the same-capture Stage-2 structure result and validated closed Binance Klines. It exposes confirmed-pivot liquidity references, equal-high/equal-low clusters, closed-candle sweep evidence and three-candle bullish/bearish FVGs. Equal-level tolerance is measured in exact `PRICE_FILTER.tickSize` units and remains provisional pending replay. Sweep evidence distinguishes wick breach, close-through and strict close-back; close-back is required by default. FVGs track ACTIVE, TOUCHED, PARTIALLY_FILLED and FILLED independently from Stage-4 OB lifecycle.

M1/M5 evidence is independent; M15 is advisory-only. Stage 5 is optional confluence evidence: it does not veto OB validity, create entries, score/rank candidates or mutate OB lifecycle. It adds no live/private API, order placement, CVD/Depth/Absorption integration, Entry/SL/TP, risk, position management, Telegram/dashboard or database migration. See [docs/SMC_V2_LIQUIDITY_FVG_EVIDENCE_STAGE5.md](docs/SMC_V2_LIQUIDITY_FVG_EVIDENCE_STAGE5.md). The 36 focused tests and full suite (646 tests) validate mechanics only; historical Binance replay and calibration remain pending.


## Unit 05E — Stage 6C.2 Eligibility Gates & Provisional Replay (v0.37.0)

Stage 6C.2 separates market-data integrity from historical execution metadata eligibility. `replay-quality` schema v2 now exposes `eligibility_gates.market_data` and `eligibility_gates.execution_metadata` while retaining the conservative combined strict status. The integrated `replay-workflow` defaults to `STRICT`; explicitly setting `replay_mode` to `PROVISIONAL_STRATEGY_EVIDENCE` allows deterministic Stage 2–5 strategy-evidence analysis only when the market-data gate passes and a valid exact candidate tick size/instrument metadata are available. Provisional reports always retain `execution_metadata_gate=BLOCKED`, `strict_execution_eligible=false`, and `STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION`. This does not validate historical order filters, fills, fees/slippage, execution, PnL or profitability. See [Stage 6C.2 eligibility gate contract](docs/SMC_V2_REPLAY_ELIGIBILITY_GATES_STAGE6C2.md).

Real BTCUSDT USDⓈ-M data was audited for 12 October–11 November 2026: M1 43,200 rows and M5 8,640 rows, with structural integrity and raw-page provenance passing. Candidate tick size is 0.10 but remains current-only corroboration; historical effective bounds are unproven and strict execution eligibility remains blocked. A bounded provisional integrated replay over a common 15-minute window completed three 3h/2h/1h pre-roll trials and 24 convergence comparisons. It did **not** converge across all evidence stages: lifecycle/liquidity differences remained and the 1h trial also differed in market structure. This is a tooling/sensitivity smoke, not strategy calibration. Details: [real-data Stage 6C.2 smoke report](docs/REAL_DATA_STAGE6C2_SMOKE_REPORT.md). The target Windows 10 / Python 3.12.9 environment remains unverified.


## v0.42.0 — Production Multi-Pair Public Feed Graph (read-only)

`divatrading market-runtime` now composes the existing public Binance USD-M services into one isolated feed graph per selected symbol. The runtime discovers the eligible USDT perpetual universe in AUTO mode or accepts an explicit MANUAL allow-list, then starts bounded workers for selected symbols.

Each graph combines:

- M1/M5/M15 Kline WebSocket streams with a REST-backed closed-candle bootstrap and gap recovery service;
- Mark Price WebSocket updates;
- Aggregate Trade WebSocket events, REST bootstrap/gap recovery, SQLite persistence and continuous Delta/CVD aggregation;
- Depth diff WebSocket events, a paced REST snapshot gate and Futures update-ID sequencing through `BinanceOrderBookSupervisor`;
- Absorption alignment and `ScalpingMarketDataAdapter` readiness/freshness validation;
- complete `ScalpingMarketDataView` captures routed through the existing SMC V2 Stage 2–5 pipeline.

The feed graph is fail-closed: incomplete Kline history, disconnected/stale Mark Price, non-contiguous Aggregate Trades, unhealthy queues, an unsynchronized/stale depth book, missing readiness or stale snapshots prevent emission. It never synthesizes Klines or marks degraded sources READY. Per-symbol workers are isolated, while history REST calls and depth snapshot calls are paced through shared request gates. The default CLI profile limits the active universe to eight symbols for the Windows 8 GB target; the cap can be adjusted up to 24 after resource observation.

Run from the extracted project directory after installation:

```powershell
python -m divatrading init-db
python -m divatrading market-runtime --mode AUTO --max-symbols 8
```

Manual selection example:

```powershell
python -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT,ETHUSDT,SOLUSDT --max-symbols 3
```

The command continues to use public market feeds only and cannot submit, amend or cancel orders. After each complete market capture, v0.43 evaluates M1/M5 OB lifecycle candidates, retains M15 as advisory context, applies configured optional confluence, builds separate LIMIT_RETRACEMENT or CONFIRMATION_MARKET trade plans, derives dynamic OB-protective SL and RR/structural TP, and records accepted/rejected candidate JSON in the application log. Its `--paper-equity-usdt` input is a reference value for plan sizing, not a Binance account balance. In-memory planning reservations are provisional and are not exchange-truth portfolio reconciliation.

Example live-market / paper-plan command:

```powershell
python -m divatrading market-runtime --mode AUTO --max-symbols 8 --entry-model LIMIT_RETRACEMENT --paper-equity-usdt 1000 --risk-per-trade-pct 0.25 --max-portfolio-risk-pct 1.00 --target-r-multiple 2.0 --min-signal-score 55
```

The alternative `--entry-model CONFIRMATION_MARKET` requires a directional, fully closed setup-timeframe candle beyond the OB zone; it does not reuse the limit midpoint trigger. v0.43 remains no-order/PAPER plan output. v0.44 will wire account reconciliation, global live risk, order execution, and position management.

The local build used Linux x86_64 / Python 3.13.x. Windows 10 / Python 3.12.9 / 8 GB compatibility and actual Binance WebSocket connectivity must be exercised on the target PC; automated tests use offline fixtures and mocks only.


## v0.43.0 — SMC V2 Signal Qualification & Dynamic Trade Planner

`SMCV2TradePlanner` converts the same-capture Stage 2–5 evidence into traceable M1/M5 candidate decisions, `QualifiedSignal` and risk-sized `TradePlan` outputs. Every decision records reason codes and planner/risk parameter snapshots. M1/M5 setup processing remains independent; M15 is advisory. FVG, sweep, Delta/CVD, depth and absorption confluence are optional by default and do not change OB lifecycle validity.

Entry models are separate: `LIMIT_RETRACEMENT` places a limit at the conservative tick-aligned OB midpoint while price remains outside the zone; `CONFIRMATION_MARKET` requires a directional closed-candle confirmation beyond the OB zone and uses the current mark price. Stop Loss is beyond the distal OB wick boundary; Take Profit uses configured R multiple or a confirmed, unbroken structural pivot that meets minimum R. Exact current exchange tick, quantity, notional and entry/bracket order-type filters are applied fail-closed. The live-market CLI logs all accepted/rejected candidates and plans. It still submits no order; v0.44 adds exchange-truth account reconciliation and the execution/position lifecycle. See [docs/SMC_V2_SIGNAL_PLANNER_V043.md](docs/SMC_V2_SIGNAL_PLANNER_V043.md).


## v0.49.0 — Managed Position Supervisor

`divatrading account-runtime` now starts a bounded Mark Price worker for each actively managed symbol and co-runs it with the User Data Stream reducer and periodic REST reconciliation. The supervisor automatically dispatches partial TP, BE/trailing stop replacement and structural-invalidation market exits through the lifecycle execution adapter. Partial TP tracks the original protected quantity and cumulative fills; exchange quantity rounding is persisted to avoid dust actions. A DIVA-managed emergency close is available through an explicit, confirmed operator command:

```powershell
python -m divatrading emergency-close --signal-id <DIVA_SIGNAL_ID> --reason "operator emergency exit" --confirm "CLOSE DIVA POSITION"
```

This command requires an explicitly configured TESTNET or LIVE environment and a running account runtime with fresh User Data Stream/reconciliation state. PAPER remains default. Entry kill switch never closes open positions. Only one active DIVA-managed signal per `(symbol, positionSide)` is supported. No actual exchange network/order validation or Windows target-PC validation has been performed. See [v0.49.0 supervisor design](POSITION_SUPERVISOR_V049.md), [release handoff](RELEASE_HANDOFF_v0.49.0.md) and [full roadmap](ROADMAP_FULL_AUTO_TRADING.md).

### Stage C controlled Demo execution

Stage C actual TESTNET execution requires both `DIVA_ENABLE_TESTNET_ORDERS=true` and the separate `DIVA_ENABLE_TESTNET_STAGE_C=true` local opt-in. The initial qualification runtime is restricted to one manually selected symbol, one worker, risk-per-trade <=0.10%, and portfolio risk <=0.25%. It waits for a genuine SMC-qualified signal and requires private User Data Stream plus REST reconciliation readiness before dispatch. See [TESTNET_STAGE_C_V057C.md](TESTNET_STAGE_C_V057C.md). Do not enable these flags until the operator is ready for an actual Demo matching-engine order. LIVE remains disabled.
