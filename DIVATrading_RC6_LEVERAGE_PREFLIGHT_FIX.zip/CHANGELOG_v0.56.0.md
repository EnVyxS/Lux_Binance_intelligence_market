# Changelog v0.56.0 — Autonomous SMC-to-Entry Dispatcher

- Adds `auto-trade-runtime` to connect the AUTO/MANUAL multi-pair market runtime, SMC V2 qualification-only planner, durable autonomous dispatcher, fresh account snapshot, global portfolio risk coordinator, idempotent execution and existing position/account supervisors.
- Persists signal claims before snapshot I/O; duplicate signals remain at-most-once and ambiguous failures require reconciliation rather than blind resubmission.
- Makes the coordinator the sole authority for final sizing and atomic portfolio reservation.
- Adds PAPER portfolio snapshots and deterministic full-fill-at-plan-price simulation with local quantity-scoped virtual protection and managed-position state. The simulation is not an exchange-quality fill/slippage model.
- Nets fully mapped, active-reservation DIVA lots against aggregate exchange notional; charges unmatched positions and unattributed external open orders conservatively; unpriced external open orders fail closed.
- TESTNET runtime requires User Data Stream and REST reconciliation readiness. Same-side TESTNET/LIVE scale-in remains blocked pending TESTNET qualification. Autonomous LIVE routing is disabled.
- Full regression: 906 passed. Clean-extraction regression: 906 passed. Compileall, CLI help, ZIP integrity and SHA-256 checks: PASS.
- No actual Binance TESTNET/LIVE private request, stream session or order was executed. Build host: Linux / Python 3.13.5; project `requires-python ==3.12.9` remains unchanged.
