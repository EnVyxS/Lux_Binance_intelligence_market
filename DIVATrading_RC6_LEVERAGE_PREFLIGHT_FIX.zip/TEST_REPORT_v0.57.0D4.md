# Test Report — v0.57.0D4

## Environment
- Linux x86_64 / Python 3.13.5
- Project target remains Windows 10 / Python 3.12.9 (`requires-python ==3.12.9`)
- Tests use local SQLite and deterministic fake exchange/stream clients.

## Results
- Full source regression: **986 passed**.
- Focused D4 suite (`test_user_data_stream.py`, `test_trade_backfill.py`, `test_position_accounting.py`, `test_position_lifecycle_execution.py`): **129 passed**.
- D4 integrated partial-trigger lifecycle scenario: included in the focused suite and passed.
- Wheel build: PASS (`divatrading_binance_bot-0.57.0rc5-py3-none-any.whl`). Metadata: `Version: 0.57.0rc5`; `Requires-Python: ==3.12.9`. Build used `--ignore-requires-python` only to allow wheel creation on Python 3.13.5; it was not installed on that host.
- `compileall`: PASS on source and clean extraction. Four CLI help checks: PASS on source and clean extraction.
- Clean archive regression: **986 passed**; source manifest verified 413/413 entries; ZIP CRC PASS.
- Sensitive-file audit: PASS.

## New coverage
- Forced userTrades backfill after every new private User Data Stream connection, bypassing the normal interval throttle.
- Forced backfill flag survives a failed symbol/page and clears only after all tracked symbols succeed.
- Runtime detects connection timestamp changes and requests forced recovery.
- Existing manual/operator halt is not cleared by a successful backfill. A failure halt owned by the reconciler can be cleared only after successful retry and a clean sequential account snapshot.
- REST-verified triggered Algo child `actualOrderId` maps to its signal lot as a CLOSE protective order before cancel/fill reduction.
- Late REST userTrades fills are retroactively attributed to the exact signal lot when child ownership becomes known.
- Multi-lot fill projections conserve aggregate quantity and preserve commission assets and realized PnL.
- Restart/duplicate Algo event replay does not create duplicate residual protection orders; aggregate-flat finalization releases both lots' reservations only after REST flat confirmation.
- Seeded deterministic quantity-conservation/FIFO allocation invariants across One-way `BOTH` and Hedge `LONG`/`SHORT` position sides.

## Existing D1–D3 coverage retained
- Algo/child REST identity, cancel races and final executed quantity.
- Zero/partial/full child fills, One-way/Hedge close semantics and paired residual protection.
- Ambiguous cancellation/restart, duplicate/out-of-order events, REST trigger backfill and opt-in TESTNET-only zero-fill re-protection.

## Limitations
- No live Binance account, Demo or LIVE private API operation, WebSocket session, order placement, child cancellation or Algo mutation was performed.
- This test run does not prove matching-engine behavior or exchange acceptance of same-side scale-in.
- Exact D4 ZIP Windows 10 / Python 3.12.9 execution remains unverified.
