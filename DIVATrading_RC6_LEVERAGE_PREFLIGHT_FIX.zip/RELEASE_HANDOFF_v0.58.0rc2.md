# Release Handoff — DIVATrading v0.58.0rc2

## What this checkpoint is

This is the recoverable release checkpoint for the Telegram `SIGNAL_ONLY` publication path and the first optional Kronos-mini shadow forecast integration. It was built from the exact v0.58.0rc1 archive restored from the Library. The prior conversation's stated RC2 ZIP was not present in the Library; this checkpoint therefore reconstructs RC2 from the verified RC1 baseline and adds the documented implementation to source.

## Preserve these design decisions

1. SMC is the only source of setup qualification.
2. Kronos is independent shadow forecasting, M5 only, and can never gate or change SMC decisions or execution.
3. Telegram signal publication is outbound-only `sendPhoto` and `SIGNAL_ONLY`. It submits no Binance orders and does not poll Telegram updates.
4. The Telegram operator control process remains a separate, owner-authenticated long-polling process.
5. Signal, forecast and evaluation records persist in SQLite schema v6.
6. The real Kronos model is **not** inside the ZIP. Install only by explicitly running the local Kronos installer on the user's Python 3.12.9 virtual environment.
7. LIVE remains disabled. Do not infer LIVE readiness from this Signal Center release.

## Source map

- `src/divatrading/intelligence/kronos.py`: lazy Kronos adapter and input/output contracts.
- `src/divatrading/intelligence/kronos_install.py`: explicit pinned-source/model installer.
- `src/divatrading/intelligence/kronos_evaluation.py`: exact future M5 forecast diagnostics.
- `src/divatrading/signals/telegram.py`: SQLite signal ledger, chart rendering and outbound `sendPhoto` publisher.
- `src/divatrading/core/database.py`: schema v6 migration.
- `src/divatrading/cli.py`: Kronos and Signal Center CLI/runtime integration.
- `INSTALL_KRONOS_WINDOWS.bat`: optional CPU model installation.
- `RUN_SIGNAL_RUNTIME_WINDOWS.bat`: BTCUSDT read-only SMC Signal Center with optional Kronos.
- `RUN_SIGNAL_RUNTIME_NO_KRONOS_WINDOWS.bat`: charted SMC Signal Center without model inference.
- `RUN_TELEGRAM_CONTROL_WINDOWS.bat`: inbound owner-only Telegram control process.

## Local startup sequence

1. Extract archive to a stable folder.
2. Run `INSTALL_WINDOWS.bat` under Python 3.12.9 x64.
3. Run `TEST_WINDOWS.bat` and require a clean pass on Windows.
4. Fill only the local `TELEGRAM_BOT_TOKEN` and `TELEGRAM_OWNER_ID` values in `.env` if Telegram is required.
5. Optional but recommended for forecast display: run `INSTALL_KRONOS_WINDOWS.bat`; this downloads model/source assets to `.kronos/` and may take several hundred MB including CPU PyTorch.
6. Run `kronos-status`; after install, run the one-shot `kronos-forecast --symbol BTCUSDT` smoke test.
7. Run `RUN_SIGNAL_RUNTIME_WINDOWS.bat`. If model download is deferred, `RUN_SIGNAL_RUNTIME_NO_KRONOS_WINDOWS.bat` publishes SMC charts with an explicit unavailable marker.
8. Run `RUN_TELEGRAM_CONTROL_WINDOWS.bat` in a separate terminal only if inbound operator commands are also required.

No Binance API key is required for market-runtime/SIGNAL_ONLY; it uses public market data. Never paste Telegram token, API keys, API secrets or `.env` into chat.

## Known gaps / next work

- Real model download/inference and CPU/RAM/latency on Windows remain unverified until the user runs the install/smoke test.
- Fee-tier and slippage assumptions are not configured; only gross RRR is shown. Net RRR is explicitly marked unavailable.
- Signal lifecycle outcomes are not represented as exchange fills. OHLC touches must not be mislabeled as executed trades.
- LIVE account preflight, fully integrated Binance leverage/margin selection, exchange-reconciled loss-streak accounting, strict account commissioning, and end-to-end LIVE lifecycle acceptance remain outstanding.

## Authority

See `BUILD_STATE_v0.58.0rc2.md`, `CHANGELOG_v0.58.0rc2.md`, `FINAL_RELEASE_VERIFICATION_v0.58.0rc2.md`, `CLEAN_EXTRACTION_TEST_REPORT_v0.58.0rc2.md`, and `NEXT_TASK_v0.58.0rc2.md` in the release archive.
