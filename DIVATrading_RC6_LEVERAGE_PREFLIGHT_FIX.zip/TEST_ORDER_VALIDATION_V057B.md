# v0.57.0B — Signed Binance USDⓈ-M Demo Test Order Validation

## Purpose and boundary

Stage B adds a controlled signed validation request to Binance USDⓈ-M Demo Futures through `POST /fapi/v1/order/test`. Binance describes this endpoint as a test of an order request that is **not submitted to the matching engine**. A successful response is evidence that the signed request and submitted parameters were accepted by this endpoint; it is not an exchange order, fill, position, or proof that Stage C execution is ready.

Only `LIMIT` and `MARKET` are supported in Stage B. The request builder accepts `GTC`, `IOC`, `FOK`, `GTX`, and `RPI` when the symbol metadata allows them; `GTD` is deliberately omitted because it additionally requires a `goodTillDate` parameter that this stage does not collect. STOP/TP/conditional Algo orders, actual `/fapi/v1/order` submission, position opening, cancellation, and fills remain out of scope and are not invoked by the Stage B CLI.

## Endpoint and credential safety

- REST host is pinned to `https://demo-fapi.binance.com` for `TESTNET`.
- LIVE host is not selectable by this command. The client rejects a custom base URL that does not exactly match the approved host for the selected environment.
- HMAC-SHA256 signs the canonical query string with `timestamp` and `recvWindow`; the API key is sent in `X-MBX-APIKEY`.
- Signed POST requests are never automatically retried. Transport errors are reported as an unconfirmed request outcome, and diagnostics do not include the signed URL or signature.
- API Key, API Secret, signatures, and raw request URLs are not printed or persisted in test reports.
- `.env` remains local. `.env` is excluded from the release ZIP and must not be committed or shared.
- `DIVA_ENABLE_TESTNET_ORDERS=false` stays false, and the command blocks if that flag is enabled. Stage B has a separate opt-in, `DIVA_ENABLE_TESTNET_ORDER_TEST=true`, plus an explicit CLI `--confirm-test-order` flag. This flag authorizes only `/fapi/v1/order/test`.
- `DIVA_LIVE_TRADING_ENABLED=false` must remain in force. PAPER remains the default runtime mode.

## Parameter validation

Before sending the test request, the command reruns the read-only Stage A preflight on the same client. It blocks unless the selected Demo account is ready and the selected symbol exists in current Demo `exchangeInfo` as an active USDT-margined perpetual.

It then checks:

- supported order types and time-in-force values reported for the symbol;
- exact `MARKET_LOT_SIZE` filters for MARKET, or `LOT_SIZE` filters for LIMIT;
- positive quantity, exchange step alignment, and current quantity bounds;
- exact `PRICE_FILTER.tickSize`, minimum price, and maximum price for LIMIT;
- exact `LIMIT` notional using the explicit limit price and current minimum/maximum notional filters;
- account position mode. Hedge Mode requires explicit `--position-side LONG|SHORT`; One-way Mode uses `BOTH`.

For MARKET, local code deliberately does not estimate notional from the last-price ticker. Reference-price rules for market-order filters are exchange-side semantics; `/order/test` remains authoritative for MARKET notional and other server-side filters. This avoids a false local pass/fail based on a stale or inappropriate price proxy.

## Local setup (when the Windows PC is available)

Use newly rotated Demo credentials if a prior key/secret was shared outside the PC. Put them only in the local `.env`; never provide them through chat, command-line arguments, screenshots, or logs.

Required `.env` values:

```dotenv
DIVA_EXECUTION_MODE=TESTNET
DIVA_ENABLE_TESTNET_ORDERS=false
DIVA_ENABLE_TESTNET_ORDER_TEST=true
DIVA_LIVE_TRADING_ENABLED=false
BINANCE_API_KEY=<local-demo-api-key>
BINANCE_API_SECRET=<local-demo-api-secret>
```

Keep withdrawal permission disabled. Enable only the Demo Futures permission required for the validation. Do not use LIVE credentials.

First run the read-only check:

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-preflight --symbols BTCUSDT
```

Proceed only if it reports `READY_FOR_TEST_ORDER_VALIDATION`. Stage B reruns preflight again immediately before the test-order call, so positions or open orders appearing in between cause the command to block.

Example MARKET validation (the current Demo `MARKET_LOT_SIZE` is checked locally; Demo exchange filters validate notional):

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-order-test --symbol BTCUSDT --side BUY --order-type MARKET --quantity <quantity-aligned-to-current-market-lot-filter> --confirm-test-order
```

Example LIMIT validation:

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-order-test --symbol BTCUSDT --side BUY --order-type LIMIT --quantity <quantity-aligned-to-current-lot-filter> --price <price-aligned-to-current-tick-size> --time-in-force GTC --confirm-test-order
```

For Hedge Mode, add `--position-side LONG` or `--position-side SHORT`. For One-way Mode, omit it. Do not blindly copy quantities or prices from old examples; use current Demo `exchangeInfo` filters and current account settings.

## Result interpretation

- `TEST_ORDER_ACCEPTED`: Demo endpoint accepted the signed validation request. `matching_engine_submission`, `order_created`, and `actual_execution` remain `false`.
- `EXCHANGE_REJECTED`: endpoint returned an exchange HTTP/code rejection. Review the numeric status/code and correct the input or account configuration.
- `BLOCKED_PREFLIGHT` or `BLOCKED_ORDER_PARAMETERS`: the command did not send the test-order request.
- `TEST_ORDER_TRANSPORT_UNCONFIRMED`: network outcome could not be confirmed. The command does not retry automatically; inspect connectivity and rerun the preflight before manually deciding whether to repeat the validation request.

## Validation performed during this build

All automated tests use fixture metadata, deterministic local clocks, mock HTTP transport, and local environment files. No actual Binance account credential, signed Demo API call, Demo WebSocket connection, test order, or LIVE request was used in this build. A user-run Demo request remains pending because the target PC is currently unavailable.

## Next stage

v0.57.0C is the separate controlled Demo entry stage. It will require a distinct explicit authorization for actual `/fapi/v1/order` placement, small risk-bounded quantity, exchange-side fill confirmation, and immediate protection/reconciliation checks. Passing Stage B does not authorize Stage C or LIVE.
