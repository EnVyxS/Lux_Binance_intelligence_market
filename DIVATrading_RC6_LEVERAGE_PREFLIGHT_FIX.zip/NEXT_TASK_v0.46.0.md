# Next Task — Position Lifecycle & Verified Risk Release (v0.47.0)

1. Define exchange-truth position state transitions for pending, partial fill, protected, partially reduced, flat and terminal states.
2. Correlate ORDER_TRADE_UPDATE, ALGO_UPDATE, ACCOUNT_UPDATE and REST order/position state to avoid double-applying fills.
3. Implement partial take-profit in exact exchange step sizes and verify close quantity/remaining position before updating local state.
4. Implement breakeven and trailing stop amendments with cancel/replace idempotency and protection-gap handling.
5. Implement explicit exit signal / structural invalidation / emergency close flows, always reduce-only/close-position and exchange-truth verified.
6. Release portfolio risk reservation only after terminal no-fill entry or verified flat position with no remaining DIVA entry/protection orders.
7. Handle partial fills, unknown submission outcomes, process restart, reconnect and duplicate event replay without duplicate exit orders.
8. Add deterministic tests for LONG/SHORT and one-way/hedge position modes, rounding, race windows, and restart recovery.

Keep PAPER default. Do not claim TESTNET/LIVE lifecycle validation until the complete state machine has dedicated exchange testing.
