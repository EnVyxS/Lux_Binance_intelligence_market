# Build State — v0.59.0rc1

- Release: DIVATrading Autonomous Execution & Risk Integration Candidate.
- Parent: v0.58.0rc4 source baseline.
- Package version: `0.59.0rc1`.
- Runtime build host: Linux / Python 3.13.5. Project pin remains `requires-python ==3.12.9`; Windows target not exercised in this build session.
- Risk sizing: typed per-symbol account leverage tiers and commission feed coordinator/dispatcher for all non-PAPER candidate sizing; fresh available margin required; fee/slippage/funding reserves applied; quantity never inflated for minNotional.
- Execution settings: isolated/crossed and leverage configuration are read from Binance, writes guarded by flat/no-open-order checks, then verified by `symbolConfig` readback. This is exercised with mocked TESTNET adapters only.
- Risk ledger: bounded restart-safe 90-day bootstrap income backfill + seven-day windows; unknown non-zero income and unsupported assets fail closed; completed managed-lifecycle results derive from attributed fills; funding allocation and loss streak persist in SQLite.
- Daily risk: Jakarta day PnL from exchange income; USDT transfers removed from flow-neutral equity; mid-day day-start anchor reconstructed using realized and floating PnL.
- Telegram: owner-only controls integrated into autonomous runtime thread; persisted settings re-read before each signal; long-poll offset persists across restart; `/resetkill confirm` clears kill latch; PAUSE/KILL only halt new entries.
- Full source regression: **1,038 passed**; compileall, package import/version and CLI help passed.
- Wheel not built because the available host is Python 3.13.5 while the release intentionally pins `==3.12.9`; no host-interpreter constraint was bypassed.
- No Binance account or API credential used; no private exchange request, WebSocket, order placement/cancellation, or LIVE account mutation was executed.
- Autonomous LIVE runtime remains hard-blocked. Exact Windows and exchange lifecycle qualifications remain outstanding.
