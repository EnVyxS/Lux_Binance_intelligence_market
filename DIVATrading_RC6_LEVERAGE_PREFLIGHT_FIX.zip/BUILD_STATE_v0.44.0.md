# Build State v0.44.0 — in progress

Base: v0.43.0 SMC V2 Signal Planner.

Implemented in this checkpoint:
- Exchange-truth account snapshot service for USD-M Futures.
- Reads equity, wallet/available balance, non-zero positions, standard open orders and conditional/algo open orders.
- Decimal parsing rejects missing, malformed and non-finite numeric values.
- Conservative open-risk reservation uses absolute position notional until verified protective-stop reconciliation is available.
- Exported account snapshot API from execution package.

Not yet complete in this checkpoint:
- User Data Stream listen-key lifecycle and event reducer.
- Atomic global risk reservation across concurrent workers.
- Full order/position reconciliation and restart recovery.
- Partial TP, breakeven, trailing and automatic exit orchestration.
- Windows/Python 3.12.9 target verification and real TESTNET connectivity.

Execution mode remains PAPER by default. No private Binance request or order was sent during this build.
