@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: run INSTALL_WINDOWS.bat first.
  exit /b 1
)
echo Telegram-only credential and private chat check. NO Binance orders.
.venv\Scripts\python.exe -m divatrading telegram-check
exit /b %errorlevel%
