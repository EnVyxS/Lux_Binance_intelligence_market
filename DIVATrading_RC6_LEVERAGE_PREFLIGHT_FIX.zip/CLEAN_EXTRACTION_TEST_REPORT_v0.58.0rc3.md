# Clean Extraction Test Report — v0.58.0rc3

- Extracted final ZIP into a new empty directory: PASS.
- ZIP CRC: PASS.
- Source manifest: 454/454 files match SHA-256.
- Targeted regression from extracted archive: 23 passed.
- `compileall`: PASS.
- Package import/version: PASS (`0.58.0rc3`).
- `live-read-only-preflight --help`: PASS.
- Full 1,018-test suite is not claimed as passed; see `TEST_REPORT_v0.58.0rc3.md`.
