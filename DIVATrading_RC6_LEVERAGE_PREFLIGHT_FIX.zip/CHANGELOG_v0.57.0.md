# Changelog — v0.57.0B / package 0.57.0b1

Binance USDⓈ-M Demo Futures Signed Test Order Validation (Stage B) (2026-11-14)

- Adds `new_test_order()` for signed `POST /fapi/v1/order/test` through the pinned Demo Futures REST host. The method does not call the actual `/fapi/v1/order` or `/fapi/v1/algoOrder` placement endpoints.
- Adds a strict LIMIT/MARKET request builder. It uses `Decimal`, current `exchangeInfo` symbol status and order types, `LOT_SIZE` or `MARKET_LOT_SIZE`, exact `PRICE_FILTER.tickSize` and bounds, active symbol time-in-force values, and explicit One-way/Hedge position mode semantics.
- LIMIT notional is checked locally against exact limit price and current symbol notional filters. MARKET notional is deliberately left to the Demo test-order endpoint instead of a last-price approximation.
- Adds `testnet-order-test`, which reruns read-only Stage A preflight immediately before the validation-only request. It requires both `DIVA_ENABLE_TESTNET_ORDER_TEST=true` in local `.env` and `--confirm-test-order` on the command line.
- Keeps `DIVA_ENABLE_TESTNET_ORDERS=false`, PAPER default, and LIVE disabled. No actual order placement, cancellation, position opening, matching-engine submission or fill is part of this stage.
- Disables automatic retry for signed writes. Transport diagnostics, API error messages and CLI output avoid emitting API credentials, signatures or signed request URLs.
- Source regression: 948 passed across two runs (941 excluding the legacy workflow module plus 7 workflow tests separately); focused Stage B + Stage A suite: 38 passed. All exchange-facing tests use fixtures and mock HTTP. No actual Binance credential, private request, Demo WebSocket or test-order request was used; user-PC validation remains pending.

---

# Changelog — v0.57.0

Binance USDⓈ-M Demo Futures Qualification Harness (Stage A) (2026-11-14)

- Adds `testnet-preflight`, a strictly read-only qualification command that validates TESTNET endpoint isolation, REST reachability, server-time synchronization/RTT, active USDT perpetual symbol metadata, signed account access, `canTrade`, single-asset collateral mode, positive available USDT balance, One-way/Hedge position mode, and absence of open positions/standard orders/Algo orders. API keys and secrets are never emitted in CLI output.
- Pins USDⓈ-M Demo REST to `https://demo-fapi.binance.com`; pins Demo public market stream to `wss://demo-fstream.binance.com/market/stream` and Demo private stream to the `/private/ws?listenKey=...&events=...` route. Migrates LIVE private User Data Stream URL construction to the current `/private` route and subscribes to order, account, Algo, trade-lite, account-configuration, margin-call and listen-key-expiry events. Legacy private stream URL paths are removed.
- Adds a local `.env.testnet.example` and operational instructions. Stage A keeps `DIVA_ENABLE_TESTNET_ORDERS=false`; no create/cancel listenKey, account-setting write, WebSocket connection, or order request is performed by preflight.
- Corrects REST User Trades history bounds after Binance's 2026-08-26 USDⓈ-M change: current `GET /fapi/v1/userTrades` historical query window is 3 months, not six months. Default bootstrap is now 90 days and larger explicit time windows fail before making requests.
- Keeps LIVE and Demo endpoint configuration isolated. `testnet-preflight` reports `READY_FOR_TEST_ORDER_VALIDATION` only; trade permission, actual stream connectivity and order behavior are deferred to later qualification stages.
- Full regression: 927 passed from source and 927 passed from clean extraction; focused TESTNET/User Data Stream/backfill suite: 64 passed; compileall and CLI help pass; archive CRC/SHA/sensitive-file audit pass. Tests use local SQLite, fixture metadata and mocked HTTP only. No actual Binance API session, Demo WebSocket session or order was executed. Build host: Linux / Python 3.13.5; project Python pin remains `==3.12.9`.

