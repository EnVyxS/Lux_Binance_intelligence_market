# Release Handoff — v0.51.0

## Baseline and objective

Continues v0.50.0. Objective: aggregate position accounting across independently managed signal lots and deterministic exchange-fill attribution, without enabling unsafe same-side scale-in.

## Delivered

1. Aggregate position-group snapshots by `(symbol, positionSide)`, with exact total quantity, weighted-average entry and per-signal lot allocations.
2. Immutable lot-open timestamp persisted in SQLite with backward-compatible migration.
3. Explicit exact-signal fill attribution and stable FIFO fallback planning for externally attributed aggregate reductions.
4. Per-lot stop/TP quantity allocation plans and coverage validator.
5. Durable mapping of exchange client IDs to signal ownership.
6. Immutable, deduplicated fill evidence from `ORDER_TRADE_UPDATE` and `TRADE_LITE`; unresolved `DIVA*` fills trigger entry halt and can be backfilled when order persistence completes.
7. `runtime-status` adds aggregate positions and fill-attribution counters.

## Verification

- Baseline tests: 838 passed.
- Working-tree full regression: 850 passed.
- Focused accounting/User Data Stream tests: 29 passed.
- Clean-extraction full regression: 850 passed; archive integrity, compileall, CLI help, package version and content audit: PASS. Details: `CLEAN_EXTRACTION_TEST_REPORT_v0.51.0.md`.

## Safety boundary

Same-side multi-signal execution is deliberately **not enabled**. The runtime still rejects multiple managed signals for one `(symbol, positionSide)`. Quantity-scoped STOP/TP execution, sibling-order cancellation after fill, fill-delta reconciliation and multi-lot lifecycle supervision must be completed before scale-in. The immutable fill ledger is evidence only and does not independently alter current position quantity.

PAPER remains default. No exchange requests/orders or Windows target-PC validation were performed.
