# Release Handoff — DIVATrading v0.56.0

## Purpose

Continue from v0.55.0 by connecting SMC V2 qualified signals to global risk and the execution lifecycle in one `auto-trade-runtime` command. The product target remains a fully autonomous multi-pair Binance USDⓈ-M Futures bot.

## Main flow

`AUTO/MANUAL Universe → Public Market Feed Graph → SMC V2 qualification-only → durable signal claim → fresh portfolio/account snapshot → atomic global risk reservation → deterministic/idempotent execution → fill confirmation → quantity-scoped protection → v0.55 multi-lot supervisor / account reconciliation`.

## Operational command

PAPER default:

```powershell
.\.venv\Scripts\python.exe -m divatrading auto-trade-runtime --mode AUTO --max-symbols 8
```

Manual universe example:

```powershell
.\.venv\Scripts\python.exe -m divatrading auto-trade-runtime --mode MANUAL --symbols BTCUSDT,ETHUSDT
```

PAPER simulated fills are enabled by default when execution settings are loaded from `.env`/process environment. Disable them with `DIVA_PAPER_SIMULATE_FILLS=false` to retain intent-only PAPER behavior. The simulator assumes a full fill at the plan price and is not a realistic slippage/queue/partial-fill model.

TESTNET entry path (not exercised in this build) requires the user to explicitly set `DIVA_EXECUTION_MODE=TESTNET`, `DIVA_ENABLE_TESTNET_ORDERS=true`, private credentials, then allow account User Data Stream and REST reconciliation readiness before market dispatch. The same-side TESTNET scale-in gate remains closed. `auto-trade-runtime` rejects LIVE mode in v0.56.0.

## Important safety semantics

- Signal claim is durable before account snapshot I/O; duplicate delivery cannot route twice. Signal age, snapshot age and entry-halt are rechecked after snapshot capture and immediately before risk routing.
- Final quantity/sizing only runs in `MultiPairExecutionCoordinator` on a fresh portfolio snapshot.
- Unknown/external positions and pending open orders are charged conservatively. Unpriced external open orders fail closed.
- Ambiguous submission or runtime errors become `REQUIRES_RECONCILIATION`; no blind POST retry. Non-PAPER dispatcher exceptions halt new entries.
- PAPER remains default; LIVE route remains disabled.

## Verification

See `TEST_REPORT_v0.56.0.md` and `CLEAN_EXTRACTION_TEST_REPORT_v0.56.0.md`. Source regression: 906 passed. Clean extraction: 906 passed. No real Binance TESTNET/LIVE private request or order was performed.

## Next task

`v0.57.0`: controlled Binance USDⓈ-M TESTNET end-to-end qualification, using explicit opt-in and one symbol/one signal first, then multi-lot Algo protection, partial fills, restart recovery, User Data Stream gap recovery, residual quantity protection, kill switch and operator runbook. Same-side scale-in remains disabled until this qualification passes.
