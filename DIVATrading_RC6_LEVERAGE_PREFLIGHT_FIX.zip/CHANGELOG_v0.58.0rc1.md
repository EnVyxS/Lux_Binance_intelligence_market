# DIVATrading v0.58.0rc1 — Persistent Operator Control Plane

## Added
- SQLite-persisted operator configuration for fixed-USDT or equity-percentage per-trade risk.
- Risk manager supports fixed-USDT sizing while retaining the existing portfolio open-risk cap and exchange quantity flooring.
- Telegram Bot API long-polling control process (`telegram-control`) with numeric owner-ID authorization, update-offset deduplication, validation, and token-redacted transport errors.
- Telegram commands for risk, daily loss, loss streak, drawdown, leverage policy, margin preference, pause/resume and kill latch.
- Daily loss and drawdown entry gates based on persisted equity anchors/high-watermark. Equity-based daily loss includes realized/unrealized account equity changes, commissions and funding reflected in account equity; deposits/withdrawals can affect the measure.
- Loss-streak configuration is fail-closed in autonomous runtime until a dedicated exchange-reconciled closed-trade streak ledger is qualified.
- BOT_ONLY account isolation gate compares exchange positions against managed symbol/position-side aggregate quantities and checks exact ownership of open standard/Algo orders. Unknown exposure halts entries; it does not close external positions.
- Added deterministic leverage feasibility function that chooses the lowest leverage satisfying supplied verified liquidation-buffer estimates and available margin. It never increases quantity/notional to satisfy exchange minimums.

## Runtime integration
- `auto-trade-runtime` reads persisted risk settings at startup and refreshes them before each candidate, so Telegram risk updates apply to subsequent setups.
- Pause/kill blocks new signal dispatch; account runtime and existing-position supervision remain running.
- For non-PAPER execution, BOT_ONLY reconciliation is checked after account readiness and before market dispatch.
- Telegram runs as a separate local process and shares the same SQLite database.

## Not enabled / remaining gates
- Autonomous LIVE order routing remains explicitly blocked in `command_autonomous_runtime`.
- Telegram leverage/margin settings are persisted policy preferences; live leverage bracket retrieval, exchange margin-mode mutation and runtime allocation are not yet wired end-to-end. The feasibility function is a tested core, not a claim of complete exchange integration.
- Daily loss/drawdown use account equity anchors; loss streak deliberately blocks entries until exact lifecycle-based streak accounting is implemented.
- No real LIVE credentials, private REST, User Data Stream, order, Algo order, or LIVE position lifecycle were exercised.
- No claim of LIVE production readiness is made by this release candidate.
