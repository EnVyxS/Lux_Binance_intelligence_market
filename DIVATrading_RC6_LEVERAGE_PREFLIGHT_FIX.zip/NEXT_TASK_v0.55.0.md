# Next Task after v0.55.0 — Autonomous SMC-to-Entry Dispatcher

## Primary objective

Connect the existing read-only multi-pair market runtime and SMC V2 planner to the execution coordinator so a fully qualified SMC TradePlan can autonomously proceed through risk approval, deterministic order submission, fill confirmation and protective-order attachment.

## Required implementation
1. Add a long-running dispatcher consuming SMC V2 qualified TradePlans from the market runtime; do not leave this as a log-only callback.
2. Fetch/consume a fresh account and portfolio snapshot immediately before sizing and reservation.
3. Deduplicate signals and persist a durable dispatch intent before any network request.
4. Normalize quantity/price against current symbol filters and confirm position mode.
5. Use the existing atomic global portfolio-risk reservation; fail closed on stale account state, entry halt, unknown/universe symbols or conflicting position state.
6. Submit the entry idempotently and reconcile ambiguous responses by deterministic client order ID; never blindly retry POST.
7. Handle NEW, PARTIALLY_FILLED, FILLED, CANCELED, EXPIRED and rejected entries, including canceling the unfilled remainder where required.
8. Confirm actual exchange fill quantity and weighted entry before attaching quantity-scoped STOP/TP for the attributed lot.
9. Hand the protected lot to the v0.55 multi-lot supervisor and account reconciliation.
10. Add end-to-end local integration tests across market runtime -> planner -> dispatcher -> risk -> fake exchange -> fill -> protection -> supervisor.

## Safety and milestones
- PAPER remains default and should support a deterministic simulated execution loop.
- TESTNET/LIVE retain explicit opt-in and fresh User Data Stream + REST reconciliation gates.
- Same-side TESTNET/LIVE scale-in remains blocked until the separate TESTNET qualification proves multi-lot Algo protection semantics.
- v0.57.0 performs controlled Binance USDⓈ-M Futures TESTNET qualification; v0.58.0 validates Windows 10 / Python 3.12.9 / 8 GB deployment.
- Do not claim exchange connectivity or order validation based on mocks.
