# Build State v0.46.0 — User Data Stream & Account Reconciliation

## Release

- Version: `0.46.0`
- Package: `DIVATrading_BinanceBot_UserDataStreamReconciliation_0.46.0.zip`
- Scope: Binance USDⓈ-M User Data Stream supervisor, durable event ingestion/projections, account reconciliation, event-watermark freshness gate, and TESTNET/LIVE readiness enforcement.
- Default execution mode remains PAPER.

## Implemented

- REST listenKey create / keepalive / close methods using API-key header without HMAC signing.
- Current LIVE WebSocket private path and TESTNET stream endpoint configuration.
- 25-minute keepalive, 23-hour connection rotation, bounded exponential reconnect, per-connection listen-key cleanup, and graceful stop.
- Event parsing and deduplication for ACCOUNT_UPDATE, ORDER_TRADE_UPDATE, ALGO_UPDATE, TRADE_LITE and listenKeyExpired.
- Atomic SQLite event retention and partial balance/position/order projections.
- Stream state and reconciliation state persistence.
- Atomic stream event watermark validation; any fresh exchange account/order/trade event invalidates READY.
- Exchange-vs-ledger reconciliation for positions, STOP/TP protection, pending intents, orphan DIVA orders, and risk reservations.
- Entry readiness checks on coordinator and direct non-PAPER ExecutionService submission.
- CLI `account-runtime` for private account stream and reconciliation/recovery.

## Deliberate scope boundary

This is not the complete autonomous execution lifecycle. It does not yet implement automatic reservation release after verified flat, full partial-TP/breakeven/trailing/final-exit management, automated mismatch repair/flattening, or production dashboard/Telegram. No real exchange REST or WebSocket session and no order was executed in this build.

## Environment

- Build/test: Linux, Python 3.13.5.
- Target environment: Windows 10, Python 3.12.9 64-bit, 8 GB RAM — not yet validated.
- Project's exact `requires-python ==3.12.9` pin was preserved.
- No API credentials, `.env`, runtime database, or user data are included in the release package.
