@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo DIVATrading Binance Bot - v0.59.0rc6 Installer
echo Required: Python 3.12.9 64-bit
echo Temporary workspace: %CD%\.diva_temp
echo ==================================================
if not exist ".diva_temp" mkdir ".diva_temp"
if not exist ".diva_temp\pip-cache" mkdir ".diva_temp\pip-cache"
set "TEMP=%CD%\.diva_temp"
set "TMP=%CD%\.diva_temp"
set "TMPDIR=%CD%\.diva_temp"
set "PIP_CACHE_DIR=%CD%\.diva_temp\pip-cache"
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher 'py' was not found.
  echo Install Python 3.12.9 64-bit, then run this installer again.
  exit /b 1
)
py -3.12 -c "import sys,struct; print(sys.version); assert sys.version_info[:3] == (3,12,9) and struct.calcsize('P')*8 == 64, 'Python 3.12.9 64-bit is required'"
if errorlevel 1 (
  echo ERROR: Python 3.12.9 64-bit was not detected.
  exit /b 1
)
if exist ".venv" rmdir /s /q ".venv"
py -3.12 -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -e ".[dev]"
if errorlevel 1 exit /b 1
if not exist ".env" copy ".env.example" ".env" >nul
if not exist "data" mkdir "data"
if not exist "logs" mkdir "logs"
echo.
echo Installation completed.
echo Next: TEST_WINDOWS.bat, then RUN_RC6_DIAGNOSTICS_WINDOWS.bat.
exit /b 0
