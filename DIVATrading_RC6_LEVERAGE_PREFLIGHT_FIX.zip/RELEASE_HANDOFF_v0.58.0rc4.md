# Release Handoff — DIVATrading v0.58.0rc4

## Baseline
Built from the v0.58.0rc3 ZIP. Preserves SMC V2, multi-lot lifecycle, autonomous dispatcher, Telegram SIGNAL_ONLY, Kronos-mini shadow forecast, persistent operator controls, BOT_ONLY account policy, and protective-order recovery lineage.

## Added
- Typed parser for account-specific USDⓈ-M leverage bracket tiers, including notional floor/cap, initial leverage, maintenance margin ratio and cumulative adjustment.
- Conservative maintenance-margin estimate and margin feasibility result. It explicitly does not estimate liquidation price.
- Maker/taker commission parser and round-trip fee reserve with configurable safety multiplier; separate slippage/funding reserves.
- LIVE read-only preflight now checks leverage tiers, symbol commission rates, and per-symbol `symbolConfig` (margin type and current leverage).
- Durable SQLite completed-lifecycle PnL ledger with idempotent lifecycle IDs, fees, funding, Jakarta trading-day key, consecutive loss streak, and reconciliation fail-closed state.

## Safety invariants
- No increase in risk-sized quantity to meet exchange minimum notional.
- No leverage/margin-mode writes, no order placement/cancellation, no LIVE route enablement.
- Maintenance margin is an estimate; no liquidation-price guarantee.
- Completed-trade ledger is not yet connected to every production lifecycle close event. Its reconciliation gate defaults CLOSED. Runtime streak guard remains fail-closed rather than assuming zero losses.
- Dynamic leverage/fee feasibility primitives are not yet injected into the live order planner; RC4 preflight gathers the account inputs, but end-to-end runtime sizing integration remains a required next stage.
- Daily Jakarta ledger grouping exists; equity-anchor normalization for deposits/withdrawals and complete income-history reconciliation remains outstanding. Do not treat this ledger as a complete account PnL source until that integration is qualified.
- Telegram controls persist settings, but runtime refresh of every control against all active workers remains a qualification item.
- No `.env`, API key, API secret, or account data is included.

## Verification
- Full source regression: 1,024 passed.
- Full clean-extraction regression: 1,024 passed; 460 manifest entries verified; ZIP CRC passed.
- Targeted RC4 + existing control/preflight suites: 20 passed.
- `compileall`: passed.
- Package import/version and CLI help: passed.
- Clean extraction regression and Windows 10 / Python 3.12.9 qualification: pending.
- No actual Binance API/account request was made during build tests; no LIVE or TESTNET order was sent.

## Next
Complete runtime integration: feed account-specific tiers, commission and available margin into risk sizing; connect completed lifecycle accounting to REST trade/income reconciliation; normalize daily PnL around deposits/withdrawals; apply persisted Telegram controls to running workers; then qualify Windows and controlled exchange lifecycle before any LIVE authorization.
