# Clean Extraction Test Report — v0.57.0D2

- Final release archive: `DIVATrading_BinanceBot_PositionAwareProtectiveRecovery_0.57.0D2.zip`.
- Archive members extracted: **389**.
- ZIP CRC: PASS.
- Full regression executed from the actual extracted release archive: **972 passed** in 19.93 seconds (Linux / Python 3.13.5).
- No failed or skipped tests.
- Sensitive-file audit: no `.env`, `.venv`, API credential, local DB, log, backup, `__pycache__`, `.pyc`, or `.diva_temp` was included.
- Exact D2 archive has not yet been full-regression-tested on Windows 10 / Python 3.12.9.
