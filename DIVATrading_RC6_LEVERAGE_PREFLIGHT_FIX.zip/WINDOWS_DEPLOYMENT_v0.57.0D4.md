# Windows Deployment Notes — v0.57.0D4

## Target
- Windows 10 x64.
- Exact Python 3.12.9 x64 (enforced by project metadata and installer).
- Keep project, venv, logs, data, TEMP/TMP and test artifacts on a drive with sufficient free space.

## Offline qualification
1. Extract the exact D4 ZIP into a new folder; do not overwrite earlier releases.
2. Copy `.env` locally from a trusted backup only when needed; never put `.env` in the ZIP or send it through chat.
3. Run `INSTALL_WINDOWS.bat`.
4. Run `TEST_WINDOWS.bat` and retain the complete output.
5. Confirm `pip check` and CLI help.
6. Keep all TESTNET order, Stage C, order-test, protection-recovery and LIVE flags false.

## D4-specific behavior
- A newly connected private User Data Stream forces `userTrades` REST backfill even if the periodic interval has not elapsed.
- If REST backfill fails, entry remains halted and retry is pending. Only a reconciler-owned transient failure halt may clear after a successful retry and clean sequential account snapshot; a manual halt remains in place.
- A triggered Algo's generated child MARKET order is linked to its signal lot only after exact REST identity validation.
- These flows are mock-tested in this build. Do not interpret them as real Binance Demo acceptance.

## Qualification boundary
D4 was built/tested on Linux / Python 3.13.5 with project metadata pinned to Python `==3.12.9`. Exact D4 Windows 10 / Python 3.12.9 qualification remains outstanding. No real Binance Demo/LIVE account or order operation was performed.
