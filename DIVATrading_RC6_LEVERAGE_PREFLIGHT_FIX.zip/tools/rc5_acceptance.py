"""Local, read-only deployment diagnostic for the DIVATrading RC5 candidate.

Does NOT place orders, access private endpoints, change account configuration,
print API credentials, or assert LIVE qualification. Run in the target venv.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import re
import struct
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]


def _env_flags() -> dict[str, object]:
    envfile = PROJECT / ".env"
    if not envfile.is_file():
        return {"env_file_present": False}
    wanted = {"DIVA_EXECUTION_MODE", "DIVA_LIVE_TRADING_ENABLED", "DIVA_ENABLE_TESTNET_ORDERS",
              "DIVA_ENABLE_TESTNET_STAGE_C", "DIVA_ENFORCE_ENTRY_QUOTE_GUARD",
              "DIVA_REQUIRE_ACCOUNT_READINESS", "DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT"}
    fields = {}
    for line in envfile.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip() or line.lstrip().startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        if k in wanted:
            fields[k] = v.strip().lower()
    # No credentials, tokens, endpoint IDs, or free-text configuration values
    # are ever returned. Only these explicit well-defined safety flags.
    return {"env_file_present": True, "safety_flags": fields}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="logs/rc5_local_acceptance.json")
    parser.add_argument("--skip-tests", action="store_true", help="Only check environment; does not assert tests passed")
    args = parser.parse_args()

    py_ok = sys.version_info[:3] == (3, 12, 9) and struct.calcsize("P") * 8 == 64
    os_ok = platform.system() == "Windows"
    required = ["pyproject.toml", "src/divatrading/cli.py", "src/divatrading/execution/service.py",
                "src/divatrading/trading/post_fill_risk.py", "src/divatrading/trading/entry_quote_guard.py",
                "tests/test_rc4_postfill_and_quote_guard.py", "tests/test_rc5_smc_contract.py", "tests/test_rc5_live_first_policy.py", "START_LIVE_FIRST_WINDOWS.bat", "TEST_WINDOWS.bat", ".env.example"]
    absent = [f for f in required if not (PROJECT / f).is_file()]
    tests = {"status": "NOT_RUN", "returncode": None, "summary": None}
    if not args.skip_tests:
        process = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=PROJECT,
                                 capture_output=True, text=True, timeout=600, check=False)
        output = (process.stdout + "\n" + process.stderr)[-4000:]
        summary = re.search(r"(?m)^.*\d+ passed(?:, \d+ .*?)? in [\d.]+s.*$", output)
        tests = {"status": "PASS" if process.returncode == 0 else "FAILED",
                 "returncode": process.returncode, "summary": summary.group(0) if summary else None}
    local = bool(py_ok and os_ok and not absent and tests["status"] == "PASS")
    report = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "candidate": "0.59.0rc5", "checks_are_read_only": True,
        "python_version": platform.python_version(), "python_3129_x64": py_ok,
        "windows_target": os_ok, "missing_project_files": absent,
        "local_tests": tests, "local_acceptance_passed": local,
        "configuration": _env_flags(),
        "live_qualified": False,
        "live_blockers": [
            "LIVE production fill/STOP/TP/partial/reconnect/restart acceptance has not been observed (operator will validate)",
            "Private LIVE account read-only preflight not performed by this offline diagnostic",
            "Strategy out-of-sample and trade-cost robustness evidence not supplied",
            "Windows unattended restart, watchdog, rollback and operator kill-switch acceptance pending",
            "LIVE-first operator activation is possible but unverified and carries real-money risk",
        ],
        "explanation": "Passing offline diagnostics never grants live order authorization.",
    }
    out = (PROJECT / args.output).resolve()
    if PROJECT not in out.parents:
        parser.error("output must remain inside the project directory")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Diagnostic: {out.relative_to(PROJECT)}")
    print(f"Local checks: {'PASS' if local else 'INCOMPLETE'}; LIVE qualified: NO")
    return 0 if local else 1


if __name__ == "__main__":
    raise SystemExit(main())
