# Test Report — v0.57.0C

- Full suite: **952 passed** (`python -m pytest -q --disable-warnings --maxfail=1`).
- `python -m compileall -q src tests`: PASS.
- CLI help: `auto-trade-runtime`, `testnet-preflight`, `testnet-order-test`: PASS.
- New regression tests: independent Stage C opt-in is required; environment default remains fail-closed.
- No real Binance API request, Demo order, matching-engine submission, fill, or protection cycle was executed.
- Build host: Linux; Python runtime in this container is 3.13.5. Target Windows 10 / Python 3.12.9 remains untested.
