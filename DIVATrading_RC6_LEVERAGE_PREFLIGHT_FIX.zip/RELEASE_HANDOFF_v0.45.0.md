# DIVATrading Release Handoff — v0.45.0

## Release identity

- ZIP: `DIVATrading_BinanceBot_AtomicPortfolioRisk_0.45.0.zip`
- Base: v0.44.0 Global Account State
- Scope: persistent, atomic portfolio-risk reservations wired into multi-pair signal routing.

## What changed

- SQLite reservations are keyed by `signal_id` and admitted under `BEGIN IMMEDIATE`.
- The gate sums exchange-reported open risk, all active reservations and requested plan risk using exact Decimal arithmetic.
- The gate includes exchange-observed position count plus locally reserved entries.
- Per-symbol notional caps are checked atomically using exchange symbol exposure plus same-symbol reservations.
- Coordinator reserves before calling `ExecutionService`; failed admission prevents execution.
- PAPER mode releases after recording the paper-only route. TESTNET/LIVE pending/protected and ambiguous submissions remain reserved until confirmed release.
- Added explicit release API for reconciliation/position-management code to use later. Duplicate active reservations are blocked at the coordinator until reconciliation, avoiding unsafe resubmission after a crash window.
- TESTNET/LIVE `ExecutionService` enforces a matching ACTIVE reservation before accepting any submission, preventing direct service calls from bypassing this gate.

## Verification

- Full regression: 762 passed.
- Compileall and root CLI help: PASS.
- Clean extraction regression: included in sidecar report.
- No Binance private request or order was performed.

## Known limitations

- v0.44's account-level open-risk figure is gross absolute notional, not verified stop-distance risk; conservative and potentially restrictive.
- Exchange exposure and retained local reservations may double-count an already-filled position until event/reconciliation lifecycle is implemented. This includes global risk, max-position count and per-symbol notional.
- Local transactions protect only workers sharing the same SQLite file; manual trading/other bots are outside this lock.
- Account snapshot freshness is not yet enforced.
- TESTNET/LIVE risk reservations require a verified release after a flat/terminal exchange state; that automatic reconciler is not included yet.

## Next implementation target

Implement Binance USD-M Futures User Data Stream lifecycle (listen-key create/keepalive/close, websocket reconnect, normalized account/order events), durable event ingestion, and REST reconciliation after disconnect/restart. Add account-state freshness gating before order submission.

Execution remains PAPER by default. Windows 10/Python 3.12.9/8 GB remains unverified.
