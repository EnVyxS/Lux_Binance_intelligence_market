@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
if not exist "logs" mkdir "logs"
REM Offline: no private Binance API request and no exchange order sent.
REM Force PAPER and dummy credentials to prevent tests from using LIVE keys.
set "DIVA_EXECUTION_MODE=PAPER"
set "DIVA_LIVE_TRADING_ENABLED=false"
set "DIVA_ENABLE_TESTNET_ORDERS=false"
set "BINANCE_API_KEY=OFFLINE_TEST_DUMMY_KEY"
set "BINANCE_API_SECRET=OFFLINE_TEST_DUMMY_SECRET"
.venv\Scripts\python.exe tools\rc6_acceptance.py --output logs\rc6_local_acceptance.json
if errorlevel 1 (
  echo Incomplete checks. Review logs\rc6_local_acceptance.json.
  exit /b 1
)
echo Offline checks pass. This is not proof of Binance LIVE execution.
exit /b 0
