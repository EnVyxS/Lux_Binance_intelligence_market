# v0.48.0 — Managed Position Lifecycle Execution Adapter (2026-11-13)

- Adds Binance USDⓈ-M partial-close execution with deterministic client IDs, exchange lot/minimum quantity validation, One-way `reduceOnly` handling and Hedge Mode `positionSide` handling.
- Adds conditional Algo STOP create/verify/cancel replacement, with strict DIVA-owned stop-ID validation and no unsafe close-all request fields.
- Adds REST fill/position confirmation; POST acknowledgement alone never advances local lifecycle state.
- Adds event-triggered lifecycle reduction for ORDER_TRADE_UPDATE, TRADE_LITE, ALGO_UPDATE and ACCOUNT_UPDATE.
- Adds verified-flat finalization with linked-order cleanup, second position check and verified SQLite risk-reservation release.
- Adds reconnect/startup recovery for pending actions and flat managed positions. `account-runtime` CLI wires the reducer automatically in explicitly enabled TESTNET/LIVE modes. No blind POST retry; recovery queries deterministic IDs.
- Adds fail-closed handling for unowned stop IDs, post-cleanup REST errors and position changes during STOP replacement.
- Full regression: 824 passed; focused lifecycle execution: 27 passed; compileall and CLI help pass.
- No actual TESTNET/LIVE API, WebSocket or order test. PAPER default; Windows target not tested.
