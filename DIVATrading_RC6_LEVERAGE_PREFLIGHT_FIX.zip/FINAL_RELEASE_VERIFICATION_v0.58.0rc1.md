# Final Release Verification — v0.58.0rc1

## Verified
- Source regression: 995 tests passed.
- Clean extraction regression: 995 tests passed.
- ZIP CRC: passed; 417 members.
- Source manifest: 416 entries; all paths, sizes and SHA-256 digests verified.
- Python compileall passed.
- CLI help checks passed for root, Telegram control, and autonomous runtime.
- Wheel build completed; package metadata version is 0.58.0rc1 and project interpreter pin remains ==3.12.9.
- New control-plane tests cover SQLite persistence across store instances, fixed/percent risk validation, daily/streak/drawdown gates, lowest feasible leverage selection, BOT_ONLY external position/order detection, same-symbol quantity mismatch, exact owned state, Telegram owner authorization, and kill latch.
- No `.env` or live secret file is included in the release archive.

## Explicitly not verified
- Windows 10 / Python 3.12.9 installation and regression for this exact release.
- Real Telegram Bot API connection/token correctness.
- Real Binance LIVE account preflight or private API access.
- Actual exchange leverage-bracket retrieval, leverage setting or margin-mode mutation.
- Exchange-reconciled loss-streak accounting.
- Actual LIVE entry/fill/STOP/TP/partial exit/restart/stream-gap/flat cycle.

## Release disposition
`0.58.0rc1` is a software release candidate with persistent operator controls and safety gates. It is **not authorized or represented as LIVE-ready**. Autonomous LIVE routing remains explicitly blocked pending the items in `NEXT_TASK_v0.58.0rc1.md`.
