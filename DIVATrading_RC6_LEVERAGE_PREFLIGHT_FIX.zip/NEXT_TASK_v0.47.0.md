# Next Task

v0.48.0: connect durable position lifecycle actions to a Binance USDⓈ-M execution adapter. Implement reduce-only partial close and protective algo stop replacement with deterministic client IDs, ambiguity-safe reconciliation, confirmed fill/state reducer, verified-flat risk release, and restart recovery. Do not mark lifecycle state complete before exchange confirmation. PAPER remains default; no LIVE enablement.
