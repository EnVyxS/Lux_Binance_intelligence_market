# Build State v0.51.0

Baseline: v0.50.0 Runtime Reliability.

## Verification

- Working-tree regression: 850 passed.
- Fresh-extraction regression: 850 passed.
- Compileall: PASS. CLI help and package version 0.51.0: PASS.
- Archive integrity and content audit: PASS.

## Implemented

- New `execution/position_accounting.py`: position-lot models, `(symbol, positionSide)` aggregation, exact weighted-average entry, deterministic FIFO close-allocation planner, exact-signal close-fill allocation, per-signal protection allocation plan and coverage validation.
- Ledger migration adds immutable `managed_positions.opened_at_utc`; legacy rows are backfilled from previous update time.
- New `execution_client_order_links` table records durable ownership of exchange client IDs across entry/protective orders and lifecycle market actions. Client ID owner conflicts fail closed.
- New `position_fill_allocations` table records unique exchange fills from User Data Stream. `ORDER_TRADE_UPDATE` and `TRADE_LITE` duplicates are deduplicated by `(symbol, trade ID)`.
- Fills are attributed to signal IDs by durable client-order ownership. An unrecognized internal `DIVA*` fill latches the new-entry halt; if the REST owner is persisted later, fill evidence is backfilled but the halt remains latched.
- Read-only aggregate API `ExecutionLedger.list_managed_position_groups()` and fill attribution counters. `runtime-status` includes both.

## Intentionally not enabled

- Multiple open signal IDs on one `(symbol, positionSide)` remain blocked by the existing position supervisor.
- `closePosition=true` protection semantics and the per-signal adapter's exchange-quantity assertion have not yet been replaced with lot-scoped quantity protection.
- Fill evidence is not applied directly to local quantity. A unified REST/User Data Stream fill-reconciliation transaction is still required.
- No automatic SMC TradePlan -> risk reservation -> exchange entry dispatcher integration in this release.
- No TESTNET/LIVE API calls, orders, or Windows target-PC validation.

## Project constraints

- PAPER remains default.
- Target environment remains Windows 10 / Python 3.12.9 / 8 GB RAM. This build environment is Linux / Python 3.13.5. The `requires-python ==3.12.9` pin is unchanged.
