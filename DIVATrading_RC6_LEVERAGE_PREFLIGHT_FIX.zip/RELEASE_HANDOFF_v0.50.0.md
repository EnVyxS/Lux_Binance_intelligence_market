# Release Handoff — v0.50.0

## Baseline and objective
Continues v0.49.0. Focus: runtime reliability, reconciliation policy and operator visibility.

## Delivered
1. Cross-platform non-blocking process lock. `account-runtime` and `market-runtime` each acquire their own lock under configured log directory; second process of the same runtime exits through normal error handling.
2. Discrepancy classification with fail-closed unknown handling. Manual/unmanaged positions are operator-only; no automatic cancellation/closure is performed.
3. Reconciliation detail now records policy metadata. A racing User Data Stream event invalidates that snapshot and triggers next-cycle retry without latching the global entry halt.
4. Heartbeat-based stale-worker watchdog primitive.
5. `divatrading runtime-status` prints a read-only JSON operational snapshot from local ledger.

## Verify
- 838/838 tests pass.
- Compileall and CLI help pass.
- Clean extracted archive test passes (report alongside release).

## Remaining
Telegram alerts/operator controls, embedded dashboard, runtime watchdog wiring/automatic restart, aggregate same-symbol position accounting, end-to-end autonomous SMC-to-entry dispatcher, Windows validation, and real Binance TESTNET integration.

## Safety
PAPER default. No private API calls or exchange orders were sent. Do not enable LIVE based solely on this release.
