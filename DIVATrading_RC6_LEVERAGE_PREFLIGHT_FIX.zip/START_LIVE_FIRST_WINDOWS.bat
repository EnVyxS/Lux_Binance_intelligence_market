@echo off
setlocal
REM Compatibility alias: RC5 launcher risk caps are replaced in RC6.
call "%~dp0START_LIVE_WINDOWS.bat"
exit /b %errorlevel%
