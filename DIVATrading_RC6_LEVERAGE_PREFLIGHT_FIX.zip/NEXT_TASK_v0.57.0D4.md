# Next Task — After v0.57.0D4

## Stage E — Integrated execution acceptance

1. First qualify the exact D4 release archive on Windows 10 / Python 3.12.9: install in a clean directory, full regression, package/CLI checks, and log/credential redaction audit. D4 Linux mocks do not qualify the Windows runtime.
2. Before any exchange writes, use a fresh Demo account preflight and verify clean account state, position mode, available balance and protection permissions. Credentials remain local only.
3. When the operator explicitly resumes exchange testing, perform one supervised BTCUSDT (or one chosen symbol) Demo cycle with the smallest approved risk: actual entry → fill/weighted price confirmation → paired quantity-scoped STOP/TP verification → one controlled protective close/partial outcome → REST userTrades reconciliation → restart/stream-gap replay → verified flat and risk release.
4. Record exact request/response IDs and sanitized exchange evidence; never log API secret/signature. Keep the test bounded to one symbol and no unattended operation.
5. Only after the single-pair cycle succeeds, separately qualify same-side multi-lot aggregate STOP/TP behavior and Hedge Mode. Do not infer this from mocks.
6. Complete account-runtime reconnect, ambiguous order/cancel recovery, kill-switch and manual operator intervention drills.
7. After Stage E acceptance, prepare v0.58 Windows packaging/resource/startup/shutdown/backup runbook.

## Non-negotiable gates

- PAPER remains default. All TESTNET order/Stage C/order-test/protection-recovery flags remain false unless an explicit supervised Demo acceptance is being executed.
- LIVE remains disabled and unauthorized.
- Same-side TESTNET/LIVE scale-in remains blocked pending dedicated exchange evidence.
- Never blindly retry ambiguous order/Algo POST or cancel.
- Never release risk before exchange-confirmed flat/terminal reconciliation.
- User has deliberately deferred actual Stage C entry testing; no PC action is required for the completed D4 software checkpoint.
