# Test Report v0.48.0

## Automated tests

- Full regression suite: **824 passed**.
- Focused position lifecycle execution suite: **27 passed**.
- `python -m compileall -q src`: **PASS**.
- `python -m divatrading --help`: **PASS**.

## Added coverage

- One-way partial TP uses `reduceOnly=true`; Hedge Mode omits `reduceOnly` and carries the correct `positionSide`.
- Action idempotency prevents duplicate partial-close POSTs.
- Partial and full fills are confirmed through REST; local quantity changes only after exchange position reconciliation.
- STOP replacement submits and confirms new Algo STOP before canceling prior STOP. A post-submit position recheck detects a concurrently triggered prior stop; flat positions are finalized, while non-flat quantity mismatches preserve both protections and halt entries.
- One-way/Hedge close-all parameters omit unsupported/incompatible request fields.
- Triggered/non-active STOP and ambiguous POST/query outcomes preserve protection state and halt entries.
- Subsequent trailing stop replacement cancels the latest managed STOP, not the original STOP.
- Unowned/manual algo client IDs cannot be supplied for cancellation.
- Finalization releases risk only after REST confirms flat position, linked orders absent and a second flat-position query.
- Post-cleanup REST verification timeout halts entries and leaves reservation active.
- Startup recovery finalizes exchange-flat managed positions and leaves open positions/reservations untouched; account runtime and CLI trigger it once per stream connection.

## Scope of test evidence

All exchange behavior is exercised with deterministic local fakes/mocks. No actual Binance TESTNET/LIVE API request, WebSocket session, order placement, cancel, or position read was performed. This is not evidence of live exchange readiness.

## Environment

- Linux, Python 3.13.5.
- Target Windows 10 / Python 3.12.9 / 8 GB remains unverified.
