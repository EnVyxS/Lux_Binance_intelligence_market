# v0.49.0 Checkpoint — What Comes Next

Next: **v0.50.0 Runtime Reliability, Remediation and Operator Visibility**.

1. Classify reconciliation discrepancies into automatically recoverable, operator-only and hard-stop categories. Never auto-cancel manual orders or close unmanaged positions.
2. Add process-wide single-instance locking for account-runtime and market-runtime.
3. Add watchdog / stale-worker detection and explicit shutdown recovery.
4. Expose current positions, risk reservations, pending lifecycle actions, per-symbol Mark Price health and entry-halt reason through a local read-only status/dashboard.
5. Add Telegram alerts with delivery idempotency and allow-listed operator actions. Destructive position operations still require explicit confirmation.
6. Test process restart, reconnect, lock contention, duplicate events, stale feeds, reconciliation drift and operator acknowledgement.

Then build aggregate same-symbol position accounting and connect the SMC signal pipeline to the automatic entry dispatcher before considering Windows deployment.
