@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
echo ==================================================
echo DIVATrading - Binance Historical Kline REST
 echo Supported intervals: 1m, 5m, 15m
 echo Timestamps must be UTC Unix milliseconds.
echo ==================================================
set /p SYMBOL=Exact contract symbol (example BTCUSDT): 
set /p INTERVAL=Interval (1m/5m/15m): 
set /p START_MS=Start time UTC Unix ms (inclusive): 
set /p END_MS=End time UTC Unix ms (inclusive): 
.venv\Scripts\python.exe -m divatrading klines-history --symbol "%SYMBOL%" --interval "%INTERVAL%" --start-time-ms "%START_MS%" --end-time-ms "%END_MS%"
exit /b %errorlevel%
