# Windows Deployment — DIVATrading v0.58.0rc2

## Target platform

- Windows 10 x64.
- Python **3.12.9 x64** exactly.
- Start with one manually selected symbol (BTCUSDT) and one runtime process.
- Kronos optional profile: CPU-only, 512 M5 context bars (bounded by currently available candles), minimum 64 candles, 6-step horizon.

## Install core application

1. Extract the release ZIP to a stable path (prefer a drive with adequate free space).
2. Run `INSTALL_WINDOWS.bat`.
3. Run `TEST_WINDOWS.bat`; require a successful complete test run on the target PC before using the runtime.
4. Copy `.env.example` to `.env` and set the local Telegram token and owner ID only if Telegram publication/control is needed. Do not put keys/tokens in chat, screenshots or support logs.

## Kronos is separately installed

Kronos weights and source are not included in the ZIP. After core tests pass, run `INSTALL_KRONOS_WINDOWS.bat`. This downloads CPU PyTorch dependencies plus the current pinned-by-commit official repository source and pinned Hugging Face model/tokenizer revisions. The installer records all revisions and archive hash in `.kronos/kronos_install_manifest.json`.

The model download needs internet and may take several hundred MB. Do not start a market runtime while installing/updating the model. The normal application can run without this optional dependency.

Verify:

```powershell
.venv\Scripts\python.exe -m divatrading kronos-status
.venv\Scripts\python.exe -m divatrading kronos-forecast --symbol BTCUSDT
```

Do not treat a successful installation as proof of forecast quality. Review first forecasts and measure inference latency/RAM on the target PC.

## Telegram signal-only runtime

Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_OWNER_ID` in `.env`. The owner ID is also the signal recipient in this first release. Start with:

```powershell
RUN_SIGNAL_RUNTIME_WINDOWS.bat
```

This runs read-only public market feeds for BTCUSDT and publishes only qualified SMC signals. `--kronos-shadow` adds Kronos M5 forecasts to the chart if installed. If not installed or unavailable, SMC signal flow continues and the chart states that status. No Binance key is required for this read-only flow.

For SMC-only Telegram pictures while Kronos remains uninstalled:

```powershell
RUN_SIGNAL_RUNTIME_NO_KRONOS_WINDOWS.bat
```

The signal publisher makes outbound `sendPhoto` requests only. It does not poll updates. `telegram-control` is the inbound owner-only operator process; start it using `RUN_TELEGRAM_CONTROL_WINDOWS.bat` in a separate terminal. Do not launch two instances of `telegram-control` using the same bot token.

## Useful commands

```powershell
.venv\Scripts\python.exe -m divatrading kronos-status
.venv\Scripts\python.exe -m divatrading signal-history --limit 50
.venv\Scripts\python.exe -m divatrading kronos-evaluate --forecast-id FORECAST_ID
```

## Safety boundary

- `market-runtime` is read-only and `SIGNAL_ONLY`; it does not send Binance orders.
- Kronos is optional shadow analysis. It cannot gate SMC or send orders.
- The autonomous LIVE route remains disabled in this release candidate.
- No API secret or model weights belong in the ZIP.
- The build host is Linux/Python 3.13.5; the Windows 10/Python 3.12.9 deployment is still a user-side qualification gate.
