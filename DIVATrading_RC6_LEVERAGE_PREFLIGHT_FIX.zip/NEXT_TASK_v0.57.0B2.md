# Next Task — After v0.57.0B2

1. User replaces the previous v0.57.0B project folder with this B2 hotfix and keeps their local `.env` out of the ZIP/chat.
2. Run `testnet-preflight --symbols BTCUSDT` with the rotated Demo credentials.
3. Review sanitized JSON. Expected result after the patch: `READY_FOR_TEST_ORDER_VALIDATION`, `can_trade: true`, and `multi_assets_mode: false`. If Binance reports `canTrade=false` or Multi-Assets enabled, the preflight must remain blocked.
4. Only after a clean preflight, proceed with the separately gated Stage B `/fapi/v1/order/test` validation (`DIVA_ENABLE_TESTNET_ORDER_TEST=true` and CLI `--confirm-test-order`). Keep `DIVA_ENABLE_TESTNET_ORDERS=false` and LIVE disabled.
5. Stage C controlled actual Demo entry remains a separate future stage requiring explicit opt-in, bounded size/risk, exchange fill confirmation, and protection verification.
