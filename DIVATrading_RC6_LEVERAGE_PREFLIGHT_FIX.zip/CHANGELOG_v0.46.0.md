# Changelog v0.46.0 — User Data Stream & Account Reconciliation

- Adds USDⓈ-M listenKey create, keepalive and close methods using API-key authorization without HMAC signing.
- Adds LIVE private WebSocket endpoint and TESTNET endpoint configuration, 25-minute listenKey keepalive, 23-hour connection rotation, bounded reconnect/backoff, fresh listenKey per reconnect, and best-effort key cleanup.
- Adds durable, idempotent event capture for ACCOUNT_UPDATE, ORDER_TRADE_UPDATE, ALGO_UPDATE, TRADE_LITE and listenKeyExpired; projects partial account balances, positions, standard orders and conditional/algo orders.
- Adds account reconciliation against sequential exchange REST snapshots, including local position mapping, standard/algo protective STOP/TP orders, pending intents, DIVA orphan orders and active risk reservations.
- Adds event-watermark freshness validation. New account/order/trade events invalidate READY; stream events racing a REST capture or reconciliation commit fail closed.
- Adds non-PAPER account-readiness gate to both coordinator routing and direct TESTNET/LIVE ExecutionService submission.
- Adds `account-runtime` CLI to maintain the private stream and periodic reconciliation; it may recover/protect exchange-confirmed pending fills but does not generate new entry signals.
- Tightens protective-order validation to require the correct closing side (SELL for LONG, BUY for SHORT).
- Full regression: 779 passed; focused account-stream/reconciliation suite: 17 passed; compileall and CLI help pass.
- No Binance TESTNET/LIVE network session or order was executed; target Windows environment remains untested. Position lifecycle management, automatic flat-state reservation release, dashboard and unattended live operation remain future work.
