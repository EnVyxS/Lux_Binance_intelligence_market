# Test Report — v0.57.0D2

## Environment

- OS: Linux x86_64 build container
- Python: 3.13.5
- Project requirement retained: Python `==3.12.9`
- Pytest: 9.0.2 in build container
- D2 package metadata: `0.57.0rc3`

## Results

| Test scope | Result |
|---|---:|
| Full regression — source tree | **972 passed** |
| Full regression — clean extraction | **972 passed** |
| Focused recovery, TESTNET-only config and account-runtime integration | **19 passed, 42 deselected** in the selected focused command |
| `compileall -q src tests` | PASS |
| CLI help checks | 4/4 PASS |
| Wheel metadata/build | PASS |
| ZIP CRC and clean extraction | PASS |
| Sensitive-file audit | PASS |

## D2 safety cases covered

- Exact canceled/expired no-fill STOP source and verified sibling before one replacement.
- Triggered or filled source defers to fill reconciliation; no replacement.
- REST `-2013` falls back only to exact durable stream evidence; later triggered stream evidence supersedes older canceled evidence.
- Ambiguous POST/query is `SUBMISSION_UNKNOWN`; no automatic retry.
- Exchange-flat position finalizes through existing flat/order-cleanup/reservation-release path without replacement.
- Multi-lot recovery uses target lot quantity, not aggregate quantity, and preserves sibling protections.
- Only one gap is recovered per fresh reconciliation snapshot.
- Restart after pointer commit before action confirmation queries the deterministic replacement and does not POST again.
- Wrong workingType/priceProtect, invalid Hedge/One-way semantics and triggered sibling protection fail closed.
- Account runtime invokes D2 only with explicit opt-in, deduplicates the same snapshot and does not clear the entry halt.

## Limitations

- All D2 tests use FakeExecutionClient, local SQLite and synthetic/durable test events. No live REST, User Data Stream, Binance Demo order, Algo POST/cancel or LIVE write occurred during this build.
- Full Windows 10 / Python 3.12.9 validation is still pending for the exact D2 archive.
- C1 Windows evidence (952 full regression passed, Demo preflight and validation-only `/order/test`) remains separate and is not represented as D2 execution qualification.
