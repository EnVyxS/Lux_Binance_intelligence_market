# DIVATrading Binance Bot — Release Handoff v0.39.0

**Release:** Unit 05E Stage 6C.3B — Replay Runtime Optimization & Partial Lifecycle Diagnostics  
**Date:** 2026-11-12  
**Base:** v0.38.0  
**Runtime used for build/tests:** Linux x86_64, Python 3.13.5  
**Target runtime:** Windows 10, Python 3.12.9, 8GB RAM — not yet verified on the user's PC.

## Included implementation

- Explicit state cloning in Stage 4 OB lifecycle and Stage 5 liquidity/FVG engines replaces recursive deep copies while retaining fresh mutable OB/FVG records and atomic M1/M5 commit semantics.
- Stage 5 pivot provenance validation indexes candles by open/close timestamp.
- Stage 4 avoids full validation for a previously validated candidate only when its complete fingerprint matches; conflicting ID reuse remains a hard error.
- Strategy stages and rules are unchanged. No FVG expiry policy is introduced.

## Verification

- Full test suite: **719 passed**.
- `compileall`: passed.
- Package import/version: `0.39.0`.
- Root CLI `--help`: passed with `PYTHONPATH=src`.
- Bounded 180-capture before/after optimization full-ledger comparison: 12,541 records on each side; all normalized records identical after excluding run/capture identity and code-hash fields.
- cProfile 180-capture benchmark: 6.321s before and 2.300s after the state-clone optimization (~2.75x in this benchmark).
- Real BTCUSDT compact partial: 600 captures / 10h, zero gaps, 140,996 suppressed records. M1 FVG inventory 210 retained (19 nonterminal); M5 33 retained (6 nonterminal).

## Incomplete acceptance item

The required 27h M5 pre-roll + 60m evaluation replay remains **INCOMPLETE**. The last durable long-horizon compact checkpoint reached 900 of 1,680 captures before the execution window ended. It is excluded from completed-trial, convergence and warm-up claims. No warm-up policy is approved.

## Known gates

- FVG cap remains 512 per timeframe. ACTIVE/TOUCHED/PARTIALLY_FILLED remain until FILLED; only terminal FILLED records are eligible for capacity trimming. No expiry was added.
- BTCUSDT historical effective `PRICE_FILTER.tickSize` remains unproven. Strict execution replay remains BLOCKED.
- This is provisional strategy evidence only; it does not establish order validity, fills, fees, slippage, PnL or profitability.
- No private API, live order execution, or TESTNET trading is enabled.

## Next task

Continue optimizing compact pre-roll evidence materialization/hashing without bypassing Stages 1–5, then complete the 25h+ M5 lifecycle and FVG retention validation. See `docs/NEXT_TASK.md` and `docs/SMC_V2_EXTENDED_M5_LIFECYCLE_FVG_RETENTION_STAGE6C3B.md`.
