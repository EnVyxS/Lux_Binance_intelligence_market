# Quantity-Scoped Protective Orders — v0.52.0

## Parameter model

The Binance USDⓈ-M Futures Algo-order path is `POST /fapi/v1/algoOrder`. DIVA now submits per-signal `STOP_MARKET` and `TAKE_PROFIT_MARKET` protection using explicit `quantity` and `triggerPrice`.

- One-way Mode: `positionSide=BOTH`, closing `side` is opposite the position direction, and `reduceOnly=true`.
- Hedge Mode: `positionSide=LONG` or `SHORT`; `reduceOnly` is omitted.
- `closePosition` is omitted for quantity-scoped protection. Binance's conditional-order parameter constraints do not allow `quantity` together with `closePosition=true`, and Hedge Mode does not accept `reduceOnly`.

Official API references:
- https://developers.binance.com/docs/derivatives/usds-margined-futures/trade/rest-api/New-Algo-Order
- https://developers.binance.com/docs/derivatives/usds-margined-futures/trade/rest-api/Cancel-Algo-Order

## Resize transaction

After a partial TP or partial MARKET exit is confirmed by order REST status plus exchange position quantity:

1. The managed lot quantity is persisted from exchange truth.
2. A deterministic `RESIZE_PROTECTION` action is claimed and persisted before exchange writes.
3. New STOP and TP clientAlgoIds are queried first. Missing IDs may be submitted once; ambiguous submission is never blindly repeated.
4. Both new orders are queried and validated for active state, symbol, type, closing side, positionSide, exact quantity and mode-specific reduce semantics.
5. Only after both replacements are verified are known old DIVA protection orders identity-checked and cancelled.
6. The lifecycle state is moved to new IDs and the action is marked CONFIRMED only after old-order cancellation is verified.

On any unresolved submission, identity, quantity or cancellation discrepancy, the adapter latches the new-entry halt. Risk reservation remains active while a position is open.

## Explicit limitations

- Create/verify-before-cancel briefly allows the old and new protection pair to coexist. No atomic Binance pair-replacement operation is assumed.
- A protective Algo trigger that leaves a residual position is not fully auto-resized in v0.52.0; the current policy retains the sibling and halts entries for reconciliation.
- Same-side multiple signal execution is still blocked.
- Local deterministic tests do not establish exchange TESTNET/LIVE behavior.
