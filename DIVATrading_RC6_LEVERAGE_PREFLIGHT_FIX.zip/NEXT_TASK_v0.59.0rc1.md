# Next Task — After v0.59.0rc1

The consolidated risk/runtime candidate is built. Do not remove the autonomous LIVE hard gate based solely on local unit tests.

1. User-side qualification of the exact ZIP on Windows 10 / Python 3.12.9 x64: install, full `TEST_WINDOWS.bat`, startup/shutdown, local SQLite backup/restart.
2. On the dedicated Binance USDⓈ-M Futures account, run `live-read-only-preflight` using API credentials stored only in local `.env`; confirm account mode, empty initial exposure/orders, symbol metadata, account leverage brackets, commission, and per-symbol `symbolConfig` read-back. This command is read-only.
3. Review any non-zero unsupported income types / non-USDT fees reported by the risk ledger. Keep new entries blocked until every account income/fill is attributed and reconciled.
4. Perform controlled exchange lifecycle acceptance on TESTNET or an explicitly approved alternative validation environment: one symbol, small risk, entry acknowledgement/fill, both protective legs, partial exit, final flat, reconnect, restart, duplicate replay and kill/pause behavior. Same-side scale-in remains blocked pending separate evidence.
5. Only after Windows and exchange evidence is reviewed should a separate LIVE authorization design/review occur. The current `auto-trade-runtime` intentionally rejects LIVE; do not work around this gate.

No API key, secret, Telegram token, `.env`, or account screenshot containing credentials may be sent in chat. Do not erase the local database between runs because it contains durable Telegram offsets, execution ownership, income watermarks, and trade-risk history.
