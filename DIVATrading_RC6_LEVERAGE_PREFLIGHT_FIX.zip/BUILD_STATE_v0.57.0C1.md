# Build State — v0.57.0C1

- Parent: v0.57.0C, user-validated working tree.
- Release package version: `0.57.0c1` (PEP 440 release-candidate identifier).
- Target: Windows 10 64-bit / Python 3.12.9 64-bit.
- Functional fixes carried into the release: coordinator import, Stage C BAT echo correction, Windows checkpoint write/flush/fsync, Stage 6B test manifest hashing path, and graceful managed-position supervisor shutdown.
- Development dependencies aligned to `pytest==9.2.0` and `pytest-asyncio==1.5.0`; async fixture loop scope fixed to `function`.
- Windows installer/test launcher route temporary files and pytest basetemp to `.diva_temp` under the project drive.
- User-reported Windows full regression on the functional source: 952 passed, 0 failed, 0 skipped, 904.90 seconds. Targeted results: supervisor 10 passed; Stage 6A 16 passed; Stage 6B 7 passed; targeted SQLite lifecycle 2 passed.
- Release-only metadata/deployment packaging changes are separately checked in the release environment: compileall, CLI help, wheel build, ZIP CRC, clean extraction and sensitive-file audit.
- No Stage C actual Demo entry/fill/protection test has been executed as part of the release build. No LIVE order is authorized.
