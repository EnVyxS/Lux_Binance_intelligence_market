# Changelog v0.50.0

- Added cross-platform OS advisory process locks for account-runtime and market-runtime.
- Added fail-closed reconciliation discrepancy classification; unknown codes require operator review.
- Added heartbeat-based WorkerWatchdog primitive for stale-worker detection.
- Added read-only `runtime-status` CLI output for stream/reconciliation state, managed positions, pending lifecycle actions and risk reservations.
- Reconciliation reports now persist discrepancy policy metadata. A stream event racing a sequential snapshot remains a transient retry condition and does not permanently latch entry halt.
- PAPER remains the default. No exchange connectivity or order submission was performed in this release validation.
