# Build State v0.49.0

- Baseline recovered from v0.48.0 source ZIP: `DIVATrading_BinanceBot_LifecycleExecutionAdapter_0.48.0.zip`.
- Baseline regression before v0.49 changes: 824 passed.
- Added `ManagedPositionSupervisor`: bounded per-symbol Mark Price workers, event freshness/future-skew checks, worker restart, active-symbol cap and one-managed-signal-per-symbol/side enforcement.
- Connected Mark Price lifecycle supervisor to `ExecutionAccountRuntime`; account-runtime now co-runs private User Data Stream, reducer, periodic REST reconciliation and position management.
- Added `STRUCTURAL_EXIT` when Mark Price touches/crosses the approved SMC TradePlan SL/invalidation boundary.
- Added an explicit `emergency-close` CLI action gated by TESTNET/LIVE mode, managed signal ID, reason and exact operator phrase.
- Added full MARKET close execution for structural/emergency exit with One-way/Hedge parameter handling, durable deterministic IDs, exchange quantity preflight, REST fill confirmation and verified-flat finalization.
- Added current ExchangeInfo-derived MARKET_LOT_SIZE/LOT_SIZE fallback and PRICE_FILTER for lifecycle order dispatch.
- Added partial TP original-size/cumulative-fill tracking so terminal partial fills only request the exact outstanding remainder of the original 50% target.
- Hardened account observation readiness: the existing-position manager may continue while entries are halted only if the most recent reconciliation has no discrepancies, is fresh and stream watermark is current. Exchange mismatch remains blocked.
- Package version, package `__version__`, and private and public REST client User-Agents updated to 0.49.0.
- Full regression: 834 passed.
- Focused lifecycle/supervisor suites: 37 passed.
- `compileall`, root CLI help, `account-runtime --help`, and `emergency-close --help`: PASS.
- Runtime compatibility check correctly rejects container Python 3.13.5 because the package requires exactly Python 3.12.9.
- PAPER default. No actual private Binance REST, User Data Stream, public Mark Price WebSocket, TESTNET/LIVE order or cancellation was used.
- Windows 10 / Python 3.12.9 / 8 GB target remains untested.
