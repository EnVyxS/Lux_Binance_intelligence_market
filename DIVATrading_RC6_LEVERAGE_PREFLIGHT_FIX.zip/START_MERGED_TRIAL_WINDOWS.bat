@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
if not exist ".env" (
  echo Configure the local .env first. See docs\MERGED_TRIAL_ID.md.
  exit /b 1
)

set "DIVA_DATABASE_PATH=data\merged-trial.db"
set "DIVA_TRIAL_EXIT_FLAG="
if defined DIVA_TRIAL_EARLY_EXIT set "DIVA_TRIAL_EXIT_FLAG=--early-exit-protection"

echo DIVATrading RC6 merged trial - REAL Binance USD-M Futures
echo Strategy: M15/M5 sweep-reclaim, bounded LIMIT IOC, RC6 partial and trailing.
echo Maximum one managed position or pending entry.
if defined DIVA_TRIAL_EXIT_FLAG echo Experimental near-target order-flow exit enabled.
echo A new trial database defaults to FIXED 0.20 USDT planned risk per trade.
.venv\Scripts\python.exe -m divatrading risk-config
if errorlevel 1 exit /b 1

.venv\Scripts\python.exe -c "raise SystemExit(0 if input('To activate real orders, type exactly START LIVE TRADING: ') == 'START LIVE TRADING' else 2)"
if errorlevel 1 (
  echo No order process launched.
  exit /b 2
)

.venv\Scripts\python.exe -m divatrading auto-trade-runtime ^
  --activate-live --mode AUTO --max-symbols 8 --max-positions 1 ^
  --strategy sweep-reclaim %DIVA_TRIAL_EXIT_FLAG% ^
  --risk-per-trade-pct 0.25 --max-portfolio-risk-pct 20
set "CODE=%errorlevel%"
echo LIVE runtime terminated with code %CODE%. Check exchange positions and orders before restarting.
exit /b %CODE%
