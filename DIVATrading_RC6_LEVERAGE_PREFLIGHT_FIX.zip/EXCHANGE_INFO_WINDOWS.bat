@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
.venv\Scripts\python.exe -m divatrading exchange-info
if errorlevel 1 exit /b %errorlevel%
.venv\Scripts\python.exe -m divatrading instruments --limit 50
exit /b %errorlevel%
