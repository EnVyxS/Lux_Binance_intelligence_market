# Stage C — Controlled TESTNET SMC Entry & Fill Qualification

## Scope

Stage C qualifies the existing autonomous pipeline against Binance USDⓈ-M Demo Futures using one manually selected symbol. It does not generate synthetic signals or bypass SMC qualification. The first eligible SMC V2 signal may create a Demo entry only after account User Data Stream and REST reconciliation report readiness. Existing execution service idempotency, account snapshot checks, portfolio risk reservation, partial-fill handling, and quantity-scoped protective-order attachment remain in force.

## Independent authorization gates

TESTNET actual order routing now requires all of the following locally:

- `DIVA_EXECUTION_MODE=TESTNET`
- `DIVA_ENABLE_TESTNET_ORDERS=true`
- `DIVA_ENABLE_TESTNET_STAGE_C=true`
- Valid Demo API credentials in `.env`
- CLI invocation `auto-trade-runtime` with `--mode MANUAL`, exactly one `--symbols` value, and `--max-symbols 1`
- `--risk-per-trade-pct` no greater than `0.10` and `--max-portfolio-risk-pct` no greater than `0.25`
- Account User Data Stream + REST reconciliation readiness

The two TESTNET flags are intentionally separate. The generic order flag alone cannot arm Stage C. PAPER remains default. LIVE remains disabled and the autonomous runtime rejects LIVE.

## Recommended initial qualification command

After Stage B is complete, and only when the operator is ready to authorize actual Demo order placement, set the two TESTNET flags to `true` in the local `.env` and run from the project root:

```bat
.\.venv\Scripts\python.exe -m divatrading auto-trade-runtime --mode MANUAL --symbols BTCUSDT --max-symbols 1 --risk-per-trade-pct 0.10 --max-portfolio-risk-pct 0.25 --account-ready-timeout-seconds 180
```

This command is a continuous autonomous runtime, not a one-shot order. It waits for a genuine qualified SMC signal; it does not force an entry. Stop with Ctrl+C when the qualification session is complete. Do not leave it unattended during initial qualification.

## Expected evidence

Capture sanitized logs for: account runtime readiness; selected BTCUSDT universe; qualified signal; dispatcher decision; durable risk reservation; entry client order ID/order acknowledgement; User Data Stream `ORDER_TRADE_UPDATE`; REST reconciliation; observed fill quantity/average price; attached STOP/TP Algo order IDs and statuses; position supervisor protection verification. Never share API credentials, `.env`, listenKey, signed URL, or raw authentication headers.

## Stop conditions

No signal means no order. Stale account snapshot, disconnected private stream, failed reconciliation, existing external position/order, failed risk reservation, ambiguous order POST, or unconfirmed protection must block new entries or halt execution according to the existing execution lifecycle. Do not manually retry an ambiguous entry; reconcile by deterministic client order ID first.

## Known boundaries

This build's tests use local fixtures, SQLite, and mocked exchange clients. It does not prove a real Demo order/fill/protection cycle. Stage C acceptance remains pending until the user executes the command on Windows 10/Python 3.12.9 and supplies sanitized logs. Same-side TESTNET/LIVE scale-in remains blocked pending separate exchange qualification. LIVE remains disabled.
