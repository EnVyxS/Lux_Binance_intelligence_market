# Next Task — v0.57.0 TESTNET End-to-End Qualification

## Goal

Prove the integrated v0.56 autonomous SMC-to-entry path against Binance USDⓈ-M Futures TESTNET, then qualify multi-lot protective Algo behavior before lifting any same-side scale-in gate. No LIVE routing in this milestone.

## Sequence

1. Validate Python 3.12.9, dependency installation, TESTNET base URL, API key permissions and IP restriction.
2. Verify account mode (One-way/Hedge), leverage/margin settings and exchange symbol filters from live TESTNET metadata.
3. Start TESTNET account User Data Stream and REST reconciliation; prove `execution_readiness` is true before market runtime is allowed to dispatch.
4. Run one manually selected liquid symbol and one signal at very conservative risk. Verify deterministic entry client ID and query-first recovery semantics.
5. Verify NEW/PARTIALLY_FILLED/FILLED/CANCELED/EXPIRED/rejected order status, partial-fill protection, STOP/TP parameter semantics, and protective Algo `actualOrderId` residual handling.
6. Reconnect stream, execute REST user-trade backfill, restart process with open position and verify no duplicate entry or lost protection.
7. Test partial TP, sibling protection replacement, per-lot risk release, external position/open-order accounting and kill switch.
8. Qualify two or more same-symbol/side signal lots with independent quantity-scoped Algo protection. Until these tests pass, same-side TESTNET/LIVE scale-in remains blocked.
9. Generate signed release evidence: sanitized logs, order/position snapshots, event timeline, test report, SHA-256 and handoff.

## Safety boundaries

- TESTNET only; do not populate LIVE opt-in values.
- No automatic retry of ambiguous order POST. Reconcile deterministic client IDs and exchange state first.
- If account stream/reconciliation/protection readiness fails, entries halt; continue managing existing positions.
- No LIVE authorization in v0.57.
- Windows 10 / Python 3.12.9 validation may be included if the user's target PC is available, otherwise keep it as a separate environment qualification.
