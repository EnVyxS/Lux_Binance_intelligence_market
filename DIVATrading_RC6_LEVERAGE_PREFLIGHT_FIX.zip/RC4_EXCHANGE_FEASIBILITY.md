# RC4 Exchange Feasibility Notes

The account-specific leverage bracket response is parsed into ordered notional tiers. The maintenance-margin estimate uses the bracket's `notional * maintMarginRatio - cum` form, floored at zero. The tier's `initialLeverage` caps leverage for that notional. The fee reserve estimates both entry and exit commission using the symbol's maker/taker rates and a configurable multiplier.

The output is an estimate, not a liquidation-price calculator. Actual liquidation depends on exchange margin state, mark price, position mode, maintenance tiers, fees, funding, other positions/orders and account configuration. Exchange remains authoritative.

Binance references used for endpoint semantics:
- USDⓈ-M Futures `GET /fapi/v1/leverageBracket` and `GET /fapi/v1/commissionRate` are read-only account endpoints.
- `GET /fapi/v1/symbolConfig` exposes per-symbol configuration; `POST /fapi/v1/leverage` and `POST /fapi/v1/marginType` are mutation endpoints and are not called by this release.
