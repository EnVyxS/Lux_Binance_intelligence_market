# Release Handoff — DIVATrading Binance Bot v0.57.0B

## Verified baseline

- v0.57.0A Testnet Environment & Exchange Qualification Harness.
- Baseline source and clean-extraction regression: 927 passed.
- Baseline had no actual Binance private session or order request.

## Delivered in Stage B

1. Added signed `POST /fapi/v1/order/test` transport method to the pinned Demo client.
2. Added LIMIT/MARKET request normalization and current symbol-filter validation using `Decimal`.
3. Added account position-mode validation: One-way uses `BOTH`; Hedge requires explicit `LONG` or `SHORT`.
4. Added `testnet-order-test` CLI, with a fresh preflight before every request.
5. Added a dedicated local environment opt-in and command confirmation. The actual order-placement flag remains false; the Stage B command blocks if it is enabled.
6. Added error/transport classification, latency/time/endpoint reporting, no automatic retries, and secret/signature redaction.
7. Deliberately left MARKET notional checks to Binance's test-order endpoint instead of approximating exchange reference-price semantics with a last-price ticker.

## Safety boundaries

- Demo base URL pinned to `https://demo-fapi.binance.com`.
- No actual `/fapi/v1/order` or `/fapi/v1/algoOrder` write path is called by Stage B.
- No actual order is created and no matching-engine submission/fill/position is expected from `/fapi/v1/order/test`.
- `DIVA_ENABLE_TESTNET_ORDERS=false` and `DIVA_LIVE_TRADING_ENABLED=false` remain mandatory.
- Stage B uses a separate flag: `DIVA_ENABLE_TESTNET_ORDER_TEST=true`, plus `--confirm-test-order`.
- Secrets and signatures are not printed, logged, or packaged.

## Verification

- Source regression: **948 passed across two runs** — 941 tests excluding `tests/test_stage6b_workflow.py`, plus 7 workflow tests in a separate run with `-p no:ddtrace`. The legacy workflow module passed independently after the monolithic command exceeded its execution window and the tracing plugin intermittently stalled process shutdown.
- Focused TESTNET/Stage B tests: **38 passed**.
- `compileall` and all three CLI help checks: PASS.
- Build host: Linux / Python 3.13.5. Project `requires-python ==3.12.9` unchanged.
- Clean extraction: **948 passed across two runs** (941 + 7; workflow module with `-p no:ddtrace`); focused tests: **38 passed**; compileall, CLI help, ZIP CRC and sensitive-file audit: PASS. See `CLEAN_EXTRACTION_TEST_REPORT_v0.57.0B.md`.
- No actual Demo credential, authenticated Binance request, WebSocket, order, or LIVE API request was exercised because the target PC was unavailable.

## Operator next step when PC access returns

1. Revoke/rotate the credentials disclosed in chat; create new Demo credentials and store them locally in `.env` only.
2. Run `testnet-preflight --symbols BTCUSDT` and require `READY_FOR_TEST_ORDER_VALIDATION`.
3. Enable only `DIVA_ENABLE_TESTNET_ORDER_TEST=true`; keep `DIVA_ENABLE_TESTNET_ORDERS=false` and `DIVA_LIVE_TRADING_ENABLED=false`.
4. Run `testnet-order-test` with a quantity/price aligned to current Demo exchange filters and `--confirm-test-order`.
5. Share sanitized JSON output only. Do not share `.env`, API Key, API Secret, screenshots containing credentials, or signed URLs.

## Next milestone

v0.57.0C — separately authorized small Demo order placement and actual fill confirmation. Stage B acceptance does not itself authorize Stage C or LIVE.
