# Kronos-mini Shadow Integration — v0.58.0rc2

## Purpose and boundary

Kronos is an optional forecast/visualisation component. SMC remains the sole source of setup qualification. A Kronos forecast cannot create, approve, reject, rank, delay, resize, or execute a trade. Inference failure never blocks SMC market analysis or Signal-only publication.

The first integration uses `NeoQuasar/Kronos-mini` with `NeoQuasar/Kronos-Tokenizer-2k`, CPU-only inference, a maximum configured context of 512 M5 bars for the Windows 10 / 8 GB deployment profile, a minimum of 64 closed bars, and a default six-bar forecast horizon. The model family card lists Kronos-mini at 4.1M parameters and a 2,048-token context limit; this application deliberately uses a smaller operational context. See the official repository/model card for model details.

## Optional installation

The core package does not import PyTorch or pandas during normal startup. Matplotlib and NumPy are installed with the core package because Telegram chart rendering must work even before the optional Kronos model is downloaded. The model and source are not included in the release ZIP.

From the project root on the required Python 3.12.9 x64 environment:

```powershell
INSTALL_KRONOS_WINDOWS.bat
```

The installer:

1. Installs a CPU-only PyTorch wheel and pinned inference/chart dependencies.
2. Resolves the current official GitHub `master` commit, downloads the archive for that exact commit, verifies the expected source layout/license and records the archive SHA-256.
3. Resolves and downloads immutable Hugging Face revisions for the model and tokenizer.
4. Writes `.kronos/kronos_install_manifest.json` only after the source/model/tokenizer snapshots have been checked.

Model/source assets remain under `.kronos/`, which is ignored and excluded from release packages. Re-run `kronos-status` after installation. Installation requires outbound access to GitHub, Hugging Face and the PyTorch CPU wheel index. The release build did not download weights or test inference against the remote model.

`--no-install-dependencies` is reserved for environments where the exact optional dependencies are already installed; it does not bypass model/source downloads.

## One-shot smoke test

After installation:

```powershell
.venv\Scripts\python.exe -m divatrading kronos-status
.venv\Scripts\python.exe -m divatrading kronos-forecast --symbol BTCUSDT --context-bars 512 --minimum-input-bars 64 --horizon-bars 6
```

This fetches public Binance USD-M M5 candles and writes the shadow forecast JSON to stdout. No API key is used. The forecast requires contiguous, closed M5 candles and rejects forming bars, gaps, wrong symbols or wrong intervals.

## Telegram SIGNAL_ONLY

Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_OWNER_ID` in the local `.env`. Do not share either value or `.env` in chat. Run the optional outbound-only publisher:

```powershell
RUN_SIGNAL_RUNTIME_WINDOWS.bat
```

Equivalent command:

```powershell
.venv\Scripts\python.exe -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT --max-symbols 1 --telegram-signals --kronos-shadow
```

The command uses public Binance market data and sends only SMC-qualified signals to the owner chat. It does not submit exchange orders and does not start a second Telegram `getUpdates` poller. `telegram-control` can remain the sole inbound command poller in a separate process if desired; the `RUN_TELEGRAM_CONTROL_WINDOWS.bat` launcher is provided for that process.

Each chart shows actual Binance M5 candles, the matched SMC OB zone where available, Entry, SL, TP1 at 1R, final TP, gross RRR, and a separately dashed Kronos M5 projection. Caption and chart clearly state that Kronos is a shadow forecast, not actual price or a trade confirmation. Gross RRR excludes fees and slippage; it must not be interpreted as net RRR.

If Kronos is not installed or inference fails, the signal still publishes with `Kronos: UNAVAILABLE` and a reason category. Signal publication remains independent of model availability. For SMC-only publication, run `RUN_SIGNAL_RUNTIME_NO_KRONOS_WINDOWS.bat`.

## Persistence and evaluation

`signal_publications` records each signal once and its Telegram delivery status. `kronos_shadow_forecasts` stores each unique forecast and `signal_forecast_links` links a forecast to every signal that used it. A delivery timeout is marked `DELIVERY_UNKNOWN` and is not automatically resent because Telegram does not provide an idempotency key for `sendPhoto`.

Inspect publication history:

```powershell
.venv\Scripts\python.exe -m divatrading signal-history --limit 50
```

Once the complete six-bar forecast horizon has closed and those bars have been observed/persisted by DIVATrading market runtime, evaluate it:

```powershell
.venv\Scripts\python.exe -m divatrading kronos-evaluate --forecast-id FORECAST_ID
```

The evaluator reports direction hit, per-bar directional accuracy, close MAE/MAPE and predicted range containment. These are forecast diagnostics only—not strategy profitability, fill quality, trade expectancy or a probability that an SMC setup will win. Results require exact matching of forecast timestamps to observed closed Binance M5 bars. Missing bars return a waiting/invalid status rather than synthesising data.

## Known limits

- The packaged release has not downloaded or run the real Kronos model. The real model smoke test must be done on the user's Windows PC after installation.
- CPU inference latency and RAM use have not been benchmarked on the user's target PC.
- Model forecasts have not been calibrated on Binance Futures scalping or BTCUSDT out-of-sample data.
- Kronos output is not used as a probability, confidence score, confluence gate or automatic trade veto.
- The first chart visualises a single forecast path (`sample_count=1`). No uncertainty band or probabilistic interval is claimed.
- SIGNAL_ONLY does not submit orders. Autonomous LIVE routing remains disabled.
