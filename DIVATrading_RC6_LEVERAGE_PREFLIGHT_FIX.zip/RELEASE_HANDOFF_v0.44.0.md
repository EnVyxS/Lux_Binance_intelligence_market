# DIVATrading Release Handoff — v0.44.0

## Identity
- Release: `DIVATrading_BinanceBot_GlobalAccountState_0.44.0.zip`
- Base: v0.43.0 SMC V2 Signal Planner
- Scope: First v0.44 execution-lifecycle delivery: exchange-truth account snapshot and conservative portfolio exposure reservation.

## Included
- `BinanceAccountStateService` captures Futures account balances/equity, active positions, standard open orders and conditional/algo open orders.
- Immutable Decimal-based `AccountSnapshot` and `PositionSnapshot` models.
- Rejects missing, malformed or non-finite financial values.
- Conservative exposure reservation uses absolute position notional until protective-stop reconciliation is complete.
- Exported API under `divatrading.execution`.

## Verification
- Full regression: 749 passed.
- `compileall` and root CLI help: PASS.
- Clean extraction regression: recorded separately.
- No Binance private request or order was submitted.

## Remaining v0.44 scope
- User Data Stream lifecycle and event reducer.
- Atomic global risk reservations across pair workers.
- Exchange/local order and position reconciliation, restart recovery.
- Partial TP, breakeven, trailing, automatic exit and kill-switch orchestration.

Execution remains PAPER by default. Runtime tested on Linux/Python 3.13.5; Windows 10/Python 3.12.9/8 GB is not yet verified.
