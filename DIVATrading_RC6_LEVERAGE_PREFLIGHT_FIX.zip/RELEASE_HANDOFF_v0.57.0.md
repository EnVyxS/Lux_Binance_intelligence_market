# Release Handoff — DIVATrading Binance Bot v0.57.0

## Verified baseline
- v0.56.0 Autonomous SMC-to-Entry Dispatcher.
- Baseline full regression passed 906 tests before v0.57.0 modifications.

## Delivered
1. Read-only `testnet-preflight` command with endpoint pinning, public REST ping, time sync, Demo exchange metadata, signed account access, position mode, balance and clean-account checks.
2. Current Binance USDⓈ-M Demo REST/market/private WebSocket endpoints.
3. Migrated LIVE private User Data Stream URL construction to `/private/ws?listenKey=...&events=...`; subscribes to order, account, Algo, trade-lite, account config, margin call and listen-key expiry events.
4. Demo Mark Price WebSocket endpoint selection.
5. Updated User Trades history bounds to 3 months/90 days based on Binance change effective 2026-08-26.
6. Added `.env.testnet.example` and Stage A operator instructions.

## Verification
- Source regression: 927 passed.
- Clean-extraction regression: 927 passed.
- Compileall and CLI help: PASS.
- ZIP CRC and sensitive-file audit: PASS; final SHA-256 is distributed in the external `.zip.sha256` sidecar.
- No real Binance request, WebSocket session or order was executed.

## Safety
- PAPER remains default.
- Stage A preflight does only public GET and signed GET operations. No listenKey lifecycle API call or order endpoint is called.
- TESTNET order opt-in remains false for Stage A.
- LIVE routing remains disabled.
- Same-side TESTNET/LIVE scale-in remains blocked pending exchange qualification.
- Python pin remains `==3.12.9`; Windows 10 / Python 3.12.9 target qualification pending.

## Next
v0.57.0B — signed `/fapi/v1/order/test` validation, followed by controlled Demo order lifecycle qualification only after Stage A preflight has been run locally and confirmed.
