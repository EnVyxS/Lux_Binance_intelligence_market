@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Virtual environment not found. Run INSTALL_WINDOWS.bat first.
  exit /b 1
)
.venv\Scripts\python.exe -m divatrading check
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m divatrading init-db
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m divatrading status
if errorlevel 1 exit /b 1
echo.
echo Unit 03E foundation, historical Kline, WebSocket feed and REST recovery modules are installed.
echo No trading order is enabled. Run EXCHANGE_INFO_WINDOWS.bat to fetch metadata or KLINES_HISTORY_WINDOWS.bat to test historical candles.
exit /b 0
