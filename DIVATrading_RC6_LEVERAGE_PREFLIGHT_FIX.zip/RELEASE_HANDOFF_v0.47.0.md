# Release Handoff — v0.47.0

## Release

DIVATrading Binance Bot v0.47.0 — Managed Position Lifecycle Foundation.

## Starting point

Continue from this ZIP and its source; do not use an older branch. Baseline is v0.46.0, which introduced User Data Stream, event watermarking, account reconciliation and TESTNET/LIVE readiness gates.

## Completed in v0.47.0

- Deterministic position lifecycle decision engine for LONG and SHORT.
- Configurable partial TP threshold/fraction, breakeven only after confirmed partial fill, and favorable-extreme trailing stop proposal.
- Monotonic stop logic and stable action IDs.
- SQLite versioned lifecycle state and idempotent action ledger.
- 797 full regression tests pass.

## Critical limitation

The lifecycle engine only emits decisions. It does not submit Binance partial-close or stop-change orders. Never treat PLANNED/SUBMITTED as FILLED/CONFIRMED. The next implementation must connect action claims to an exchange adapter, then confirm actual fills/order states through User Data Stream and REST reconciliation. Risk reservation must remain active until exchange confirms position is flat and all related orders are terminal.

## Next task

Implement v0.48.0 lifecycle execution adapter and fill-confirmed reducer: reduce-only partial close, safe algo STOP replacement/cancel-replace semantics, confirmed state transitions, verified-flat release and restart recovery. Preserve PAPER default and TESTNET/LIVE readiness gates.

## Environment

No TESTNET/LIVE API request, WebSocket session or order was used. Linux/Python 3.13.5 tested. Windows 10/Python 3.12.9/8GB not tested. Keep secrets out of release artifacts.
