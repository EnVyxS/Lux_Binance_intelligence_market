# Test Report v0.44.0

- Full suite: 749 passed.
- Added tests: account snapshot Decimal parsing, active position filtering, notional reservation, standard/algo open-order capture, malformed/non-finite account field rejection.
- Runtime: Linux x86_64 / Python 3.13.5.
- No real Binance API connection or order submission performed.
- Windows 10 / Python 3.12.9 / 8 GB remains unverified.
