# Test Report — v0.57.0D3

## Environment
- Build/test host: Linux, Python 3.13.5.
- Project runtime metadata remains pinned to Python `==3.12.9`.
- Test dependencies: pytest 9.2.0, pytest-asyncio 1.5.0.

## Results
- Full regression: **978 passed in 18.15s**.
- Focused triggered Algo fill/residual/zero-fill/backfill selection: **10 passed, 55 deselected**.
- `python -m compileall -q src tests`: PASS.
- Package version alignment (`pyproject.toml` vs `divatrading.__version__`): PASS (`0.57.0rc4`).
- CLI help checks: 4/4 PASS (`auto-trade-runtime`, `testnet-preflight`, `testnet-order-test`, `replay-workflow`).
- Wheel build: PASS using setuptools 82.0.1 with `pip wheel --no-deps --no-build-isolation --ignore-requires-python`. The override was needed only because the build host Python 3.13.5 differs from the intentionally pinned target `==3.12.9`; wheel METADATA retains `Requires-Python: ==3.12.9`. Wheel was not installed or runtime-tested here.

## D3 coverage
- Triggered Algo is re-queried by exact clientAlgoId and matching child `actualOrderId`.
- Child MARKET-order identity, original quantity, closing side, positionSide and close semantics are checked.
- Active child remainder cancellation is followed by a final REST query; post-cancel `executedQty` controls residual sizing.
- Fill-during-cancel race, stale/out-of-order stream cumulative quantity, partial fill, full fill, terminal zero fill with and without opt-in, ambiguous cancel/restart, duplicate events, and REST trigger backfill after stream gap are covered by tests.
- Runtime opt-in propagation and per-snapshot recovery deduplication are covered.

## External validation not performed
- No Binance Demo or LIVE request, order, cancel, child-order mutation, or Algo mutation was performed by this build.
- Exact v0.57.0D3 archive has not yet been qualified on Windows 10 / Python 3.12.9. C1's prior Windows regression evidence does not automatically qualify D3.
