# Position Lifecycle Decision Engine — v0.47.0

## Included

- Deterministic Decimal-based management decisions for LONG and SHORT positions.
- Configurable partial take-profit threshold (default 1R) and fraction (default 50%).
- Breakeven stop proposal only after the caller records a confirmed partial fill.
- Favorable-excursion trailing proposal (default activation 1.5R, distance 1R).
- Monotonic high-watermark for LONG and low-watermark for SHORT; proposed stops never loosen the current stop.
- Stable action IDs for idempotent downstream submission.
- SQLite persistence for management state with compare-and-swap versioning, plus idempotent action claims and action status updates.

## Critical execution boundary

This release adds the decision engine and durable intent/state primitives. It does **not** submit partial-close or stop-modification orders to Binance. A management action must be claimed in the ledger, submitted by a later exchange adapter, and marked confirmed only after User Data Stream plus REST reconciliation verify the resulting exchange state. Do not mark `partial_tp_done`, `breakeven_done`, or a new stop as effective merely because an action was planned or a POST was attempted.

## Default policy

- Partial TP: 50% of currently managed quantity at +1R.
- Breakeven: only after partial fill confirmation.
- Trailing: activates at +1.5R, trails by 1R from the favorable extreme.
- Stop updates are monotonic (never widen risk).
- Closed positions emit no actions.
- No automatic market exit policy is introduced in this slice.

These are conservative engineering defaults, not calibrated strategy parameters. They must remain configurable and be validated on TESTNET before LIVE use.
