# Build State — v0.58.0rc1

- Release: `DIVATrading v0.58.0rc1 — Persistent Operator Control Plane`.
- Baseline: v0.57.0D4 (`0.57.0rc5`), restored from the exact D4 Library archive.
- Package version: `0.58.0rc1`.
- Target interpreter pin: Python `==3.12.9`.
- Build host: Linux x86_64 / Python 3.13.5.
- Regression: **995 passed** on source tree.
- `compileall`: passed.
- CLI root help, `telegram-control --help`, and `auto-trade-runtime --help`: passed.
- Wheel: `divatrading_binance_bot-0.58.0rc1-py3-none-any.whl`; SHA-256 `e17eb266322b037b9c033f845e4bdff2e25abf806bfc6b46cd1fe31f3ecebea6`.
- Wheel built with `pip wheel --no-deps --no-build-isolation --ignore-requires-python` because build host is Python 3.13.5 while target pin is Python 3.12.9. Wheel preserves the target pin; it was not installed or runtime-tested on Python 3.12.9 here.
- Exchange integration: mocked/local SQLite only. No real Binance LIVE credentials, private REST, private stream, order, Algo order or position lifecycle was exercised.
- LIVE routing remains rejected by autonomous runtime. This is a release candidate, not a production LIVE release.
