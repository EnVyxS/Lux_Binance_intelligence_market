# Next Task after v0.54.0 — Multi-Lot Position Supervisor

1. Replace the current single-signal-per-(symbol, positionSide) runtime assumption with a deterministic multi-lot supervisor.
2. Route each Mark Price event to every active lot on that symbol while preserving independent signal state and lifecycle versions.
3. Aggregate exchange position quantity and weighted entry against the sum of local lots; detect manual/unattributed deltas and fail closed.
4. Maintain per-lot quantity-scoped STOP/TP, partial TP, structural exit, sibling cancellation and resize. Verify aggregate protected quantity equals aggregate exchange quantity.
5. Allocate exchange fills by exchange order ownership and `(symbol, tradeId)`; never pro-rate unknown fills without an explicit deterministic policy.
6. Reconcile reservations and portfolio risk as lots open, reduce, close and recover.
7. Add replay/restart/concurrency tests for two or more same-side signal IDs on one symbol.
8. Keep same-side scale-in blocked until TESTNET account-mode, entry, partial-fill, protection, reconnect and restart-recovery qualification passes.
9. After multi-lot supervisor, implement SMC V2 TradePlan -> atomic global risk reservation -> idempotent entry dispatcher -> fill confirmation -> protective orders.
10. Preserve PAPER default, explicit TESTNET opt-in and LIVE hard gate. Windows 10 / Python 3.12.9 validation remains pending.
