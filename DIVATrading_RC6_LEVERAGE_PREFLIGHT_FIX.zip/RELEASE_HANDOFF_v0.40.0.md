# DIVATrading Binance Bot — Release Handoff v0.40.0

**Release:** Multi-Pair Auto-Trading Core  
**Date:** 2026-11-12  
**Base:** Unit 05E Stage 6C.3B v0.39.0  
**Build/test runtime:** Linux x86_64, Python 3.13.5  
**Target runtime:** Windows 10, Python 3.12.9, 64-bit, 8 GB RAM — not yet verified on the user's PC.

## What changed

This release is the first build step toward the agreed **FULL AUTO TRADING BOT**. It is not signal-only: it adds the trading-side interfaces and execution primitives needed after strategy qualification.

- AUTO/MANUAL eligible USDT perpetual selector and `universe` CLI.
- Multi-symbol SMC V2 Stage 2–5 evidence pipeline.
- Immutable strategy-to-execution `QualifiedSignal` / `TradePlan` contracts.
- Decimal portfolio risk sizing and multi-pair execution coordinator.
- Signed Binance USDⓈ-M private REST client for account/position/order/algo-order/leverage/income operations.
- Separate persistent SQLite ledger for intent idempotency, order/position/event records, income deduplication and new-entry halt.
- PAPER-default execution service; TESTNET/LIVE require explicit local configuration.
- Stop-loss / take-profit conditional Algo Order attachment after a non-zero fill; partial LIMIT remainder cancellation; pending/ambiguous entry reconciliation by deterministic client order ID.

## Verification

- Full regression: **729 passed**.
- compileall: passed.
- CLI root help and `universe --help`: passed.
- Import/version: `0.40.0`.
- Default execution mode: PAPER.
- Clean extraction and smoke test: see `CLEAN_EXTRACTION_TEST_REPORT.md`.

## Critical remaining work — still part of build roadmap

1. Continuous dynamic multi-pair feed runtime and market-data recovery.
2. Connect live feeds to `ScalpingMarketDataAdapter` and `SMCV2EvidencePipeline`.
3. Complete strategy signal qualification plus dynamic entry/SL/TP policy without silently changing the existing SMC Stage 1–5 logic.
4. Build exchange-account portfolio snapshot and reconciliation from Binance truth before risk approval.
5. Complete order/position lifecycle worker with User Data Stream, partial exits, breakeven, trailing, cancellation and restart recovery.
6. Complete emergency action policy and protection verification.
7. Full PnL/income accounting with pagination/checkpointing.
8. Dashboard, Telegram, operational monitoring and Windows deployment/resource limits.

The next target is v0.41.0: **Multi-Pair Live Market Runtime & Feed-to-SMC Integration**. It must be read-only and should not place orders.

## Operator safety

- Do not run this release in unattended LIVE mode. The continuous signal-to-order runtime and full position reconciliation are not complete.
- PAPER is the default and does not load private Binance credentials.
- TESTNET requires `DIVA_EXECUTION_MODE=TESTNET` and `DIVA_ENABLE_TESTNET_ORDERS=true`.
- LIVE requires `DIVA_EXECUTION_MODE=LIVE`, `DIVA_LIVE_TRADING_ENABLED=true`, and exact confirmation `DIVA_LIVE_CONFIRMATION=I_ACCEPT_REAL_MONEY_RISK`; this is not recommended before all remaining runtime and recovery work is complete.
- API keys/secrets must remain local, must not be uploaded into chat or ZIP, and must not have withdrawal permission.
- No private exchange network calls or real orders were used during this build.

## Project decisions carried forward

- Full auto-trading multi-pair is the final product; not a signal-only product.
- AUTO and MANUAL symbol modes are both required.
- M1/M5 SMC states remain independent; M15 is advisory. No legacy nested M5/M15 priority is reintroduced.
- Binance USDⓈ-M Futures USDT perpetual universe; global risk manager across all symbols.
- Stage 6 extended historical research, long replay convergence, 12-month dataset calibration and profitability research are deferred from the build critical path. This does not waive code correctness or execution-safety work.
- Preserve release ZIP, SHA-256, handoff, build state and test report at each completed checkpoint.

## Resume instructions

Use this handoff and `BUILD_STATE_v0.40.0.md` as the continuation source. Do not restart Stage 6C.3B research as the next task. Continue directly with the v0.41.0 multi-pair live market runtime.
