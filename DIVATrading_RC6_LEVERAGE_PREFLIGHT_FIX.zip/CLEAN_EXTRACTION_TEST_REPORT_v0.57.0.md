# Clean Extraction Test Report — v0.57.0

- Archive: `DIVATrading_BinanceBot_TestnetQualificationHarness_0.57.0.zip`
- Archive entries: 339
- ZIP CRC/integrity: PASS
- Sensitive/runtime file audit: PASS (no `.env`, database, log, bytecode, pycache, or pytest cache entries)
- Extraction: PASS to an empty directory.
- Extracted package version: `0.57.0`
- Full regression from extracted source: **927 passed**.
- `compileall -q src tests`: PASS.
- `python -m divatrading --help`: PASS; `testnet-preflight` and `auto-trade-runtime` registered.
- `python -m divatrading testnet-preflight --help`: PASS.

All tests use local SQLite, fixture metadata, fake clients and mocked HTTP. No real Binance Demo/TESTNET or LIVE API, WebSocket session, or order was used.
