# Multi-Lot Position Supervisor — v0.55.0

## Scope

This release changes the managed-position runtime from a single signal per `(symbol, positionSide)` assumption to multiple independent signal allocations within one aggregate exchange position. It does not yet authorize live same-side scale-in.

## Lot and group model

- Each `signal_id` is a distinct lot with its own quantity, entry basis, stop, take-profit, lifecycle state, action history and portfolio-risk reservation.
- Lots are grouped deterministically by `(symbol, positionSide)`.
- Group quantity is the exact Decimal sum of active lot quantities; group weighted-entry diagnostics are computed from the per-lot quantity and entry price.
- The supervisor routes a symbol's Mark Price updates to every active lot, ordered by `opened_at_utc` and then `signal_id` for deterministic processing.
- Exchange position quantity is the source of truth for the aggregate. A local/exchange mismatch, missing lifecycle state, inactive reservation, or ambiguous ownership fails closed.

## Independent lifecycle

- Partial TP and market exits submit only the target signal lot's remaining quantity.
- Confirmation checks the aggregate exchange residual against `group_quantity_before - executed_quantity`, then changes only the target allocation.
- STOP/TP resize is per signal lot. The affected lot's replacement STOP and TP must be created and REST-verified before its prior protection is canceled.
- A full protective Algo execution can close only the attributed lot while leaving sibling lots and their protection untouched.
- When the aggregate exchange position is confirmed flat, the group finalizer cancels all bot-owned protections, verifies terminal order states and flat REST quantity, then closes every local lot and releases its risk reservation.
- Algo trigger replay resolves the stored action using deterministic client Algo IDs, preventing duplicate application after WebSocket replay/restart.

## Concurrency and admission safety

- Lifecycle action claims serialize mutations across all active lots sharing `(symbol, positionSide)`; only one group-level exchange mutation may be pending at a time.
- The multi-pair coordinator checks managed positions and unresolved entries before risk reservation.
- The execution service repeats the check after reading the actual Binance position mode and before leverage/order submission.
- One-way `BOTH` blocks any additional entry on the same symbol while the managed position is open.
- Hedge Mode blocks new same-side entries while allowing an opposite `positionSide` only when persisted position-side records establish Hedge Mode.
- Any unresolved/ambiguous entry for the same symbol blocks a new symbol entry pending reconciliation.
- These TESTNET/LIVE same-side scale-in gates remain enabled until v0.57.0 TESTNET qualification. PAPER can exercise multiple lots for simulation and deterministic unit testing.

## Explicit limitations

- The market runtime still does not autonomously dispatch SMC V2 TradePlans into the coordinator; that is v0.56.0.
- No real Binance TESTNET/LIVE private API or order was used in v0.55.0. Current validation is deterministic local tests with fake clients/SQLite.
- The exchange interaction with multiple simultaneous per-lot Algo protections still requires controlled TESTNET qualification before same-side scale-in is enabled.
- Windows 10 / Python 3.12.9 / 8 GB validation remains pending. The project Python pin is unchanged.
