# DIVATrading v0.58.0rc2 — Telegram Signal Center & Kronos-mini Shadow Forecast

## Added
- Outbound-only Telegram `sendPhoto` signal publisher; does not poll `getUpdates` and has no order-submission API.
- `SIGNAL_ONLY` market runtime flow publishes SMC-qualified candidates after qualification-only planning; reference PAPER equity and order sizing do not gate a signal.
- Matplotlib PNG chart with closed Binance USD-M M5 candles, optional SMC OB zone, Entry, SL, TP1 at 1R, final TP, gross RRR and visually distinct Kronos forecast candles.
- Durable SQLite schema v6: signal publications, Kronos forecasts, many-to-many signal/forecast links and forecast evaluations.
- Publication idempotency and explicit `DELIVERY_UNKNOWN` state; no automatic retry after an ambiguous Telegram sendPhoto result.
- Optional lazy Kronos-mini adapter for contiguous closed M5 candles. It cannot create, qualify, rank, block, size or execute an SMC trade.
- Opt-in `kronos-install`: pinned-by-commit official GitHub source and pinned Hugging Face model/tokenizer revisions, CPU-only PyTorch installation, local manifest written only after validation. Model weights are excluded from release ZIP.
- `kronos-status`, `kronos-install`, `kronos-forecast`, `kronos-evaluate`, and `signal-history` CLI commands.
- Windows launchers for Kronos install, SIGNAL_ONLY with/without Kronos, and inbound Telegram operator control.
- Forecast evaluation metrics: final direction hit, per-step directional accuracy, close MAE/MAPE and forecast-range containment; exact future M5 timestamp matching required.

## Hardened
- Forecast IDs include the exact input candle payload, model/tokenizer/source revisions and inference settings.
- Kronos import verifies that Python resolved the intended local official source, avoiding accidental import of an unrelated top-level `model` package.
- Optional model install invalidates the prior manifest before replacing assets; partial/failed installs cannot leave a stale READY manifest.
- Signal chart rejects gaps in the visible 100-bar M5 window rather than interpolating missing candles.
- Bounded forecast cache and bounded publisher deduplication memory.
- Core Matplotlib/NumPy dependencies ensure chart generation works even when Kronos has not been downloaded.

## Explicit limitations
- The real model has not been downloaded or inferred in the build environment. Run `INSTALL_KRONOS_WINDOWS.bat` and `kronos-forecast` on the target PC.
- Forecast display is one path (`sample_count=1`), not a confidence interval or calibrated probability.
- Net RRR is not reported until an actual fee-tier/slippage profile is configured; current caption states this explicitly.
- Forecast metrics are not trade PnL, execution quality, strategy edge or probability of an SMC signal succeeding.
- `market-runtime` remains read-only. Autonomous LIVE routing is disabled.
