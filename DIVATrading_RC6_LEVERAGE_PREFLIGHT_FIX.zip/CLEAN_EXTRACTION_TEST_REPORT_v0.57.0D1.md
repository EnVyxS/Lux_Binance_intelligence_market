# Clean Extraction Test — v0.57.0D1

- Final release archive CRC: PASS.
- Extracted all 380 archive members into a fresh isolated directory using validated relative paths: PASS.
- Full regression from the clean extracted tree: **956 passed** in 18.15 seconds.
- `python -m compileall -q src tests`: PASS.
- CLI help from extracted tree: `auto-trade-runtime`, `testnet-preflight`, and `testnet-order-test` — PASS.
- Package import version from extracted tree: `0.57.0rc2` — PASS.
- Source manifest hashes and sizes verified against archive content: PASS.
- No `.env`, `.venv`, database, local logs, pytest cache, backup files, API credentials or private account artifacts are included.
- Build/test host is Linux / Python 3.13.5; project runtime pin remains exactly Python 3.12.9. This does not claim Windows deployment qualification for D1.
