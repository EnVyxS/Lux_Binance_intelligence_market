# Build State — v0.57.0D1

- Parent: v0.57.0C1.
- Scope: Stage D1 Protective Algo Order Integrity Hardening.
- Package: `divatrading-binance-bot==0.57.0rc2` (PEP 440 release candidate 2; workstream D1).
- Runtime requirement remains exactly Python `==3.12.9` (Windows 10 64-bit target).
- New behavior: every initial, resized and replacement STOP/TP is verified against exact exchange symbol, deterministic clientAlgoId, order type, closing side, positionSide, quantity and trigger price before it is accepted as protection.
- Initial protection always re-queries Binance after POST; POST acknowledgement alone is not accepted.
- Previously-recorded but missing protection and mismatched protection fail closed, latch the entry halt and are never blindly reposted.
- Account reconciliation now detects wrong STOP/TP trigger prices, not just presence and quantity.
- Development dependencies remain pinned to pytest 9.2.0 and pytest-asyncio 1.5.0; async fixture loop scope is explicit.
- Full regression on build host: **956 passed**. Focused protective/lifecycle/reconciliation suite: **92 passed**. `compileall`: PASS.
- Build host: Linux / Python 3.13.5. This is development regression evidence, not Windows 10/Python 3.12.9 requalification of D1.
- No Binance Demo actual order, fill, Algo order mutation or LIVE action was performed.
