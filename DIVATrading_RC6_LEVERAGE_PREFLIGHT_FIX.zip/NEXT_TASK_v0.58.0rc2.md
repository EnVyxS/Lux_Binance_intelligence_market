# Next Task — After v0.58.0rc2

## User-side qualification required first

1. Install this exact archive on Windows 10 x64 / Python 3.12.9.
2. Run `TEST_WINDOWS.bat`; capture its full result locally, with secrets redacted.
3. Configure Telegram locally and verify one outbound signal chart delivery when a genuine SMC-qualified setup appears. Do not fabricate a signal to force a send.
4. If Kronos is desired immediately, run `INSTALL_KRONOS_WINDOWS.bat`, verify `kronos-status`, and run `kronos-forecast --symbol BTCUSDT`. Record model revision, inference latency and peak RAM from the target PC.
5. Allow full 6-candle M5 horizons to close and evaluate persisted forecasts using `kronos-evaluate`. Collect a meaningful walk-forward sample before judging model usefulness.

## v0.58.0rc3 — LIVE Account Feasibility and Safety Controls

1. Add read-only LIVE preflight with pinned LIVE REST endpoint, server-time sync, account permission/configuration, wallet/available balance, position mode, open positions, standard orders, Algo orders, symbol filters and strict `BOT_ONLY` reconciliation.
2. Retrieve and validate symbol-specific leverage brackets, notional tiers, maintenance margin, fee reserve and margin availability.
3. Integrate dynamic leverage selection with the real Binance exchange settings path. Query first, compare, change only behind explicit local authorization, and reconcile the exchange response. Default to isolated margin only after the account mode and symbol state are verified.
4. Complete closed-position/loss-streak ledger across partial exits, multiple lots, funding and commissions. An incomplete streak state must block new entries.
5. Reconcile daily loss anchors with deposits/withdrawals and define the daily boundary timezone explicitly.
6. Complete cross-module Telegram operator settings → persistent config → runtime refresh → risk gate tests.

## v0.58.0rc4 — LIVE Position Lifecycle Hardening

1. Validate private User Data Stream reconnect/backfill and exact ownership of standard/Algo orders.
2. Validate entry → partial fill → STOP/TP Algo protection → partial protective fill → residual protection → final exit.
3. Validate ambiguous POST/cancel, process restart, lost stream events and REST reconciliation. Any ambiguous state remains halted until resolved.
4. Verify pause/kill blocks new entries while position supervision and protection management continue.
5. Verify Telegram outage does not disable local account/position supervisor behavior.
6. Qualify exact release on Windows 10 / Python 3.12.9.

## LIVE acceptance gate

Only after the above release-candidate gates and the user's own read-only account preflight pass: request explicit authorization for a supervised minimum-risk single-symbol LIVE acceptance. No unattended multi-pair LIVE rollout before this evidence exists. Never ask for credentials in chat; use local `.env` only. Withdrawals must remain disabled and IP restrictions should be used when supported.
