# Build State — v0.58.0rc2

- Release: `DIVATrading v0.58.0rc2 — Telegram Signal Center & Kronos-mini Shadow Forecast`.
- Baseline: restored `v0.58.0rc1` source, whose parent handoff identifies `v0.57.0D4` as the execution/runtime baseline.
- Package version: `0.58.0rc2`.
- Target interpreter: Python `==3.12.9`, 64-bit; target OS Windows 10.
- Build host: Linux x86_64 / Python 3.13.5.
- Database schema: v6. Adds durable signal publication, forecast, forecast-to-signal link and forecast evaluation tables.
- SMC remains the sole signal qualification authority. Telegram publication runs `SIGNAL_ONLY`; order submission is not in this command path.
- Kronos: optional `NeoQuasar/Kronos-mini` + `NeoQuasar/Kronos-Tokenizer-2k`; lazy CPU-only adapter; context default 512 M5 candles, min input 64, forecast horizon 6; downloaded source/model/tokenizer are stored under ignored `.kronos/` and excluded from archive.
- Matplotlib and NumPy are core dependencies for signal chart generation, independent of optional Kronos model availability. PyTorch/pandas and downloaded model/source are opt-in via `kronos-install`.
- Source regression: **1,013 passed**. Clean extraction regression is separately recorded in `CLEAN_EXTRACTION_TEST_REPORT_v0.58.0rc2.md`.
- `compileall`, CLI help, imports, release metadata, SQLite schema migration, Telegram publisher mocks, chart rendering, forecast input validation and forecast evaluation passed.
- No model weights were downloaded in the build environment; no real Kronos inference was executed. The user's PC still needs the explicit install and one-shot model smoke test.
- No real Telegram API send was made; sendPhoto success/failure is covered with mocked HTTP.
- No real Binance private account request, leverage/margin mutation, order, Algo order or LIVE trade was made.
- Autonomous LIVE routing remains blocked. Loss-streak ledger, LIVE preflight, end-to-end exchange leverage/margin application and full LIVE lifecycle qualification remain next-release work.
