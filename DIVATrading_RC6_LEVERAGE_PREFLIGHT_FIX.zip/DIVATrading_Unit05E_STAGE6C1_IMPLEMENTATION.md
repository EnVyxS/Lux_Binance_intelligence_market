# SMC V2 — Stage 6C.1 Binance REST Kline Intake

## Scope

Stage 6C.1 adds read-only retention of Binance USDⓈ-M public REST Kline response pages and a derived native 12-column CSV. It is an acquisition/provenance helper, not a dataset acceptance or strategy calibration stage.

- Market: Binance USDⓈ-M Futures, USDT perpetual.
- Initial symbol: BTCUSDT. ETHUSDT follows after the BTC intake protocol is validated.
- Intervals: 1m and 5m; 15m optional/advisory.
- Source endpoint: `GET https://fapi.binance.com/fapi/v1/klines`.
- The REST API documents a maximum `limit` of 1,500. The collector defaults to 1,500 rows/request and a 1-second inter-request delay; these defaults are conservative client-side choices, not a claim about the API's full rate allowance.
- The capture window is half-open `[start_open_time_ms, end_open_time_ms_exclusive)`. Both values must align to the interval, and the exclusive end must not exceed the server's current interval floor. Thus the current, still-forming candle is rejected.
- Exact JSON response body bytes are retained per page, with request parameters, selected response headers, row count, open-time range and SHA-256 in the page index. A derived native Binance 12-column CSV is streamed separately.
- Missing leading/internal/trailing intervals are counted and sampled. No sorting, deduplication, interpolation, correction, rounding or candle synthesis occurs.
- Page count is bounded. If the cap is reached, the collector retains `.partial.csv` and marks the capture `PARTIAL_PAGE_CAP`. A paginated capture may still contain gaps; always run `replay-quality`.
- Capture IDs and source targets are immutable; an existing capture cannot be overwritten accidentally.

## CLI

Supply UTC Unix milliseconds aligned to the selected interval. The end boundary is exclusive:

```powershell
.\.venv\Scripts\python.exe -m divatrading binance-rest-kline-intake `
  --symbol BTCUSDT --interval 1m `
  --start-open-time-ms <START_UTC_MS> `
  --end-open-time-ms-exclusive <END_UTC_MS_EXCLUSIVE> `
  --dataset-root .\data\BTCUSDT --capture-id btc-m1-smoke
```

Use the same boundaries for M5 with `--interval 5m` and a separate capture ID. To capture current contract metadata:

```powershell
.\.venv\Scripts\python.exe -m divatrading binance-current-metadata `
  --symbol BTCUSDT --output-dir .\data\BTCUSDT\metadata\current
```

The directory layout is:

```text
<dataset-root>/raw/rest_klines/<symbol>/<interval>/<capture-id>/
  pages/page_000001.json
  pages.jsonl
  capture.provenance.json
<dataset-root>/derived/rest_klines/<symbol>-<interval>-<capture-id>.csv
```

A page JSON file is the retained response-body payload. `pages.jsonl` carries per-page hashes, query parameters and response headers. The provenance file binds the request window, Binance server time, aggregate raw-page hash, page-index hash, CSV hash, first/last candle, gap totals and pagination status.

The derived CSV is a convenience view and is not byte-equivalent to the JSON response. The raw page bodies remain the source evidence. For replay, create a Stage 6A manifest that references the derived CSV only after the quality gate passes and metadata is independently established.

## Metadata and historical tick-size evidence

`GET /fapi/v1/exchangeInfo` provides current trading rules and symbol information. The helper retains the raw response, a canonical symbol snapshot, server time and provenance. It always marks the record `CURRENT_SNAPSHOT_ONLY`, sets no historical effective-from/effective-to period and sets strict historical calibration eligibility to false. `pricePrecision` must never be substituted for exact `PRICE_FILTER.tickSize`.

Stage 6A currently accepts one metadata snapshot per dataset manifest. A calibration span crossing a proven filter change must be divided into metadata-homogeneous windows. `metadata_evidence_ref` is only a caller-supplied reference and is not fetched/authenticated by this tooling. A current exchangeInfo capture cannot prove a prior tick size. Do not manually relabel it `HISTORICAL_EFFECTIVE`.

## Binance Vision licensing decision

Binance Public Data Vision Terms v1.0 (last updated 26 August 2026) provide a non-commercial dataset license and restrict use for live proprietary trading execution and commercial trading-bot integration absent a separate written enterprise license. Therefore, the Vision downloader is intentionally not shipped as the intake source for this bot. See the [official terms](https://github.com/binance/binance-public-data/blob/master/TERMS_AND_CONDITIONS.md).

The selected REST collector uses a documented public market-data endpoint. It does not imply permission for resale, providing paid signals, operating a service for other people, or managing third-party funds. Review the applicable current Binance terms for the user's account and jurisdiction; this documentation is not legal advice.

## Required next validation

1. Run the collector from a network-capable supported Windows/Python 3.12.9 environment against a closed 30-day BTCUSDT M1 and M5 window.
2. Preserve raw capture directories and verify per-page raw hashes, page index, and derived CSV hashes. Record exact UTC boundaries and client/software version.
3. Run `replay-quality` over each CSV with exact interval-aligned boundaries. Require a strict PASS; any gap, duplicate, conflict, timestamp/OHLC defect or tick-grid issue must be resolved from source evidence, never by editing bars.
4. Capture current exchangeInfo for diagnostics, then separately collect independently verifiable dated Binance evidence for the effective historical `PRICE_FILTER.tickSize`. Do not infer the whole interval from today's filters.
5. Build metadata-homogeneous manifests only after the historical metadata timeline is evidenced. Then run the integrated Stage 6B.4 workflow for the 30-day tooling smoke.
6. Before calibration, freeze parameters, search bounds, chronological 60/20/20 split, warm-up trials and acceptance criteria. Target at least 12 complete UTC months for BTCUSDT; test ETHUSDT as later cross-symbol robustness after protocol freeze.

## Validation boundary

The Stage 6C.1 tests use mocked REST HTTP responses and synthetic Klines. No live Binance request succeeded in the build environment and no genuine data was acquired, audited or replayed. No empirical warm-up convergence, historical tick-size timeline, strategy calibration, PnL, win rate or profitability is established. No private API or order execution is present.
