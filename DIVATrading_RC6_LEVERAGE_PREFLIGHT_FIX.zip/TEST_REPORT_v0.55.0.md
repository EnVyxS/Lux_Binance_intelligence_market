# Test Report — v0.55.0

## Environment
- OS: Linux build container
- Python: 3.13.5
- Project `requires-python`: `==3.12.9` (unchanged; build host runs under 3.13.5)
- Exchange access: no authenticated Binance API session; all exchange behavior in tests uses local fakes/mocks.

## Source regression
- Command: `python -m pytest -q`
- Result: **891 passed in 16.57s**

## Focused coverage
- Multi-lot lifecycle, supervisor and accounting tests.
- Per-lot partial TP and protective Algo partial/full fill.
- One-way and Hedge Mode parameter behavior.
- Aggregate quantity reconciliation and flat-group finalization.
- Per-lot protection existence/quantity validation.
- Group-level lifecycle action serialization.
- Duplicate/replayed Algo trigger idempotency.
- Coordinator pre-risk gate and ExecutionService second-line admission guard for unqualified same-side scale-in.

## Static and CLI checks
- `python -m compileall -q src/divatrading`: PASS
- `PYTHONPATH=src python -m divatrading.cli --help`: PASS
- `runtime-status --help`: PASS
- `account-runtime --help`: PASS
- `market-runtime --help`: PASS
- Imported package version: `0.55.0`

## Clean-extraction verification
- Final release ZIP was extracted into a fresh empty directory separate from the source workspace.
- Full regression from extracted source: **891 passed**.
- Compileall, CLI help (`divatrading`, `runtime-status`, `account-runtime`, `market-runtime`) and package version `0.55.0`: PASS.
- See `CLEAN_EXTRACTION_TEST_REPORT_v0.55.0.md`.

## Not tested
- No TESTNET/LIVE private API request or order.
- No real Binance WebSocket / User Data Stream session.
- No Windows 10 / Python 3.12.9 execution.
