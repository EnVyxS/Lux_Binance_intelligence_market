# v0.56.0 — Autonomous SMC-to-Entry Dispatcher

## Objective

Connect the existing multi-pair SMC V2 market pipeline to the existing global risk coordinator and execution lifecycle without duplicating sizing, bypassing account readiness, or blindly retrying ambiguous order submissions.

## Runtime path

1. `MultiPairLiveMarketRuntime` selects the active AUTO/MANUAL universe and invokes `on_universe` before workers start. The callback converts exact exchange `SymbolInfo` objects into `InstrumentSpec` and updates the coordinator's active universe.
2. SMC V2 runs in `qualification_only` mode. It evaluates structure, OB/FVG, sweep, Delta/CVD, Depth and Absorption confluence and emits `QualifiedSignal` records; it deliberately does not create a final risk-sized plan or reserve risk.
3. `AutonomousEntryDispatcher` writes a durable `signal_dispatches` claim keyed by `signal_id` before any snapshot-provider I/O. The unique primary key gives at-most-once routing across duplicate market events and process restart. A previously claimed signal is not resubmitted.
4. The dispatcher validates signal age, entry halt, active-universe membership and freshness of the new `PortfolioSnapshot`. Immediately after snapshot capture it rechecks signal age, snapshot age and entry-halt state using a new decision timestamp; a slow REST snapshot cannot route an expired signal or bypass an entry halt raised during capture. PAPER uses a configured reference equity provider. TESTNET captures exchange wallet/equity, positions and open orders through `BinanceAccountStateService`.
5. `MultiPairExecutionCoordinator` is the sole authority for final quantity, leverage/notional and risk sizing. It atomically reserves global portfolio risk in SQLite, obtains deterministic client IDs, then calls `ExecutionService`.
6. Execution waits for existing fill-confirmation/protection behavior. Managed positions, quantity-scoped protections and lifecycle supervisor remain responsible for the position after entry. TESTNET runtime runs account User Data Stream, trade backfill, REST reconciliation and Mark Price position supervision in the same process.

## Durable dispatch states

- `CLAIMED`: signal identity persisted before external snapshot work.
- `SNAPSHOT_PENDING`: waiting for fresh portfolio/account capture.
- `RISK_ROUTING`: final sizing and atomic reservation are being evaluated.
- `DISPATCHED`: execution adapter accepted the entry path or PAPER simulation.
- `REJECTED`: deterministic validation/risk/admission rejection.
- `REQUIRES_RECONCILIATION`: stale or failed snapshot, ambiguous submission, exception, or incomplete execution state.

There is intentionally no automatic retry transition from `REQUIRES_RECONCILIATION`. An operator or reconciliation workflow must establish exchange truth before a new signal/intent can be considered. Existing manual entry halt is never cleared by the dispatcher. Non-PAPER exceptions set an entry halt.

## Risk snapshot treatment

- Exchange positions that match all local OPEN managed lots by symbol, position side and exact aggregate quantity, with active reservations for every lot, are represented by their existing local per-lot risk reservations rather than charged a second time at full notional.
- Unmatched, partially mapped, or quantity-mismatched positions are external/unattributed and charged conservatively at full absolute notional.
- Locally owned open orders are represented by their intent/reservation or are protective close orders. Unattributed external open standard/Algo orders are counted as pending exposure when price and remaining quantity can be established. Unpriced/malformed external open orders fail closed.
- This is a conservative admission snapshot, not a broker-grade margin simulator. Exchange mode, leverage, margin, liquidation and portfolio correlation remain subject to TESTNET and operational qualification.

## PAPER behavior

`DIVA_PAPER_SIMULATE_FILLS=true` (default in environment-derived CLI configuration) creates a deterministic full entry fill at the approved plan price, with quantity-scoped virtual STOP/TP orders, a managed-position row and retained risk reservation. This deliberately does not model order-book queue priority, latency, spread, slippage, partial execution probability, funding or market impact. Set `DIVA_PAPER_SIMULATE_FILLS=false` for intent-only PAPER execution. A PAPER full-fill is a simulation artifact, never evidence of actual Binance execution quality.

## Safety gates

- PAPER remains default and does not load private credentials.
- TESTNET routing requires `DIVA_EXECUTION_MODE=TESTNET`, `DIVA_ENABLE_TESTNET_ORDERS=true`, API credentials, User Data Stream and successful REST account reconciliation readiness.
- Same-side TESTNET/LIVE scale-in remains blocked until multi-lot conditional Algo protection is validated on the exchange. Existing One-way positions block another symbol-side entry; Hedge Mode opposite-side routing requires proven Hedge Mode state.
- Autonomous LIVE routing is explicitly disabled by `auto-trade-runtime` in v0.56.0 even if other local settings are populated.
- Existing deterministic client IDs, query-first recovery and no-blind-POST-retry semantics remain in force.

## Validation boundary

The v0.56.0 test suite uses local SQLite and mocked/fake account/exchange providers. It validates dispatcher ordering, deduplication, freshness, universe updates, risk admission, PAPER behavior, reservation ownership netting and external pending-order accounting. It does not execute private Binance calls or TESTNET/LIVE orders. Build host is Linux with Python 3.13.5; the package's `requires-python ==3.12.9` pin is unchanged. Windows 10 / Python 3.12.9 qualification is still pending.
