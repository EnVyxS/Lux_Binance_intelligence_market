# Build State v0.52.0

Baseline: v0.51.0 Aggregate Position Accounting & Fill Attribution.

## Verification

- Baseline regression before v0.52 changes: 850 passed.
- Final working-tree regression: 855 passed.
- `python -m compileall -q src tests`: PASS.
- Clean-extraction regression, CLI, version, and ZIP integrity are recorded in `CLEAN_EXTRACTION_TEST_REPORT_v0.52.0.md`.

## Implemented

- New `execution/protection.py` builds and validates quantity-scoped Binance USDⓈ-M STOP_MARKET / TAKE_PROFIT_MARKET Algo parameters.
- `ExecutionService` initial fill protection now uses exact observed fill quantity and correct One-way vs Hedge Mode flags.
- `PositionLifecycleExecutionAdapter.replace_stop()` creates exact-quantity STOP replacement orders and REST-verifies order fields before old-stop cancellation.
- Added paired, deterministic `RESIZE_PROTECTION` management actions for confirmed partial TP and partial market exits. New STOP and TP orders are query-first by deterministic clientAlgoId, exact-field validated, persisted into the execution ledger, and both must be active before old protection IDs are cancelled.
- On restart, `recover_pending_actions()` can route and reconcile `RESIZE_PROTECTION` actions without blindly retrying old POST requests.
- Reconciliation checks each signal allocation independently and requires its exact managed protective IDs and quantity. Legacy close-all orders are only accepted by the bounded singleton migration rule.
- Triggered Algo updates are no longer mistaken for fills on NEW/PENDING lifecycle updates. A triggered protection with a residual position keeps the sibling order in place and latches an entry halt for reconciliation.

## Intentionally not enabled / incomplete

- Same-side multi-signal execution and scale-in remain blocked.
- Full automatic SMC TradePlan -> global risk -> entry dispatcher wiring is not completed by this release.
- Fill evidence still needs a transactional REST/User Data Stream delta applier for signal-lot quantity changes.
- Partial-fill recovery originating directly from a protective Algo trigger remains an operator/reconciliation safety-halt case; this release only automates paired resize after confirmed PARTIAL_TP and partial market-exit fills.
- Telegram notifications/operator controls are not implemented here.

## Environment constraints

- Project target remains Windows 10 / Python 3.12.9 / 8 GB RAM.
- Build/test environment: Linux x86_64 / Python 3.13.5. The pinned `requires-python ==3.12.9` is unchanged.
- No Binance TESTNET/LIVE private API calls, orders, or exchange integration certification were performed.
