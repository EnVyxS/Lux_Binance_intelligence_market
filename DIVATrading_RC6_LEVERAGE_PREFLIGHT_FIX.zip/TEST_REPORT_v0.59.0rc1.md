# Test Report — v0.59.0rc1

## Source regression

`python -m pytest -q`: **1,038 passed**.

`python -m compileall -q src tests`: PASS.

`PYTHONPATH=src python -m divatrading --help`: PASS. Package import/version: PASS (`0.59.0rc1`).

## Added/updated coverage

- Account-specific leverage bracket/commission/available-margin risk sizing and risk-budget bounds.
- No quantity expansion to satisfy exchange minimum notional.
- Binance symbol margin/leverage read-before-write, open-position mutation block and exact readback.
- Income history seven-day window pagination, recursive split at full-page threshold, idempotent persistence, transfer cashflow exact Decimal and failure-safe watermark.
- Closed-lifecycle fill projection, funding allocation, fee handling, durable consecutive-loss state, daily Jakarta income PnL, unknown-income fail-closed behavior and reconstructed day-start equity.
- Runtime Telegram controls, owner authorization, persisted settings, restart-safe monotonically increasing update offset and explicit kill-latch reset.
- Existing strategy, dispatcher, account readiness, multi-lot lifecycle, stream-gap recovery, protective order and CLI regressions.

## Environment and scope

- Build/test host: Linux, Python 3.13.5.
- Declared target: Windows 10, Python 3.12.9 x64.
- Tests use deterministic fixtures, mocked exchange clients and local SQLite. No actual Binance account credentials, REST private session, User Data Stream, matching-engine order, Algo mutation or liquidation behavior was exercised.
- Wheel build was not produced: the build host is Python 3.13.5 while project metadata intentionally pins `==3.12.9`; no interpreter pin was relaxed to force a mismatched wheel.
- `auto-trade-runtime` intentionally rejects LIVE mode. This report is not LIVE acceptance or a profitability claim.
