# Next Task — v0.44.0 Global Risk, Execution & Position Lifecycle

## Objective

Wire v0.43 `QualifiedSignal` and `TradePlan` outputs into one exchange-truth, multi-symbol portfolio risk and execution system. Add the continuous account/order/position lifecycle supervisor.

## Required work

1. Create an account snapshot adapter for equity, available balance, margin, positions, open standard orders and open Algo Orders.
2. Add Binance User Data Stream lifecycle, listen-key refresh/reconnect, event persistence and REST reconciliation after reconnect.
3. Compute current open risk and notional from exchange-observed position quantity and protective stop; do not trust in-memory planner reservations as account truth.
4. Extend global coordinator to atomically reserve portfolio risk across symbols and re-check account snapshot freshness immediately before each submission.
5. Route `TradePlan` to existing PAPER-default `ExecutionService`; preserve deterministic client IDs and SQLite idempotency claims.
6. Complete entry state machine for NEW/PARTIALLY_FILLED/FILLED/CANCELED/EXPIRED/REJECTED/UNKNOWN and partial-fill remainder handling.
7. Protect only actual filled quantity with STOP_MARKET and TAKE_PROFIT_MARKET Algo Orders; verify protection against exchange open-algo inventory.
8. Add continuous position management: reduce-only partial TP, breakeven, trailing, SL/TP replacement, final close and realized/unrealized PnL reconciliation.
9. Add fail-closed behavior for stale account state, unknown order outcome, unknown position, missing bracket protection, exchange filter changes, API permission errors and disconnect/restart recovery.
10. Keep PAPER as default. TESTNET and LIVE require explicit separate local opt-ins; LIVE must require two independent local confirmations and remain disabled in packaged defaults.

## Non-goals

- No Stage 1–5 strategy-semantic changes.
- No profitability claim, walk-forward or calibration gate.
- No unguarded live trading or credentials in source/release.

## Deliverables

- v0.44.0 source ZIP and SHA-256.
- Release handoff, build state, clean-extraction report and test report.
- Explicit Windows target-runtime limitations.
