# Clean Extraction Test Report — v0.57.0B

## Archive

- Release: `DIVATrading_BinanceBot_SignedTestOrderValidation_0.57.0B.zip`
- Extracted to a new empty directory outside the source tree.
- ZIP CRC/integrity: PASS.
- Archive file count and SHA-256: recorded in `FINAL_RELEASE_VERIFICATION_v0.57.0B.md`, distributed alongside the release archive.
- Sensitive/runtime file audit: PASS. No `.env`, database, log, bytecode, `__pycache__`, `.pytest_cache`, virtual environment, or build output was packaged. `.env.example` and `.env.testnet.example` are included.

## Tests from extracted source

- Main regression excluding the legacy workflow module: **941 passed**.
- Legacy workflow module run separately with `-p no:ddtrace`: **7 passed**.
- Total clean-extraction regression: **948 passed across two runs**.
- Focused Stage B + Stage A TESTNET regression: **38 passed**.
- `python -m compileall -q src tests`: PASS.
- `python -m divatrading --help`: PASS.
- `python -m divatrading testnet-order-test --help`: PASS.
- `python -m divatrading testnet-preflight --help`: PASS.

The monolithic pytest run exceeded the execution time window while the legacy workflow suite was running. The legacy suite was rerun independently with `-p no:ddtrace` because the auto-loaded tracing plugin intermittently stalled pytest process shutdown after test assertions; all seven workflow tests passed. No test logic or project plugin was otherwise disabled. There were no test failures in the partitioned verification.

## Validation boundary

All exchange-facing tests use fixtures and mock HTTP. No actual Binance Demo credential, signed request, `/fapi/v1/order/test`, WebSocket session, actual Demo order, or LIVE request was used. Authenticated account validation remains pending until the operator can run the release locally with newly rotated Demo credentials.
