# DIVATrading Binance Futures — status implementasi dan handoff RC3

**Tanggal:** 15 November 2026  
**Versi:** `0.59.0rc3` (perbaikan di atas `0.59.0rc2`)  
**Target:** Binance USDⓈ-M perpetual futures, Windows 10 x64 / Python 3.12.9 / RAM 8 GB  
**Penilaian:** kandidat source yang telah diuji lokal, **BUKAN modul LIVE yang terkualifikasi**.

## 1. Inventaris: fitur yang sudah ada di source

- **Pasar dan universe:** metadata exchange / simbol USDT perpetual, mode AUTO dan MANUAL, Kline M1/M5/M15, mark price, aggregate trades, depth snapshot + diff-depth, Delta/CVD/absorption, restart/feed recovery dan SQLite.
- **Strategi:** SMC V2 menghasilkan kandidat OB/FVG, struktur, sweep, confluence/ranking; M1 dan M5 independen dengan M15 advisory. Kombinasi fitur tidak menyatakan performa trading yang sudah terbukti.
- **Planner/risk:** retracement LIMIT dan confirmation MARKET; SL/TP berbasiskan struktur/pivot atau fallback R; sizing Decimal, fee/funding/slippage reserves, risk reservation global, pembatasan leverage/margin, akun dan filter kontrak.
- **Execution/posisi:** private signed REST, order intent dan client ID deterministik, satu kali POST tanpa retry buta, fill/cancel-race reconciliation, conditional Algo STOP/TP, verifikasi stop/TP, partial fill, per-lot accounting, breakeven, trailing dan lifecycle supervision.
- **Akun/operasi:** stream akun privat, trade/income backfill, reconciliation, bot-only account isolation, pause/kill Telegram owner control, max-loss, ledger risiko dan diagnostic operator.
- **Tes/riset:** fixture/pytest, replay kronologis evidence, data-quality audit, import historis, PAPER simulation, optional Kronos shadow. Di PAPER, fill tidak meniru antrian order real.

## 2. Sudah diperbaiki khusus dalam RC3

1. **Commissioning risk TESTNET:** batas trade 0,10% dan portfolio 0,25% tidak lagi hanya mengandalkan argumen CLI pada startup. `TestnetCommissioningCaps` memeriksa persentase efektif (termasuk nilai tersimpan/Telegram) sebelum route, dan FIXED USDT dihitung terhadap fresh account equity.
2. **Account runtime failsafe:** task account supervisor dipantau selama market runtime aktif. Berhenti/gagal secara prematur akan melatch `entries_halted`, menghentikan proses entry, dan mengakhiri market runtime tanpa menganggap proteksi posisi sudah dicabut.
3. **Pre-POST entry halt:** durable `entries_halted()` dibaca ulang sebelum `new_order` POST untuk mengurangi race ketika readiness snapshot tertinggal; intent diblokir dan reservation dibebaskan bila halt sudah terpasang.
4. **Konsistensi lingkungan Demo:** dalam `auto-trade-runtime` mode TESTNET, REST market (metadata/history/depth) dan seluruh feed WebSocket (Kline, mark, aggTrade, depth) diarahkan ke Binance Demo seperti private execution. PAPER tetap memakai mainnet public feeds. Tidak lagi mengasumsikan harga mainnet sama dengan matching engine Demo.
5. **Startup feed graph:** `KlineRecoveryService` disetel menggunakan maksimum halaman yang tidak melampaui `HistoricalKlineService.max_pages`; konstruktor feed graph yang sebelumnya gagal pada konfigurasi default kini dapat dibuat. Pengujian konstruksi per feed ditambahkan.

## 3. Masih dalam pengembangan (bukan pengujian lulus)

- Post-fill actual risk dan overshoot vs initial reservation saat slip/partial fill; proteksi harus dievaluasi terhadap posisi sesungguhnya dan senario penolakan/timeout exchange.
- Pre-trade executable bid/ask, batas spread & slippage dan order price cap; maker/IOC plan; SL volatilitas, net-RR minimum, setup expiry/invalidation, opposing OB; semantics MARKET dengan mark price masih rawan perbedaan harga eksekusi.
- Account supervisor, reconciliation dan kill-switch perlu fault injection yang lebih luas dengan state nyata; cakupan tes mock tidak memastikan semua perilaku Binance.
- Windows installer/runtime dan Python 3.12.9 exact environment; filter, symbols, account mode/hedge/leverage di akun pengguna; readiness handshake Demo; conditional Algo accepted/rejected/triggered di exchange.
- OOS/walk-forward setelah biaya transaksi riil; equity curve, expectancy, profit factor dan drawdown belum membuktikan adanya edge.

## 4. Baru rancangan, masih belum dikerjakan penuh

- Aktivasi penuh multi-pair LIVE dan release gate/qualified deployment.
- Template pembukaan order maker→IOC bounded, TP extension/early exits berbasis order-flow/opposing SMC state secara end-to-end.
- Kalibrasi expectancy dan probabilitas SMC score sebagai win probability.
- Dashboard/GUI operator yang lengkap dan automasi release berkelanjutan; sebagian kontrol Telegram sudah ada, tetapi bukan berarti UI akhir selesai.

## 5. Pengujian yang dilakukan

- Arsip masukan `v0.59.0rc2` melalui suite lokal: **1.046 passed**.
- Pembenahan risk/account/recheck awal: **1.052 passed**.
- RC3 setelah perbaikan feed/environment isolation: rujuk hasil final **`AUDIT_TEST_RESULT_RC3.txt`** untuk hitungan final.
- Python/Linux di container ini, bukan Python 3.12.9 Windows. Tidak dilakukan network call akun pengguna, read-only LIVE preflight, atau penempatan order TESTNET/LIVE. Tes yang mengandung nama exchange menggunakan mock, bukan verifikasi matching engine.

## 6. Keamanan & deployment operator

- Default config `.env` adalah `DIVA_EXECUTION_MODE=PAPER`, dan TESTNET/LIVE order opt-in default `false`.
- Untuk PAPER: jalankan `INSTALL_WINDOWS.bat`, `TEST_WINDOWS.bat`, `RUN_WINDOWS.bat`, lalu command `auto-trade-runtime` secara lokal; monitor posisi/ledger. PAPER bukan simulasi PnL realistis.
- Untuk read-only akun LIVE, setelah memastikan API permission/IP whitelist/akun khusus BOT_ONLY dan menyiapkan `.env` **hanya di PC**, gunakan `DIVA_EXECUTION_MODE=LIVE`, `DIVA_LIVE_TRADING_ENABLED=false`, `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true`, lalu `python -m divatrading live-read-only-preflight --symbols BTCUSDT`. Tidak menempatkan order.
- Untuk Demo TESTNET, siapkan kredensial Binance Demo khusus, jalankan preflight Stage A dan signed `/order/test` Stage B lebih dulu. Order TESTNET Stage C mengharuskan izin operator lokal dan `--mode MANUAL --symbols ONE_SYMBOL --max-symbols 1` dengan batas 0,10%/0,25%. Jangan aktifkan sampai preflight dan lingkungan akun benar-benar lolos.
- Jangan kirim key atau Telegram token ke chat; arsip tidak mengandung `.env`, kunci, atau saldo akun.

## 7. Blocker menuju release LIVE yang sah

A. Validasi Windows 10 + Python 3.12.9 dan arsip clean-extraction beserta hash.  
B. Kontrol aktual risiko setelah setiap fill + audit order rejection and missing protection.  
C. Siklus nyata matching engine Binance Demo satu simbol: entry, fill, STOP, TP, partial, cancel race, stream disconnect, ledger restart, emergency stop, final flat.  
D. Uji strategi OOS dan profil slippage/fees/funding sebelum dinyatakan layak finansial.  
E. Read-only preflight di akun pengguna sendiri, account isolation, lalu approval lokal LIVE dalam rilis terpisah dengan kill-switch dan rollback teruji.

**Jangan menghapus hard block `Autonomous LIVE routing remains disabled` hanya untuk mengubah label kesiapan.** Bersih dari error unit test tidak menjamin keamanan dana atau kinerja strategi. Detail kronologi rilis terdahulu: `AUDIT_PROYEK_ID.md` dan `ROADMAP_FULL_AUTO_TRADING.md`.
