# Test Report — v0.56.0

## Environment

- Linux container
- Python 3.13.5
- Project metadata requires Python `==3.12.9`; pin unchanged
- All tests use local SQLite and mocked/fake API/account providers

## Results

- Full regression suite: **906 passed**
- Focused `tests/test_autonomous_dispatcher.py`: **13 passed**
- `python -m compileall -q src tests`: PASS
- CLI parser help: PASS for `auto-trade-runtime`, `market-runtime`, `account-runtime`, `runtime-status`
- Package version bump to 0.56.0: verified during release build

## Coverage highlights

- Durable signal claim precedes snapshot provider I/O.
- Duplicate signal does not capture a second snapshot or repeat execution.
- Stale/future snapshots and expired signals fail closed before risk reservation/entry. Signal age and entry-halt are rechecked after snapshot capture, so a slow REST snapshot cannot route an expired signal or bypass a halt added during capture.
- Selected exchange instruments are published to coordinator before market workers start.
- SMC qualification-only mode defers final sizing to the global coordinator.
- PAPER deterministic fill creates quantity-scoped virtual protection, managed position and retained reservation.
- DIVA-owned positions with active lot reservations are not double-counted as external notional.
- Unmatched position quantities and unknown external open orders are charged conservatively; unpriced external orders fail closed.
- Existing execution/account readiness, idempotency, protection and multi-lot supervisor regressions remain passing.

## Explicit exclusions

No private Binance REST/WebSocket session, TESTNET order or LIVE order was executed. No Windows 10 / Python 3.12.9 validation was performed. Passing mocked tests does not establish profitability or production readiness.
