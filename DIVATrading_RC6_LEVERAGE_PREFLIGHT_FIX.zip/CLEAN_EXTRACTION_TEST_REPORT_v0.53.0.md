# Clean Extraction Test Report — v0.53.0

## Artifact

- Archive: `DIVATrading_BinanceBot_ProtectivePartialFillReconciliation_0.53.0.zip`
- Archive layout: project root (`pyproject.toml`, `src/`, `tests/`, docs and Windows scripts) at archive root.
- Contents: 302 files; ZIP integrity check passed.
- Excluded: `.env`, virtual environments, databases, runtime logs/data, bytecode and test/cache directories.

## Clean environment verification

The archive was extracted into a new empty directory separate from the build source tree.

- Full regression suite from clean extraction: **863 passed**.
- Focused lifecycle execution + User Data Stream suite: **64 passed**.
- `python -m compileall -q src`: PASS.
- `python -m divatrading --help`: PASS.
- Imported package version: `0.53.0`.
- Python used: 3.13.5 on Linux.

## Scope and limitations

- All exchange-facing tests use mocked clients and local SQLite.
- No real Binance TESTNET/LIVE private REST request, WebSocket session or order was executed.
- Windows 10 / Python 3.12.9 / 8 GB validation has not been performed.
- The source pin `requires-python ==3.12.9` was preserved.

This report is included in the release archive. The final archive was re-extracted and the verification suite rerun after adding this report.
