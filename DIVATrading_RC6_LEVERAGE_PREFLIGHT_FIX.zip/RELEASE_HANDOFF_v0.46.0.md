# DIVATrading Release Handoff — v0.46.0

## Release identity

- Package: `DIVATrading_BinanceBot_UserDataStreamReconciliation_0.46.0.zip`
- Version: `0.46.0`
- Scope: USDⓈ-M User Data Stream + exchange/account reconciliation + TESTNET/LIVE account readiness gate.
- Prior baseline: v0.45.0 Atomic Portfolio Risk Reservations.

## Architecture changes

New modules:

- `divatrading.execution.user_data_stream`: listenKey lifecycle, WebSocket reconnect/rotation, event validation, durable event dispatch.
- `divatrading.execution.reconciliation`: exchange/local positions and order/protection comparison, event-watermark handling, fail-closed entry readiness.
- `divatrading.execution.account_runtime`: runs the private account stream with periodic reconciliation.

Extended modules:

- `binance_private.py`: listenKey create/keepalive/close REST endpoints.
- `ledger.py`: idempotent raw event store, partial projections, stream/reconciliation state, atomic readiness snapshot.
- `service.py` and `coordinator.py`: require fresh account readiness and matching active portfolio reservation for TESTNET/LIVE orders.
- `cli.py`: `account-runtime` command.

## Runtime contract

Start the account runtime only in an explicitly selected TESTNET/LIVE environment. It does not generate new entries. When supplied with the execution service, it may resolve a previously pending exchange order and protect an exchange-confirmed fill with STOP/TP orders. Do not run simultaneous duplicate account-runtime processes against the same account/ledger.

Reconciliation mismatch halts new entries. It does not auto-flatten the account or silently cancel unknown manual orders. An operator must resolve discrepancies and explicitly clear the entry halt through the controlled service interface; a later successful reconciliation is still required before the readiness gate can pass.

A new account/order/trade stream event invalidates reconciliation READY. REST account reads are sequential rather than atomic; the persisted stream watermark blocks a READY result when an event races the REST capture/commit.

## Safety defaults

- PAPER remains the default.
- No secrets, `.env`, runtime SQLite database, or exchange credentials are packaged.
- TESTNET/LIVE require existing explicit opt-in guards, a matching active global risk reservation, CONNECTED User Data Stream, and a fresh READY reconciliation.
- `DIVA_REQUIRE_ACCOUNT_READINESS=true` by default for non-PAPER modes.
- No real Binance request or order test was run for this release.

## Tests

- Full suite: 779 passed.
- Focused new suite: 17 passed.
- Compileall and CLI help: PASS.
- Clean extraction retest is recorded outside the ZIP in `CLEAN_EXTRACTION_TEST_REPORT_v0.46.0.md`.

## Outstanding work (next checkpoint)

1. Position lifecycle state machine: partial TP, breakeven, trailing and dynamic exits.
2. Verified terminal/flat reconciliation and safe risk-reservation release.
3. Exchange mismatch remediation policy, order ownership classification and recovery controls.
4. Persistent account-runtime watchdog, process locking and service orchestration.
5. Dashboard/Telegram alerts and guarded operator controls.
6. Windows 10 / Python 3.12.9 installation and target hardware validation.

## Recovery starting point

Read this handoff, `BUILD_STATE_v0.46.0.md`, `TEST_REPORT_v0.46.0.md`, `USER_DATA_STREAM_V046.md`, and `RISK_RESERVATIONS_V045.md` before continuing. The current source release is the authoritative baseline; do not reconstruct the project from chat history alone.
