# Final Release Verification — v0.58.0rc3

- Package metadata and import version: `0.58.0rc3`.
- Read-only LIVE preflight is pinned to `https://fapi.binance.com`.
- Explicit opt-in required: `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true`.
- `DIVA_LIVE_TRADING_ENABLED` must remain `false`.
- Preflight makes read-only requests only; no trading or account-setting write methods are called.
- Active positions and any open standard/Algo orders block initial clean-account onboarding.
- Targeted tests: 23 passed; compileall and CLI help passed.
- Full regression not claimed; see test report.
- No credentials or `.env` included.
- Windows target qualification and real-account read-only run remain outstanding.
