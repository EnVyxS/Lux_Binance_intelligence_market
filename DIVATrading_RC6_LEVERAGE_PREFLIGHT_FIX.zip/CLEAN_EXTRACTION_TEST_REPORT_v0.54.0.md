# Clean Extraction Test Report — v0.54.0

## Artifact under test

- Archive: `DIVATrading_BinanceBot_RESTTradeBackfill_0.54.0.zip`
- Extraction: new empty `clean_extraction/` directory, separate from the build workspace.
- Runtime: Linux / Python 3.13.5.

## Results

- ZIP integrity test: PASS.
- Full regression from extracted source: **875 passed in 15.15s**.
- `python -m compileall -q src`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -m divatrading account-runtime --help`: PASS.
- Package import/version: PASS (`0.54.0`).
- Release archive audit: no `.env`, database, log, `.pyc`, `__pycache__`, `.venv`, or pytest cache artifacts included.

No actual Binance TESTNET/LIVE private API request or order was executed. Windows 10 / Python 3.12.9 validation remains pending.
