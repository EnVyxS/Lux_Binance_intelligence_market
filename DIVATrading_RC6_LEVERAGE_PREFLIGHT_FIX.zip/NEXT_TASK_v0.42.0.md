# Next Task — v0.42.0 Production Feed Graph & Live Market Capture

## Objective
Replace the v0.41 injected feed seam with a production `feed_factory` that composes the existing Binance public services into a single validated per-symbol capture stream.

## Required work
1. Instantiate M1/M5/M15 Kline websocket + REST backfill/recovery per symbol.
2. Instantiate Mark Price feed per symbol.
3. Instantiate aggregate-trade websocket, bootstrap/recovery, storage/fanout and Delta/CVD per symbol.
4. Instantiate depth snapshot/diff supervisor with correct update-ID sequencing and stale-data health.
5. Build `StrategyMarketDataAdapter` inputs from real service snapshots; preserve closed-candle chronology and expose component readiness.
6. Convert only complete validated snapshots into `ScalpingMarketDataView`; never fabricate missing fields or mark degraded data READY.
7. Enforce subscription caps, queue caps, controlled REST weight, cancellation and graceful reconnect.
8. Add runtime CLI/config for `market-runtime` with explicit read-only designation.
9. Keep v0.41 runtime supervisor as the lifecycle owner; do not change SMC Stage 1–5 rules.

## Boundary
This stage remains read-only. No order placement. Continue only after source-level integration and offline tests are complete; live connectivity is user-run later.
