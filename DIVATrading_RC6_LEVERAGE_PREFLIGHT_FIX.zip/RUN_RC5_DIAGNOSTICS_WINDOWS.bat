@echo off
setlocal
call "%~dp0RUN_RC6_DIAGNOSTICS_WINDOWS.bat"
exit /b %errorlevel%
