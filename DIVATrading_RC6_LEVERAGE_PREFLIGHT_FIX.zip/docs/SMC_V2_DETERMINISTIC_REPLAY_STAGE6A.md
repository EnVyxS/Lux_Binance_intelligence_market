# SMC V2 — Deterministic Historical Replay Harness (Stage 6A)

**Release:** Unit 05E v0.31.0  
**Baseline:** Stage 1–5 engines from v0.30.0; replay driver introduced in v0.31.0  
**Scope:** evidence-only, historical, single-symbol replay  
**Runtime target:** Windows 10 / Python 3.12.9 64-bit; verification in this checkpoint uses Python 3.13.5 / Linux.

## 1. What Stage 6A implements

Stage 6A adds a deterministic, bounded chronological driver for the existing SMC V2 Stage 1–5 engines. It does not change their detection rules or defaults. For each symbol it reads native Binance USDⓈ-M Klines, advances a UTC replay clock, constructs a same-capture immutable market-data view, and runs:

1. Stage 1 — data contract/readiness adapter;
2. Stage 2 — market structure;
3. Stage 3 — displacement and initial OB formation;
4. Stage 4 — OB lifecycle;
5. Stage 5 — liquidity references/sweeps and FVG evidence.

M1 and M5 remain independent streams. M5 is the primary setup source; M1 is independent and remains available for its own structural evidence/entry-timing research. M15 is optional advisory context only. It never vetoes or arbitrates M1/M5. There is no legacy nested M5/M15 OB priority.

The output is an evidence ledger and descriptive end-of-run summary. Stage 6A does **not** generate qualified trade setups, entries, orders, fills, SL/TP, fees, slippage, PnL, win rate, expectancy or profitability claims. OB mitigation and FVG fill are state observations, not exchange fills.

## 2. Source modules and public API

- `divatrading.replay.manifest`: `ReplayKlineFile`, `ReplayMetadataSnapshot`, `ReplayDatasetManifest`, `ReplayManifestError`, `sha256_file`.
- `divatrading.replay.klines`: `iter_binance_kline_rows`, `iter_manifest_klines`, `iter_kline_chunks`, `iter_rest_klines`, `ReplayKlineReadError`.
- `divatrading.replay.engine`: `ReplayConfig`, `HistoricalReplayRunner`, `ReplayRunSummary`, `ReplayRunnerError`.
- `divatrading.replay`: exports the public types/functions above.

Prices and quantities remain existing `Decimal`-based `Kline` values. Times remain UTC Unix milliseconds. Native Kline rows must follow Binance's 12-column contract; the reader accepts a CSV/TXT file or a ZIP containing exactly one CSV member. Header rows are optional. A malformed row, duplicate/decreasing open time, wrong symbol/interval, or invalid candle fails closed.

`iter_rest_klines()` adapts the existing `HistoricalKlineService`; REST page retrieval is bounded and typed. It preserves gaps and does not synthesize missing candles. The replay CLI itself consumes a local manifest/source files; it does not silently download data.

## 3. Dataset root and manifest

A dataset root can contain daily/monthly Binance archive files and one manifest. Example layout:

```text
 data/BTCUSDT_2025/
   BTCUSDT-1m-2025-01.zip
   BTCUSDT-1m-2025-02.zip
   BTCUSDT-5m-2025-01.zip
   BTCUSDT-5m-2025-02.zip
   BTCUSDT-15m-2025-01.zip       # optional
   BTCUSDT-15m-2025-02.zip       # optional
   manifest.json
```

Every file entry has its interval, relative path, SHA-256, row count, first/last open time and source URL. File paths may not escape the dataset root. Source files for the same interval may not overlap; chronological gaps are allowed and become explicit replay events. The dataset time window is `[start_open_time_ms, end_open_time_ms)` based on Kline open times. Every included row must lie inside it. For each supplied interval, both boundaries must align to that native timeframe, the first file row must begin exactly at the dataset start, and the last row must be the final fully closed candle ending at the dataset boundary. This prevents a final M5/M15 candle from extending beyond the declared evaluation window. Internal gaps are allowed and explicitly emitted; leading/trailing partial coverage is rejected. Native M1 and M5 are mandatory; native M15 is optional and must not be fabricated from M1/M5.

### Metadata quality and strict mode

The manifest stores one exact Binance symbol object, source URL, capture time, canonical metadata hash, and (for historical quality) effective-from/effective-to timestamps. Exact `PRICE_FILTER.tickSize` is mandatory; `pricePrecision` is not a substitute.

- `HISTORICAL_EFFECTIVE`: creator declares the snapshot effective over the entire dataset window. Strict replay requires this quality and full interval coverage.
- `CURRENT_SNAPSHOT_ONLY`: diagnostic-only. It is accepted only with the explicit `--allow-current-metadata` override and must not be used for strict historical tick-dependent calibration.
- `MISSING_OR_CONFLICTED`: rejected, including diagnostic mode, because an exact non-conflicted tick grid is unavailable.

**Important limitation:** v0.31.0 supports exactly one metadata snapshot per dataset and requires it to cover the whole dataset period. It does not support an effective-dated timeline with multiple `tickSize` changes. The `HISTORICAL_EFFECTIVE` label is supplied by the dataset author; this code validates the declared interval and metadata identity but cannot independently prove that the historical exchange rule was truly effective. Keep the underlying source evidence and provenance. If tick size changed during the selected period, split the replay into metadata-homogeneous datasets or wait for a later metadata-timeline implementation. Never treat today's `exchangeInfo` as proof of an old tick size.

### Creating a manifest (Python API)

The caller supplies exact symbol metadata from the appropriate source and declares its quality. `effective_to_ms` is exclusive. The example intentionally does not fetch metadata or claim historical effectiveness:

```python
import json
from pathlib import Path

from divatrading.replay import (
    ReplayDatasetManifest,
    ReplayKlineFile,
    ReplayMetadataSnapshot,
)

root = Path(r"data/BTCUSDT_2025")
symbol_info = json.loads((root / "BTCUSDT_symbol_info.json").read_text(encoding="utf-8"))
metadata = ReplayMetadataSnapshot.from_symbol_payload(
    symbol_info,
    quality="HISTORICAL_EFFECTIVE",  # only assert when independently evidenced
    source_url="<source URL for the retained metadata evidence>",
    captured_at_ms=1_735_689_600_000,
    effective_from_ms=1_735_689_600_000,
    effective_to_ms=1_738_368_000_000,
)
files = tuple(
    ReplayKlineFile.inspect(
        root, filename, interval, symbol="BTCUSDT",
        source_url="<original Binance archive or REST provenance>",
    )
    for interval, filename in (
        ("1m", "BTCUSDT-1m-2025-01.zip"),
        ("1m", "BTCUSDT-1m-2025-02.zip"),
        ("5m", "BTCUSDT-5m-2025-01.zip"),
        ("5m", "BTCUSDT-5m-2025-02.zip"),
    )
)
manifest = ReplayDatasetManifest(
    symbol="BTCUSDT",
    start_open_time_ms=1_735_689_600_000,
    end_open_time_ms=1_738_368_000_000,
    files=files,
    metadata=metadata,
)
manifest.write(root / "manifest.json")
```

Replace placeholder URLs/timestamps and file names with the retained source evidence and actual UTC window. Do not copy the sample's dates as an assertion about your data. `ReplayKlineFile.inspect()` calculates local row counts/ranges and SHA-256; it does not authenticate the source publisher.

## 4. Replay clock, captures and Stage pipeline

For each Kline, the event becomes visible at `close_time_ms + 1 ms`. A candle is eligible only when `close_time_ms < captured_at_ms`. When two or more intervals close at the same clock boundary, their newly closed candles enter one capture. No forming/future candle is passed into the current view.

Capture IDs and run IDs are deterministic from the dataset identity, engine configuration, source code tree/version and clock policy. Each JSONL record carries the replay/capture identity, dataset identity, symbol, known-at time, sequence and stage. The run header stores config/code/metadata/source-file hashes, dataset window, software version, engine configuration and clock policy.

The runner keeps bounded rolling Kline histories (`max_history_candles`, allowed 2–2000; default 1000) and uses the existing engine capacity limits. It streams JSONL to disk; `run_to_jsonl()` is a convenience API for small synthetic fixtures, not a recommended large-history path. A single runner instance is single-symbol and sequential; run separate manifests/runners for additional symbols.

### Gap behavior

No candle is interpolated or forward-filled. When a later candle exposes a missing interval, the runner emits `REPLAY_DATA_GAP`, resets only the affected symbol/timeframe in Stages 2–5, clears that timeframe's bounded window and waits for readiness/warm-up again. M1, M5 and M15 are independent; M15 cannot block M1/M5. Source files themselves must be strictly chronological; duplicates/revisions are rejected. Cross-file overlap is rejected at manifest validation.

The current runner records the gap at detection time (the first later candle), not at an artificial missing-candle timestamp. It does not reconstruct unknown price action inside the gap. Downstream evidence is only valid after the relevant engine reports readiness again.

### End-of-file

Active OB/FVG state at the end of the selected data window is right-censored. It is not relabelled expired, invalidated or filled merely because the file ended. The final summary reports right-censored counts.

## 5. JSONL ledger records

The ledger begins with `REPLAY_RUN_HEADER`, then chronologically emits Stage 1–5 evidence and control records, and ends with `REPLAY_RUN_SUMMARY` on a completed run. Record families include:

- `BAR_TRACE` and structure/event evidence;
- `OB_FORMATION_TRACE` and `ORDER_BLOCK_CANDIDATE`;
- `OB_LIFECYCLE_TRACE` and `ORDER_BLOCK_LIFECYCLE` state snapshots/deltas;
- `LIQUIDITY_REFERENCE`, `LIQUIDITY_SWEEP`, `LIQUIDITY_FVG_TRACE` and FVG state evidence;
- `REPLAY_DATA_GAP` and `REPLAY_CAPTURE_SUMMARY`;
- final `REPLAY_RUN_SUMMARY`, including capture/gap and right-censored counts.

Stable JSON key ordering and decimal strings make ledger bytes deterministic for a fixed manifest/config/code. A changed future source row changes the whole source-file hash, dataset ID and run/capture identity by design; the anti-look-ahead property is that strategy evidence known before that future row must remain unchanged.

## 6. Checkpoint and restart semantics

`run_to_file()` can write an optional checkpoint every configured number of captures. A checkpoint binds the dataset/run/config/code hashes, last capture timestamp, capture count, JSONL byte offset, SHA-256 of the durable ledger prefix and completion flag. Resume requires the original ledger and checkpoint, validates the identity, durable prefix SHA-256 and newline boundary, truncates any bytes after the durable offset, then deterministically replays from the beginning to rebuild all engine state through the checkpoint. It skips rewriting the verified prefix and appends the new suffix.

This is deliberately conservative: restart does not serialize private mutable engine internals. It reconstructs state from source and can therefore take time proportional to the prefix length. The ledger/checkpoint pair must remain together with the exact manifest and source files. A completed checkpoint cannot be resumed. A different manifest, configuration, code tree or version is rejected.

## 7. CLI

From the project root (PowerShell):

```powershell
# Validate manifest, source hashes, row counts/ranges and metadata eligibility
.\.venv\Scripts\python.exe -m divatrading replay-validate `
  --manifest .\data\BTCUSDT_2025\manifest.json `
  --root .\data\BTCUSDT_2025

# Run strict evidence-only replay
.\.venv\Scripts\python.exe -m divatrading replay-run `
  --manifest .\data\BTCUSDT_2025\manifest.json `
  --root .\data\BTCUSDT_2025 `
  --ledger .\logs\BTCUSDT_2025.jsonl `
  --checkpoint .\logs\BTCUSDT_2025.checkpoint.json `
  --max-history-candles 1000 `
  --checkpoint-every-captures 1000

# Resume an interrupted run with the exact same input/config/code
.\.venv\Scripts\python.exe -m divatrading replay-run `
  --manifest .\data\BTCUSDT_2025\manifest.json `
  --root .\data\BTCUSDT_2025 `
  --ledger .\logs\BTCUSDT_2025.jsonl `
  --checkpoint .\logs\BTCUSDT_2025.checkpoint.json `
  --resume
```

Diagnostic-only metadata override:

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-run `
  --manifest .\data\BTCUSDT_current_snapshot\manifest.json `
  --ledger .\logs\BTCUSDT_diagnostic.jsonl `
  --allow-current-metadata
```

The diagnostic output is tagged `CURRENT_SNAPSHOT_ONLY`; do not use it as strict historical tick-grid evidence. The default CLI configuration uses the M15 files in the manifest if present and max history 1000. The current CLI exposes those bounded settings and strict/diagnostic metadata selection; detailed engine parameter sweeps remain a later stage.

## 8. Verification and exclusions

Stage 6A's synthetic focused suite covers manifest/schema/hash validation, aligned/full-window boundary checks, strict metadata rejection, deterministic evidence output, simultaneous M1/M5 close alignment, closed-candle causality, gap isolation, restart equivalence, mismatched resume rejection, corrupted-prefix checkpoint rejection, future-perturbation prefix invariance, independent M1/M5 streams, chunk-size invariance and bounded REST page iteration.

The Stage 6A unit tests prove implementation mechanics only. No large Binance dataset has been replayed in this checkpoint. No historical tick-size timeline or real retained dataset bundle is included. No Windows 10/Python 3.12.9 execution, live Binance connectivity, CVD/depth/absorption replay, Pine runtime parity, trade outcome modelling, fill simulation or profitability has been verified.

Not implemented: candidate qualification/scoring/ranking, evidence hard gates, OB retest/entry models, dynamic Entry/SL/TP, fees/slippage, fills, PnL, position sizing/management, CVD/Depth/Absorption integration, private API, live orders, Telegram/dashboard or SQLite migration. SQLite remains schema v5.
