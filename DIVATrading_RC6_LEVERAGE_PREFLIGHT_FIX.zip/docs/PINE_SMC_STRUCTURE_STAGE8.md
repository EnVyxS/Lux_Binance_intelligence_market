# Unit 05D Stage 8 — Pine Baseline Entry / SL / TP Proxy Geometry

## Scope and source

Stage 8 implements the local level calculation and signal-record construction inside `f_smc()` after the first Stage-6 candidate is selected and its Stage-7 score is calculated. Primary Pine source: `Sniper_SMC_MTF_Enhanced.pine`, level inputs at lines 56–66 and signal-level logic approximately lines 612–684.

This is still the Pine indicator's historical proxy. `entry_proxy` is the source candle `close`; it is not a Binance Bid/Ask, exchange fill, average fill, or position entry. The signal/level trace is unshifted at this stage. Stage 9 will apply the source's one-bar output shift and MTF arbitration.

## Configuration mapping

| Pine input / series | Python config | Default | Pine range / behavior |
|---|---|---:|---|
| `syminfo.mintick` | `tick_size` | unavailable | Exact positive Binance USD-M `PRICE_FILTER.tickSize`; never inferred from OHLC precision |
| `slBufferAtr` | `sl_buffer_atr` | 0.10 | `>= 0` |
| `slSpreadMult` | `sl_spread_mult` | 2.0 | `>= 0` |
| `maxSLAtr` | `max_sl_atr` | 3.0 | `>= 0.5` |
| `maxSpreadSLPct` | `max_spread_sl_pct` | 20.0 | `>= 0` |
| `highVolSLMult` | `high_vol_sl_mult` | 1.50 | `[1.0, 3.0]` |
| `tpMode` | `tp_mode` | `Fixed RR` | `Fixed RR`, `Structure`, `Hybrid OB/Liquidity` |
| `rr` | `rr` | 2.0 | `>= 0.25` |
| `minRR` | `min_rr` | 1.5 | `>= 0.25` |
| `spreadEstimateTicks` | `spread_estimate_ticks` | 0.0 | `>= 0` |
| `minStopTicks` | `min_stop_ticks` | 1.0 | `>= 0` |
| `consumeOBOnSignal` | `consume_ob_on_signal` | true | Boolean signal-based OB-used proxy |

When `tick_size` is absent, Stage-7 scoring and Stage-8 level geometry are unavailable. No SL/TP level is fabricated. Earlier SMC structure/lifecycle stages remain usable without tick size.

## Exact level sequence

After Stage 6 returns its first candidate and Stage 7 supplies the matching `chosen_score`:

1. Validate that the Stage-7 chosen-score index and OB identity match the Stage-6 selected OB. A mismatch is a replay consistency error.
2. Set `entry = close` for the source candle. Keep this field explicitly named `entry_proxy`.
3. Calculate `spreadPrice = spreadEstimateTicks * tickSize`.
4. Calculate `regimeBufferMult = highVolSLMult` only when volatility regime is enabled and the pre-current-bar `atrRatioNow >= highVolRatio`; otherwise use `1.0`. `atrRatioNow` is the Stage-4 trace value calculated with the previous-bar custom ATR(200), matching the Pine order.
5. Calculate `buffer = max(spreadPrice * slSpreadMult, atrFastNow * slBufferAtr) * regimeBufferMult`.
6. Bullish structural stop is `OB.bottom - buffer`; bearish structural stop is `OB.top + buffer`.
7. Calculate directional `slDist`. Pine continues only when `slDist > 0`; non-positive distance is rejected before minimum-stop adjustment.
8. Calculate `minDist = minStopTicks * tickSize`. If `slDist < minDist`, set `slDist = minDist` and rebuild SL from entry in the stop direction.
9. Start `levelsOK` with both strict gates: reject if `atr200 > 0 && slDist > maxSLAtr * atr200`; reject if `spreadPrice > slDist * maxSpreadSLPct / 100`.
10. Structural liquidity target is the tracked swing range top for bullish only when it is above entry, or range bottom for bearish only when it is below entry.
11. Hybrid opposing-OB scan traverses the full current active array oldest-to-newest, including used OBs. Bullish chooses the nearest bearish OB bottom above entry (`min`); bearish chooses the nearest bullish OB top below entry (`max`).
12. `Fixed RR` uses `entry +/- slDist * rr`; the separate `minRR` input is not an additional Fixed-RR gate.
13. `Structure` uses only the directional structural target and requires positive reward plus `finalReward / slDist >= minRR`.
14. `Hybrid OB/Liquidity` prefers the opposing OB, otherwise structural liquidity. If that target is unavailable, non-directional, or below `minRR`, fall back to fixed RR. The fallback is rejected if it would pass through the known opposing OB: bullish `opposingOBTarget < fallbackTarget`; bearish `opposingOBTarget > fallbackTarget`.
15. Require target availability and strictly positive directional reward. Only if all level gates pass is a local Pine signal proxy emitted.
16. If `consume_ob_on_signal` is enabled, set the selected active OB's `used=true` only after every level gate passes. If levels fail, `used` remains unchanged. This is the Pine indicator's signal-consumption proxy, not exchange fill-based consumption.

The selected Stage-6 candidate is not replaced if its levels fail. Pine does not retry the next OB after the first trigger/sweep candidate has been chosen.

## Immutable output contract

- `PineSmcSignalProxy`: source event timestamp (candle open time), direction, trigger code, selected active-array index and pre-consumption OB snapshot; entry/SL/TP proxies; spread/buffer/stop geometry; structural/opposing-OB target context; target source, final reward/RR, Stage-7 score and ideal-band references; explicit `ob_consumed_by_signal_proxy` flag.
- `PineSmcLevelEvaluationTrace`: whether geometry was attempted/available/accepted, chosen candidate/trigger, rejection reasons, intermediate level values, proxy-consumption status and optional signal record.
- `PineSmcBarTrace.level_evaluation` is included in deterministic JSONL. The per-bar `active_order_blocks` snapshot is built after Stage-8 consumption, so it reflects the post-signal `used` state. Stage-5/6 candidate traces and Stage-7 score inputs remain the pre-consumption snapshots used during evaluation.
- The level trace is local to one `request.security` source context and remains unshifted. Stage 9 owns confirmed output shift, chart context and M1/M5/M15 arbitration.

## Exclusions

No one-source-bar `[1]` output shift, request.security lookahead reproduction, MTF nesting/arbitration, CVD/order-flow filter, Dynamic Entry/SL/TP, actual exchange fill, position management, private API, order placement, Telegram/dashboard, risk sizing, or SQLite migration is introduced here.

## Tests

`tests/test_pine_smc_level_geometry.py` covers configuration validation; long/short close proxies and structural stops; spread/ATR and high-volatility buffers; minimum-stop adjustment; non-positive stop rejection; strict max-SL and spread percentage boundaries; Fixed RR's `minRR` semantics; Structure target and minRR; Hybrid nearest opposing OB, structural fallback, minRR fallback and obstacle rejection; no retry of a later candidate; missing tick/ATR fail-closed; score-to-candidate identity; consume opt-out and successful-only mutation; immutable signal/trace serialization; and no-candidate behavior.

Stage 8 tests are deterministic source-derived implementation checks. They are not independent TradingView runtime parity observations.
