# Sources — Unit 04B

- Binance USDⓈ-M Futures REST API, Market Data, Compressed/Aggregate Trades List: https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
  - `GET /fapi/v1/aggTrades`
  - `fromId` is inclusive.
  - IP request weight: 20.
  - Maximum `limit`: 1,000; default: 500.
  - Current documentation states only history within the previous 48 hours is queryable.
  - Do not combine `fromId` with `startTime`/`endTime` because the docs warn this can cause a response timeout.
  - REST payload fields include `a`, `p`, `q`, `nq`, `f`, `l`, `T`, `m`; `nq` excludes RPI orders.

- Binance USDⓈ-M Futures WebSocket Aggregate Trade stream (Unit 04A): https://developers.binance.com/docs/derivatives/usds-margined-futures/websocket-market-streams/Aggregate-Trade-Streams

No credentials, private API endpoints or user account data are required for Unit 04B.


## Unit 04D — Order Book Depth & Book Imbalance

- Binance USDⓈ-M Futures REST Market Data, Order Book: https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
  - `GET /fapi/v1/depth`; supported snapshot limits `5, 10, 20, 50, 100, 500, 1000`; request weight scales by limit.
- Binance USDⓈ-M Futures WebSocket Market Streams, Diff Book Depth: https://developers.binance.com/docs/derivatives/usds-margined-futures/websocket-market-streams/Diff-Book-Depth-Streams
  - Diff-depth stream fields include `U`, `u`, `pu`, `E`, `T`, `b`, and `a`; the Futures local-book sequence is based on `pu` continuity after the initial snapshot bridge.
- Binance Futures public depth does not expose Retail Price Improvement (RPI) orders. Metrics describe displayed public depth only.

No live Binance connection was performed during Unit 04D; implementation verification uses deterministic fixtures and mocked HTTP/WebSocket transports.
