# SMC V2 Signal Qualification & Dynamic Trade Planner — v0.43.0

## Scope

This delivery converts same-capture SMC V2 Stage 2–5 evidence into auditable candidate decisions, immutable `QualifiedSignal` objects and Decimal `TradePlan` objects. It does not submit exchange orders. Existing Stage 1–5 structure, OB formation, OB lifecycle and FVG/sweep semantics are not modified.

## Candidate sources and isolation

- Only M1 and M5 are setup timeframes, evaluated independently.
- M15 is advisory context only; opposing M15 direction is not a hard veto by default.
- Candidate provenance retains symbol, setup timeframe, OB candidate ID, lifecycle snapshot/status, source structure event, capture time, same-timeframe FVG/sweep references and confirmed structural target pivots.
- Candidate and structure event symbol/timeframe/direction identities must match. Source confirmation timestamps later than the capture are rejected as a look-ahead guard.
- `ACTIVE_FRESH` OBs are eligible. `TOUCHED` can be enabled/disabled by config (enabled by default). `CANDIDATE`, `MITIGATED`, `INVALIDATED` and `EXPIRED` are not eligible.

## Qualification and traceability

`SMCTradePlannerConfig` defines the score threshold, OB age, confluence weights, optional hard requirements and level construction. Every candidate evaluation includes status, score, reason codes and a parameter snapshot. The snapshot includes both planner and risk-manager settings.

Default score contributions are deliberately provisional: ACTIVE_FRESH=45, TOUCHED=40, BOS=8, CHoCH=10, SWING=5, directional overlapping FVG=8, qualifying same-direction liquidity sweep=8, aligned fresh/continuous Delta+CVD=5, synchronized depth imbalance=4, aligned absorption=6, and aligned M15 advisory context=5. Default minimum score is 55. These are configurable ranking rules, not profitability calibration.

Delta/CVD, depth, absorption, FVG, sweep and M15 are optional confluence by default. They do not change OB validity or lifecycle. A user may explicitly configure a confluence as a hard qualification requirement.

## Entry models

### LIMIT_RETRACEMENT

- Entry: midpoint of the OB wick zone, snapped conservatively to the exact tick grid (BUY limit floors; SELL limit ceils).
- LONG limit is considered only while mark price remains above the OB zone; SHORT limit only while mark price remains below it. Already retraced/through zones are rejected rather than submitted as stale limits.
- It does not use a confirmation-market trigger.

### CONFIRMATION_MARKET

- Entry: current mark price (must already align to the exact tick size).
- LONG requires the latest closed setup-timeframe candle to close above the OB zone top and close above its open.
- SHORT requires the latest closed setup-timeframe candle to close below the OB zone bottom and close below its open.
- It does not reuse the LIMIT midpoint trigger as its confirmation condition.

## Dynamic protective levels

- Stop Loss is placed beyond the distal OB wick boundary plus the configured tick buffer (below a bullish OB; above a bearish OB).
- Take Profit defaults to configured R multiple (2R default). If enabled, the closest confirmed, unbroken opposing structure pivot may replace the R target only if it is beyond current mark price and meets `min_target_r_multiple`.
- Entry, SL and TP are exact `Decimal` values and must align with `PRICE_FILTER.tickSize`. The planner does not infer tick size from price precision or silently round market-reference prices.
- Current exchange price bounds, entry/bracket order types, `LOT_SIZE`, `MARKET_LOT_SIZE`, `MIN_NOTIONAL` and optional maximum notional are enforced through exact metadata and the existing global risk sizing contract. Missing tick, minimum-notional or required entry/bracket order-type metadata fails closed.

## Risk sizing boundary

The planner uses `PortfolioRiskManager` to size the resulting plan against a supplied equity reference, stop distance, portfolio risk budget, symbol notional cap, leverage and exact quantity grids. In the live-market CLI, `--paper-equity-usdt` is explicitly a reference value, not a Binance account read. Short-lived 60-second in-memory reservations prevent separate pair callbacks from each consuming the full provisional risk allowance. This is not account reconciliation and is superseded by exchange-truth portfolio snapshots in v0.44.

The planner deduplicates an accepted candidate for the same symbol/candidate/entry model during the process lifetime. `release_candidate_signal` is available for downstream lifecycle reconciliation; `reset_planning_reservations` clears temporary PAPER planning reservations.

## Runtime use

After installation, `market-runtime` logs each candidate evaluation and approved plan to the configured application log. Example:

```powershell
python -m divatrading market-runtime --mode AUTO --max-symbols 8 --entry-model LIMIT_RETRACEMENT --paper-equity-usdt 1000 --risk-per-trade-pct 0.25 --max-portfolio-risk-pct 1.00 --target-r-multiple 2.0 --min-signal-score 55
```

Alternative entry model:

```powershell
python -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT,ETHUSDT,SOLUSDT --max-symbols 3 --entry-model CONFIRMATION_MARKET
```

The command still consumes public market feeds only and submits no orders. v0.44 will connect the plans to exchange-truth account reconciliation and the PAPER/TESTNET/LIVE execution lifecycle.
