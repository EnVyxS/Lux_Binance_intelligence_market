# Unit 04D — Order Book Depth & Book Imbalance

## Scope and safety

Unit 04D adds public, read-only Binance USDⓈ-M Futures order-book depth collection. It does not add absorption/exhaustion inference, SMC changes, scoring changes, Telegram, dashboard, private endpoints or order execution. The project remains PAPER-only.

## Binance endpoints

- REST snapshot: `GET https://fapi.binance.com/fapi/v1/depth`
- WebSocket: `wss://fstream.binance.com/market/stream`
- Per-symbol diff stream: `<symbol>@depth@100ms` or `<symbol>@depth@500ms`
- REST `limit` is explicit and restricted to Binance-supported values `5, 10, 20, 50, 100, 500, 1000`; default is 100. REST requests are paced (default 250 ms between requests).
- Binance REST documentation: https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
- Binance USDⓈ-M Diff Book Depth stream documentation: https://developers.binance.com/docs/derivatives/usds-margined-futures/websocket-market-streams/Diff-Book-Depth-Streams

RPI orders are not visible in the public order-book snapshot. The local book is therefore a view of displayed public depth, not all latent liquidity.

## Synchronization rules

1. Start the exact-symbol WebSocket stream and buffer its events before requesting a REST snapshot.
2. Build the initial book from `lastUpdateId` and the snapshot bid/ask levels.
3. Discard buffered events whose final update ID `u` is older than the snapshot update ID.
4. The first event applied must bridge the snapshot: `U <= lastUpdateId <= u`.
5. Subsequent USDⓈ-M Futures events must chain by `pu == previous final update ID`. Do not substitute the Spot rule `U == previous u + 1` for Futures.
6. Apply each event's absolute quantity by price level; quantity zero removes that level.
7. A `pu` mismatch, stale event, invalid/crossed book, malformed state or queue overflow invalidates readiness. Consumers must discard metrics and fetch a fresh snapshot/rebuild the book.

`LocalOrderBook.synchronize()` applies a buffered batch against temporary copies and publishes state only after the batch validates. `apply()` uses a copy-on-write update so a failed diff never leaves a partially updated healthy book.

## Bounded resources

- Exact selected symbols only; default maximum 8, hard maximum 32.
- Event queue default 4,096; hard maximum 16,384. Overflow raises `OrderBookQueueFullError`; it never silently drops a depth event.
- WebSocket message limit 64 KiB and library frame queue 16.
- REST snapshot default 100 levels; supported limit maximum 1,000.
- Local book default cap 100 levels per side; configurable up to 1,000.
- Metrics use configurable top-N levels (default 20), not every level retained in the book.

## Metrics

`LocalOrderBook.metrics()` is gated by synchronized state and freshness. It returns:

- best bid and best ask;
- absolute spread and spread in basis points;
- summed bid and ask quantity over configured top-N levels;
- depth imbalance `(bid_qty - ask_qty) / (bid_qty + ask_qty)`;
- update ID, level counts, event timestamp and synchronized flag.

Positive imbalance indicates greater displayed bid quantity; negative indicates greater displayed ask quantity. This is a snapshot of displayed depth, not proof of absorption, intent, hidden liquidity or a future price move.

## Minimal usage

```python
import asyncio
from divatrading.market_data.order_book import (
    BinanceDepthSnapshotClient,
    BinanceDepthWebSocketFeed,
    LocalOrderBook,
)

async def main():
    symbols = ["BTCUSDT"]
    feed = BinanceDepthWebSocketFeed(symbols=symbols, update_speed="100ms")
    book = LocalOrderBook("BTCUSDT", max_levels=100, depth_levels=20)
    rest = BinanceDepthSnapshotClient(limit=100)
    stop = asyncio.Event()
    runner = asyncio.create_task(feed.run(stop))
    buffered = []
    try:
        # Start receiving first, then buffer a short bounded batch.
        while len(buffered) < 100:
            event = await asyncio.wait_for(feed.get_event(), timeout=2)
            if event.symbol == "BTCUSDT":
                buffered.append(event)
        snapshot = rest.fetch("BTCUSDT")
        if not book.synchronize(snapshot, buffered):
            raise RuntimeError("No snapshot bridge; fetch a new snapshot and resynchronize")
        while True:
            event = await feed.get_event()
            if event.symbol != "BTCUSDT":
                continue
            book.apply(event)
            print(book.metrics())
    finally:
        stop.set()
        await runner
        rest.close()

asyncio.run(main())
```

Unit 04E provides `BinanceOrderBookSupervisor` for this orchestration. See [ORDER_BOOK_SUPERVISOR_GUIDE.md](ORDER_BOOK_SUPERVISOR_GUIDE.md) for the readiness contract, reconnect and resynchronization lifecycle. The service remains caller-managed and is not wired into the default CLI or strategy consumers.

## Current limitations

- No SQLite persistence for depth snapshots/diffs in this unit.
- No live Binance connectivity test was performed in the build environment.
- No depth-derived absorption/exhaustion, liquidity wall, spoofing or execution inference.
- The REST snapshot is limited to the requested number of levels. Levels outside the snapshot are not known until later updates affect them.
- Windows 10 / Python 3.12.9 user-environment validation remains pending.
