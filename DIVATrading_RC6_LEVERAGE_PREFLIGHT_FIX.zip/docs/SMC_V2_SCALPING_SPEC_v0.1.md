# DIVATrading — SMC Engine V2 Scalping Specification

**Document:** SMC_V2_SCALPING_SPEC  
**Design checkpoint:** 0.1.0  
**Status:** Architecture and strategic direction accepted; detailed numeric thresholds remain calibration-pending.  
**Parent software baseline:** DIVATrading Binance Bot v0.25.0 (Unit 05D Stages 1–8).  
**Implementation status:** Not implemented. This document is a design contract, not a software release.

## 1. Purpose and decision

Build a new SMC strategy engine for Binance USDⓈ-M Futures that supports frequent, cost-aware scalping opportunities while retaining explicit Order Block provenance and consistent Entry/SL/TP geometry.

The V2 engine is a **new strategy implementation**, not a 1:1 port of the current Pine/EA-derived logic. The prior Pine source and Python Unit 05D Stages 1–8 remain preserved as a legacy/reference implementation. They are not to be silently modified or used as the V2 strategy specification.

The existing Binance market-data infrastructure is reused. The entire bot is not rebuilt.

## 2. Accepted design decisions

1. Main product profile: **Scalping Hybrid**.
2. Timeframes: **M15 context → M5 primary setup → M1 entry timing**.
3. **M1 independent setup generation is allowed** to preserve scalp opportunity frequency; it must be distinguishable from M1 confirmation of a parent M5 setup.
4. M15 is a soft contextual bias by default, not a mandatory directional veto.
5. Legacy nested M5/M15 OB priority, `nestMode`, and M5-standalone arbitration are not used in V2.
6. Two entry models are separate configuration choices: **OB Limit / Retracement** and **Confirmation / Market**. They must never be represented as the same entry mechanic.
7. Baseline OB source is the **last opposing candle before a valid displacement that breaks confirmed structure**. Multi-candle source clusters may be introduced as a configurable variant later, not silently merged into the first implementation.
8. Full candle wick range is the initial OB-zone boundary convention; body-only boundaries may be a later explicit alternative. Zone construction must be configurable and traceable.
9. FVG, liquidity sweep, M15 alignment, Delta/CVD, depth imbalance, and absorption are confluence inputs by default, not mandatory gates for every setup.
10. Data integrity, structure validity, OB invalidation, symbol filters, executable spread/slippage, and portfolio risk remain hard safety gates.
11. Several valid OB candidates may coexist. Selection is not based only on newest-first ordering. Candidate qualification precedes ranking.
12. Every setup, signal, simulated fill, and trade must retain immutable links to its originating timeframe, structure event, OB, entry model, and evidence.

## 3. Scalping architecture

### 3.1 Timeframe roles

| Timeframe | Primary role | May independently create a trade setup? | Default treatment |
|---|---|---:|---|
| M15 | Higher-timeframe context: directional structure, swing liquidity and premium/discount context | No | Soft bias / scoring context; missing M15 does not invalidate M1/M5 setup generation |
| M5 | Primary setup timeframe: displacement, structure break, OB and FVG candidates | Yes | Main setup source |
| M1 | Entry timing for M5 setups and independent micro-structure setups | Yes | Entry engine and optional independent scalp source |

No timeframe wins merely because its OB overlaps or nests inside another timeframe's OB. MTF logic is contextual and candidate-based, not a legacy winner-takes-all nested priority ladder.

### 3.2 Setup identity and duplicate control

Every setup receives a deterministic `setup_id` derived from symbol, setup timeframe, structure-event identity, direction, OB identity, and setup generation sequence.

- An M1 confirmation of an M5 OB is a child *confirmation event* on the M5 setup; it is not a separate M1 OB setup.
- An independently formed M1 OB is a separate setup with its own M1 source structure and OB identity.
- Duplicate suppression may apply only when two signals reference the same canonical setup/OB event or when a configurable same-opportunity key proves they are the same executable opportunity.
- Geometric overlap between M1 and M5 zones alone is not a suppression reason.
- Any suppression/coalescing decision must be exposed in an immutable decision trace.

### 3.3 Scalping profiles

The configuration should expose at least:

| Profile | Behavior |
|---|---|
| `FAST_SCALP` | M1 independent setups enabled; M5 context optional/soft; M15 advisory; lower confluence dependency; strict execution-cost and risk checks remain mandatory |
| `BALANCED_SCALP` | Default; M5 primary setups plus M1 independent setups; M1 retest/confirmation for M5; M15 soft bias |
| `SELECTIVE_SCALP` | Same engine, but higher configurable candidate-quality and confluence requirements; no different OB or structure definition |

No fixed trades-per-day promise is specified. Frequency is measured on historical replay and then adjusted through transparent configuration rather than loosening structural validity.

## 4. Market structure engine

The structure engine runs independently for each enabled source timeframe and symbol.

Required outputs:
- confirmed swing highs/lows and internal pivots;
- structure leg and direction state;
- BOS and CHoCH events with exact broken level, event time, confirmation time, source timeframe, and source pivot identity;
- protected high/low or equivalent invalidation landmarks;
- event-extreme references used by downstream OB provenance;
- immutable per-bar/per-event traces and deterministic replay serialization.

A structure break must use a declared confirmation rule. The V2 baseline should prefer a candle close beyond a confirmed structure level; wick-only breaks are liquidity events unless separately configured. No look-ahead pivot may be used before its confirmation bar.

## 5. Displacement and Order Block formation

### 5.1 Candidate creation sequence

1. A confirmed structure level exists.
2. A directional displacement leg occurs.
3. The displacement closes beyond the eligible structure level under the configured BOS/CHoCH confirmation rule.
4. Search backward within a bounded `ob_source_lookback_bars` window for the last opposing candle preceding the displacement leg.
5. Create one candidate OB tied to that exact structure-break event and source candle.
6. Validate the candidate; only validated candidates become active OBs.

### 5.2 Displacement measurement

Displacement must be measurable rather than a subjective label. The implementation should record at least:
- candle body size and full range;
- body/range ratio;
- body and close extension normalized by ATR;
- number of directional candles in the leg;
- distance of the break close beyond the broken structure level;
- optional FVG evidence.

Numeric ATR and body-ratio thresholds remain configurable and must be selected through replay calibration. They must not be hard-coded solely from convention.

### 5.3 OB zone and source provenance

- Initial boundary convention: full source-candle wick, `zone_top=source_high`, `zone_bottom=source_low`.
- Store source candle open/high/low/close, source timestamp, source index, break timestamp, break level, direction, setup timeframe, displacement-leg identity, and zone-boundary convention.
- Optional body-only and opposing-candle cluster modes are future explicit options.
- The source candle's expected color is a validity property for the baseline last-opposing-candle definition, not merely a score bonus.
- One structural break event must not generate duplicate OBs on every subsequent candle.

### Stage-3 implementation note (v0.28.0)

The first implementation now creates initial M1/M5 OB candidates from exact Stage-2 confirmed structure events. It measures raw break/leg body and range, body/range ratios and close extension in symbol ticks; selects the nearest opposing source candle within a bounded lookback; and uses full-wick source boundaries. Numeric cutoffs are disabled by default pending replay calibration. ATR-normalized displacement and FVG evidence are explicitly deferred; Stage 3 reports FVG as `NOT_EVALUATED`. This note does not mark OB lifecycle, retest, entry or trade management as implemented.

## 6. OB validation and lifecycle

### 6.1 Hard validation

Candidate OB must satisfy:
- valid confirmed structure break and directional displacement;
- valid opposing source candle within the configured source lookback;
- positive, correctly ordered zone boundaries aligned to the exact symbol tick grid;
- no immediate invalidation under the configured invalidation convention;
- source data continuity and timeframe identity are intact;
- the candidate is not a duplicate of an existing OB for the same break event.

### 6.2 Lifecycle states

`CANDIDATE → VALIDATED → ACTIVE_FRESH → TOUCHED / MITIGATED → SETUP_ARMED → RESERVED → FILLED / CONSUMED`, with terminal alternatives `INVALIDATED`, `EXPIRED`, `CANCELLED`.

The lifecycle distinguishes signal creation from actual fill. An OB is not marked filled/consumed merely because a setup signal or RR box was drawn. A paper/live fill simulator or execution adapter reports fill state to the trade-management layer; the SMC baseline state must retain the original event history.

### 6.3 Retest and re-entry policy

Configurable policies:
- first touch only;
- allow partial mitigation and first qualified confirmation;
- permit re-entry after a completed/cancelled setup with cooldown and duplicate control.

Default V2 first implementation: first qualified retest per OB/setup, with re-entry disabled until replay evidence and position lifecycle are available. The policy must be parameterized rather than embedded in code.

## 7. Setup qualification and entry models

### 7.1 OB Limit / Retracement

- Price must return to the selected active OB zone.
- Entry is a configured price or depth inside the OB, measured from a named boundary; it is not the current close by default.
- Store entry band low/high and the exact intended limit price separately.
- If price never trades through the intended limit, the setup remains unfilled; a touch is not automatically proof of fill.
- Limit fill simulation must model conservative queue/touch assumptions and fees. A backtest must not assume every wick touch fills.

### 7.2 Confirmation / Market

- Price must interact with the selected OB under a declared retest rule.
- After the interaction, require a configurable M1 rejection or micro-structure confirmation (for M5 setups, confirmation occurs on M1; for independent M1 setups, use the subsequent M1 event/bar sequence).
- Entry reference is the first executable quote after confirmation: buy uses ask-side reference, sell uses bid-side reference, plus modeled slippage. A candle close is a signal proxy only, not a fill.
- Confirmation may use closed M1 bars for deterministic replay; event-driven use of validated Aggregate Trade / quote updates is a separate real-time path and must not introduce historical look-ahead.

### 7.3 Trigger modes

Use explicit entry-model and confirmation configuration rather than a single ambiguous `Either` switch. Rejection and structure confirmation may both be enabled, but every signal trace must record which condition actually triggered and its order of evaluation.

## 8. Confluence and candidate scoring

Candidate evaluation has two phases:

**Phase A — hard qualification:** structure, displacement, OB validity/lifecycle, retest conditions, feed integrity, symbol constraints, and risk/execution feasibility.

**Phase B — soft ranking:** displacement quality, structure significance, liquidity context/sweep, FVG, freshness, M15 alignment, CVD/Delta, depth imbalance, absorption, spread efficiency, and entry proximity.

- Missing optional confluence data yields `UNAVAILABLE`/neutral evidence, not an automatic rejection.
- M15 opposition may reduce rank or alter allowed profile, but does not veto by default.
- CVD and absorption may raise/lower quality; they must not become required unless the user explicitly selects a stricter profile.
- Scores are ranking/quality indices, not calibrated win probabilities.
- Initial weights and minimum score remain calibration-pending; no arbitrary numeric thresholds are frozen in this design checkpoint.
- Preserve each component value, availability, weight, and contribution in the decision trace.

## 9. Entry / Stop Loss / Take Profit geometry

### 9.1 Entry

The entry field must identify its semantic type:
- planned limit price;
- confirmation trigger reference;
- current bid/ask executable quote;
- simulated fill price;
- actual exchange average fill price (future execution layer).

These values must never be conflated.

### 9.2 Stop Loss

- Bullish stop is beyond the OB's structural invalidation boundary; bearish stop is beyond the opposite boundary.
- Buffer is volatility- and execution-aware (ATR component, spread component, and optional tick/minimum-distance component).
- Exact `PRICE_FILTER.tickSize` is mandatory for price alignment.
- Reject non-positive stop distance, stops beyond configured scalping-distance/ATR limits, and risk that exceeds the configured per-trade/portfolio budget.
- Do not widen a stop merely to satisfy exchange minimum quantity/notional; risk controls govern sizing.

### 9.3 Take Profit

Candidate targets may include nearest opposing validated OB boundary, confirmed swing liquidity, equal highs/lows or other configured external liquidity, and a risk-multiple fallback. Select the nearest valid target only after direction, available reward, costs, and minimum net-RR checks.

The TP engine must expose target source and fallback reason. Later Position Management may add partial exits, target extension, absorption/delta reversal exits, breakeven and structural trailing without changing the original setup identity.

### 9.4 Cost-aware R

Backtest and PAPER performance must use net results after configured maker/taker fees, spread, slippage, and applicable funding. The current project does not yet have account-specific fee data or a trade execution service; fee assumptions must therefore be explicit configuration and sensitivity-tested.

## 10. Binance data contract for SMC V2

### Mandatory for structural setup generation
- Exact Binance USDⓈ-M symbol identity and active contract metadata.
- Closed M1 and M5 Kline series with continuity, alignment, freshness and source identity validated.
- Exact symbol `tickSize` from `SymbolInfo.price_filter.tick_size`.
- Sufficient bounded history for indicators and structure warmup.

### Contextual / optional for setup generation
- M15 closed Klines: soft context. If unavailable, mark M15 alignment unavailable/neutral; do not block M1/M5 setup generation.
- Mark Price/funding: optional futures context. Not a substitute for last-traded price or bid/ask execution quote.
- Aggregate Trade / Delta-CVD: optional flow confluence; only trust when aggregate ID continuity and freshness are healthy.
- Order Book metrics: optional depth confluence. Current metrics include best bid/ask, spread, spread bps, top-N bid/ask depth and imbalance; they do not expose a complete historical L2 series.
- Absorption evidence: optional short rolling-window confluence. `UNAVAILABLE`, `WARMING_UP`, and `NO_CANDIDATE` must be distinguishable from a negative trade signal.

### Execution readiness is separate
A strategy setup may be valid while execution is unavailable. An entry may not be submitted/simulated as executable unless current quote/spread, symbol filters, fee/slippage assumptions, and risk constraints pass. The design must expose separate `SETUP_READY`, `ENTRY_READY`, and `EXECUTION_READY` states.

## 11. Signal and runtime state model

Minimum immutable records:
- `StructureEvent`;
- `OrderBlockCandidate` / `OrderBlockSnapshot`;
- `SetupCandidate`;
- `EntryIntent`;
- `RiskGeometry`;
- `ScalpSignal`;
- `ScalpDecisionTrace`;
- `MarketDataQualitySnapshot`.

Each includes symbol, source interval, source/event time, evaluation/observation time, deterministic identity, price convention, and reason codes. Price values use exact Decimal semantics and are aligned to symbol filters before execution handoff.

Engine state is per symbol/timeframe. No shared pivot/ATR/OB mutable state across intervals. Memory, candidate counts, event queues, and replay windows must be bounded for the Windows 10 / 8 GB target.

## 12. Scalping performance measurement

Replay reports must include at least:
- candidate setups by symbol, timeframe, direction, and entry model;
- qualified signals, cancelled setups, limit touch count, simulated fill count, fill ratio, and missed/unfilled count;
- trades/day and trades/session; average and median holding time;
- gross and net expectancy, average R, win/loss distribution, profit factor, max drawdown, MAE/MFE;
- fee, spread and slippage contribution; maker/taker sensitivity;
- performance by market regime, timeframe, MTF context, and confluence availability;
- rejection/suppression reason counts and duplicate rates.

Use chronological train/validation/test partitions and walk-forward evaluation. Avoid selecting parameters from the same sample used for final performance claims. A high trade count is not a success criterion unless net expectancy and drawdown remain acceptable after costs.

## 13. Acceptance gates before PAPER execution

1. Data adapter distinguishes mandatory M1/M5 from optional M15/flow/depth/absorption.
2. Missing optional confluence never blocks structurally valid setup detection; data corruption/staleness still blocks use of the affected source.
3. Structure events and OB candidates have deterministic identities and no duplicate creation from the same break event.
4. OB source candle and zone boundaries are traceable to exact closed source candles.
5. Retest and entry-model behavior is deterministic in replay and has no look-ahead.
6. Entry, stop and target reference the same setup/OB identity; planned entry is not mislabeled as fill.
7. Every rejection, ranking, deduplication and lifecycle transition has a trace reason.
8. Backtest includes cost-aware limit/market fill models and frequency metrics.
9. Full regression passes from a clean archive; target Windows 10 / Python 3.12.9 validation is completed before deployment.
10. PAPER mode remains enforced; no private API or live order placement until separately specified and approved.

## 14. Explicit exclusions from the first SMC V2 slice

- Live exchange order placement, cancellation, API signing, and account endpoints.
- Portfolio sizing and full production risk manager (may be designed as a later layer).
- Telegram and Dashboard integration.
- Kronos/ML forecast gating.
- Mandatory CVD/absorption/FVG/sweep confluence.
- Legacy `nestMode` / nested M5-M15 arbitration.
- Claim of 1:1 parity with the current Pine script.

## 15. Calibration items that remain open by design

The following must be chosen using historical Binance replay, not guessed now:
- ATR periods and displacement thresholds by timeframe;
- structure pivot lengths / internal-vs-swing sensitivity;
- OB source lookback and maximum active OB count;
- entry depth and allowed retest penetration;
- first-touch / re-entry cooldown values;
- score component weights and score thresholds;
- stop buffer, maximum stop ATR, minimum net RR and TP fallback preferences;
- per-symbol spread/slippage limits and maker/taker cost assumptions;
- FAST/BALANCED/SELECTIVE profile defaults.

These are configurable parameters. Changing them must not alter the definitions of event identity, source provenance, price types or lifecycle state semantics.
