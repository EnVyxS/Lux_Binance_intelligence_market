# Windows Deployment and Storage Guide — v0.57.0C1

## Supported target

- Windows 10, 64-bit
- Python 3.12.9, 64-bit, available through the Python Launcher (`py -3.12`)
- Project extracted to a drive with sufficient free space (for example, `B:`)

## Temporary storage placement

The Windows installer sets `TEMP`, `TMP`, `TMPDIR`, and `PIP_CACHE_DIR` to `.diva_temp` under the project directory before creating `.venv` or running pip. `TEST_WINDOWS.bat` uses the same local workspace and passes `.diva_temp\pytest` as pytest's `--basetemp`.

This keeps pip build isolation, pip cache, pytest databases and temporary files on the project drive rather than implicitly filling the Windows system drive. The `.diva_temp` directory is local working data: it is excluded from the release and checkpoint archives and ignored by Git.

For manual PowerShell commands in a new shell, set the same paths first:

```powershell
New-Item -ItemType Directory -Force -Path .diva_temp, .diva_temp\pytest, .diva_temp\pip-cache | Out-Null
$env:TEMP = (Join-Path $PWD '.diva_temp')
$env:TMP = $env:TEMP
$env:TMPDIR = $env:TEMP
$env:PIP_CACHE_DIR = (Join-Path $PWD '.diva_temp\pip-cache')
```

To run the test suite manually:

```powershell
.venv\Scripts\python.exe -m pytest -q --basetemp .diva_temp\pytest
```

The variables set in PowerShell apply only to that PowerShell process and child processes. The batch launchers set their own local values with `setlocal`.

## Install and test

1. Extract the release into a new project folder on the target drive.
2. Preserve any existing `.env` separately and copy it into the new folder only on the local PC. Never include it in source archives or share it.
3. Run `INSTALL_WINDOWS.bat`. It verifies the exact Python runtime, recreates `.venv`, installs runtime/development dependencies, and stores temporary install data below `.diva_temp`.
4. Run `TEST_WINDOWS.bat`. The launcher uses the project-drive temporary directory.
5. Verify `pip check` and `python -m divatrading auto-trade-runtime --help` before considering runtime qualification.

## Execution safety

The release templates keep these flags disabled:

```dotenv
DIVA_EXECUTION_MODE=PAPER
DIVA_ENABLE_TESTNET_ORDERS=false
DIVA_ENABLE_TESTNET_STAGE_C=false
DIVA_ENABLE_TESTNET_ORDER_TEST=false
DIVA_LIVE_TRADING_ENABLED=false
```

Do not enable TESTNET order routing merely to test installation or CLI availability. Stage C is a continuous runtime and may submit a real order to the Binance Demo matching engine when both independent TESTNET flags are explicitly enabled and a qualified SMC signal occurs. It must be supervised. LIVE remains separately gated and is not authorized by this release.

## Validation boundaries

The Windows full-suite evidence recorded for C1 comes from the operator's Windows 10 / Python 3.12.9 environment. Local release packaging checks do not constitute a Binance Demo integration test. No actual Stage C entry, fill, protective Algo confirmation, or LIVE order is asserted as complete.
