# DIVATrading — Binance Market-Data Integration Audit for SMC V2

**Document:** BINANCE_MARKET_DATA_V2_AUDIT  
**Design checkpoint:** 0.1.0  
**Status:** Source audit complete against extracted verified releases; no integration code changed.  
**Audited baselines:** Unit 04G v0.14.0, Unit 05A v0.15.0, Unit 05D v0.25.0.

## 1. Scope and integrity

Audited release artifacts:

| Release | SHA-256 verified in this audit | Purpose |
|---|---|---|
| Unit 04G v0.14.0 | `c6de1000de6e4a180c12b2a0f48e6397650b9b31e2b6805f7c62e40573ddfd92` | Unified market-data orchestration |
| Unit 05A v0.15.0 | `6136ff642dc8f1bbee35a6eaea9071cc5d7a6d5499d1b5418eda3dbb2944807f` | Strategy-facing read-only snapshot |
| Unit 05D v0.25.0 | `59892cf01409156b5266c94145042c5cded0be3131ded60a597c51d3da559278` | Legacy Pine-derived SMC engine Stage 1–8 |

Unit 05D v0.25.0 was extracted and independently rechecked during this audit: `pytest -q` **488 passed**, `compileall` passed, package root CLI help passed using `PYTHONPATH=src`, ZIP integrity passed, and the SHA-256 matched the recorded release hash. Runtime used here: Python 3.13.5 64-bit / Linux, not the target Windows 10 / Python 3.12.9.

## 2. Existing market-data capabilities

### 2.1 Kline

- Historical REST collection, bounded pagination, validation and explicit gap reporting exist in Unit 03A.
- SQLite Kline storage/repository exists from Unit 03B; reads can return bounded ascending rows and tail ranges.
- WebSocket Kline supports separate `FORMING` and `CLOSED` events; strategy confirmation must not treat forming data as closed.
- Supported strategy intervals are `1m`, `5m`, and `15m`.
- `KlineSeriesInput` in Unit 05A accepts closed candles plus an optional separate forming event, source-observation timestamp, health/completeness flags, and missing-open-time list.
- Default strategy snapshot cap is 500 candles/interval; adapter hard maximum is 2,000. V2 must explicitly request enough bars for its per-timeframe warmup and indicator pre-roll; 500 is not automatically sufficient.

### 2.2 Exchange metadata

- Unit 02 exposes exact-symbol `SymbolInfo` and typed filters.
- `SymbolInfo.price_filter.tick_size` provides exact Binance `PRICE_FILTER.tickSize`; `lot_size`, `market_lot_size`, and notional filters are available for later execution validation.
- Unit 05A `StrategyMarketDataSnapshot` does **not** currently carry `SymbolInfo` or `tick_size`. V2 data view must join a matching, current symbol metadata snapshot or pass a typed instrument-spec object separately.

### 2.3 Aggregate Trades and Delta/CVD

- Unit 04A provides USDⓈ-M Aggregate Trade WebSocket events, exact Decimal price/quantity, aggressor-side inference from `buyer_is_maker`, event/trade timestamps, aggregate IDs, bounded queues, and reconnect/continuity handling.
- Unit 04B provides REST aggregate-trade recovery and SQLite persistence with per-symbol contiguous-ID state. Source documentation records Binance historical API availability as bounded (48-hour historical retrieval at the time the module was authored); stored local rows can outlive that online retrieval window.
- Unit 04C produces exact Decimal BUY/SELL volume, Delta, CVD, imbalance and rolling buckets. `OrderFlowSnapshot` includes continuity/freshness flags, bucket window, aggregate-trade cursors, buy/sell quote/base volumes, Delta and trade count.
- The CVD baseline starts from the earliest locally retained aggregate-trade identity at initialization; it is not guaranteed to be lifetime or exchange-session CVD.
- Aggregate Trade is an aggregated feed, not a complete individual matching-engine fill tape.
- `StrategyMarketDataSnapshot` carries the current `OrderFlowSnapshot`, not a raw bounded list of recent Aggregate Trade events. If V2 needs event-by-event M1 tape confirmation, add a bounded fan-out/subscriber contract from the orchestrator; the SMC consumer must not steal events from the orchestrator's only queue consumer.

### 2.4 Order Book

- Unit 04D provides public REST depth snapshots and USDⓈ-M diff-depth WebSocket feed, local sequence-checked book and resynchronization behavior.
- Unit 04E supervisor manages per-symbol snapshot bridge, `pu` sequence chain, freshness, queue health and readiness.
- `OrderBookMetrics` exposes best bid/ask, spread, spread bps, top-N bid/ask depth, imbalance, level counts, synchronization and last event time.
- The strategy-facing snapshot receives the aggregated metrics and health, not the complete per-level book ladder.
- Audited source search found no Order Book depth sample persistence/repository in Units 04D/04E. Current book state is a bounded live in-memory view; it is not available as a complete historical depth series for backtesting.

### 2.5 Absorption evidence

- Unit 04F aligns flow and READY depth in bounded rolling windows.
- Default window is 5,000 ms, minimum span 3,000 ms, max sample gap 2,000 ms, and maximum 120 samples/symbol; status distinguishes `UNAVAILABLE`, `WARMING_UP`, `NO_CANDIDATE`, and `CANDIDATE`.
- `AbsorptionEvidence` contains measurements and source update identity, but the service's sample windows are in memory; no durable historical evidence/depth sample store was found.
- It is appropriate as optional real-time confluence, not as a historical feature that can be reconstructed from Kline alone.

### 2.6 Unified orchestrator

- Unit 04G coordinates Aggregate Trade ingestion/recovery, Delta/CVD, Order Book supervisor, and absorption evidence.
- It provides immutable `MarketDataReadiness` per exact symbol, including feed continuity, Delta/CVD readiness, order-book health, queue health, evidence status and timestamp.
- It is caller-managed, not automatically launched by CLI or the SMC strategy runtime.
- Therefore V2 integration still needs an explicit application supervisor/runner that starts services, registers subscriptions, supplies the snapshot to strategy workers, drains events, and handles shutdown/backpressure.

## 3. Critical incompatibility in current StrategyMarketDataAdapter

Unit 05A `StrategyMarketDataConfig` defaults `required_intervals=("1m","5m","15m")`. Each configured interval is treated as required; the adapter does not currently distinguish required from optional timeframes.

More importantly, `build_snapshot()` computes `ready` by requiring **all** of:

`KLINES`, `MARK_PRICE`, `DELTA_CVD`, `DEPTH`, `ABSORPTION`, and `ORCHESTRATOR`.

This conflicts with the accepted SMC V2 design:
- M1/M5 are the default structural inputs.
- M15 is optional soft context.
- Mark Price, CVD, Depth and Absorption are contextual/confluence sources, not mandatory OB-setup prerequisites.
- A missing optional component must not suppress a structurally valid SMC setup.

### Required change

Preserve the legacy adapter contract for compatibility. Add a new V2-specific data contract or extend it compatibly with explicit component policies:

- `required_for_structure`: M1/M5 Kline continuity/freshness and exact symbol/instrument metadata;
- `optional_context`: M15 Kline, Mark Price/funding, flow, depth, absorption;
- `required_for_entry`: current executable quote/spread and symbol price filter, according to chosen entry model;
- `required_for_execution`: later risk, account, fee and exchange capability checks.

Expose independent states such as `DATA_INTEGRITY_READY`, `STRUCTURE_READY`, `SETUP_READY`, `ENTRY_READY`, and `EXECUTION_READY`. A strategy candidate may be visible while an execution gate is unavailable; do not collapse every layer into one global READY flag.

## 4. V2 input-contract proposal

The new `ScalpingMarketDataView` (name provisional) should contain:

1. exact symbol plus a typed current `InstrumentSpec` derived from `SymbolInfo` (tick size mandatory; quantity/notional filters available to execution layer);
2. closed M1 and M5 candle histories with source health, completeness, and observation time;
3. optional closed M15 history;
4. separate forming M1/M5/M15 candle events;
5. optional latest Mark Price/funding event;
6. optional `OrderFlowSnapshot` with status, continuity, aggregate-trade cursor, timestamps and rolling CVD/Delta fields;
7. optional `OrderBookSymbolHealth` plus `OrderBookMetrics` with matching update ID;
8. optional `AbsorptionEvidence` with source update ID/window timestamps;
9. optional bounded recent Aggregate Trade event window or immutable event batches, delivered through a non-competing orchestrator fan-out;
10. per-component readiness, age, provenance and reason codes.

All price/quantity values remain `Decimal`. All time values must retain UTC epoch-ms semantics and distinguish exchange event/trade time, Kline source time, observation time, and strategy evaluation time.

## 5. Readiness policy for V2

| Source | Structural setup | Context/ranking | Executable entry |
|---|---|---|---|
| M1 closed Kline | Required for M1 trigger/timing | — | Required for closed-bar confirmation mode |
| M5 closed Kline | Required for primary M5 setup | — | Required for M5-origin setup |
| M15 closed Kline | Optional | Soft bias | Not required |
| `tickSize` / SymbolInfo | Required for valid price geometry | — | Required |
| Mark Price | Optional | Funding/mark context | Not a replacement for bid/ask quote |
| Aggregate Trade/CVD | Optional | Flow confluence | Required only when selected entry mode explicitly depends on it |
| Order Book metrics | Optional | Spread/depth/imbalance confluence | Current bid/ask/spread required for executable market/limit safety checks |
| Absorption evidence | Optional | Short-window confluence | Not mandatory |
| Unified orchestrator health | Required for trusting components sourced through it | Component-specific | Required for any live-derived event used by entry gate |

If one optional source is stale or unavailable, exclude that component and record why; do not mark it as a negative market signal. If a required structural Kline source has a gap, wrong symbol, stale bar, or uncertain closure, block new setups for that timeframe. If a current execution quote is unavailable or spread exceeds the configured limit, retain the setup but block entry readiness.

## 6. Data-retention and replay gaps

| Capability | Current state | Impact / action |
|---|---|---|
| Historical Kline | Persisted in SQLite | Sufficient foundation for structure/OB replay after choosing warmup and history bounds |
| Aggregate Trade | Persisted and ID recovery supported | Flow replay possible over retained contiguous rows; baseline scope must be recorded |
| Delta/CVD buckets | Persisted in SQLite | Useful for historical flow confluence, subject to continuity and baseline metadata |
| Mark Price | WebSocket feed; no persistence identified | Historical funding/mark context unavailable unless added later |
| Order Book L2 | Live in-memory synchronized book; no historical depth persistence identified | Cannot backtest historical depth/absorption faithfully yet |
| Absorption windows | In-memory bounded rolling windows | Cannot reconstruct historical absorption from current Kline/CVD alone |
| Fee schedule | No account-specific trading fee contract in current market-data snapshot | Use explicit configured maker/taker fee assumptions and sensitivity tests until execution/account module exists |
| Trade fills/positions | Not implemented | No true fill-based OB consumption or realized PnL yet |

## 7. Integration tasks before SMC V2 engine implementation

1. Add the V2-specific `ScalpingMarketDataView` and `InstrumentSpec`; do not break existing `StrategyMarketDataAdapter` public behavior.
2. Split readiness into structural/data integrity, contextual confluence, entry quote safety, and execution/risk readiness.
3. Make M1/M5 candle requirements distinct from optional M15 context.
4. Add bounded Aggregate Trade event fan-out for strategy consumers; preserve a single owner of the source feed queue and fail closed on fan-out overflow.
5. Expose the precise current best bid/ask/spread and freshness for entry safety; do not use Mark Price or candle close as executable quote.
6. Document history/warmup requirements per timeframe and lift the 500-candle default only via explicit V2 configuration within the existing adapter hard cap or a compatible new adapter.
7. Decide whether to add sampled depth persistence for historical confluence replay. It is not a prerequisite for initial SMC structure/OB engine, but it is required before claiming historical depth/absorption validation.
8. Build a caller-managed strategy runtime supervisor that owns lifecycle and queue draining; no component should silently compete for a feed queue.

## 8. Explicit limitations

- No live Binance REST/WebSocket session was run as part of this audit.
- Windows 10 / Python 3.12.9 validation remains pending; audit tests ran on Python 3.13.5 / Linux.
- `OrderFlowSnapshot` is aggregate/window-level, not raw matching-engine trade tape.
- Current `StrategyMarketDataSnapshot` is immutable and useful, but its global all-components readiness policy is unsuitable as-is for V2 soft confluence.
- No live order placement, private account API, fee lookup, exchange fill, position, or historical L2 depth recorder exists in the audited releases.
