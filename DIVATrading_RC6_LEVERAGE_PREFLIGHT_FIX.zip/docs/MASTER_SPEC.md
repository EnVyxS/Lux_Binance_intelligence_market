> Latest safe candidate: v0.59.0rc3, 2026-11-15. Read [AUDIT_RC3_STATUS_DAN_HANDOFF.md](../AUDIT_RC3_STATUS_DAN_HANDOFF.md) for current status; read [../AUDIT_PROYEK_ID.md](../AUDIT_PROYEK_ID.md) for the source-checked status. Earlier checkpoint descriptions below are historical, not the current implementation inventory. LIVE remains disabled.

# DIVATrading Binance Bot — Master Specification

## Fixed project constraints

- Exchange: Binance only.
- Initial market: USDⓈ-M Futures, USDT perpetual contracts.
- Target OS: Windows 10, local computer, no VPS.
- Target Python: exactly 3.12.9, 64-bit.
- Available RAM: 8 GB.
- Initial operational mode: PAPER. Live trading remains disabled until later validation and explicit Owner activation.
- Legacy/reference strategy: preserve the user's `Sniper_SMC_MTF_Enhanced` Pine implementation and its parity artifacts separately. New SMC strategy: implement SMC Engine V2 Scalping Hybrid from the accepted V2 specification; do not inherit legacy EA nested M5/M15 arbitration.
- Main timeframes: M1, M5, M15.

## Planned subsystems

1. Binance data: REST metadata, kline history, WebSocket kline/mark price, aggregate trades, depth stream, open interest, funding, liquidation where supported, and account/user streams.
2. SMC engine: swing/internal structure, BOS/CHoCH, OB, FVG, sweep, premium/discount, RSI, ADX, volatility regime, MTF arbitration, Pine-compatible scoring and gates.
3. Market intelligence: delta, CVD, imbalance, absorption/exhaustion, order book liquidity, OI/funding/liquidation context. Intelligence is initially scoring; data integrity, spread, and execution safety are hard gates.
4. Optional Kronos: isolated shadow forecasting module, initially Kronos-mini on M5 and candidate-only inference. It must not block execution or veto SMC until out-of-sample evidence supports it.
5. Risk: Fixed USDT or percentage equity, position sizing, fees, slippage reserve, funding, daily loss/drawdown limits, exposure and correlation controls, exchange filters.
6. Execution: short maker attempt followed by bounded Limit IOC, price cap, no chasing, partial-fill handling, order idempotency, protective SL verification.
7. Trade management: structural/liquidity-aware SL, opposing-OB/liquidity initial TP, partial TP, TP extension, absorption/Delta reversal/opposite-signal early exit, breakeven and structural trailing.
8. Positions: one position per symbol, pyramiding OFF; paper max 3; live commissioning max 1; live normal max 2 after validation; configurable absolute cap 3. Initial portfolio risk budget 2R and correlated-group budget 1R are provisional controls to validate.
9. Telegram: inline-keyboard control panel, universe, scanner controls, risk, execution, positions, trade management, notification preferences, reports, Owner/access management and redeem codes. FORMING notifications default OFF; READY and trade/risk alerts default ON as specified in later implementation settings.
10. Dashboard: overview, active setups, setup history, market intelligence, open positions, trade history, performance.
11. Reliability/security: API secret protection, no withdrawal permission, websocket reconnect/resync, reconciliation, state recovery, protective-order verification, audit logs, safe emergency controls.
12. Validation: replay/backtest, paper, Binance Futures Testnet, recovery testing, then live commissioning only after explicit Owner approval.

## Implemented baseline as of Unit 05A

- Units 01–03A: project foundation, Binance USDⓈ-M metadata adapter, typed Kline parser and bounded historical REST collection.
- Unit 03B: SQLite schema v3 with normalized Kline candle persistence, composite candle identity and exact Decimal string round-tripping.
- Unit 03C: bounded asynchronous public Kline WebSocket feed, configured subscriptions, FORMING/CLOSED events, queue cap, reconnect/resubscribe and graceful shutdown.
- Unit 03D: bounded REST gap backfill and SQLite reconciliation, per-stream/global readiness states, reconnect invalidation and closed-event ingestion gating; schema remains v3.
- Unit 03E adds a bounded per-symbol Mark Price / Index Price / Funding Rate stream, distinct from Last Price and Kline close.
- Unit 04A adds a bounded exact-symbol USDⓈ-M Aggregate Trade feed. It normalizes `buyer_is_maker` to BUY/SELL taker aggression, maintains Decimal volumes, and flags aggregate-ID gaps.
- Unit 04B persists Aggregate Trades, maintains a durable contiguous cursor, and repairs recent gaps using bounded REST `fromId` pagination.
- Unit 04C adds Decimal BUY/SELL volume, Delta, cumulative CVD and rolling imbalance using persisted trades. CVD is based on the earliest locally retained baseline and is blocked across degraded/unresolved gaps.
- Current Kline timeframes remain `1m`, `5m`, and `15m`.
- No private account endpoint, signed request or order execution function is present.

## Development invariants

- Binance is the only exchange/price source for this bot. No Exness/MT5 integration.
- No blending different contract feeds.
- Signal price is not fill price; realized position risk uses average fill price.
- Never expand risk just to satisfy exchange minimum quantity/notional.
- Partial TP does not release a position slot.
- Opposite signal does not automatically reverse a position.
- Pause New Entries must not stop management/protection of existing positions.
- Live execution must be impossible in foundation releases and only enabled after explicit safety validation.
- Every setup/trade has traceable IDs and an audit trail.


## Unit 04B — Aggregate Trade Persistence & REST Gap Recovery

- Aggregate ID identity `(exchange, symbol, aggregate_trade_id)` in SQLite schema v4.
- Exact Decimal storage for price, quantity and optional normal quantity; preserve RPI `nq` separately from total `q`.
- Inclusive `fromId` REST pagination, max page 1,000, per-pass page cap and explicit resume cursor.
- Durable contiguous cursor and unresolved gap audit; no synthetic trade records.
- Enforce current Binance 48-hour history availability and expose unresolved retention/history status.
- No Delta/CVD windows until aggregate IDs and event freshness are validated.


## Unit 04C — Delta & CVD Aggregation

- Forward-only SQLite schema v5 adds `order_flow_state` and `order_flow_buckets`.
- BUY/SELL volume uses taker aggressor derived from Binance `m`; quote volume uses `price × q` as exact Decimal.
- Calculates base/quote Delta, cumulative base/quote CVD and rolling buy/sell imbalance over UTC-aligned buckets (`1s`, `5s`, `15s`, `1m`, `5m` by default).
- CVD starts immediately before the earliest currently retained local trade ID; it is not day/session/lifetime exchange CVD.
- The processor advances only through Unit 04B's durable contiguous cursor; DEGRADED/UNRESOLVED states prevent bridging gaps. Freshness is separately exposed.
- Bounded processing (up to 5,000 rows per call, max 20 passes per catch-up) and deterministic replay are implemented. Replay requires a HEALTHY raw source.
- No depth, absorption, SMC modification, scoring, Kronos, Telegram, dashboard or execution is included.


## Unit 04G — Unified Market-Data Orchestrator

- Coordinates Aggregate Trade feed/REST recovery, durable persistence, Delta/CVD, order-book supervisor and absorption evidence.
- Exposes immutable per-symbol readiness, source health, queue health, reconnect generations and explicit reason codes.
- Uses bounded queues and bounded catch-up; blocking REST/SQLite work runs outside the event loop.
- Caller-managed; not started by the default CLI and not connected to a strategy or execution engine.

## Unit 05A — Strategy-Facing Read-Only Snapshot Contract

- Adds `StrategyMarketDataAdapter` and immutable `StrategyMarketDataSnapshot`.
- Default required timeframes are M1, M5 and M15. Closed candles are kept separate from an optional forming candle.
- Validates candle order, gaps, closure, completeness, source age and bounded candle counts; validates Mark Price freshness and connection state.
- Carries Unit 04G Delta/CVD, depth health/metrics, absorption evidence and orchestrator readiness; checks exact symbol and matching depth/absorption update IDs.
- Snapshot readiness fails closed if any required source is missing, stale, degraded or internally inconsistent. `WARMING_UP` and `NO_CANDIDATE` absorption states are valid data states; `UNAVAILABLE` is not.
- Adapter has no network, database, background task, mutable cache, SMC calculation, scoring, risk sizing, signal, Telegram/dashboard or order-execution behavior. SQLite remains schema v5.

## Pine SMC status at completion of Unit 05B

The exact available Pine v6 content has been audited and its duplicate Library candidates were confirmed byte-identical. Unit 05B provides the source map, 49-input inventory, normalized reference contract and deterministic diff utility. Unit 05D Stages 1–5 now implement warmup reset, custom ATR(200), parsed candle extremes, swing/internal pivot legs, BOS/CHoCH state, OB/FVG lifecycle, Pine built-in ATR(14)/RSI(14)/SMA(20)/DMI(14,14) pre-roll, volatility-regime flags, and ordered OB candidate eligibility as isolated Python replay primitives. Trigger/sweep, scoring, signal output and MTF arbitration remain unimplemented; measured TradingView parity remains unverified. Source-derived implementation tests do not count as external parity evidence. Consult `docs/PINE_SMC_PARITY_AUDIT.md`, `docs/PINE_SMC_REPLAY_CONTRACT.md`, and the Unit 05D stage documents before extending the engine.


## Unit 05B — Pine SMC Parity Audit & Deterministic Reference Contract

- Audited Pine v6 `Sniper SMC MTF · EA Matched + Entry Score` (905 lines, 62,206 bytes). The two matching Library candidates are byte-identical; SHA-256 `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Documents all 49 input defaults and source-line behavior for state/warmup, Pine TA series, swing/internal structure, BOS/CHoCH, OB/FVG, mitigation, newest-first candidate scan, filters, rejection/structure trigger, sweep, score weights, entry/SL/TP proxies, MTF request/lookahead and nested arbitration.
- Adds `divatrading.strategy.parity_contract` immutable `ParitySignal` and deterministic normalized signal diff report. It does not replay candles or calculate SMC.
- Adds JSON reference fixture schema/template and deterministic OHLCV replay requirements. The template is unpopulated because no trusted TradingView reference output was supplied.
- Explicitly separates Pine indicator proxy entry (`close`) and signal-based OB consumption from future exchange fill-based execution semantics.
- No strategy engine, scoring/entry modifications, private API, Telegram/dashboard, risk, or order execution; no database migration (schema remains v5).

## Pine SMC parity status

At the Unit 05B checkpoint, the source audit and comparator contract were complete but signal parity had not been measured because no trusted machine-readable TradingView fixture existed. This historical checkpoint note must not be interpreted as blocking source-derived code translation. Current implementation status is recorded below under Unit 05D; measured full parity still requires independent reference observations from the exact Pine and Binance USDⓈ-M ticker/history.


## Unit 05C — Trusted TradingView Reference Fixture Intake & Validation

- Adds a separate 47-series Data Window capture patch for the audited Pine source. It exports M1/M5/M15 event fields, entry/SL/TP proxy, OB source/coordinates, scores, bands, evaluation time and MTF arbitration flags. The patch is additive after the existing `take*` decisions; original signal expressions remain unchanged. Original Pine SHA and patch SHA are independently pinned.
- Includes `Sniper_SMC_MTF_Enhanced_Instrumented_v1.pine` as a ready-to-paste full script. Removing the exact patch block restores the original Pine source byte-for-byte (the full instrumented file has its own recorded SHA-256). The patch variables are checked against the exact Pine tuple names.
- Adds `reference_fixture.v2.schema.json`, `capture_manifest.template.json`, and three-export CSV intake (M1 with signal plots; M5/M15 native candle exports).
- Adds `divatrading.strategy.fixture_intake` builder and validator; raw CSV SHA-256/byte length and embedded candle/signal contents are rechecked. Semantic validation includes exact `BINANCE:{symbol}.P` mapping, 49 inputs, warmup agreement, timezone/timestamp rules, contiguous OHLCV, tick grid, MTF last-bar alignment, source-close entry proxy and signal/OB timestamp membership.
- Adds CLI `validate-pine-fixture` and capture documentation. JSON Schema validator is pinned as `jsonschema==4.26.0`.
- Unit tests exercise synthetic fixtures only. **No actual user TradingView CSV bundle was supplied or accepted**; Pine parity remains unmeasured. At the historical 05C checkpoint, CSV-based intake was the planned validation route; the later 05D implementation decision allows source-derived translation to proceed without it. A real fixture or exact manual spot checks remain independent evidence for measured parity, not a prerequisite for translating explicit source expressions.
- No DB migration, private API, Telegram/dashboard, risk sizing, or order execution.


## Unit 05D — Python Pine SMC Structure Primitives (Stage 1, v0.18.0)

- Adds `PineSmcStructureConfig`, `PineSmcStructureEngine`, immutable bar/pivot trace records, and deterministic JSONL serialization.
- Implements the source-derived `startIndex = max(0, last_bar_index - warmupBars + 1)` reset independently per timeframe.
- Implements custom True Range and ATR(200): initial arithmetic mean across local indices 0–199, then `(previous_atr200 * 199 + TR) / 200` from index 200.
- Implements the inclusive high-volatility parsed-candle branch, preserving the Pine high/low inversion.
- Implements independent swing/internal delayed pivot-leg detection with strict tie rejection, high-branch priority, pivot index/time capture, crossed reset and swing range extrema.
- Consumes existing validated Binance USD-M `Kline` objects; Decimal market data is converted to binary64 only at the Pine calculation boundary. It fails closed on wrong source identity, invalid OHLC/timestamps and gaps.
- Fifteen focused stage-1 tests; source-derived implementation tests only. No real TradingView reference observations have been accepted; parity remains unmeasured.
- No OB/FVG lifecycle, BOS/CHoCH event handling, trigger, score, signal, MTF arbitration, dynamic Entry/SL/TP, CVD filters, Telegram, database, private API or order execution added. SQLite remains schema v5.

## Unit 05D — Pine SMC Structure Events (Stage 2, v0.19.0)

- Adds exact `confluenceFilter` input handling, preserving Pine's `a=high-max(close,open)` and `b=min(close,open-low)` expressions and strict comparisons.
- Implements internal bullish break then internal bearish break with the source `extraBull`/`extraBear` filters, valid/crossed guards, strict close-cross conditions and sequential `internalTrend` mutation.
- Classifies internal CHoCH versus BOS from the trend immediately before each branch and exposes four per-bar event flags.
- Implements the raw event-extreme scan from the crossed internal pivot through the current candle, retaining the earliest candle on equal extrema through strict `<`/`>` comparisons.
- Implements swing high then swing low cross checks after internal events; sets pivot crossed flags and updates separate `swingTrend` without emitting internal event flags.
- Extends immutable trace and deterministic JSONL with `swing_trend`, `internal_trend`, confluence booleans, event flags and event extreme value/index/source timestamp. Existing tracked `trTop`/`trBot` boundaries remain source-identical.
- Adds six focused tests; focused structure file: 21 passed; full regression suite: 399 passed. Source-derived tests are not independent TradingView parity evidence.
- Retains full in-window history in a Pine-warmup-bounded list (maximum 2,500 bars) for event-extreme scans; source identity and contiguous Kline validation remain fail-closed.
- No OB/FVG creation or mitigation, trigger/signal/scoring, MTF arbitration, Dynamic Entry/SL/TP, private API, Telegram/dashboard, risk sizing, database migration or order execution. SQLite remains schema v5.

## Unit 05D — OB/FVG Creation and Mitigation Lifecycle (Stage 3, v0.20.0)

- Preserves Stages 1–2 and adds the source-derived parsed-candle OB source scan after each internal bullish/bearish structure event.
- Bullish OB uses strict minimum parsed-low selection; bearish OB uses strict maximum parsed-high selection. Strict ties retain the earlier source candle. Top/bottom are normalized with max/min; source and break candle index/time are both retained.
- Adds directional FVG checks using the original series offsets and the break candle's `fvgMinAtr * atr200` threshold. The source positive-gap and inclusive threshold conditions are preserved.
- Models Pine's parallel OB arrays as one typed active collection, capped at 100 with oldest-first FIFO eviction. `used` initializes false and is not changed before candidate selection exists.
- Internal event creation order remains bullish then bearish; mitigation follows structure processing and runs in reverse collection index order. `mitigateClose=false` uses high for bearish invalidation and low for bullish invalidation; `true` uses close for both. Boundaries are strict.
- Same-bar created OBs may be mitigated on the same bar. Immutable trace separates created, mitigated, evicted and final active snapshots.
- Config/replay metadata records `fvg_min_atr=0.10` and `mitigate_close=false` defaults. SQLite remains schema v5; no migration.
- Eleven focused tests cover OB source selection/ties, bullish/bearish FVG offsets and inclusive threshold, FIFO, mitigation source/order/boundaries, same-bar behavior, immutable snapshots and deterministic JSONL. Total suite: 410 tests.
- Stage 3 does not implement OB candidate selection, signal trigger, sweep, scoring, signal emission, one-bar shift, MTF arbitration, Dynamic Entry/SL/TP or execution. Real TradingView observations and fixtures remain zero; parity is unmeasured.



## Unit 05D — Pine Built-in TA Pre-roll and Volatility Regime (Stage 4, v0.21.0)

- Adds streaming `PineBuiltinTAEngine` for the exact Pine source's ATR(14), RSI(14), SMA(volume,20), and DMI(14,14) series. It consumes each loaded candle before the SMC warmup conditional, preserving full-history pre-roll.
- ATR(14) uses True Range with the first-loaded-bar `high-low` fallback and Wilder RMA(14); RSI(14) uses the documented Pine long-form gain/loss RMA calculation, including the first-bar ternary zeros and `0/0` unavailable case; SMA(20) retains a bounded 20-value window and remains unavailable for its first 19 samples.
- DMI(14,14) uses prior high/low/close directional movement, a first-bar `ta.tr`/DM unavailable sample, independent RMA(14) streams, `fixnan`-style DI carry-forward, DX and ADX smoothing. DI first becomes available on source index 14; ADX on index 27 for a complete prefix.
- Adds immutable `PineSmcIndicatorTrace` fields for ATR(14), RSI, volume average, +DI, -DI, ADX, previous-bar ATR(200) denominator, ATR ratio and volatility flags. Pine unavailable values serialize as JSON `null`.
- Mirrors `atrRatioNow` evaluation order before current-bar ATR(200) update, its `1.0` fallback when ATR(200) is not positive, inclusive `extremeVolRatio` comparison, and strict low/high/ADX comparisons for `volatilityChoppy`.
- Stage 4 adds 14 focused indicator tests; Stage 1–4 focused tests total 46; full regression suite: 424 passed. Stage tests are source-derived implementation checks, not independent TradingView parity observations.
- No OB candidate selection, trigger/sweep, scoring, signal emission, one-source-bar output shift, MTF arbitration, Dynamic Entry/SL/TP, order-flow filtering, Telegram/dashboard, private API, execution or database migration. SQLite remains schema v5.


## Unit 05D — Ordered OB Candidate Eligibility (Stage 5, v0.22.0)

- Preserves Stages 1–4 and implements the eligibility block of Pine `FindSignal()` (lines 542–570) as a read-only candidate scan.
- Adds exact Pine defaults and validations for `maxAgeM15=150`, `maxAgeM5=300`, `freshOnly=true`, `useTrendFilter=true`, `usePDFilter=true`, and `requireFVG=false`.
- Preserves the source call mapping: the M1 and M5 `request.security()` contexts pass `maxAgeM5`; the M15 context passes `maxAgeM15`.
- Applies the fresh-only/used, strict age window, direction-specific swing trend, valid-range premium/discount equilibrium, stored FVG and Stage-4 extreme/choppy regime gates in Pine source order.
- Returns all eligibility evaluations newest-to-oldest with original active-array index, immutable OB snapshot and ordered rejection reason codes. The eligible subset preserves the same order; no sorting occurs and no `used` mutation is allowed at this stage.
- Adds 11 focused tests; Stage 1–5 focused tests total 57; working-tree full regression suite: 436 passed. Stage tests are source-derived implementation checks, not independent TradingView runtime parity evidence.
- No rejection/structure trigger, sweep, score, final signal, level calculation, one-source-bar shift, MTF arbitration, Dynamic Entry/SL/TP, private API, Telegram/dashboard, order execution or database migration. SQLite remains schema v5.

## Unit 05D — Trigger and Sweep Qualification (Stage 6, v0.23.0)

- Adds the exact Pine trigger inputs: `triggerMode`, `structAllowBOS`, `minWickPct`, `requireSweep`, `sweepLookback` and `sweepWindow`, with Pine defaults and ranges.
- Implements bullish/bearish rejection triggers with positive candle range, OB touch, candle direction, close relative to OB midpoint and exact wick percentage formula.
- Implements structure trigger using Stage-2 event flags/extreme, strict event-after-break index, CHoCH allowance, `structAllowBOS` gating and inclusive OB boundary comparison.
- Preserves trigger priority: rejection code `1` before structure code `2`; otherwise no trigger code `0`.
- Implements the optional nested `sweepWindow`/`sweepLookback` loops with strict new-low/high and close-back-through conditions, exact local-history offsets and the Pine history-availability gate. Disabled sweep bypasses the test.
- Consumes only Stage-5 eligible candidates, preserves newest-to-oldest order and stops at the first candidate with a nonzero trigger and passing sweep. The immutable chosen-candidate view does not emit a final signal or mutate `used`.
- Adds 16 focused Stage-6 tests; Stage 1–6 focused tests total 73; full working-tree regression suite: 451 passed. Tests are source-derived implementation checks, not independent TradingView parity observations.
- No scoring, entry bands, Pine proxy levels, signal output, one-source-bar shift, MTF arbitration, Dynamic Entry/SL/TP, private API, Telegram/dashboard, order execution or database migration. SQLite remains schema v5.


## Unit 05D — OB Scoring and Ideal Entry Bands (Stage 7, v0.24.0)

- Ports Pine `f_scoreOB()` and its selected-candidate and active-OB diagnostic call sites. All Stage 1–6 calculations and candidate order are preserved.
- Adds `entry_depth_near=0.50`, `entry_depth_deep=0.80`, and `tick_size` config. Depth input bounds and `deepDepth <= nearDepth` fallback match Pine.
- Builds bullish and bearish ideal entry bands from `zoneRange=max(obTop-obBottom, syminfo.mintick)` with exact direction-specific formulas.
- Adds nine weighted OB-quality components: volatility (10), displacement (16), source candle (12), RSI (12), trend (12), FVG (8), relative volume (6), freshness (6), and sweep confluence (8); subtotal divided by 90.
- Adds timing score (45% current-candle direction/close position, 55% proximity) and setup score (80% quality, 20% timing), each with Pine clamps and fallbacks. The model is diagnostic metadata, not a calibrated win rate.
- Implements full-loaded-prefix `ta.lowest(low[1], sweepLookback)` / `ta.highest(high[1], sweepLookback)` separately from Stage-6 nested sweep qualification.
- Computes all active OB scores in original array order and links the Stage-6 chosen index to its score. It does not sort, replace the chosen candidate, or mutate `used`.
- Exact `syminfo.mintick` is required for score output; caller must provide the matching Binance USD-M `PRICE_FILTER.tickSize`. Without it, scoring is explicitly unavailable rather than guessed.
- Adds immutable `PineSmcObScoreTrace` and `PineSmcObScoringTrace`; focused Stage-7 tests: 16; focused Stage 1–7 total: 89; full suite: 467. Source-derived tests do not prove independent TradingView runtime parity.
- No entry/SL/TP geometry, final signal output, one-source-bar shift, MTF arbitration, dynamic trade management, order execution, private API or SQLite migration.


## Unit 05D — Pine Baseline Entry / SL / TP Proxy Geometry (Stage 8, v0.25.0)

- Preserves Stages 1–7 and implements the local `f_smc()` entry/level geometry from Pine source lines 624–684.
- `entry_proxy` is the source-bar `close`; it is an indicator/historical proxy and is not a Binance Bid/Ask, fill, or position entry.
- Exact estimated spread is `spreadEstimateTicks * syminfo.mintick`. Stop buffer is the maximum of spread-multiple and ATR(14)-multiple, multiplied by `highVolSLMult` only when volatility regime is enabled and `atrRatioNow >= highVolRatio`.
- Bullish SL uses selected OB bottom minus buffer; bearish SL uses selected OB top plus buffer. A non-positive directional stop distance rejects before min-stop. The minimum stop is enforced from entry, then strict `maxSLAtr` and `maxSpreadSLPct` checks run in Pine order.
- `Fixed RR` uses `rr` without a separate `minRR` check. `Structure` uses the directional tracked swing extreme and applies positive reward and `minRR`. `Hybrid OB/Liquidity` scans all active opposing OBs oldest-to-newest including used records, prefers the nearest qualifying boundary, otherwise structural liquidity, then falls back to fixed RR if needed. A fallback passing through a known opposing OB is rejected.
- Geometry evaluates only the first Stage-6 chosen candidate. Failure does not retry another OB. The selected Stage-7 score identity must match the selected Stage-6 OB snapshot.
- Immutable `PineSmcSignalProxy` and `PineSmcLevelEvaluationTrace` retain trigger, selected OB, score, entry/SL/TP proxy values, target origin, reward/RR and ordered level rejection reasons.
- `consumeOBOnSignal` changes the selected Pine indicator OB `used` flag only after all level checks pass. This remains a signal-consumption proxy, not exchange fill consumption.
- Exact `syminfo.mintick` from the matching Binance USD-M `PRICE_FILTER.tickSize` is required. Missing exact tick size or ATR(14) fails closed. Stage 9 still owns one-source-bar confirmed-output shift and MTF arbitration.
- Stage 8 adds 21 focused tests; Stage 1–8 focused total: 110; full regression suite: 488 passed. Source-derived tests do not independently prove TradingView runtime parity.
- No Dynamic Entry, live execution, private API, order-flow gate, Telegram/dashboard, risk sizing, database migration, or actual fill/position tracking. SQLite remains schema v5.


## SMC Engine V2 — accepted strategy direction (design checkpoint 0.1.0)

SMC V2 is a new Binance USDⓈ-M Futures scalping strategy, not a 1:1 port of the legacy Pine/EA-derived Unit 05D implementation. Unit 05D v0.25.0 remains immutable as a legacy/reference implementation; its planned nested M5/M15 Stage 9 arbitration is not carried into V2.

Accepted baseline: Scalping Hybrid; M15 soft market context; M5 primary setup; M1 entry timing plus optional independent M1 micro-setup; no nested OB priority. OB Limit/Retracement and Confirmation/Market are separate entry models. The initial OB source definition is the last opposing candle before a valid directional displacement that closes beyond confirmed structure; full wick is the initial zone boundary convention. M15 alignment, FVG, liquidity sweep, CVD/Delta, depth and absorption are soft confluence by default, not mandatory vetoes. Data integrity, valid structure/OB lifecycle, exact Binance filters, spread/slippage and risk remain hard constraints. Numeric thresholds and score weights require historical replay calibration.

### Unit 05E — SMC V2 Scalping Data Contract (Stage 1, v0.26.0)

- Adds an immutable V2-specific market-data view and independent readiness for M1, M5, optional M15 context, Mark Price, Delta/CVD, depth/quote, absorption and orchestrator health.
- Reuses existing validated Binance Kline and market-data objects; existing Unit 05A `StrategyMarketDataAdapter` remains behavior-compatible.
- Maps exact Binance `SymbolInfo` to `InstrumentSpec`; `PRICE_FILTER.tickSize` is mandatory for price-grid readiness and is never inferred from price precision.
- M1 and M5 readiness are independent; M15 is optional; CVD/Depth/Absorption unavailability does not veto structural scan. Entry quote readiness is separate and requires synchronized, fresh, update-ID-matched, tick-aligned best bid/ask.
- Adds bounded Aggregate Trade fan-out to optional orchestrator integration. The orchestrator remains the sole source-queue consumer; subscriber overflow fails closed and is not silently skipped.
- No SMC calculations, OB formation, entry, risk, order execution, database migration, or live/private API behavior is added in Stage 1.
- Focused tests: 27; full regression: 515 passed. Verification environment Python 3.13.5/Linux; Windows 10/Python 3.12.9 and live Binance validation remain pending.

The next stage is Unit 05E Stage 2 — SMC V2 Market Structure Engine. See `docs/SMC_V2_SCALPING_SPEC_v0.1.md`, `docs/BINANCE_MARKET_DATA_V2_AUDIT_v0.1.md`, and `docs/SCALPING_MARKET_DATA_CONTRACT_STAGE1.md`.


## Unit 05E — SMC V2 Scalping Market Structure (Stage 2, v0.27.0)

- Adds a new independent-per-symbol/timeframe market-structure engine on top of the Stage-1 `ScalpingMarketDataView`; it does not modify the preserved Unit 05D legacy Pine replay.
- M1/M5 structures run independently; M15 is optional advisory context and does not suppress M1/M5.
- Confirmed swing/internal pivots use configurable symmetric left/right windows; the pivot is not visible until its right-side confirmation candle closes. Strict equality rejects equal-high/low pivots; outside candles may confirm both sides.
- BOS/CHoCH requires a strict close cross through a previously confirmed pivot. Wick-only penetration is not a structure break. Initial and same-direction breaks are BOS; opposite-direction breaks are CHoCH.
- Each layer maintains independent direction and protected high/low landmarks. Event and pivot records retain exact source, confirmation, break and level provenance.
- Supports per-timeframe sensitivity overrides, deterministic warm-up/reset, bounded per-symbol/per-timeframe state, rolling incremental snapshots and fail-closed overlap/revision handling.
- MTF inputs are preflight-validated before any state mutates. Exact Binance tick-grid and closed contiguous candles are required.
- Stage 2 focused tests: 32; full regression: 547. These synthetic tests validate implementation mechanics, not profitability or Pine parity.
- No displacement/OB formation, OB lifecycle, FVG, sweep, Entry/SL/TP, risk, private API, order execution, Telegram/dashboard or database migration.


## Unit 05E — SMC V2 Displacement Qualification & Initial OB Formation (Stage 3, v0.28.0)

- Adds `strategy/scalping_order_block_formation.py`, consuming exact same-capture Stage-2 `StructureEvent` plus its immutable break-bar trace and Binance market-data view. Validates confirmed close-cross semantics, event/trace equality, pivot and break timestamps, previous close, same-capture Kline OHLC where available, symbol/timeframe and tick grid.
- Defines displacement leg as contiguous same-direction real-body candles ending with the break candle; doji/opposite body terminates the leg. Overlong legs exceed a bounded cap and are rejected instead of silently truncated.
- Measures break body, full range, body/range ratio, close extension beyond the broken structure level, tick-normalized extension, directional-leg candle count, leg body sum/range sum and leg body/range ratio. FVG evidence is explicit `NOT_EVALUATED`; no FVG gate exists in Stage 3.
- Searches backward from the displacement-leg start for the nearest opposing candle within a bounded source lookback. Bullish OB requires bearish source candle; bearish OB requires bullish source candle. Dojis are skipped; missing bars before a source is found fail closed.
- Uses full source-candle wick boundaries and exact tick alignment without price rounding. Candidate IDs are deterministic and linked to a unique StructureEvent, exact timeframe/layer, source candle and break candle. Repeated event delivery is idempotent.
- M1/M5 candidates are independent. M15 remains advisory-only and cannot create/suppress OB candidates. Candidate/trace/event/symbol/history resources are bounded and results serialize deterministically.
- Optional Decimal body/range and close-extension thresholds default to disabled until replay calibration; no threshold is claimed calibrated. ATR-normalized body/extension remains deferred pending explicit ATR period/smoothing semantics.
- Stage 3 focused tests: 30; Unit 05E Stages 1–3 focused total: 89; full regression: 577 passed. Synthetic tests validate mechanics only, not profitability or Pine parity.
- No OB lifecycle, mitigation, invalidation, retest, entry, SL/TP, scoring, risk, execution, private API, Telegram/dashboard or database migration. SQLite remains schema v5.




## Unit 05E — SMC V2 OB Validation & Lifecycle (Stage 4)

- Adds a separate lifecycle engine over immutable Stage-3 OB candidates and same-capture Binance closed Klines.
- M1/M5 lifecycle is independent; M15 is advisory-only. Overlapping zones remain distinct; no nested M5/M15 priority.
- Explicit states: CANDIDATE, ACTIVE_FRESH, TOUCHED, MITIGATED, INVALIDATED, EXPIRED. Touch is a candle-range intersection; positive entry-side penetration begins mitigation and maximum depth is retained as a clamped 0–1 ratio.
- Invalidation is explicitly configured as WICK or CLOSE and STRICT or INCLUSIVE distal boundary. Defaults WICK/STRICT.
- Provisional max age is 300 bars in the source timeframe; expires only after exceeding the limit and must be calibrated through Binance replay.
- Break candle is excluded from post-formation touch evaluation because OHLC cannot establish intrabar ordering. Same later candle records touch/depth before invalidation.
- Source/break OHLC and timestamps are cross-checked against same-capture Klines. Gaps, revised candles, late candidates and incomplete data fail closed.
- Bounded state may evict oldest terminal lifecycle records only; active records are not silently discarded. `filled=false` and `consumed=false` remain invariant until later execution/position layers.
- Stage 4 does not add retest, entry, scoring, FVG/sweep, Entry/SL/TP, risk or execution.


## Unit 05E — SMC V2 Liquidity & FVG Evidence Engine (Stage 5, v0.30.0)

- Adds `strategy/scalping_liquidity_fvg.py` as a separate optional evidence engine consuming same-capture Stage-2 confirmed pivots and closed Binance Klines. It does not modify Stage-2 structure, Stage-3 OB formation or Stage-4 OB lifecycle.
- Derives `SWING_HIGH/LOW`, `LOCAL_HIGH/LOW` and `EQUAL_HIGH/LOW` references from confirmed swing/internal pivots. A pivot is causally available only when its confirmation close precedes the candidate candle's open. Stage-2 close-break events retire a pivot only for subsequent candles; if a pivot is known broken but its event is no longer retained, it is excluded fail-closed.
- Equal-level clusters use exact Binance `PRICE_FILTER.tickSize * equal_level_tolerance_ticks`; default 2 ticks is provisional and requires replay calibration. Canonical level is an existing tick-aligned pivot price; no rounding.
- Closed-candle sweep evidence separates wick breach, close-through and strict close-back. High-side sweep direction is bearish; low-side sweep direction is bullish. Default `require_sweep_close_back=true`. Qualified sweeps consume their pivot IDs; Stage-2 confirmed close-through breaks retire levels after the break candle.
- Detects bullish FVG when `C3.low > C1.high`, zone `[C1.high, C3.low]`; bearish FVG when `C3.high < C1.low`, zone `[C3.high, C1.low]`. C1/C2/C3 and confirmation timestamps are retained. No minimum gap-size or ATR threshold is enabled.
- FVG status is independent: ACTIVE, TOUCHED, PARTIALLY_FILLED, FILLED. Maximum fill ratio is Decimal `[0,1]`; first-touch and full-fill timestamps are separate. A gap entirely beyond the zone without candle-range intersection does not fabricate touch/fill.
- Adds immutable evidence and trace records, deterministic IDs/JSONL, duplicate idempotence, incremental two-candle memory, exact tick and provenance checks, overlap/revision/gap fail-closed behavior, reset, atomic M1/M5 preflight and bounded histories. Filled FVGs may be evicted; nonterminal FVGs are never silently dropped.
- M1/M5 are independent; M15 advisory-only. Evidence cannot veto OB validity, create entries, rank candidates or mutate Stage-4 lifecycle. No CVD/Depth/Absorption integration, entry, scoring, SL/TP, risk, execution, private API, Telegram/dashboard or DB migration.
- Stage 5 focused tests: 36; Unit 05E Stages 1–5 focused total: 158; full regression: 646 passed. Synthetic tests validate mechanics only; historical Binance replay calibration, live Binance, Windows 10/Python 3.12.9 and Pine runtime parity remain pending.


## Unit 05E — Historical Replay Harness (Stage 6A, v0.31.0)

- Implements the deterministic chronological replay harness over existing Stage 1–5 evidence engines; their strategy detection rules are unchanged.
- Stage 1–5 replay requires native Binance USDⓈ-M M1 and M5 Klines; M15 remains optional and advisory-only. M1/M5 must not be nested or resampled from one another.
- Dataset manifest preserves source hashes, exact UTC millisecond Kline identities, symbol/interval, acquisition provenance, coverage/gaps and parser version. A replay envelope adds dataset/config/code hashes, capture sequence and deterministic capture ID because `ScalpingMarketDataView` currently exposes `captured_at_ms` but no global capture ID.
- Replay is scheduled by closed-candle close time. All Stages 2–5 consume one same-capture immutable view; forming/future candles are excluded.
- Exact `PRICE_FILTER.tickSize` remains authoritative. Current `/fapi/v1/exchangeInfo` is not a historical tick-size timeline; effective-dated metadata is required for strict tick-dependent historical calibration, otherwise output is explicitly metadata-limited.
- Data gaps and revised closed candles fail closed. Only the affected timeframe is reset/re-warmed; M1/M5 are independent and M15 cannot veto. Active OB/FVG at dataset end are right-censored, not called expired or filled.
- Outputs are immutable evidence JSONL and descriptive structure/lifecycle distributions; no fill, trade return, PnL, win-rate or profitability inference.
- Proposed experiment partition is chronological 60/20/20 train/validation/test, with no shuffling and frozen config before final test.
- Aggregate Trades/CVD is a later data tier. Faithful historical depth/absorption requires durable timestamped L2 snapshots/diffs; current in-memory state is insufficient.
- Stage 6A acceptance requires prefix invariance, future perturbation, closed-bar gating, M1/M5 isolation, M15 advisory isolation, chunk-size/restart determinism, gap handling and right-censor tests.
- See `SMC_V2_REPLAY_READINESS_STAGE6.md` and `NEXT_TASK.md`.


## Unit 05E — Deterministic Historical Replay Harness (Stage 6A)

- Public package: `divatrading.replay` (`ReplayDatasetManifest`, `ReplayKlineFile`, `ReplayMetadataSnapshot`, `ReplayConfig`, `HistoricalReplayRunner`, `ReplayRunSummary`).
- Dataset manifest v1 binds Binance USD-M USDT perpetual symbol, end-exclusive UTC window, native M1/M5 files, optional M15 files, source SHA-256, row counts/ranges and one metadata snapshot. Each timeframe must align to and fully cover the window boundaries; internal gaps remain explicit.
- Strict replay requires the declared metadata quality `HISTORICAL_EFFECTIVE`, exact `PRICE_FILTER.tickSize`, and declared effective interval covering the dataset. Current snapshot override is diagnostic-only. Multi-snapshot tick-size timelines are not implemented; caller-supplied historical status is not independently authenticated.
- CSV/TXT/ZIP reader streams native 12-column Kline rows into existing typed `Kline` values. ZIP input must contain exactly one CSV. REST helper uses bounded `HistoricalKlineService` pages. Gaps are preserved, never filled.
- Clock policy is `UTC_KLINE_CLOSE_PLUS_1MS_V1`; all intervals that close at the same boundary enter a common capture, and only bars with `close_time_ms < captured_at_ms` are passed to engines.
- Execution order: Stage-1 adapter, Stage-2 structure, Stage-3 OB formation, Stage-4 OB lifecycle, Stage-5 liquidity/FVG evidence. M1/M5 independent; M15 advisory-only.
- Evidence-only JSONL contains stable replay/capture envelopes, source/metadata/config/code hashes, stage traces, lifecycle evidence, gap events and descriptive summary. End-state active OB/FVG are right-censored. No fill/order/trade/PnL labels.
- Bounded rolling history is configurable from 2 to 2,000 candles (default 1,000). JSON checkpoint resumes by replaying the source prefix to reconstruct engine state, validates identity, durable ledger-prefix SHA-256 and newline boundary, then appends the deterministic suffix.
- CLI: `replay-validate` and `replay-run`. Detailed manifest/sample commands in `SMC_V2_DETERMINISTIC_REPLAY_STAGE6A.md`.
- Tests: 14 new focused Stage 6A tests; 158 focused Stages 1–5 tests; 660 full regression tests. Synthetic fixtures only; no historical Binance calibration, live exchange, Windows runtime or profitability claim.


## Unit 05E — Replay Dataset Quality, Warm-up Convergence & Evidence Analytics (Stage 6B; v0.34.0)

- Stage 6B.1 implements `divatrading.replay.quality`: streaming raw-source audit for native Binance CSV/TXT/ZIP and manifest-backed source verification. The raw audit runs before strict Stage 6A manifest construction so repeated timestamps and malformed inputs remain diagnosable.
- It distinguishes identical duplicates, conflicting revisions, non-monotonic rows, cross-file overlaps, malformed rows, out-of-window/misaligned open times, close-time mismatches, invalid OHLC relationships, source symbol declaration mismatch and exact Decimal `PRICE_FILTER.tickSize` violations. Input is never sorted, deduplicated, repaired, rounded or rewritten.
- Quality reports preserve expected/observed valid-bar counts, coverage ratio, explicit leading/trailing/internal gap counts, bounded chronological gap-cluster samples, row-integrity counters, source SHA-256 and metadata provenance/effective window. Source hashes are checked before and after scanning. Current snapshots are diagnostic-only; historical-effective labels/evidence references are caller-supplied and not authenticated by the bot.
- `replay-quality` CLI supports raw mode (`--source INTERVAL=PATH`) and manifest mode (`--manifest`); it schema-validates and atomically writes the report. Exit code 0 means PASS/WARN, 9 means a quality FAIL report was written, 2 means a request/runtime error.
- Warm-up trials compare different pre-roll lengths over the same common evaluation slice, with identical code/config/metadata identity and evaluation-slice hashes. State is continuous across the evaluation boundary; gaps remain explicit confounders. Comparisons are descriptive with no hard-coded convergence threshold.
- Train/validation/test target 60/20/20 in chronological half-open windows. Boundaries align to the LCM of active timeframe durations. One full replay labels evidence by known-at time; engines are never reset at split boundaries.
- Evidence analytics operate only on immutable Stage 6A JSONL, use actual closed bars from `REPLAY_CAPTURE_SUMMARY.updated_intervals`, and report per-1,000-bar rates, rejection reasons, exact Decimal nearest-rank distributions, OB lifecycle and liquidity/FVG evidence. OB nonterminal states and non-FILLED FVGs at window end are administrative right-censoring, not trade failure.
- Schemas: `docs/schemas/stage6b_dataset_quality_report.schema.json`, `stage6b_warmup_convergence_report.schema.json`, and `stage6b_evidence_analytics_report.schema.json`.
- Stage 6B.1 raw-source dataset quality auditor, Stage 6B.2 chronological split/evidence analytics and Stage 6B.3 warm-up convergence runtime are implemented. Stage 6B.2 uses strict immutable Stage 6A JSONL validation, chronological half-open 60/20/20 partitions aligned to the LCM of enabled intervals, one continuous replay state, closed-bar denominators from capture `updated_intervals`, descriptive Stage 2–5 metrics, Decimal distributions and administrative OB/FVG right-censoring. Stage 6B.3 `replay-convergence` compares distinct pre-roll trials over identical native-Kline evaluation slices with frozen code/config/metadata/clock identity, per-timeframe source fingerprints, gap/readiness confounders and stable Stage 2–5 evidence keys. Replay-relative fields ending `_index` are excluded from equality only; raw payloads remain available in divergence samples. Both analysis commands use immutable provenance checks and temporary SQLite storage; convergence has no automatic pass threshold. See `SMC_V2_REPLAY_CHRONOLOGICAL_ANALYTICS_STAGE6B2.md` and `SMC_V2_WARMUP_CONVERGENCE_STAGE6B3.md`. Next: Stage 6B.4 integration/final review; then Stage 6C real-data calibration after the required provenance gates. No real Binance warm-up convergence/calibration, scoring, qualification, entry, fills/PnL, CVD/Depth/Absorption replay, private API, live order or database migration is included.


## Telegram Signal Center and Kronos Shadow Forecast (v0.58.0rc2)

- SMC is the sole signal qualification authority. The market-only `SIGNAL_ONLY` flow bypasses execution sizing and cannot submit orders.
- Telegram signal delivery is outbound-only `sendPhoto`; the owner-only Telegram command poller is a separate process.
- Charts show the actual closed Binance USD-M M5 candles, SMC OB zone when available, Entry/SL/TP1/final TP and gross RRR. Net RRR remains unavailable until actual fee-tier/slippage assumptions are configured.
- Kronos-mini is optional and M5-only, with a default 512-bar context (bounded by available history), minimum 64 closed contiguous bars and a 6-bar forecast horizon. It cannot qualify, rank, veto, resize, or execute a setup.
- Forecasts are stored with input/model/tokenizer/source provenance and later compared against the exact future closed M5 timestamps. Forecast metrics do not represent trade PnL or probability of trade success.
- Single `sample_count=1` output is drawn as one projected path; no confidence band is claimed.
- The user explicitly has not downloaded Kronos yet. Installation is local/opt-in and weights remain outside the source ZIP.
