# SMC V2 Replay Dataset Quality, Warm-up Convergence & Evidence Analytics — Stage 6B Design

**Implementation checkpoint:** Unit 05E v0.32.0  
**Implementation target:** Unit 05E Stage 6B implementation release v0.32.0  
**Parent implementation:** Stage 6A v0.31.0 (`Deterministic Historical Replay Harness`)  
**Status:** Stage 6B.1 dataset quality auditor implemented; Stage 6B.2/6B.3 remain design-only.

## 1. Purpose and hard boundaries

Stage 6B adds an audit and measurement layer around the immutable Stage 6A replay ledger. It must answer four questions without changing the SMC V2 strategy:

1. Is each native Binance USDⓈ-M Kline source complete, chronologically valid, correctly aligned and on the declared exchange price grid?
2. How sensitive are Stage 2–5 evidence records to the amount of pre-roll history available before one common evaluation window?
3. How should a single chronological replay be labelled into train, validation and test windows without resetting causal strategy state?
4. What descriptive distributions and event rates are visible in the Stage 6A evidence ledger, with right-censoring and provenance retained?

Stage 6B is **not** a parameter optimizer, scoring system, candidate qualifier or trade simulator. The following remain excluded: entry, SL/TP, order placement, exchange fills, trade labels, fees/slippage, PnL, win rate, expected value, profitability inference, risk sizing, position management, CVD/Depth/Absorption replay, Telegram/dashboard and SQLite migration. M1/M5 stay independent. M15 remains advisory-only. Legacy nested M5/M15 priority must not be reintroduced.

## 2. Inputs and provenance

### 2.1 Required inputs

- Stage 6A `ReplayDatasetManifest` and the exact source CSV/ZIP files it references.
- Exact parsed `PRICE_FILTER.tickSize` from the manifest metadata snapshot.
- Stage 6A JSONL ledger, replay header and final summary for evidence analytics.
- One frozen software/code/config identity per comparison family.

### 2.2 Metadata quality

Retain the Stage 6A labels:

- `HISTORICAL_EFFECTIVE`: caller-declared effective metadata with `effective_from_ms` / `effective_to_ms`; the declaration must be backed by independently retained exchange evidence.
- `CURRENT_SNAPSHOT_ONLY`: present-day snapshot; diagnostic only and not eligible for strict historical calibration.
- `MISSING_OR_CONFLICTED`: exact tick size is not trustworthy; quality report must fail strict grid validation rather than infer from `pricePrecision`.

A future effective-dated metadata timeline is outside Stage 6B unless separately approved. Until then, strict replay windows must be metadata-homogeneous and covered by one exact tick-size declaration. Stage 6B must never imply that it independently authenticates Binance historical filter changes.

### 2.3 Source identity

Every report records `dataset_id`, symbol, half-open dataset window `[start_open_time_ms, end_open_time_ms)`, all source paths and SHA-256 values, metadata SHA-256/quality/effective window, replay run ID where applicable, code SHA-256 and config SHA-256. Report hashes are deterministic: canonical JSON with sorted keys and compact separators, excluding only the report's own `report_sha256` field.

## 3. Dataset quality audit

### 3.1 Run before strict manifest construction

`ReplayKlineFile.inspect()` and Stage 6A's streaming reader deliberately reject duplicate or decreasing open times. Therefore, the Stage 6B auditor must support a **raw-source inspection mode before a strict manifest is accepted**. It receives symbol, interval, dataset window, raw source descriptors and the exact metadata snapshot. It must not silently sort, deduplicate, repair, interpolate or synthesize source candles.

For a valid Stage 6A manifest, the same report can run in manifest-verification mode and cross-check every manifest hash, row count and range. Raw-source inspection is necessary to report duplicate/revision evidence that the strict Stage 6A reader otherwise rejects at first occurrence.

### 3.2 Expected bars and coverage

For each selected interval with step `S_ms`:

- Require `start_open_time_ms % S_ms == 0` and `end_open_time_ms % S_ms == 0`.
- Expected opens are the exact arithmetic sequence `start, start + S, …, end - S`.
- `expected_bar_count = (end - start) / S`.
- `observed_unique_bar_count` counts distinct in-window, interval-aligned timestamps with at least one parseable Kline row whose close time and OHLC relationship are valid; conflicting revisions still represent one covered timestamp if at least one revision is parseable and valid. Off-grid prices remain parseable coverage but fail the separate tick-grid check.
- Rows with malformed numeric fields, mismatched close time or invalid OHLC relationship are excluded from parseable coverage and remain separately counted.
- `missing_bar_count = expected_bar_count - observed_unique_bar_count`.
- `coverage_ratio` is reported as both numerator/denominator and a fixed-precision decimal string; the integer counts remain authoritative.
- `leading_missing_bar_count`, `trailing_missing_bar_count`, and internal gaps are separate. Gap clusters are chronologically identified; at most 100 are retained in `gap_clusters`, with `gap_cluster_count` and `gap_clusters_truncated` preserving full aggregate visibility. Stage 6A strict manifest boundaries must not be loosened by the auditor.

### 3.3 Gap clusters

A gap cluster contains `last_valid_open_time_ms`, `first_missing_open_time_ms`, `last_missing_open_time_ms`, `first_resumed_open_time_ms` and `missing_bar_count`. Adjacent missing opens belong to one cluster. No gap is filled. A replayable internal gap remains a reset/re-warm-up boundary for only the affected symbol/timeframe, exactly as Stage 6A specifies.

### 3.4 Duplicate, revision and ordering evidence

The scanner preserves raw 12-column row identity and classifies:

- `identical_duplicate_rows`: repeated open time with identical trimmed values across all 12 parsed CSV fields.
- `conflicting_revision_rows`: repeated open time with any differing trimmed value among the 12 parsed CSV fields (including OHLC, volume, close time, trade count or taker volumes).
- `non_monotonic_rows`: a row open time lower than the preceding row within one source file.
- `cross_file_overlap_rows`: repeated timestamps across source files.

A conflicting revision is not resolved by “latest wins”. Any duplicate/revision/order anomaly is visible in the report and blocks strict replay dataset acceptance until the source owner provides a corrected, independently sourced file. Identical duplicates are still an integrity defect; they are not silently dropped.

### 3.5 Timestamp and row validity

Count malformed rows, out-of-window timestamps, open-time interval misalignment, close-time mismatch (`close_time_ms` must equal `open_time_ms + S_ms - 1` for these fixed-minute intervals), symbol/interval mismatch, invalid OHLC relationship and invalid numeric fields. A malformed row must not be converted to a synthetic or partial candle. The report may continue scanning other rows to maximize diagnostics, but it must mark the affected source as not replayable.

### 3.6 Exact tick-grid audit

For every successfully parsed in-window candle, check `open`, `high`, `low` and `close` against exact `Decimal` multiples of the declared `tickSize`. A price is on-grid only when `price % tickSize == 0`. Do not use `pricePrecision`, float tolerance, rounding or nearest-tick correction. Record violation count and a bounded sample containing source path, row number, open time, field, exact price and tick size. Volume values are not price-grid checked.

### 3.7 Quality status

- `PASS`: no missing rows, duplicate/revision, non-monotonic, malformed, timestamp, OHLC or tick-grid issues; source hashes and metadata provenance checks pass.
- `WARN`: internal gaps exist but all remaining rows are otherwise valid and hash/provenance checks pass; Stage 6A can replay with explicit gap-reset events, but the dataset is not “continuous”. `CURRENT_SNAPSHOT_ONLY` metadata and missing independent evidence reference also force diagnostic status.
- `FAIL`: source hash mismatch, leading/trailing coverage defect, conflicting revision, duplicate/open-time ordering defect, malformed/out-of-window row, timestamp/OHLC defect, tick-grid violation, metadata conflict or missing exact tick size.

The report separates `quality_status` from strict replay eligibility. In Stage 6C.2 schema v2, `eligibility_gates.market_data` independently reports structural source/candle integrity, while `eligibility_gates.execution_metadata` reports exact contract-rule evidence. An explicit `PROVISIONAL_STRATEGY_EVIDENCE` replay can proceed only when the market-data gate is PASS and an exact candidate tick size plus valid instrument metadata are present. It still reports `execution_metadata.status=BLOCKED`, `strict_replay_eligible=false`, and `result_scope=STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION`. It is not eligible for execution validation or strict calibration. A PASS with caller-declared `HISTORICAL_EFFECTIVE` remains a provenance claim, not independent proof of historical exchange metadata. See `SMC_V2_REPLAY_ELIGIBILITY_GATES_STAGE6C2.md`.

## 4. Warm-up convergence protocol

### 4.1 Trial design

Compare at least three pre-roll windows (short, medium, long) when data permits. Two windows are the minimum diagnostic fallback and must be labelled `LIMITED_TWO_TRIAL_COMPARISON`. The windows are expressed as exact per-timeframe bar counts and corresponding UTC start times; do not compare only a single elapsed duration when M1/M5/M15 are enabled.

All trials must share:

- Same symbol and same active timeframe set.
- Exactly identical evaluation interval `[evaluation_start_ms, evaluation_end_ms)`.
- Byte-identical source candle content over that common evaluation interval, proven by per-interval evaluation-slice fingerprints.
- Same Stage 6A software version, `code_sha256`, `config_sha256`, metadata SHA-256 and replay clock policy.
- Same strategy configuration and no strategy reset at `evaluation_start_ms`.

Trial `dataset_id` and `replay_run_id` will differ because pre-roll boundaries differ. That is expected. The trial-level `evaluation_slice_sha256` is a composite hash of sorted `(interval, interval_slice_sha256)` pairs; this proves that every enabled timeframe has the same closed Kline content over the evaluation window. The common evaluation-slice fingerprint—not equality of whole-dataset hashes—is the required data identity for a convergence comparison.

### 4.2 Causal procedure

Each trial replays from its own pre-roll start, continuously and chronologically, through the same evaluation end. Engine state is not reset when the replay clock crosses `evaluation_start_ms`. Pre-roll evidence is excluded from comparison; pre-roll state is retained. A gap before or inside the evaluation interval resets the affected timeframe according to Stage 6A and is recorded as a convergence confounder.

All trial ledgers are immutable inputs. The convergence analyzer filters records by `known_at_time_ms` in the common evaluation interval and compares strategy records without treating dataset-scoped capture IDs or whole-source hashes as strategy evidence.

### 4.3 Evidence matching

Use stable record identity keys, not list position:

- Structure: timeframe + `BAR_TRACE` bar open time; also compare embedded pivot/event identities and layer snapshots.
- OB formation: timeframe + `event_id` / `candidate_id`.
- OB lifecycle: timeframe + `candidate_id` + `known_at_time_ms` for snapshots; transition `event_id` for transition traces.
- Liquidity/FVG: timeframe + reference/sweep/FVG identity; FVG status snapshots include `fvg_id` + `known_at_time_ms`.

For each trial pair, report `exact_payload_matches`, same-key/different-payload records, left-only records and right-only records. `matched_key_agreement = exact_payload_matches / matched_keys`; it is null when no key matches. Report it as a descriptive ratio; do not introduce a universal pass threshold or select the “best” trial automatically. Longer pre-roll is a comparison reference, not proof of correctness.

### 4.4 Convergence outputs

At minimum report, per timeframe and stage:

- Pre-roll bar count and elapsed time.
- Common evaluation slice hash.
- Data gaps and bars since the last gap at evaluation start.
- Evidence record counts by type.
- Exact identity/payload agreement, one-sided evidence and changed payload counts.
- First divergence time and bounded examples of differing identities.
- Readiness changes and current OB/FVG states at the end of the evaluation window.

No convergence threshold is hard-coded in this design. Parameter calibration cannot proceed until the owner reviews the observed sensitivity and approves a threshold policy.

## 5. Chronological train / validation / test partitions

### 5.1 Default plan

Default target fractions are 60% / 20% / 20% by elapsed UTC time over one dataset window. Boundaries are quantized to the least common multiple of active interval durations (for Binance M1/M5/M15 this is 15 minutes). Report target and realized duration fractions; do not claim exact 60/20/20 if alignment moves a boundary.

Segments are half-open:

- Train: `[dataset_start, train_end)`
- Validation: `[train_end, validation_end)`
- Test: `[validation_end, dataset_end)`

Every segment must be non-empty and contain at least one complete candle for every active interval. If a short dataset cannot satisfy this, split creation fails with an explicit reason; do not silently reduce the segments.

### 5.2 Single continuous replay

Run Stage 1–5 once from dataset start through dataset end. The strategy engines retain state across both split boundaries. There is no split-triggered reset, warm-up restart, data re-fetch, shuffle or cross-boundary lookahead. Every ledger evidence record receives a split label from its `known_at_time_ms`; the split plan itself is anchored to the dataset window and is recorded in the analytics report.

### 5.3 Leakage controls

- Train/validation/test are chronological; never shuffle.
- Any parameter/config selection may use train and validation only.
- Before opening test analytics, freeze dataset/source hashes, metadata SHA, code SHA, config SHA, split boundaries and analysis schema version.
- The final test report records the frozen identities and whether the test interval has been opened.
- No tuning or threshold selection using test distributions, outcomes or summaries.
- A test ledger is not an independent holdout if its data, config or code was already used to design/adjust the strategy.

Stage 6B reports partitions and enforces identity checks; it does not optimize or select parameters.

## 6. Evidence analytics over Stage 6A JSONL

### 6.1 Ledger integrity

The analyzer streams JSONL and validates UTF-8, one JSON object per line, `record_schema_version`, run identity, monotonic `capture_sequence` and `known_at_time_ms`, presence of a run header and terminal run summary, and matching dataset/config/code/metadata provenance. A truncated, mixed-run, reordered or malformed ledger fails closed. Preserve the exact input ledger SHA-256 and file size. Do not rewrite the source ledger.

### 6.2 Closed-bar denominators and rates

Use `REPLAY_CAPTURE_SUMMARY.payload.updated_intervals` to count actual newly closed candles per interval. This is the authoritative denominator; do not use the total number of captures as a proxy for bars. Count events by `record_type`, stage, timeframe and split. Report event rates as `event_count / closed_bar_count * 1000`, with integer numerator/denominator and a deterministic decimal string. If the denominator is zero, rate is `null`, never zero.

### 6.3 Required descriptive metrics

- Stage 2: BOS/CHoCH and pivot counts by timeframe/layer, readiness periods and warm-up status.
- Stage 3: OB formation outcomes and rejection reason-code frequencies; created candidate counts.
- Displacement: sample count and exact Decimal min, nearest-rank P50/P90/P95/max for break body/range ratio, close extension in ticks, leg body/range ratio and directional-leg candle count.
- Stage 4: unique OB candidate counts; final status counts; age-bar and elapsed-time distributions; first-touch, mitigation, invalidation and expiry counts/timing; mitigation depth distributions; reason-code counts.
- Stage 5: reference counts by type, sweep counts by outcome and qualification, FVG counts by direction/status, maximum fill-ratio distributions and elapsed bars from FVG confirmation to touch/full mitigation.
- Right-censored counts: OBs whose last observed lifecycle state at the analysis-window end is nonterminal (`CANDIDATE`, `ACTIVE_FRESH`, `TOUCHED`, `MITIGATED`) and FVGs whose last observed state is not `FILLED`. `INVALIDATED` and `EXPIRED` are terminal OB states; `FILLED` is a terminal FVG price-zone state. None of these means an exchange order was filled.

### 6.4 Quantile and Decimal policy

All prices and measured ratios are parsed as `Decimal`; no float conversion is allowed for source measurements. Quantiles use the nearest-rank method: sort ascending and select rank `ceil(p * n)` using one-based rank, for `p ∈ {0.50, 0.90, 0.95}`. Empty distributions return `n=0` and `min/p50/p90/p95/max=null`. Decimal values serialize as canonical base-10 strings without exponent notation. No normality, profitability or significance inference is made.

### 6.5 Snapshot semantics

For OB/FVG state distributions, retain the latest snapshot for each entity at or before the analysis boundary. Lifecycle transitions remain event counts; repeated snapshots must not inflate unique candidate/FVG counts. Split-specific right-censoring is administrative censoring at that split's end and must be labelled as such. Do not interpret an entity crossing a split boundary as a new setup in the following split.

## 7. Machine-readable report contracts

The three Draft 2020-12 schemas in `docs/schemas/` are the design contracts:

- `stage6b_dataset_quality_report.schema.json`
- `stage6b_warmup_convergence_report.schema.json`
- `stage6b_evidence_analytics_report.schema.json`

All reports are deterministic JSON objects with `report_schema_version=1`, a fixed `report_type`, exact provenance fields and `report_sha256`. A schema validates structure; the report hash validates canonical content. Store each report beside (not instead of) the immutable ledger and manifest. Large issue/evidence samples must be bounded and disclose their cap; complete counts remain in aggregate fields.

## 8. Module and CLI boundaries

Implemented in v0.32.0:

- `divatrading.replay.quality`: raw CSV/TXT/ZIP and manifest-backed source scanner, duplicate/revision/order classification, coverage/gap clustering, exact tick-grid checks, deterministic report hashing and atomic report writer.
- `replay-quality`: raw-source mode (`--symbol`, UTC window, repeated `--source INTERVAL=PATH`, optional metadata/expected hashes/row counts) and manifest verification mode (`--manifest`). It performs no exchange requests and does not mutate input files.

Remaining design-only modules:

- `divatrading.replay.splits`: chronological aligned split plan and split-label helper.
- `divatrading.replay.analytics`: strict ledger reader, event/rate/distribution aggregation and right-censor snapshots.
- `divatrading.replay.warmup`: trial manifest validation, evaluation-slice fingerprinting and pairwise evidence comparison.

Remaining read-only CLI targets:

- `replay-analyze --ledger ... --split-ratios 60/20/20 --report ...`
- `replay-warmup-compare --trials ... --evaluation-start-ms ... --evaluation-end-ms ... --report ...`

All commands must remain deterministic and must not initiate exchange requests or mutate source ledgers/data.

## 9. Implementation sequence

1. **6B.1 Dataset quality auditor — IMPLEMENTED in v0.32.0:** raw-source scanner, expected/observed coverage, row integrity, duplicate/revision classification, bounded gap clusters, exact tick grid, metadata caveats, quality schema, read-only CLI and synthetic source fixtures.
2. **6B.2 Temporal split plan and ledger analytics — PENDING:** strict ledger reader, aligned 60/20/20 plan, continuous-state split labelling, rates/distributions/right-censoring and analytics schema.
3. **6B.3 Warm-up convergence analyzer — PENDING:** common evaluation-slice identity, at least three trial manifests where possible, pairwise key/payload comparison, warm-up schema and anti-look-ahead fixtures.
4. **6B.4 Integration and package verification — PENDING:** cross-module CLI, README/spec/handoff/checkpoint, clean extraction, Windows target-compatible syntax, full regression and schema meta-validation.

Stage 6B.1 is now delivered as a verified checkpoint. Continue with 6B.2 as a separate checkpoint; do not collapse all remaining functionality into one unbounded in-memory report builder.

## 10. Synthetic acceptance matrix

| Case | Expected result |
|---|---|
| Complete M1/M5 data, exact tick grid, effective metadata | Quality PASS; exact expected/observed counts |
| One internal missing run | One gap cluster; quality WARN; no synthetic candle |
| Missing leading/trailing bar | Quality FAIL; strict manifest remains rejected |
| Exact duplicate row | Duplicate counter increments; quality FAIL |
| Same timestamp, changed OHLCV/trade metadata | Revision counter increments; quality FAIL |
| Decreasing open time within a source | Ordering anomaly; quality FAIL |
| One off-grid OHLC field | Exact tick violation; quality FAIL; no rounding |
| Current metadata snapshot | Diagnostic warning; strict calibration ineligible |
| Different pre-rolls, identical common evaluation data and evidence | Exact pairwise matches; deterministic report |
| Different pre-rolls with a pivot/OB/FVG boundary-sensitive divergence | One-sided/changed evidence and first divergence disclosed |
| Future rows changed only after evaluation end | Common evaluation fingerprint and comparison unchanged |
| Gap before evaluation start | Gap/reset and bars-since-gap disclosed; no false convergence claim |
| Continuous ledger crosses train/validation/test | Split labels change; engine state and entity identity do not reset |
| Truncated, mixed-run or reordered ledger | Analytics fails closed |
| Empty distribution / zero closed bars | `n=0`, null statistics/rates; no divide-by-zero |
| OB remains MITIGATED or FVG remains PARTIALLY_FILLED at window end | Administrative right-censor count increments; not classified as trade failure |

## 11. Exit criteria and real-data gate

Stage 6B is implementation-complete only when the schemas are exercised by synthetic acceptance tests, reports are deterministic and content-addressed, input ledgers stay unchanged, quality defects are never repaired silently, warm-up comparison uses identical evaluation slices, split boundaries do not reset engines, and anti-look-ahead fixtures pass from clean extraction.

Long-range strict calibration remains blocked until the project has native Binance USDⓈ-M M1/M5 archives for at least the selected pilot period and independently retained evidence for the effective `tickSize` over every metadata segment. A BTCUSDT 30-day smoke dataset is a tooling test only; first evaluation target remains at least 12 fully closed UTC months. ETHUSDT is cross-symbol robustness only after the protocol and configuration have been frozen. No performance conclusion follows from Stage 6B analytics.
