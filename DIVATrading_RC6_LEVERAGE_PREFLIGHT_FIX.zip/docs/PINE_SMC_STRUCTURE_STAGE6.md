# Unit 05D — Trigger and Sweep Qualification (Stage 6)

## Status and source identity

- Release: `0.23.0`.
- Parent checkpoint: Unit 05D Stages 1–5 v0.22.0; ZIP SHA-256 `fdfcb5bca168e8a9e10071cb1fe6698e7a564c3bcea90d1c2faef9e0e2fce058`.
- Original Pine v6 SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented Pine SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Capture patch SHA-256: `4901facc8365692b51397eabc34d232d7de86a78e6f3c28e2eb894df81a160ed`.
- Pine source block: `FindSignal()` trigger and sweep clauses, lines 572–610.

## Implemented behavior

1. Adds exact trigger/sweep Pine inputs to `PineSmcStructureConfig`:
   - `trigger_mode="Either"` (`Rejection`, `Structure`, `Either`).
   - `struct_allow_bos=true`.
   - `min_wick_pct=20.0`, finite and in `[0,100]`.
   - `require_sweep=false`.
   - `sweep_lookback=20`, integer range `[2,100]`.
   - `sweep_window=5`, integer range `[1,20]`.
2. Stage 6 consumes only `PineSmcObEligibilityTrace.eligible_candidates`; it does not rescan the active OB array, reorder candidates or change `used`.
3. Rejection trigger mirrors Pine's exact condition order and comparisons:
   - Evaluated only when `trigger_mode != "Structure"` and current candle range is positive.
   - Bullish: `low <= OB top`, green candle, `close > OB midpoint`, and `(min(open, close)-low)/range*100 >= minWickPct`.
   - Bearish: `high >= OB bottom`, red candle, `close < OB midpoint`, and `(high-max(open, close))/range*100 >= minWickPct`.
4. Structure trigger is evaluated only when `trigger_mode != "Rejection"`, the Stage-2 event-extreme index is valid, and it is strictly greater than the candidate OB break index.
   - Bullish CHoCH always qualifies as the event type; bullish BOS requires `struct_allow_bos`. The event extreme must be `<= OB top`.
   - Bearish CHoCH always qualifies; bearish BOS requires `struct_allow_bos`. The event extreme must be `>= OB bottom`.
5. Trigger code priority is exact: rejection `1`, otherwise structure `2`, otherwise `0`. If both booleans are true, rejection wins.
6. Sweep requirement is bypassed and passes when `require_sweep=false`. When enabled, each eligible candidate runs the source's nested `sweep_window` and `sweep_lookback` loops:
   - Only offsets satisfying `localIndex - sweepOffset > sweepLookback` are inspected.
   - Bullish sweep requires a strict new low below the prior lookback minimum and a strict close back above that minimum.
   - Bearish sweep requires a strict new high above the prior lookback maximum and a strict close back below that maximum.
   - Historical offsets map to the retained local SMC candle history without filling or synthesizing bars.
7. Candidates remain newest-to-oldest. The scan stops at the first candidate with a non-zero trigger and passing sweep gate, matching Pine's `while ... chosen == -1` behavior. A failed trigger or failed sweep continues to the next older Stage-5 candidate.
8. The immutable `PineSmcObTriggerEvaluation` records active-array index, OB snapshot, rejection/structure booleans, trigger code, sweep result and accepted-candidate boolean. `PineSmcTriggerSweepTrace` records the ordered evaluations, chosen active-array index and chosen trigger code. The result is only a qualified candidate, not a final signal.
9. Per-bar JSONL trace and replay metadata include all Stage-6 configuration and outputs.

## API changes

`PineSmcStructureConfig` adds:

- `trigger_mode: str = "Either"`
- `struct_allow_bos: bool = True`
- `min_wick_pct: float = 20.0`
- `require_sweep: bool = False`
- `sweep_lookback: int = 20`
- `sweep_window: int = 5`

Public strategy exports add:

- `PineSmcObTriggerEvaluation`
- `PineSmcTriggerSweepTrace`

`PineSmcBarTrace` adds `trigger_sweep`; `PineSmcStructureReplayResult` records the effective Stage-6 inputs. SQLite schema remains v5; no migration is required.

## Deterministic Stage-6 tests

Sixteen focused tests cover config defaults and validation, bullish/bearish rejection formulae, zero candle range, trigger-mode gating, event-after-break strictness, inclusive OB boundary comparison, CHoCH/BOS policy, rejection-over-structure priority, Stage-5 order retention, first accepted-candidate short-circuit, bullish/bearish strict sweeps, sweep-window historical offsets, insufficient-lookback handling, disabled-sweep bypass, per-candidate sweep continuation, immutable trace and JSONL metadata.

These are source-derived implementation tests, not independent TradingView runtime parity observations.

## Stage-6 exclusions

No `f_scoreOB()` scoring, entry-depth bands, final signal emission, Pine `entry=close`/SL/TP proxy geometry, `levelsOK`, OB `used` mutation, one-source-bar output shift, MTF arbitration, Dynamic Entry/SL/TP, position management, CVD/order-flow gates, Telegram/dashboard, private API, live execution or database migration is introduced.

## Evidence and limitations

- Focused Stage-6 tests: 16 passed.
- Focused Stages 1–6 tests: 73 passed.
- Full regression suite in the working tree: 451 passed.
- Independent TradingView reference observations/fixtures accepted: zero. Runtime parity remains unmeasured.
- Verification target is Python 3.13.5/Linux; Windows 10/Python 3.12.9 remains outstanding.
- Preserve the Pine CC BY-NC-SA 4.0 notice and confirm permissions before commercial use or redistribution of derivative code.
