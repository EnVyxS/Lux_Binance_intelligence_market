# SMC V2 Replay Eligibility Gates — Stage 6C.2 (v0.37.0)

## Purpose

Stage 6C.2 separates two questions that were previously combined in one dataset-quality status:

1. Are the native market-data sources structurally suitable for strategy-evidence replay?
2. Are exchange trading rules historically evidenced well enough to validate simulated order prices and strict execution assumptions?

A failure in the second category must not misclassify otherwise clean OHLCV data. Conversely, a clean market-data gate must never be presented as strict execution eligibility.

## Gate A — Market data

`eligibility_gates.market_data` summarizes source/candle integrity independently of exchange metadata. It covers source hashes, coverage, gaps, duplicates/revisions, ordering, timestamp alignment, close-time consistency, numeric/OHLC relationships and other candle structural defects.

- `PASS`: the tested native sources are structurally complete and internally consistent for the declared window.
- `WARN` / `FAIL`: strategy replay is blocked by the gate; no gap is repaired or interpolated.
- `eligible_for_strategy_replay=true` is only a data-readiness result, not a model-validity or execution statement.

## Gate B — Execution metadata

`eligibility_gates.execution_metadata` reports exact contract-rule evidence, including `PRICE_FILTER.tickSize` provenance and historical effective bounds.

- `PASS`: required exact metadata and declared effective interval satisfy the strict contract.
- `BLOCKED`: metadata is absent, current-only, conflicted, lacks the required independent evidence reference, or fails tick-grid checks.
- `strict_replay_eligible` remains false while this gate is blocked.

Current `/fapi/v1/exchangeInfo` is a current snapshot. It may corroborate the present contract configuration but cannot be relabeled as an historical snapshot or used to infer historical effective bounds.

## Provisional strategy-evidence mode

Workflow plans may set:

```json
"replay_mode": "PROVISIONAL_STRATEGY_EVIDENCE"
```

The mode is opt-in. It requires:

- market-data gate `PASS`;
- an exact positive candidate tick size supplied in the current/diagnostic instrument snapshot;
- valid symbol/contract metadata;
- no candle integrity failure, gap or off-grid OHLC value.

The replay uses `strict_metadata=false` only for the explicit provisional workflow. Result reports must identify:

- `workflow_status: COMPLETED_PROVISIONAL`;
- `execution_metadata_gate: BLOCKED`;
- `strict_execution_eligible: false`;
- `result_scope: STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION`.

This mode may be used to inspect deterministic market-structure, OB, lifecycle, liquidity and FVG evidence. It must not be used to claim exchange-order validity, accurate fills, transaction-cost fidelity, strict backtest readiness, calibration acceptance or profitability. Any entry/SL/TP prices derived from the candidate tick size are provisional and are not validated against the historical exchange filter.

The original workflow default remains `STRICT`; existing plans without `replay_mode` continue to use strict metadata eligibility.

## Real BTCUSDT Stage 6C.2 smoke result

Dataset: Binance USDⓈ-M BTCUSDT perpetual, `[2026-10-12T00:00:00Z, 2026-11-11T00:00:00Z)`.

- M1: 43,200 rows; M5: 8,640 rows.
- Source and derived-file provenance checks passed; no gaps, duplicates, malformed rows, ordering defects or OHLC relationship defects.
- Candidate `tickSize=0.10` had zero observed OHLC-grid violations, but it remains current-only corroboration, not a historical exchange-rule proof.
- Main raw-source audit: market-data gate `PASS`, execution-metadata gate `BLOCKED`, provisional strategy replay eligible, strict replay not eligible.

Integrated provisional workflow was run over a bounded common 15-minute evaluation window with three pre-roll histories (3h, 2h, 1h), M1/M5. All three trial replays completed, each gap count was zero, all checkpoint/resume probes completed, chronological analytics completed, and 24 pairwise convergence comparisons were generated. This is an integration/tooling smoke, not calibration.

All three trials reported READY for M1 and M5 during the short evaluation window. That readiness does not establish state convergence. The comparison verdict was `automatic_convergence_verdict=false`: 3h and 2h pre-rolls matched exactly on Stage 2 market-structure and Stage 3 OB-formation evidence, but diverged on Stage 4 OB-lifecycle and Stage 5 liquidity/FVG evidence; the 1h pre-roll also differed on Stage 2 structure. Longer pre-roll experiments and a sufficiently representative evaluation window are required before a warm-up sufficiency policy can be approved.

The exact workflow and convergence report hashes are retained in the Stage 6C.2 evidence pack / continuation handoff.

## Non-goals and release boundary

- No current metadata is promoted to `HISTORICAL_EFFECTIVE`.
- No bypass of `EXACT_TICK_SIZE_MISSING` occurs in strict mode.
- No live/private API, order placement, fill/PnL simulation, strategy scoring, qualification, or entry/SL/TP execution is added.
- No Windows 10 / Python 3.12.9 verification is claimed from the Linux/Python 3.13.5 build environment.
