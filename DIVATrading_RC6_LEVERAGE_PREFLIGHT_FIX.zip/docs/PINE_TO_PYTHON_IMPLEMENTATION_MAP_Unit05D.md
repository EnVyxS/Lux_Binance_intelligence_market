# DIVATrading — Pine-to-Python Implementation Map (Unit 05D Stages 1–8)

**Status:** Stages 1–8 implemented from the audited Pine source; deterministic source-derived tests pass; no TradingView parity claim is made.
**Current release:** Unit 05D v0.25.0; focused Stage 1–8 component tests: 110; full suite: 488.  
**Verified stage-1 base release:** Unit 05D v0.18.0.  
**Stage-1 ZIP SHA-256:** `928d9f679e01c1813e88479e985753d2787a518608b3f52adf502fc5ef4b74de`.  
**Original Pine SHA-256:** `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.  
**Instrumented Pine SHA-256:** `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.

## 1. Architecture decision

1. The original Pine v6 source is the authoritative definition of the baseline SMC signal engine.
2. Python must reproduce the Pine calculations, ordering, state transitions, timeframe contexts and signal semantics. It must not substitute generic SMC formulas or silently normalize edge cases.
3. DIVATrading's later dynamic trade-management layer is separate. Actual Binance fill price, exchange-side position state, dynamic entry, dynamic SL/TP and position management must not be fed back into the Pine-baseline parity engine.
4. Pine's `close` entry and signal-based `consumeOBOnSignal` are indicator proxies. They are not actual Binance fills.
5. Source-derived unit tests can be written before a TradingView capture is available, but they do not independently prove Pine runtime parity. External reference cases must remain explicitly marked unavailable until captured and checked.

## 2. Unit 05D implementation boundaries

### Stage 1 — reset, candle and pivot primitives

- Per-timeframe state reset boundary.
- Local source-bar index.
- True range and custom ATR(200).
- Parsed high/low candle values.
- Swing and internal pivot-leg state transitions.
- Deterministic per-bar trace records for these outputs.

### Stage 2 — crossed-state and structure events

- Exact `confluenceFilter` candle test using the Pine/EA expression.
- Internal bullish break before internal bearish break, preserving state mutation order.
- Internal pivot crossed flags, internal trend transition, and BOS/CHoCH classification.
- Per-event extreme scanning from the relevant internal pivot through the current bar, preserving strict comparison and oldest-tie behavior.
- Swing high break before swing low break, swing pivot crossed flags and swing trend updates.
- Per-bar event flags and event-extreme source/local timestamps in the immutable trace.
- Existing `trTop`/`trBot` tracking remains source-identical: update established running extremes before new pivot detection; a new swing pivot then resets its corresponding boundary.

The following work remains outside Stages 1–2 and is implemented only in its own later bounded stage:

- OB creation, mitigation, freshness, or selection.
- FVG.
- Trigger selection, signal scoring, signal emission.
- Entry/SL/TP calculation.
- MTF output arbitration.
- CVD/order-flow filtering, dynamic trade management, Telegram, dashboard, risk sizing, or Binance order execution.

These exclusions preserve the existing staged boundary in `docs/NEXT_TASK.md`.

## 3. Pine-to-Python source map

The line references below refer to the packaged combined instrumented script. The instrumentation is additive after the strategy logic; its removal restores the original Pine source.

| Concern | Pine source | Required Python behavior |
|---|---:|---|
| Independent timeframe state | 219–265, 733–735 | Instantiate a distinct engine state for M1, M5 and M15; never share pivots or ATR state between timeframes. |
| Reset point | 266–310 | `start_index = max(0, last_bar_index - warmupBars + 1)` evaluated in each source-timeframe context. Reset exactly when source `bar_index == start_index`. |
| Local index | 221, 266–267, 311, 355–356 | Initialize/reset to `-1`; increment once on every in-window source candle, so the first in-window candle has `local_index == 0`. |
| Built-in indicator pre-roll | 344–350 | Pine `ta.atr(14)`, `ta.rsi(14)`, `ta.sma(volume,20)`, `ta.lowest/highest`, and `ta.dmi(14,14)` are series evaluated outside the SMC warmup `if`. They are not reset at `start_index`; do not truncate history to exactly `warmupBars` when implementing later dependent logic. |
| Custom ATR(200) | 358–366 | First local bar TR is `high-low`; subsequent TR is `max(high-low, abs(high-prev_close), abs(low-prev_close))`. For `local_index < 200`, maintain cumulative TR mean. Thereafter use `(previous_atr200 * 199 + tr) / 200`. |
| Parsed candle extremes | 368–370 | After updating ATR(200), set `high_vol = (high-low) >= 2 * atr200`. If true, `parsed_high=low` and `parsed_low=high`; otherwise preserve high/low. Do not “correct” the apparent inversion. |
| Swing pivot leg | 377–411 | Delayed candidate offset is `swingLen`; compare against the more recent `swingLen` bars. Any `high[j] >= high[swingLen]` rejects high candidate; any `low[j] <= low[swingLen]` rejects low candidate. High candidate branch is tested before low candidate. Change of leg records pivot at `local_index-swingLen`. |
| Internal pivot leg | 412–440 | Same semantics using `internalLen`, independently of swing state. High detection precedes low detection. A leg transition records the relevant pivot and resets its crossed flag. |
| Confluence candle gate | 442–448 | Default both bar flags to true. When enabled, `a=high-max(close,open)`, `b=min(close,open-low)`, then bullish iff `a>b`, bearish iff `a<b`. Preserve the unusual second expression and strict comparisons. |
| Internal bullish structure break | 450–469 | Check `extraBull`, valid/not-crossed internal high, `localIndex>=1`, `close>inHCur`, and `close[1]<=inHCur`. Set crossed and `inTrend=1`; classify CHoCH only when prior `inTrend==-1`, otherwise BOS. Scan the lowest raw low from pivot index through current bar; strict `<` keeps the oldest equal low. |
| Internal bearish structure break | 487–504 | Evaluated after the bullish branch. Check `extraBear`, valid/not-crossed internal low, `close<inLCur`, and `close[1]>=inLCur`. Set crossed and `inTrend=-1`; classify CHoCH only when the trend at this point is `1`, otherwise BOS. Scan the highest raw high through current bar; strict `>` keeps the oldest equal high. |
| Swing bullish/bearish breaks | 522–528 | After both internal checks, test swing high first, then swing low. Set the corresponding crossed flag and update `swTrend`; these swing breaks do not emit the internal `evBull*`/`evBear*` flags. |
| One-source-bar output shift | 720–721 | Values returned from `f_smc` are shifted by one source candle. Preserve source event time separately from evaluation/visibility time in later stages. This shift is not an extra shift to apply inside the raw state update itself. |
| Chart MTF request behavior | 727–735 | M1 always uses `lookahead_on`; M5/M15 lookahead depends on chart timeframe seconds. Record chart timeframe in reference metadata; M1 is the documented recommended chart timeframe. |

## 4. State and boundary details

At reset, the Pine source resets:

- `localIndex=-1`, `atr200=0`, `trSum=0`, parsed extremes to `na`.
- Swing/internal pivot current and previous values to `0`; crossed/valid flags to `false`; pivot indices to `-1`.
- Swing/internal trends and leg states to `0`.
- Range extrema to `0` and their validity flags to `false`.
- Stage-2 internal and swing trends remain independent; each break consumes its current pivot once by setting its crossed flag. A later pivot update resets only that pivot's crossed flag.
- Active OB arrays to empty (later engine stages only).

Important implementation constraints:

- Reset is per M1/M5/M15 source context and depends on each context's own `last_bar_index`.
- `warmupBars` is a count of source-timeframe bars, not one shared wall-clock duration.
- `localIndex` is not the exchange timestamp and must not replace the candle's UTC open time.
- Use exact decimal inputs for OHLC and deterministic numeric semantics. Do not round raw candle values to tick size during ingestion.
- Keep the previous close available for TR after the first local bar. At the reset boundary, the first local-bar TR deliberately excludes the pre-reset close.

## 5. Pivot edge cases that tests must pin down

1. Comparisons are strict in effect: equality disqualifies a candidate (`>=` for highs and `<=` for lows).
2. The candidate pivot is `high[len]` / `low[len]`, not the current candle.
3. Only the more-recent `len` bars (`j=0..len-1`) are tested; do not add older bars or symmetric right-side checks.
4. High-leg detection takes precedence over low-leg detection because it is an `if` followed by `else if`.
5. The leg variable is updated even when no transition occurs; pivot state is updated only when `change != 0`.
6. A pivot index is `local_index-len` in the reset-local coordinate system. The corresponding source candle timestamp must be carried separately.
7. Swing and internal legs are separate state machines and can transition on the same source candle.

## 6. Required deterministic tests for the first slice

- Reset occurs exactly at `last_bar_index-warmupBars+1`, including a zero-clamped start.
- No pre-reset SMC local state leaks into the first in-window candle.
- First local candle TR equals `high-low`; second and subsequent TR use prior close.
- ATR initialization at local indices 0, 1, 199, 200 and 201 matches the Pine recurrence exactly.
- The `>= 2*ATR200` parsed-candle threshold is tested below, at and above the boundary.
- Parsed high/low values are verified in both normal and high-volatility branches, including the intentional swap.
- Swing and internal pivot delayed offsets are tested independently.
- Equal highs/lows, multiple qualifying candidates, both-leg candidate bars, and no-transition cases pin exact branch priority.
- Repeated identical input series produce byte-stable normalized trace output.
- M1/M5/M15 states remain isolated when their history lengths and reset points differ.

## 7. Reference evidence without TradingView CSV export

TradingView CSV export is not a prerequisite for translating the formulas. The intake workflow must not require the user to upgrade a TradingView plan.

Use two evidence classes and never conflate them:

- **Source-derived tests:** deterministic expected values derived from the audited Pine expressions and hand-constructed candle sequences. These test the implementation mechanics but are not an independent TradingView parity fixture.
- **External TradingView spot checks:** selected exact bars inspected with the instrumented Pine Data Window/visible output. Record ticker, chart timeframe, candle open timestamp, all relevant input values, the exact output fields observed, capture timestamp, and screenshot evidence. Treat these only as positive sampled cases; do not infer complete signal coverage or claim that no other signals occurred.

Historical OHLCV for replay can be sourced from Binance USDⓈ-M Futures history. The market identity must match the exact TradingView Binance perpetual ticker; never substitute spot or another exchange. Reuse the existing Binance Kline history/client path instead of creating a duplicate downloader unless source inspection proves a missing capability.

A full machine-readable TradingView fixture remains optional additional evidence. If a user environment supports a legitimate chart-data export, the existing v2 validator can still be used. Synthetic validator fixtures must never be labeled as TradingView output.

## 8. Stage-2 event trace semantics

- `internal_trend` and `swing_trend` are separate Pine state variables. Internal breaks alone produce the four `structure_events` CHoCH/BOS flags; swing breaks update `swing_trend` and pivot crossed state only.
- Internal event order is bullish then bearish. The bearish classification observes any trend update made by the bullish branch earlier on the same candle, matching sequential Pine assignments.
- Swing break order is bullish high break then bearish low break, after both internal checks.
- `extraBull` and `extraBear` retain the Pine guard that excludes an internal level numerically equal to the corresponding valid swing level.
- Event extreme scans start at `local_index - span` (the corresponding internal pivot) and continue through the current source bar. Strict `<`/`>` updates mean an equal later extreme does not replace the earliest source bar.
- The trace stores both event-extreme local index and UTC source candle-open timestamp. No OB is created from these values in Stage 2.
- `confluence_filter` is an effective Pine input in the stage configuration and replay metadata. Its default is `false`, matching the Pine default.
- The full in-window history list is bounded by the Pine `warmupBars` input (maximum 2,500) so event scans can reach older pivots without retaining unbounded market history.

### Stage-2 deterministic tests

- Internal bullish BOS from neutral trend, then bearish CHoCH after the bullish transition.
- Event extreme low/high scan boundaries, earliest-source tie retention, local index and source timestamp.
- Crossed flag blocks a second break of the same pivot; a newly confirmed pivot resets only that pivot's crossed flag.
- Swing high and low crosses update swing trend and tracked range extrema without emitting internal BOS/CHoCH flags.
- `confluenceFilter` source formula and strict equality case.
- Byte-stable event JSONL output.

## 9. Parity reporting policy

- Mark source-derived unit tests as implementation tests, not parity tests.
- Mark manual TradingView spot checks as sampled parity observations, with their narrow timestamps/fields.
- Do not claim full parity until sufficient independent reference observations cover all relevant state transitions and final signal behavior.
- Never interpret an absent signal in a partial visual/sample interval as a confirmed negative.
- Report all mismatches explicitly; do not widen tolerances merely to obtain a pass.

## 10. Later separation: baseline SMC vs dynamic trade management

After the full baseline SMC engine is implemented and validated, later units can add a separate decision/management layer:

- Dynamic entry evaluation using current Binance market state.
- Structural/ATR/liquidity-aware SL.
- Initial TP at opposing OB/liquidity, with later TP adaptation based on absorption, Delta/CVD, order flow and reversal evidence.
- Actual exchange order/fill state, BEP, partial exits, trailing and execution controls.

Those additions must not alter the baseline Pine signal output or its parity report. Record them as downstream decisions with separate provenance and tests.

## 11. Known external constraints

- The Pine header carries a CC BY-NC-SA 4.0 notice (NonCommercial + ShareAlike). Confirm permission before commercial use or redistribution of derivative code.
- Existing 05C package was validated in Python 3.13.5/Linux; target Windows 10 / Python 3.12.9 is not yet tested.
- The 05C release had 378 passing tests, but no actual TradingView fixture; live Binance and TradingView compiler checks remain unperformed.

## 12. Unit 05D Stage-3 OB/FVG lifecycle mapping

| Pine source block | Python implementation | Required semantics |
|---|---|---|
| `f_pushOB` / `f_removeOB` (78–110) | `_PineOrderBlockState`, `_push_order_block`, `_mitigate_order_blocks` | Parallel fields remain aligned through a typed record; hard capacity 100; FIFO shift oldest; reverse-index mitigation removal. |
| Bullish internal event OB scan (470–485) | `_create_order_block(..., bias=1)` | `span=localIndex-inHIdx`; parsedLow minimum starts at oldest pivot offset; strict `<` retains oldest equal source; normalized `max/min`; source and break times captured. |
| Bearish internal event OB scan (505–520) | `_create_order_block(..., bias=-1)` | ParsedHigh maximum; strict `>`; same normalization and metadata contract. |
| Bullish FVG (481–484) | `_has_directional_fvg(..., bias=1)` | `low[off-1]-high[off+1]`; require positive gap and `gap >= fvgMinAtr*atr200`. |
| Bearish FVG (516–519) | `_has_directional_fvg(..., bias=-1)` | `low[off+1]-high[off-1]`; same positive/inclusive threshold conditions. |
| `DeleteMitigated()` (530–540) | `_mitigate_order_blocks` | After structure branches and OB insertion; newest index to oldest; strict comparisons; high/low unless `mitigateClose` selects close. |

- Stage 3 effective inputs: `fvg_min_atr=0.10` and `mitigate_close=False` by default. No UI-step rounding or tick-size rounding is introduced into the calculation.
- The per-bar immutable `ob_lifecycle` records `created`, `mitigated`, and `evicted`; `active_order_blocks` is the post-mitigation active array snapshot in oldest-to-newest order.
- Creation snapshots are captured before mitigation, so same-bar creation and same-bar removal remain observable as both lifecycle events while the final active tuple excludes the removed OB.
- Stage 3 source-derived tests are not independent TradingView parity observations. No accepted TradingView cases exist yet.
- Candidate scan, trigger selection, sweep, scoring, signal output, MTF shift/arbitration and Dynamic Trade Management remain excluded.



## 13. Unit 05D Stage-4 built-in TA and volatility mapping

| Pine source | Python implementation | Required semantics |
|---|---|---|
| `ta.atr(14)` at line 345 | `PineBuiltinTAEngine.atr_rma` | `ta.tr(true)` fallback `high-low` on the first loaded bar; RMA(14) with SMA seed across the first 14 valid TR values. |
| `ta.rsi(close,14)` at line 346 | `rsi_gain_rma`, `rsi_loss_rma` | Documented Pine long-form equivalent; first-bar `change` is `na`, v6 comparisons are false, so ternaries contribute zero; 14-value RMA seeds; zero/zero remains unavailable. |
| `ta.sma(volume,20)` at line 347 | `volumes`, `volume_sum` | Current-inclusive 20-bar rolling mean; unavailable for the first 19 source bars. |
| `ta.dmi(14,14)` at line 350 | DMI TR/+DM/-DM/ADX RMA streams | First `ta.tr` and DM samples unavailable; strict +DM/-DM dominance; DI division, `fixnan` carry-forward, DX and ADX RMA. |
| `atrRatioNow` at line 351 | `_build_indicator_trace()` | Evaluated before current-bar custom ATR(200) update; denominator is the pre-update value; use exact `1.0` fallback when it is not positive. |
| `volatilityExtreme` / `volatilityChoppy` at lines 352–353 | `PineSmcIndicatorTrace` | `>= extreme`; choppy requires strict `> low`, `< high`, and `ADX < choppyAdxMax`; both booleans false when the required numeric input is unavailable. |

All four built-ins update on every loaded prefix candle, not only on SMC in-window bars. `PineSmcIndicatorTrace` is immutable and uses `None`/JSON `null` for unavailable numeric values. `PineSmcStructureReplayResult` records the effective regime inputs. The source-derived tests exercise initialization, gaps, rising/falling/flat markets, DMI directional ties, prefix sensitivity, ratio ordering, thresholds and JSON serialization; these tests do not establish independent TradingView parity.


## 14. Unit 05D Stage-5 ordered OB candidate eligibility mapping

| Pine source | Python implementation | Required semantics |
|---|---|---|
| `f_smc(maxAge, ...)` request calls at lines 733–735 | `PineSmcStructureEngine._max_age_for_timeframe()` | M1 and M5 both receive `maxAgeM5`; M15 receives `maxAgeM15`. |
| `freshOnly` / `oUsed` (555–556) | `_evaluate_ob_eligibility()` | Reject used OB only when enabled; never mutate `used` during scan. |
| `localIndex` / `oBreakIdx` / `maxAge` (557) | age gate | Reject at/before break index and when age is greater than maxAge; maximum age is inclusive. |
| `useTrendFilter` / `swTrend` / `oBias` (559) | swing-trend gate | Bullish requires trend +1; bearish requires -1. |
| `usePDFilter`, `trTopOK`, `trBotOK`, equilibrium and OB midpoint (561–565) | premium/discount gate | Run only with both valid range endpoints and top > bottom; bullish midpoint strictly above equilibrium rejects; bearish strictly below rejects; equality passes. |
| `requireFVG` / stored OB flag (566–567) | FVG gate | Read the boolean stored at OB creation; do not run a new FVG search. |
| `volatilityExtreme` / `volatilityChoppy` (568–570) | Stage-4 indicator trace gate | Either precomputed true flag rejects; do not recompute thresholds. |
| active OB arrays / reverse scan (545–548) | `_evaluate_ob_eligibility()` | Evaluate array indices `len-1` down to `0`; preserve each original index and immutable OB snapshot. No score sort. |

- `PineSmcObCandidateEvaluation` stores active-array index, frozen OB snapshot, eligibility and ordered rejection reason codes.
- `PineSmcObEligibilityTrace` stores the timeframe's selected `max_age`, every evaluated OB in newest-to-oldest order, and the eligible subset in that same order.
- `PineSmcBarTrace.ob_eligibility` exposes the per-bar result; replay metadata records the six Stage-5 effective inputs. JSONL remains deterministic.
- Stage 5 tests cover all eligibility gates, exact boundaries, gate order, max-age routing, array order, immutability and break-bar/later-bar integration. No independent TradingView parity observation is claimed.
- Stage 6 should consume the eligible candidate view to apply rejection/structure trigger priority and sweep, preserving order and without scoring or levels.


## Stage 6 — trigger and sweep qualification

Source block: `FindSignal()` lines 572–610.

- Effective config: `trigger_mode` (`Rejection`, `Structure`, `Either`; default `Either`), `struct_allow_bos=true`, `min_wick_pct=20.0`, `require_sweep=false`, `sweep_lookback=20`, `sweep_window=5`.
- Rejection: exact bullish/bearish OB touch, candle direction, close-vs-midpoint, positive range and direction-specific wick percentage.
- Structure: trigger mode permits structure, event extreme index is valid and strictly after OB break index; CHoCH qualifies and BOS requires `struct_allow_bos`; extreme-to-OB-boundary comparison is inclusive.
- Trigger priority: rejection code 1 before structure code 2; no trigger code 0.
- Sweep: when enabled, mirror the Pine `sweepWindow` and `sweepLookback` loops. For each window offset, require `localIndex-offset > sweepLookback`; bullish uses strict new-low plus close-back-above, bearish strict new-high plus close-back-below. Historical offsets use the bounded source-timeframe candle history. Disabled sweep bypasses the check.
- Stage 6 consumes only Stage-5 eligible candidates, retains newest-to-oldest order, evaluates until the first non-zero trigger with passing sweep, and stores immutable candidate/OB snapshots. It does not mutate OB `used`.
- Public immutable trace types: `PineSmcObTriggerEvaluation` and `PineSmcTriggerSweepTrace`; each bar trace includes `trigger_sweep`. Replay metadata records all effective Stage-6 config.
- The chosen candidate is not a final signal. No scoring, Entry/SL/TP, signal output, source-bar shift or MTF arbitration is implemented.

Stage-6 test file: `tests/test_pine_smc_trigger_sweep.py` (16 tests). Stage 1–6 focused total: 73 tests; full regression suite: 451 tests. These are source-derived implementation checks, not independent TradingView runtime parity evidence.

## 16. Unit 05D Stage-7 OB scoring and ideal-entry mapping

Source blocks: `f_scoreOB()` lines 155–217, prior sweep series lines 348–349, selected candidate scoring lines 617–624, active-array score serialization lines 693–699.

| Pine source | Python implementation | Required semantics |
|---|---|---|
| `syminfo.mintick` | `PineSmcStructureConfig.tick_size` | Exact positive symbol tick from matching Binance USD-M `PRICE_FILTER.tickSize`; scoring is explicitly unavailable when missing. No guess/default. |
| `entryDepthNear`, `entryDepthDeep` | config fields | Defaults 0.50/0.80; Pine ranges; when deep <= near, replace deep with `min(0.95, near+0.10)`. |
| `zoneRange`, `entryLow`, `entryHigh` | `_score_order_block()` | `max(oTop-oBottom,tickSize)`; bullish band measured down from top; bearish band measured up from bottom. |
| `volatilityScore`, `dispAtr`, `displacementScore` | score component fields | ATR(14)/ATR(200) ratio fallback 1; break close displacement in slow ATR units; exact clamps. |
| source candle body/wick and expected color | `source_candle_score` | Original source candle OHLC (not parsed candle); body 70% + rejection wick 30%, expected color multiplier 1.0/0.65. |
| RSI, trend, FVG and volume | `rsi_score`, `trend_score`, `fvg_score`, `volume_score` | RSI target 58/42 and `na` fallback 50; trend blend 55/45; FVG 100/40; volume 50 fallback and exact relative-volume clamp. |
| freshness | `freshness_score` | `clamp(100 - 70*age/maxAge,20,100)`. |
| `priorLowestSweep`, `priorHighestSweep` | full-prefix prior sweep values | `ta.lowest(low[1],N)` / `ta.highest(high[1],N)` over preceding source candles, excluding current bar and including pre-SMC-reset prefix; distinct from Stage-6 sweep gate. |
| directional current-candle sweep | `sweep_score`, `swept_current_candle` | Strict new low/high and strict close-back through prior level; 100 if swept else 45. |
| current candle / band proximity | `current_candle_score`, `proximity_score` | Exact direction/close-position formula, distance-to-band sign, ATR(14) proximity and no-ATR fallback. |
| quality/timing/setup | `ob_quality_score`, `timing_score`, `setup_score` | Quality weights `(16,12,10,12,12,8,6,6,8)` / 90; timing 45/55; setup 80/20, final clamp 0–100. |
| active OB diagnostic list | `PineSmcObScoringTrace.active_order_block_scores` | Score all active OBs oldest-to-newest, preserving array index; chosen score is linked to Stage-6 chosen index. Never sort or reselect by score. |

Public immutable types: `PineSmcObScoreTrace` and `PineSmcObScoringTrace`. `PineSmcBarTrace.ob_scoring` is part of deterministic JSONL. When the exact tick size is absent, `available=false`, an explicit reason is provided, and no score rows are fabricated; prior stages remain usable.

Stage-7 tests: `tests/test_pine_smc_ob_scoring.py` (16 tests). Focused Stage 1–7 total: 89; full regression: 467. These are source-derived implementation checks, not independent TradingView parity observations.

## Stage 7 complete — next boundary

Stage 8 implements Pine proxy entry/SL/TP geometry and local signal/level construction after Stage-6 selection and Stage-7 scoring. Keep actual exchange fills separate. Stage 9 then implements one-source-bar confirmed-output shift and chart-level MTF arbitration.


## Stage 8 — Pine baseline level geometry

**Source:** original Pine `f_smc()` level block, approximately lines 624–684; inputs lines 56–66 and `highVolSLMult` in the volatility inputs.

| Pine expression / behavior | Python implementation |
|---|---|
| `entry=close` | `PineSmcSignalProxy.entry_proxy` from source candle close; explicitly not a fill |
| `spreadEstimateTicks * syminfo.mintick` | exact tick-size-based `spread_price` |
| `max(spreadPrice*slSpreadMult, atrFastNow*slBufferAtr) * regimeBufferMult` | Stage-8 `stop_buffer`; regime multiplier activates at `atrRatioNow >= highVolRatio` when regime filter is enabled |
| Directional SL from `oBottom` / `oTop` | selected OB bottom for bullish, top for bearish, plus/minus buffer |
| `slDist > 0` then minimum stop adjustment | reject non-positive distance first; expand to `minStopTicks*tickSize` before `levelsOK` |
| `levelsOK` max-SL / max-spread constraints | strict `>` gates with Pine evaluation order |
| `Fixed RR` | `entry +/- slDist*rr`; no separate `minRR` test |
| `Structure` | directional `trTop`/`trBot`, positive reward and `minRR` gate |
| `Hybrid OB/Liquidity` | oldest-to-newest full active-array scan including used OBs; nearest opposing boundary, structural fallback, then guarded fixed-RR fallback |
| `consumeOBOnSignal` | selected OB `used` mutation only after all level gates pass; indicator proxy only |

Stage 8 evaluates only the first Stage-6 selected OB. Level failure does not retry later candidates. Stage-7 chosen score must match Stage-6 index and OB identity. Exact tick size and ATR(14) availability are required; missing dependencies fail closed. The local `PineSmcSignalProxy` remains unshifted until Stage 9.

Stage 8 focused tests: 21; focused Stage 1–8 component tests: 110; full suite: 488. Runtime parity remains unmeasured because no verified TradingView reference observations have been accepted.

## Next map boundary — Stage 9

One-source-bar output shift, source event/evaluation timestamps, chart-timeframe context, `request.security()` lookahead and `gaps_off`, MTF nesting/arbitration and immutable suppression trace. No execution fill or Dynamic Trade Management is part of the Pine baseline.
