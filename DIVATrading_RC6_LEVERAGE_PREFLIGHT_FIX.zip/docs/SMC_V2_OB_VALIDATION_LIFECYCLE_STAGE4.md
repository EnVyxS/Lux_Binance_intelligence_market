# SMC V2 — OB Validation & Lifecycle (Unit 05E Stage 4)

## Scope

Stage 4 consumes immutable Stage-3 `OrderBlockCandidate` records and validated closed Binance USDⓈ-M Klines. It manages only the lifecycle of M1/M5 candidates. M15 remains advisory-only. This stage does not calculate retests, entries, scores, FVG, sweeps, Entry/SL/TP, risk, fills, positions or exchange orders.

## Public API

Module: `divatrading.strategy.scalping_order_block_lifecycle`

Public types:

- `ScalpingOrderBlockLifecycleConfig`
- `ScalpingOrderBlockLifecycleEngine`
- `ScalpingOrderBlockLifecycleResult`
- `OrderBlockLifecycleTimeframeResult`
- `OrderBlockLifecycleSnapshot`
- `OrderBlockLifecycleTrace`
- `ScalpingOrderBlockLifecycleError` and input/continuity/capacity subclasses

The engine accepts `ScalpingOrderBlockFormationResult` and the exact same-capture `ScalpingMarketDataView` through `process(formation, view)`. It requires exact symbol/timestamp identity, the candidate's source and break candles in retained history, exact OHLC provenance, and exact Binance tick-grid values. Candidate source and break candles are cross-checked against the corresponding Kline snapshot.

## Lifecycle states

| State | Meaning | Terminal |
|---|---|---|
| `CANDIDATE` | Stage-3 candidate recorded at its confirmed break close; no post-break candle processed yet | No |
| `ACTIVE_FRESH` | At least one subsequent closed source-timeframe candle processed without touching the zone | No |
| `TOUCHED` | A subsequent closed candle range intersects the OB zone, but has not penetrated the entry-side boundary | No |
| `MITIGATED` | Price has penetrated into the zone by a positive depth; partial/full depth is retained separately | No |
| `INVALIDATED` | Configured distal-boundary invalidation rule is met | Yes |
| `EXPIRED` | Source-timeframe age exceeds the configured maximum | Yes |

A touch is not mitigation when penetration depth is exactly zero. Any positive penetration changes the state to `MITIGATED`; `maximum_mitigation_depth_ratio` records the deepest observed penetration, clamped to `[0, 1]`. Thus partial mitigation and full-depth traversal are distinguishable without introducing an uncalibrated percentage threshold.

## Causal candle convention

The Stage-3 break candle is excluded from touch/mitigation/invalidation evaluation. The candidate becomes observable only after that candle closes, and OHLC cannot establish the intrabar ordering between the structure break and a possible return into its source OB. Lifecycle evaluation begins with the first subsequent closed candle in the candidate's own timeframe.

For a subsequent candle, the engine records zone touch and depth evidence first, then evaluates invalidation. If the same candle both intersects the zone and meets the invalidation rule, touch/depth traces precede the terminal invalidation trace. A candle whose entire range is beyond the distal edge can invalidate an OB, but it does not create a synthetic touch or mitigation because its OHLC range never intersects the zone.

## Touch and mitigation formulas

Zone overlap is inclusive:

`candle.low <= zone_top AND candle.high >= zone_bottom`.

Let `height = zone_top - zone_bottom`.

- Bullish OB entry side is `zone_top`; penetration price is the candle low; depth is `(zone_top - penetration_price) / height`.
- Bearish OB entry side is `zone_bottom`; penetration price is the candle high; depth is `(penetration_price - zone_bottom) / height`.
- Depth is clamped to `[0, 1]` and only calculated for a candle whose range intersects the zone.
- The engine retains the maximum depth and its observed wick price. First-touch time and first positive-penetration time are separate.

## Invalidation policy

Config defaults:

- `invalidation_mode="WICK"`
- `invalidation_boundary="STRICT"`

Modes:

- `WICK`: bullish uses candle low versus `zone_bottom`; bearish uses candle high versus `zone_top`.
- `CLOSE`: both directions use candle close versus the distal boundary (`zone_bottom` bullish, `zone_top` bearish).

Boundary semantics:

- `STRICT`: invalidation only when price moves strictly beyond the distal boundary (`<` bullish / `>` bearish).
- `INCLUSIVE`: equality at the distal boundary also invalidates (`<=` bullish / `>=` bearish).

These are explicit V2 settings. No Pine/EA `mitigateClose` behavior is inherited implicitly. Invalidation price, close-time observation, bar open time and reason are retained.

## Age and expiry

`max_age_bars=300` is a provisional, uncalibrated default, measured in the candidate's own source timeframe. Age 300 remains eligible; the first subsequent bar with age 301 expires the candidate. M1 and M5 therefore age independently. The default must be calibrated with historical Binance replay and is not a performance claim or a copied Pine max-age setting.

## Continuity and provenance safeguards

- M1/M5 lifecycle state is independent; M15 never creates, suppresses or arbitrates OBs.
- Candidate source and break candle must be present in the same-capture closed Kline history and match exact OHLC/time.
- Closed candles must be contiguous and tick-aligned. Unready/incomplete source snapshots do not advance lifecycle state.
- Incremental snapshots require exact next-bar continuity. Previously processed overlapping candles are fingerprinted; revised OHLCV or other Kline payload changes fail closed.
- A new candidate arriving after its break bar has already been processed is rejected as late; the engine will not infer missed traversal.
- Duplicate candidate delivery is idempotent; conflicting reuse of candidate ID fails closed.
- Overlapping candidates remain distinct; no coalescing or M5/M15 nested priority.
- The break candle is deliberately not treated as a post-formation retest.
- M1/M5 preflight is staged on copies and committed atomically; a malformed M5 update cannot partially commit M1.
- Per-symbol, per-timeframe OB state, trace history and candle/candidate fingerprints are bounded. Oldest terminal lifecycle records may be evicted to admit new candidates; if all records are nonterminal at capacity, the engine raises a capacity error instead of silently dropping active zones.

## Trade/fill separation

Lifecycle snapshots explicitly report `filled=false` and `consumed=false`. A zone touch, mitigation, invalidation, expiry, visual box, or setup candidate is not an order fill. Actual fill and consumption belong to a later paper/execution layer.

## Validation

Stage-4 focused tests cover bullish/bearish zones, touch versus positive-depth mitigation, partial/full penetration, WICK/CLOSE and STRICT/INCLUSIVE boundaries, same-candle evidence ordering, source-timeframe expiry, source/break candle provenance, no synthetic traversal across a gap, late candidates, revised candles, unavailable data, duplicate delivery, overlapping candidate retention, M1/M5 independence, M15 advisory-only behavior, atomic preflight, bounded capacity/terminal eviction, reset and deterministic JSONL.

Default expiry and invalidation policy are provisional design choices. Historical Binance replay, live Binance validation, Windows 10/Python 3.12.9 validation and profitability have not been established.
