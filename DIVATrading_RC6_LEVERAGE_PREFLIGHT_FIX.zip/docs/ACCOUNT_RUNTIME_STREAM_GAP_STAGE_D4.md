# Stage D4 — Account Runtime Stream-Gap & Multi-Lot Recovery

## Objective

Extend the D3 protective-trigger recovery into the account-runtime and durable fill-accounting boundary. A reconnect must not rely on the ordinary user-trade backfill timer, and a protective Algo child fill must remain attributable to its original signal lot even when its stream event or local order acknowledgement arrives late.

## Runtime reconnect and forced REST backfill

- `ExecutionAccountRuntime` watches the durable private User Data Stream connection timestamp. A new `connected_at_ms` value calls `AccountReconciliationService.request_trade_backfill()` once for that connection.
- The request is a latched flag, separate from the regular interval throttle. The next account reconciliation therefore runs `/fapi/v1/userTrades` recovery for every symbol in `list_trade_history_symbols()` even when the periodic interval has not elapsed.
- The forced request is cleared only after every tracked symbol's backfill returns successfully. A failure on any symbol leaves the request latched, so the next reconciliation retries it.
- Backfill occurs before the sequential account snapshot/readiness decision. Failed backfill keeps entries halted and persists `TRADE_HISTORY_BACKFILL_FAILED`.
- If and only if the current reconciler itself introduced that exact transient backfill-failure halt, a later successful backfill may move it to an in-progress transient halt and clear it only after a fresh sequential snapshot has no discrepancies. A pre-existing manual kill switch or another safety halt is never cleared by this recovery path.
- A private-stream reconnect alone does not set account readiness. Normal snapshot, position/protection comparison and event-watermark rules still apply.

## Protective Algo child-order ownership bridge

- A triggered conditional Algo has a `clientAlgoId`, while the matching-engine child MARKET order is identified by `actualOrderId`. They are different namespaces.
- D4 links the child exchange order ID to the target signal ID, symbol, position side and protective role only after REST has revalidated the exact child order identity, type, original quantity, side, position side and One-way/Hedge close semantics.
- The link is committed before cancellation of any remaining child quantity. It uses the existing exchange-order ownership table with `effect=CLOSE`, and conflicting ownership fails closed. Repeating the exact link is idempotent.
- The ledger retroactively re-attributes exact matching fills previously stored as `EXTERNAL` or `UNATTRIBUTED`, then rebuilds that signal's position-fill projection. Late `ORDER_TRADE_UPDATE` and `/fapi/v1/userTrades` history can therefore resolve the child by exchange order ID without trusting its generated client ID.
- This mapping is accounting/ownership metadata. It does not replace the D3 rule that final child `executedQty`, aggregate REST position and local group quantity must agree before lifecycle quantity mutation.

## Multi-lot accounting and deterministic integration qualification

The D4 regression includes: 

1. Two independently managed signal lots sharing one `(symbol, positionSide)` group.
2. A STOP trigger on one lot and a matching-engine child partial fill.
3. Child order ID ownership mapping and subsequent REST user-trade backfill, including entry and closing fills.
4. Per-signal entry/close/net quantity, commission-asset totals and realized PnL projections, with aggregate net quantity matching the exchange position.
5. Restart followed by duplicate/late `ALGO_UPDATE`, proving the existing durable action is reused and no duplicate protection POST occurs.
6. Aggregate exchange-flat event, linked protection cleanup, per-lot finalization and risk-reservation release.

A deterministic seeded invariant test exercises quantity conservation and FIFO close allocation across `BOTH`, `LONG` and `SHORT` side semantics. Existing D1–D3 tests continue to cover zero/partial/full triggered-child outcomes, cancel races, paired residual protection, restart replay and TESTNET-only zero-fill recovery gating.

## Safety invariants

- PAPER remains the default; all execution authorization flags remain false by default.
- A stream reconnect forces REST recovery; it does not itself authorize a new entry.
- Backfill failure remains fail-closed and does not silently advance a completion state.
- Only the reconciler-owned transient backfill halt can be cleared, and only after a clean fresh account snapshot.
- Existing manual kill switch, operator halt, and LIVE-disabled policy remain intact.
- Child-order mapping is created only from an exact REST-verified protective trigger; ambiguous/mismatched ownership fails closed.
- No blind order POST, cancel retry or Algo mutation is introduced by D4.
- Position quantity/risk reservation changes remain governed by the existing lifecycle reducer, aggregate exchange checks and verified-flat finalizer.

## Verification boundary

- Source regression: 986 passed on Linux / Python 3.13.5.
- Focused D4 stream-gap, userTrades backfill, accounting and lifecycle tests: 129 passed.
- Tests use local SQLite and fake REST/stream/execution clients.
- No actual Binance Demo/LIVE private request, order placement, cancellation, Algo mutation or real account connection was executed.
- Exact release archive validation on Windows 10 / Python 3.12.9 remains outstanding.
