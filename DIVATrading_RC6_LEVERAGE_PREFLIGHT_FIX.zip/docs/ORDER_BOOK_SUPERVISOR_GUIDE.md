# Unit 04E — Order Book Supervisor Guide

## Purpose

`BinanceOrderBookSupervisor` coordinates the Unit 04D depth feed, public REST snapshots and per-symbol `LocalOrderBook` instances. It is an explicit caller-managed asynchronous service. It does not start itself, modify SMC signals or place orders.

## Lifecycle

1. The supervisor starts the WebSocket feed and begins draining its bounded event queue.
2. Each configured symbol buffers depth events before requesting its REST snapshot.
3. Snapshot calls execute in worker threads so REST latency does not block WebSocket consumption. A shared asynchronous lock serializes calls across symbols and preserves the REST client's request pacing.
4. The buffered sequence is passed to `LocalOrderBook.synchronize()`. Only a successful snapshot bridge and sequence validation mark the symbol `READY`.
5. Once ready, each new event is applied to the local book. A sequence gap, stale event, invalid book or initial-buffer overflow invalidates that symbol and schedules a fresh snapshot.
6. Feed disconnect/reconnect invalidates all configured symbol books. A change in `feed.stats.connection_count` also catches a fast reconnect even if the disconnected interval is missed by polling.
7. If the feed task fails (including queue overflow), all books are invalidated and the supervisor propagates an error. It does not keep serving stale metrics.

## Readiness contract

`supervisor.health(symbol)` returns an immutable `OrderBookSymbolHealth` record with:

- `connection_state`: `CONNECTED` or `DISCONNECTED`;
- `snapshot_state`: `WAITING_FOR_STREAM`, `BUFFERING`, `FETCHING_SNAPSHOT`, `READY`, `RESYNC_REQUIRED` or `ERROR`;
- `sequence_integrity`: local book has a valid synchronized update ID;
- `event_fresh`: latest event passes the configured age/future-time gate;
- `queue_healthy`: feed queue remains below its configured high-water mark;
- `ready`: all five gates pass simultaneously;
- current update ID, event age, queue depth/capacity, buffer count, invalid reason and last error.

Consumers must use `supervisor.metrics(symbol)`, not access a `LocalOrderBook` directly. `metrics()` raises `OrderBookNotReady` whenever any readiness gate fails. `supervisor.is_ready` is true only when every selected symbol is ready.

## Resource bounds

- The symbol count is bounded by the configured feed (default 8, hard cap 32).
- Initial per-symbol buffer defaults to 2,048 events; hard cap 10,000.
- Snapshot retry attempts default to 5 and are capped at 20.
- Retry delay defaults to 250 ms and cannot be configured above 10 seconds.
- A shared snapshot lock serializes REST calls; each blocking fetch runs in `asyncio.to_thread`.
- Queue readiness becomes false at 75% queue occupancy by default; configurable range is 50–95%.
- Supervisor state is in-memory and per-process. A restart always obtains a new snapshot and re-establishes a fresh WebSocket bridge.

## Minimal usage

```python
import asyncio

from divatrading.market_data import (
    BinanceDepthSnapshotClient,
    BinanceDepthWebSocketFeed,
    BinanceOrderBookSupervisor,
    OrderBookNotReady,
)

async def main():
    symbols = ["BTCUSDT", "ETHUSDT"]
    feed = BinanceDepthWebSocketFeed(symbols=symbols, update_speed="100ms")
    snapshots = BinanceDepthSnapshotClient(limit=100)
    supervisor = BinanceOrderBookSupervisor(
        feed=feed,
        snapshot_client=snapshots,
        max_buffered_events=2048,
        max_levels=100,
        depth_levels=20,
    )
    stop = asyncio.Event()
    runner = asyncio.create_task(supervisor.run(stop))
    try:
        while True:
            await asyncio.sleep(0.25)
            for symbol in symbols:
                health = supervisor.health(symbol)
                if not health.ready:
                    continue
                try:
                    metrics = supervisor.metrics(symbol)
                except OrderBookNotReady:
                    continue
                print(symbol, metrics.best_bid, metrics.best_ask, metrics.imbalance)
    finally:
        stop.set()
        await runner
        close_rest_client = getattr(snapshots, "close", None)
        if callable(close_rest_client):
            close_rest_client()

asyncio.run(main())
```

The example only reads displayed public depth. The service should be started with a deliberate, small selected-symbol list on the target 8 GB Windows PC. Callers must stop the supervisor cleanly and close the REST client they created.

## Persistence decision

No depth snapshot or diff rows are written to SQLite in Unit 04E. There is no current consumer requiring historical book replay, and storing every diff would create unbounded write volume without a retention and compaction design. A process restart deliberately rebuilds readiness from a new live stream and fresh REST snapshot; it never trusts a persisted stale book.

SQLite remains schema v5. No migration is added.

## Safety boundary and limitations

- Public Binance USDⓈ-M endpoints only; no API key, private endpoint, order placement or cancellation.
- No absorption/exhaustion inference, spoofing detection, SMC changes, scoring, Telegram or dashboard integration.
- The supervisor is a Python service, not yet wired into the default CLI/runtime startup or strategy executor.
- Test fixtures and injected fake feeds are used; no live Binance connection is part of this release.
- Windows 10 / Python 3.12.9 target validation remains pending.
