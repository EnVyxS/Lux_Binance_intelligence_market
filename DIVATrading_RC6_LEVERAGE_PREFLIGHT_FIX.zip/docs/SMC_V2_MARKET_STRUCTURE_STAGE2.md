# SMC V2 Market Structure Engine — Unit 05E Stage 2 (v0.27.0)

## Scope

Stage 2 adds only deterministic per-symbol/per-timeframe market structure. It consumes the immutable `ScalpingMarketDataView` built by Stage 1 and uses only validated, closed Binance USD-M Klines. It does not create OBs or setups and does not place or simulate orders.

## Public API

`divatrading.strategy.scalping_market_structure` exports:

- `ScalpingMarketStructureConfig`
- `StructureTimeframeSettings`
- `ScalpingMarketStructureEngine`
- `ScalpingMarketStructureResult`
- `StructureTimeframeResult`
- `StructureBarTrace`
- `StructurePivot`, `StructurePivotState`
- `StructureEvent`, `StructureLayerSnapshot`
- `ScalpingMarketStructureError`, `ScalpingMarketStructureInputError`, `ScalpingMarketStructureContinuityError`, `ScalpingMarketStructureCapacityError`

The same public names are re-exported from `divatrading.strategy`.

## Timeframe/state partitioning

- State is independent for each exact `(symbol, timeframe)` key.
- M1 and M5 are independent setup-source structures. One timeframe's events or direction do not suppress or mutate the other.
- M15 is processed only as advisory context when enabled and when its own source is ready. It is not a prerequisite for M1/M5 processing.
- The default engine retains state for at most 16 symbols. A configurable cap can be lowered/raised up to 32. Per-layer pivot count, event count, bar-trace count and pivot lookback window are bounded.

## Pivot confirmation and no-look-ahead rule

For each layer, a candidate pivot is evaluated only after its configured right-side bars have closed. The candidate is the candle `right_bars` behind the current confirmation candle.

- Swing defaults: 3 left bars / 3 right bars.
- Internal defaults: 1 left bar / 1 right bar.
- These are initial deterministic scaffolding values, not calibrated trading thresholds. `StructureTimeframeSettings` allows separate swing/internal pivot lengths for M1, M5 and M15.
- A HIGH pivot must be strictly higher than every other high in the left/right window. A LOW pivot must be strictly lower than every other low. Equal highs/lows are not pivots under this strict baseline.
- An outside candle may independently qualify as both a HIGH and a LOW pivot; both are emitted with separate deterministic IDs.
- `source_open_time_ms` identifies the pivot candle. `confirmation_close_time_ms` identifies the close that made the pivot knowable. A pivot is ineligible for a structure break on its own confirmation candle; later candles may break it.

The warm-up requirement per timeframe is the maximum of the swing and internal `left + right + 1` windows. Until enough closed bars are processed, the result is `WARMING_UP` and does not claim structural readiness.

## BOS / CHoCH semantics

Break checks run independently for SWING and INTERNAL layers after confirmed pivots are updated on each closed candle.

- Bullish break: previous close `<=` the confirmed HIGH pivot and current close `>` that pivot.
- Bearish break: previous close `>=` the confirmed LOW pivot and current close `<` that pivot.
- Wick-only penetration does not emit BOS/CHoCH. It remains available to a later independent liquidity-sweep stage.
- If more than one same-direction pivot level is crossed on a candle, a single event is emitted for that layer using the most recently confirmed crossed pivot; all crossed levels are marked consumed so they cannot trigger again.
- Initial break from NEUTRAL is classified BOS. A break in the current bias direction is BOS. A break opposite to the previous bias is CHoCH. Direction state is maintained separately per layer.
- Event IDs are deterministic from symbol, timeframe, layer, event class/direction, source pivot identity and break candle.

Each `StructureEvent` carries the broken level, direction, layer, pivot ID and source time, pivot confirmation time, break candle open time, confirming candle close time, previous close, confirmation close, and the protected landmark selected for the new direction.

## Protected landmarks

- After a bullish structural break, the layer records the latest confirmed LOW pivot available before the break as its protected low.
- After a bearish structural break, the layer records the latest confirmed HIGH pivot as its protected high.
- Swing and internal protected landmarks are separate. They are structural references for downstream invalidation/OB logic, not an order-management stop.

## Incremental processing and reset policy

`ScalpingMarketStructureEngine.process(view)` can be called repeatedly with overlapping rolling snapshots.

- The last processed closed candle must still appear in the next snapshot with an identical immutable OHLCV fingerprint.
- Only candles after that overlap are processed. Repeating an identical snapshot is idempotent and does not duplicate bars or events.
- A missing overlap or revised previously closed candle raises `ScalpingMarketStructureContinuityError`; call `reset(symbol=..., timeframe=...)` and replay a fresh contiguous window rather than guessing the missing state.
- `reset()` clears all partitions; `reset(symbol=...)` clears one symbol; `reset(symbol=..., timeframe=...)` clears one timeframe for a symbol.
- All participating timeframe snapshots are preflight-validated before any state is mutated. A corrupt M5 snapshot cannot leave M1 partially advanced.

Candle validation rechecks exchange/symbol/timeframe identity, closed status, OHLC consistency, interval continuity and exact Binance `PRICE_FILTER.tickSize`. No price is rounded or inferred from `pricePrecision`.

## Immutable trace and serialization

The result contains per-timeframe status, warm-up counts, bounded pivot/event snapshots, swing/internal layer state and retained `StructureBarTrace` values. Bar traces record new pivots, events, OHLC, source and confirmation timestamps and post-bar layer snapshots. `ScalpingMarketStructureResult.to_jsonl()` emits stable timeframe/bar ordering and deterministic JSON keys/Decimal strings.

## Exclusions preserved

Stage 2 does not implement displacement qualification, last-opposing-candle OB formation, OB lifecycle/mitigation, FVG, liquidity sweep, scoring/ranking, MTF suppression/arbitration, Entry/SL/TP, risk, CVD/Depth/Absorption hard gates, private API, live order execution, Telegram/dashboard or SQLite migration. It does not resume Unit 05D's legacy nested M5/M15 arbitration and does not modify the legacy Pine replay.

## Validation

- Focused Stage 2 tests: 32 passed.
- Full inherited regression: 547 passed.
- The tests use deterministic synthetic Binance Kline inputs to validate mechanics; they are not TradingView parity fixtures and do not prove profitability.
- Verification runtime: Python 3.13.5 64-bit / Linux. Windows 10 / Python 3.12.9 and live Binance connectivity remain pending.
