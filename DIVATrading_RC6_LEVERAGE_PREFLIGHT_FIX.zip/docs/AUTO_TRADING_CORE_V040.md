# DIVATrading v0.40.0 — Multi-Pair Auto-Trading Core

## Delivery scope

This delivery adds the first persistent trading-side core on top of the existing Unit 01–05E market-data and SMC foundations:

- AUTO/MANUAL symbol universe selection for active Binance USDⓈ-M USDT perpetual contracts.
- 24h liquidity ranking with bounded active-symbol count and explicit rejection reasons.
- Exact Decimal position sizing from risk-to-stop distance, portfolio open-risk budget, symbol notional cap, leverage ceiling and exchange quantity filters.
- Signed private Binance Futures REST client with explicit TESTNET/LIVE environment selection.
- Standard order submission, position/account queries, conditional Algo Order placement/query/cancel, leverage setup and income-history retrieval.
- SQLite execution ledger with atomic unique signal claims, deterministic client IDs, order records, position records, event audit, income deduplication and an entry kill switch.
- Execution service with PAPER default, duplicate-signal protection, pending-order reconciliation and protective STOP_MARKET / TAKE_PROFIT_MARKET creation using Binance conditional Algo Orders.
- `SMCV2EvidencePipeline` composes the existing per-symbol Stage 2–5 engines without reintroducing nested MTF priority.
- `MultiPairExecutionCoordinator` routes strategy-qualified signals from any active symbol through one global risk manager and one execution service.

## Important integration boundary

`ExecutionService.submit()` accepts a `TradePlan` whose `QualifiedSignal` must already have been approved by the strategy layer. The multi-symbol evidence pipeline now runs the existing SMC Stage 2–5 engines for each supplied validated `ScalpingMarketDataView`, but it does not invent new SMC entry criteria or claim evidence alone is a qualified trade signal. The existing Stage 1–5 SMC engines remain unchanged. The live feed-to-SMC-to-qualified-signal coordinator and the complete position lifecycle worker are still integration work for the next delivery.

The current `universe` CLI command is a live read-only selector; it does not send orders:

```powershell
python -m divatrading universe --mode AUTO --max-symbols 24 --min-quote-volume 10000000 --min-trades 1000
python -m divatrading universe --mode MANUAL --symbols BTCUSDT,ETHUSDT,SOLUSDT
```

Refresh current public contract metadata first:

```powershell
python -m divatrading exchange-info
```

## Execution environment

`ExecutionConfig` defaults to PAPER. The signed client has fixed approved base URLs:

- TESTNET: `https://testnet.binancefuture.com`
- LIVE: `https://fapi.binance.com`

TESTNET requires `mode=TESTNET` and `enable_testnet_orders=True`. LIVE requires all of:

- `mode=LIVE`
- `enable_live_trading=True`
- `live_confirmation="I_ACCEPT_REAL_MONEY_RISK"`

Credentials must be provided via local environment variables or a local secret store. Never place API key/secret in source code, chat, ZIP, logs or screenshots. Restrict API key IPs and permissions. The bot must not be given withdrawal permission.

Example local environment variables (do not commit a populated `.env`):

```dotenv
BINANCE_API_KEY=
BINANCE_API_SECRET=
DIVA_EXECUTION_MODE=PAPER
DIVA_ENABLE_TESTNET_ORDERS=false
DIVA_LIVE_TRADING_ENABLED=false
DIVA_LIVE_CONFIRMATION=
```

Conditional protective orders use `/fapi/v1/algoOrder`; they are separate from ordinary `/fapi/v1/order` entries. The service persists deterministic client IDs before/after exchange operations and does not automatically retry write requests after a transport timeout. Ambiguous outcomes halt new entries and must be reconciled by client ID.

## Current limitations

- The SMC Stage 1–5 engines are not yet wired into a continuously running multi-symbol signal-generation worker.
- `QualifiedSignal` is a strategy-to-execution contract, not an assertion that a valid signal is being produced.
- The execution service attaches protective conditional orders once a non-zero entry fill is observed. The persistent reconciliation worker must be run continuously by the upcoming runtime integration.
- The entry kill switch prevents new entries but intentionally preserves existing protective exits.
- Windows 10 / Python 3.12.9 / 8 GB compatibility has not been exercised on the user's PC.
- No TESTNET or LIVE credentials were used for this build, and no real order was sent.

## Recommended operator posture

Use PAPER while strategy/runtime wiring is completed. Then validate on TESTNET. LIVE remains disabled until the complete runtime, position reconciliation, account-level risk controls, stream recovery and emergency protection are available and explicitly enabled by the operator.
