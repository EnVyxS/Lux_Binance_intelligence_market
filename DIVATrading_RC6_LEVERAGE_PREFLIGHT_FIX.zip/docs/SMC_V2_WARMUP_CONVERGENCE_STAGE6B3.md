# SMC V2 — Warm-up Convergence Runtime (Stage 6B.3)

## Purpose

Stage 6B.3 compares the Stage 2–5 evidence produced by multiple deterministic Stage 6A replays that begin at different historical pre-roll points but share one identical evaluation window. The purpose is to measure sensitivity to available pre-roll history, not to select profitable parameters or declare strategy quality.

Use at least three distinct pre-roll durations where data coverage permits. Two trials are supported only as an explicitly limited comparison. The engine does not assign an automatic convergence pass/fail threshold.

## Frozen comparison requirements

Every trial must have a valid Stage 6A manifest and complete immutable JSONL ledger. All trials must share:

- symbol and exact active native intervals;
- one identical half-open evaluation window `[start_ms, end_ms_exclusive)` aligned to every active interval;
- code SHA-256, canonical strategy config SHA-256, metadata SHA-256 and `UTC_KLINE_CLOSE_PLUS_1MS_V1` clock policy;
- identical native candle content for each active timeframe inside the evaluation window.

The comparator validates the source-file hashes, row counts, ledger header, capture sequence, monotonic replay clock, capture summary and terminal run summary. It verifies source and ledger hashes again after comparison. A change to any source during the analysis rejects the report. Input manifests, source candles and ledgers are never modified.

The engine state is **not reset** at the evaluation boundary. Each trial is a full replay from its own manifest start; the evaluation window is only a comparison filter over the resulting capture/evidence stream.

## Evidence comparison semantics

Stage 2 structure traces, Stage 3 OB formation/candidate evidence, Stage 4 OB lifecycle evidence, and Stage 5 liquidity/reference/sweep/FVG evidence are compared by stable event/entity keys and absolute known-at time.

Replay-relative positional fields whose names end in `_index` are excluded from equality comparison. Their values necessarily shift when a replay starts earlier or later and are not absolute market coordinates. Absolute source/confirmation timestamps, OHLC/zone/price values, deterministic IDs, event types, lifecycle state, and all other payload fields remain in the comparison. Divergence samples retain the original unmodified left/right payloads so the excluded positional values remain inspectable.

The report includes, per trial, pre-roll duration and bar counts by timeframe, first pre-roll timestamp, evaluation-slice SHA-256 fingerprints and counts by timeframe, leading/internal/trailing gaps, replay gap events, and warm-up readiness observations. Pairwise comparisons report record counts, normalized exact payload matches, one-sided keys, changed payloads, first divergence time and bounded raw-payload samples.

Gap/confound samples and divergence samples are capped at 100 per report section/pair; aggregate counts are not capped. The implementation uses a temporary on-disk SQLite spool and streaming Kline reads to avoid holding entire ledgers or candle histories in Python memory.

## Plan file and CLI

Create a plan JSON. Relative `manifest`, `ledger`, and optional `root` paths resolve from the directory containing the plan file.

```json
{
  "plan_schema_version": 1,
  "evaluation_window": {
    "start_ms": 1790000000000,
    "end_ms_exclusive": 1790086400000
  },
  "trials": [
    {
      "trial_id": "short",
      "manifest": "short/manifest.json",
      "ledger": "short/replay.jsonl"
    },
    {
      "trial_id": "medium",
      "manifest": "medium/manifest.json",
      "ledger": "medium/replay.jsonl"
    },
    {
      "trial_id": "long",
      "manifest": "long/manifest.json",
      "ledger": "long/replay.jsonl"
    }
  ]
}
```

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-convergence `
  --plan .\data\BTCUSDT\warmup-plan.json `
  --report .\reports\BTCUSDT-warmup-convergence.json
```

The plan supports 2–10 trials and requires distinct pre-roll durations. Three trials without explicit labels receive SHORT/MEDIUM/LONG labels ordered by duration. Two trials are reported as `LIMITED_TWO_TRIAL_COMPARISON`; three or more as `THREE_PLUS_TRIAL_COMPARISON`.

The output is schema-validated against `docs/schemas/stage6b_warmup_convergence_report.schema.json` and written atomically with a deterministic report SHA-256. `comparison_payload_policy` identifies the relative-index normalization. `convergence_policy` is always `DESCRIPTIVE_NO_AUTOMATIC_PASS_THRESHOLD`.

## Interpretation and limitations

- Agreement is descriptive and depends on the selected common evaluation window and source coverage.
- Missing bars and replay gap events are confounders; they are reported, not interpolated or silently repaired.
- A stable report does not imply profitable trades, robust execution, out-of-sample validity, or statistical significance.
- Stage 6C.2 completed a bounded real BTCUSDT provisional smoke over a common 15-minute evaluation interval with 3h/2h/1h pre-rolls. All trials had complete common evaluation candles and READY M1/M5 status, but the automatic convergence verdict remained false: Stage 4/5 differences persisted between 3h and 2h, and 1h also differed in Stage 2. See `REAL_DATA_STAGE6C2_SMOKE_REPORT.md`. This is an empirical sensitivity observation, not a convergence pass or calibration result.
- The feature is read-only. It does not modify Stage 6A replay behavior or SMC V2 Stage 1–5 detection rules and adds no scoring, candidate qualification, entry, SL/TP, risk, private API, order execution, Telegram, or dashboard behavior.

## Verification

Stage 6B.3 focused tests cover three-trial and two-trial modes, identical evaluation-source fingerprints, relative-index normalization, duplicate pre-roll rejection, immutable input hashes, schema output and CLI report generation. Full regression and clean-extraction verification are recorded in the release handoff and test report.
