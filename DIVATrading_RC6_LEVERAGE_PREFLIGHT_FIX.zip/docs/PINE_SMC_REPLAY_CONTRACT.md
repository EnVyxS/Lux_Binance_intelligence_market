# Pine SMC Deterministic Replay & Reference Contract — Unit 05B

## 1. Purpose and non-goals

This contract defines how to capture the exact inputs and outputs needed to verify a future Python implementation against the audited Pine v6 indicator. It does not implement candle replay, SMC logic, scoring, signal generation, SL/TP calculation or order execution.

The comparison boundary has two stages:

1. **Per-timeframe engine output:** M1, M5 and M15 output records, including event time, candidate signal fields, swing trend and active OB state needed to inspect the engine.
2. **Chart-level arbitration output:** the final M1/M5/M15 `take*` decisions after nested M5/M15 rules.

Both stages matter. Matching a final marker alone is not sufficient to prove that OB creation, mitigation, freshness, or MTF nesting is correct.

## 2. Reference provenance required

Every fixture must identify:

- The Pine source SHA-256 and Pine language version.
- Exact TradingView exchange ticker ID, which must resolve to the same Binance USDⓈ-M perpetual market used by the bot. Do not substitute spot or another exchange feed.
- Chart timeframe, capture/export date, chart timezone, tick size, and all effective values for the 49 Pine inputs (defaults included; record overrides explicitly).
- The TradingView loaded-history boundary and the final bar available at capture. `last_bar_index` changes the SMC reset point.
- A continuous OHLCV series for each of 1m, 5m and 15m, in ascending opening-time order, with exact UTC epoch-millisecond open times and decimal strings for OHLCV.
- The full available prefix used by Pine's `ta.atr(14)`, `ta.rsi(14)`, `ta.sma(volume,20)` and `ta.dmi(14,14)` series, not only the `warmupBars` SMC state window.
- The explicit output comparison interval. A fixture may assert “no signal” only when its coverage is complete and `assert_no_other_signals` is true.
- Reference outputs and their capture method. Do not transcribe a visual marker approximately when exact values are not available.

Use the schema in `reference/pine_smc/reference_fixture.schema.json`. It enumerates all 49 accepted input names/types/ranges/default annotations and requires every effective input. A `assert_no_other_signals=true` fixture must also set `coverage.complete=true`. The template is prefilled with Pine defaults but otherwise deliberately unpopulated: there are no verified TradingView reference cases in this checkpoint.

## 3. OHLCV replay semantics

- Candles are keyed by `(exchange, symbol, timeframe, open_time_ms)`. `open_time_ms` is candle opening time in UTC epoch milliseconds, not close time, local timezone, arrival time or exchange event time.
- Values are decimal strings. Parsing through binary float is not allowed in fixture storage. Keep the original Binance/TradingView export precision; do not round to `tickSize` during ingestion.
- Every candle must satisfy `high >= max(open, close)`, `low <= min(open, close)`, `high >= low`, positive OHLC prices and non-negative volume.
- Series must be strictly chronological, unique and gap-free for their interval. A gap invalidates that fixture segment; do not fill it with synthetic candles.
- Capture the source history from the same loaded chart dataset. The SMC state reset is governed by `startIndex=max(0,last_bar_index-warmupBars+1)` per `request.security` source context, but Pine built-in indicator series continue from bars before that boundary. Truncating to exactly `warmupBars` will generally not reproduce those indicator values.
- `warmupBars` is 300–2500 in Pine, default 1500, and is applied independently to M1, M5 and M15 source contexts. Record each context's final available source bar/open time.
- Evaluate only on source bars at which the Pine-returned series is available. Because `f_smc()` shifts returned fields by one source bar, record both `evaluation_time_ms` (bar on which shifted result is observed) and `event_time_ms` (original signal source bar's `time`). Do not collapse these into one timestamp.
- The source signal time uses Pine `time`, which is the source candle's opening time. It is not the candle close timestamp.
- `request.security` uses `gaps_off`. The script's lookahead selection depends on the chart timeframe; record the chart timeframe and preserve the exact source context. The recommended chart timeframe in the indicator is M1.
- Replaying a historical prefix with a different last bar than the reference changes the SMC state reset boundary. Therefore identical candle values over a smaller/different dataset do not automatically imply identical results.

## 4. Indicator series / numeric compatibility

The future engine must reproduce the Pine semantics, not substitute a similarly named Python library indicator. The reference harness must be able to compare or inspect:

- Custom ATR(200): initial arithmetic mean for local indices 0 through 199, then the exact Wilder-like recurrence in the source.
- `ta.atr(14)`, `ta.rsi(14)`, `ta.sma(volume,20)` and `ta.dmi(14,14)`: Pine built-in semantics and their pre-roll/initialization.
- `syminfo.mintick`: captured for the exact TradingView instrument. SL spread estimate and minimum-stop logic depend on it.
- Source float and display precision separately. Pine formats some OB/score CSV fields with `format.mintick` or `#.0`; that formatting must not be confused with underlying calculations.

`compare_signal_sets()` in `divatrading.strategy.parity_contract` compares normalized `Decimal` records. It applies only tolerances explicitly passed by the caller. The default is exact comparison; there is no hidden tick or score rounding.

## 5. Normalized reference output

Each signal record identifies:

- `symbol`, `timeframe`, `event_time_ms` (original source-bar opening time), `evaluation_time_ms` (bar/time when the one-bar-shifted output becomes observable), `direction`, and `trigger`.
- `ob_source_time_ms`, `ob_top`, `ob_bottom`.
- `entry_proxy`, `stop_loss`, `take_profit`.
- `entry_band_low`, `entry_band_high`.
- `setup_score`, `ob_quality_score`, `timing_score`.

The current code-level contract requires `Decimal` for numeric price and score fields and validates stable signal identity by `(symbol,timeframe,event_time_ms,direction)`. Trigger and OB source timestamp are exact fields. Price and score tolerances are caller-supplied and must reflect the precision of the trusted reference capture.

For a full parity fixture, also preserve per-timeframe engine observations and active OB snapshots at the comparison evaluation time. These are needed to investigate OB priority and nesting failures even when the final selected signal happens to match.

## 6. Parity report semantics

A report is a deterministic ordered set of:

- `MISSING`: a Pine reference signal has no corresponding candidate signal.
- `UNEXPECTED`: candidate emits a signal not present in the Pine reference coverage.
- `FIELD`: same identity, but trigger, OB source time, price or score differs beyond its explicit tolerance.

A fixture's coverage interval and complete-coverage assertion must be validated before interpreting absence as an error. Partial TradingView screenshots or manually sampled signals do not establish that no other signals occurred.

## 7. Reference acquisition and evidence gates

1. Implement source expressions in bounded, auditable slices directly from the exact Pine v6 source. A real TradingView fixture is not required to translate a formula whose source behavior is explicit.
2. Write deterministic source-derived tests for initialization, recurrence, state reset, branch ordering and boundary cases. Mark these as implementation tests, never as TradingView parity tests.
3. Use the exact Binance USDⓈ-M perpetual ticker and chart timeframe when collecting independent observations. M1 is the recommended chart context because `request.security()` lookahead depends on chart timeframe.
4. Historical replay OHLCV may come from Binance USDⓈ-M Futures through the existing Kline history path, provided the ticker mapping, timeframe, candle timestamps and loaded-history prefix match the TradingView chart data. Never substitute another exchange or spot feed.
5. TradingView Basic users can record selected exact Data Window outputs as narrow positive spot checks; record all effective inputs, field names/values, source event candle and evaluation candle timestamps, chart timezone, source hashes and capture time. A screenshot supplements exact text observations.
6. A full machine-readable TradingView fixture from the existing v2 CSV intake remains optional when chart-data export is available. It is not a requirement to start source-derived implementation.
7. Partial screenshots/manual samples do not establish complete signal coverage or prove that no signals occurred elsewhere. Complete-negative assertions require complete, independently attested coverage.
8. Review source identity and timestamp alignment, then publish all mismatches. Do not tune tolerances simply to make a failing test pass.

## 8. Current fixture status

- Trusted TradingView reference cases: **none supplied / none accepted**.
- Synthetic OHLCV: **not included as expected-output evidence**.
- No signal output is claimed to be verified against TradingView in Unit 05B.
- The comparator itself is tested with hand-authored unit records only to verify diff mechanics; these tests are not Pine reference fixtures.

## 9. Implementation boundary

Source-derived implementation can proceed in narrow slices before independent TradingView fixtures are available, as long as every expected value is derived from explicit Pine source expressions and deterministic test inputs. Unit 05D stages 1–2 cover warmup reset, custom ATR(200), parsed candle extremes, swing/internal pivot-leg state, crossed-state, BOS/CHoCH, independent trends and event-extreme scans. Do not claim full parity, and do not interpret incomplete samples as negative coverage. OB/FVG lifecycle, scoring, trigger selection and MTF arbitration require separate source mapping and implementation slices. Independent TradingView observations remain necessary to measure runtime parity for corresponding behaviors.
