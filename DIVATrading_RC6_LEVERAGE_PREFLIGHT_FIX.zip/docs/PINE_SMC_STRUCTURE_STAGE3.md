# Unit 05D — OB/FVG Creation and Mitigation Lifecycle (Stage 3)

## Status and source identity

- Release: `0.20.0`.
- Parent checkpoint: Unit 05D Stages 1–2, v0.19.0; ZIP SHA-256 `1c6e673af15d75b3234eaf5bb2ab177730cf9076a1bfcbe743bd612fac3d6c6c`.
- Original Pine v6 SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented Pine SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Source blocks: `f_pushOB` / `f_removeOB` around lines 78–110; internal-break OB scans around lines 450–520; mitigation around lines 530–540 in the packaged Pine reference.

## Implemented behavior

1. Adds effective Pine inputs `fvgMinAtr` (default `0.10`, minimum `0`) and `mitigateClose` (default `false`) to `PineSmcStructureConfig`; both are recorded in replay metadata.
2. After an internal bullish event, scans parsed lows beginning at the internal-high pivot offset using strict `<`, retaining the oldest equal minimum. After an internal bearish event, scans parsed highs with strict `>`, retaining the oldest equal maximum.
3. Normalizes the chosen parsed candle with `top=max(parsedHigh, parsedLow)` and `bottom=min(parsedHigh, parsedLow)`. The source candle index/time and structure-break index/time remain separate.
4. Bullish FVG uses `low[off-1] - high[off+1]`; bearish FVG uses `low[off+1] - high[off-1]`. A gap qualifies only when it is both positive and `>= fvgMinAtr * atr200` on the break bar.
5. Keeps OB records in creation order (oldest to newest), matching Pine's parallel arrays as one typed state record. Capacity is exactly 100; insertion at capacity evicts the oldest record before appending the new one.
6. Creates bullish OB before bearish OB when their respective internal branches fire. Swing break handling remains after both internal branches.
7. Runs mitigation after structure processing and after OB creation, iterating from newest index to oldest. With `mitigateClose=false`, bearish OBs use current high and bullish OBs use current low. With `true`, both use current close. Comparisons remain strict (`>` for bearish top, `<` for bullish bottom).
8. Same-bar create-then-mitigate is preserved: a newly inserted OB can appear in both the `created` and `mitigated` trace tuples and be absent from the final active snapshot for that bar.
9. Exposes immutable `PineSmcOrderBlockTrace` snapshots through `PineSmcObLifecycleEvents` (`created`, `mitigated`, `evicted`) and each bar's `active_order_blocks`. Active snapshots preserve the collection's oldest-to-newest order; mitigation events report reverse-index removal order.
10. `used` is initialized to `false`. No signal selection is implemented in Stage 3, so no code marks an OB as used.

## API changes

`PineSmcStructureConfig` adds:

- `fvg_min_atr: float = 0.10` — finite, non-negative Pine `fvgMinAtr` value.
- `mitigate_close: bool = False` — Pine `mitigateClose` source selector.

`PineSmcStructureReplayResult` records both effective values. Public trace types exported from `divatrading.strategy`:

- `PineSmcOrderBlockTrace`
- `PineSmcObLifecycleEvents`

`PineSmcBarTrace` adds `ob_lifecycle` and immutable `active_order_blocks` snapshots. JSONL remains deterministic and now includes OB creation, mitigation, eviction and active-state records.

## Important loop and history boundary

Pine v6 `for` loops count downward when the initial value is greater than the final value; this is documented in TradingView's [Pine Script loop reference](https://www.tradingview.com/pine-script-docs/language/loops/). The OB source-selection loop is mirrored with inclusive endpoint direction and strict comparison. A valid internal pivot cannot be broken on its own confirmation bar because the delayed pivot candidate must be strictly beyond the confirming bar's high/low; a valid break therefore has at least two local bars between the pivot and break (`span >= 2`). This keeps the actual FVG scan's `off` values in the valid historical range. The defensive helper also skips any unavailable/future reference rather than synthesizing a value.

The Pine history-reference operator accesses past bars only; unavailable references propagate `na`, and negative history offsets are not a valid substitute for future data. See TradingView's [history-referencing operator documentation](https://www.tradingview.com/pine-script-docs/language/operators/). The `span=1` helper boundary is unit-tested defensively but cannot be emitted by a valid structure-break path under the audited pivot confirmation conditions.

## Stage-3 deterministic tests

The 11 additional tests cover:

- Configuration defaults/ranges for `fvgMinAtr` and `mitigateClose`.
- Bullish minimum parsed-low OB selection and strict oldest-tie behavior.
- Bearish maximum parsed-high OB selection and top/bottom normalization.
- Bullish and bearish FVG directional offsets, positive-gap condition, inclusive ATR threshold and threshold rejection.
- Descending Pine-loop helper boundary and unavailable future history reference handling.
- Same-bar creation followed by wick mitigation versus close mitigation.
- Strict mitigation boundary equality.
- Reverse-index deletion order and correct source selection.
- Capacity-100 oldest-first FIFO eviction.
- Immutable active snapshots and stable JSONL serialization.

All are source-derived implementation tests, not independent TradingView runtime parity observations.

## Stage-3 exclusions

No newest-to-oldest OB candidate selection, freshness/age/trend/PD/volatility filters, trigger selection, rejection/structure trigger, sweep logic, scoring, signal output, one-source-bar output shift, MTF arbitration, Pine built-in TA pre-roll, Dynamic Entry/SL/TP, CVD/order-flow filter, Telegram/dashboard, private API or order execution is introduced. SQLite schema remains v5 without migration.

## Evidence and limitations

- Accepted real TradingView observations: zero.
- Accepted full machine-readable TradingView reference fixtures: zero.
- Source-derived tests validate translation mechanics only; measured parity remains unverified.
- The instrumented Pine script still requires TradingView editor compilation and user-side spot checks.
- Target Windows 10 / Python 3.12.9 validation remains outstanding; this checkpoint is built/tested on Python 3.13.5 / Linux.
- The Pine source carries CC BY-NC-SA 4.0; confirm permissions before commercial use or redistribution of derivative code.
