# Stage 6C.2 — Real BTCUSDT Data & Provisional Integrated Replay Smoke

**Date:** 2026-11-12  
**Software candidate:** Unit 05E v0.37.0 (not yet clean-extraction verified at authoring)  
**Dataset:** Binance USDⓈ-M BTCUSDT Perpetual  
**Source window:** `[2026-10-12T00:00:00Z, 2026-11-11T00:00:00Z)`

## 1. Immutable source dataset

- User archive: `data.zip`
- Archive SHA-256: `0335b0e097e6ca15b6d5959ffc56f51a36a74d219cd1c70144b731886c825f63`
- M1: 43,200 closed candles, 29 raw REST pages, capture status COMPLETE.
- M5: 8,640 closed candles, 6 raw REST pages, capture status COMPLETE.
- M1 derived CSV SHA-256: `60dd30071b73c14644739b2431005885097237dd55c26e94f55fb39b1707f074`
- M5 derived CSV SHA-256: `89cea9845b5aada9b5c046a96598030a10b607a4729082ac93d1646c0c800106`
- Raw page hashes, page indexes, provenance and derived CSVs reconcile. Flattened raw REST values match the CSV rows.
- Source chronology, interval continuity, duplicate checks, close-time checks and OHLC relationships pass.

## 2. Quality audit v2

The audit returns:

- `market_data.status = PASS`
- `market_data.eligible_for_strategy_replay = true`
- `execution_metadata.status = BLOCKED`
- `execution_metadata.strict_replay_eligible = false`
- `provisional_strategy_replay_eligible = true`
- `strict_replay_eligible = false`
- combined `quality_status = WARN`

The single remaining warning is the use of a `CURRENT_SNAPSHOT_ONLY` instrument metadata snapshot. Candidate BTCUSDT tick size is `0.10`. All M1 and M5 OHLC prices are on that grid (zero violations); this is corroborating market data only and does not independently establish the filter's effective history.

## 3. Integrated provisional workflow smoke

Plan:

- Mode: `PROVISIONAL_STRATEGY_EVIDENCE`
- Symbol: BTCUSDT; intervals: M1 and M5
- Common evaluation window: `[2026-11-10T23:45:00Z, 2026-11-11T00:00:00Z)`
- Pre-roll trials: 3 hours, 2 hours and 1 hour
- Replay history cap: 128 candles; checkpoint interval: 30 captures
- Every trial uses the same code/config/metadata hash and exactly the same evaluation Kline slice.

Workflow outcome:

- `workflow_status = COMPLETED_PROVISIONAL`
- `market_data_gate = PASS`
- `execution_metadata_gate = BLOCKED`
- `strict_execution_eligible = false`
- `result_scope = STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION`
- 3/3 trial replays completed; capture counts 180, 120 and 60.
- 0 replay data gaps across all three trials.
- 3/3 checkpoint partial-to-resume probes completed.
- 3/3 Stage 6B.2 analytics reports completed.
- Stage 6B.3 convergence report completed with 3 trials and 24 pairwise comparisons.
- All three trials reported READY for M1 and M5 at all 15 M1 / 3 M5 evaluation observations.
- Evaluation Kline slice fingerprint was identical across the three trials.
- Main raw-source quality report file SHA-256: `3e7c4f0750627556243dc38643a2bfeaaed1bc66def83baca85f6cc21f30f8f9`
- Workflow report SHA-256: `f75404d1e8c6ab449f4a9d2e7e9bbf8c68f8df440725c92d8006769a1dbc54fc`
- Workflow report file SHA-256: `320ce31c0eb19768107780b1d221e685eb484e72b84d069dc7ab5838791babf9`
- Convergence report SHA-256: `84417e54eb9ffeabafb14cba8b2107862786cbb7dcc8f47300bcee858e80648e`
- Convergence report file SHA-256: `90ed34e8696ce7bfa5dc44cbb7e18db7aad362658d7b6f954a392f219740340d`
- Frozen code SHA-256: `c6244b5878cd656a92eb91ddd03df1875d93f3e5eaa68111693be275b8f5fded`

## 4. Convergence interpretation — NOT CONVERGED

The convergence engine deliberately has no automatic pass threshold. The observed output is not a convergence PASS:

- 3h vs 2h: Stage 2 market-structure evidence and Stage 3 OB-formation evidence matched exactly on both M1/M5. Stage 4 OB lifecycle differed (375 M1 / 33 M5 evidence differences); Stage 5 liquidity/FVG differed (300 M1 / 33 M5 differences).
- 3h vs 1h: Stage 2 differed (15 M1 / 3 M5 payload divergences); Stage 4 differed (621 M1 / 122 M5); Stage 5 differed (660 M1 / 99 M5). Stage 3 OB formation matched on M1; no M5 OB formation records occurred in this slice.
- 2h vs 1h: Stage 2 differed (15 M1 / 3 M5); Stage 4 differed (276 M1 / 89 M5); Stage 5 differed (360 M1 / 66 M5). Stage 3 OB formation matched on M1; no M5 OB formation records occurred in this slice.

These are evidence counts/differences, not trade outcomes. The 15-minute evaluation interval is intentionally a small tooling smoke. The observed differences show that a short pre-roll is insufficient for some stateful OB lifecycle and liquidity evidence; they do not quantify how much pre-roll will be sufficient.

## 5. Known issue fixed during smoke

The first convergence attempt failed because Stage 4 lifecycle traces shared the originating structure `event_id`, although an OB can emit multiple lifecycle transitions. The convergence stable-key function now uses `candidate_id + transition + observed_time_ms + to_status`, matching the deterministic identity already used by the replay engine. A regression test covers distinct transitions sharing one parent event ID. This fixes evidence identity collision; it does not suppress or reinterpret genuine pre-roll divergences.

## 6. Limitations and next work

- This is not a 30-day Stage 6A ledger replay. A full 30-day trial generated an oversized ledger during an interrupted attempt; the run was stopped and the partial output was discarded. A bounded 3h/2h/1h run was used to validate orchestration mechanics.
- No strict execution replay, fills, fees/slippage validation, entries, SL/TP, PnL, calibration or profitability claim.
- Historical tick-size confirmation remains pending. Do not relabel the current snapshot as historical effective metadata.
- Need longer pre-roll sensitivity experiments on a representative evaluation interval, then an explicit owner-approved warm-up policy.
- Need at least 12 fully closed UTC months of BTCUSDT M1/M5 for eventual calibration, with TEST held sealed until protocol freeze.
- Windows 10 / Python 3.12.9 target verification is still outstanding.
