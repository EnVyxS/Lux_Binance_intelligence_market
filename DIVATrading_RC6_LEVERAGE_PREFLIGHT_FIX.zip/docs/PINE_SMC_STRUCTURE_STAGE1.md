# Unit 05D — Pine SMC Structure Primitives (Stage 1)

## Status and source identity

- Release: `0.18.0`.
- Source of truth: audited Pine v6 source preserved in `reference/pine_smc/Sniper_SMC_MTF_Enhanced_Instrumented_v1.pine`.
- Original Pine SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented full script SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- This implementation is derived from the audited source expressions at lines 219–310, 355–370, 377–440 of the packaged instrumented script. Capture plots do not change those expressions.

## Implemented source behavior

1. Each engine instance represents exactly one source timeframe (`1m`, `5m`, or `15m`). Independent instances must be used for all three contexts.
2. The replay requires the complete chronological loaded-history prefix for the source context. `last_bar_index` is `len(candles)-1` and `start_index = max(0, last_bar_index - warmup_bars + 1)`. Bars before that index do not affect the SMC local state.
3. `local_index` is reset to `-1` at the boundary and increments to zero on the first in-window bar.
4. True Range is `high-low` at local index 0. Thereafter it is the maximum of the current range and the absolute high/low gaps from the previous source candle close.
5. Custom ATR(200) accumulates the arithmetic mean for local indices 0–199. Starting at index 200 it uses `(previous_atr200 * 199 + true_range) / 200`. `tr_sum` stops accumulating after the initialization period, matching the Pine code.
6. The volatility test is inclusive: `(high-low) >= 2 * atr200`. When true, `parsed_high=low` and `parsed_low=high`; the apparent inversion is intentional and is preserved.
7. Swing and internal pivot-leg machines are independent. Each examines the candle at the delayed `length` offset against only the more recent `length` candles. Equal highs (`recent_high >= candidate_high`) and equal lows (`recent_low <= candidate_low`) disqualify those candidate branches. High-leg detection has priority over low-leg detection.
8. A leg transition updates only the matching pivot side, resets its crossed flag, records `local_index-length`, and preserves the previous pivot value. Swing pivot transitions also update the Pine trailing range top/bottom state.
9. Per-bar trace output records source candle open time and pivot source time separately from local array index. JSONL serialization uses sorted keys and stable separators.

## API

- `PineSmcStructureConfig`: symbol, timeframe, Pine `warmupBars`, `swingLen`, `internalLen`. It enforces the Pine input ranges.
- `PineSmcStructureEngine(config).replay(candles)`: consumes a complete contiguous sequence of existing `Kline` objects. It rejects wrong exchange/symbol/timeframe, invalid OHLC, invalid timestamps, gaps and non-finite binary64 conversions.
- `PineSmcStructureReplayResult`: contains reset boundary, history count and immutable per-bar traces.
- `PineSmcStructureReplayResult.to_jsonl()`: deterministic trace serialization.
- `parse_candle_extremes()`: the standalone Pine parsed-candle operation for deterministic boundary tests.

OHLCV remains stored in the existing market-data `Kline` model as `Decimal`. Conversion to Python `float` occurs only at the Pine calculation boundary because Pine's `float` operations are IEEE-754 binary64. No tick-size rounding is applied in this module.

## Explicit non-goals in Stage 1

This release does not implement BOS/CHoCH event transitions, OB/FVG lifecycle, OB selection, mitigation, signal triggers, scoring, signal generation, one-source-bar output shift, MTF arbitration, Pine built-in TA pre-roll (`ta.atr(14)`, RSI, SMA, DMI), or any entry/SL/TP decision. It does not connect to live feeds, database, CVD/order flow, Telegram, dashboard, or Binance execution.

The trace therefore must not be interpreted as a complete `f_smc()` output. Do not call this a full Pine parity implementation.

## Evidence policy

The 15 new tests are source-derived implementation tests, not expected outputs transcribed from TradingView. No fake reference outputs are used. TradingView CSV export is optional for users who have a supported export feature; it is not a precondition for source-level translation. For TradingView Basic, selected visible/Data Window outputs can be recorded as narrow positive spot checks. A screenshot is supporting evidence; exact fields must also be recorded as text. Manual samples cannot establish complete signal coverage or absence of signals.

No independently accepted TradingView spot-check or full fixture is present in this release. Pine parity remains unmeasured.

## Next bounded stage

Continue Unit 05D by translating the next state-transition block after pivot detection from the Pine source, keeping BOS/CHoCH and crossed-state semantics isolated and source-derived. Do not begin OB lifecycle, signal arbitration, or dynamic trade management until their dependencies are separately implemented and tested.
