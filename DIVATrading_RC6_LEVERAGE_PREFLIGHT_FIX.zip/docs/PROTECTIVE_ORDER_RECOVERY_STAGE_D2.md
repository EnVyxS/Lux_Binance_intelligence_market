# Stage D2 — Position-Aware Protective Order Recovery

## Objective

Recover a missing quantity-scoped STOP_LOSS or TAKE_PROFIT Algo order for an existing managed lot only when the prior order is proven terminal with zero executed quantity and the exchange position still exactly matches the durable local allocation. This is not a generic order retry and it is not a replacement path for triggered or partially filled orders.

## Authorization and default behavior

- `DIVA_ENABLE_PROTECTION_RECOVERY=false` by default in both `.env.example` and `.env.testnet.example`.
- The feature is accepted only when `DIVA_EXECUTION_MODE=TESTNET`; PAPER and LIVE configurations reject it.
- TESTNET order placement and Stage C continue to require their separate explicit authorization flags. D2 does not enable those flags and does not alter LIVE authorization.
- The recovery path never clears the account entry halt. A successful replacement only restores protection; the operator must obtain a fresh reconciliation and release any safety halt through the separately governed control path.

## Preconditions

1. Private User Data Stream status is `CONNECTED`.
2. Latest account reconciliation is a fresh sequential REST snapshot and no stream event occurred during the snapshot.
3. The reconciliation stream-event watermark exactly equals the current durable User Data Stream watermark.
4. The only account discrepancies eligible for recovery are `POSITION_MISSING_PROTECTION` entries within the same managed `(symbol, positionSide)` group. A flat-position branch may also accept a matching `LOCAL_POSITION_NOT_ON_EXCHANGE` discrepancy, but only after REST confirms zero exchange quantity.
5. The target managed lot, management state and ACTIVE risk reservation exist and agree. Aggregate local group quantity must equal the exact REST position quantity.
6. The source STOP/TP is queried by its deterministic `clientAlgoId`; source identity must match symbol, side, positionSide, order type, per-lot quantity, trigger price, reduceOnly/closePosition semantics, workingType and priceProtect.
7. Source status must be `CANCELED`, `CANCELLED`, `EXPIRED` or `REJECTED`, with `executedQty=0` and no `actualOrderId`.

## Source evidence hierarchy

- Primary: signed REST `GET /fapi/v1/algoOrder` by `clientAlgoId`.
- If REST returns `-2013`, confirm the ID is not in open Algo orders, then use the latest durable matching `ALGO_UPDATE` event.
- If a recovery action is resumed after REST history no longer retains the source, the latest stream update overrides the original action snapshot. A persisted source snapshot is accepted only with its stored SHA-256 verification. A newer TRIGGERED/filled event overrides older CANCELED evidence.
- REST query errors other than `-2013`, absent stream evidence, malformed identity or an active source are not proof of terminal no-fill and fail closed.

## Recovery sequence

1. Verify the fresh account observation and exact group allocation.
2. If exchange position is zero, do not create protection; invoke existing flat-position finalization, order cleanup and reservation-release verification.
3. If the target Algo is already active and exactly matches the persisted lot, return `ALREADY_PROTECTED` without mutation.
4. If source is TRIGGERED/FINISHED/EXECUTED/FILLED, has `actualOrderId`, or has non-zero `executedQty`, return `TRIGGERED_REQUIRES_FILL_RECONCILIATION`; the existing fill reducer owns residual-quantity management. Never create a replacement in this branch.
5. Verify every sibling lot and the other protective role. A listed sibling gap can be skipped only if REST shows the exact terminal no-fill source or REST `-2013` is backed by the exact durable terminal no-fill stream event. Active siblings must match all identity fields.
6. Claim a deterministic durable `PROTECTIVE_ORDER_RECOVERY` action. Store exact lot quantity/trigger, source Algo evidence and SHA-256, replacement client ID, allowed gap identities and `post_attempted=false`. The group action lock prevents concurrent mutation of the shared `(symbol, positionSide)` quantity.
7. Query the deterministic replacement ID before POST. If an exact active order already exists, adopt it; if it is mismatched, halt.
8. Before the one permitted POST, re-read fresh sequential reconciliation and exact aggregate position quantity. Persist `post_attempted=true` before the request.
9. Send exactly one quantity-scoped Algo POST. Query the exact replacement ID afterward. POST acknowledgement alone is not proof. Verify symbol, clientAlgoId, order type, closing side, positionSide, exact per-lot quantity, trigger, reduceOnly/closePosition, workingType and priceProtect.
10. Re-read exchange quantity and group projection, update only the target lot's protection pointer, record the Algo order/action, and leave entry halt latched.

## Ambiguous outcomes and restart behavior

- A transport/POST ambiguity or post-query failure sets `SUBMISSION_UNKNOWN`, keeps the risk reservation and entry halt, and never automatically repeats the POST. Restart recovery queries the exact deterministic replacement ID. If it is still absent or query remains ambiguous, action stays unknown for operator reconciliation.
- If the process crashes after state pointer commit but before action status becomes CONFIRMED, restart recognizes the known replacement ID in the persisted pointer, queries it, re-verifies the order and finishes the durable action without another POST.
- One missing role is recovered per fresh reconciliation snapshot. After each recovery, Account Runtime must obtain a new REST snapshot before considering another gap, avoiding use of stale discrepancy lists.

## Explicit non-goals

- No recovery of TRIGGERED/partially filled orders; those remain with the D1 fill reducer path.
- No blind recreation when a source Algo ID is absent without durable terminal evidence.
- No cancel/replace of an active sibling protection.
- No risk-reservation release while exchange position remains open.
- No automatic entry-halt clear.
- No LIVE operation and no same-side scale-in qualification.

## Validation

Unit tests use FakeExecutionClient, local SQLite and synthetic User Data Stream events. They cover STOP replacement, terminal evidence fallback, later triggered evidence precedence, triggered deferral, flat finalization, ambiguous POST/no retry, duplicate restart, crash after pointer commit, wrong protection semantics, One-way/Hedge parameters, multi-lot sizing and one-gap-per-snapshot sequencing. No real Binance Demo/LIVE order or Algo mutation is executed by build tests.
