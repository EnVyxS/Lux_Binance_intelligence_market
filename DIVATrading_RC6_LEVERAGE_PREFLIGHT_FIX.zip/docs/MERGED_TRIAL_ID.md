# DIVATrading RC6 gabungan

## Profil awal

| Pengaturan | Nilai awal |
|---|---|
| Akun | Binance USDⓈ-M Futures |
| Strategi | Sweep swing M15, reclaim dan break M5, kemudian retest pada L2 yang segar |
| Entry | LIMIT IOC dengan batas harga, filter Binance, dan minimum estimasi 2R netto |
| Risiko terencana per setup | `FIXED 0.20 USDT` pada database baru |
| Slot pada trial | **1** posisi aktif atau entry pending pada satu waktu |
| Batas LIVE | **2** slot jika dipilih secara eksplisit |
| Supervisor posisi | SL/TP native Binance, partial `1R`, breakeven setelah fill partial terkonfirmasi, dan trailing RC6 |
| Exit order-flow menjelang TP | Opsi eksperimental, aktifkan secara eksplisit |

Risiko terencana memakai estimasi fee, slippage, dan reservasi RC6. Binance tetap bisa menolak setup yang ukurannya di bawah batas minimum. Rugi pada fill aktual dapat melebihi estimasi, terutama saat harga bergerak melewati pemicu stop.

## Pengaturan di Windows

Gunakan Python 3.12.9 x64 dan `INSTALL_WINDOWS.bat`. Isi kredensial hanya di `.env` lokal. `TEST_WINDOWS.bat` menjalankan tes dengan mode PAPER dan izin order yang dimatikan. `START_MERGED_TRIAL_WINDOWS.bat` menampilkan risiko tersimpan dari `data\merged-trial.db` sebelum meminta frasa konfirmasi `START LIVE TRADING`. Launcher itu mengaktifkan jalur real-money setelah konfirmasi.

Jalankan satu aktor penulis untuk akun Binance yang sama. Proses LIVE paket gabungan yang memakai API key sama pada pengguna sistem operasi yang sama berbagi lock. Hentikan bot lama atau proses pada perangkat lain terlebih dahulu. Pakai kembali database trial untuk restart dan pengaturan, agar posisi serta order bot tetap dapat direkonsiliasi.

### Risiko yang bisa diedit

Jalankan dari Command Prompt di folder hasil ekstraksi. Gunakan jalur database yang sama dengan launcher.

```bat
set "DIVA_DATABASE_PATH=data\merged-trial.db"
.venv\Scripts\python.exe -m divatrading risk-config
.venv\Scripts\python.exe -m divatrading risk-config --mode fixed --value 0.20
```

Gunakan `risk-config --mode percent --value ANGKA_PERSEN` untuk beralih ke persentase ekuitas. Gunakan `--mode fixed` kembali untuk nilai dalam USDT. Nilainya disimpan di SQLite dan dibaca sebelum kandidat entry berikutnya. Jika Telegram RC6 diaktifkan, kontrol `/risk fixed` dan `/risk percent` mengubah pengaturan yang sama.

Launcher trial memakai `--max-positions 1`. Ubah opsi itu menjadi `--max-positions 2` pada perintah `auto-trade-runtime` jika ingin membuka dua slot kelak. Batas ini juga menghitung reservasi entry pending lintas pair. Jumlah pair yang dipindai diatur terpisah dengan `--max-symbols`.

### Exit opsional menjelang target

Di Command Prompt, set `DIVA_TRIAL_EARLY_EXIT=1` sebelum menjalankan launcher untuk menambahkan `--early-exit-protection`. Untuk kembali ke default, hapus variabel itu dengan `set "DIVA_TRIAL_EARLY_EXIT="`. Saat diaktifkan, proteksi ini mengevaluasi sisa posisi setelah partial RC6 yang terkonfirmasi. Ia memakai snapshot L2 dan arus transaksi yang segar untuk mencari dua jendela pelemahan dan tembus level pada kedua sisi quote. Saat feed simbol kehilangan cakupan, SL/TP native dan supervisor berbasis mark price tetap menjadi proteksi posisi.

## Cakupan validasi

Tes offline memakai respons exchange tiruan untuk memeriksa IOC, reservasi slot, serta pemasangan dan pemulihan proteksi. Siklus order dan fill pada akun Binance, runtime Windows, dan hasil strategi di pasar masih memerlukan verifikasi terpisah. Gunakan status dan order Binance untuk memeriksa eksposur jika log menunjukkan rekonsiliasi tertahan atau SL gagal dikonfirmasi.
