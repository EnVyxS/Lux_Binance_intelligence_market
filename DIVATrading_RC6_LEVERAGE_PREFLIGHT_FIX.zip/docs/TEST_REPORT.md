# Test Report — v0.43.0

## Automated test summary
- Full suite: **747 passed**.
- Includes existing v0.40–v0.42 coverage plus SMC planner tests for LIMIT retracement, distinct confirmation-market trigger, failed confirmation, optional/required FVG confluence, invalidated OB rejection, structural target selection, M15 advisory non-veto, missing notional fail-closed, exchange max-notional cap, and candidate ranking before risk allocation.

## Static/runtime checks
- `PYTHONPATH=src python -m compileall -q src`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -m divatrading market-runtime --help`: PASS; planner and sizing options visible.
- Package import/version 0.43.0: PASS.
- `SMCV2TradePlanner` import and default configuration construction: PASS.

## Scope of verification
- Automated tests are deterministic offline tests using fixtures and mocked services.
- No real Binance public WebSocket session was opened during this build.
- No Binance private API request or order was submitted.
- No profitability, win-rate, expectancy, slippage or fill-quality claim is made.
- Local build runtime: Linux x86_64 / Python 3.13.5.
- Target Windows 10 / Python 3.12.9 / 8 GB compatibility has not yet been verified on the user's PC.


## v0.58.0rc2 — Telegram Signal Center & Kronos-mini Shadow Forecast

- Source-tree regression: **1,013 passed** on Linux x86_64 / Python 3.13.5.
- Includes v6 DB migration, signal-only qualification path, outbound Telegram photo delivery mocks, chart renderer, Kronos input/output/evaluation adapter tests, and CLI validation.
- Real Kronos model download/inference, real Telegram API send, Binance authenticated API/orders, and Windows 10/Python 3.12.9 are not covered by this build test.
