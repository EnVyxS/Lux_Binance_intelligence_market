# SMC V2 — Displacement Qualification & Initial OB Formation

**Unit:** 05E, Stage 3  
**Release:** v0.28.0  
**Status:** Implemented; deterministic mechanics tested.  
**Parent:** Unit 05E v0.27.0 (Stages 1–2).  

## 1. Scope

Stage 3 consumes the immutable, confirmed `StructureEvent` records from Stage 2 and forms initial Order Block candidates for M1 and M5. It is deliberately not an OB lifecycle or trade-entry engine.

M1 and M5 candidates are independent. M15 is retained as advisory context only; it cannot create an OB candidate, become a mandatory parent, or suppress M1/M5 candidates. Legacy Unit 05D nested M5/M15 arbitration is not used.

## 2. Public API

New module: `divatrading.strategy.scalping_order_block_formation`.

Public exports:

- `ScalpingOrderBlockFormationConfig`
- `ScalpingOrderBlockFormationEngine`
- `ScalpingOrderBlockFormationResult`
- `OrderBlockTimeframeResult`
- `OrderBlockCandidate`
- `OrderBlockFormationTrace`
- `DisplacementMeasurements`
- `ScalpingOrderBlockFormationError`, `ScalpingOrderBlockFormationInputError`, `ScalpingOrderBlockFormationCapacityError`

Call contract:

```python
result = ob_engine.process(structure_result, same_capture_market_data_view)
```

The Stage-2 result and `ScalpingMarketDataView` must have the same exact symbol and capture timestamp. The exact Binance `PRICE_FILTER.tickSize` is required. No price is rounded or inferred.

## 3. Confirmed structure-event provenance

Every candidate is derived from one Stage-2 `StructureEvent`. Before evaluation, Stage 3 checks:

- exact symbol/timeframe and supported M1/M5 source context;
- valid BOS/CHoCH direction and swing/internal layer;
- pivot source and pivot confirmation times precede the break candle;
- break confirmation time matches the source interval's close boundary;
- `pivot_price == broken_level`;
- the event satisfies the same strict confirmed-close crossing rule as Stage 2;
- the event payload is identical to the event embedded in exactly one break-bar trace;
- event previous/confirmation closes match their respective trace provenance;
- the structure trace is immutable/consistent and, when the same candle remains in the current bounded Kline snapshot, its OHLC matches the exact Binance Kline.

Missing break or previous-bar traces reject the event with explicit reason codes. Conflicting reuse of an event ID fails closed. A malformed M5 input is detected before either M1 or M5 state is committed.

## 4. Displacement leg definition and measurements

The displacement leg is the contiguous run of candles whose real bodies point in the structure-event direction, ending at the break-confirmation candle:

- bullish leg candle: `close > open`;
- bearish leg candle: `close < open`;
- a doji or opposite-color candle terminates the run;
- the break candle itself must have the expected body direction;
- the scan is bounded by `max_displacement_leg_candles`; if the leg continues beyond that bound, the event is rejected rather than truncated and misidentified.

The immutable `DisplacementMeasurements` record contains:

- break-candle body size (`abs(close - open)`);
- break-candle full range (`high - low`);
- break-candle body/full-range ratio;
- directional close extension beyond the exact broken structure level;
- the same extension normalized to the exact symbol tick size;
- directional-leg start bar/index/time and candle count;
- sum of directional-leg candle bodies;
- sum of directional-leg full ranges and the resulting leg body/range ratio;
- FVG evidence metadata (`None`, `NOT_EVALUATED`) for a later independent FVG stage.

ATR-normalized body/extension fields are not yet emitted. Their period and smoothing semantics must be specified explicitly before thresholds are calibrated; Stage 3 does not silently reuse the legacy Pine/EA ATR policy.

## 5. Numeric thresholds

Configurable thresholds:

- `min_break_body_range_ratio`;
- `min_leg_body_range_ratio`;
- `min_close_extension_ticks`.

Each threshold is a finite `Decimal`. Ratio thresholds must be in `[0, 1]`; extension threshold must be non-negative. A value of `None` disables that numeric gate. When enabled, exact equality passes (`measured >= configured minimum`).

Defaults are intentionally disabled until historical Binance replay can calibrate them. This is a deliberate high-frequency-safe starting point: Stage 3 still requires a true confirmed structure break, a directionally valid leg, an opposing source candle, and a valid tick-grid zone. The defaults are not a profitability or performance claim.

Additional bounded settings:

- `min_directional_leg_candles=1`;
- `max_displacement_leg_candles=8`;
- `ob_source_lookback_bars=20`;
- bounded symbols, candidates, processed-event identities and traces.

All numeric defaults remain provisional until replay calibration.

## 6. Last opposing source candle

After the leg start is known, Stage 3 scans backward from the immediately preceding candle, no farther than `ob_source_lookback_bars`:

- bullish OB requires the nearest preceding bearish candle (`close < open`);
- bearish OB requires the nearest preceding bullish candle (`close > open`);
- dojis are skipped and cannot become the source candle;
- the search stops as soon as the nearest opposing candle is found; older history beyond that source is not required;
- a missing trace before the source has been found fails closed;
- no opposing candle inside the configured bound rejects the candidate.

This is a hard source-definition rule, not a scoring preference. Candle clusters are not merged in this stage.

## 7. Zone boundaries and identity

Initial zone boundaries use the full source-candle wick:

- `zone_top = source_high`;
- `zone_bottom = source_low`.

The engine validates positive ordered boundaries and requires both prices to be exact multiples of the instrument tick size. It never quantizes the source candle or substitutes `pricePrecision`.

Each `OrderBlockCandidate` retains:

- deterministic `candidate_id` and exact `event_id`;
- symbol, source timeframe, structure layer, BOS/CHoCH type and direction;
- source candle index, opening/confirmation time and full OHLC;
- zone top/bottom and `FULL_SOURCE_CANDLE_WICK` convention;
- broken structure level and break-candle index/time/OHLC/confirmation time;
- deterministic displacement-leg identity and all measured metrics;
- creation reason codes.

At most one candidate is emitted for a processed event ID/source candle. Repeated delivery of the same event is idempotent. Different swing/internal events remain distinct even if their source candle/zone geometry happens to coincide; any later overlap/coalescing policy must be explicit and traceable, not silently applied here.

## 8. Immutable output, state and resource bounds

- Candidate and formation trace records are frozen dataclasses.
- `ScalpingOrderBlockFormationResult.to_jsonl()` emits deterministic, sorted-key JSON lines.
- M1/M5 state partitions are independent by symbol/timeframe.
- M15 is advisory-only and always emits an empty candidate set.
- Candidate, trace, processed-event and symbol counts are capped by config; incoming event/trace batches have hard limits.
- `reset()` supports all state, one symbol, or one symbol/timeframe partition.

## 9. Explicit exclusions

Stage 3 does not implement OB mitigation, touch, partial/full mitigation, invalidation, expiry, freshness lifecycle, retest, re-entry, setup ranking/scoring, FVG calculation/gating, liquidity sweep, entry models, Entry/SL/TP, fees/slippage, risk, position management, CVD/Depth/Absorption hard gates, database migration, private API, live execution, Telegram or dashboard.

SQLite remains schema v5. Legacy Unit 05D Pine/EA replay modules are unchanged.

## 10. Tests and limits

Stage 3 focused tests: **30 passed**. Unit 05E focused tests Stage 1–3: **89 passed**. Full regression: **577 passed**.

Synthetic tests validate code mechanics only. No claim is made about win rate, profitability, Pine parity, live Binance operation, or target Windows runtime. Verification environment: Python 3.13.5 64-bit / Linux. Windows 10 / Python 3.12.9 remains untested.
