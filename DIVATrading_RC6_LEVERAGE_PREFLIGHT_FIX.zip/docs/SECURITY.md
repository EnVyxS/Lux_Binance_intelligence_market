# Security Baseline

- Keep `.env` local; it is ignored by Git. Unit 02 public metadata requests require no credentials.
- Do not send Binance API keys, API secrets, Telegram bot tokens, or account identifiers in chat or screenshots.
- Future Binance keys must have withdrawals disabled. Enable only the permissions required by implemented endpoints.
- Use Binance IP restrictions when operationally feasible for the user's connection model.
- Do not log credential values. The logging layer redacts configured secret strings as defense in depth.
- Telegram Owner identity must be verified server-side before accepting privileged callbacks or commands.
- Validate callback ownership and authorization on every action; hiding a button is not authorization.
- Dangerous actions (Live enable, emergency close, risk limit increase) require explicit confirmation and audit logging.
- Unit 02 has only a public read-only REST client and blocks live mode. Do not add a private or live order path in a metadata-only change.
