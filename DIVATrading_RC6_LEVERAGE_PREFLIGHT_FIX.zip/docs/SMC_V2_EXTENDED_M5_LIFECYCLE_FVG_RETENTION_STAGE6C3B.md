# SMC V2 Stage 6C.3B — Extended M5 Lifecycle & FVG Retention Diagnostics

**Release:** 0.39.0  
**Status:** Runtime optimization implemented; long-horizon acceptance incomplete.

## Scope and invariants

This checkpoint optimizes replay execution only. It does not alter Stage 1–5 strategy definitions, OB age/invalidation rules, FVG state transitions, entry/exit logic, or warm-up policy.

- Stage 4 M1/M5 OB lifecycle remains independent and transactional.
- Stage 5 FVGs retain their existing states and 512-per-timeframe capacity. No age-based expiry was added.
- Replay remains provisional strategy evidence. It does not validate historical execution metadata, orders, fills, fees, slippage, PnL, or profitability.

## Runtime changes

1. Stage 4 state cloning now copies mutable dictionaries/lists and creates fresh `_MutableLifecycle` records with `dataclasses.replace`; immutable candidates/traces are reused.
2. Stage 5 state cloning copies mutable containers and fresh `_MutableFVG` records; immutable Klines, references, sweeps and traces are reused.
3. Stage 5 pivot source/confirmation candle validation uses timestamp-indexed dictionaries rather than repeated linear scans through the candle window.
4. Stage 4 computes candidate fingerprints and skips the expensive full validation path only when an identical fingerprint was already validated and retained. Conflicting candidate-ID reuse still fails closed.

The explicit clone strategy preserves the prior two-timeframe atomic commit model. The full 719-test suite passes. A bounded 180-capture comparison between the pre-optimization and optimized implementation produced 12,541 records on each side; after normalizing only run/capture identity and code-hash fields, all records were identical.

## Performance evidence

| Measurement | Result |
|---|---:|
| 180 captures, before optimization, cProfile | 6.321 s |
| 180 captures, after state-clone optimization, cProfile | 2.300 s |
| Relative improvement | ~2.75x |
| 700 captures, direct iterator warm-through | ~13.7 s (without cProfile) |
| 20 captures after capture 900, cProfile | 2.327 s |
| Full regression | 719 passed |

These are Linux/Python 3.13.5 measurements. They are not a Windows 10/Python 3.12.9 performance guarantee.

## Real BTCUSDT partial diagnostic

Source: retained BTCUSDT USDⓈ-M M1/M5 REST-derived dataset; manifest window from `1794254400000` through `1794355200000` (28 hours). The intended trial uses 27 hours of pre-roll and a common 60-minute evaluation window.

A compact partial run completed 600 M1 captures (10 hours), with zero replay gaps:

- Suppressed pre-roll evidence records: 140,996.
- M1 OB retained: 195 — ACTIVE_FRESH 13, CANDIDATE 2, MITIGATED 9, INVALIDATED 158, EXPIRED 13.
- M5 OB retained: 41 — ACTIVE_FRESH 10, MITIGATED 3, INVALIDATED 28.
- M1 FVG retained: 210 — ACTIVE 7, TOUCHED 1, PARTIALLY_FILLED 11, FILLED 191. Total retained occupancy 41.02% of 512; nonterminal inventory 19/512 (3.71%).
- M5 FVG retained: 33 — ACTIVE 2, PARTIALLY_FILLED 4, FILLED 27. Total retained occupancy 6.45% of 512; nonterminal inventory 6/512 (1.17%).

These figures are a 10-hour partial snapshot only. They do not establish 25-hour M5 lifecycle convergence, FVG long-horizon capacity safety, or a warm-up threshold.

## Incomplete long-horizon trial

The 27h pre-roll + 60m evaluation trial was attempted with compact evidence mode and checkpointing. It did not complete within the available execution window; the last durable checkpoint reached 900 captures of 1,680. This partial run is explicitly excluded from completed-trial and convergence claims. The partial checkpoint is not part of the release evidence package because later code changes invalidate its code hash.

Further runtime profiling indicates the remaining cost is concentrated in repeated full Stage 1–5 validation/evidence materialization and canonical serialization of the large suppressed pre-roll record stream. No strategy logic was bypassed to force completion.

## FVG retention decision

No expiry policy is introduced. The existing engine retains ACTIVE, TOUCHED and PARTIALLY_FILLED FVGs until FILLED. Only terminal FILLED records may be trimmed when capacity pressure requires it. A future retention/expiry change needs an explicit strategy-design decision and calibration evidence.

## Acceptance still outstanding

- Complete at least 25 hours of M5 pre-roll plus a 60-minute evaluation window.
- Compare M5 OB state across longer pre-rolls at identical evaluation timestamps.
- Measure FVG inventory and nonterminal capacity pressure across the complete horizon.
- Verify compact/full evaluation evidence equivalence on a completed real-data trial.
- Do not approve a warm-up policy until those checks pass.
