# Unit 05C — Optional Fixture Intake Contract

## Version and reference identities

- Fixture format: v2 (`reference/pine_smc/reference_fixture.v2.schema.json`).
- Original Pine SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumentation: `DIVATrading Pine Capture Instrumentation v1`.
- Instrumentation patch SHA-256: `4901facc8365692b51397eabc34d232d7de86a78e6f3c28e2eb894df81a160ed`.
- Ready-to-paste full instrumented script SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Removing the exact patch from the full instrumented script recovers the original Pine source byte-for-byte.

## Builder

`build_fixture_from_capture_manifest(manifest_path, output_path)` converts three retained TradingView chart CSV exports into a fixture. It preserves decimal strings, converts timestamps to UTC Unix milliseconds, records raw-export SHA-256/size, and extracts signals only from the M1 export's instrumented plot columns.

The capture CSVs remain external bundle artifacts. The output JSON does not replace them. The original three CSVs must stay beside the fixture (or in the directory passed as `--source-dir`) for independent acceptance.

## Validator

`validate_reference_fixture(fixture_path, source_dir=...)` first validates JSON Schema Draft 2020-12, then checks semantic and provenance invariants:

- exact Pine and instrumentation identity;
- `BINANCE:{symbol}.P` and matching `replay.symbol`;
- UTC capture timestamp, IANA timezone when naive local time parsing is requested;
- warmup input parity;
- exact first/last loaded candle boundaries;
- M1/M5/M15 contiguous, grid-aligned OHLCV and price tick multiples;
- same-capture MTF last-bar alignment;
- valid coverage ordering and complete-negative assertion;
- signal event/OB source times exist on the matching timeframe;
- Pine entry proxy equals event candle close;
- price/score constraints and unique signal identity;
- raw CSV hash, size, candle content and signal content equality.

Acceptance is deliberately fail-closed. Missing raw CSVs, mismatched hashes, an unrecognized ticker, gaps, ambiguous timestamps, off-tick values, invalid OHLC ranges or incomplete negative-coverage claims reject the fixture.

## Security and resource bounds

- CSV files are read from a caller-selected directory; manifest paths must be simple local filenames and resolved paths may not escape the directory.
- CSV parsing uses the standard library and does not execute macros or formulas.
- Fixture schema caps each timeframe at 100,000 bars; oversized inputs are rejected before strategy use.
- Source file hashing uses 1 MiB streaming chunks.
- This unit performs no network access, API signing, database writes, strategy calculations, or order actions.

## Status semantics

A validator report with `accepted=true` means that the fixture's structure, semantic consistency and retained-source provenance passed. It does not prove that TradingView's server, Pine runtime or indicator code produced valid signals beyond the exact captured artifacts. The operator still attests the chart identity, effective inputs, full loaded history and signal coverage.

No user TradingView CSV was present in the development workspace. No real reference fixture has been accepted in this checkpoint.


## Relationship to Unit 05D

This CSV-based v2 intake remains available for users who have a supported TradingView chart-data export feature. It is not required to translate audited Pine expressions into source-derived Python components, and it must not be treated as a reason to upgrade a TradingView plan. Unit 05D may proceed with bounded source-derived tests. Independent TradingView spot checks/full fixture evidence remains necessary before declaring measured parity for the corresponding runtime behavior.
