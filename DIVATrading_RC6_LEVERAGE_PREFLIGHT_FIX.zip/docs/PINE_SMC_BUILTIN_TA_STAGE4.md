# Unit 05D — Pine Built-in TA Pre-roll and Volatility Regime (Stage 4)

## Status and source identity

- Release: `0.21.0`.
- Parent release: Unit 05D Stages 1–3, v0.20.0; ZIP SHA-256 `0c737d715f40ee6a0de4c59299cad3555816795a69dcbea397ec6b51cc8a1422`.
- Original Pine v6 SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented Pine SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Pine source calls: `ta.atr(14)`, `ta.rsi(close, 14)`, `ta.sma(volume, 20)`, `ta.dmi(14, 14)` and the ATR-ratio regime expressions at lines 344–353. Effective volatility inputs are at lines 45–49. The custom `atr200` state update occurs later, at lines 355–366.

## Implemented components

New module: `src/divatrading/strategy/pine_builtin_ta.py`.

The `PineBuiltinTAEngine` advances on every input source candle, including bars before the SMC `startIndex`. It is streaming and retains only bounded RMA state and a 20-volume deque. The structure replay retains indicator outputs only on the SMC in-window trace, but its indicator values already include the complete loaded prefix.

### 1. ATR(14)

- True Range is `max(high-low, abs(high-previousClose), abs(low-previousClose))` when a previous close exists.
- On the first loaded source bar, the `ta.tr(true)` fallback is `high-low`.
- `ta.atr(14)` is represented as Wilder RMA(14) of that True Range sequence.
- The initial RMA is the arithmetic mean of the first 14 non-`na` TR samples; subsequent values use `alpha=1/14` and `RMA[t] = alpha*TR[t] + (1-alpha)*RMA[t-1]`.

### 2. RSI(14)

- Uses the TradingView documented long-form equivalent of `ta.rsi(close,14)`: close change, non-negative gain, non-negative loss, separate RMA(14) averages, then `100 - 100/(1 + averageGain/averageLoss)`.
- On the first loaded bar, `change(close)` is `na`. Under Pine v6, comparisons involving `na` return `false`; both ternary expressions therefore contribute `0.0` to the initial gain/loss seed, matching the documented expression.
- The first RMA seed and first RSI output can therefore occur at source index 13, after 14 gain/loss samples.
- When average loss is zero and average gain is positive, RSI is 100. When average gain is zero and average loss is positive, RSI is 0. When both are zero, the relative-strength division is `0/0`, so RSI remains unavailable (`na` / Python `None`).

### 3. SMA(volume,20)

- Uses the last 20 source-bar volumes, including the current bar.
- The first 19 bars are unavailable; the first value appears at source index 19.
- The rolling state is bounded to 20 values.

### 4. DMI(14,14)

- Directional movement follows the strict Wilder comparison: `upMove = high - previousHigh`, `downMove = previousLow - low`; `+DM` is `upMove` only when it is positive and strictly greater than `downMove`; `-DM` is `downMove` only when positive and strictly greater than `upMove`. Equal positive moves produce zero for both.
- DMI uses `ta.tr` semantics, not `ta.tr(true)`: True Range, `+DM` and `-DM` are unavailable on the first source bar because no previous candle exists.
- Separate RMA(14) streams smooth TR, +DM and -DM. DI is `100 * smoothedDM / smoothedTR`; unavailable DI values follow Pine's `fixnan` carry-forward behavior.
- DX is `abs(+DI - -DI) / ((+DI + -DI) == 0 ? 1 : (+DI + -DI))`. ADX is `100 * RMA(DX,14)`.
- With the first DMI input bar unavailable, the 14th valid TR/DM sample is source index 14. The first DI and DX are available there; the first ADX seed is available at source index 27 after 14 DX values.

## Full-history pre-roll versus SMC reset

- Pine evaluates the built-in TA calls before the `if inWarmupWindow` block, so ATR(14), RSI(14), SMA(20) and DMI(14,14) do not reset at `startIndex`.
- `PineBuiltinTAEngine.update()` therefore runs for every loaded candle. The existing SMC ATR(200), pivot, structure and OB/FVG state still reset independently at `startIndex=max(0,last_bar_index-warmupBars+1)`.
- A changed prefix before `startIndex` must change TA values when mathematically relevant, while leaving the reset SMC state unchanged. This separation is explicitly tested.

## ATR ratio and volatility flags

The source evaluates these expressions before updating the current bar's custom ATR(200):

- `atrRatioNow = atr200 > 0 ? atrFastNow / atr200 : 1.0`.
- `volatilityExtreme = useVolatilityRegime and atrRatioNow >= extremeVolRatio`.
- `volatilityChoppy = useVolatilityRegime and atrRatioNow > lowVolRatio and atrRatioNow < highVolRatio and adxNow < choppyAdxMax`.

Accordingly, the trace records `atr200_ratio_base`, the ATR(200) value visible before the current bar update. On the SMC reset bar the base is 0 and the source fallback produces ratio 1.0. If ATR(200) is positive but ATR(14) is unavailable, the ratio remains unavailable and both flags evaluate false. The threshold operators remain inclusive for extreme and strict on both choppy ratio bounds and the ADX threshold.

## API and trace

- `PineSmcIndicatorTrace` is immutable and exported from `divatrading.strategy`.
- Numeric indicator values preserve unavailable Pine values as Python `None`, serialized as JSON `null`.
- `PineSmcBarTrace.indicators` records ATR(14), RSI(14), SMA(volume,20), +DI, -DI, ADX, ATR(200) ratio base, ATR ratio and both regime flags.
- `PineSmcStructureReplayResult` records the effective volatility-regime input values used in the replay.
- No SQLite schema change or migration is required.

## Stage-4 deterministic tests

Fourteen focused tests cover first-valid indices, rising and falling RSI, flat RSI `0/0`, ATR gap handling, SMA rolling updates, bullish/bearish/tied DMI movement, DI/ADX seed points, full-prefix pre-roll, previous-bar ATR(200) ratio, volatility gate thresholds, unavailable JSON values, immutability and input validation. Full Stage 1–4 focused tests total 46.

These are source-derived implementation tests, not independent TradingView runtime parity observations. No accepted real TradingView spot check or complete fixture is claimed by this stage.

## Stage-4 exclusions

No newest-first OB candidate selection, age/freshness/trend/premium-discount/FVG/regime candidate gates, rejection/structure trigger, sweep, scoring, signal emission, one-source-bar shift, MTF arbitration, Dynamic Entry/SL/TP, position management, CVD/order-flow integration, Telegram/dashboard, private API or order execution is introduced. SQLite remains schema v5.

## References

- TradingView RSI calculation and Pine long-form equivalent: https://www.tradingview.com/support/solutions/43000502338-relative-strength-index-rsi/
- TradingView ATR example using `ta.rma(ta.tr(true),14)`: https://www.tradingview.com/support/solutions/43000734653-how-are-adr-and-atr-calculated/
- TradingView DMI definitions and directional-movement formulas: https://www.tradingview.com/support/solutions/43000502250-directional-movement-dmi/
- Pine v6 `na` comparisons and Boolean behavior: https://www.tradingview.com/pine-script-docs/faq/variables-and-operators/
