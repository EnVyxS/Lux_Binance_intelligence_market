# Unit 05A — Strategy-Facing Market-Data Snapshot Guide

## Scope

`StrategyMarketDataAdapter` builds a single immutable, read-only snapshot for one exact Binance USDⓈ-M contract symbol. It is an adapter over source services, not a market-data collector. It performs no network or database I/O, creates no background tasks, holds no mutable cache, does not calculate SMC, and cannot place or manage orders.

Default required candle intervals are `1m`, `5m`, and `15m`. The adapter accepts at most one input series per configured interval and at most 500 candles per interval by default (configurable, hard maximum 2,000). Closed candles and a live forming candle are separate fields; a forming candle is never inserted into the confirmed `candles` tuple.

## Data sources supplied by the caller

The caller assembles:

- One `KlineSeriesInput` for each required interval, containing chronological, confirmed-closed `Kline` objects, `source_observed_at_ms`, explicit `source_healthy` / `source_complete` flags, and any known missing open times. An optional `MarketKlineEvent` with `is_closed=False` can be supplied separately as `forming_event`.
- The most recently consumed `MarkPriceEvent` plus the feed's current `is_connected` state. The adapter does not read the Mark Price event queue or retain a latest-value cache.
- The per-symbol `MarketDataReadiness` from Unit 04G. It carries Aggregate Trade connection/continuity, Delta/CVD, depth health, absorption evidence, queue health, reconnect generations and reason codes.
- The matching `OrderBookMetrics` captured from the same order-book supervisor. Health and metrics update IDs must agree.

The Kline caller should use the existing bounded `KlineRepository.read_tail()` or `read()` path after the Unit 03D recovery supervisor has confirmed continuity. `source_complete=True` is an assertion from that upstream recovery/health layer; it must not be set merely because a query returned rows.

## Minimal construction example

```python
from divatrading.market_data.strategy_snapshot import (
    KlineSeriesInput,
    StrategyMarketDataAdapter,
)

now_ms = ...  # synchronized UTC epoch milliseconds
klines = []
for interval in ("1m", "5m", "15m"):
    stored = kline_repository.read_tail(
        symbol="BTCUSDT", interval=interval, limit=300,
        end_open_time_ms=...,  # last confirmed closed candle only
    )
    klines.append(KlineSeriesInput(
        symbol="BTCUSDT",
        interval=interval,
        candles=tuple(row.kline for row in stored),
        source_observed_at_ms=now_ms,
        source_healthy=kline_recovery.is_ready,
        source_complete=True,  # only after the recovery layer confirms no gaps
    ))

snapshot = StrategyMarketDataAdapter().build_snapshot(
    symbol="BTCUSDT",
    now_ms=now_ms,
    kline_series=tuple(klines),
    mark_price=latest_mark_price_event,
    mark_price_connected=mark_price_feed.is_connected,
    readiness=market_data_orchestrator.health("BTCUSDT"),
    order_book_metrics=order_book_supervisor.metrics("BTCUSDT"),
)

if not snapshot.ready:
    # Preserve the failure reasons; a downstream strategy must not infer READY.
    print(snapshot.status, snapshot.reason_codes)
```

This is an interface example, not a runnable application bootstrap. The caller must keep draining all WebSocket queues continuously and retain latest Mark Price data in its own bounded per-symbol state. Capture `MarketDataReadiness` and depth metrics close together; the adapter fails closed if their update IDs disagree.

## Validation and readiness rules

The adapter raises `StrategyMarketDataInputError` for malformed typed objects, cross-symbol data, unsupported intervals, invalid Decimal values or invalid structural fields. It returns a snapshot with explicit reason codes for incomplete or unhealthy sources.

Kline gates include exact `BINANCE_UM` identity, supported interval alignment, finite Decimal OHLCV, chronological unique candles, no interval gaps, closed-candle timestamps, source completeness, bounded count and freshness. The default maximum age for the latest confirmed candle and source observation is two interval durations.

Mark Price gates include exact symbol, positive finite mark/index prices, finite funding rate, event-time freshness, bounded future skew and an explicitly connected feed.

Flow gates include healthy status, valid continuity, freshness, non-empty trade window, non-negative buy/sell volumes, monotonic aggregate-trade baseline/cursor and Unit 04G's `delta_cvd_ready` flag.

Depth gates include READY health, sequence integrity, fresh event, healthy queue, synchronized metrics, positive two-sided market, finite metrics and matching health/metrics update ID. Absorption evidence must reference the same symbol and, when supplied, the same depth update ID as the metrics.

The global snapshot is `READY` only when every required component is available and passes its gates. `WARMING_UP` and `NO_CANDIDATE` are valid absorption evidence states and do not imply a data-integrity failure. `UNAVAILABLE` absorption, missing sources, stale data, gaps or mismatches fail closed. `UNAVAILABLE` describes a snapshot with no source inputs; otherwise failed readiness is `DEGRADED`.

## Important boundaries

- No SMC structure, BOS/CHoCH, OB/FVG, OB priority, score, entry, SL, TP, MTF arbitration or Pine parity logic exists in this unit.
- No mark-price queue supervisor/latest-value cache is added; that remains caller-owned at this boundary.
- No database migration; SQLite schema remains v5.
- No CLI activation, Telegram/dashboard connection, private API, account state, order placement or live-trading behavior.
- All returned models are frozen dataclasses containing immutable tuples and source dataclasses. Consumers should retain the full snapshot and its `reason_codes` for auditability rather than converting a degraded state into a signal.
