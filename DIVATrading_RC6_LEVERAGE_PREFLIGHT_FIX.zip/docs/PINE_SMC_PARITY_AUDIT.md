# Pine SMC Parity Audit — Unit 05B

## 1. Audited source identity

- Indicator title: `Sniper SMC MTF · EA Matched + Entry Score`.
- Pine language: v6.
- Source length: 905 lines; 62,206 bytes.
- Canonical content SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Library names found: `Sniper_SMC_MTF_Enhanced.pine` and `Sniper_SMC_MTF_Enhanced(1).pine`.
- The two materialized Library files were compared byte-for-byte and have the same SHA-256. They are content-identical copies, not competing revisions.
- The source identifies itself as an indicator port of `SniperSMC_EA_v1.mq5`; the EA source itself was not supplied in this audit, so equivalence to that EA cannot be independently re-verified here.
- The source header attributes Smart Money Concepts [LuxAlgo] and states CC BY-NC-SA 4.0, NonCommercial + ShareAlike. Preserve attribution and license terms. Commercial use or redistribution needs a separate license review; this audit does not grant any additional rights.

The actual Pine text is retained in the user's Library. The release stores this manifest and audit, not a second copy of the source file.

## 2. Input inventory (49 inputs)

Defaults and constraints below are read from the audited Pine source. “Signal” means the value affects the signal/state/levels returned by `f_smc`; “display/alert” does not alter the base candidate decision unless noted.

| # | Input | Default | Role | Notes |
|---:|---|---:|---|---|
| 1 | `showM5Zones` | `true` | Display | M5 OB rendering / signal labels section |
| 2 | `showM15Zones` | `true` | Display | M15 OB rendering / signal labels section |
| 3 | `showM1Zones` | `true` | Display | M1 OB rendering |
| 4 | `showRRBoxes` | `true` | Display | Historical RR rectangles only |
| 5 | `rrHistoryCap` | `35` | Display | Min 5, max 100 |
| 6 | `showSignals` | `true` | Display | Gates marker and visual RR drawing |
| 7 | `showStatus` | `true` | Display | Status table only |
| 8 | `maxDrawZones` | `5` | Display | Min 1, max 20 |
| 9 | `swingLen` | `50` | Signal | Min 2, max 100 |
| 10 | `internalLen` | `5` | Signal | Min 1, max 25 |
| 11 | `mitigateClose` | `false` | Signal | False uses High for bearish / Low for bullish mitigation |
| 12 | `confluenceFilter` | `false` | Signal | Enables exact candle-confluence expression in source |
| 13 | `warmupBars` | `1500` | Signal/state | Min 300, max 2500; rolling start from `last_bar_index` |
| 14 | `fvgMinAtr` | `0.10` | Signal | FVG gap threshold as fraction of custom ATR(200) |
| 15 | `maxAgeM15` | `150` | Signal | M15 maximum OB age |
| 16 | `maxAgeM5` | `300` | Signal | Passed to both M1 and M5 engines |
| 17 | `freshOnly` | `true` | Signal/state | Rejects used OB; also affects M15 nested-child test |
| 18 | `triggerMode` | `Either` | Signal | `Rejection`, `Structure`, `Either` |
| 19 | `structAllowBOS` | `true` | Signal | Allows BOS as well as CHoCH in structure trigger |
| 20 | `minWickPct` | `20.0` | Signal | Min 0, max 100 |
| 21 | `useTrendFilter` | `true` | Signal | Uses swing trend, not internal trend |
| 22 | `usePDFilter` | `true` | Signal | Uses midpoint of tracked swing range |
| 23 | `requireFVG` | `false` | Signal | Requires OB's stored FVG flag |
| 24 | `requireSweep` | `false` | Signal | Requires a directional sweep in `sweepWindow` |
| 25 | `sweepLookback` | `20` | Signal | Min 2, max 100 |
| 26 | `sweepWindow` | `5` | Signal | Min 1, max 20 |
| 27 | `useVolatilityRegime` | `true` | Signal/levels | Gates extreme/choppy; controls high-volatility SL multiplier |
| 28 | `lowVolRatio` | `0.70` | Signal/score | Lower bound for choppy regime; low ratio otherwise affects score |
| 29 | `highVolRatio` | `1.60` | Signal/levels | Upper choppy bound; activates high-volatility SL multiplier |
| 30 | `extremeVolRatio` | `2.40` | Signal | Extreme volatility hard block |
| 31 | `choppyAdxMax` | `16.0` | Signal | Choppy regime ADX threshold |
| 32 | `highVolSLMult` | `1.50` | Levels | Multiplier applied to max(ATR buffer, estimated-spread buffer) |
| 33 | `nestMode` | `Overlap` | MTF arbitration | `Overlap` or `Inside` |
| 34 | `m5Standalone` | `true` | MTF arbitration | Allows M5 only when no new M15 signal on this evaluation and M5 has no M15 parent |
| 35 | `slBufferAtr` | `0.10` | Levels | ATR(14) multiplier |
| 36 | `slSpreadMult` | `2.0` | Levels | Multiplier applied to estimated spread price |
| 37 | `maxSLAtr` | `3.0` | Levels | Maximum SL distance in custom ATR(200) units |
| 38 | `maxSpreadSLPct` | `20.0` | Levels | Rejects when estimated spread exceeds this fraction of SL distance |
| 39 | `tpMode` | `Fixed RR` | Levels | `Fixed RR`, `Structure`, `Hybrid OB/Liquidity` |
| 40 | `rr` | `2.0` | Levels | Fixed-RR target and Hybrid fallback; min 0.25, step 0.25 |
| 41 | `minRR` | `1.5` | Levels | Structure gate and Hybrid target/fallback selection |
| 42 | `spreadEstimateTicks` | `0.0` | Levels | Static estimate in symbol ticks; zero disables estimated spread buffer |
| 43 | `minStopTicks` | `1.0` | Levels | Minimum SL distance in symbol ticks |
| 44 | `consumeOBOnSignal` | `true` | Signal/state | Marks OB used after valid indicator signal; explicitly a proxy for EA fill-based consumption |
| 45 | `showIdealEntry` | `true` | Display | Ideal entry band drawing |
| 46 | `showModelScore` | `true` | Display | OB label score text only |
| 47 | `entryDepthNear` | `0.50` | Score/visual output | Near band depth; min 0.20, max 0.75 |
| 48 | `entryDepthDeep` | `0.80` | Score/visual output | Deep band depth; min 0.25, max 0.95; auto-adjusted if <= near depth |
| 49 | `scoreAlertMin` | `70.0` | Alert only | High-score alerts only; does not gate base signals |

## 3. Evaluation state, warmup and indicators

Source map: lines 219–375, 720–735.

- `f_smc()` runs independently inside each `request.security()` timeframe context. Persistent state includes local index, custom ATR(200), parsed candle extremes, swing/internal pivots and trends, range extremes, plus parallel arrays for OB top/bottom, source/break index/time, bias, FVG flag and used flag.
- `startIndex = max(0, last_bar_index - warmupBars + 1)`. At that exact source-context bar, the strategy state and OB arrays are reset. `localIndex` begins at `-1`, then increments to `0` on the first in-window bar.
- Custom ATR(200) uses an arithmetic mean while `localIndex < 200` and then `(previous_atr200 * 199 + true_range) / 200`. True range uses the current high/low and previous close after the first local bar.
- `parsedHigh/parsedLow` normally equal high/low. When candle range is at least `2 * atr200`, they are reversed (`parsedHigh=low`, `parsedLow=high`). These parsed values are used to choose OB candles.
- `ta.atr(14)`, `ta.rsi(close,14)`, `ta.sma(volume,20)`, and `ta.dmi(14,14)` are evaluated on every source bar outside `if inWarmupWindow`. They are not reset with the custom SMC state. Exact replay therefore needs the same pre-roll/history available to those Pine series, not merely 1,500 bars cut at the SMC reset boundary.
- `atrRatioNow = atrFastNow / atr200`, or `1.0` while custom ATR(200) is zero.
- The 1,500 default is applied independently inside M1, M5 and M15 `request.security` contexts. It is 1,500 source bars per timeframe, not one common wall-clock duration.

## 4. Structure and BOS/CHoCH semantics

Source map: lines 377–528.

- Swing and internal legs are detected separately with `swingLen` and `internalLen` delayed comparisons against `high[len]` / `low[len]`. The candidate at offset `len` is rejected if any of the more-recent `len` bars has a high greater-or-equal or low less-or-equal. High-leg detection is checked before low-leg detection. A leg transition records a new pivot and resets its crossed flag.
- Internal bullish break requires a valid, uncrossed internal high; the current close crosses above it while previous close was at or below it; and the source's `extraBull` condition passes. Bearish is symmetric.
- A bullish internal break is CHoCH only when the prior internal trend was bearish; otherwise it is BOS. Bearish is symmetric. `inTrend` then updates.
- `confluenceFilter=false` leaves both candle-side booleans true. When enabled, the exact source expressions are preserved: `a = high - max(close, open)`, `b = min(close, open - low)`, bullish when `a > b`, bearish when `a < b`. Do not replace this with a textbook body/wick rule.
- Internal breaks create OB candidates. Swing breaks only update `swTrend`; they do not create OBs. The swing trend is later used by the trend filter and scoring.
- Swing range extrema `trTop` / `trBot` are initialized by new swing pivots and subsequently updated when price exceeds them. Premium/discount filtering compares OB midpoint to `(trTop+trBot)/2` only when both extrema are valid and `trTop > trBot`.

## 5. OB construction, FVG, mitigation and priority

Source map: lines 450–520, 530–571, 612–718.

- On bullish internal break, scan bars between the internal pivot and break, excluding the break bar, and select the offset with the smallest `parsedLow`; OB bounds are max/min of that parsed candle. Bearish selects the largest `parsedHigh`. Strict comparisons preserve the first selected offset on ties.
- FVG is stored as one boolean on the new OB. Bullish tests `low[off-1] - high[off+1]`; bearish tests `low[off+1] - high[off-1]`; a positive gap must also be at least `fvgMinAtr * atr200`. This is not a separate FVG-zone priority list.
- The active OB arrays have a cap of 100. On insertion at capacity, the oldest item is shifted out.
- Mitigation/deletion runs before `FindSignal()`. With `mitigateClose=false`, bearish OB invalidation uses `high > OB top` and bullish uses `low < OB bottom`; with true, both use close. Comparisons are strict.
- `FindSignal()` scans active OBs newest-to-oldest and selects the first candidate passing all gates. There is no explicit numeric OB priority score used to reorder the array. A newer OB can therefore win before an older but higher-scoring OB.
- A candidate is blocked if `freshOnly` and used; on the break bar (`localIndex <= breakIndex`); older than `maxAge`; against swing trend when trend filter enabled; on the wrong side of tracked range equilibrium when PD filter enabled; lacking FVG when required; or in extreme/choppy volatility regime.
- Age is `localIndex - breakIndex`; equal-to-maxAge is allowed, greater-than-maxAge is rejected.
- `consumeOBOnSignal` is set only after a valid signal with accepted SL/TP levels. This Pine indicator marks the OB used on signal, not actual exchange fill. The header tooltip explicitly calls this a proxy because the indicator cannot see broker fill.

## 6. Trigger and sweep rules

Source map: lines 572–610.

- Rejection is evaluated when `triggerMode != Structure` and candle range is positive. Bullish requires low to touch/cross OB top, green candle, close above OB midpoint, and lower-wick percentage at least `minWickPct`. Bearish is the mirrored upper-wick rule.
- Structure trigger is evaluated when `triggerMode != Rejection`, an internal structure event exists after the OB break, and the event extreme reaches through the relevant OB boundary. CHoCH always qualifies; BOS qualifies only when `structAllowBOS=true`.
- When both triggers qualify under `Either`, rejection has priority because `trig = rejection ? 1 : structure ? 2 : 0`.
- If `requireSweep=true`, a separate recent directional sweep must occur inside `sweepWindow`. The tested range for each candidate sweep bar is built from the prior `sweepLookback` bars. Strict new-low/new-high and close-back-through comparisons are used. Sweep does not replace the trigger.

## 7. Volatility and scoring

Source map: lines 45–50, 155–213, 344–353, 568–570, 617–623.

- Extreme regime hard-block: `atrRatio >= extremeVolRatio`.
- Choppy hard-block: `atrRatio > lowVolRatio && atrRatio < highVolRatio && ADX < choppyAdxMax`.
- Low-volatility below `lowVolRatio` is not itself a hard block; it affects the continuous volatility score.
- High-volatility SL buffer multiplier applies when enabled and `atrRatio >= highVolRatio`.
- OB-quality subtotal has 9 components and weights that total 90: displacement 16, source candle 12, volatility 10, RSI 12, trend 12, FVG 8, relative volume 6, freshness 6, sweep 8. The subtotal is divided by 90.
- Timing score is current-candle score 45% and proximity-to-ideal-entry-band 55%.
- Final setup score is 80% OB quality plus 20% timing, clamped to 0–100. It is a heuristic, not a calibrated win probability.
- `scoreAlertMin` is not a signal gate. It only gates “high score” alert conditions.

## 8. Entry proxy, SL and TP semantics

Source map: lines 57–66, 624–684.

- Entry is `close` of the source bar as an indicator proxy. The Pine comment states the EA uses live Ask/Bid; this difference must not be erased in documentation or parity reports.
- Estimated spread price is `spreadEstimateTicks * syminfo.mintick`. Buffer is `max(spreadPrice * slSpreadMult, atrFastNow * slBufferAtr)`, then multiplied by `highVolSLMult` in high-volatility regime when enabled.
- Structural SL is outside the OB: bullish `OB bottom - buffer`, bearish `OB top + buffer`. If its distance is below `minStopTicks * mintick`, it is widened to that minimum.
- Levels fail when SL distance exceeds `maxSLAtr * atr200`, or estimated spread price exceeds `slDist * maxSpreadSLPct / 100`.
- Fixed RR sets target to entry +/- `slDist * rr`. The source does not apply `minRR` as an additional rejection gate in this Fixed RR branch.
- Structure TP uses the tracked swing extreme in the trade direction and requires final RR >= `minRR`.
- Hybrid OB/Liquidity first selects the nearest opposing active OB boundary beyond entry (bearish OB bottom for BUY; bullish OB top for SELL), otherwise tracked structural liquidity. If missing, invalid or below `minRR`, it falls back to fixed RR; it rejects the fallback if it would pass through an intervening opposing OB.
- `entryDepthNear` / `entryDepthDeep` produce an ideal band for scoring/visualization. If deep <= near, source substitutes `min(0.95, near+0.10)`. The band does not replace the `close` entry proxy.
- If SL/TP levels fail, the chosen OB does not produce a signal output and is not marked used.

## 9. MTF request behavior and arbitration

Source map: lines 727–735, 796–808.

- Three independent security contexts are requested: M1, M5 and M15. All use `gaps_off`.
- M1 always requests `lookahead_on` and passes `maxAgeM5` to its `f_smc` call. M5 also passes `maxAgeM5`; M15 passes `maxAgeM15`.
- M5 uses `lookahead_on` when chart timeframe seconds <= 5m, otherwise `lookahead_off`. M15 uses `lookahead_on` when chart timeframe seconds <= 15m, otherwise `lookahead_off`.
- Every field returned from `f_smc` is shifted by one source bar (`[1]`), including signal timestamp, levels, OB data, scores, trend and active-OB CSV. The signal's event timestamp and the bar on which the shifted output becomes visible are distinct and must be represented separately in replay records.
- On chart timeframes above M5/M15, lower-timeframe requests can collapse multiple source bars; the source comment explicitly warns about this. The indicator recommends chart M1.
- A new signal is detected when non-`na` signal time differs from its previous chart-series value.
- Nesting requires same direction, child OB source time >= parent source time, and either overlap (`childTop >= parentBottom && childBottom <= parentTop`) or full containment (`Inside`).
- Arbitration is exact and ordered by booleans: M1 is independent; a new M5 with an M15 parent is `takeM5Nested`; a new M15 is selected only if it has no qualifying active M5 child and M5 nested did not win; M5 standalone requires `m5Standalone`, no new M15 signal on that evaluation, and no M15 parent. Thus simultaneous M15 activity can suppress standalone M5 even if M15 itself is suppressed by a nested child.

## 10. Returned engine output versus rendering

`f_smc()` returns a 24-field tuple per source timeframe: latest bullish OB top/bottom/source time/break time; latest bearish equivalents; signal time/direction/entry/SL/TP/trigger/OB top/bottom/OB source time; setup/quality/timing scores; ideal entry band low/high; swing trend; and active-OB CSV.

Signal-relevant/state outputs: this tuple and the active OB collection used for MTF nesting. Rendering-only sections begin at `f_drawCurrentOBs` (lines 742 onward), `f_markSignal`, `f_drawRR`, status table and `alertcondition` declarations. Label text, colors, tooltip composition, chart boxes, panel state, visual history caps and alert message wording are not signal logic. `scoreAlertMin` affects only extra alert variants.

## 11. Important parity boundaries / unresolved external facts

1. This source is an **indicator**, not a TradingView `strategy()` and not an execution simulator. RR boxes are explicitly visual-only.
2. Its `close` entry and `consumeOBOnSignal` behavior are indicator proxies; a future Binance execution engine must keep fill-based position state distinct and must not alter Pine signal parity to mimic exchange fills.
3. The Pine script comments claim a direct port of an EA, but the referenced MQ5 file is not in this project checkpoint. We cannot independently validate EA-vs-Pine semantics.
4. No trusted TradingView exported signal/OB/time series reference fixture was supplied with the audited source. Therefore no expected signal values are invented and parity is **not yet measured**.
5. No data-source capture of the exact TradingView symbol/ticker, chart timeframe, input overrides, loaded-history boundary, exchange tick size or chart timezone has been supplied. These are required for reference fixture provenance.
6. Pine's source header contains a NonCommercial + ShareAlike license notice. Confirm permissions before any commercial use or redistribution of derivative code.

## 12. Implementation and parity gates

A trusted TradingView fixture is not a prerequisite for translating explicit Pine source expressions into isolated, source-derived implementation slices. Unit 05D stages 1–2 implement reset, custom ATR(200), parsed extremes, swing/internal pivot-leg state, internal BOS/CHoCH transitions, swing trend breaks and event-extreme scans using deterministic source-derived tests. This does not prove Pine runtime parity.

Full parity validation remains gated on independent observations from the exact Pine revision, exact Binance USDⓈ-M ticker, chart timeframe, all effective inputs, loaded-history boundary, source timeframe OHLCV, and relevant output fields. Active-OB snapshots are required when OB priority/MTF nesting is being validated. TradingView Basic manual Data Window spot checks can validate only selected timestamps/fields; a complete machine-readable fixture remains optional additional evidence where export is available. No partial sample may be used to assert absence of signals.
