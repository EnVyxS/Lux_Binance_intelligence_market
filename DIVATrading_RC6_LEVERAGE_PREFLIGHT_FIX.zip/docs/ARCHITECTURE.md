> Latest safe candidate: v0.59.0rc3, 2026-11-15. Read [AUDIT_RC3_STATUS_DAN_HANDOFF.md](../AUDIT_RC3_STATUS_DAN_HANDOFF.md) for current status; read [../AUDIT_PROYEK_ID.md](../AUDIT_PROYEK_ID.md) for the source-checked status. Earlier checkpoint descriptions below are historical, not the current implementation inventory. LIVE remains disabled.

# Architecture and Unit Boundaries

The application uses a `src/` package layout. Exchange adapters publish normalized metadata/events; strategy code must not make direct HTTP calls.

```text
src/divatrading/
  core/       configuration, runtime guard, logging, SQLite persistence
  exchange/
    binance/  public REST client, typed metadata models, exact symbol resolver
  market_data/
    klines.py typed Binance Kline record and payload parser
    history.py bounded REST history pagination and gap reporting
    storage.py SQLite Kline repository with exact Decimal persistence
    websocket.py bounded async Binance Kline feed, normalized FORMING/CLOSED events
    mark_price.py bounded async USD-M Mark Price / Index Price / Funding stream
    aggregate_trades.py bounded async USD-M Aggregate Trade stream with taker-side normalization
    aggregate_trade_history.py bounded aggTrades REST parser and ID-range paginator
    aggregate_trade_storage.py SQLite aggTrade repository, durable cursor and gap log
    aggregate_trade_recovery.py aggregate-ID bootstrap and REST gap-recovery coordinator
  orderflow/  delta, CVD, absorption and exhaustion (later unit)
  smc/        Pine-compatible SMC engine (later unit)
  intelligence/ market scoring and optional Kronos adapter (later unit)
  risk/       risk budgets and position sizing (later unit)
  execution/  order state machine and protective orders (later unit)
  trade_manager/ dynamic TP, SL and exit management (later unit)
  telegram/   inline keyboard control plane (later unit)
  dashboard/  local web dashboard (later unit)
```

## Unit 01 implementation

- Immutable settings loaded from `.env` plus process environment overrides.
- Exact Python 3.12.9 / 64-bit runtime validation.
- PAPER-only configuration guard.
- Rotating console/file logging with known-secret redaction.
- SQLite connection-per-operation model, WAL, foreign keys, busy timeout and forward-only schema migrations.
- JSON settings and structured runtime event records.
- CLI commands: `check`, `init-db`, `status`.

## Unit 02 implementation

- Read-only public Binance USDⓈ-M REST client for `GET /fapi/v1/exchangeInfo`.
- Separate connect/read timeouts; bounded retries only for safe GET transport errors, HTTP 429 and HTTP 5xx.
- Typed symbol models with decimal tick/quantity/notional filter values.
- Exact contract-symbol resolver; no base-symbol aliasing or automatic substitution.
- Initial tradable universe restricted to active USDT-quoted, USDT-margined perpetual contracts.
- Unknown filter payloads retained without breaking parsing.
- SQLite schema migration v2 and last-known-good metadata snapshot cache with SHA-256 integrity verification.
- CLI commands: `exchange-info`, `instruments`.
- No private endpoints, signing, order placement or cancellation functions.

## Unit 03A implementation

- Public read-only `GET /fapi/v1/klines` transport method.
- M1/M5/M15 immutable Kline record with Decimal values, UTC timestamps and endpoint identity.
- Bounded REST pagination with cursor advancement by one interval beyond the last open time.
- Default page limit 499 to stay below the documented 500-row request-weight tier, 20 pages per collection and 100 ms inter-page pacing.
- Explicit incomplete result/resume cursor when the page cap is reached.
- Missing intervals between returned candles are reported, not backfilled or synthesized in this checkpoint.
- Kline candle model remains independent of storage and feed transport.

## Unit 03B implementation

- Forward-only SQLite migration v3 creates `market_klines`.
- Candle identity is `(exchange, symbol, interval, open_time_ms)`.
- `KlineRepository` provides atomic UPSERT, bounded ascending reads, exact-key existence and batch open-time existence checks.
- OHLCV and taker-volume fields are stored as decimal strings in `TEXT` columns and reconstructed as `Decimal`.
- Persistence audit fields include source endpoint, first-seen UTC, last-fetched UTC and last-saved UTC.
- No WebSocket, Mark Price, order-flow feed or trading execution was added.

## State and recovery policy

SQLite is the durable local source for configuration, metadata snapshots and event history. Future exchange order/position state must always be reconciled against Binance on process start and after stream recovery; local database records are not authoritative over exchange state.

## Module boundary rule

Exchange adapters publish normalized events. Strategy code must not make direct HTTP calls. Strategy decisions emit intents; only the execution subsystem may translate validated intents into exchange orders. This boundary prevents model/strategy code from bypassing risk checks.

## Unit 03C implementation

- Public USDⓈ-M Kline stream uses the post-migration market endpoint `wss://fstream.binance.com/market/stream`; stream names use lowercase symbols such as `btcusdt@kline_1m`.
- The feed sends one `SUBSCRIBE` request containing only the explicitly configured contract symbols and `1m`, `5m`, and/or `15m` intervals.
- Combined-stream envelopes and raw event payloads are accepted; event identity and Decimal OHLCV values are normalized through the shared `Kline` model.
- Binance `k.x` is mapped to explicit `FORMING` (`false`) or `CLOSED` (`true`) event status. Strategy consumers must use CLOSED events for candle-confirmed SMC decisions.
- Default subscription cap is 48 streams; configurable hard cap is 128. Event queue defaults to 2,048 entries with a hard cap of 8,192; queue overflow raises an explicit error rather than dropping updates silently.
- WebSocket library buffers are capped at 16 frames and 64 KiB per message. Reconnect attempts use bounded exponential backoff and resubscribe using the same validated stream set.
- Disconnect gap reconciliation remains Unit 03D; Mark Price remains Unit 03E. No live connection is exercised by automated tests.

## Unit 03D implementation

- `storage.py` adds indexed, bounded `read_tail()` and `earliest_open_time_ms()` accessors; no schema change is required.
- `recovery.py` reconciles configured WebSocket streams with the existing historical REST paginator and SQLite repository.
- Each stream must be registered. If it has no stored candles, a caller-supplied interval-aligned bootstrap start is mandatory; the service never guesses the amount of history to download.
- The supervisor calls `observe_websocket_feed(feed)`. It uses both `feed.is_connected` and successful `feed.stats.connection_count`, so an internal reconnect invalidates readiness even if a fast disconnect was missed by polling.
- Backfill detects bootstrap-leading, internal and trailing gaps, uses inclusive UTC millisecond bounds and keeps its per-pass candle budget below the bounded audit window so the preceding anchor remains available on the next pass.
- A REST candle is persisted only when `close_time_ms < now_ms`; an absent candle remains an explicit unresolved gap, not a synthetic record.
- CLOSED WebSocket events can be persisted only after earlier gaps recover. FORMING events are ignored.
- Global readiness is true only when the feed is connected and every registered `(symbol, interval)` stream is HEALTHY. A disconnect or reconnect returns streams to RECOVERING.
- Recovery APIs are synchronous and should be run serially by one market-data worker; do not run concurrent recoveries for the same stream. A future asynchronous supervisor must keep draining the bounded WebSocket queue while backfill is performed on a serialized worker.
- Recovery status is runtime state, not a separate durable migration; after process restart, initialize the service and perform a fresh reconciliation before strategy readiness.


## Unit 03E implementation

- `mark_price.py` provides a dedicated per-symbol Binance USDⓈ-M Mark Price stream using `wss://fstream.binance.com/market/stream`.
- The stream set is exact and configured by symbol, using `<symbol>@markPrice@1s` or `<symbol>@markPrice@3s`; the all-market `!markPrice@arr` stream is not used.
- `MarkPriceEvent` keeps Mark Price, Index Price, Funding Rate, estimated settlement price, Mark Price moving average and timestamps separately from the Kline model and last trade price. Monetary/rate values use `Decimal`.
- If the post-migration symbol type field is present, only `st=1` is accepted; COIN-M events are rejected.
- The feed has bounded subscriptions (48 default / 128 hard cap), a bounded event queue (2,048 default / 8,192 hard cap), capped WebSocket message/frame buffers, bounded reconnect backoff and exact resubscription.
- Events older than 10 seconds or more than 5 seconds ahead of the local clock are rejected as stale; duplicate or out-of-order event timestamps per symbol are skipped and counted.
- Queue overflow is an explicit fatal error; messages are not silently dropped. Graceful shutdown uses an asyncio stop event.
- The module does not persist Mark Price snapshots or connect to private endpoints. Automated tests use fixtures and an injected connector; no live Binance session was opened.


## Unit 04A implementation

- `aggregate_trades.py` adds a dedicated public USDⓈ-M `<symbol>@aggTrade` feed using routed market stream endpoint `wss://fstream.binance.com/market/ws` and explicit `SUBSCRIBE` messages.
- Exact selected symbols only; default subscription cap 16 / hard cap 48. No all-market subscription.
- `AggregateTradeEvent` keeps aggregate ID, first/last underlying trade IDs, event/trade timestamps, price and base quantity. Monetary values use `Decimal`; times and IDs remain integer values with UTC timestamp properties.
- `buyer_is_maker` maps to taker aggressor direction: `true` = SELL aggressor and negative signed volume; `false` = BUY aggressor and positive signed volume. Quote quantity is derived from price × base quantity.
- Duplicate and out-of-order aggregate IDs are skipped per symbol. Forward ID gaps are explicitly attached to the next normalized event and counted; Unit 04A does not repair gaps. Downstream flow calculations must not bridge a gap without a later reconciliation step.
- Event/trade timestamps are freshness-checked; reconnect uses bounded exponential backoff; exact symbol subscriptions are resent after reconnect; graceful stop and explicit bounded-queue overflow errors are implemented.
- Default queue 8,192 / hard cap 32,768; WebSocket frame and message buffers remain bounded. Consumer must continuously drain events.
- No aggregate-trade persistence, REST gap recovery, Delta/CVD windows, depth, absorption, private API or order execution was added.


## Unit 04B implementation

- `aggregate_trade_history.py` parses REST `/fapi/v1/aggTrades` rows as `Decimal`, retains `q` and optional RPI-excluding `nq` separately, and paginates inclusive `fromId` ID ranges with a hard per-pass limit.
- `aggregate_trade_storage.py` persists `(BINANCE_UM, symbol, aggregate_trade_id)` identities in SQLite schema v4. Immutable payload conflict is rejected; repeated REST/WebSocket identity is idempotent and can enrich optional metadata.
- A durable per-symbol cursor advances only over a gap-free sequence. Observed future IDs are stored but keep state DEGRADED until missing IDs are reconciled. Gap history is audited in SQLite.
- `aggregate_trade_recovery.py` establishes a deliberate latest-page baseline, accepts normalized live events, and fills only missing IDs retrieved through REST. Binance's documented recent-history boundary is 48 hours; unavailable IDs remain unresolved.
- Explicit `prune_oldest()` retention only operates while stream continuity is HEALTHY. No automatic deletion, Delta/CVD, order-book depth or execution is part of this unit.
- REST and SQLite recovery are synchronous; the future supervisor must serialize recoveries and keep draining WebSocket events in a separate bounded consumer.


## Unit 04C implementation

- `order_flow.py` derives BUY/SELL base and quote volume, Delta, cumulative CVD and rolling volume imbalance from Unit 04B's persisted Aggregate Trade records.
- Taker-side mapping follows `buyer_is_maker`: `false` is BUY aggression and positive signed volume; `true` is SELL aggression and negative signed volume. Uses total `q`; optional REST `nq` is not used for the live-consistent measure.
- SQLite schema v5 adds durable `order_flow_state` and `order_flow_buckets`, using decimal text for all monetary/volume values. Cursor and bucket updates commit atomically.
- Default epoch-aligned UTC buckets are `1s`, `5s`, `15s`, `1m`, `5m`; each service instance may select a smaller set. Per-call processing is bounded to 5,000 records; rolling reads are capped at 1,440 buckets.
- The initial CVD baseline is the earliest raw Aggregate Trade currently retained locally; CVD starts at zero immediately before that ID. This is not full exchange history, day/session CVD or lifetime CVD.
- Processing reads only through Unit 04B's durable contiguous aggregate-ID cursor. DEGRADED sources process only their safe prefix; UNRESOLVED sources remain invalid and never get bridged. A missing retained row or regressing trade timestamp makes derived flow UNRESOLVED.
- `is_fresh` is separate from sequence integrity; default max trade age is 10 seconds with 5 seconds future skew. Consumers must check both as appropriate.
- `reset_for_replay()` clears derived order-flow state only and replays retained raw trades; replay requires source HEALTHY. No raw trade history is recreated after pruning.
- The service is synchronous and not yet wired into a background supervisor, Telegram or dashboard. Serialize processing per symbol and continue draining the Aggregate Trade feed during REST recovery.
- No order-book depth, absorption/exhaustion, SMC strategy modification, scoring, Kronos, Telegram, dashboard, private account endpoint or order execution is included.


## Unit 04E — Order-book runtime supervision

`BinanceOrderBookSupervisor` is the caller-managed async owner of Unit 04D's depth feed, REST snapshots, per-symbol bounded buffers and local books. It drains the WebSocket queue while REST snapshots run in worker threads, serializes snapshot calls across symbols, tracks feed connection generations, and invalidates all affected books on reconnect or feed failure. A symbol is ready only when connection, snapshot bridge, Futures sequence, event freshness and queue-health gates all pass. Invalid books resynchronize from a new snapshot; stale metrics are never served as ready data. Depth diffs/snapshots are not persisted because no historical depth consumer or retention policy exists. SQLite remains schema v5. The service is not started by the default CLI and is not connected to strategy execution.
