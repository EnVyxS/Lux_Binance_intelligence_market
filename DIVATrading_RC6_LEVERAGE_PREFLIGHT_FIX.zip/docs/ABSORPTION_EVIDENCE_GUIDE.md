# Unit 04F — Depth–Aggressor Flow Alignment & Absorption Candidates

## Purpose and safety boundary

`DepthAggressorAlignmentService` is a read-only evidence layer. It aligns Unit 04C's continuity-aware Delta/CVD snapshot with Unit 04E's supervised, synchronized depth metrics. It reports **candidates**, not confirmed absorption, hidden liquidity, participant intent, spoofing, or guaranteed reversals.

No Pine-compatible SMC conditions, OB/FVG priority, scoring, entry/SL/TP, Telegram, dashboard, private endpoint, or execution behavior is changed. SQLite remains schema v5; no depth or evidence persistence is added.

## Input contract

For each selected exact symbol, call `observe()` from one serialized market-data worker with:

- `OrderFlowSnapshot`: `status == HEALTHY`, `continuity_valid`, `is_fresh`, non-empty trade window, last trade time, CVD quote and latest bucket Delta/BUY/SELL quote volume.
- `OrderBookSymbolHealth`: `ready`, `sequence_integrity`, `event_fresh`, `queue_healthy`.
- `OrderBookMetrics`: synchronized book, matching symbol and matching update ID to the health snapshot, positive two-sided depth and uncrossed best bid/ask.
- `observed_at_ms`: caller's UTC epoch milliseconds.

The flow trade timestamp and depth event timestamp must be within `max_input_skew_ms`. Source ages are checked independently. Any failed readiness, freshness, continuity, timestamp or book-integrity gate returns `UNAVAILABLE` and clears the symbol's evidence window.

## Window and bounded resources

Defaults:

| Setting | Default |
|---|---:|
| Rolling window | 5,000 ms |
| Minimum observation span | 3,000 ms |
| Maximum gap between samples | 2,000 ms |
| Maximum flow/depth timestamp skew | 3,000 ms |
| Maximum flow age | 10,000 ms |
| Maximum depth age | 3,000 ms |
| Minimum absolute net CVD quote change | 1,000 quote units |
| Maximum directional price progress | 2 bps |
| Minimum opposing displayed-depth ratio | 0.80 |
| Samples per symbol | 120 |
| Symbols | 32 |

All thresholds are configurable through `AbsorptionConfig`. Samples and symbol windows are bounded. A sample gap, clock regression, source timestamp regression, update-ID regression or invalid source resets continuity. Call `reset_symbol()` on aggregate-trade reconnect/continuity reset as well as any upstream lifecycle reset not otherwise visible to this service.

## Candidate rules

- **BUY aggression at ask:** CVD quote change is positive and latest bucket Delta is positive. Directional price progress is measured upward from the first to last mid-price. Candidate requires net aggression above threshold, limited upward price progress, and ask depth that either remained above the configured minimum ratio or recovered to at least its starting value after a dip.
- **SELL aggression at bid:** symmetric logic using negative CVD change/latest Delta, downward price progress, and bid depth persistence/replenishment.

Depth persistence uses the minimum observed top-N displayed depth divided by starting opposing depth. Replenishment requires the ending opposing depth to recover to at least its starting value after a measured dip. This is only observed displayed-liquidity behavior; it does not prove the same orders remained or were replenished by the same participant.

The current `OrderFlowSnapshot` BUY/SELL quote volumes are emitted as the latest configured flow-window context. They are not summed across samples because those snapshots can overlap. Net flow over the evidence window is measured by the difference in cumulative quote CVD between its first and last samples.

## Output states

- `UNAVAILABLE`: one or more input/readiness/freshness/continuity gates failed. No inference is emitted.
- `WARMING_UP`: valid samples exist but the minimum observation span has not been reached.
- `NO_CANDIDATE`: window is valid but directional flow, price response or opposing depth behavior does not satisfy the configured criteria.
- `CANDIDATE`: measured conditions align with a possible absorption event. `reason_codes` and raw measurements explain why.

The `absorbed_aggressor` field refers to the aggressive side potentially being absorbed (BUY at ask or SELL at bid); it is not a trade direction or an instruction to enter a position.

## Example

```python
from divatrading.market_data import DepthAggressorAlignmentService

alignment = DepthAggressorAlignmentService()
# In the serialized market-data worker, after processing a complete Delta/CVD
# batch and obtaining READY depth health + metrics for the same symbol:
evidence = alignment.observe(
    symbol="BTCUSDT",
    flow=delta_cvd_service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1),
    book_health=depth_supervisor.health("BTCUSDT"),
    book=depth_supervisor.metrics("BTCUSDT"),
    observed_at_ms=clock_ms(),
)
if evidence.status == "CANDIDATE":
    # Publish/store as an evidence event in a future integration unit.
    # Do not treat this as an entry signal.
    print(evidence.reason_codes, evidence.cvd_change_quote, evidence.price_progress_bps)
```

The service is caller-managed and is not wired into a background supervisor, Telegram, dashboard or strategy execution in Unit 04F.
