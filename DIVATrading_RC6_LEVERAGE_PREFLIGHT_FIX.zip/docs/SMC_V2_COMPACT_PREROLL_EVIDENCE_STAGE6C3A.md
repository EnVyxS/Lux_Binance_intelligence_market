# SMC V2 Compact Pre-roll Evidence — Stage 6C.3A

## Purpose

Reduce verbose replay-ledger output during pre-roll without skipping any source candle, engine invocation, state transition, gap check, or deterministic evidence record generation.

## Contract

- `ReplayConfig.evidence_start_time_ms=None` preserves the prior full-ledger behavior.
- When configured, every candle/capture before the UTC epoch-millisecond boundary is still processed through Stages 1–5 in chronological order.
- Verbose evidence rows for captures strictly before the boundary are omitted from the output ledger.
- Every omitted record is canonical-JSON serialized with a trailing LF and fed to a SHA-256 digest. The final summary stores both `suppressed_pre_roll_record_count` and `suppressed_pre_roll_records_sha256`.
- Header stores `evidence_mode` and `evidence_start_time_ms`; the boundary is part of ReplayConfig, config hash and replay identity.
- The source-file paths, row counts and SHA-256 values remain in the header. The manifest still validates the complete source files.
- Evaluation-window records retain the same strategy payloads as full-ledger replay. Run/capture identifiers differ because compact and full configurations have different deterministic run identities.
- Checkpoint resume reconstructs state from dataset start, recomputes the suppressed-record digest, verifies the existing ledger prefix and continues deterministically. No engine state is serialized or trusted from an unverified checkpoint.
- This is an evidence-output mode only. It does not alter Stage 1–5 algorithms or strategy semantics.

## CLI

`replay-run --evidence-start-time-ms <UTC_EPOCH_MILLISECONDS>` enables compact pre-roll output. The value is a UTC capture boundary, not a duration. Omit the flag for full-ledger behavior.

## Validation

Focused tests prove:
1. Compact and full replay produce equal evaluation-window records after removing run/capture identity fields.
2. The compact summary count and digest equal independently regenerated pre-roll records for the compact run identity.
3. Interrupted compact replay plus checkpoint resume is byte-identical to uninterrupted compact replay.
4. Existing full-ledger and checkpoint behavior remains covered by regression tests.

No historical tick-size assertion is upgraded. Current-only exchange metadata remains diagnostic; strict execution replay remains blocked.
