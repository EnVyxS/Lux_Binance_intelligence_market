# SMC V2 Chronological Replay Splits & Evidence Analytics — Stage 6B.2

**Implementation release:** Unit 05E v0.33.0  
**Parent release:** Stage 6B.1 Dataset Quality Auditor v0.32.0  
**Status:** Implemented; verified with synthetic ledger fixtures only.

## Scope and exclusions

Stage 6B.2 adds deterministic chronological labels and descriptive analytics over one complete Stage 6A JSONL replay. It does not change Stage 1–5 strategy behavior or Stage 6A replay scheduling. It is not a calibration optimizer, scoring or qualification engine, trade simulator, execution engine, or profitability test. M1/M5 remain independent and M15 remains advisory-only; no legacy nested M5/M15 arbitration is introduced.

## Chronological split policy

- The fixed target is chronological **60% TRAIN / 20% VALIDATION / 20% TEST**. Shuffling and alternative ratios are not supported in this release.
- All windows are UTC and half-open: `[start_ms, end_ms_exclusive)`. A record exactly at an internal boundary belongs to the following partition.
- Internal cut points are aligned to the least common multiple (LCM) of all active interval durations. Every partition must contain at least one full alignment quantum.
- The Stage 6A clock policy is close-time plus 1 ms. When the last capture's `known_at_time_ms` equals the manifest's `end_open_time_ms_exclusive`, only the final analysis boundary is extended by 1 ms so the final capture is assigned to TEST. Split proportions are calculated against the nominal dataset duration; that extra clock millisecond is not treated as additional elapsed market-data duration.
- The split labels are applied to a single uninterrupted replay. Strategy state and OB/FVG entities are not reset at TRAIN/VALIDATION/TEST boundaries.
- Before evidence aggregation, the analyzer freezes a canonical identity hash over dataset, ledger, code, config, metadata, split plan and analytics schema version. The report labels TEST `OPENED_AFTER_FREEZE`. This is an identity/provenance boundary in the analysis pipeline, not a claim that the underlying dataset was hidden from its operator or that a blind research process was enforced.

## Ledger integrity and memory behavior

`analyze_replay_ledger()` reads an immutable Stage 6A JSONL ledger and fails closed on malformed UTF-8/JSONL, blank lines, invalid schema version, missing or non-terminal run summary, mixed run/dataset/symbol/metadata identity, non-contiguous capture sequence, reordered timestamps, changing known-at time within a capture, duplicate/missing capture summaries, invalid timeframe declarations, or inconsistent capture summary envelope/payload fields. It checks the terminal capture count against the actual capture summaries.

The analyzer records source SHA-256 and byte length, checks them again after analysis to detect concurrent source modification, and never modifies the ledger. Rows are parsed incrementally into a temporary SQLite spool on disk; Python memory use is bounded independently of the total ledger length. Temporary spool data is removed when the analysis completes or fails.

Closed-bar denominators are counted only from `REPLAY_CAPTURE_SUMMARY.payload.updated_intervals`. Snapshot records are not treated as closed bars. Event rates retain event numerator and closed-bar denominator and are reported per 1,000 closed bars. A zero denominator produces a null rate rather than division by zero.

## Evidence metrics

Each partition reports:

- closed bars by active timeframe and descriptive per-1,000-bar event rates;
- Stage 2 BAR_TRACE count, pivot count, BOS/CHoCH/event counts by layer, readiness status and warm-up remaining-bar distributions;
- Stage 3 OB formation outcomes/rejection reason counts and Decimal distributions for displacement measurements;
- Stage 4 unique OB lifecycle snapshots at split end, status/transition/reason counts, age and elapsed-time distributions, touch/mitigation/invalidation/expiry transitions and maximum mitigation depth;
- Stage 5 liquidity reference kinds, liquidity traces, sweep outcomes/qualification, FVG direction/status/fill-ratio and confirmation-to-touch/full-fill elapsed-bar distributions;
- administrative right-censored OB/FVG entity counts at each split end.

Snapshot state is deduplicated by entity identity per partition end, so repeated OB/FVG snapshots do not inflate the number of unique entities. Distributions use exact `Decimal` values and nearest-rank P50/P90/P95; empty distributions carry `n=0` and null statistics. Float values are not accepted as exact Decimal evidence.

OB `CANDIDATE`, `ACTIVE_FRESH`, `TOUCHED` and `MITIGATED` states are counted as right-censored when still present at the split boundary. Non-`FILLED` FVGs are also administratively right-censored. Censoring is a statement that the observation window ended while the entity remained unresolved; it is not expiry, trade failure, loss, fill, or an outcome label.

## API and CLI

Public API from `divatrading.replay`:

```python
from divatrading.replay import analyze_replay_ledger, write_evidence_analytics_report

report = analyze_replay_ledger(r"logs/BTCUSDT-replay.jsonl")
write_evidence_analytics_report(report, r"reports/BTCUSDT-evidence-analytics.json")
```

CLI:

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-analyze `
  --ledger .\logs\BTCUSDT-replay.jsonl `
  --report .\reports\BTCUSDT-evidence-analytics.json
```

The optional `--schema` argument selects a Draft 2020-12 report schema. The bundled default schema is used otherwise. `--split-ratios` exists for explicitness but accepts only the frozen `60/20/20` value. Output is validated and atomically written; the report includes a deterministic `report_sha256` over canonical JSON excluding its own hash field.

## Validation and interpretation limits

Automated tests use synthetic Stage 6A-shaped ledgers to validate chronology, alignment, schema, provenance, immutability, event counts, snapshot deduplication, censoring and fail-closed behavior. This does **not** constitute a real Binance dataset replay, strategy calibration, TradingView parity measurement, or evidence of trading performance. No entry, SL/TP, execution/fill, fee/slippage, trade labels, risk, PnL, win rate, expected value, statistical significance, or profitability outputs are generated.

Stage 6B.3 Warm-up Convergence remains pending. Stage 6C historical calibration must wait until the dataset quality gate and real-data provenance requirements are satisfied.
