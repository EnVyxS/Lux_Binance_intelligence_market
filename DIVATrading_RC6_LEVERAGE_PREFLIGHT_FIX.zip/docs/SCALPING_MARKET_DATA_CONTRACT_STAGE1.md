# SMC V2 — Scalping Market-Data Contract (Unit 05E Stage 1)

## Status

Implemented in software release **0.26.0**. This is a data-contract/readiness adapter only. It does not calculate market structure, OBs, setups, entries, risk, or orders.

## Public API

- `InstrumentSpec`
- `ScalpingMarketDataConfig`
- `ScalpingComponentReadiness`
- `ScalpingReadiness`
- `ScalpingMarketDataView`
- `ScalpingMarketDataAdapter.build_view(...)`
- `AggregateTradeEventFanout`
- `AggregateTradeEventSubscription`

## Instrument metadata

`InstrumentSpec.from_symbol_info()` consumes the exact parsed Binance USDⓈ-M `SymbolInfo` for the requested symbol. It retains contract/status/assets, `PRICE_FILTER` minimum/maximum/tick, `LOT_SIZE`, `MARKET_LOT_SIZE`, notional minimum, order types and TIF values.

`tick_size` is sourced only from `PRICE_FILTER.tickSize`. `pricePrecision` is not a substitute. A missing tick disables the instrument price grid and therefore prevents M1/M5 setup readiness. Off-grid OHLC and best bid/ask are never silently rounded; the affected timeframe or quote readiness is degraded with an explicit reason code.

## Timeframe and readiness policy

- M1 and M5 are separate setup sources. Readiness is evaluated independently for each.
- M15 is optional context. Missing, stale, incomplete, or invalid M15 does not veto valid M1/M5 data.
- M5-on-M1 confirmation readiness requires both a valid M5 setup series and a valid M1 entry-timing series.
- If M1 is not ready, a valid M5 setup may still be discovered; M1 confirmation is unavailable.
- If M5 is not ready, a valid independent M1 setup may still be discovered.
- `ScalpingReadiness.can_scan_setups` is true when the instrument price grid is ready and at least one M1/M5 source is ready. This is source/readiness permission, not proof that a market structure or trade setup exists; the structure engine adds its own warm-up and confirmation requirements.

## Optional context and confluence

Mark Price, Delta/CVD, Order Book depth/imbalance, absorption, and global orchestrator health are retained as individual components. Missing/stale optional data yields `UNAVAILABLE`/`DEGRADED` status and reason codes; it is not converted into a negative confluence signal and does not veto a structurally valid M1/M5 scan.

Order Book data has two downstream roles: optional depth confluence and the current executable bid/ask/spread safety input. `entry_quote_ready` is separate from setup readiness. It requires healthy synchronized depth, matching health/metrics update IDs, freshness, and bid/ask aligned to the exact instrument tick grid. An unavailable quote can block an entry attempt without erasing the underlying setup.

## Aggregate Trade event fan-out

`UnifiedMarketDataOrchestrator` remains the sole owner/consumer of the source Aggregate Trade feed queue. An optional `AggregateTradeEventFanout` can be attached at construction; the collector publishes normalized events to bounded subscriber queues before accepting them into its own persistence/flow-processing queue.

- Subscribers may receive all symbols or filter to one exact symbol.
- Subscriber count defaults to a hard maximum of 32.
- Queue capacity defaults to 2,048 and hard maximum is 8,192 per subscriber.
- Publish is synchronous and preflights all matching subscriber queues. If any is full, the event is delivered to none of them and the orchestrator fails closed with an explicit queue-full error.
- A subscriber must continuously drain its queue and call `task_done()` after processing. Slow consumers are not silently skipped.
- The fan-out carries the original normalized `AggregateTradeEvent`, including aggregate-ID gap metadata. It does not replace durable Aggregate Trade recovery or Delta/CVD processing.

## Resource and safety boundary

No network I/O, SQLite I/O, background task, private endpoint, signing, account query, or order placement is performed by the new strategy adapter/fan-out. Existing public feed/orchestrator lifecycle remains caller-managed. SQLite schema remains v5.

## Validation

Stage 1 adds 27 focused tests: 19 scalping data/instrument/readiness tests, 5 fan-out tests, and 3 orchestrator fan-out integration tests. Full regression suite: 515 passed. Tests use fixture/injected data; they do not constitute live Binance validation. Runtime here: Python 3.13.5 64-bit / Linux. Target Windows 10 / Python 3.12.9 remains pending.
