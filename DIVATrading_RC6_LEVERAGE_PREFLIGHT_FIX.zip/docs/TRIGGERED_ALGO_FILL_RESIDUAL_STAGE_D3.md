# Stage D3 — Triggered Algo Fill & Residual-Quantity Recovery

## Objective

Complete the triggered-protection path deferred by D2. `ALGO_UPDATE` is a wake-up hint; the matching-engine child identified by `actualOrderId`, its final REST order status/`executedQty`, and the REST aggregate position determine the actual residual. The reducer must survive cancel races, out-of-order stream updates, duplicate delivery, disconnects and process restart.

## Trigger recognition and identity

- Accept only `TRIGGERED`, `FINISHED`, `EXECUTED`, or `FILLED` as trigger hints.
- Re-query the exact `clientAlgoId` through signed REST. REST must still report a triggered status and the same non-empty `actualOrderId`.
- Query the child regular order by `actualOrderId`; require exact symbol, order ID, MARKET type, original quantity, closing side, positionSide and compatible One-way/Hedge close flags.
- The initial REST `executedQty` is only an observation. Any stream `aq`/executed quantity is not used for sizing.

## Remainder cancellation and final fill authority

- If the child order is `NEW` or `PARTIALLY_FILLED`, persist `PROTECTIVE_TRIGGER_RECONCILIATION_PENDING` and a cancellation-attempt marker before issuing cancel.
- After cancellation acknowledgement, `-2011`/`-2013`, or an ambiguous transport outcome, query the same `actualOrderId` again. A cancellation timeout does not establish terminal status.
- If the child remains active/nonterminal, retain the durable pending action and entry halt. Restart recovery re-queries it; no new child MARKET order is submitted.
- Require final `executedQty` to be finite, non-negative, no greater than `origQty`, and never lower than the prior REST observation. `FILLED` must equal the original quantity.
- Final residual is `original protective quantity - final REST executedQty`. Expected aggregate exchange quantity is `pre-trigger aggregate quantity - final REST executedQty`; both are checked before local state changes.

## Outcomes

### Partial fill

- Atomically apply the affected lot's residual to lifecycle state and managed-position projection.
- Preserve ACTIVE risk reservation while the lot remains open.
- Replace both quantity-scoped residual STOP/TP protections; verify both through REST before old sibling cancellation/pointer commit completes.
- Keep account entry halt latched pending a fresh full reconciliation.

### Full fill

- Atomically set the affected lot quantity to zero and close its projection.
- Finalize only that signal lot; sibling lots on the same `(symbol, positionSide)` remain open and protected.
- Release risk only after exchange quantity and linked order cleanup are confirmed.

### Zero fill

- The triggered Algo's child order must be terminal with zero `executedQty` (`CANCELED`, `CANCELLED`, `EXPIRED`, or `REJECTED`).
- Reconfirm that exchange aggregate quantity still equals the pre-trigger local group quantity.
- Automatic replacement of the triggered STOP/TP pair is a recovery mutation and is permitted only when `DIVA_ENABLE_PROTECTION_RECOVERY=true` under the existing TESTNET-only configuration gate. It creates/verifies a full replacement pair at unchanged quantity, then marks the parent action confirmed. It never clears entry halt.
- When opt-in is false, no Algo POST/cancel is initiated by the zero-fill branch; the parent remains `PROTECTIVE_TRIGGER_RECONCILIATION_PENDING`, entry halt remains latched, and an operator must resolve the missing protection.

## Stream-gap backfill

- After each private User Data Stream connection, account runtime runs startup fill projection/pending-action recovery, then a REST scan for each OPEN lot's current STOP and TP `clientAlgoId`.
- Only an exact REST-triggered response with `actualOrderId` is routed into the same durable reducer. If REST returns `-2013`, only exact durable stream evidence may be used as fallback; otherwise source state is unverified and the account stays halted.
- This scan does not infer cancellation from an absent open-order listing and does not POST an unverified child order.

## Idempotency and restart

- Parent trigger action ID remains deterministic: `protective-trigger:<signal_id>:<clientAlgoId>`.
- Persist child order identity, original quantity, initial REST executed quantity, pre-trigger group quantity and role before cancellation.
- Persist final REST status/executed quantity/residual before mutating local quantity.
- A restart re-queries Algo and child order. If terminal, it resumes local residual application/protection replacement from the exchange result. A duplicate or late ALGO_UPDATE resolves the same action and cannot create a second action or child order.
- Replacement protection actions retain D2 deterministic IDs and their own query-before-POST/no-blind-retry semantics.

## Safety invariants

- Never size from `ALGO_UPDATE` stream `aq` or a pre-cancel `executedQty` snapshot.
- Never mutate local quantity until terminal child order and REST aggregate position agree.
- Never release risk while exchange quantity remains for the lot.
- Never cancel sibling protections until the complete replacement pair is exact and verified.
- Never clear account entry halt automatically.
- Zero-fill re-protection requires explicit TESTNET-only `DIVA_ENABLE_PROTECTION_RECOVERY` opt-in; default remains false and LIVE rejects the setting.

## Verification scope

Automated tests use local SQLite, fake REST clients and synthetic stream events. They cover partial fill growth during cancel, stale/out-of-order event quantities, zero fill with/without opt-in, full fill, multi-lot sibling accounting, One-way/Hedge semantics, cancel ambiguity/restart, duplicates and REST backfill after stream gap. No real Binance Demo/LIVE order, child-order cancel, or Algo mutation is performed by the build.
