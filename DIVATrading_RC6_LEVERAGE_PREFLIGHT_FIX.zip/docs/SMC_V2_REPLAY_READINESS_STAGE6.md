# SMC V2 — Historical Replay Readiness & Stage 6 Design Review

**Design origin:** Unit 05E Stage 6 design review, v0.30.1  
**Current implementation status:** Stage 6A implemented in v0.31.0  
**Document revision:** 1.1  
**Strategy baseline:** SMC V2 Stages 1–5 from v0.30.0; their detection rules remain unchanged.

## 1. Decision summary

The next implementation should be a **deterministic historical replay harness**. It should not be an evidence-integration layer or candidate-qualification layer yet.

Reason: Stages 1–5 already expose independent, immutable evidence engines. The missing prerequisite is a repeatable chronological driver that feeds exact closed Binance data into those engines, records provenance and outputs, handles data discontinuities, and proves causality. Building qualification or scoring before this exists would make thresholds difficult to audit and calibrate.

Stage 6 itself is design-only. This document does not add runtime behavior, new signals, score weights, entries, simulated fills, risk logic or execution.

### Approved design boundaries

- Binance USDⓈ-M, USDT-margined perpetual contracts only.
- M1 and M5 remain independent structural/setup streams; M5 is the primary setup source, M1 is entry-timing context and may also form independent setups.
- M15 remains optional advisory context. It cannot veto, suppress or arbitrate M1/M5.
- Replay Stage 1–5 evidence only: market-data readiness, confirmed structure, displacement/OB formation, OB lifecycle, liquidity references/sweeps and FVG lifecycle.
- No legacy Unit 05D nested M5/M15 priority.
- No CVD/Depth/Absorption hard gates, scoring/ranking, entry, SL/TP, fee/slippage fill simulation, PnL, position management, private API, live orders, Telegram/dashboard or SQLite schema migration.
- All strategy prices/quantities remain `Decimal`; timestamps remain UTC epoch milliseconds.
- Replay is single-symbol sequential by default and bounded for the target Windows 10 / 8 GB machine.

## 2. Required datasets and data tiers

### 2.1 Tier A — required for Stage 1–5 replay

For each selected symbol, acquire native Binance USDⓈ-M contract Klines:

| Interval | Role | Requirement |
|---|---|---|
| `1m` | Independent M1 structure/OB/evidence and fine chronological clock | Required |
| `5m` | Primary setup structure/OB/evidence | Required |
| `15m` | Soft context only | Optional; absence must not block M1/M5 |

Use the **native exchange Kline series** for each interval. Do not manufacture M5/M15 candles from M1 as a substitute. Cross-timeframe aggregation checks may be run as data-quality diagnostics, but they must not overwrite Binance-native candles or be used to conceal a missing native interval.

Each USDⓈ-M Kline record has the Binance 12-field contract: open time, OHLC, base volume, close time, quote volume, trade count, taker-buy base volume, taker-buy quote volume and the final ignore field. The current `Kline.from_binance_row()` parser already maps these values into typed fields and enforces exact interval close boundaries. Binance documents `/fapi/v1/klines` as the symbol Kline endpoint, with candles uniquely identified by open time and a maximum request limit of 1,500. [Binance USDⓈ-M Kline API](https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data).

Primary acquisition sources:

1. Binance public historical archives at [data.binance.vision](https://data.binance.vision/) for bulk daily/monthly files.
2. USDⓈ-M REST `/fapi/v1/klines` for bounded backfill, range repair and cross-checks.

Archive and REST data must be normalized into the existing 12-field typed Kline contract. Keep the original raw file/row available for audit. Verify the archive checksum where provided and calculate a local SHA-256 for every downloaded archive and normalized data file.

### 2.2 Instrument metadata — required for strict Stage 1–5 eligibility

Capture and preserve the exact USDⓈ-M symbol metadata used to build `InstrumentSpec`, including at least:

- `symbol`, `pair`, `contractType`, `status`, base/quote/margin assets;
- `onboardDate` and `deliveryDate` when supplied;
- exact `PRICE_FILTER.minPrice`, `maxPrice` and `tickSize`;
- `LOT_SIZE`, `MARKET_LOT_SIZE` and notional filters for completeness/future execution work;
- raw `exchangeInfo` response, capture time, source URL and SHA-256.

`PRICE_FILTER.tickSize` is authoritative. `pricePrecision` is not a substitute. Existing Stage 1/3/5 checks require exact tick-grid values and do not silently round.

**Historical metadata limitation:** Binance `/fapi/v1/exchangeInfo` documents current exchange trading rules and symbol information; it is not a historical filter archive. A current `tickSize` therefore cannot automatically be treated as the tick size effective throughout an old replay period. Dataset metadata must carry an explicit quality classification:

- `HISTORICAL_EFFECTIVE`: metadata snapshot/effective interval is known for the replay candle period;
- `CURRENT_SNAPSHOT_ONLY`: only current `exchangeInfo` is available;
- `MISSING_OR_CONFLICTED`: no reliable exact filter or conflicting metadata.

Only `HISTORICAL_EFFECTIVE` is eligible for strict historical calibration of tick-dependent evidence unless an independently verified historical filter record is supplied. `CURRENT_SNAPSHOT_ONLY` may be used for diagnostic exploration only, must be clearly tagged, and must not be presented as historically exact. `MISSING_OR_CONFLICTED` fails closed for full Stage 1–5 replay. Never infer historical tick-size changes from `pricePrecision` or round old OHLC values to fit today's grid.

Source: [Binance USDⓈ-M Exchange Information](https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data) describes current trading rules and symbol information.

### 2.3 Tier B — flow/CVD replay, later scope

When CVD/Delta research is approved, add USDⓈ-M **Aggregate Trades** with:

- aggregate trade ID and first/last underlying trade IDs;
- exact price, total quantity `q`, optional non-RPI quantity `nq`;
- event/trade timestamp and buyer-is-maker/taker direction;
- source file/endpoint, hash, acquisition time and continuity audit.

Binance `/fapi/v1/aggTrades` provides compressed aggregate trades. Same-price, same-taking-side trades within 100 ms are aggregated; RPI quantity is included without a distinct RPI tag. The response distinguishes total quantity `q` from the normal quantity excluding RPI, `nq`. Preserve both fields and freeze which quantity definition is used before any CVD calibration. [Binance Aggregate Trades API](https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data).

Kline taker-buy volumes may be retained as coarse bar-level context, but they are not a substitute for the existing aggregate-trade CVD contract and must not be labelled event-level CVD.

### 2.4 Tier C — historical depth/absorption, later scope

Historical depth/absorption validation requires timestamped L2 snapshots and ordered diff events with the exchange sequence/update identifiers needed to reconstruct a synchronized book. The current project audit found the local book and absorption windows are in-memory and not available as complete durable historical series. Klines or Aggregate Trades alone cannot reconstruct historical queue depth or absorption.

Do not manufacture historical depth/absorption from OHLCV. A future recorder must define snapshot cadence, diff continuity, event timestamps, arrival timestamps, gap/reconnect behavior, retention and checksums before any historical depth claim is made.

Mark Price, funding and other derivatives context are optional independent datasets and are not prerequisites for Stage 1–5 structural replay.

## 3. Symbol and date-window policy

### 3.1 Pilot sequence

1. **Harness smoke test:** one symbol, `BTCUSDT`, 30 consecutive UTC days, all three Kline intervals. This tests ingestion, row counts, replay throughput, gap reporting and output determinism; it is not a calibration sample.
2. **First structural evaluation:** `BTCUSDT`, at least 12 consecutive fully closed UTC calendar months for which the dataset and instrument metadata quality pass.
3. **Cross-symbol robustness:** repeat the frozen evaluation protocol on `ETHUSDT`; only then consider a small, explicitly selected set of liquid USDT perpetuals.

The symbol selector must verify USDⓈ-M, `PERPETUAL`, USDT quote and USDT margin contract identity. Do not silently mix COIN-M, dated delivery contracts, Spot or symbols whose trading lifecycle is not covered by the manifest.

### 3.2 Calibration horizon

Twelve months is the recommended first evidence-distribution sample, not a claim that it is statistically sufficient for profitability. After the harness and metadata checks are proven, target 24 months or more across distinct volatility/liquidity regimes where the same instrument identity and trustworthy metadata coverage exist.

Record explicit UTC `start_open_time_ms`, exclusive `end_open_time_ms`, source availability, symbol onboard date and actual row counts for every interval. Do not assume every symbol existed for the full requested window. A symbol's pre-onboard period is `NOT_LISTED`, not a missing-candle data gap.

Approximate row counts for a 365-day one-symbol dataset are:

| Interval | Approximate rows |
|---|---:|
| M1 | 525,600 |
| M5 | 105,120 |
| M15 | 35,040 |

Use streaming/chunked reads. Do not load every symbol, interval and every row into memory at once.

## 4. Replay input and provenance contract

Stage 6A should add a versioned replay manifest/envelope without weakening the existing typed Kline or V2 adapter contracts.

### 4.1 Dataset manifest — minimum fields

- `manifest_schema_version`;
- `dataset_id` (deterministic identifier derived from canonical manifest content and file hashes);
- exchange `BINANCE_UM`, market type, contract type and symbol;
- interval, UTC timezone, timestamp unit (`MILLISECONDS`), start/end boundaries;
- source kind (`PUBLIC_ARCHIVE` or `REST_API`), source URL/endpoint and acquisition timestamp;
- raw archive/file SHA-256, normalized file SHA-256, checksum verification result, row count;
- first/last open time, first/last close time, expected interval milliseconds;
- duplicate count, conflicting duplicate count, missing interval count/list or bounded gap summary;
- instrument metadata snapshot hash, metadata effective interval and metadata quality class;
- parser/normalizer version and normalization warnings.

A dataset manifest is immutable once a replay run begins. A changed source file, parser version or metadata snapshot creates a new `dataset_id`.

### 4.2 Replay run and capture identity

Use an outer replay envelope because the current `ScalpingMarketDataView` has `captured_at_ms` but no standalone globally unique capture ID. The envelope must include:

- `replay_run_id`;
- `dataset_id` and source file hashes;
- canonical strategy-config hash and code/release version;
- symbol and exact replay-clock timestamp;
- monotonically increasing capture sequence;
- latest included closed Kline identity per interval (`symbol`, `interval`, `open_time_ms`, `close_time_ms`);
- instrument metadata hash;
- deterministic `replay_capture_id` derived from the fields above.

Pass the same immutable `ScalpingMarketDataView` and same `captured_at_ms` to Stages 2–5 for a capture. Existing Stage 3/5 APIs already verify that their Stage-2 result and the view share symbol and capture time. The outer envelope supplies durable identity without pretending the current view has a field it does not have.

### 4.3 Candle contract and closed-bar provenance

- Keep exchange open/close times as integer UTC epoch milliseconds; preserve Binance's inclusive close time.
- For `1m`, `5m`, `15m`, enforce `close_time_ms = open_time_ms + interval_ms - 1` and exact interval-aligned open time.
- Parse numeric values from source text into `Decimal`; never route strategy geometry through binary float.
- Sort strictly by `open_time_ms`; reject conflicting duplicate Kline identities and changed immutable payloads.
- A candle may enter a replay capture only when `close_time_ms < replay_clock_ms`.
- For a capture immediately after a close boundary, set replay clock to `close_time_ms + 1`; never use local wall-clock time as the historical event clock.
- `source_observed_at_ms` in an offline replay represents the simulated replay clock, not actual historical network receipt time. Record that distinction in provenance.
- Keep forming/unclosed bars out of every Stage 1–5 engine.

### 4.4 M1/M5/M15 event scheduling

The runner must use a single UTC chronological clock. On each close boundary it publishes one capture containing all intervals whose candles have closed by that timestamp. For example, when an M1 and M5 candle close at the same UTC instant, both are included in the same capture. M15 is included only after its own close has occurred.

Do not expose a later M5/M15 candle to an earlier M1 replay step. Do not infer M1/M5 nested priority from the schedule. Each timeframe remains an independent state partition; M15 remains advisory-only. Native M5/M15 candles are not replaced by locally resampled M1 bars.

## 5. Deterministic Stage 1–5 processing pipeline

For each capture, the future runner should invoke the existing components in this order:

1. Build and validate `ScalpingMarketDataView` using exact symbol metadata and only closed bars available at the replay clock.
2. `ScalpingMarketStructureEngine.process(view)` — confirmed pivots, BOS/CHoCH and protected structure.
3. `ScalpingOrderBlockFormationEngine.process(structure_result, view)` — displacement evidence and initial OB candidates.
4. `ScalpingOrderBlockLifecycleEngine.process(formation_result, view)` — OB touch/mitigation/invalidation/expiry evidence.
5. `ScalpingLiquidityFVGEngine.process(structure_result, view)` — optional liquidity reference/sweep and FVG evidence.
6. Persist/stream immutable stage outputs and replay audit records to deterministic JSONL.

Stages 3–5 must consume the exact same capture/view as Stage 2 for that iteration. Do not reconstruct a newer view between calls. Do not merge M1 and M5 state or allow M15 to veto them.

If a stage raises a continuity, provenance, capacity or input error, stop the affected replay run/partition and record the failure. Do not silently skip an event, force a reset and continue as though the history were continuous. A restart must replay from a documented checkpoint or from the dataset start, with the same manifest/config hashes.

## 6. Data-gap, correction and warm-up policy

### 6.1 Gaps and corrections

- Never synthesize a missing candle and never forward-fill OHLC.
- A missing interval, duplicate conflict, timestamp discontinuity or revised closed candle is a data-integrity event, not a neutral candle.
- Record exact missing open times or a bounded gap summary, affected timeframe, first detection time and affected replay range.
- Mark only the affected timeframe unavailable; M1 and M5 are independent. M15 failure removes context only.
- Reset only the affected `(symbol, timeframe)` state in every participating stage engine, then rebuild it from a fresh contiguous segment. Until warm-up is satisfied, emit `WARMING_UP`/`UNAVAILABLE` and do not count candidates/evidence as valid.
- Existing Stage-2/4/5 continuity checks and fail-closed behavior remain authoritative. The runner must not bypass them.
- A gap in M1 does not automatically erase valid M5 history, and an M15 gap must never block valid M1/M5 processing.

### 6.2 Warm-up and boundary effects

Minimum mechanical warm-up must cover the active configuration's lookbacks, including pivot left/right windows, displacement leg and OB source lookback, FVG's three-candle formation context and OB age/lifecycle state. Current scaffolding includes swing 3/3, internal 1/1, maximum displacement leg 8, OB source lookback 20, OB max age 300 bars, and FVG three-candle context. These are minimum mechanical constraints, not proof that all long-lived structure history has converged.

Because an unbroken structure pivot may remain relevant beyond a short fixed pre-roll, every experiment must record `warmup_start_ms` and `scored_start_ms`. Run a warm-up convergence check with at least two pre-roll lengths; compare states/events at the scored boundary. If boundary state materially changes, extend pre-roll or mark the affected metrics as boundary-sensitive. Do not claim a universal finite warm-up until tests establish one.

At the end of a dataset, active OBs/FVGs are right-censored at the data boundary. Do not relabel them as expired, invalidated or filled merely because no later candle exists.

## 7. Train / validation / test design

Use chronological, never random, segmentation:

- **Train:** first 60% of the scored UTC interval; explore a bounded parameter grid and report descriptive event distributions.
- **Validation:** next 20%; select/adjust candidate parameter sets. No final performance claim.
- **Test:** final 20%; hold parameters and config hash fixed before opening this segment. Run once for final out-of-sample reporting.

Apply common UTC split boundaries across symbols. Keep a pre-roll before the first scored segment. Replay state must advance causally across split boundaries; a split is an evaluation label, not a reason to reset engine state. For a new parameter configuration, start a new replay from the same manifest and pre-roll so state is reconstructed consistently.

At this stage the outputs are structural evidence, not trade labels, so no return/PnL optimization is permitted. When a later stage introduces forward trade-outcome labels, add purge/embargo at least as long as the maximum label/outcome horizon and prevent labels crossing train/validation/test boundaries. The exact embargo cannot be fixed until that future horizon is defined.

## 8. Parameters requiring calibration or stability review

Separate strategy-behavior parameters from resource limits. Resource caps should be tuned for PC stability, not optimized as alpha parameters.

| Stage | Parameter | Current scaffold/default | Review requirement |
|---|---|---:|---|
| 2 | Swing pivot left/right | 3 / 3 bars | Compare event frequency/stability across M1/M5 independently |
| 2 | Internal pivot left/right | 1 / 1 bars | Measure noise vs structural responsiveness |
| 3 | Minimum break body/range ratio | Disabled (`None`) | Explore only explicit bounded candidates |
| 3 | Minimum displacement leg body/range ratio | Disabled (`None`) | Distribution and robustness review |
| 3 | Minimum close extension ticks | Disabled (`None`) | Tick-normalized distribution; requires valid metadata |
| 3 | Minimum/maximum directional leg | 1 / 8 candles | Inspect leg composition and sensitivity |
| 3 | OB source lookback | 20 bars | Inspect source availability and rejected candidates |
| 4 | Invalidation | `WICK` / `STRICT` | Compare explicit alternatives; no implicit Pine inheritance |
| 4 | OB max age | 300 source-timeframe bars | Compare expiry distribution, M1 and M5 independently |
| 5 | Equal-level tolerance | 2 ticks | Compare cluster stability by instrument/tick regime |
| 5 | Sweep qualification | Close-back required | Compare wick, close-through and close-back evidence separately |
| 5 | Internal pivots included | `true` | Measure incremental references/sweeps; no mandatory gate |

FVG minimum gap/ATR threshold remains absent until a defined V2 measurement and calibration method exists. M15 alignment remains advisory. Do not tune memory/history caps to improve apparent strategy statistics.

For every replay, store the full serialized engine configs and a canonical SHA-256 config hash. Each result must be reproducible from `(dataset_id, code version, config hash, replay clock policy)`.

## 9. Evaluation outputs — evidence, not trades

### 9.1 Event-level ledger

Emit immutable JSONL records with common envelope fields:

- `record_schema_version`, `record_type`, `replay_run_id`, `replay_capture_id`, `dataset_id`;
- symbol, timeframe, event/known-at timestamp, source candle open/close times;
- stage, deterministic event/candidate/reference ID, direction and reason codes;
- exact geometry/metrics as decimal strings;
- relevant source identities (pivot IDs, structure event IDs, OB candidate ID, FVG C1/C2/C3 times);
- config hash, code version, instrument metadata hash and input watermark.

Stage record families:

- data readiness/integrity and warm-up state;
- Stage-2 pivots, BOS/CHoCH events and protected landmarks;
- Stage-3 displacement measurements, source-candle choice and OB candidates;
- Stage-4 OB lifecycle transitions/snapshots, touch/depth/invalidation/expiry timestamps;
- Stage-5 liquidity references, sweep evidence/outcome, FVG formation and FVG state transitions.

Stable key ordering and stable decimal formatting are required. Output files are partitioned by replay run, symbol, timeframe and/or month so the 8 GB machine never needs to retain the full ledger in memory.

### 9.2 Summary metrics

Allowed descriptive summaries include:

- bars ingested, valid coverage, gap/revision counts and readiness uptime by timeframe;
- pivot, BOS, CHoCH and protected-landmark counts/rates per 1,000 closed bars;
- displacement and leg metric distributions; candidate and source-candle rejection counts;
- OB lifecycle state counts, age-at-touch/invalidation/expiry distributions and right-censored active count;
- liquidity reference/sweep counts by reference/outcome/direction;
- FVG count, touch/partial/full-fill descriptive counts and right-censored active count;
- warm-up boundary sensitivity, replay runtime, peak memory and output volume.

Do not report trade win rate, expectancy, return, drawdown, fill rate or profitability from these records. An OB touch/mitigation, FVG fill or sweep is not an order fill or trade outcome. Existing Stage-4 records explicitly retain `filled=false` and `consumed=false`.

## 10. Anti-look-ahead and determinism acceptance tests

Stage 6A replay harness is not accepted until these tests pass:

1. **Closed-bar gate:** no candle with `close_time_ms >= replay_clock_ms` reaches an engine.
2. **Causal pivot gate:** a pivot is unavailable on its source/confirmation candle and is available only after confirmation close under the existing strict rule.
3. **Prefix invariance:** replaying a prefix through time `t` produces exactly the same records through `t` as replaying the full dataset and filtering records to `known_at_ms <= t`.
4. **Future perturbation:** modifying/appending candles strictly after `t` cannot change any historical output at or before `t`.
5. **OB formation causality:** an OB candidate cannot be visible before its break candle close; Stage 4 cannot use the break candle as a post-formation touch.
6. **FVG causality:** C1/C2/C3 must be closed before formation; C3 cannot retest its own FVG.
7. **M1/M5 independence:** adding/removing/altering M5 data cannot change M1 outputs, and vice versa, except that malformed shared capture data must fail closed according to the adapter/engine contracts.
8. **M15 advisory isolation:** M15 availability or direction cannot suppress or mutate M1/M5 candidates/evidence.
9. **Timestamp alignment:** M1/M5/M15 bars included at the same replay close boundary have identical capture time; no later interval leaks into earlier captures.
10. **Chunk-size invariance:** replaying the same data with different file chunk sizes and overlapping snapshot sizes yields identical event JSONL and summaries.
11. **Restart invariance:** checkpoint/restart at a valid capture produces the same suffix as uninterrupted replay.
12. **Gap/correction fail-closed:** missing bars, conflicting duplicates and revised previously closed candles are surfaced; no synthetic bar or silent bridge is allowed.
13. **Warm-up partition:** changing the scored split boundary does not reset causal engine state; warm-up outputs are excluded from scored summaries.
14. **Deterministic identity:** the same manifest/config/code produces identical dataset, capture and event IDs and byte-stable JSONL.
15. **Right-censor rule:** end-of-file active OB/FVG records remain active/right-censored; they are not falsely expired or filled.

## 11. Implementation decision and bounded Stage 6A scope

**Chosen next implementation: replay harness.**

Stage 6A should add only:

1. immutable/versioned dataset manifest and validation;
2. archive/REST Kline reader with chunked parsing into existing `Kline` records;
3. exact instrument metadata snapshot intake with metadata quality classification;
4. chronological M1/M5/M15 replay clock and deterministic capture envelope;
5. Stage 1–5 pipeline runner using the existing public engines in fixed order;
6. deterministic event-ledger JSONL and summary manifest;
7. gap segmentation, affected-timeframe reset/warm-up and restartable checkpointing;
8. the anti-look-ahead/determinism tests listed above.

Do **not** add new strategy gates, scoring, candidate qualification, entry/SL/TP, PnL, fills, CVD/depth integration, a database migration, private API or live orders in Stage 6A. The replay harness must first establish reproducible evidence and dataset integrity. Candidate qualification, evidence weighting and trade outcome modelling are separate later decisions.

## 12. References and source notes

1. Binance USDⓈ-M Kline/Candlestick Data: https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
2. Binance USDⓈ-M Exchange Information: https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
3. Binance USDⓈ-M Compressed/Aggregate Trades: https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
4. Binance Public Data archive repository: https://github.com/binance/binance-public-data/blob/master/README.md
5. Binance public archive host: https://data.binance.vision/

API endpoint contracts and archive conventions must be rechecked against the official documentation at implementation time. Synthetic unit tests validate software mechanics only; historical evidence, tick-metadata coverage and live exchange behavior remain separate verification obligations.


## 13. Stage 6A implementation status (v0.31.0)

Stage 6A now implements the bounded deterministic replay harness described above. See `SMC_V2_DETERMINISTIC_REPLAY_STAGE6A.md` for exact API, manifest, CLI, ledger and checkpoint behavior.

Implemented in v0.31.0:

1. Content-addressed dataset manifest and Draft 2020-12 schema, source hash/row/range/instrument validation.
2. Streaming native Binance 12-column CSV/ZIP Kline reader and bounded REST-page adapter.
3. One-snapshot instrument metadata quality enforcement (`HISTORICAL_EFFECTIVE`, diagnostic `CURRENT_SNAPSHOT_ONLY`, or rejected `MISSING_OR_CONFLICTED`).
4. UTC close-time clock, deterministic replay/capture identity and a same-capture Stage 1–5 pipeline.
5. Evidence-only JSONL ledger with source, metadata, config, code and dataset provenance.
6. Bounded rolling history, affected-timeframe gap reset and deterministic restart from a validated JSON checkpoint.
7. Fourteen focused tests covering strict metadata, aligned/full-window boundaries, closed-bar causality, aligned captures, gap isolation, M1/M5 independence, prefix invariance, future perturbation, chunk-size and restart determinism, plus checkpoint-prefix integrity.

The implemented metadata contract is narrower than the full design target: one declared snapshot must cover the entire dataset window. A timeline of multiple historical filter changes is not yet supported. `HISTORICAL_EFFECTIVE` is a caller-supplied declaration; the manifest validates the claim's interval and hash but cannot independently authenticate historical exchange rules.

Stage 6A has been verified against synthetic fixtures and the inherited test suite only. No historical Binance dataset was replayed or calibrated. The next bounded milestone is Stage 6B design/review for warm-up convergence, evaluation partition labels, evidence analytics and real-dataset quality acceptance. Do not add scoring/qualification or trade outcome labels until that protocol is separately approved.
