# Unit 04C — Delta & CVD Aggregation

## Scope and data contract

Unit 04C derives taker-aggressor volume from the persisted Binance USDⓈ-M Aggregate Trade stream. It does not connect directly to Binance; Unit 04A/04B own market-data transport, persistence and continuity recovery.

For each aggregate trade:

- Binance `m=false`: buyer is taker/aggressor → BUY volume; signed base/quote quantity is positive.
- Binance `m=true`: buyer is maker/passive → seller is taker/aggressor → SELL volume; signed base/quote quantity is negative.
- Base volume uses total aggregate quantity `q`.
- Quote volume is exact `price × q` using `Decimal`.
- Optional REST `nq` is retained in raw storage but is not used for Delta/CVD. The live stream does not provide `nq`, so using it would make REST backfill and WebSocket live calculations inconsistent.

This is Aggregate Trade flow. Binance's `aggTrade` stream groups fills; it is not an unaggregated record of every matching-engine match.

## Formulas

Let `q` be base quantity and `p` be price:

```text
BUY base volume  = sum(q where m=false)
SELL base volume = sum(q where m=true)
Delta base       = BUY base volume - SELL base volume

BUY quote volume  = sum(p*q where m=false)
SELL quote volume = sum(p*q where m=true)
Delta quote       = BUY quote volume - SELL quote volume

CVD base(t)  = CVD base(t-1) + signed base quantity(t)
CVD quote(t) = CVD quote(t-1) + signed quote quantity(t)

Imbalance = (BUY volume - SELL volume) / (BUY volume + SELL volume)
```

Imbalance is a ratio in `[-1, +1]`, not a percentage. It is `0` when the selected window has no volume.

## Time buckets and rolling window

Default epoch-aligned UTC bucket intervals: `1s`, `5s`, `15s`, `1m`, `5m`. These may be reduced through `bucket_intervals` to lower SQLite write load. Each accepted aggregate trade updates one bucket per configured interval.

A snapshot's `lookback_buckets` is bounded to `1..1440` and includes the current time bucket plus the preceding buckets. The `Delta` fields in the snapshot describe this rolling time window. `cvd_base` and `cvd_quote` are cumulative since the explicit local baseline, not merely the rolling window.

## Baseline semantics

The first baseline is the earliest Aggregate Trade row currently retained locally when the flow service initializes. CVD starts at zero immediately before that ID and includes that baseline row when processed. It is **not** a claim to represent the entire exchange history, the UTC day, a trading session or the contract's lifetime.

If raw trade retention had already pruned older rows before first initialization, the local CVD baseline begins at the earliest remaining row. Once initialized, cumulative CVD state and buckets are stored in SQLite and survive application restart.

`reset_for_replay()` explicitly clears only the derived order-flow buckets/state and replays raw retained Aggregate Trades from the earliest retained ID. Replay requires the upstream Aggregate Trade stream to be `HEALTHY`. Replay does not restore raw rows that were already pruned.

## Continuity and freshness

The service reads only up to Unit 04B's durable `last_contiguous_aggregate_trade_id`:

- `HEALTHY`: all known raw IDs through the current source cursor have been processed.
- `DEGRADED`: source recovery is incomplete or the flow processor still has a bounded backlog. Only the safe contiguous prefix may be processed.
- `UNRESOLVED`: the source gap cannot be recovered, or a supposedly contiguous persisted row is missing / its trade timestamp regresses. CVD stops; it never bridges the gap.
- `BOOTSTRAPPING`: no usable baseline/contiguous range is ready.

Freshness is a separate field (`is_fresh`, `data_age_ms`). The default max trade age is 10 seconds with a 5-second future clock-skew allowance. A stream can be sequence-continuous but stale because no recent trade arrived. Consumers must gate on both `continuity_valid` and `is_fresh` when freshness is required by the strategy.

## Persistence and bounded processing

SQLite is migrated forward to schema v5:

- `order_flow_state`: per-symbol baseline, processed aggregate ID, cumulative base/quote CVD, latest trade time and integrity status.
- `order_flow_buckets`: exact Decimal BUY/SELL base/quote volume and trade count by symbol/interval/UTC bucket.

`process_available()` processes at most 5,000 aggregate rows per call (default 1,000). `process_until_caught_up()` is also bounded to at most 20 passes. It is safe to call repeatedly; the durable processed cursor prevents duplicate accumulation. The bucket updates and CVD cursor advance in one SQLite transaction.

Serialize processing per symbol. Do not concurrently run order-flow processing and replay for the same symbol. The market-data supervisor must continue draining the bounded Aggregate Trade WebSocket queue while REST recovery is performed by the Unit 04B recovery worker.

## Example

```python
from pathlib import Path
from divatrading.core.database import Database
from divatrading.market_data.aggregate_trade_storage import AggregateTradeRepository
from divatrading.market_data.order_flow import DeltaCvdService, OrderFlowRepository

# Run only after Unit 04B has established a baseline and the stream is reconciled.
db = Database(Path("data/divatrading.db"))
db.initialize()  # applies schema v5
trades = AggregateTradeRepository(db)
flow_repo = OrderFlowRepository(db)
flow = DeltaCvdService(trades, flow_repo)  # defaults: 1s/5s/15s/1m/5m

result = flow.process_until_caught_up(
    symbol="BTCUSDT", max_passes=5, records_per_pass=1000
)
print(result.status, result.last_processed_aggregate_trade_id, result.complete)

snapshot = flow.snapshot(
    symbol="BTCUSDT", interval="1m", lookback_buckets=5
)
print("BUY/SELL base:", snapshot.buy_volume_base, snapshot.sell_volume_base)
print("Delta base/quote:", snapshot.delta_base, snapshot.delta_quote)
print("CVD base/quote:", snapshot.cvd_base, snapshot.cvd_quote)
print("Imbalance:", snapshot.buy_imbalance_base, snapshot.buy_imbalance_quote)
print("Integrity/freshness:", snapshot.status, snapshot.continuity_valid, snapshot.is_fresh)
```

The service is synchronous and is not yet wired into an always-running supervisor, Telegram or dashboard. This checkpoint adds calculations and durable derived-state only; it does not add depth, absorption, SMC changes, scoring, Kronos, risk or order execution.
