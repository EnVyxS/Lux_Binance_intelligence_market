# Unit 04B — Aggregate Trade Persistence & REST Gap Recovery

## Scope

Unit 04B preserves Unit 04A and adds durable trade storage, a per-symbol contiguous aggregate-ID cursor, bounded REST backfill and explicit retention/error states. It does not calculate Delta/CVD, consume order-book depth, detect absorption, run SMC, send Telegram messages, render a dashboard, or place orders.

## Binance endpoint constraints

- REST: `GET https://fapi.binance.com/fapi/v1/aggTrades`.
- `fromId` is inclusive; pagination resumes at `last_aggregate_trade_id + 1`.
- Maximum REST page size is 1,000 (default Binance page size is 500).
- Current Binance documentation reports IP request weight 20 per call and says only aggregate-trade history within the previous 48 hours can be queried.
- Do not send `fromId` together with `startTime`/`endTime`; Binance warns that combining these can cause a response timeout.
- Automated recovery defaults to a maximum of 3 pages per pass (up to 3,000 rows, request weight 60), with 200 ms pacing between pages. A later pass resumes from the persisted cursor.
- Existing REST GET retry handles transport errors, HTTP 429 and HTTP 5xx with bounded attempts.

## Data model and identity

SQLite migration v4 adds:

- `aggregate_trades`: primary key `(exchange, symbol, aggregate_trade_id)`; `exchange` is constrained to `BINANCE_UM`.
- `aggregate_trade_stream_state`: durable latest-observed ID, last-contiguous ID, status and timestamp anchors.
- `aggregate_trade_gaps`: audit log for gaps detected and resolved or marked unavailable.

Price, base quantity and optional normal quantity are persisted as TEXT and reconstructed as `Decimal`. Aggregate IDs and underlying first/last trade IDs remain integers. `first_seen_at_utc`, `last_seen_at_utc`, first/last source kind and source endpoint are retained.

A repeated ID is idempotent only when its immutable payload (`price`, `quantity`, first/last underlying IDs, trade timestamp and buyer-is-maker flag) matches. A conflicting payload raises `AggregateTradeIdentityConflict`; it is never silently overwritten. REST may enrich a WebSocket row with `nq` and WebSocket event time.

REST `q` is total aggregate quantity. Binance's REST `nq` is normal quantity excluding RPI trades. The WebSocket aggTrade message does not include `nq`; therefore, do not substitute `nq` for `q` in the live-stream signed-volume pipeline. Both values are kept separately for future deliberate policy decisions.

## Bootstrap and live ingestion

A new stream needs a baseline before live events can be committed:

```python
from pathlib import Path
from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.market_data.aggregate_trade_history import BinanceAggregateTradeHistoryService
from divatrading.market_data.aggregate_trade_storage import AggregateTradeRepository
from divatrading.market_data.aggregate_trade_recovery import AggregateTradeRecoveryService

database = Database(Path("data/divatrading.db"))
database.initialize()  # applies the latest schema (v5 in Unit 04C)
repository = AggregateTradeRepository(database)
rest_client = BinanceUsdMFuturesRestClient()
history = BinanceAggregateTradeHistoryService(rest_client)
recovery = AggregateTradeRecoveryService(history, repository)

 # Start the selected-symbol WebSocket feed first. Buffer its arriving events
 # in a bounded ingress queue while this bounded REST baseline is fetched.
 state = recovery.bootstrap_latest(symbol="BTCUSDT", limit=1000)
 # Replay the buffered WebSocket events in aggregate-ID order, then keep
 # draining feed.events and pass each event to ingest_websocket_event().
```

`bootstrap_latest()` stores the latest contiguous REST page and establishes its first returned ID as the intentional local history boundary. It does not claim that earlier aggregate IDs have been stored. Existing stream state must not be reset by running bootstrap again.

If a caller needs a specific lower starting ID, register it explicitly with `repository.register_from_id(symbol="BTCUSDT", start_from_id=...)`; the service will attempt to retrieve it by ID. With no timestamp anchor, an empty REST response is recorded as unavailable history, not assumed to be within retention.

The caller must not process the live feed before baseline state exists. In a future market-data supervisor, keep the WebSocket receive loop draining continuously into a bounded ingress buffer while the synchronous REST/bootstrap/recovery work runs on one serialized worker. If that buffer reaches capacity, stop declaring the feed healthy; do not discard events silently.

## Gap recovery state machine

- `BOOTSTRAPPING`: an explicit ID boundary exists but no contiguous baseline has yet been completed.
- `HEALTHY`: every persisted ID from the current local baseline through the latest observed ID is contiguous.
- `DEGRADED`: a WebSocket event arrived above `last_contiguous_id + 1`; the event itself is stored and the expected ID range is durable.
- `UNRESOLVED`: the REST endpoint did not provide a required ID, or the request range is outside/ambiguous against Binance's history retention boundary. This state is not cleared automatically by later live events.

`recover_gap(symbol=...)` fetches from `last_contiguous_id + 1` through `latest_observed_id - 1`. It persists returned rows idempotently and advances the durable cursor only over consecutive IDs. If the three-page pass cap is reached, the result includes `next_from_id`; call another bounded pass later. An empty response or a REST response that skips the expected ID creates an unresolved history state. No synthetic aggregate trade is ever created.

`HEALTHY` in this table refers to ID continuity only. The future supervisor must also require the Unit 04A feed's `is_connected` flag and reject stale events before strategy use.

## Retention

`AggregateTradeRepository.prune_oldest(symbol=..., keep_latest_rows=250_000)` is an explicit maintenance method. It only prunes a stream whose continuity state is `HEALTHY`, preserves the latest configured row count and never deletes the durable stream cursor or gap audit. It is deliberately not automatic; historical deletion must remain a deliberate retention decision. Allowed `keep_latest_rows` is 1 to 2,000,000.

## Operational constraints

- REST service and SQLite repository methods are synchronous. Run them serially and keep draining the bounded WebSocket queue in a separate consumer.
- If a gap is older than the current documented 48-hour REST window, recovery is marked unresolved. Do not claim continuity or compute gap-free cumulative order flow across it.
- The aggregate-trade stream is aggregated (not every matching-engine fill). Insurance-fund and ADL trades are not returned by this REST endpoint.
- Unit tests use fixture responses and temporary SQLite databases; no credentials or live Binance connection are needed.
