# Pine SMC OB Scoring and Ideal Entry Bands — Unit 05D Stage 7

## Scope

Stage 7 ports `f_scoreOB()` from the audited Pine v6 source (instrumented source lines 155–217), the selected-candidate call (lines 617–624), and the active-OB diagnostic score serialization (lines 693–699). It is diagnostic metadata only. It does not choose a candidate, alter Stage-6 trigger results, set `used`, or produce final signal/price levels.

## Exact metadata dependency: `syminfo.mintick`

The Pine score function uses `syminfo.mintick` for the minimum OB-zone range, source-candle range and current-candle range. This value cannot be inferred reliably from OHLCV. `PineSmcStructureConfig.tick_size` must therefore be populated with the exact tick size for the same Binance USDⓈ-M perpetual contract, normally `PRICE_FILTER.tickSize` from Binance Exchange Information. It must correspond to the exact TradingView ticker/data source.

For backward compatibility with Stages 1–6, `tick_size` remains optional. When it is absent, the replay still runs, but `ob_scoring.available=false`, `chosen_score=null` and the active score list is empty. The engine does not guess a tick size. This is a fail-closed scoring state, not a score of zero.

Pine inputs added to replay config:

- `entry_depth_near=0.50`, valid `[0.20, 0.75]`.
- `entry_depth_deep=0.80`, valid `[0.25, 0.95]`.
- `tick_size`: exact finite positive number or `None`.

## Ideal entry band

Let `zoneRange = max(obTop - obBottom, tickSize)`. If `deepDepth <= nearDepth`, Pine substitutes `min(0.95, nearDepth + 0.10)`; otherwise it uses `deepDepth`.

- Bullish: `entryLow = obTop - zoneRange * deepDepth`; `entryHigh = obTop - zoneRange * nearDepth`.
- Bearish: `entryLow = obBottom + zoneRange * nearDepth`; `entryHigh = obBottom + zoneRange * deepDepth`.

No tick rounding is applied to these diagnostic floating-point boundaries; Pine returns the underlying price calculations and later display formatting is separate.

## OB-quality components

The implementation follows `f_scoreOB()` expression order and the source's individual clamp/fallback rules:

1. **Volatility (10 weight):** `atrFast / atrSlow` when `atrSlow>0` and ATR(14) is available, else ratio `1.0`; `clamp(100 - abs(ratio - 1) * 55, 0, 100)`.
2. **Displacement (16):** break-candle close distance beyond the relevant OB boundary in custom ATR(200) units; divide the ATR distance by 2 and scale to 100, clamped. If ATR(200) is not positive, use `0` displacement.
3. **Source candle (12):** source OB candle body percentage × 70% plus direction-specific rejection wick percentage × 30%; multiply by `1.0` for expected opposing candle color or `0.65` otherwise; clamp.
4. **RSI (12):** unavailable RSI gets neutral `50`; otherwise target RSI is `58` for bullish or `42` for bearish, with `100 - abs(rsi-target)*2.2`, clamped.
5. **Trend (12):** swing contribution `100` when aligned, `45` when neutral and `0` when opposed; internal contribution uses the same mapping. Blend 55% swing / 45% internal.
6. **FVG (8):** `100` when the OB's stored FVG flag is true, otherwise `40`.
7. **Relative volume (6):** unavailable/non-positive average gets `50`; otherwise `clamp(50 + (volume / average - 1) * 40, 0, 100)`.
8. **Freshness (6):** `clamp(100 - 70 * age / maxAge, 20, 100)`; defensive fallback `20` if maxAge is non-positive.
9. **Directional sweep (8):** bullish requires current low strictly below the prior lowest and current close strictly above it; bearish is symmetric with prior highest. Score `100` if swept, otherwise `45`.

Quality score is the weighted subtotal divided by **90.0**, preserving the source's explicit weight sum rather than normalizing to a different total.

## Timing and setup scores

- Current-candle range is `max(high-low, tickSize)`.
- Close position is clamped to `[0,1]`.
- Bullish current-candle score is `50*closePosition + 50` when `close>open`, else without the directional 50; bearish mirrors this.
- Distance to entry band is zero inside the band, `close-entryHigh` above it, or `entryLow-close` below it.
- Proximity is `clamp(100 - distance/atrFast*100, 0, 100)` when ATR(14)>0; otherwise it is `100` only at zero distance and `0` otherwise.
- Timing is `currentCandleScore*0.45 + proximityScore*0.55`.
- Setup is `clamp(obQualityScore*0.80 + timingScore*0.20, 0, 100)`.

These are dynamic model scores, not calibrated win probabilities.

## Prior sweep series: separate from Stage 6

The score's confluence input is Pine `ta.lowest(low[1], sweepLookback)` / `ta.highest(high[1], sweepLookback)`. Stage 7 evaluates the preceding `sweepLookback` source candles, excluding the current candle, against the **full loaded-history prefix**. It is not Stage-6's nested `sweepWindow`/`sweepLookback` qualification loop. Prior-low/high series can therefore reflect candles before `startIndex`, just like Pine's `ta.lowest` / `ta.highest` calls.

## Evaluation and ordering

Pine calls `f_scoreOB()` for the chosen Stage-6 candidate and again for each active OB while generating its diagnostic active-OB CSV. The Python trace computes each active OB in original array order (oldest-to-newest), preserving its original `active_array_index`. `chosen_score` references the score row for the Stage-6 `chosen_active_array_index`. It does not choose the maximum score, sort candidates, or change the chosen index.

All records are frozen dataclasses and are part of the deterministic JSONL trace. With no active OBs and a valid tick size, scoring is available with an empty active score list.

## Tests and boundary

`tests/test_pine_smc_ob_scoring.py` contains 16 focused tests for tick-size validation/fail-closed behavior, bullish/bearish bands, deep-depth fallback, all weighted components, directional sweep scoring, strict boundaries, min-tick range guards, source/break candle offsets, active-array order, chosen-score linkage, no mutation, full-prefix prior-sweep values and JSON serialization.

Stage 7 does not implement entry proxy, SL buffer/geometry, min-stop or max-SL gates, TP modes, opposing-OB target, final signal fields, `used` mutation, one-source-bar output shift, MTF arbitration, dynamic trade management, CVD/order-flow gates or execution. SQLite schema v5 remains unchanged.
