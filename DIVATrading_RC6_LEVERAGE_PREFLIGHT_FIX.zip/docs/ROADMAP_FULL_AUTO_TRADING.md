> Latest safe candidate: v0.59.0rc3, 2026-11-15. Read [AUDIT_RC3_STATUS_DAN_HANDOFF.md](../AUDIT_RC3_STATUS_DAN_HANDOFF.md) for current status; read [../AUDIT_PROYEK_ID.md](../AUDIT_PROYEK_ID.md) for the source-checked status. Earlier checkpoint descriptions below are historical, not the current implementation inventory. LIVE remains disabled.

# DIVATrading — Full Auto Trading Build Roadmap

**Product target:** fully automated, multi-pair Binance USDⓈ-M Futures bot. The deliverable is the complete autonomous trade lifecycle, not a signal generator.

## Fixed architecture decisions

- AUTO universe discovery and MANUAL symbol selection across eligible USDT-margined perpetuals.
- Independent market-data and SMC state per symbol; M1/M5 setup contexts remain independent; M15 is advisory only.
- Existing SMC V2 Stages 1–5 semantics are preserved; legacy nested M5/M15 OB priority is not reintroduced.
- Delta/CVD, Depth/Order Book, Absorption, FVG and sweep are aligned evidence/confluence, optional by default rather than hidden OB invalidation gates.
- One global risk/portfolio coordinator governs all active symbols.
- Exact Decimal price/quantity math, current exchange filters, SQLite idempotency and exchange-truth reconciliation.
- PAPER is default. TESTNET/LIVE require explicit local opt-in. Secrets never enter source or release ZIPs.
- Bounded feed workers/caches/queues target Windows 10 / Python 3.12.9 / 8 GB RAM; local Windows compatibility is still unverified.

## Delivery map

| Release | Scope | Status |
|---|---|---|
| v0.40.0 | AUTO/MANUAL multi-pair universe, Decimal risk sizing, private REST foundation, SQLite execution ledger, PAPER execution service and coordinator | Built |
| v0.41.0 | Continuous multi-pair public market runtime and independent symbol workers | Built |
| v0.42.0 | Public feed graph: M1/M5/M15 Klines, Mark Price, Aggregate Trades, Depth, Delta/CVD, Absorption, recovery and SMC snapshots | Built; offline/mocked validation, no live orders |
| v0.43.0 | SMC V2 candidate qualification, independent M1/M5 setups, M15 advisory, optional confluence, entry models and dynamic risk-sized TradePlans | Built; planning only |
| v0.44.0 | Exchange account snapshot and portfolio exposure view | Built; sequential REST snapshot |
| v0.45.0 | Atomic global portfolio-risk reservation across concurrent symbol workers | Built; reservation layer |
| v0.46.0 | User Data Stream, durable account/order events, account reconciliation, protection verification and TESTNET/LIVE freshness gate | Built; no live/testnet network validation |
| v0.47.0 | Managed-position decision engine: partial TP plan, fill-gated breakeven and trailing proposals with durable state | Built; decision layer |
| v0.48.0 | Partial-close adapter, safe conditional Algo STOP replacement, REST fill confirmation, verified-flat release and reconnect recovery | Built; deterministic local tests |
| v0.49.0 | Continuous Mark Price managed-position supervisor, lifecycle dispatch, structural/emergency exits, multi-pair worker isolation and recovery gates | Built; local deterministic tests |
| v0.50.0 | Reconciliation discrepancy policy, process locking, watchdog primitive and read-only operator status CLI | Built; watchdog not wired to all workers |
| v0.51.0 | Aggregate same-symbol position-group accounting, immutable fill attribution, per-signal allocation plans and operator diagnostics | Built; same-side multi-signal execution still blocked |
| v0.52.0 | Quantity-scoped protection, sibling cancellation, fill reconciliation, multi-lot lifecycle supervisor and autonomous SMC TradePlan-to-entry dispatcher | Planned |
| v0.53.0 | Windows packaging, secure configuration, install/startup/shutdown, backups, resource limits and target-PC validation | Planned |

## Build-complete boundary

The full bot is not complete until one integrated runtime can: discover symbols; operate synchronized feeds and recover gaps; run independent SMC state; qualify/rank signals; calculate entry/SL/TP; reconcile account/positions/open orders against Binance; allocate global portfolio risk; submit idempotent orders; protect actual fills; manage partial fills, exits, breakeven and trailing; release risk only after exchange-confirmed flat/terminal states; recover after disconnect/restart; and expose safe operator controls.

## Current v0.51.0 boundary

The account runtime now exposes aggregate position groups, immutable lot-open timestamps and per-signal fill attribution from Binance `ORDER_TRADE_UPDATE`/`TRADE_LITE`. Fill evidence is deduplicated by symbol/trade ID; an unknown internal `DIVA*` fill latches entry halt. The position supervisor still refuses multiple managed signals on one `(symbol, positionSide)`: current protection uses close-all semantics and the lifecycle adapter verifies per-signal state against the aggregate exchange quantity. v0.51 therefore delivers the accounting foundation, not same-side scale-in or the full autonomous order path. Quantity-scoped protections, sibling cancellation, fill-delta reconciliation and the end-to-end SMC TradePlan dispatcher remain the immediate build tasks. No actual Binance TESTNET/LIVE integration or Windows target-PC validation has been performed.

## Deferred research (not build blockers)

- Extended 25h+ replay and warm-up convergence.
- 12-month historical calibration and cross-symbol statistical robustness.
- Walk-forward/out-of-sample and profitability validation.

These are deferred strategy-validation activities, not represented as completed. Basic software integrity, chronological/no-lookahead behavior, exact exchange filters, idempotency, reconciliation and execution safety remain mandatory for build completion.
