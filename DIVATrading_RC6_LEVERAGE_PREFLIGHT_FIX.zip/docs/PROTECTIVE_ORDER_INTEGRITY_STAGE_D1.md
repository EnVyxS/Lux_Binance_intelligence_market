# Stage D1 — Protective Algo Order Integrity Hardening

## Objective

Make the exchange-reported STOP/TAKE_PROFIT Algo order—not a local ledger row or POST acknowledgement—the authoritative evidence that a managed position is protected.

## Validation contract

For quantity-scoped protection, the validator checks:

- Algo order is in an active status.
- Exact symbol and deterministic `clientAlgoId` match the managed allocation.
- Order type is `STOP_MARKET` or `TAKE_PROFIT_MARKET` as appropriate.
- Closing side and `positionSide` match the managed LONG/SHORT and One-way/Hedge account mode.
- Exact quantity matches the protected lot quantity.
- Exact `triggerPrice` matches the durable current STOP or TAKE_PROFIT price.
- `closePosition` is absent/false for quantity-scoped orders.
- One-way requests require `reduceOnly=true`; Hedge Mode requires it to be absent/false.

Legacy pre-v0.52 close-all Algo protection remains recognized only in the existing single-lot migration path, and its symbol, client ID, trigger, status, side and positionSide are checked.

## Entry protection behavior

`ExecutionService._ensure_protection()` now always queries each deterministic clientAlgoId, even if the local ledger already records that role.

- If the order is found and every required field matches, the current exchange response is persisted and accepted.
- If no local record exists and Binance returns `-2013`, the code may submit the initial protection once, then performs a new GET by deterministic clientAlgoId. The POST acknowledgement alone is not accepted as proof of active protection.
- If a locally-recorded order is missing from Binance, entries are halted and the method fails closed. D1 does not blindly recreate it because it may have triggered, been canceled, or require position-residual reconciliation.
- If any field mismatches, entries are halted, a sanitized event is recorded, and no duplicate or replacement Algo order is submitted.
- If the post-submit GET is ambiguous or fails, the system halts and records `PROTECTION_ORDER_POST_UNVERIFIED`. A later recovery pass must query the same deterministic ID before any further mutation.

## Lifecycle and reconciliation

- Protection resize verifies the exact new STOP and TP client IDs, symbol, trigger prices, type, mode-specific fields and quantity before canceling old protection.
- Trailing STOP replacement verifies its exact new ID, symbol, trigger and quantity before old-stop cancellation.
- Periodic account reconciliation compares exchange `triggerPrice` with the persisted current stop and managed take-profit. A wrong trigger is now `POSITION_MISSING_PROTECTION` and blocks account readiness.

## Safety boundaries

- D1 is an integrity-verification and fail-closed release. It does not add automatic repair of a missing protection order for an already-open position.
- A missing or mismatched order must be reconciled against current exchange position quantity, order status, and protective trigger history before a separate recovery action is allowed.
- No real Binance Demo or LIVE order, cancellation, fill, or Algo mutation was executed during this build.
- C1 actual Demo entry/fill/protection qualification remains pending. D1 unit and regression tests use local fakes, SQLite and deterministic fixtures.
- LIVE remains disabled and unauthorized.

## Next increment

Stage D2 will implement an explicit position-aware recovery workflow for missing protective orders, including exchange position residual checks, active/terminal Algo identification, deterministic replacement IDs, query-after-POST confirmation, and paired-protection safety. It must never infer that a missing GET response means the position is flat.
