# Unit 05D — Pine SMC Structure Events (Stage 2)

## Status and source identity

- Release: `0.19.0`.
- Parent checkpoint: Unit 05D Stage 1 v0.18.0; ZIP SHA-256 `928d9f679e01c1813e88479e985753d2787a518608b3f52adf502fc5ef4b74de`.
- Original Pine v6 SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented Pine SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Implemented from the exact packaged Pine source block at lines 442–528, with Stage 1 state and pivot updates at lines 355–440.

## Implemented behavior

1. `confluenceFilter` defaults both `bullishBar` and `bearishBar` to true. When enabled, Pine computes `a = high - max(close, open)` and `b = min(close, open - low)`, then applies strict `a > b` / `a < b`. The second expression is deliberately preserved exactly; it is not replaced with the more conventional lower-wick expression.
2. Internal bullish break is evaluated first. It preserves the `extraBull` swing-level inequality guard, valid/not-crossed check, local-index minimum, and strict close-cross conditions (`close > inHCur`, previous close `<= inHCur`). It marks the internal high crossed and sets `internalTrend=1`.
3. Bullish classification is CHoCH only when the internal trend immediately before that branch was `-1`; otherwise it is BOS.
4. Internal bearish break is evaluated second, using the equivalent `extraBear` guard and strict close-cross conditions. It marks the internal low crossed and sets `internalTrend=-1`. It is CHoCH only when the trend at that point is `1`; otherwise it is BOS. This branch observes the bullish branch's trend update if both could ever become true on a bar, matching Pine's sequential state mutation.
5. For each internal event, the raw event extreme is scanned from the corresponding pivot local index through the current local index. Bullish events find the minimum raw low; bearish events find the maximum raw high. Comparisons are strict, so equal later extrema do not replace the earliest source candle.
6. Swing high break is evaluated after both internal checks, followed by swing low break. A swing break marks the corresponding pivot crossed and changes only `swingTrend`; it does not set internal BOS/CHoCH event flags.
7. Existing `trTop`/`trBot` tracking remains intact: established extremes update before pivot detection; a new swing pivot overwrites its corresponding range boundary. Both are included in per-bar traces.
8. `PineSmcStructureEvents` captures the confluence booleans, four internal event flags, event extreme, local index and source candle-open timestamp. The bar trace also captures independent `internal_trend` and `swing_trend` values.

## API changes

`PineSmcStructureConfig` adds:

- `confluence_filter: bool = False`, corresponding to Pine `confluenceFilter` default.

`PineSmcStructureReplayResult` records the effective `confluence_filter` value.

`PineSmcBarTrace` adds:

- `swing_trend`
- `internal_trend`
- `structure_events: PineSmcStructureEvents`

The event trace is exported through `divatrading.strategy`.

The replay retains all in-window candles in a list bounded by `warmupBars` (Pine maximum 2,500). This is necessary because the event-extreme scan can span farther back than the pivot lookback. It does not retain candles before the per-timeframe reset boundary.

## Stage 2 exclusions

No OB creation, FVG detection, OB removal/mitigation, OB scan/selection, trigger precedence, sweep, score, signal emission, one-source-bar output shift, MTF arbitration, Dynamic Entry/SL/TP, CVD/order-flow filtering, Telegram/dashboard, private API, or order execution is introduced. Those are later independent stages and must not alter this Pine-baseline structure trace.

## Tests

The 6 added focused tests cover:

- Internal bullish BOS followed by bearish CHoCH, with exact event-extreme source index/time and strict oldest-tie behavior.
- Crossed-state suppression of repeated breaks until a new pivot updates the crossed flag.
- New pivot re-arming the crossed flag and the next opposite-state break classifying as CHoCH.
- Swing bullish and bearish break transitions, crossed flags and tracked range boundaries without internal-event flags.
- The exact source confluence expression and strict equality behavior.
- Deterministic JSONL serialization of the event trace.

These are source-derived implementation tests. They are not independent TradingView runtime parity evidence. At this checkpoint there are still zero accepted TradingView observations and parity remains unmeasured.
