# DIVATrading RC5 — LIVE-first operating guide

**Release:** 0.59.0rc5. **Target:** Windows 10, Python 3.12.9 64-bit, Binance USDⓈ-M Futures. **State:** offline regression candidate; live exchange behavior is unverified.

## Architecture

- M1: independent SMC scalping setup; M5: independent SMC setup, with M1 confirmation for M5 Confirmation-MARKET; M15: optional soft context.
- Evidence: closed candles and OB lifecycle, FVG/sweep, trades→Delta/CVD, depth, absorption and Mark Price. Optional evidence cannot veto healthy mandatory price sources; order execution still requires independent executable-quote checks.
- Entry types: `LIMIT_RETRACEMENT` (default) and `CONFIRMATION_MARKET` (only on verified OB retest and a **later** closed confirming bar). Sweep/FVG evidence is time-bounded.
- Account/recovery: global risk ledger, idempotent intent, entry/exit reconciliation, deterministic protective Algo orders, managed position supervisor, no trading with externally unowned positions/orders. LIVE-first has mandatory order quote guard and protection recovery opt-in.
- Open Interest, Funding, Liquidation additional feature models have NOT been added into RC5 SMC scoring. Their benefit has not been independently established; do not claim all Binance market datasets are consumed.

## Before the user chooses to contact Binance

1. Extract the ZIP into a **new** Windows directory. Do not overwrite a running RC4 state database. Do not import credentials from chat or copy private keys into logs.
2. Install **Python 3.12.9 x64** and run `INSTALL_WINDOWS.bat`.
3. Run `TEST_WINDOWS.bat` and `RUN_RC5_DIAGNOSTICS_WINDOWS.bat` (no signed requests/orders). Check `logs/rc5_local_acceptance.json`.
4. Inspect the `docs`, tests, current symbol filters and local account risk controls; the offline check is not a claim of LIVE safety.

## Optional real-account read-only check

Copy `.env.example` to `.env` (the installer will create a default if absent). Keep it only on the operator PC. For the optional GET-only preflight set `DIVA_EXECUTION_MODE=LIVE`, `DIVA_LIVE_TRADING_ENABLED=false`, `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true`, and local `BINANCE_API_KEY` / `BINANCE_API_SECRET`. Run `START_LIVE_READ_ONLY_WINDOWS.bat` only when the operator decides to allow authenticated account inspection. The check never submits or changes orders.

## Operator-controlled real-money activation (NO DEMO prerequisite)

**WARNING: THE FOLLOWING STARTS A REAL ORDER-CAPABLE PROCESS**. It must not be run until you have reviewed the code, logs and risks. Real fills can lose the entire margin and liquidation can occur. If the account capital is too small for Binance minimum notional/lot filters at the 0.10% risk budget, the bot must skip entry rather than increase the risk budget.

1. Stop every other bot on the same account. Bot-only account reconciliation may stop this process if it detects positions/orders it does not own; manually created positions should not be modified by this engine.
2. Configure local `.env` **only when you choose to arm LIVE**:

```dotenv
DIVA_EXECUTION_MODE=LIVE
DIVA_LIVE_TRADING_ENABLED=true
DIVA_LIVE_CONFIRMATION=I_ACCEPT_REAL_MONEY_RISK
DIVA_ENFORCE_ENTRY_QUOTE_GUARD=true
DIVA_ENABLE_PROTECTION_RECOVERY=true
DIVA_REQUIRE_ACCOUNT_READINESS=true
BINANCE_API_KEY=YOUR_LOCAL_PRODUCTION_KEY
BINANCE_API_SECRET=YOUR_LOCAL_PRODUCTION_SECRET
```

Ensure Binance Futures permission is enabled, withdrawals are disabled, API access is IP-restricted, and margin/leverage are correct. Set an operator kill-switch and emergency close workflow. Never post the `.env` or private key.
3. Run `START_LIVE_FIRST_WINDOWS.bat`, read the risk notice and type the exact on-screen phrase; this is the second activation gate. A direct CLI invocation also requires `--activate-live`. No LIVE order is sent simply by unpacking the ZIP.
4. **Observe the first order, fill and conditional STOP/TP closely.** Check REST status and actual account position after each stage. If STOP/TP is absent, stale or inconsistent, disable new entries and use an exchange UI manual emergency process. The operator must evaluate real slippage, fees, and effective drawdown.
5. Stop via Ctrl+C and review account state, pending intents, open Algo orders, orphan order risk and logs before restarting. Restart can reconcile, but asynchronous exchange ambiguity is not theoretically eliminable.

## What the offline tests DO and DO NOT demonstrate

The RC5 tests demonstrate Python fixtures for retrospective retest sequencing, M5/M1 confirmation, stale sweep removal, risk caps, mark reference rounding, dedicated execution lifecycle and non-network safety gates. These tests do not prove strategy profitability, complete market-data quality, Binance production compatibility, exact funding/commission terms, or real fill/recovery. No out-of-sample net-PnL backtest of user-supplied long-history Binance datasets is included in RC5.

## Known release boundaries

- Tested in Linux/Python 3.13.5; Windows Python 3.12.9 target validation requires the operator to run scripts.
- Historical Binance Futures data and true personal exchange account balances not included in the release archive.
- No guarantee of profit, no universal cap on realized losses, risk cannot be eliminated.
- A scalping profile is defined, but there is **no independently proven time-in-trade cap** in this candidate. Positions rely on lifecycle/SL/TP rules; operator should measure and consider a maximum holding-time exit in future releases.
- AggTrades-based CVD/Delta is a proxy, not full exchange order flow. Liquidation streams are lossy snapshots. Additional OI/Funding/Liquidation data must be assessed for incremental value before being allowed to affect entry.
- Initial LIVE policy is deliberately **one pair/one position**, not multi-pair; the research engine still scans independent M1/M5 sources. Multi-pair LIVE expansion requires separate acceptance, not changing only `--max-symbols`.

If a release test or account risk gate fails, do not force an entry by disabling protection or increasing leverage.
