# Unit 05D — Ordered OB Candidate Eligibility (Stage 5)

## Status and source identity

- Release: `0.22.0`.
- Parent checkpoint: Unit 05D Stages 1–4 v0.21.0; ZIP SHA-256 `387be0c0f70bcc3270ec0e19a3e429258ed10abbca58e29a8ef5184701210edb`.
- Original Pine v6 SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.
- Instrumented Pine SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.
- Capture patch SHA-256: `4901facc8365692b51397eabc34d232d7de86a78e6f3c28e2eb894df81a160ed`.
- Pine source block: `FindSignal()` eligibility scan, lines 542–570.

## Implemented behavior

1. Adds Stage-5 effective Pine inputs to `PineSmcStructureConfig`: `max_age_m15=150`, `max_age_m5=300`, `fresh_only=true`, `use_trend_filter=true`, `use_pd_filter=true`, and `require_fvg=false`. Replay metadata records all six values.
2. Mirrors Pine's timeframe max-age argument mapping: M1 and M5 contexts receive `maxAgeM5`; M15 contexts receive `maxAgeM15`. There is no separate M1 age parameter in the source calls.
3. Scans the active OB collection from its newest index to its oldest index. Each evaluation records the original active-array index, a frozen `PineSmcOrderBlockTrace` snapshot, an eligibility boolean and all gate rejection reason codes in Pine condition order.
4. `fresh_only` rejects `used=true` only when enabled. Eligibility is read-only; it never changes `used`.
5. Age is rejected when `local_index <= break_local_index` or `local_index - break_local_index > max_age`. Thus the first eligible age is 1 and the configured maximum age is inclusive.
6. Trend requires `swing_trend == 1` for bullish OBs and `swing_trend == -1` for bearish OBs when enabled.
7. Premium/discount runs only when enabled and both tracked range endpoints are valid with `range_top > range_bottom`. It computes `eq=(range_top+range_bottom)/2` and `ob_mid=(top+bottom)/2`. Bullish is rejected only when `ob_mid > eq`; bearish only when `ob_mid < eq`. Equality passes.
8. `require_fvg` checks only the stored OB FVG boolean. It does not run a second FVG scan.
9. Volatility eligibility consumes Stage-4 `volatility_extreme` and `volatility_choppy` booleans without recomputing thresholds. Either true rejects the candidate.
10. `PineSmcObEligibilityTrace` carries `max_age`, the full newest-to-oldest scan, and its eligible subset in the same order. Each `PineSmcBarTrace` includes this immutable view; deterministic JSONL serialization includes the candidate evaluations and reason codes.

## API changes

`PineSmcStructureConfig` adds:

- `max_age_m15: int = 150`
- `max_age_m5: int = 300`
- `fresh_only: bool = True`
- `use_trend_filter: bool = True`
- `use_pd_filter: bool = True`
- `require_fvg: bool = False`

Public strategy exports add:

- `PineSmcObCandidateEvaluation`
- `PineSmcObEligibilityTrace`

Per-bar `PineSmcBarTrace` adds `ob_eligibility`. `PineSmcStructureReplayResult` records effective Stage-5 inputs. No SQLite migration is required.

## Deterministic Stage-5 tests

Eleven focused tests cover:

- Pine default values, input type/range checks, and M1/M5/M15 max-age argument mapping.
- Newest-to-oldest scan order, original array indices and unchanged underlying collection order.
- Strict post-break age and inclusive `maxAge` boundary.
- `freshOnly` with used and unused OB state, proving no mutation.
- Bullish/bearish trend direction and neutral trend behavior.
- Premium/discount midpoint rules, strict equilibrium equality and invalid-range bypass.
- Required FVG using the stored flag only.
- Independent extreme/choppy rejection and combined reason ordering.
- Simultaneous rejection reason ordering matching Pine's `if` sequence.
- Immutable snapshots and deterministic JSONL representation.
- Replay integration: an OB is ineligible on its break bar (`localIndex <= breakIndex`) and may become eligible on a later bar if it survives mitigation.

These are source-derived implementation tests, not independent TradingView runtime parity observations.

## Stage-5 exclusions

No rejection/structure trigger, `triggerMode`, `structAllowBOS`, `minWickPct`, sweep, sweep lookback/window, score computation, entry band, final signal emission, OB `used` mutation, one-source-bar output shift, MTF arbitration, Dynamic Entry/SL/TP, CVD/order-flow filters, Telegram/dashboard, private API, live execution or database migration is introduced. SQLite schema remains v5.

## Evidence and limitations

- Focused Stage-5 tests: 11 passed.
- Focused Stage 1–5 tests: 57 passed.
- Full regression suite in the working tree: 435 passed.
- Independent TradingView reference observations/fixtures accepted: zero. Runtime parity remains unmeasured.
- Verification target is Python 3.13.5/Linux; Windows 10/Python 3.12.9 remains outstanding.
- Preserve the Pine CC BY-NC-SA 4.0 notice and confirm permissions before commercial use or redistribution of derivative code.
