# Unit 04A — Aggregate Trade feed usage

```python
import asyncio
from divatrading.market_data.aggregate_trades import BinanceAggregateTradeWebSocketFeed

async def main() -> None:
    feed = BinanceAggregateTradeWebSocketFeed(symbols=["BTCUSDT"])
    stop_event = asyncio.Event()
    task = asyncio.create_task(feed.run(stop_event))
    try:
        while True:
            event = await feed.get_event()
            print(
                event.symbol, event.aggressor_side, event.price, event.quantity,
                event.signed_quantity, event.aggregate_trade_id,
            )
            if event.missed_aggregate_trades_before:
                # Sequence is not continuous. Do not bridge this event into a
                # trusted running Delta/CVD until a later gap-recovery unit
                # reconciles the missing aggregate IDs.
                print("Observed missing aggregate IDs:", event.missed_aggregate_trades_before)
    finally:
        stop_event.set()
        await task

asyncio.run(main())
```

## Interpretation

- Binance `m=true`: buyer is maker; seller is the taker/aggressor. `aggressor_side` is `SELL`; signed base/quote quantity is negative.
- Binance `m=false`: buyer is taker/aggressor. `aggressor_side` is `BUY`; signed base/quote quantity is positive.
- `quantity` is base-asset volume. `quote_quantity` is derived as `price × quantity`, preserving `Decimal`.
- `aggTrade` is aggregated by Binance and is not an unaggregated tape of every individual matching-engine fill.
- The feed is public/read-only and requires no API key. The consumer must continuously drain the queue; queue overflow raises an explicit exception.
- Begin with one or two selected symbols on the 8 GB target PC. The 16-symbol default cap is a hard resource ceiling, not a recommended initial subscription count.
- Forward aggregate ID gaps are surfaced but not repaired in Unit 04A. Do not treat downstream cumulative order flow as gap-free until the gap is reconciled.
