# SMC V2 Stage 6B.4 — Integrated Replay Workflow & Final Review

## Purpose and scope

Stage 6B.4 adds a single orchestration boundary for the Stage 6B dataset-to-evidence chain. It does not change Stage 6A replay clocks or Stage 1–5 SMC V2 detection semantics.

The integrated order is fixed:

1. Raw-source dataset quality audit (Stage 6B.1, manifest-backed source re-scan).
2. Strict manifest, source hash/row-count and historical metadata eligibility.
3. Deterministic Stage 6A evidence replay.
4. Stage 6B.2 chronological 60/20/20 analytics.
5. Stage 6B.3 warm-up comparison across a common evaluation slice.
6. Final source/manifest immutability verification and artifact hash report.

## Runtime API and CLI

- Module: `src/divatrading/replay/workflow.py`.
- Public API: `run_stage6b_workflow(plan_path, report_path, output_dir=None, plan_schema_path=None, report_schema_path=None)`.
- Errors: `ReplayWorkflowError`, `ReplayWorkflowEligibilityError`.
- CLI: `replay-workflow --plan PLAN.json --report REPORT.json [--output-dir DIR] [--plan-schema SCHEMA] [--report-schema SCHEMA]`.
- Plan schema: `docs/schemas/stage6b_workflow_plan.schema.json`.
- Final report schema: `docs/schemas/stage6b_workflow_report.schema.json`.

Plan paths are resolved relative to the plan file unless absolute. Each trial identifies a unique `trial_id`, a Stage 6A manifest, and optionally a dataset root. Two to ten trials are accepted; at least three distinct pre-roll lengths are recommended. All trials must share symbol, active intervals and exact metadata snapshot, cover the same aligned evaluation window, and have distinct pre-roll starts. Every Stage 6B.2 ledger window is preflighted for the minimum length required by the frozen aligned 60/20/20 split before replay begins.

Example plan:

```json
{
  "workflow_schema_version": 1,
  "evaluation_window": {
    "start_ms": 1760000000000,
    "end_ms_exclusive": 1760086400000
  },
  "metadata_evidence_ref": "archive:exchange-info-effective-window-2026-01",
  "output_dir": "stage6b-output",
  "replay_config": {
    "max_history_candles": 1000,
    "checkpoint_every_captures": 1000
  },
  "trials": [
    {"trial_id": "short", "manifest": "short/manifest.json", "root": "short"},
    {"trial_id": "medium", "manifest": "medium/manifest.json", "root": "medium"},
    {"trial_id": "long", "manifest": "long/manifest.json", "root": "long"}
  ]
}
```

Run on Windows:

```powershell
.\.venv\Scripts\python.exe -m divatrading replay-workflow `
  --plan .\data\BTCUSDT\workflow-plan.json `
  --report .\reports\BTCUSDT-stage6b-workflow.json
```

## Gate and recovery behavior

- Default `replay_mode` is `STRICT`; plans without the field preserve the original strict behavior. Stage 6C.2 adds the explicit opt-in `PROVISIONAL_STRATEGY_EVIDENCE` mode. The two modes and the independent market-data / execution-metadata gates are specified in `SMC_V2_REPLAY_ELIGIBILITY_GATES_STAGE6C2.md`.
- A raw-source audit report is written per trial before manifest validation. Strict mode requires `strict_replay_eligible=true`. Provisional strategy-evidence mode requires `provisional_strategy_replay_eligible=true`, and final outputs are conspicuously labelled `STRATEGY_EVIDENCE_ONLY_NO_EXECUTION_VALIDATION` with the execution metadata gate still blocked. Internal gaps can be represented in the quality report, but their WARN status is not strict-eligible in this workflow. No missing candle is interpolated or repaired.
- Stage 6A manifest hash, row count, symbol/contract, metadata snapshot and source integrity are revalidated. Dataset/output path overlap and duplicate trial IDs are rejected. The output and final report destinations cannot overwrite source files/manifests or be placed inside a dataset root.
- Each trial deliberately exercises recovery: replay one capture to an incomplete checkpoint, then resume with the same manifest/config/code and require a completed checkpoint before analytics. Stage 6A rebuilds engine state from the dataset prefix; it does not restore by trusting serialized engine internals.
- The same frozen replay configuration and code identity are required across trials. Warm-up convergence additionally verifies identical evaluation-slice native Kline fingerprints and metadata/clock identity.
- Every generated quality, analytics, convergence and final workflow report is Draft 2020-12 validated. The final report binds manifest/source/ledger/replay/config/code/metadata/report identities and hashes generated artifacts.
- Source files and manifests are hashed before the workflow and rechecked at the end. Any observed mutation aborts final report emission. Quality, analytics and convergence use temporary SQLite spools; these are automatically removed when each operation exits.
- The final report intentionally contains no automatic convergence pass/fail or calibration verdict. A low divergence rate in synthetic fixtures is not empirical convergence evidence.

## Metadata evidence limitation

`metadata_evidence_ref` is a caller-supplied reference string. Stage 6B records its presence and preserves the metadata snapshot hash, but does not fetch, authenticate or prove the referenced external evidence. `HISTORICAL_EFFECTIVE` remains a caller-declared claim. A real Stage 6C calibration dataset requires independently retained Binance metadata evidence for the entire historical window. Stage 6A currently supports only one metadata snapshot per dataset; windows crossing filter changes must be split into metadata-homogeneous datasets.

## Verification and exclusions

Stage 6B.4 original tests use synthetic Binance-shaped Kline CSV fixtures and the retained exchange-info fixture. They validate end-to-end mechanics, strict quality gating, deterministic reports, checkpoint/resume, source immutability, tamper rejection and schema behavior. They do not validate real BTCUSDT/ETHUSDT historical data, empirical warm-up convergence, calibration, TradingView parity, trading signals, fills, PnL or profitability.

Stage 6C.2 subsequently exercised the provisional path on a real 30-day BTCUSDT source, using a deliberately bounded 15-minute common evaluation window and three pre-roll lengths. The end-to-end workflow completed; empirical evidence did not fully converge. See `REAL_DATA_STAGE6C2_SMOKE_REPORT.md`. This does not replace the synthetic tests or qualify strict execution.

No private API, order execution, entry/SL/TP, risk sizing, position manager, Telegram or dashboard is part of this stage. Windows 10 / Python 3.12.9 still requires separate target-environment verification.
