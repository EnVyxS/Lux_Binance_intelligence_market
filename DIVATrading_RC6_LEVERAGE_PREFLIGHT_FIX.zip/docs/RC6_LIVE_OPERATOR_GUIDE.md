# DIVATrading RC6 — LIVE Autonomous Scalping Operator Guide

## Pemakaian dengan API Binance saja

1. Ekstrak RC6 ke folder BARU, tanpa menyalin database RC5 yang sedang dipakai bot aktif.
2. Install Python 3.12.9 64-bit lalu jalankan `INSTALL_WINDOWS.bat` (membuat `.env` jika belum ada).
3. Isi HANYA dua field Binance di `.env`: `BINANCE_API_KEY` dan `BINANCE_API_SECRET`.
4. Jalankan `TEST_WINDOWS.bat` / `RUN_RC6_DIAGNOSTICS_WINDOWS.bat` (semuanya offline, tanpa order).
5. Jalankan `START_LIVE_WINDOWS.bat`, baca risiko lalu tulis `START LIVE TRADING` untuk mengaktifkan runtime real-money.

Konfigurasi `.env.example` sudah LIVE-armable; **menyalin .env tidak mengirim order**. Launcher selalu membutuhkan persetujuan interaktif. Menjalankan Python CLI manual juga memerlukan `--activate-live`. Bukan jaminan bahwa order akan diterima; kesiapan dan minimum order harus terpenuhi.

## Default strategi dan risiko

- SMC setup independen M1/M5; M15 soft context; LIMIT_RETRACEMENT; autonomous AUTO universe 8 pair kandidat/worker dengan maksimal **2 posisi managed** lintas pair.
- Risk mode default `FIXED`/Peluru: **0.20 USDT/trade**, daily realized + floating loss gate **1.00 USDT**; batas nominal diuji dengan fee/funding/slippage reserve sebelum order.
- Live risk guard tambahan: fixed bullet/percent risk masing-masing <= **10% ekuitas** dan total portfolio open risk <= **20% ekuitas**. Keduanya merupakan ceiling penyelamatan, bukan target. Persen portofolio CLI default 20%, namun maksimal dua posisi dan risk masing-masing tetap membatasi actual exposure.
- Leverage AUTO: memilih feasible bracket berdasarkan ukuran notional dan aturan Binance, maksimum efektif sesuai `GET /fapi/v1/leverageBracket`; bukan jaminan lebih aman dari likuidasi. Sizing tidak dibesarkan hanya agar memenuhi minimum Binance.
- Daily loss / risk mode dapat diubah via Telegram (`/maxloss daily 1`, `/risk fixed 0.2`, `/risk percent 1`). Pengaturan tersimpan di SQLite dan dipertahankan saat upgrade, termasuk nilai yang sebelumnya dikonfigurasi operator. Untuk kembali ke default gunakan Telegram atau database BARU — jangan hapus database trading aktif tanpa audit.
- Tidak ada hard gate harian 1% default yang menimpa batas $1. Optional extra cap `--live-max-daily-loss-pct`/`--live-max-drawdown-pct` dapat ditambahkan CLI.

## Telegram — dua kredensial terpisah

- Telegram **tidak dapat diaktifkan hanya dengan Binance API key**. Isi `TELEGRAM_BOT_TOKEN` dari BotFather dan `TELEGRAM_OWNER_ID` (ID numerik akun Telegram owner), lalu tekan Start / kirim `/start` ke bot melalui chat pribadi terlebih dahulu.
- `CHECK_TELEGRAM_WINDOWS.bat` melakukan GET `getMe` dan `getChat`, tanpa API Binance dan tanpa order. Jika keduanya valid, `telegram-control` berjalan otomatis sebagai thread runtime dan dispatch hasil qualified order diberitahukan bila `TELEGRAM_NOTIFY_TRADES=true`.
- `/help`, `/status`, `/risk fixed 0.2`, `/risk percent 1`, `/maxloss daily 1`, `/maxloss daily percent 2`, `/leverage auto 125`, `/pause`, `/resume`, `/kill`, `/resetkill confirm`. `/kill` mengunci entry baru tetapi TIDAK menutup posisi secara membabi-buta.
- Jika kosong KEDUA token dan owner ID, bot masih dapat trading tetapi Telegram **nonaktif**; jika salah satu saja diisi, startup ditolak. Jika keduanya diisi tetapi bot/owner tidak bisa diverifikasi dari Binance LIVE launcher, runtime menolak startup hingga diperbaiki. Telegram notification gagal tidak boleh melakukan pengiriman order ulang.
- Bot ini memakai `getUpdates` (long polling). Jangan jalankan instance Telegram bot lain dengan token sama, dan jangan aktifkan webhook bot yang sama. Kunci bot/akun jangan pernah diberikan kepada orang lain.

## Penting sebelum LIVE

- Gunakan Binance USDⓈ-M Futures API permissions yang tepat; jangan izinkan withdrawal; gunakan IP whitelist dan jangan bagikan `.env`. Pastikan akun kosong dari posisi/order manual yang tidak dimiliki bot karena kebijakan BOT_ONLY akan menolak entry, bukan memodifikasinya.
- Jangan menjalankan dua instance terhadap akun sama. Cek posisi dan orders real di Binance pada transaksi pertama. SL/TP menggunakan Algo Order; perlu divalidasi terhadap exchange aktual. Hentikan bot jika entry tidak terproteksi dan tangani manual melalui Binance UI.
- Tests lulus tidak membuktikan profitabilitas, biaya aktual, reliabilitas Windows, acceptance fills/partial fills, atau keselamatan modal. Dana asli dapat habis akibat pergerakan pasar, margin/leverage, kegagalan jaringan, dan likuidasi. Tidak ada order exchange dilakukan oleh pembuat RC6.
