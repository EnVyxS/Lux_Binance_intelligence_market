# Unit 05E Stage 5 — Liquidity & FVG Evidence Engine

**Release:** 0.30.0  
**Status:** Implemented; synthetic/mechanical tests pass. Historical replay calibration remains pending.

## Scope and isolation

`strategy/scalping_liquidity_fvg.py` consumes a same-capture `ScalpingMarketStructureResult` and immutable `ScalpingMarketDataView`. It emits optional liquidity and Fair Value Gap evidence only.

- M1 and M5 have independent state and replay cursors.
- M15 is advisory-only and does not create, suppress, or arbitrate M1/M5 evidence.
- Stage 5 does not consume or mutate Stage-3 OB candidates or Stage-4 OB lifecycle.
- FVG and sweep evidence do not qualify/veto OB validity, create entries, rank candidates, or modify a trade.
- No CVD/Delta, Depth, Absorption, private API, order placement, Telegram/dashboard, Entry/SL/TP, risk, position management or DB migration is introduced.

## Liquidity references

References are derived from Stage-2 confirmed `SWING` and, when enabled, `INTERNAL` pivots.

A pivot is causally available to a candle only when:

`pivot.confirmation_close_time_ms < candle.open_time_ms`

Thus the pivot cannot be used by its source candle or its right-side confirmation candle. A pivot that Stage 2 later breaks is retired only from candles after the corresponding structure event's confirmation time; a final `broken` flag is not projected backward into earlier candles. If a pivot is marked broken but its break event is no longer retained, it is excluded fail-closed.

Reference kinds:
- `SWING_HIGH` / `SWING_LOW`: individual confirmed swing pivots.
- `LOCAL_HIGH` / `LOCAL_LOW`: individual confirmed internal pivots.
- `EQUAL_HIGH` / `EQUAL_LOW`: clusters of at least two same-side confirmed pivots.

Equal-level grouping uses the exact Binance `PRICE_FILTER.tickSize`:

`maximum cluster deviation from its canonical first level <= tickSize * equal_level_tolerance_ticks`

The default tolerance is **2 ticks**, provisional and uncalibrated. The canonical reference price is the earliest pivot's exact tick-aligned price; no price rounding or floating-point arithmetic is used. A cluster ID is deterministic from its pivot identities. Duplicate pivot IDs are deduplicated before clustering.

The result's `references` are the currently available levels at the latest processed candle, not a permanent historical archive. Sweep evidence retains its own immutable reference ID and exact price.

## Sweep evidence

Sweep checks run only on closed candles and only against levels known before that candle opened.

For a high-side level `L`:
- wick breach: `high > L`
- close-through: `close > L`
- close-back: `high > L AND close < L`

For a low-side level `L`:
- wick breach: `low < L`
- close-through: `close < L`
- close-back: `low < L AND close > L`

All comparisons are strict. A close exactly at the level is neither close-through nor close-back. The record exposes all booleans and an outcome (`WICK_BREACH`, `CLOSE_THROUGH`, `CLOSE_BACK`) independently of qualification.

Default `require_sweep_close_back=true`: only close-back qualifies as a sweep. If disabled, any wick breach qualifies, including a close-through. High-side sweep direction is bearish (`-1`); low-side sweep direction is bullish (`+1`). A qualified sweep consumes the referenced pivot IDs to prevent repeated sweep events from the same liquidity pool. A close-through structure break retires that pivot for subsequent candles using Stage-2 event confirmation time; the break candle itself can still emit its close-through evidence.

## Three-candle FVG

The engine uses three consecutive closed candles C1, C2, C3. C2 is retained as exact indexing/provenance; the gap boundary comparison is between C1 and C3.

Bullish:
- condition: `C3.low > C1.high`
- zone: `zone_bottom = C1.high`, `zone_top = C3.low`
- direction: `+1`

Bearish:
- condition: `C3.high < C1.low`
- zone: `zone_bottom = C3.high`, `zone_top = C1.low`
- direction: `-1`

Equality is not an FVG. No minimum gap size, ATR filter or other uncalibrated threshold is imposed. Each FVG retains C1/C2/C3 open times and C3 close confirmation time. The formation candle is not also evaluated as a retest.

Independent FVG state:
- `ACTIVE`: no subsequent range overlap.
- `TOUCHED`: first subsequent overlap, with zero positive penetration.
- `PARTIALLY_FILLED`: positive penetration, but the distal edge has not been reached.
- `FILLED`: subsequent candle range intersects and reaches/passes the distal boundary.

Maximum fill ratio is a Decimal clamped to `[0,1]`; first touch and full-fill times are distinct. A candle entirely gapped beyond the FVG without intersecting its range does not fabricate a touch or fill. FVG state is separate from Stage-4 OB lifecycle.

## Replay, integrity and resource bounds

- Immutable evidence and trace records; deterministic SHA-256-derived IDs and stable JSONL.
- Duplicate capture delivery is idempotent.
- Exact Kline identity, close boundary, tick grid and closed-candle checks.
- Gaps, missing overlap, revised retained candles, mismatched capture identity and invalid pivot provenance fail closed.
- M1/M5 inputs are preflighted and staged before atomic commit.
- Rolling two-candle memory is sufficient for the next three-candle FVG evaluation.
- Per-symbol state, current liquidity references, sweep history, FVG records, traces and candle fingerprints are bounded.
- Old sweep/trace/fingerprint history is truncated to configured caps. Filled FVGs are terminal and may be evicted; nonterminal FVGs are never silently dropped. If the FVG cap is occupied only by nonterminal gaps, a typed capacity error is raised.
- Reset supports all state, one symbol, or one symbol/timeframe.

## Default configuration

| Setting | Default | Calibration status |
|---|---:|---|
| `equal_level_tolerance_ticks` | 2 | Provisional |
| `require_sweep_close_back` | `true` | Explicit conservative default |
| `include_internal_pivots` | `true` | Configurable |
| `max_references_per_timeframe` | 512 | Resource bound |
| `max_sweeps_per_timeframe` | 1024 | Resource bound |
| `max_fvgs_per_timeframe` | 512 | Resource bound |
| `max_traces_per_timeframe` | 4096 | Resource bound |
| `max_candle_fingerprints_per_timeframe` | 2048 | Resource bound |

## Public API

Exported from `divatrading.strategy`:
- `ScalpingLiquidityFVGConfig`
- `ScalpingLiquidityFVGEngine`
- `ScalpingLiquidityFVGResult`
- `LiquidityReference`
- `LiquiditySweepEvidence`
- `FairValueGap`
- `LiquidityFVGTrace`
- `LiquidityFVGTimeframeResult`
- typed Stage-5 errors.

## Validation and limitations

Stage-5 focused tests cover bullish/bearish FVG boundaries, exact three-candle indexing, touch/partial/full fill, unclosed-candle exclusion, confirmed-pivot causality, equal-level tick tolerance, duplicate pivot identity, high/low sweeps, strict close-back semantics, close-through retirement, qualified-sweep consumption, M1/M5 independence, M15 advisory-only, deterministic replay/JSONL, reset, continuity/revision fail-closed, atomic preflight, bounded sweeps and FVG capacity.

Tests establish implementation mechanics only. No historical Binance replay, threshold calibration, live Binance validation, Windows 10/Python 3.12.9 validation, profitability or Pine runtime parity is claimed.
