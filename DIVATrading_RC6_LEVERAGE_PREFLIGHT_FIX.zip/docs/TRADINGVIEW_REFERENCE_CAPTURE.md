# TradingView Reference Capture — Pine SMC Baseline

## Purpose

This document explains how to collect independent observations for the audited Pine v6 indicator without making TradingView chart CSV export a prerequisite. The original Pine source remains the authority for implementing calculations. Binance USDⓈ-M historical Klines are the replay input; TradingView observations are used to independently check selected outputs.

Original Pine SHA-256: `46dd39e0e94c3d08fbb1fb185cb215d1eaf976fceee9af8328b2f60d25a75a2c`.

Instrumented full script: `reference/pine_smc/Sniper_SMC_MTF_Enhanced_Instrumented_v1.pine`
SHA-256: `83c1babe978173856bebf5beab5668465955c4a7902ae5f1f90e604f0fe58ef7`.

Additive capture patch: `reference/pine_smc/TV_CAPTURE_INSTRUMENTATION_V1.pine.txt`
SHA-256: `4901facc8365692b51397eabc34d232d7de86a78e6f3c28e2eb894df81a160ed`.

The instrumentation adds 47 Data Window plots after the existing MTF arbitration booleans. It does not feed values back into signal calculations. The full instrumented script still requires compilation in TradingView before relying on its outputs. Use the complete instrumented script OR insert the patch once into the exact original source; never do both. Removing the exact patch restores the original Pine source byte-for-byte.

## Default method — TradingView Basic / manual spot checks

1. Add the instrumented script to a TradingView chart and confirm that it compiles. If the editor reports a compile or plot-limit error, record it; do not delete arbitrary plots or alter source signal logic to force compilation.
2. Select the exact Binance USDⓈ-M perpetual ticker used by the bot. Example mapping: TradingView `BINANCE:BTCUSDT.P` to Binance USD-M contract symbol `BTCUSDT`. Do not use spot or another exchange.
3. Use chart timeframe **1 minute** for the baseline checks. The Pine `request.security()` lookahead behavior depends on chart timeframe; 1m is the audited recommended context. Record chart timeframe explicitly.
4. Record chart timezone. UTC is recommended. Keep candle timestamps as UTC candle-open times (Unix milliseconds) in the replay records.
5. Confirm all 49 effective Pine inputs. Record whether defaults were confirmed or transcribe every override exactly. The Pine Inputs panel is the authority for effective values.
6. Fetch historical M1/M5/M15 OHLCV from Binance USDⓈ-M Futures using the existing `HistoricalKlineService` / Kline storage path. Do not create a duplicate downloader. Preserve the loaded-history prefix used by each Pine source timeframe; do not truncate to only the final `warmupBars` candles when later Pine built-in indicators are being replayed.
7. Select a specific chart candle and read the relevant `DIVA_...` plot values in TradingView's Data Window. Record exact displayed field names and values as text, along with the selected candle's UTC open timestamp. Save a screenshot of the chart/Data Window as supporting evidence.
8. Capture positive signal observations and state transitions in different records. Distinguish the Pine source event candle from the chart bar on which the shifted output becomes visible. The instrumented output exposes evaluation time and event time separately.
9. Record capture time, ticker, symbol, chart timeframe, timezone, Pine and instrumentation hashes, all effective inputs, source candle timestamp, exact observed fields, and screenshot filename.

A manual spot check is a narrow, sampled observation. It may verify the fields actually recorded at the selected timestamp, but it cannot prove that no other signals occurred in an interval. Do not set complete-coverage or no-other-signals assertions from visual sampling.

Suggested record shape (illustrative placeholders only; do not copy placeholder values as evidence):

```json
{
  "pine_source_sha256": "<original Pine SHA-256>",
  "instrumented_script_sha256": "<instrumented Pine SHA-256>",
  "tradingview_ticker_id": "BINANCE:BTCUSDT.P",
  "binance_symbol": "BTCUSDT",
  "chart_timeframe": "1",
  "chart_timezone": "Etc/UTC",
  "captured_at_utc": "<ISO-8601 UTC timestamp>",
  "effective_inputs_source": "TRADINGVIEW_DEFAULTS_CONFIRMED",
  "effective_inputs": {"<all 49 Pine input names>": "<exact values>"},
  "selected_candle_open_time_ms": 0,
  "observed_data_window_fields": {"DIVA_<exact field name>": "<exact displayed value>"},
  "screenshot_file": "<supporting evidence filename>"
}
```

Do not approximate numeric values from a marker position. A screenshot supplements exact text values; it does not establish full historical coverage.

## Optional method — machine-readable TradingView CSV bundle

Keep the Unit 05C fixture v2 path for environments/accounts that legitimately expose TradingView **Export chart data**. It is optional, not a required subscription upgrade. The full procedure and strict validator remain available.

Required files for the optional v2 bundle:

| File | Chart timeframe | Required contents |
|---|---:|---|
| `tradingview_m1_with_signals.csv` | 1 minute | Native M1 OHLCV and instrumented Pine plot columns |
| `tradingview_m5_candles.csv` | 5 minutes | Native M5 OHLCV |
| `tradingview_m15_candles.csv` | 15 minutes | Native M15 OHLCV |

Use the exact ticker, chart timezone and effective input values for all three. Keep raw CSV bytes unchanged. The fixture builder records and validates SHA-256, file size, OHLCV values, timestamps, continuity, tick alignment, MTF boundaries, signal/event/OB source membership and arbitration flags.

Build and validate from the project root:

```powershell
python tools_build_pine_reference_fixture.py --manifest .\capture\capture_manifest.json --output .\capture\reference_fixture.v2.json
divatrading validate-pine-fixture --fixture .\capture\reference_fixture.v2.json --source-dir .\capture
```

See `reference/pine_smc/capture_manifest.template.json` and `docs/UNIT_05C_INTAKE_CONTRACT.md` for the full optional manifest, schema and acceptance details. Synthetic test fixtures only validate the intake machinery; they are not TradingView references.

## Parity interpretation

- Source-derived tests: verify exact translation of source expressions against deterministic, hand-constructed inputs. They are not independent TradingView parity.
- Manual TradingView spot checks: prove only the recorded fields at the recorded timestamp, subject to correct ticker, timeframe and inputs.
- Accepted full fixture: enables broader machine-readable replay comparison and explicit coverage assertions.
- No parity claim is permitted solely because unit tests pass. Report missing, unexpected and field mismatches explicitly. Do not widen tolerances just to obtain a pass.

Never interpret Pine entry/SL/TP proxies as actual exchange fills or future Dynamic Trade Management outputs.
