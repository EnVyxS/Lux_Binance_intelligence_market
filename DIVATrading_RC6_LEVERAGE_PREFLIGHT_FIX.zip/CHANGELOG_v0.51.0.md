# Changelog v0.51.0

- Added `position_accounting` primitives to aggregate independent managed signal lots by `(symbol, positionSide)` using exact `Decimal` quantities and weighted-average entry price.
- Added stable lot opening timestamps to the managed-position ledger with a backward-compatible SQLite migration.
- Added per-signal stop/TP quantity allocation plans and quantity coverage validation. These are accounting plans only; they do not claim that exchange protection orders have been verified.
- Added deterministic close-fill allocation: exact signal attribution is preferred; FIFO is an explicit fallback for externally attributed aggregate reductions.
- Added immutable `position_fill_allocations` evidence sourced from Binance `ORDER_TRADE_UPDATE` and `TRADE_LITE`, deduplicated by symbol/trade ID and mapped through durable client-order ownership.
- Added late owner backfill for the race where a User Data Stream fill arrives before the REST order response is committed. The entry halt remains latched until an operator/reconciliation workflow clears it.
- Unknown `DIVA*` fills are persisted as `UNATTRIBUTED` and latch the global entry halt. External fills are recorded separately and do not get falsely attributed to a strategy signal.
- Added `ledger.list_managed_position_groups()` and extended `runtime-status` with aggregated groups and fill-attribution counters.
- Kept the current runtime fail-closed for multiple same-side signal lots. Quantity-scoped Algo protection, sibling cancellation and multi-lot lifecycle execution remain prerequisites before enabling same-side scale-in.
- PAPER remains default. No Binance TESTNET/LIVE network calls or orders were performed.
