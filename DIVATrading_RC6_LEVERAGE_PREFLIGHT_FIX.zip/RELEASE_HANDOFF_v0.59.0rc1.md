# Release Handoff — DIVATrading v0.59.0rc1

## Summary

Consolidated integration candidate built from v0.58.0rc4. It connects account-specific exchange feasibility inputs to risk sizing/dispatch, exchange income/trade history to durable risk controls, and persisted Telegram operator controls to the autonomous runtime.

## Integrated modules

- `trading/exchange_feasibility.py`: strict account leverage bracket and fee parsing; maintenance margin and initial margin are estimates only.
- `trading/risk.py` + coordinator/dispatcher: risk-first size calculation with commission/slippage/funding reserves, current available margin and exchange tier caps. It will reject under-minimum feasible sizes; it does not enlarge a position to satisfy exchange filters.
- `execution/service.py`: per-symbol position/order checks before changing margin mode/leverage; exact symbolConfig readback; no change while symbol has exposure or open standard/Algo orders.
- `execution/income_backfill.py`: bounded 90-day income-history bootstrap, seven-day slices, recursive full-page subdivision, idempotent insert, and watermark only after success.
- `execution/trade_risk_reconciliation.py`: closed lifecycle results from attributed fill projections; USDT commissions/realized PnL; funding allocated to attributed active lots; unknown assets/income/attribution fail closed; daily Jakarta PnL and day-start equity reconstruction.
- `cli.py`: integrated startup waits for account reconciliation and completed-trade ledger readiness; BOT_ONLY account check; reads persisted control config before each candidate; Telegram control runs in a reconnecting thread while account supervision stays separate.
- `trading/control_plane.py`: owner-only risk/maxloss/leverage/margin/pause/kill commands; persisted Telegram update offset; explicit `/resetkill confirm`.

## Safety invariants

- `auto-trade-runtime` explicitly rejects `ExecutionMode.LIVE` until separate account, platform and exchange lifecycle qualification is completed.
- `.env.example` keeps LIVE, TESTNET orders, TESTNET Stage C, TESTNET order-test and automatic protection recovery flags false.
- Non-PAPER risk sizing refuses to proceed without fresh account available margin and matching symbol-specific leverage/commission inputs.
- Quantity is derived from the risk budget and is never inflated for minimum notional.
- External/unattributed fills, unsupported non-zero income types, non-USDT fee/funding without conversion, ambiguous funding and unreconciled closed lots keep the risk ledger unready.
- PAUSE/KILL block new entries; they do not blindly close or abandon existing managed positions.
- Never share API secrets, Telegram tokens or `.env`; none are shipped.

## Verification

- Source regression: 1,038 passed.
- `compileall`: PASS.
- Clean-extraction manifest + ZIP CRC + full regression are reported in `CLEAN_EXTRACTION_TEST_REPORT_v0.59.0rc1.md`.
- Build host: Linux / Python 3.13.5; Windows 10 / Python 3.12.9 exact-target validation is pending. A wheel was not built because the host interpreter does not satisfy the exact project pin.
- No actual Binance account/API session or exchange order was used. No LIVE trade was performed.

## Operator next steps

Follow `WINDOWS_DEPLOYMENT_v0.59.0rc1.md`. Run installation and full local tests first. Then, only on the dedicated account, run read-only LIVE preflight with API credentials kept in local `.env`. The read-only preflight does not enable trading. The current runtime does not support LIVE orders, so do not attempt to bypass the gate.
