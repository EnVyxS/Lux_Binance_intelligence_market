# Atomic Portfolio Risk Reservations — v0.45.0

## Purpose

Prevent independent symbol workers from spending the same remaining portfolio risk budget when they size signals from a shared or slightly stale account snapshot.

## Transaction model

- A reservation is keyed by immutable `signal_id` and persisted in SQLite.
- `reserve_portfolio_risk()` uses `BEGIN IMMEDIATE`; one writer evaluates and commits before another worker can evaluate the same ledger.
- The risk calculation uses `Decimal` text values only: exchange-reported open-risk input + all active local reservations + requested risk must not exceed `equity × max_portfolio_open_risk_pct / 100`.
- Position admission also counts exchange-observed active positions plus active local reservations against `max_positions`.
- Symbol exposure admission combines exchange-observed symbol notional, active local reservations for that symbol and the requested plan notional; the result must not exceed the configured equity/leverage-derived symbol cap.
- Repeating an active reservation at the ledger API is idempotent. The coordinator blocks a duplicate active reservation from reaching execution until intent and exchange state are reconciled; a released signal cannot silently recreate its reservation.
- Release is a separate, idempotent transaction. A coordinator convenience method emits a release event after the caller confirms the position is flat or the entry is terminal without a fill.

## Coordinator behavior

1. The existing risk manager calculates a candidate `TradePlan` from the supplied account snapshot.
2. The coordinator atomically reserves that plan's exact `risk_usdt` before passing it to execution.
3. A reservation rejection becomes a `RiskDecision(False, reason)` and no order is submitted.
4. PAPER mode releases immediately because it does not create or manage a simulated open position.
5. TESTNET/LIVE retain a reservation for pending or protected positions. Confirmed no-fill terminal entry statuses release it.
6. Any exception/ambiguous result retains the reservation. Do not manually release it until exchange/local reconciliation proves that no position or live entry order remains.

## Important conservative limitations

- v0.44 `AccountSnapshot.open_risk_usdt` currently equals the absolute notional of every open position, not stop-distance loss. This intentionally overstates risk and can reject otherwise viable trades until verified stop-loss reconciliation computes true exposure.
- A filled position can be represented both by exchange snapshot exposure and an active local reservation. The current implementation may therefore double-count portfolio risk, position count and symbol notional and under-allocate. This is deliberately conservative; it is not a final position-risk accounting model.
- TESTNET/LIVE direct execution calls are blocked without a matching active reservation. PAPER remains available for isolated service tests, but production routing should still pass through the coordinator.
- The atomic guarantee applies to workers sharing the same SQLite database file on a supported local filesystem. It does not serialize manual orders or other bots that do not use this ledger.
- Account state is still an external snapshot. A separate freshness gate and exchange event reconciliation remain necessary to prevent stale/manual account changes from being treated as current truth.
- The reservation is not itself an exchange order, stop, margin hold or guarantee of fill price.

## API

- `ExecutionLedger.reserve_portfolio_risk(...) -> RiskReservationResult`
- `ExecutionLedger.release_risk_reservation(signal_id, reason) -> bool`
- `ExecutionLedger.active_risk_reservations() -> list[dict]`
- `ExecutionLedger.active_reserved_risk_usdt() -> Decimal`
- `MultiPairExecutionCoordinator.release_position_risk_reservation(signal_id, reason) -> bool`

Release must be called only after a reconciler has confirmed the terminal/flat condition. No automatic live-position release worker is included yet.
