# v0.57.0A — Binance USDⓈ-M Demo Futures Environment & Qualification Harness

## Scope

Stage A delivers a local, read-only preflight harness for Binance USDⓈ-M Demo Futures. It prepares the environment for later `/fapi/v1/order/test` and controlled order-lifecycle tests. It is not an actual exchange qualification result because this build did not use user credentials or connect to Binance.

## Pinned endpoints

| Surface | Endpoint |
|---|---|
| Demo Futures REST | `https://demo-fapi.binance.com` |
| Demo market stream | `wss://demo-fstream.binance.com/market` |
| Demo private stream base | `wss://demo-fstream.binance.com/private` |
| Demo User Data Stream URL shape | `/private/ws?listenKey=<listenKey>&events=<event-list>` |
| LIVE Futures REST | `https://fapi.binance.com` |
| LIVE private stream base | `wss://fstream.binance.com/private` |

The USDⓈ-M Futures WebSocket URL migration notice describes the Public/Market/Private routing and the private `listenKey + events` form; legacy URLs were retired on 2026-04-23. DIVA constructs the private URL with the account/order events it consumes. Demo REST and WebSocket hosts are pinned separately from LIVE.

References:
- Binance USDⓈ-M Futures WebSocket System Upgrade Notice (2026-03-06): https://www.binance.com/en/support/announcement/detail/ebf9b0aa9eca4ff3804eef6fb09ba32a
- Binance USDⓈ-M Futures General Info / Demo base endpoints: https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/general-info
- Binance USDⓈ-M Futures Change Log (2026-08-26 `userTrades` history update): https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/change-log

## Read-only command

Prepare `.env` from `.env.testnet.example` inside the extracted project directory. Set:

```dotenv
DIVA_EXECUTION_MODE=TESTNET
DIVA_ENABLE_TESTNET_ORDERS=false
DIVA_LIVE_TRADING_ENABLED=false
BINANCE_API_KEY=<local-demo-api-key>
BINANCE_API_SECRET=<local-demo-api-secret>
```

Use Demo Trading credentials only. Keep withdrawal permission disabled. Never paste credentials into chat, command-line arguments, screenshots, logs, or source control. A Windows convenience runner `TESTNET_PREFLIGHT_WINDOWS.bat` invokes the same command from the project directory.

Run:

```powershell
.\.venv\Scripts\python.exe -m divatrading testnet-preflight --symbols BTCUSDT
```

The command performs:

1. Exact TESTNET environment and REST host pin validation before network I/O.
2. Public REST ping and server-time offset/round-trip validation.
3. Demo `exchangeInfo` parsing and selected symbol validation as a trading USDT perpetual with valid price, quantity and notional filters.
4. Signed account GET validation, `canTrade`, single-asset margin profile, positive available balance and position-mode parsing.
5. Read-only scans for non-flat positions, open standard orders and open Algo orders.
6. Sanitized JSON output; API key/secret are not included.

The command does **not** create/keepalive/close a listenKey, connect a WebSocket, change leverage or margin mode, place/cancel orders, or call any POST/PUT/DELETE endpoint. Stage A can be run while `DIVA_ENABLE_TESTNET_ORDERS=false`.

## Interpreting the result

- `READY_FOR_TEST_ORDER_VALIDATION`: the read-only checks passed and the selected symbols have valid exchange metadata. It is not proof of order permission, successful WebSocket connectivity, or successful order execution.
- `BLOCKED_CONFIGURATION`: execution mode is not TESTNET or LIVE opt-in is present.
- `BLOCKED_CREDENTIALS`: local Demo API credentials are missing.
- `BLOCKED_ENDPOINT_ISOLATION`: client is not pinned to the approved Demo REST host.
- `BLOCKED_PREFLIGHT`: one or more account, mode, balance, symbol, timing or cleanliness checks failed.

A clean account is required for the first exchange qualification: no open positions, standard orders or Algo orders. If the account has any, resolve them manually in the Demo UI before rerunning; the harness never cancels or closes them.

The `TRADE_PERMISSION` check is intentionally `WARN` in Stage A. A signed read-only account query does not prove order permission. Stage B uses the signed `/fapi/v1/order/test` endpoint, which validates an order request without placing an exchange order. Actual order lifecycle tests remain a later, explicit stage.

## Current User Trades history correction

Binance's USDⓈ-M change log states that the `GET /fapi/v1/userTrades` history availability changed from six months to three months effective 2026-08-26. DIVA's backfill bootstrap now caps at 90 days; explicit larger time windows are rejected. Existing local SQLite fill records remain available independently of Binance's REST history retention. Trades older than the exchange query window require an operator archive/export for historical reconstruction.

## Safety boundaries

- PAPER remains the default runtime mode.
- Stage A uses no exchange write calls and no orders.
- TESTNET order opt-in remains `false` during Stage A.
- LIVE routing remains disabled; no LIVE keys should be placed in `.env` for this work.
- Same-side TESTNET/LIVE scale-in remains blocked until multi-lot Algo protection is qualified on Demo exchange.
- No actual Binance credential, network, WebSocket or order test was executed for this release.
- Build environment: Linux / Python 3.13.5. Project pin `requires-python ==3.12.9` is unchanged; Windows 10 qualification remains pending.
