# Next Task — After v0.57.0C

1. Extract v0.57.0C to a new folder and preserve the local `.env` separately.
2. Keep `DIVA_ENABLE_TESTNET_ORDERS=false`, `DIVA_ENABLE_TESTNET_STAGE_C=false`, and `DIVA_LIVE_TRADING_ENABLED=false` until explicitly ready to run Stage C.
3. Run Stage C only when supervised: enable both TESTNET flags locally and run the one-symbol BTCUSDT command in `TESTNET_STAGE_C_V057C.md`.
4. Stop the runtime after the first useful qualification session. Submit only sanitized logs.
5. Verify actual entry acknowledgement, User Data Stream fill, REST position reconciliation, and protective Algo order confirmation. Any missing evidence means Stage C remains pending.
6. Continue to Stage D only after Stage C is confirmed.
