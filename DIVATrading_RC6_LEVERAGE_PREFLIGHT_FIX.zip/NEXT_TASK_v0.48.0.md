# Next Task — Managed Position Supervisor (v0.49.0)

1. Build a per-managed-position supervisor that consumes fresh Mark Price updates and evaluates the persisted `ManagedPositionState` with `PositionLifecycleEngine` on deterministic event/time boundaries.
2. Dispatch PARTIAL_TP and MOVE_STOP actions through `PositionLifecycleExecutionAdapter`; persist proposed watermark/state separately from exchange-confirmed state so restart cannot skip an action.
3. Add explicit strategy/structural-invalidation exit and separately configured emergency close flows, with One-way/Hedge close semantics, exact lot filters, deterministic IDs, REST fill confirmation and no duplicate POST after ambiguity.
4. Enforce the current supported contract: one active DIVA-managed signal per symbol/position side until aggregate position accounting is implemented. Prevent concurrent workers from opening a second managed leg that would make per-signal quantity reconciliation ambiguous.
5. Reconcile event-driven and periodic position loops; ensure user-stream event callbacks cannot race duplicate close/replace actions.
6. Keep reservations active until verified flat and all DIVA-linked orders are absent; preserve manual/safety entry halt across restarts.
7. Add deterministic restart, reconnect, race, LONG/SHORT, One-way/Hedge, precision and failure-injection tests.
8. Integrate the supervisor into the multi-pair live runtime and add operator-readable position/action status. Do not add dashboard/Telegram ahead of core lifecycle correctness.

PAPER remains default. Do not claim TESTNET/LIVE readiness until actual exchange integration tests, target Windows validation and all core safety gates are complete.
