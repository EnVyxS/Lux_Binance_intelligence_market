# Test Report — v0.58.0rc2

## Source-tree regression

- Command: `PYTHONPATH=src pytest -q`
- Result: **1,013 passed**.
- Focused signal/Kronos/database/planner suite: 50 passed.
- Focused CLI/Kronos/Signal Center suite: 18 passed.
- `python -m compileall -q src tests`: passed.
- CLI root help and `kronos-status`, `kronos-install`, `kronos-forecast`, `kronos-evaluate`, `signal-history`, `market-runtime`, `telegram-control` help: passed.
- Package and new module imports: passed; version reports `0.58.0rc2`.

## What tests exercise

- Schema v6 creation, idempotent initialization and forward migrations from v1-v4, including preservation of existing market data/trade rows.
- Kronos input data must be Binance USD-M M5, closed, strictly chronological, unique and contiguous; minimum context and horizon bounds are enforced.
- Forecast identity includes exact candle payload and inference/model revisions/configuration.
- Kronos inference uses an injected fake predictor for deterministic adapter/evaluator tests. Missing model installation fails cleanly and does not make the rest of the app import PyTorch.
- Exact future closed-M5 timestamp matching for evaluation; no gaps are filled.
- Telegram chart rendering with/without Kronos, actual/forecast visual separation, M5 gap rejection, signal persistence/deduplication, successful mocked `sendPhoto`, and ambiguous mocked transport failure behavior.
- CLI `SIGNAL_ONLY` options and validation.

## Limits

Mocks and local fixtures only. No real model download/inference, Telegram Bot API send, authenticated Binance request, account setting mutation, LIVE order/Algo order, or Windows 10/Python 3.12.9 execution occurred.

Build host: Linux x86_64 / Python 3.13.5. Target runtime: Python `==3.12.9` on Windows 10 x64.
