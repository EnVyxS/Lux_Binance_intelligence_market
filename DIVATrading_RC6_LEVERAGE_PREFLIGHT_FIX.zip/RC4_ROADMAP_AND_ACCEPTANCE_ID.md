# DIVATrading Binance Futures 0.59.0rc4 — roadmap implementasi dan acceptance

**Status:** kandidat keselamatan dan kesiapan offline. **BUKAN** persetujuan untuk autonomous LIVE.  
**Basis:** ZIP v0.59.0rc3 yang diaudit sebelumnya.  
**Tanggal:** 15 November 2026.  
**Target:** Binance USDⓈ-M Futures; Windows 10 x64, Python 3.12.9, RAM 8 GB.

## Tujuan dan batas arsitektur

Pertahankan pipeline strategi SMC V2 M1/M5 dengan konteks M15, per-symbol market-data graph, risk/portfolio coordinator, idempotent exchange client IDs, STOP/TP Algo, SQLite ledger, account reconciliation, Telegram control, dan isolasi PAPER/TESTNET/LIVE. Tidak ada backtest atau kalibrasi edge baru dalam RC4; tidak ada klaim WR/PF/expectancy.

## Peta pekerjaan berbasis exit criteria

| Gate | Pelaksanaan | Status | Bukti penutupan yang masih dibutuhkan |
|---|---|---|---|
| G0 Audit | Inventaris source, status roadmap, baseline regresi | SELESAI SOURCE | RC3 baseline 1.055 tes; referensi AUDIT_RC3_STATUS_DAN_HANDOFF.md |
| G1 Execution risk | Audit risiko setelah fill, harga 0/unreported, validasi bid/ask, depth, spread, adverse slippage | IMPLEMENTASI RC4, pengujian offline | Response Binance Demo nyata dan skenario ekstrem |
| G2 Reconciliation | Clear transient halt secara atomic CAS, cegah risk latch dibuka oleh backfill | IMPLEMENTASI RC4, pengujian offline | Injeksi kegagalan koneksi account/exchange |
| G3 Strategy robustness | Walk-forward OOS, biaya aktual, edge per regime, batas drawdown | BELUM TERVERIFIKASI | Dataset, asumsi biaya dan laporan OOS yang dapat diaudit |
| G4 Windows release | Installer existing, test existing, diagnostic read-only RC4 | IMPLEMENTASI, BELUM DIUJI WINDOWS TARGET | RUN_RC4_DIAGNOSTICS_WINDOWS.bat pada PC pengguna |
| G5 Demo E2E | Demo single symbol: read-only → order/test → Stage C → STOP/TP → exit/flat → restart | MENUNGGU PENGUJIAN AKUN | Log exchange (redacted), exchange-truth, status setiap order/protector |
| G6 Real account preflight | Akun BOT_ONLY, permission, symbol filters, margin mode, IP allowlist, risk cap | MENUNGGU USER-LOCAL PREFLIGHT | Status read-only dan operator approval |
| G7 Autonomous LIVE | Release terpisah setelah G0-G6 lulus | TERKUNCI | Release gate tertulis, rollback/kill-switch, pengawasan awal |

## Perubahan source RC4

- `trading/post_fill_risk.py`: per-fraction reservation audit berdasarkan **harga fill aktual**, volume kumulatif, struktur SL/TP, dan biaya yang disisihkan. Risiko melebihi reservasi, `avgPrice=0`, hilang, tidak finite, atau geometri tidak valid akan melatch `entries_halted`. Protektor yang terverifikasi tidak dibatalkan oleh pemeriksaan ini.
- `execution/service.py`: audit dipakai pada direct order dan post-crash entry reconciliation. Untuk harga fill yang belum valid, pencatatan posisi sementara memakai harga plan positif dan mewajibkan resolusi exchange-truth sebelum entry baru (bukan dianggap fill-price valid).
- `trading/entry_quote_guard.py`: order-book snapshot (bid/ask) dengan timestamp, spread cap, dan estimasi VWAP/impact untuk MARKET berdasarkan top 5 depth. LIMIT menolak book corrupt/stale/wide, tapi tidak menolak retracement LIMIT hanya karena harga saat ini berbeda dari harga limit.
- `execution/binance_private.py`: GET public depth pada endpoint environment yang sama dengan private execution, tetap read-only; jam yang disinkronkan dengan server Binance.
- `execution/ledger.py` dan `execution/reconciliation.py`: compare-and-swap clear transient backfill halt; mencegah proses lama menghapus halt risiko/operator baru.
- `service.resume_new_entries`: tidak dapat membuka halt postfill selama managed position masih OPEN; pada non-PAPER harus ada readiness akun segar (di luar efek halt itu sendiri).
- `.env.testnet.example`: quote guard wajib dinyalakan pada autonomous Stage C TESTNET; khusus LIVE tetap dikunci di CLI tanpa qualification.
- `tools/rc4_acceptance.py`, `RUN_RC4_DIAGNOSTICS_WINDOWS.bat`: offline Windows diagnostics yang **tidak** mengirim order atau memakai secret.

## Cara memeriksa di Windows

1. Ekstrak ke direktori baru; jalankan `INSTALL_WINDOWS.bat` (membutuhkan Python **3.12.9 x64**).
2. Jalankan `TEST_WINDOWS.bat`, kemudian `RUN_RC4_DIAGNOSTICS_WINDOWS.bat`. Simpan `logs/rc4_local_acceptance.json` yang berisi hasil non-rahasia.
3. Untuk lingkungan aman, mode PAPER tetap default. Gunakan file `.env.testnet.example` sebagai panduan sebelum menyetel Demo.
4. Jika kualifikasi DEMO Stage C disetujui secara manual pada PC, gunakan hanya **satu simbol**, batas risk 0,10% per trade, 0,25% portfolio, dan quote guard enabled. Ini mengirim **order sungguhan ke Demo**, walau dananya bukan dana real.
5. Baru setelah Demo dan pengujian OOS lulus, jalankan `live-read-only-preflight` dari akun real dengan API key restricted local (tanpa izin withdrawal). Command ini *tidak* memperbolehkan trade.

Jangan menyimpan API secret di ZIP, log, screenshot, atau percakapan. Jangan menetapkan `DIVA_LIVE_TRADING_ENABLED=true` untuk autonomous trading sekarang: CLI tetap menolak LIVE.

## Known limitations / risiko residual

- Depth snapshot dan VWAP top-of-book bukan jaminan eksekusi; market dapat bergerak sebelum POST. Kontrol postfill hanya menahan order berikutnya dan **tidak otomatis memperkecil posisi yang baru over-risk**.
- Rekonsiliasi avgPrice belum memverifikasi setiap per-trade commission, fee asset conversion, dan funding dalam guard post-fill; ledger lama mengelola komponen tersebut terpisah.
- Ketepatan jumlah proteksi, partial TP, trigger fill, modal, margin dan stop saat exchange failure masih memerlukan demonstrasi empiris.
- Trade yang gagal/terlambat tidak boleh diklaim aman hanya karena tes mock lulus. Endpoint Binance Demo/Live berbeda dan harus diuji terpisah.
- Pengujian Docker/Linux atau Python 3.13.5 **tidak menggantikan** validasi Windows 10/Python 3.12.9.
- LIVE belum diaktifkan. Penyelesaian source dan pemenuhan syarat deployment adalah dua milestone yang berbeda.
