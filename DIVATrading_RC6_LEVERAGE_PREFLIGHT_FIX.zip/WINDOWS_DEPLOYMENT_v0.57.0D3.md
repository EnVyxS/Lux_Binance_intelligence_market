# Windows Deployment Notes — v0.57.0D3

## Target
- Windows 10 x64.
- Exact Python 3.12.9 x64 (enforced by project metadata and installer).
- Keep project, virtual environment, logs, data and temporary build/test directories on a drive with sufficient free space.
- For a constrained C: drive, use a project-drive TEMP/TMP directory before running installer/tests; C1 introduced `.diva_temp` on the project drive for temporary build/test operations.

## Installation and qualification
1. Extract the release ZIP into a new directory; do not overwrite prior C1/D2 directories.
2. Copy `.env` locally from a trusted backup. Never put `.env` in release ZIPs or share it.
3. Run `INSTALL_WINDOWS.bat`.
4. Run `TEST_WINDOWS.bat` and retain the complete output.
5. Confirm `pip check` reports no broken requirements.
6. Keep all order, Stage C, protection-recovery and LIVE flags false during installation qualification.

## Stage D3 recovery policy
- `DIVA_ENABLE_PROTECTION_RECOVERY=false` by default.
- Enabling it is a separate TESTNET-only authorization. It is not needed for code installation or offline regression.
- D3 actual Algo-trigger/cancel/residual behavior is mock-tested; do not treat it as real-exchange acceptance.

## Qualification boundary
D3 was built and regression-tested on Linux / Python 3.13.5. Exact D3 Windows 10 / Python 3.12.9 qualification remains pending. No actual Binance Demo/LIVE order, cancellation, or Algo mutation was performed by the release build.
