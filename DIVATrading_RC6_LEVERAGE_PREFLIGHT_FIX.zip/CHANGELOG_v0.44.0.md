# v0.44.0
- Added exchange-truth account state snapshots for Binance USD-M Futures.
- Added Decimal-safe position snapshots and conservative notional exposure reservation.
- Captures standard and conditional open orders for reconciliation consumers.
- Added fail-closed handling for invalid financial fields.
