# Test Report — v0.57.0B

## Environment

- Build host: Linux x86_64, Python 3.13.5.
- Project requirement remains `==3.12.9`; Windows 10 target was not tested in this environment.

## Source regression

- `pytest -q --ignore=tests/test_stage6b_workflow.py`: **941 passed**.
- `pytest -q -p no:ddtrace tests/test_stage6b_workflow.py`: **7 passed**.
- Total: **948 passed across two runs**. The all-in-one invocation exceeded the execution window while running the legacy workflow module; that module passed independently with the tracing plugin disabled after it intermittently stalled pytest process shutdown. No failures were reported in either partition.
- Focused Stage B + Stage A TESTNET regression: **38 passed**.
- `python -m compileall -q src tests`: PASS.
- CLI help checks for `divatrading`, `testnet-order-test`, and `testnet-preflight`: PASS.

## Stage B coverage

- HMAC-SHA256 signature construction, timestamp/recvWindow, API-key header and Demo endpoint pinning.
- LIMIT/MARKET request normalization with Decimal precision and current exchange metadata.
- `LOT_SIZE` / `MARKET_LOT_SIZE`, quantity bounds and step alignment.
- LIMIT tick-size/price bounds and local notional rules.
- MARKET notional left to the exchange test endpoint rather than inferred from last price.
- One-way/Hedge position-side validation.
- Two independent gates: local `DIVA_ENABLE_TESTNET_ORDER_TEST=true` and CLI `--confirm-test-order`; actual order flag must remain false.
- No automatic retry for signed write requests; transport outcome is classified as unconfirmed.
- Secret, API key, signature, and signed URL redaction in diagnostics and error paths.
- Exchange HTTP/API error and transport classification.

## Clean extraction

The final archive was extracted to an empty directory. The same partitioned regression passed: 941 tests excluding the legacy workflow module and 7 workflow tests independently with `-p no:ddtrace`, for 948 total; focused Stage B/Stage A suite: 38 passed; compileall and all CLI help checks: PASS. See `CLEAN_EXTRACTION_TEST_REPORT_v0.57.0B.md`.

## Validation boundary

All automated tests use fixtures, deterministic local time, local SQLite, and mocked HTTP transport. No real Binance credentials, signed Demo request, `/fapi/v1/order/test`, Demo WebSocket, actual Demo order, or LIVE request was used. The authenticated Demo validation remains pending until the user can run the package locally with newly rotated credentials.
