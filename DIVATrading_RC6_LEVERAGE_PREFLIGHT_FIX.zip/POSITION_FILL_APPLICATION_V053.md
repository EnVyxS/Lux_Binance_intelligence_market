# Per-Signal Position Fill Projection — v0.53.0

## Evidence sources

- Binance `ORDER_TRADE_UPDATE` carries detailed execution and fee fields.
- Binance `TRADE_LITE` provides a compact trade event and may arrive before its detailed counterpart.
- The ledger deduplicates fills by `(symbol, tradeId)` and enriches an existing compact fill with detailed fields rather than counting it twice.
- Ownership is resolved first through the deterministic client order ID and then through the standard matching-engine exchange order ID. If the fill arrives before its owner order is registered, a later order registration backfills ownership and rebuilds the projection.

## Transactional projection

`ExecutionLedger.apply_position_fill_allocations()` rebuilds attributed fill projections under a SQLite `BEGIN IMMEDIATE` transaction. It writes unique fill-application records and a per-signal projection containing:

- Entry quantity and entry notional.
- Close quantity and remaining net quantity.
- Decimal weighted-average entry price.
- Commission totals grouped by fee asset, including signed rebates.
- Realized PnL grouped by contract PnL denomination (USDT for this USDT-margined project), not by commission asset.
- Fill count and projection timestamp.

A close quantity exceeding known attributed open quantity is rejected, latches the global entry halt, and raises an error. Unknown or conflicting internal fill ownership also fails closed.

## Runtime integration

- New `ORDER_TRADE_UPDATE` / `TRADE_LITE` events trigger projection refresh in the User Data Stream processor.
- Late order ownership registration backfills previously unassigned fills and refreshes the projection.
- Startup recovery rebuilds fill projections before resuming pending lifecycle actions.
- Projections are accounting evidence only. They do not apply fill deltas directly to `managed_positions.quantity`, which remains governed by REST-observed exchange position state to avoid double application.

## Important remaining gap

This release does not yet page Binance REST `/fapi/v1/userTrades` history to recover events missed during a stream outage. Until that is implemented, stream continuity gaps must not be treated as fully reconciled. Keep same-side multi-signal execution blocked and retain fail-closed entry readiness on unknown or incomplete evidence.
