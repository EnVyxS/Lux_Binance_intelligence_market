# Test Report — v0.57.0C1

## Operator Windows validation (functional source)

Target: Windows 10 64-bit, Python 3.12.9 64-bit.

- Full regression: **952 passed** in 904.90 seconds; the supplied terminal output showed no failed or skipped tests.
- `tests/test_position_supervisor.py`: **10 passed** in 87.03 seconds.
- `tests/test_historical_replay_stage6a.py`: **16 passed** in 6.15 seconds.
- `tests/test_stage6b_workflow.py`: **7 passed** in 79.48 seconds.
- Two targeted SQLite lifecycle tests: **2 passed** in 12.98 seconds.
- Two formerly failing async supervisor tests: **2 passed** in 24.51 seconds.
- `pip check`: `No broken requirements found`.
- `compileall`, coordinator import, CLI help and execution-flag checks passed in the operator's working tree.

These results were supplied from the operator's PC. They establish regression evidence for the functional source changes in the C1 tree, not external exchange integration.

## Release-environment verification

- Python syntax compilation: run on the extracted release tree.
- CLI help: run on the extracted release tree under the available build interpreter.
- Wheel build: checked with setuptools 82.0.1 on the available Python 3.13.5 build host. `--ignore-requires-python` was used only to inspect the wheel build; wheel metadata retains `Requires-Python: ==3.12.9`. This does not qualify Python 3.13 as a supported runtime.
- ZIP CRC and clean extraction: checked.
- Sensitive-file audit: `.env`, `.venv`, database, cache, log, backup and generated egg-info are excluded; example credentials remain blank/placeholders.

The packaging environment is Linux / Python 3.13.5, not the project's pinned Python 3.12.9 target. The release environment therefore does not claim to reproduce the Windows full regression run.

## Not tested / not claimed

- No actual C1 Stage C Demo entry order, matching-engine acknowledgement, fill, protective Algo order, position recovery or end-to-end Demo lifecycle was executed by the release builder.
- No LIVE exchange call or order was executed or authorized.
