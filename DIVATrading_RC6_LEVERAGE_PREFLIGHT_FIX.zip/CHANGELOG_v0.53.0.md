# Changelog v0.53.0 — Protective Partial-Fill Reconciliation & Transactional Fill Projection

**Date:** 2026-11-13

## Implemented

- Deterministic reconciliation of protective USDⓈ-M conditional Algo partial execution using `actualOrderId` to identify the triggered matching-engine order.
- Validation of symbol, matching-engine order ID, closing side, `positionSide`, account mode, `executedQty`, and REST-observed residual position quantity.
- Cancellation and terminal-state confirmation of a still-active protective market-order remainder before residual protection is re-established.
- Quantity-scoped residual STOP/TP replacement; both replacements must be verified before the previous sibling protective order is canceled.
- Replay-safe parent lifecycle action and child `RESIZE_PROTECTION` actions, including query-first recovery and deterministic identifiers.
- SQLite transactional per-signal fill projections from `ORDER_TRADE_UPDATE` and `TRADE_LITE`, with trade-ID deduplication, event enrichment, exact Decimal quantities/notional, weighted entry, commissions by fee asset, and realized PnL denominated in USDT.
- Fill ownership resolution by client order ID and standard matching-engine exchange order ID, including late ownership backfill.
- Startup projection rebuild and automatic projection refresh after new stream fill evidence or late order ownership registration.
- Fail-closed handling of unknown/conflicting DIVA fills, close quantity exceeding known open quantity, and REST/local residual mismatch.

## Validation

- Full regression: 863 passed.
- Focused lifecycle execution and User Data Stream tests: 64 passed.
- `compileall`: passed.
- `python -m divatrading --help`: passed.
- Package import/version check: 0.53.0.
- Tests use local SQLite and mocked exchange clients. No real Binance TESTNET/LIVE API request, private WebSocket session, or exchange order was executed.

## Explicitly not included

- REST historical `userTrades` backfill/recovery for stream gaps.
- Same-side multi-signal execution or the full multi-lot position supervisor.
- Autonomous SMC V2 TradePlan-to-entry dispatcher.
- End-to-end TESTNET qualification or LIVE execution.
- Windows 10 / Python 3.12.9 hardware/runtime validation.
