# Next Task — After v0.57.0D3

1. Stage D4: broaden restart/disconnect qualification across the full account runtime, including stream reconnect during `ALGO_UPDATE`, late `ORDER_TRADE_UPDATE` fill allocations, REST user-trade backfill, and multi-lot aggregate protection replacement.
2. Build a deterministic full lifecycle simulation: entry fill -> paired STOP/TP -> Algo trigger -> child partial/full/zero fill -> cancel remainder -> residual protection -> restart replay -> flat finalization.
3. Add property/invariant tests for quantity conservation across per-lot fills, aggregate One-way/Hedge positions, commissions/realized PnL, and risk reservation transitions.
4. Keep D2/D3 automatic protection recovery disabled by default. Only explicitly opt in on TESTNET after exact release qualification; never enable it in LIVE.
5. Actual C1 Stage C entry/fill/protection evidence remains deferred. After D4, complete one supervised single-pair Demo cycle before expanding symbols or qualifying same-side scale-in.
6. Stage E: full E2E and multi-lot qualification, then 0.58 Windows deployment/release qualification.
7. LIVE remains disabled and unauthorized.
