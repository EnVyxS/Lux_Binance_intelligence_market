# Next Task after v0.51.0

The next milestone must connect the SMC V2 TradePlan pipeline to autonomous entry execution while completing safe multi-lot exchange semantics. Priority order:

1. **Quantity-scoped protective Algo orders:** implement STOP/TP quantity per signal allocation; never combine quantity with `closePosition=true`; correctly handle One-way vs Hedge Mode; verify exact exchange filters and total protection coverage.
2. **Sibling-order lifecycle:** on a stop/TP fill, cancel or resolve the paired protective order deterministically; reconcile partial fills, race conditions, retries and ambiguous submissions without over-closing.
3. **Fill reconciliation:** merge immutable User Data Stream fills with REST order/trade history, deduplicate by exchange trade ID and atomically update signal-lot quantities; unknown DIVA fills must remain hard-stop.
4. **Multi-lot supervisor:** manage multiple signal states under one `(symbol, positionSide)` worker without comparing each lot to the whole exchange quantity; allocate partial close and exit fills to the correct signal.
5. **Autonomous entry dispatcher:** approved SMC TradePlan -> atomic global risk reservation -> exchange-filter normalization -> idempotent entry -> fill confirmation -> quantity-scoped protection -> account reconciliation. Keep PAPER as default and require explicit TESTNET/LIVE opt-in.
6. Add actual Binance USDⓈ-M Futures TESTNET integration tests, then Windows 10 / Python 3.12.9 / 8 GB deployment validation.
7. Telegram notifications and allow-listed operator control may follow after core execution path is safe; no UI-only milestone should displace the entry dispatcher.

Do not enable same-side scale-in until steps 1–4 pass deterministic regression and TESTNET integration.
