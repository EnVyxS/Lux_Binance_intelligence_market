# Test Report — DIVATrading v0.42.0

**Date:** 2026-11-12  
**Environment:** Linux x86_64 / Python 3.13.5  
**Scope:** offline source-level regression and clean-extraction verification

## Original working tree

| Check | Result |
|---|---|
| `pytest -q` | **735 passed in 10.15s** |
| `python -m compileall -q src` | PASS |
| `PYTHONPATH=src python -m divatrading --help` | PASS |
| `PYTHONPATH=src python -m divatrading market-runtime --help` | PASS |
| Import `BinanceFeedGraphConfig`, `BinancePublicFeedFactory` | PASS |
| Package version | `0.42.0` |

The automated suite is offline and fixture/mock based. It covers graph configuration, strict metadata binding, and feed-factory symbol eligibility in addition to the existing regression suite.

## Runtime limitations

- No public Binance WebSocket was connected during this build.
- No private API key or account was used.
- No order was submitted, modified or cancelled.
- No Windows target-PC execution was performed.
- This report does not establish profitability, fills, slippage, fee handling or live operational stability.
