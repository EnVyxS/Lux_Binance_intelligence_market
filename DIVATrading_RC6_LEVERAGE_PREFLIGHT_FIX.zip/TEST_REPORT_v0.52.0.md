# Test Report v0.52.0

## Regression

- Baseline before implementation: **850 passed**.
- Focused lifecycle/User Data Stream/supervisor suite after quantity-scoped resize: **64 passed**.
- Final full project suite: **855 passed**.
- `python -m compileall -q src tests`: PASS.

## New/updated coverage

- Initial STOP/TP protections are quantity-scoped and mode-aware.
- One-way protections carry `reduceOnly=true`; Hedge Mode protections carry `positionSide` and omit `reduceOnly`.
- Exact REST verification rejects mismatched mode/quantity/order identity.
- Partial TP fill resizes both remaining protections to the residual quantity.
- Partial structural market-exit fill resizes both remaining protections and retains the risk reservation.
- Repeated resize requests reuse deterministic action/client IDs and do not duplicate submissions.
- Partial TP sequences resize protections repeatedly as the signal lot quantity changes.
- Trigger events in NEW/PENDING state are not interpreted as fills; residual positions retain the sibling order and latch an entry halt.

## Tooling / environment

- Archive extraction and test details are in `CLEAN_EXTRACTION_TEST_REPORT_v0.52.0.md`.
- Target project interpreter is Python 3.12.9; current build host is Linux / Python 3.13.5. No Windows validation was performed.
- Ruff was not run if not installed in the environment.
- No Binance TESTNET/LIVE API calls, WebSocket sessions, or orders were performed. These are deterministic local tests, not exchange integration certification.
