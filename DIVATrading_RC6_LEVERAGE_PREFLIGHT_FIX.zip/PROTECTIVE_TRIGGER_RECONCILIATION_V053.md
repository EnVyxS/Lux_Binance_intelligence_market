# Protective Algo Partial-Fill Reconciliation — v0.53.0

## Goal

Handle a triggered Binance USDⓈ-M conditional protective Algo order that executes only part of its requested quantity without leaving the managed signal lot with oversized, missing, or duplicated STOP/TP protection.

## Reconciliation sequence

1. Persist a deterministic `PROTECTIVE_TRIGGER_RECONCILIATION` action for the managed signal and source Algo order.
2. Query the Algo order and require its `actualOrderId` before treating it as an executed matching-engine order.
3. Query the standard matching-engine order by `actualOrderId`; verify symbol, order ID, closing side and `positionSide` against the managed lot.
4. Enforce account-mode semantics: One-way requires reduce-only behavior for the closing order; Hedge Mode uses the correct `positionSide` and does not accept reduce-only semantics.
5. If the matching-engine market order is still `NEW` or `PARTIALLY_FILLED`, cancel its remaining quantity and query again. Do not resize protection while an old closing remainder can still execute.
6. Require terminal order state and stable `executedQty`. Derive the expected residual from the original managed quantity minus confirmed executed quantity.
7. Query REST position state and require the observed same-side residual to equal the expected residual. Any mismatch fails closed, leaves entry halt latched and does not mutate local lot quantity or place replacement protection.
8. Persist the exact residual to the managed lot/lifecycle state using an idempotent SQLite update.
9. Create quantity-scoped residual STOP and TP replacements using deterministic client IDs. Verify both replacements through REST.
10. Only after both replacement orders are verified, cancel the old sibling protection and mark the parent action confirmed. Keep new-entry halt latched until a full account reconciliation establishes readiness.

## Recovery and idempotency

- Query-first recovery is used for deterministic Algo and standard order IDs; POST acknowledgements alone do not establish success.
- Parent action identity and child resize action payloads allow the paired protection resize to execute without allowing unrelated pending actions to bypass the per-position action claim.
- Duplicate Algo update delivery recognizes the already reconciled action and does not create replacement orders again.
- Exchange Algo IDs and matching-engine standard order IDs are separate namespaces. Only standard-order IDs are stored as `exchange_order_id` ownership links.

## Scope boundary

This module covers protective-trigger partial fills delivered through the supported private event/reconciliation path. It does not replace the pending REST historical `userTrades` backfill needed to recover fills missed while disconnected. It also does not enable multiple live signal lots on the same `(symbol, positionSide)`; that remains blocked pending the multi-lot supervisor. Validation is local/mocked, not actual TESTNET or LIVE exchange qualification.
