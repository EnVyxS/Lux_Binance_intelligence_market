# Clean Extraction Test Report — v0.59.0rc1

- Archive extracted into a new directory independent of the source working tree: PASS.
- ZIP CRC (`ZipFile.testzip()`): PASS.
- SHA-256 manifest: **476 entries verified**, zero mismatches. The manifest does not hash itself; it is included as the final archive member.
- Clean-extracted `compileall -q src tests`: PASS.
- Clean-extracted package import/version (`0.59.0rc1`): PASS.
- Clean-extracted CLI help: PASS.
- Clean-extracted full regression: **1,038 passed**.
- Archive excludes `.env`, credentials, local databases, virtual environments, caches and local model snapshots. Only `.env.example` and `.env.testnet.example` templates are included.
- Build host: Linux / Python 3.13.5. Target Windows 10 / Python 3.12.9 remains pending user-side qualification.
- Wheel build not produced: host Python 3.13.5 does not satisfy the exact `==3.12.9` project requirement; the pin was not changed.
