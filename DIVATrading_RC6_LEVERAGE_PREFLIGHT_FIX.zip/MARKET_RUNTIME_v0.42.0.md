# DIVATrading v0.42.0 — Production Multi-Pair Market Runtime

## Delivered

- Per-symbol graph factory compatible with `MultiPairLiveMarketRuntime.feed_factory`.
- Exact `SymbolInfo` injection on universe refresh; no metadata guessed from tickers.
- M1/M5/M15 Kline WebSocket + initial REST bootstrap + KlineRecoveryService reconnect/gap recovery.
- Mark Price WebSocket feed and freshness checks.
- Aggregate Trade WebSocket + REST bootstrap/recovery + SQLite repository + Delta/CVD processing.
- Depth WebSocket + shared paced REST snapshot gate + sequence-safe local book supervisor.
- Unified order-flow/depth/absorption readiness and strict `ScalpingMarketDataAdapter` capture gate.
- Complete `ScalpingMarketDataView` snapshots routed into SMC V2 Stage 2–5 by v0.41 supervisor.
- Shared REST history request pacing; bounded queues and symbol worker cap; graceful cancellation/cleanup.
- Read-only CLI: `divatrading market-runtime`.

## Runtime commands

AUTO:

```powershell
python -m divatrading market-runtime --mode AUTO --max-symbols 8
```

MANUAL:

```powershell
python -m divatrading market-runtime --mode MANUAL --symbols BTCUSDT,ETHUSDT,SOLUSDT --max-symbols 3
```

## Important operation boundaries

- This CLI uses public market-data endpoints and public WebSockets only.
- It cannot create, amend or cancel orders.
- It emits only complete, ready snapshots. A degraded component blocks capture emission.
- Default active-symbol cap is 8; upper command cap is 24. Each active symbol currently owns Kline, Mark Price, Aggregate Trade and Depth WebSocket sessions. Increase the cap only after observing PC RAM, CPU, connection stability and Binance stream behavior.
- Kline history bootstrap defaults to 500 closed bars per interval. Strategy snapshot windows are bounded to 500 candles per timeframe.
- History requests are globally serialized/paced across graphs. Depth snapshots are also serialized/paced through a shared gate.

## Not included yet

- Signal candidate qualification / priority and reason scoring.
- Dynamic Limit/Retracement and Confirmation/Market trade planner.
- Dynamic SL/TP construction and tick/lot-aware final quantity plan.
- Strategy-to-Global-Risk-to-Execution end-to-end loop.
- Continuous order/position lifecycle and exchange reconciliation.
- Dashboard, Telegram and final Windows deployment package.

## Verification

- Full automated suite: 735 passed.
- `compileall`: passed.
- Root CLI and `market-runtime --help`: passed.
- Import/version check: 0.42.0.
- Offline fixture-based tests only; no real Binance network session or order was run.
- Build/test host: Linux x86_64 / Python 3.13.5.
- Target PC: Windows 10 / Python 3.12.9 / 8 GB — not yet verified.
