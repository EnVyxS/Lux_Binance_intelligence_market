# Build State — v0.57.0D3

- Release label: `v0.57.0D3 — Triggered Algo Fill & Residual Recovery`
- Python package version: `0.57.0rc4` (PEP 440 prerelease identity; `src/divatrading.__version__` is aligned)
- Baseline: v0.57.0D2 (`0.57.0rc3`)
- Project interpreter pin: `==3.12.9`
- Build host: Linux / Python 3.13.5
- Scope: triggered Algo child-order reconciliation; cancel-race final REST executedQty; zero-fill branch with TESTNET-only protection-recovery opt-in; REST backfill after User Data Stream reconnect; deterministic restart/idempotency.
- D3 keeps all actual order, Stage C, protection-recovery and LIVE flags disabled by default.
- No real Binance Demo/LIVE order, child order cancellation or Algo mutation has been executed by build/test.
- Windows 10 / Python 3.12.9 evidence remains C1 (952 passed); exact D3 archive requires separate Windows qualification.

- Full regression: **978 passed** on Linux / Python 3.13.5; 10 focused triggered-protection tests passed; compileall and 4 CLI help checks passed.
- Wheel: `divatrading_binance_bot-0.57.0rc4-py3-none-any.whl` built with local setuptools 82.0.1 using `--ignore-requires-python` because the build host is Python 3.13.5 while project metadata deliberately pins `==3.12.9`; wheel metadata preserves the target Python pin. The wheel was built, not installed or runtime-tested on this host.
