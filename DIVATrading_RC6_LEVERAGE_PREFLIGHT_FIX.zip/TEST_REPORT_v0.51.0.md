# Test Report v0.51.0

- Baseline regression before changes: **838 passed**.
- Full working-tree regression after changes: **850 passed**.
- Focused accounting and User Data Stream tests: **29 passed**.
- `python -m compileall -q src/divatrading`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -m divatrading runtime-status --help`: PASS.
- Package import/version check: PASS (`0.51.0`).
- `divatrading check` correctly refuses the current host interpreter (Python 3.13.5); project pin remains `==3.12.9`.
- Ruff lint was not run because Ruff is not installed in this environment.
- Clean-extraction full regression: **850 passed**; archive integrity, compileall, CLI help, version assertion and content audit: PASS. See `CLEAN_EXTRACTION_TEST_REPORT_v0.51.0.md`.

Environment: Linux x86_64 / Python 3.13.5. Project target remains Python 3.12.9. No Binance TESTNET/LIVE API calls or order submissions were performed. These are local deterministic tests, not exchange integration certification.
