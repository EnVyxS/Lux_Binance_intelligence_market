@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run INSTALL_WINDOWS.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m divatrading market-runtime %*
set EXIT_CODE=%ERRORLEVEL%
echo.
echo Market runtime exited with code %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
