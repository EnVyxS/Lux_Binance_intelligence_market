# Next Task — After v0.58.0rc3

## User-side validation
1. Qualify exact package on Windows 10 x64 / Python 3.12.9.
2. Keep `DIVA_LIVE_TRADING_ENABLED=false`.
3. Only if ready for account inspection, use a dedicated Binance Futures account with withdrawals disabled and IP restrictions. Set `DIVA_EXECUTION_MODE=LIVE` and `DIVA_ENABLE_LIVE_READ_ONLY_PREFLIGHT=true` locally; run `divatrading live-read-only-preflight --symbols BTCUSDT`.
4. Do not send credentials or `.env` through chat. Do not run any order command as part of this read-only step.

## v0.58.0rc4 — Exchange Feasibility and Risk Ledger
1. Parse account-specific leverage bracket tiers and maintenance margin into typed models.
2. Retrieve symbol commission rates and integrate fee reserve into risk feasibility.
3. Implement closed-position trade ledger for consecutive losses across partial exits, multiple lots, commissions and funding; unknown state blocks new entries.
4. Reconcile daily PnL anchors across deposits/withdrawals and explicit Asia/Jakarta day boundary.
5. Connect Telegram risk/max-loss/leverage/margin controls to runtime refresh and gates.
6. Add symbol-level margin-mode query/reconciliation before any authorized setting change. No automatic setting writes in this phase.

## v0.58.0rc5 — LIVE Position Lifecycle Qualification
1. Validate private User Data Stream reconnect/backfill and exact ownership of standard/Algo orders.
2. Validate entry → partial fill → STOP/TP protection → partial protective fill → residual protection → final exit.
3. Validate ambiguous POST/cancel, process restart, lost stream events and REST reconciliation.
4. Verify pause/kill blocks new entries while position supervision continues.
5. Qualify Windows 10 / Python 3.12.9.

## LIVE acceptance gate
No order routing until read-only account checks pass, trade accounting and loss guards are complete, position lifecycle is qualified, and explicit authorization is obtained for a supervised minimum-risk single-symbol acceptance. No unattended multi-pair rollout before evidence exists.
