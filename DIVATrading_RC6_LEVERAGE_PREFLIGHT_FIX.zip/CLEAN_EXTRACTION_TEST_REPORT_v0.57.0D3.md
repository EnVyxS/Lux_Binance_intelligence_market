# Clean Extraction Test Report — v0.57.0D3

## Final archive verification
- Release archive was extracted into a new, isolated directory before running tests.
- Archive member CRC check: PASS.
- Full regression from extracted archive: **978 passed**.
- `compileall -q src tests`: PASS.
- Four CLI help checks: PASS (`auto-trade-runtime`, `testnet-preflight`, `testnet-order-test`, `replay-workflow`).
- Source manifest SHA-256 entries: all PASS.
- Sensitive-file audit: PASS; no `.env`, `.venv`, runtime database, log, backup, or Python cache included.

## Environment boundary
- Clean extraction host: Linux / Python 3.13.5.
- Project metadata remains pinned to Python `==3.12.9`.
- This is not a Windows 10 / Python 3.12.9 qualification. C1 Windows evidence cannot be carried forward as D3 evidence.
- No Binance Demo/LIVE order, cancellation, or Algo mutation was executed.
