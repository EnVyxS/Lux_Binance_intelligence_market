# Clean Extraction Test Report — v0.43.0

- Exact release ZIP is extracted to an isolated directory and checked from that extracted tree.
- ZIP integrity (`unzip -t`): PASS.
- `PYTHONPATH=src python -m compileall -q src`: PASS.
- Root CLI `PYTHONPATH=src python -m divatrading --help`: PASS.
- `market-runtime --help`: PASS, including entry model, paper reference equity, risk, target-R and minimum score options.
- Package version import: 0.43.0.
- Full pytest suite from clean extraction: 747 passed.
- No network access or live order submission performed.
- Runtime: Linux x86_64 / Python 3.13.5; target Windows 10 / Python 3.12.9 / 8 GB remains unverified.
