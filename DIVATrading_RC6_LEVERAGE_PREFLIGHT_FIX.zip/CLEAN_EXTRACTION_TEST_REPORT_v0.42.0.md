# Clean Extraction Test Report — v0.42.0

**Archive:** `DIVATrading_BinanceBot_MultiPairProductionFeedGraph_0.42.0.zip`  
**Host:** Linux x86_64 / Python 3.13.5  
**Date:** 2026-11-12

The release archive was extracted into a fresh directory and the following checks were run from that extracted copy:

| Check | Result |
|---|---|
| `unzip -t` archive integrity | PASS |
| `pytest -q` | **735 passed in 11.12s** |
| `python -m compileall -q src` | PASS |
| `PYTHONPATH=src python -m divatrading --help` | PASS |
| `PYTHONPATH=src python -m divatrading market-runtime --help` | PASS |
| Import `BinanceFeedGraphConfig`, `BinancePublicFeedFactory` | PASS |
| Package version equals `0.42.0` | PASS |

All tests are offline/fixture/mock based. No public Binance WebSocket connection, private API request, TESTNET order or LIVE order was performed. Windows 10 / Python 3.12.9 / 8 GB compatibility remains unverified on the target PC.
