# Binance USDⓈ-M User Data Stream & Account Reconciliation — v0.46.0

## Scope

v0.46.0 adds private account event ingestion, durable event projections, account reconciliation, and a non-PAPER execution-readiness gate. It is a staged execution-safety checkpoint, not a declaration that unattended LIVE trading is complete.

## Binance protocol used

Implementation was checked against the Binance USDⓈ-M Futures User Data Stream documentation last updated 2026-11-12:

- REST listen-key create: `POST /fapi/v1/listenKey`.
- REST keepalive: `PUT /fapi/v1/listenKey`.
- REST close: `DELETE /fapi/v1/listenKey`.
- These listen-key calls use the `X-MBX-APIKEY` header; the implementation does not add an HMAC signature or timestamp.
- LIVE WebSocket: `wss://fstream.binance.com/private/ws/{listenKey}`.
- TESTNET WebSocket: `wss://fstream.binancefuture.com/ws/{listenKey}`.
- Binance documents a 60-minute listen-key lifetime without keepalive and a 24-hour WebSocket connection lifetime. This supervisor sends keepalive every 25 minutes and rotates the socket after 23 hours.

Relevant event families:

- `ACCOUNT_UPDATE`: partial balance and position deltas; absent assets/positions are not interpreted as zero.
- `ORDER_TRADE_UPDATE`: standard order lifecycle updates.
- `ALGO_UPDATE`: conditional/algo order lifecycle updates, including protective STOP/TAKE_PROFIT state.
- `TRADE_LITE`: trade-level state signal; invalidates the last reconciliation readiness.
- `listenKeyExpired`: forces a new listen key and reconnect.

## Runtime behavior

`BinanceUserDataStreamSupervisor` owns listen-key lifecycle, TLS WebSocket connection, receive parsing, bounded exponential reconnect, event processing, graceful close, and 23-hour socket rotation. It does not create entry orders or cancel positions. Each reconnect uses a fresh listen key; the previous key is closed best-effort to prevent abandoned keys.

`ExecutionLedger` stores the raw event payload with a stable SHA-256 event identity and projects partial balances, positions, standard orders, and algo orders in one SQLite transaction. Duplicate payloads are ignored. Event-derived data is a cache/projection; exchange REST state remains the reconciliation authority.

`AccountReconciliationService` captures exchange account state, positions, standard open orders, and algo open orders, then compares exchange positions and protective orders with local DIVA intents/managed positions. It checks STOP and TAKE_PROFIT protection types, position side, closing order side, and closePosition/reduceOnly semantics. It detects unmanaged exchange positions, local positions missing on exchange, quantity mismatches, missing protection, orphan DIVA orders, unresolved pending entries, and orphan risk reservations.

A reconciliation snapshot consists of sequential REST calls and is therefore not an atomic Binance snapshot. A stream-event watermark is captured around those calls. Any relevant stream event received during the capture or before the atomic SQLite commit prevents the result from becoming READY. Any later account/order/trade update immediately invalidates READY until a new successful reconciliation.

## TESTNET/LIVE entry gate

When `DIVA_EXECUTION_MODE` is TESTNET or LIVE, `ExecutionService.submit` requires all of the following before sending an entry:

1. A matching ACTIVE portfolio-risk reservation from the coordinator.
2. User Data Stream state `CONNECTED`.
3. Latest reconciliation state `READY`.
4. Reconciliation age no greater than `DIVA_MAX_ACCOUNT_SNAPSHOT_AGE_MS` (default 30,000 ms).
5. No global entry halt / kill-switch state.

`DIVA_REQUIRE_ACCOUNT_READINESS` defaults to `true`; TESTNET/LIVE configuration is rejected if this gate is disabled. The service checks readiness both before intent claim and again immediately before the entry-order POST. PAPER mode is not subject to this private-account gate and still sends no exchange order.

## Running the account runtime

The `account-runtime` CLI is available for a deliberately opted-in TESTNET/LIVE environment:

```powershell
$env:DIVA_EXECUTION_MODE="TESTNET"
$env:DIVA_ENABLE_TESTNET_ORDERS="true"
python -m divatrading account-runtime
```

LIVE additionally requires the existing explicit live enablement and confirmation guard. Do not put API secrets in a ZIP or source control. Start only after API permissions, IP restrictions, account mode, and environment selection have been checked.

This command maintains account events and reconciles pending execution. With the execution service wired in, it may recover an exchange-confirmed partial/full entry fill by cancelling the unfilled remainder and attaching protective SL/TP orders. It does not discover symbols, generate new SMC signals, or start the complete entry/position lifecycle runtime. It should not be interpreted as permission to run unattended LIVE trading.

## Known limitations

- No real Binance REST request, TESTNET WebSocket session, private account event, or exchange order was performed during build validation.
- REST account/position/order reads are sequential. The watermark prevents known event races but cannot turn separate exchange endpoints into a transactional account snapshot.
- Reconciliation blocks and halts new entries on mismatches; it does not automatically flatten unmanaged exposure or cancel arbitrary orders.
- It does not yet autonomously release all reservations when an exchange position is verified flat and all related orders are terminal.
- Partial take-profit, breakeven, trailing stop, dynamic final exits, and full managed-position state machine remain later work.
- The runtime expects the account's positions and orders to be represented in DIVA's ledger. Manual/discretionary positions on the same futures account are treated as unmanaged exposure and can block new entries. Use a dedicated subaccount for the bot when possible.
- Windows 10 / Python 3.12.9 / 8 GB validation remains outstanding; this checkpoint was tested on Linux / Python 3.13.5.
