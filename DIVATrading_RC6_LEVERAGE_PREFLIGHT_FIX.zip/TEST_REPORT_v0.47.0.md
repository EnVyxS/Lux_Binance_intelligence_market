# Test Report v0.47.0

- Full suite: **797 passed**.
- Focused lifecycle tests: 18 passed (included in full suite).
- Coverage includes threshold behavior, LONG/SHORT direction, Decimal validation, partial-fill gate for breakeven, favorable watermark, monotonic trailing, deterministic action IDs, closed-position no-op, SQLite CAS persistence and idempotent action claims.
- No live/testnet Binance API or order execution was performed.
- Runtime environment is Linux/Python 3.13.5; Windows 10/Python 3.12.9/8GB target remains unverified.
