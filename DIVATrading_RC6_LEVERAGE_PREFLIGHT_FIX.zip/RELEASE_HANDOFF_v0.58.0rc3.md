# Release Handoff — DIVATrading v0.58.0rc3

## Baseline
Built from the verified v0.58.0rc2 archive. Preserves SMC V2, position supervisor, dispatcher, Telegram SIGNAL_ONLY, Kronos-mini optional shadow adapter, persistent operator controls and protective-order recovery lineage.

## Added
- Strictly read-only LIVE USDⓈ-M preflight with pinned official REST host.
- Checks account permissions/config, USDT wallet/available balance, position mode, active positions, standard orders, Algo orders, symbol status, and account-specific leverage brackets.
- Added read-only leverage-bracket and commission-rate client methods.
- Requires local explicit opt-in; LIVE order flag must remain false.

## Safety invariants
- No order submission, leverage change, margin-mode change, cancellation, or other account mutation occurs in this release's LIVE preflight.
- Any open position or order blocks initial clean-account onboarding. Never auto-close unknown exposure.
- No API credentials or `.env` are included in the archive.
- LIVE trading remains disabled; no real exchange request has been made during build tests.

## Verification
See `TEST_REPORT_v0.58.0rc3.md`, `CLEAN_EXTRACTION_TEST_REPORT_v0.58.0rc3.md`, `FINAL_RELEASE_VERIFICATION_v0.58.0rc3.md`, and source manifest.

## Next
Follow `NEXT_TASK_v0.58.0rc3.md`. Windows 10 / Python 3.12.9 qualification and real-account read-only validation remain user-side gates.
