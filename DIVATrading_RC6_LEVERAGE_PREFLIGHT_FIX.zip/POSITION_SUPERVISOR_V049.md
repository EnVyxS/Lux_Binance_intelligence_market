# Managed Position Supervisor — v0.49.0

## Purpose

v0.49.0 connects the v0.47 lifecycle decision engine and v0.48 exchange execution adapter to a continuous, per-symbol Mark Price supervisor. It manages already-open DIVA positions. It does not yet wire fresh SMC trade-plan candidates into a continuous autonomous entry dispatcher.

## Runtime integration

`ExecutionAccountRuntime` co-runs:

- Binance USDⓈ-M User Data Stream and lifecycle fill reducer;
- periodic exchange account / position / order reconciliation;
- one bounded Mark Price feed worker per actively-managed symbol;
- a per-position lifecycle evaluator and action dispatcher.

Each symbol worker validates symbol identity, event timestamp, future skew and mark freshness. Feed disconnection, stale marks, malformed events, worker exceptions, action ambiguity, missing reservation/state, or quantity mismatch halt new entries and retain position protection. A worker reconnects with a bounded delay. The supervisor cap is 16 active symbols by default in the 8 GB-oriented runtime profile.

## Lifecycle actions

- `PARTIAL_TP`: reduce-only MARKET close in One-way mode; explicit `positionSide` and no `reduceOnly` in Hedge Mode. REST order status and actual position quantity are confirmed before state changes.
- `MOVE_STOP`: exact tick-size rounding (LONG down, SHORT up) and safe create/verify/cancel replacement of a DIVA-owned close-all Algo STOP.
- `STRUCTURAL_EXIT`: full MARKET close when Mark Price crosses the approved SMC TradePlan stop/invalidation boundary. The exchange-side stop remains in place until flat is verified.
- `EMERGENCY_CLOSE`: explicit operator action through `divatrading emergency-close`; requires a managed signal ID, non-empty reason and exact confirmation phrase `CLOSE DIVA POSITION`. It is never triggered by the entry kill switch.

## Partial TP target accounting

The lifecycle state now records `initial_quantity` and `partial_tp_filled_quantity`. The configured 50% target is measured against original protected quantity, not repeatedly against the shrinking residual. The target is snapped down once to the exchange MARKET quantity step, and the snapped target is persisted so no untradeable sub-step remainder is chased. When a market close receives a terminal partial fill, the supervisor can calculate only the unfilled remainder of the original target. Existing v0.48 action payloads are used to backfill original size and cumulative terminal fills when available.

Breakeven becomes eligible only after cumulative partial TP fills satisfy the full configured target. A terminal partial fill alone does not claim the target is complete.

## Account readiness while entries are halted

New-entry kill switch and management of existing positions are separate controls. The account observation gate permits existing-position management under `ENTRIES_HALTED` only when the latest REST reconciliation status contains zero discrepancies, is fresh, and its stream-event watermark still matches the current User Data Stream watermark. `BLOCKED_MISMATCH`, `CAPTURE_FAILED`, stale snapshots and event-watermark drift remain fail-closed.

## Supported position contract

Only one active DIVA-managed signal per `(symbol, positionSide)` is supported. Multiple DIVA scaling entries on the same exchange position side are rejected and halt new entries. Aggregate position accounting, scale-in/scale-out attribution and netted manual + DIVA ownership are not implemented.

## Mark Price endpoint configuration

`DIVA_MARK_PRICE_WS_ENDPOINT` may override the endpoint, but must be a secure `wss://` URL. The default is the USDⓈ-M live market stream endpoint; the testnet default is paired with the project's legacy USDⓈ-M Testnet REST environment. No WebSocket connection was opened during local tests.

## Safety boundaries

- PAPER remains the default mode.
- Account runtime and emergency close require explicit TESTNET or LIVE configuration.
- No API credentials are included in source or release archives.
- Emergency close does not cancel protective stops before flat confirmation.
- Partial/ambiguous market exits retain protection and risk reservation; they do not count as closed.
- Entry halt never means automatic flattening or cancellation of protective orders.
- Same-symbol aggregate position accounting and complete entry-signal integration remain future work.

## Verification

See `TEST_REPORT_v0.49.0.md`. All exchange operations are tested with deterministic local fakes/mocks. No real TESTNET/LIVE REST request, WebSocket session, order, cancellation or fill was performed.
