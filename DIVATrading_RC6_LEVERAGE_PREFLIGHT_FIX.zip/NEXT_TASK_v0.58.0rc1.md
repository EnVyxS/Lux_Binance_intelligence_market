# Next Task — After v0.58.0rc1

## v0.58.0rc2 — Complete LIVE account adapter and dynamic leverage
1. Add read-only LIVE preflight command with fixed LIVE endpoint, time sync, account mode, wallet/available balance, exchange filters, open standard orders, open Algo orders, position-risk snapshot and strict BOT_ONLY reconciliation.
2. Retrieve symbol-specific leverage brackets and maintenance-margin tiers from Binance; model initial margin, maintenance margin, fee reserve, funding and conservative liquidation buffer.
3. Integrate leverage selection into the actual sizing/dispatch path. Never upsize quantity to meet min-notional; reject if exchange minimum exceeds risk budget or margin feasibility.
4. Apply margin mode and leverage only after exact read-only feasibility and explicit local opt-in; reconcile returned exchange settings before any entry.
5. Implement exchange-reconciled closed-position streak ledger, including partial exits and multi-lot lifecycle identity.
6. Make daily loss baseline robust to deposits/withdrawals and document day-boundary timezone semantics.
7. Add end-to-end mocked integration tests for Telegram mutation → live runtime refresh → risk sizing → loss gates → BOT_ONLY isolation.

## v0.58.0rc3 — LIVE lifecycle hardening
1. Validate private User Data Stream reconnect/backfill, exact order/Algo ownership, partial protective fills, ambiguous POST/cancel recovery and restart.
2. Validate STOP/TP protection on every observed fill and fail closed on any mismatch.
3. Test kill/pause with open positions; verify existing-position supervision continues and no new entries dispatch.
4. Test process restart and Telegram disconnection; persisted config remains in effect and account supervisor remains independent.
5. Add Windows 10 / Python 3.12.9 clean install and regression qualification.

## LIVE acceptance
Only after all release-candidate gates pass: user-run read-only LIVE preflight, then a separately approved smallest-risk single-symbol LIVE acceptance. No unattended multi-pair LIVE rollout before this evidence exists.
