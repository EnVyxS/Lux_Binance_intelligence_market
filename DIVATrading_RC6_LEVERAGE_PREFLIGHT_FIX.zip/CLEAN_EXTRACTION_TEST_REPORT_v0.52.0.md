# Clean Extraction Test Report v0.52.0

Release archive: `DIVATrading_BinanceBot_QuantityScopedProtection_0.52.0.zip`

## Fresh extraction verification

- Extracted into a new empty directory: PASS.
- Full regression from extracted source: **855 passed**.
- `python -m compileall -q src tests`: PASS.
- `PYTHONPATH=src python -m divatrading --help`: PASS.
- `PYTHONPATH=src python -m divatrading runtime-status --help`: PASS.
- Package import/version assertion (`0.52.0`): PASS.
- ZIP integrity (`ZipFile.testzip()`): PASS.
- Archive content audit: PASS; no `.env`, SQLite runtime database, `.pyc`, or cache directories included.

## Environment

Linux x86_64 / Python 3.13.5. Project pin remains `requires-python ==3.12.9`; target Windows 10 validation is not performed. CLI help was tested, but no TESTNET/LIVE account request or order was sent.
