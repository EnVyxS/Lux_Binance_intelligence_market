# Build State — v0.57.0B

- Baseline: v0.57.0A Testnet Environment & Exchange Qualification Harness.
- Release label: v0.57.0B — Signed Demo Test Order Validation.
- Package version: `0.57.0b1` (PEP 440 prerelease).
- Python requirement pin: `==3.12.9` (unchanged).
- Build environment: Linux / Python 3.13.5; Windows 10 target remains untested.
- TESTNET REST host pinned to `https://demo-fapi.binance.com`.
- Signed endpoint: `POST /fapi/v1/order/test`; no automatic retries.
- Added LIMIT/MARKET parameter builder with exact Decimal exchange filter checks and One-way/Hedge Mode validation.
- MARKET local validation checks MARKET_LOT_SIZE and quantity; exchange response is authoritative for MARKET notional semantics.
- Added `testnet-order-test` CLI with separate local opt-in and explicit command confirmation.
- Stage B opt-in: `DIVA_ENABLE_TESTNET_ORDER_TEST=true`; actual order flag `DIVA_ENABLE_TESTNET_ORDERS=false` remains false.
- PAPER remains default; LIVE routing remains disabled.
- API credentials are read from local `.env` only and are never part of source, test fixtures, ZIP, or reports.
- No actual Binance API credential, private request, Demo order, WebSocket session, or LIVE request was used. Target-PC authenticated validation remains pending.

## Verification

- Source regression: **948 passed across two runs** — 941 tests excluding `tests/test_stage6b_workflow.py`, then 7 workflow tests in a separate run with `-p no:ddtrace` because the auto-loaded tracing plugin intermittently stalled process shutdown in that legacy module. The complete suite was partitioned because a monolithic run exceeded the execution time limit; the isolated module passed.
- Focused Stage B + Stage A TESTNET suite: **38 passed**.
- `python -m compileall -q src tests`: PASS.
- `python -m divatrading --help`: PASS.
- `python -m divatrading testnet-order-test --help`: PASS.
- `python -m divatrading testnet-preflight --help`: PASS.
- Clean-extraction regression: **948 passed across two runs** (941 + 7; workflow module with `-p no:ddtrace`); focused tests: **38 passed**; compileall, CLI help, ZIP CRC, and sensitive-file audit: PASS. See `CLEAN_EXTRACTION_TEST_REPORT_v0.57.0B.md`.
