# Build State — v0.57.0

- Baseline: v0.56.0 Autonomous Entry Dispatcher.
- Release scope: TESTNET Environment & Qualification Harness (Stage A, strictly read-only).
- Package version: 0.57.0.
- Python requirement pin: `==3.12.9` (unchanged).
- Build environment: Linux / Python 3.13.5.
- TESTNET REST: `https://demo-fapi.binance.com`.
- TESTNET market stream: `wss://demo-fstream.binance.com/market/stream`.
- TESTNET private stream: `wss://demo-fstream.binance.com/private/ws?listenKey=...&events=...`.
- LIVE REST/private stream remain separate production endpoints.
- New CLI: `testnet-preflight --symbols BTCUSDT`; read-only public and signed GET calls only.
- New local credential template: `.env.testnet.example`; credentials are never printed or packaged.
- Corrected User Trades bootstrap retention to 90 days based on Binance change effective 2026-08-26.
- No actual Binance API credentials, private network request, WebSocket session or order was used.
- Same-side TESTNET/LIVE scale-in remains blocked. LIVE routing remains disabled.

- Final source regression: 927 passed.
- Final clean-extraction regression: 927 passed.
- ZIP CRC, SHA sidecar and sensitive-file audit: PASS.
