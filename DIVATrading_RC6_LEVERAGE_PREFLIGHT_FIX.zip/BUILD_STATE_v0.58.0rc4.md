# Build State — v0.58.0rc4

- Source baseline: v0.58.0rc3 release archive.
- Version: 0.58.0rc4.
- Runtime host: Linux, Python 3.13.5; target requirement remains Python 3.12.9.
- Full tests: 1,024 passed; clean-extraction full tests: 1,024 passed.
- New tests: typed leverage bracket parsing, maintenance margin, fee reserve, feasibility rejection, completed lifecycle idempotency, net PnL/streak, Asia/Jakarta day boundary.
- Live preflight: validates account leverage tiers, commission rate and per-symbol margin configuration using read-only endpoints.
- Compileall/import/CLI: passed; ZIP CRC and 460-file manifest verification passed.
- No real exchange account or credentials used; no order submitted.
- Explicit incomplete items: runtime dynamic leverage/fee integration; lifecycle ledger event ingestion/reconciliation; deposit/withdrawal-aware daily equity anchor; complete Telegram worker refresh; Windows qualification.
