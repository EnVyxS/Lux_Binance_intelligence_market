from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from threading import Event

import pytest

from divatrading.core.database import Database, SCHEMA_VERSION
from divatrading.market_data.klines import Kline
from divatrading.market_data.storage import KlineRepository


def test_database_migrates_and_is_idempotent(tmp_path: Path) -> None:
    db = Database(tmp_path / "state" / "diva.db")
    assert db.initialize() == SCHEMA_VERSION
    assert db.initialize() == SCHEMA_VERSION
    assert db.schema_version() == SCHEMA_VERSION


def test_settings_round_trip_json(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    db.set_setting("universe", {"mode": "MANUAL", "symbols": ["BTCUSDT"]})
    assert db.get_setting("universe") == {"mode": "MANUAL", "symbols": ["BTCUSDT"]}
    assert db.get_setting("missing", "fallback") == "fallback"


def test_same_path_serializes_market_and_core_writers_without_blocking_wal_reads(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = tmp_path / "diva.db"
    owner = Database(db_path)
    owner.initialize()
    owner.set_setting("visibility", "committed")
    unrelated = Database(tmp_path / "unrelated.db")
    unrelated.initialize()

    connect = Database.connection

    @contextmanager
    def fail_fast_connection(database):
        with connect(database) as connection:
            # The application lock, not SQLite's busy timeout, should queue writers.
            connection.execute("PRAGMA busy_timeout = 0")
            yield connection

    monkeypatch.setattr(Database, "connection", fail_fast_connection)

    @contextmanager
    def observe_writer_lock(lock, reached):
        acquired = lock.acquire(blocking=False)
        if acquired:
            lock.release()
        reached.set()
        assert not acquired, "A separate Database instance did not share the active writer lock"
        with lock:
            yield

    def write(database, reached, index):
        try:
            if index < 12:
                open_time_ms = index * 60_000
                candle = Kline.from_binance_row(
                    [open_time_ms, "100", "101", "99", "100", "1", open_time_ms + 59_999,
                     "100", 1, "1", "100", "0"],
                    symbol="BTCUSDT", interval="1m", source_endpoint="fixture",
                )
                KlineRepository(database).upsert_many([candle])
            else:
                database.record_event("INFO", "fixture", "concurrent_write", str(index))
        finally:
            reached.set()

    def read_and_write_unrelated():
        value = Database(db_path).get_setting("visibility")
        unrelated.set_setting("independent", True)
        return value

    with ThreadPoolExecutor(max_workers=25) as executor:
        with owner.transaction() as connection:
            connection.execute(
                "UPDATE app_settings SET value_json = ? WHERE setting_key = 'visibility'",
                ('"uncommitted"',),
            )
            futures = []
            waiting = []
            for index in range(24):
                database = Database(tmp_path / "alias" / ".." / db_path.name)
                reached = Event()
                # Signal the test at the actual contention point instead of sleeping.
                lock = getattr(database, "_write_lock", None)
                if lock is not None:
                    monkeypatch.setattr(database, "_write_lock", observe_writer_lock(lock, reached))
                waiting.append(reached)
                futures.append(executor.submit(write, database, reached, index))
            assert all(reached.wait(timeout=5) for reached in waiting)
            assert executor.submit(read_and_write_unrelated).result(timeout=5) == "committed"
        for future in futures:
            future.result(timeout=5)

    assert owner.get_setting("visibility") == "uncommitted"
    assert unrelated.get_setting("independent") is True
    assert len(KlineRepository(owner).read(symbol="BTCUSDT", interval="1m")) == 12
    assert {event["message"] for event in owner.recent_events()} == {str(i) for i in range(12, 24)}


def test_runtime_events_round_trip(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    event_id = db.record_event("info", "unit-test", "test_event", "hello", {"n": 1})
    events = db.recent_events()
    assert events[0]["id"] == event_id
    assert events[0]["details"] == {"n": 1}
    assert events[0]["level"] == "INFO"


def test_invalid_event_and_limit_are_rejected(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    with pytest.raises(ValueError):
        db.record_event("INFO", "", "event", "message")
    with pytest.raises(ValueError):
        db.recent_events(0)


def test_exchange_metadata_snapshot_storage_and_integrity(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    payload = {"serverTime": 123, "symbols": [{"symbol": "BTCUSDT"}]}
    snapshot_id = db.save_exchange_metadata_snapshot(
        source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo",
        fetched_at_utc="2026-11-10T00:00:00.000Z",
        server_time_ms=123,
        symbol_count=1,
        payload=payload,
    )
    cached = db.latest_exchange_metadata_snapshot()
    assert snapshot_id == 1
    assert cached is not None
    assert cached["payload"] == payload
    assert cached["payload_sha256"]


def test_exchange_metadata_retention_keeps_newest_snapshots(tmp_path: Path) -> None:
    db = Database(tmp_path / "diva.db")
    db.initialize()
    for index in range(3):
        db.save_exchange_metadata_snapshot(
            source_endpoint="fixture",
            fetched_at_utc=f"2026-11-10T00:00:0{index}.000Z",
            server_time_ms=index,
            symbol_count=index,
            payload={"symbols": [], "index": index},
            retain=2,
        )
    cached = db.latest_exchange_metadata_snapshot()
    assert cached is not None
    assert cached["id"] == 3
    with db.connection() as connection:
        count = connection.execute("SELECT COUNT(*) FROM exchange_metadata_snapshots").fetchone()[0]
    assert count == 2


def test_existing_schema_v1_database_upgrades_to_latest_schema(tmp_path: Path) -> None:
    import sqlite3

    db_path = tmp_path / "legacy-v1.db"
    connection = sqlite3.connect(db_path)
    connection.executescript(
        """
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, applied_at_utc TEXT NOT NULL);
        INSERT INTO schema_migrations(version, applied_at_utc) VALUES (1, '2026-11-09T00:00:00Z');
        CREATE TABLE app_settings (setting_key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at_utc TEXT NOT NULL);
        CREATE TABLE runtime_events (id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_at_utc TEXT NOT NULL, level TEXT NOT NULL, component TEXT NOT NULL, event_name TEXT NOT NULL, message TEXT NOT NULL, details_json TEXT NOT NULL DEFAULT '{}');
        CREATE INDEX idx_runtime_events_time ON runtime_events(occurred_at_utc DESC);
        CREATE INDEX idx_runtime_events_component ON runtime_events(component, event_name);
        INSERT INTO app_settings(setting_key, value_json, updated_at_utc) VALUES ('preserve', '{"yes":true}', '2026-11-09T00:00:00Z');
        """
    )
    connection.commit()
    connection.close()

    db = Database(db_path)
    assert db.initialize() == SCHEMA_VERSION
    assert db.get_setting("preserve") == {"yes": True}
    assert db.latest_exchange_metadata_snapshot() is None


def test_exchange_metadata_snapshot_detects_payload_tampering(tmp_path: Path) -> None:
    import sqlite3

    db = Database(tmp_path / "diva.db")
    db.initialize()
    db.save_exchange_metadata_snapshot(
        source_endpoint="fixture",
        fetched_at_utc="2026-11-10T00:00:00.000Z",
        server_time_ms=None,
        symbol_count=0,
        payload={"symbols": []},
    )
    connection = sqlite3.connect(db.path)
    connection.execute("UPDATE exchange_metadata_snapshots SET payload_json = ?", ('{"symbols":[1]}',))
    connection.commit()
    connection.close()

    with pytest.raises(RuntimeError, match="SHA-256 integrity"):
        db.latest_exchange_metadata_snapshot()


def test_existing_schema_v3_migrates_to_v6_and_preserves_kline_data(tmp_path: Path) -> None:
    db = Database(tmp_path / "legacy-v3.db")
    db.initialize()
    with db.transaction() as connection:
        connection.execute(
            """INSERT INTO market_klines(
                exchange, symbol, interval, open_time_ms, open, high, low, close, volume,
                close_time_ms, quote_asset_volume, trade_count, taker_buy_base_volume,
                taker_buy_quote_volume, ignore_value, source_endpoint, first_seen_at_utc,
                last_fetched_at_utc, last_saved_at_utc
            ) VALUES ('BINANCE_UM', 'BTCUSDT', '1m', 0, '1', '1', '1', '1', '0',
                     59999, '0', 0, '0', '0', '0', 'fixture', '2026-11-10T00:00:00Z',
                     '2026-11-10T00:00:00Z', '2026-11-10T00:00:00Z')"""
        )
        connection.execute("DELETE FROM schema_migrations WHERE version>=4")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_evaluations")
        connection.execute("DROP TABLE IF EXISTS signal_forecast_links")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_forecasts")
        connection.execute("DROP TABLE IF EXISTS signal_publications")
        connection.execute("DROP TABLE IF EXISTS order_flow_buckets")
        connection.execute("DROP TABLE IF EXISTS order_flow_state")
        connection.execute("DROP TABLE aggregate_trade_gaps")
        connection.execute("DROP TABLE aggregate_trade_stream_state")
        connection.execute("DROP TABLE aggregate_trades")
    assert db.schema_version() == 3

    assert db.initialize() == 6
    with db.connection() as connection:
        row = connection.execute(
            "SELECT close FROM market_klines WHERE symbol='BTCUSDT' AND open_time_ms=0"
        ).fetchone()
        trade_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='aggregate_trades'"
        ).fetchone()
    assert row["close"] == "1"
    assert trade_table is not None


def test_existing_schema_v4_migrates_to_v6_without_touching_trade_rows(tmp_path: Path) -> None:
    db = Database(tmp_path / "legacy-v4.db")
    db.initialize()
    with db.transaction() as connection:
        connection.execute(
            """INSERT INTO aggregate_trades(
                exchange, symbol, aggregate_trade_id, price, quantity, normal_quantity,
                first_trade_id, last_trade_id, event_time_ms, trade_time_ms, buyer_is_maker,
                first_source_kind, last_source_kind, first_source_endpoint, last_source_endpoint,
                first_seen_at_utc, last_seen_at_utc
            ) VALUES ('BINANCE_UM', 'BTCUSDT', 10, '100', '0.1', NULL, 20, 21, 1000, 1000, 0,
                     'REST', 'REST', 'fixture', 'fixture', '2026-11-10T00:00:00Z', '2026-11-10T00:00:00Z')"""
        )
        connection.execute("DELETE FROM schema_migrations WHERE version>=5")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_evaluations")
        connection.execute("DROP TABLE IF EXISTS signal_forecast_links")
        connection.execute("DROP TABLE IF EXISTS kronos_shadow_forecasts")
        connection.execute("DROP TABLE IF EXISTS signal_publications")
        connection.execute("DROP TABLE order_flow_buckets")
        connection.execute("DROP TABLE order_flow_state")
    assert db.schema_version() == 4
    assert db.initialize() == 6
    with db.connection() as connection:
        trade = connection.execute(
            "SELECT aggregate_trade_id, price FROM aggregate_trades WHERE symbol='BTCUSDT'"
        ).fetchone()
        state_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='order_flow_state'"
        ).fetchone()
    assert trade["aggregate_trade_id"] == 10
    assert trade["price"] == "100"
    assert state_table is not None
