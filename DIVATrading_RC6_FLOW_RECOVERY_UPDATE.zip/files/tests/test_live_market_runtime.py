import asyncio
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading.trading.live_runtime import LiveMarketRuntimeConfig, MultiPairLiveMarketRuntime
from divatrading.trading.universe import SymbolUniverseConfig


FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


class FakeRest:
    exchange_info_endpoint = "https://fapi.binance.com/fapi/v1/exchangeInfo"

    def __init__(self):
        self.payload = __import__("json").loads(FIXTURE.read_text())

    def get_exchange_info(self):
        return self.payload

    def get_ticker_24h(self):
        return [
            {"symbol": item["symbol"], "quoteVolume": "50000000", "count": 5000}
            for item in self.payload["symbols"]
            if item.get("quoteAsset") == "USDT"
        ]


@pytest.mark.asyncio
async def test_runtime_refresh_selects_symbols_and_starts_workers():
    started = []

    async def feed(symbol):
        started.append(symbol)
        if False:
            yield None

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(mode="AUTO", max_active_symbols=3,
                                      min_quote_volume_usdt=__import__("decimal").Decimal("1"),
                                      min_trade_count_24h=1),
        max_concurrent_workers=3,
        worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(rest_client=FakeRest(), feed_factory=feed, config=cfg)
    selected = await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    assert len(selected.symbols) == 2
    assert set(started) == set(selected.symbols)
    assert set(runtime.snapshot.selected_symbols) == set(selected.symbols)
    await runtime.stop()


@pytest.mark.asyncio
async def test_runtime_resets_only_the_symbol_retired_from_the_universe():
    rest = FakeRest()
    resets = []

    async def feed(symbol):
        await asyncio.Event().wait()
        yield None

    runtime = MultiPairLiveMarketRuntime(
        rest_client=rest, feed_factory=feed, on_symbol_reset=resets.append,
    )
    try:
        assert set((await runtime.refresh_universe()).symbols) == {"BTCUSDT", "ETHUSDT"}
        btc = next(row for row in rest.payload["symbols"] if row["symbol"] == "BTCUSDT")
        btc["status"] = "SETTLING"
        assert (await runtime.refresh_universe()).symbols == ("ETHUSDT",)
    finally:
        await runtime.stop()

    assert resets == ["BTCUSDT"]


def test_runtime_config_rejects_unbounded_symbol_count():
    with pytest.raises(ValueError):
        LiveMarketRuntimeConfig(
            universe=SymbolUniverseConfig(max_active_symbols=25),
            max_concurrent_workers=24,
        )


@pytest.mark.asyncio
async def test_runtime_is_read_only_and_rejects_non_async_feed():
    async def bad_feed(symbol):
        return []

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(mode="MANUAL", manual_symbols=("BTCUSDT",),
                                      max_active_symbols=1),
        max_concurrent_workers=1,
        worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(rest_client=FakeRest(), feed_factory=bad_feed, config=cfg)
    await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    status = runtime.snapshot.workers[0]
    assert status.status == "DEGRADED"
    assert "TypeError" in status.last_error
    await runtime.stop()


@pytest.mark.asyncio
async def test_runtime_publishes_selected_exchange_instruments_before_workers_start():
    from divatrading.strategy.scalping_market_data import InstrumentSpec

    observed = []

    def on_universe(selection, metadata):
        observed.append((selection.symbols, metadata.source_endpoint))

    async def feed(symbol):
        if False:
            yield None

    cfg = LiveMarketRuntimeConfig(
        universe=SymbolUniverseConfig(
            mode="MANUAL", manual_symbols=("BTCUSDT",), max_active_symbols=1,
        ),
        max_concurrent_workers=1, worker_restart_seconds=0.01,
    )
    runtime = MultiPairLiveMarketRuntime(
        rest_client=FakeRest(), feed_factory=feed, on_universe=on_universe, config=cfg,
    )
    selected = await runtime.refresh_universe()
    await asyncio.sleep(0.02)
    assert observed == [(selected.symbols, FakeRest.exchange_info_endpoint)]
    assert selected.symbols == ("BTCUSDT",)
    await runtime.stop()


@pytest.mark.asyncio
async def test_worker_reports_l2_and_flow_progress_after_first_capture(caplog, monkeypatch):
    from divatrading.strategy.scalping_market_data import (
        ScalpingComponentReadiness, ScalpingMarketDataView, ScalpingReadiness,
    )
    from divatrading.trading import live_runtime

    clock = [1.0]
    monkeypatch.setattr(live_runtime, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    readiness = ScalpingReadiness(
        instrument_price_grid_ready=True, instrument_quantity_grid_ready=True,
        m1_setup_ready=True, m5_setup_ready=True, m5_m1_confirmation_ready=True,
        m15_context_available=True, entry_quote_ready=False, mark_price_available=True,
        delta_cvd_available=False, depth_confluence_available=False, absorption_available=False,
    )
    view = ScalpingMarketDataView(
        symbol="BTCUSDT", captured_at_ms=1000, instrument=None,
        m1=None, m5=None, m15=None, mark_price=None, flow=None,
        order_book_health=None, order_book_metrics=None, absorption=None,
        orchestrator_readiness=None, readiness=readiness,
        components=(ScalpingComponentReadiness("DEPTH", "DEGRADED", False, (), None,
                                               ("DEPTH_METRICS_MISSING",)),),
        status="READY", reason_codes=(),
    )

    async def feed(symbol):
        yield view
        clock[0] = 2.0
        yield replace(view, captured_at_ms=2000, readiness=replace(readiness, entry_quote_ready=True))
        clock[0] = 60.0
        yield replace(view, captured_at_ms=60_000)
        clock[0] = 63.0
        yield replace(view, captured_at_ms=63_000, readiness=replace(readiness, delta_cvd_available=True))
        runtime._stop.set()

    runtime = MultiPairLiveMarketRuntime(
        rest_client=FakeRest(), feed_factory=feed, pipeline=SimpleNamespace(process=lambda view: view),
    )
    runtime._selection = SimpleNamespace(symbols=("BTCUSDT",))

    with caplog.at_level("INFO", logger=live_runtime.__name__):
        await runtime._worker_supervisor("BTCUSDT")

    statuses = [record.message for record in caplog.records if "MARKET_WORKER_FEED_STATUS" in record.message]
    assert len(statuses) == 3
    assert "captures=1" in statuses[0] and "DEPTH_METRICS_MISSING" in statuses[0]
    assert "captures=2" in statuses[1] and "entry_quote=True quote_ready_captures=1" in statuses[1]
    assert "captures=4" in statuses[2] and "delta_cvd=True flow_ready_captures=1" in statuses[2]


@pytest.mark.asyncio
@pytest.mark.parametrize("stream_failure", [False, True], ids=["ended", "failed"])
async def test_replacement_worker_rebuilds_revised_candles_only_for_its_symbol(stream_failure, caplog):
    from test_scalping_market_structure_v2 import BARS_BULL_THEN_BEAR, view_for

    before = view_for(m1_values=BARS_BULL_THEN_BEAR)
    rows = [*BARS_BULL_THEN_BEAR[:-1], ("100.0", "111.0", "98.0", "100.0")]
    revised = view_for(m1_values=rows, now_ms=before.captured_at_ms + 1_000)
    results = []
    resets = []
    launches = 0

    async def feed(symbol):
        nonlocal launches
        launches += 1
        if launches == 1:
            yield before
            if stream_failure:
                error = ValueError("redacted fixture text")
                for kind in (KeyError, OSError, RuntimeError, TypeError):
                    wrapper = kind("redacted fixture text")
                    wrapper.__cause__ = error
                    error = wrapper
                raise error
        elif launches == 2:
            # This is a valid Binance series with a revised last candle at
            # the previous worker's exact continuity anchor.
            assert resets == ["BTCUSDT"]
            yield revised
            runtime._stop.set()
        else:
            runtime._stop.set()

    runtime = MultiPairLiveMarketRuntime(
        rest_client=FakeRest(), feed_factory=feed, on_evidence=results.append,
        on_symbol_reset=resets.append,
        config=LiveMarketRuntimeConfig(worker_restart_seconds=0.001),
    )
    runtime._selection = SimpleNamespace(symbols=("BTCUSDT", "ETHUSDT"))
    healthy = view_for(m1_values=BARS_BULL_THEN_BEAR, symbol="ETHUSDT")
    runtime.pipeline.process(healthy)

    await runtime._worker_supervisor("BTCUSDT")

    assert launches == 2
    assert resets == ["BTCUSDT"]
    assert [result.captured_at_ms for result in results] == [before.captured_at_ms, revised.captured_at_ms]
    assert runtime.pipeline.active_symbols == ("BTCUSDT", "ETHUSDT")
    assert results[-1].structure.timeframe("1m").bar_traces[-1].close == revised.m1.candles[-1].close
    assert "redacted fixture text" not in caplog.text
    reason = "TypeError:RuntimeError:OSError:KeyError" if stream_failure else "FEED_STREAM_ENDED"
    assert f"captures=1 reason={reason}" in caplog.text
    assert "ValueError" not in caplog.text


@pytest.mark.asyncio
async def test_worker_closes_suspended_stream_before_restarting_and_keeps_original_error(caplog):
    launches = 0
    closed = []

    async def feed(symbol):
        nonlocal launches
        launches += 1
        if launches > 1:
            assert closed == [symbol]
            runtime._stop.set()
            return
        try:
            yield None  # Consumer rejects the view while the generator is suspended.
        finally:
            closed.append(symbol)
            raise RuntimeError("cleanup fixture text")

    runtime = MultiPairLiveMarketRuntime(
        rest_client=FakeRest(), feed_factory=feed,
        config=LiveMarketRuntimeConfig(worker_restart_seconds=0.001),
    )
    runtime._selection = SimpleNamespace(symbols=("BTCUSDT",))

    await runtime._worker_supervisor("BTCUSDT")

    assert launches == 2
    assert closed == ["BTCUSDT"]
    assert "MARKET_WORKER_CLOSE_FAILED symbol=BTCUSDT reason=RuntimeError" in caplog.text
    assert "MARKET_WORKER_DEGRADED symbol=BTCUSDT captures=0 reason=TypeError" in caplog.text
    assert "cleanup fixture text" not in caplog.text
