import asyncio
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading.core.database import Database
from divatrading.market_data.absorption import DepthAggressorAlignmentService
from divatrading.market_data.aggregate_trade_history import parse_aggregate_trade_rest_row
from divatrading.market_data.aggregate_trade_history import BinanceAggregateTradeHistoryService
from divatrading.market_data.aggregate_trade_recovery import AggregateTradeRecoveryService
from divatrading.market_data.aggregate_trade_storage import AggregateTradeRepository
from divatrading.market_data.aggregate_trades import AggregateTradeEvent
from divatrading.market_data.order_flow import (
    DEFAULT_BUCKET_INTERVALS,
    DeltaCvdService,
    OrderFlowIntegrityError,
    OrderFlowNotReady,
    OrderFlowRepository,
)
from divatrading.market_data.orchestrator import UnifiedMarketDataOrchestrator

NOW_MS = 1_800_000_000_000
NOW = datetime.fromtimestamp(NOW_MS / 1000, UTC)


def make_record(
    agg_id: int,
    *,
    price: str = "100",
    quantity: str = "0.1",
    buyer_is_maker: bool | None = None,
    time_ms: int | None = None,
    normal_quantity: str = "0.08",
):
    return parse_aggregate_trade_rest_row(
        {
            "a": agg_id,
            "p": price,
            "q": quantity,
            "nq": normal_quantity,
            "f": agg_id * 2,
            "l": agg_id * 2 + 1,
            "T": NOW_MS if time_ms is None else time_ms,
            "m": bool(agg_id % 2 == 0) if buyer_is_maker is None else buyer_is_maker,
        },
        symbol="BTCUSDT",
        received_at_utc=NOW,
    )


@pytest.fixture

def setup(tmp_path: Path):
    database = Database(tmp_path / "order-flow.db")
    assert database.initialize() == 6
    trades = AggregateTradeRepository(database)
    flow = OrderFlowRepository(database)
    return database, trades, flow


def make_service(trades, flow, **kwargs):
    return DeltaCvdService(trades, flow, **kwargs)


def seed(trades, records=None):
    rows = records or [make_record(i) for i in range(100, 110)]
    return trades.bootstrap_latest(rows)


def test_default_bucket_intervals_are_supported_and_resource_bounded():
    assert DEFAULT_BUCKET_INTERVALS == ("1s", "5s", "15s", "1m", "5m")


def test_order_flow_baseline_requires_existing_contiguous_aggregate_stream(setup):
    _, trades, flow = setup
    service = make_service(trades, flow)
    with pytest.raises(OrderFlowNotReady, match="must be bootstrapped"):
        service.process_available(symbol="BTCUSDT")


def test_delta_cvd_base_quote_and_aggressor_mapping_are_exact(setup):
    _, trades, flow = setup
    rows = [
        make_record(10, price="100", quantity="0.5", buyer_is_maker=True),
        make_record(11, price="101", quantity="0.2", buyer_is_maker=False),
        make_record(12, price="99", quantity="0.1", buyer_is_maker=True),
        make_record(13, price="102", quantity="0.4", buyer_is_maker=False),
    ]
    trades.bootstrap_latest(rows)
    service = make_service(trades, flow, bucket_intervals=("1s", "1m"))
    result = service.process_available(symbol="BTCUSDT")
    assert result.complete is True
    snap = service.snapshot(symbol="BTCUSDT", interval="1m", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.buy_volume_base == Decimal("0.6")
    assert snap.sell_volume_base == Decimal("0.6")
    assert snap.delta_base == Decimal("0.0")
    assert snap.buy_volume_quote == Decimal("61.0")
    assert snap.sell_volume_quote == Decimal("59.9")
    assert snap.delta_quote == Decimal("1.1")
    assert snap.cvd_base == Decimal("0.0")
    assert snap.cvd_quote == Decimal("1.1")
    assert snap.trade_count == 4
    assert snap.continuity_valid is True


def test_total_quantity_q_is_used_not_rpi_normal_quantity_nq(setup):
    _, trades, flow = setup
    trades.bootstrap_latest([make_record(1, price="100", quantity="1", buyer_is_maker=False, normal_quantity="0.2")])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.buy_volume_base == Decimal("1")
    assert snap.buy_volume_quote == Decimal("100")


def test_process_is_bounded_and_resumes_from_persisted_cursor(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 106)])
    service = make_service(trades, flow, bucket_intervals=("1s",), max_data_age_ms=60_000)
    first = service.process_available(symbol="BTCUSDT", max_records=2)
    assert first.records_processed == 2
    assert first.complete is False
    assert first.next_from_id == 102
    second = service.process_until_caught_up(symbol="BTCUSDT", max_passes=5, records_per_pass=2)
    assert second.complete is True
    assert second.last_processed_aggregate_trade_id == 105
    state = flow.get_state(symbol="BTCUSDT")
    assert state.last_processed_aggregate_trade_id == 105


def test_duplicate_processing_is_idempotent(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 104)])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    first = service.process_available(symbol="BTCUSDT")
    snap1 = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    second = service.process_available(symbol="BTCUSDT")
    snap2 = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert first.records_processed == 4
    assert second.records_processed == 0
    assert snap2.cvd_base == snap1.cvd_base
    assert snap2.cvd_quote == snap1.cvd_quote
    assert snap2.trade_count == snap1.trade_count


def test_state_and_cvd_survive_database_reopen(setup, tmp_path):
    database, trades, flow = setup
    seed(trades, [make_record(i) for i in range(20, 24)])
    service = make_service(trades, flow, bucket_intervals=("1m",))
    service.process_available(symbol="BTCUSDT")
    expected = flow.get_state(symbol="BTCUSDT")
    reopened = Database(tmp_path / "order-flow.db")
    reopened.initialize()
    new_flow = OrderFlowRepository(reopened)
    loaded = new_flow.get_state(symbol="BTCUSDT")
    assert loaded.last_processed_aggregate_trade_id == expected.last_processed_aggregate_trade_id
    assert loaded.cumulative_delta_base == expected.cumulative_delta_base
    assert loaded.cumulative_delta_quote == expected.cumulative_delta_quote


def test_flow_processes_only_safe_prefix_when_aggregate_source_is_degraded(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 103)])
    # Persist an out-of-sequence WebSocket event to create a source gap at 103-104.
    from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord
    rec = make_record(105)
    ws = AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=rec.aggregate_trade_id,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=NOW_MS, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="wss://fstream.binance.com/market/ws", received_at_utc=rec.received_at_utc,
    )
    trades.record_observed(ws)
    service = make_service(trades, flow, bucket_intervals=("1s",))
    result = service.process_available(symbol="BTCUSDT")
    assert result.last_processed_aggregate_trade_id == 102
    assert result.source_contiguous_aggregate_trade_id == 102
    assert result.status == "DEGRADED"
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.continuity_valid is False
    assert snap.status == "DEGRADED"


def test_reconciled_source_allows_cvd_to_continue_without_reset(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 103)])
    from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord
    rec = make_record(105)
    ws = AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=105,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=NOW_MS, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="wss://fstream.binance.com/market/ws", received_at_utc=rec.received_at_utc,
    )
    trades.record_observed(ws)
    service = make_service(trades, flow, bucket_intervals=("1s",))
    service.process_available(symbol="BTCUSDT")
    # Recovery inserts the exact missing rows; no synthetic records are made.
    missing = [make_record(103), make_record(104)]
    trades.persist_recovered(missing, symbol="BTCUSDT")
    assert trades.get_stream_state("BTCUSDT").status == "HEALTHY"
    result = service.process_available(symbol="BTCUSDT")
    assert result.complete is True
    assert result.last_processed_aggregate_trade_id == 105
    assert service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS).continuity_valid


@pytest.mark.asyncio
async def test_orchestrator_catches_up_safe_sqlite_prefix_before_aggregate_gap_is_filled(setup):
    _, trades, flow = setup
    symbol = "BTCUSDT"
    seed(trades)
    service = make_service(trades, flow, bucket_intervals=("1s",))
    service.process_available(symbol=symbol, max_records=2)
    recovery = AggregateTradeRecoveryService(history=None, repository=trades)
    events = []
    for aggregate_id in (110, 111, 113, 114):
        raw = make_record(aggregate_id)
        events.append(AggregateTradeEvent(
            symbol=symbol, aggregate_trade_id=aggregate_id, price=raw.price,
            quantity=raw.quantity, first_trade_id=raw.first_trade_id, last_trade_id=raw.last_trade_id,
            event_time_ms=NOW_MS, trade_time_ms=NOW_MS, buyer_is_maker=raw.buyer_is_maker,
            source_endpoint="wss://fixture", stream_name="btcusdt@aggTrade", received_at_utc=NOW,
        ))
    upstream = recovery.ingest_websocket_events(events)
    assert upstream.status == "DEGRADED"
    assert upstream.last_contiguous_aggregate_trade_id == 111

    queue = asyncio.Queue(maxsize=20)
    feed = SimpleNamespace(
        symbols=(symbol,), is_connected=True, events=queue, get_event=queue.get, run=lambda stop: stop.wait(),
    )
    depth = SimpleNamespace(symbols=(symbol,), health=lambda symbol: None, metrics=lambda symbol: None)
    orchestrator = UnifiedMarketDataOrchestrator(
        aggregate_feed=feed, aggregate_recovery=recovery, delta_cvd=service,
        order_book_supervisor=depth, evidence_service=DepthAggressorAlignmentService(),
        wall_clock_ms=lambda: NOW_MS,
    )
    # No REST pass is due yet. Maintenance must still process the safe prefix.
    orchestrator._runtimes[symbol].last_recovery_attempt_ms = NOW_MS
    await orchestrator._maintain_symbol(symbol)

    degraded = orchestrator.health(symbol)
    assert degraded.flow.last_processed_aggregate_trade_id == 111
    assert not degraded.delta_cvd_ready
    assert not degraded.aggregate_trade_continuity

    trades.persist_recovered([make_record(112)], symbol=symbol)
    await orchestrator._maintain_symbol(symbol)

    recovered = orchestrator.health(symbol)
    assert recovered.flow.last_processed_aggregate_trade_id == 114
    assert recovered.flow.trade_count == 15
    assert recovered.aggregate_trade_continuity
    assert recovered.delta_cvd_ready


def test_unresolved_source_gap_propagates_and_blocks_future_cvd(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 103)])
    from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord
    rec = make_record(105)
    ws = AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=105,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=NOW_MS, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="wss://fstream.binance.com/market/ws", received_at_utc=rec.received_at_utc,
    )
    trades.record_observed(ws)
    trades.mark_unresolved(symbol="BTCUSDT", status="UNRESOLVED_HISTORY", reason="fixture history unavailable")
    service = make_service(trades, flow, bucket_intervals=("1s",))
    result = service.process_available(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    cursor = result.last_processed_aggregate_trade_id
    blocked = service.process_available(symbol="BTCUSDT")
    assert blocked.records_processed == 0
    assert blocked.last_processed_aggregate_trade_id == cursor
    assert service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS).status == "UNRESOLVED"


def test_missing_raw_row_before_safe_cursor_marks_flow_unresolved(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(100, 104)])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    # Initialize flow state then simulate external raw-row loss before processing.
    service._ensure_baseline("BTCUSDT")
    with trades.database.transaction() as connection:
        connection.execute("DELETE FROM aggregate_trades WHERE symbol='BTCUSDT' AND aggregate_trade_id=100")
    result = service.process_available(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    assert result.records_processed == 0


def test_trade_time_regression_marks_unresolved_and_does_not_bridge(setup):
    _, trades, flow = setup
    rows = [
        make_record(1, time_ms=NOW_MS),
        make_record(2, time_ms=NOW_MS - 1_000),
        make_record(3, time_ms=NOW_MS + 1_000),
    ]
    trades.bootstrap_latest(rows)
    service = make_service(trades, flow, bucket_intervals=("1s",))
    result = service.process_available(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    assert result.records_processed == 1
    assert result.last_processed_aggregate_trade_id == 1


def test_snapshot_computes_base_and_quote_imbalance(setup):
    _, trades, flow = setup
    trades.bootstrap_latest([
        make_record(1, price="100", quantity="3", buyer_is_maker=False),
        make_record(2, price="100", quantity="1", buyer_is_maker=True),
    ])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.delta_base == Decimal("2")
    assert snap.buy_imbalance_base == Decimal("0.5")
    assert snap.delta_quote == Decimal("200")
    assert snap.buy_imbalance_quote == Decimal("0.5")


def test_snapshot_freshness_is_separate_from_continuity(setup):
    _, trades, flow = setup
    trades.bootstrap_latest([make_record(1, time_ms=NOW_MS - 20_000)])
    service = make_service(trades, flow, bucket_intervals=("1s",), max_data_age_ms=10_000)
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.continuity_valid is True
    assert snap.is_fresh is False
    assert snap.data_age_ms == 20_000


def test_snapshot_marks_future_timestamps_not_fresh(setup):
    _, trades, flow = setup
    trades.bootstrap_latest([make_record(1, time_ms=NOW_MS + 10_000)])
    service = make_service(trades, flow, bucket_intervals=("1s",), future_skew_ms=5_000)
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.is_fresh is False
    assert snap.data_age_ms == -10_000


def test_multiple_timeframe_buckets_are_aligned_to_epoch(setup):
    _, trades, flow = setup
    time_a = NOW_MS // 60_000 * 60_000 + 1_000
    time_b = time_a + 2_000
    trades.bootstrap_latest([
        make_record(1, time_ms=time_a),
        make_record(2, time_ms=time_b),
    ])
    service = make_service(trades, flow, bucket_intervals=("1s", "5s", "1m"))
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=5, now_ms=time_b)
    assert snap.trade_count == 2
    assert snap.window_start_ms == (time_b // 1_000) * 1_000 - 4_000
    assert snap.window_end_ms == (time_b // 1_000) * 1_000 + 1_000


def test_deterministic_replay_reproduces_same_cvd_and_buckets(setup):
    _, trades, flow = setup
    records = [make_record(i, price=str(100 + (i % 3)), quantity="0.25") for i in range(100, 110)]
    trades.bootstrap_latest(records)
    service = make_service(trades, flow, bucket_intervals=("1s", "1m"))
    service.process_until_caught_up(symbol="BTCUSDT", max_passes=10, records_per_pass=3)
    first = service.snapshot(symbol="BTCUSDT", interval="1m", lookback_buckets=1, now_ms=NOW_MS)
    service.reset_for_replay(symbol="BTCUSDT")
    service.process_until_caught_up(symbol="BTCUSDT", max_passes=10, records_per_pass=3)
    second = service.snapshot(symbol="BTCUSDT", interval="1m", lookback_buckets=1, now_ms=NOW_MS)
    assert second.cvd_base == first.cvd_base
    assert second.cvd_quote == first.cvd_quote
    assert second.delta_base == first.delta_base
    assert second.delta_quote == first.delta_quote
    assert second.trade_count == first.trade_count


def test_replay_is_blocked_for_non_healthy_aggregate_source(setup):
    _, trades, flow = setup
    seed(trades, [make_record(i) for i in range(10, 13)])
    from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord
    rec = make_record(15)
    ws = AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=15,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=NOW_MS, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="fixture", received_at_utc=rec.received_at_utc,
    )
    trades.record_observed(ws)
    service = make_service(trades, flow, bucket_intervals=("1s",))
    with pytest.raises(OrderFlowIntegrityError, match="requires a HEALTHY"):
        service.reset_for_replay(symbol="BTCUSDT")


def test_snapshot_requires_initialized_derived_state(setup):
    _, trades, flow = setup
    seed(trades, [make_record(1), make_record(2)])
    service = make_service(trades, flow)
    with pytest.raises(OrderFlowNotReady):
        service.snapshot(symbol="BTCUSDT")


def test_config_validation_for_intervals_batches_and_windows(setup):
    _, trades, flow = setup
    with pytest.raises(ValueError, match="bucket_intervals"):
        make_service(trades, flow, bucket_intervals=("2m",))
    seed(trades, [make_record(1)])
    service = make_service(trades, flow, bucket_intervals=("1m",))
    with pytest.raises(ValueError, match="max_records"):
        service.process_available(symbol="BTCUSDT", max_records=0)
    with pytest.raises(ValueError, match="lookback_buckets"):
        service.snapshot(symbol="BTCUSDT", lookback_buckets=0)
    with pytest.raises(ValueError, match="interval"):
        service.snapshot(symbol="BTCUSDT", interval="5m")


def test_zero_total_window_volume_has_zero_imbalance(setup):
    _, trades, flow = setup
    trades.bootstrap_latest([make_record(1, time_ms=NOW_MS - 120_000)])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    service.process_available(symbol="BTCUSDT")
    snap = service.snapshot(symbol="BTCUSDT", interval="1s", lookback_buckets=1, now_ms=NOW_MS)
    assert snap.trade_count == 0
    assert snap.buy_imbalance_base == Decimal("0")
    assert snap.buy_imbalance_quote == Decimal("0")


def test_process_until_caught_up_validates_bounds(setup):
    _, trades, flow = setup
    seed(trades, [make_record(1)])
    service = make_service(trades, flow, bucket_intervals=("1s",))
    with pytest.raises(ValueError, match="max_passes"):
        service.process_until_caught_up(symbol="BTCUSDT", max_passes=0)
    with pytest.raises(ValueError, match="records_per_pass"):
        service.process_until_caught_up(symbol="BTCUSDT", records_per_pass=0)
