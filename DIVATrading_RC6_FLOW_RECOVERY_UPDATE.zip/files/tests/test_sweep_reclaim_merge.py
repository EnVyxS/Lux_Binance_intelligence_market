from dataclasses import replace
from decimal import Decimal
import json
import logging
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.market_data.klines import Kline
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.strategy.scalping_market_data import InstrumentSpec
from divatrading.strategy.scalping_pipeline import SMCV2EvidenceSnapshot
from divatrading.trading.sweep_reclaim import (
    SWEEP_RECLAIM_STRATEGY_ID,
    SweepReclaimConfig,
    SweepReclaimPlanner,
)


BASE = 1_800_000_000_000
STEP = 300_000
BREAK = BASE + 14 * STEP - 1
SYMBOL = "BTCUSDT"
FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def _candle(slot, high, low, close, interval, side, symbol):
    high, low, close = map(Decimal, (high, low, close))
    if side == -1:
        high, low, close = 200 - low, 200 - high, 200 - close
    width = 3 if interval == "15m" else 1
    start, end = BASE + (slot - width) * STEP, BASE + slot * STEP - 1
    row = [start, str(close), str(high), str(low), str(close), "1",
           end, "100", 10, "0.5", "50", "0"]
    return Kline.from_binance_row(row, symbol=symbol, interval=interval, source_endpoint="fixture")


def _evidence(
    *,
    now=BREAK + 1_000,
    bid="100.33",
    ask="100.35",
    update_id=1,
    event_at=None,
    last_closed=14,
    side=1,
    symbol=SYMBOL,
    depth_ready=True,
    depth_generation=0,
    flow_generation=0,
    flow_start=None,
    target="102.60",
):
    meta = parse_exchange_info(json.loads(FIXTURE.read_text()), source_endpoint="fixture")
    instrument = replace(
        InstrumentSpec.from_symbol_info(meta.get_symbol(SYMBOL)),
        symbol=symbol, tick_size=Decimal("0.01"), min_price=None, max_price=None,
        order_types=("LIMIT", "MARKET", "STOP_MARKET", "TAKE_PROFIT_MARKET"),
        time_in_force=("GTC", "IOC"),
    )
    m15 = tuple(
        _candle(slot, high, low, close, "15m", side, symbol)
        for slot, high, low, close in [
            (0, "101.10", "100.00", "100.11"),
            (3, "101.20", "100.01", "100.14"),
            (6, target, "99.80", "100.38"),
            (9, "101.15", "99.95", "100.18"),
            (12, "100.35", "99.96", "100.05"),
        ]
    )
    m5 = tuple(
        _candle(slot, high, low, close, "5m", side, symbol)
        for slot, high, low, close in [
            (-2, "100.98", "100.04", "100.31"),
            (-1, "101.10", "100.01", "100.42"),
            (0, "100.50", "100.00", "100.11"),
            (1, "100.99", "100.04", "100.40"),
            (2, "101.20", "100.02", "100.12"),
            (3, "100.45", "100.01", "100.14"),
            (4, target, "100.20", "100.90"),
            (5, "100.70", "99.80", "100.30"),
            (6, "100.68", "100.26", "100.38"),
            (7, "101.15", "100.08", "100.24"),
            (8, "100.30", "99.95", "100.26"),
            (9, "100.33", "99.98", "100.18"),
            (10, "100.35", "100.02", "100.18"),
            (11, "100.22", "100.01", "100.20"),
            (12, "100.23", "99.96", "100.05"),
            (13, "100.14", "99.65", "99.90"),
            (14, "100.46", "99.87", "100.40"),
        ]
        if slot <= last_closed
    )
    bid, ask = Decimal(bid), Decimal(ask)
    if side == -1:
        bid, ask = 200 - ask, 200 - bid
    event_at = now if event_at is None else event_at
    quote = OrderBookMetrics(
        symbol, update_id, bid, ask, ask - bid, (ask - bid) * 20_000 / (bid + ask),
        Decimal("10"), Decimal("10"), Decimal("0"), 5, 5, depth_ready, event_at,
    )
    flow = None if flow_start is None else SimpleNamespace(
        symbol=symbol, is_fresh=True, continuity_valid=True, window_start_ms=flow_start,
        last_trade_time_ms=now - 10, trade_count=4,
        buy_volume_quote=Decimal("100"), sell_volume_quote=Decimal("300"),
        delta_quote=Decimal(-200 * side),
    )
    view = SimpleNamespace(
        symbol=symbol, captured_at_ms=now, instrument=instrument,
        m5=SimpleNamespace(candles=m5), m15=SimpleNamespace(candles=m15),
        readiness=SimpleNamespace(
            m5_setup_ready=True, m15_context_available=True,
            entry_quote_ready=depth_ready, delta_cvd_available=flow is not None,
        ),
        order_book_metrics=quote, flow=flow,
        orchestrator_readiness=SimpleNamespace(
            depth_reconnect_generation=depth_generation,
            aggregate_trade_reconnect_generation=flow_generation,
        ),
    )
    return SMCV2EvidenceSnapshot(symbol, now, None, None, None, None, view)


def _evaluate(planner, evidence, **options):
    return planner.evaluate(evidence, equity_usdt=Decimal("1000"), qualification_only=True, **options)


def _bounce(**options):
    return _evidence(now=BREAK + 1_500, bid="100.35", ask="100.37", update_id=2, **options)


@pytest.mark.parametrize("side,entry,stop,target", [
    (1, "100.38", "99.63", "102.58"),
    (-1, "99.63", "100.37", "97.42"),
])
def test_passes_deferred_decimal_ioc_plan_after_causal_retest(side, entry, stop, target):
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence(
        now=BREAK - STEP + 1_000, last_closed=13, side=side,
    )).qualified_signals
    assert not _evaluate(planner, _evidence(side=side)).qualified_signals
    # A repeated depth update cannot serve as the second leg of the retest.
    repeated = _evidence(now=BREAK + 1_250, bid="100.35", ask="100.37", side=side)
    assert not _evaluate(planner, repeated).qualified_signals
    result = _evaluate(planner, _bounce(side=side))
    assert len(result.qualified_signals) == 1
    signal = result.qualified_signals[0]
    assert signal.strategy_id == SWEEP_RECLAIM_STRATEGY_ID
    assert signal.entry_type == "LIMIT_IOC"
    assert signal.side == ("LONG" if side == 1 else "SHORT")
    assert signal.entry_price == Decimal(entry)
    assert signal.stop_loss == Decimal(stop)
    assert signal.take_profit == Decimal(target)
    assert signal.minimum_net_rr == Decimal("2")
    assert not result.plans
    assert _evaluate(planner, _bounce(side=side)).evaluations[0].status == "ALREADY_EMITTED"


def test_planner_requires_estimated_net_rr_and_does_not_extend_target():
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence(target="102.02")).qualified_signals
    result = _evaluate(planner, _bounce(target="102.02"))
    assert result.evaluations[0].reason_codes == ("SWEEP_NET_RR_BELOW_MINIMUM",)
    assert not result.qualified_signals


@pytest.mark.parametrize("target,expected", [
    ("102.60", "RISK_REJECTED"),
    ("103.80", "PLANNED"),
])
def test_portfolio_sizing_rechecks_net_rr_with_rc6_cost_reserves(target, expected):
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence(target=target)).qualified_signals
    result = planner.evaluate(_bounce(target=target), equity_usdt=Decimal("1000"))
    item = result.evaluations[0]
    assert item.status == expected
    if expected == "RISK_REJECTED":
        assert "IOC_REWARD_RISK_BELOW_MINIMUM_AFTER_COSTS" in item.reason_codes
        assert not result.plans
    else:
        assert item.plan is not None
        assert item.plan.quantity > 0
        assert item.plan.signal.entry_price == Decimal("100.38")
        assert item.plan.fee_reserve_usdt > 0
        assert item.plan.slippage_reserve_usdt > 0
        assert item.plan.funding_reserve_usdt > 0


def test_depth_gap_discards_touch_instead_of_using_a_stale_retest():
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence()).qualified_signals
    gap = _evidence(now=BREAK + 1_100, depth_ready=False)
    assert _evaluate(planner, gap).evaluations[0].reason_codes == ("SWEEP_ENTRY_QUOTE_UNAVAILABLE",)
    assert not _evaluate(planner, _bounce()).qualified_signals


def test_optional_delta_rejects_volume_before_the_retest():
    planner = SweepReclaimPlanner(config=SweepReclaimConfig(require_flow_alignment=True))
    assert not _evaluate(planner, _evidence()).qualified_signals
    result = _evaluate(planner, _bounce(flow_start=BREAK + 999))
    assert result.evaluations[0].reason_codes == ("SWEEP_RETEST_FLOW_INSUFFICIENT",)
    fresh_flow = _evidence(
        now=BREAK + 2_000, bid="100.35", ask="100.37", update_id=3, flow_start=BREAK + 1_000,
    )
    assert "RETEST_ADVERSE_FLOW_WITH_PRICE_RECOVERY" in _evaluate(
        planner, fresh_flow,
    ).qualified_signals[0].reason_codes


@pytest.mark.parametrize("require_flow,generation", [
    (False, {"depth_generation": 1}),
    (True, {"flow_generation": 1}),
])
def test_reconnect_requires_a_new_touch_and_rebound(require_flow, generation):
    planner = SweepReclaimPlanner(config=SweepReclaimConfig(require_flow_alignment=require_flow))
    assert not _evaluate(planner, _evidence()).qualified_signals
    assert not _evaluate(planner, _bounce(flow_start=BREAK + 1_000, **generation)).qualified_signals

    touch_time = BREAK + 2_000
    assert not _evaluate(planner, _evidence(now=touch_time, update_id=3, **generation)).qualified_signals
    rebound = _evidence(
        now=touch_time + 500, bid="100.35", ask="100.37", update_id=4,
        flow_start=touch_time, **generation,
    )
    assert _evaluate(planner, rebound).qualified_signals


def test_order_flow_reconnect_does_not_reset_a_quote_only_retest():
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence()).qualified_signals
    assert _evaluate(planner, _bounce(flow_generation=1)).qualified_signals


def test_retest_state_is_isolated_between_pairs():
    planner = SweepReclaimPlanner()
    assert not _evaluate(planner, _evidence()).qualified_signals
    assert not _evaluate(planner, _bounce(symbol="ETHUSDT")).qualified_signals
    assert _evaluate(planner, _bounce()).qualified_signals[0].symbol == SYMBOL


@pytest.mark.parametrize("m5,m15,reason", [
    (False, True, "M5_NOT_READY"),
    (True, False, "M15_NOT_READY"),
    (False, False, "M5_M15_NOT_READY"),
])
def test_scan_wait_reason_distinguishes_unready_timeframes(m5, m15, reason):
    evidence = _evidence()
    evidence.market_view.readiness.m5_setup_ready = m5
    evidence.market_view.readiness.m15_context_available = m15
    result = _evaluate(SweepReclaimPlanner(), evidence)
    assert result.evaluations == ()
    assert result.scan_wait_reason == reason


def test_scan_wait_reasons_preserve_the_original_no_entry_paths():
    planner = SweepReclaimPlanner()
    invalid = _evidence()
    invalid.market_view.captured_at_ms += 1
    assert _evaluate(planner, invalid).scan_wait_reason == "INVALID_VIEW"
    before_break = _evidence(now=BREAK - STEP + 1_000, last_closed=13)
    assert _evaluate(planner, before_break).scan_wait_reason == "NO_ACTIVE_SETUP"
    assert _evaluate(planner, _evidence()).scan_wait_reason == "RETEST_WAIT"
    assert _evaluate(planner, _evidence(now=BREAK + 500)).scan_wait_reason == "NONMONOTONIC_CAPTURE"
    result = _evaluate(planner, _bounce())
    assert result.scan_wait_reason is None
    assert result.qualified_signals


def test_sweep_scan_status_reports_snapshot_counts_and_prunes_removed_symbols(caplog):
    from divatrading.cli import _SweepScanStatus

    caplog.set_level(logging.INFO)
    diagnostics = _SweepScanStatus(logging.getLogger(__name__))
    planner = SweepReclaimPlanner()
    waiting = _evaluate(planner, _evidence())
    qualified = _evaluate(planner, _bounce())
    evaluation = qualified.evaluations[0]
    mixed = replace(qualified, evaluations=(
        evaluation, evaluation, replace(evaluation, status="REJECTED", signal=None),
    ))
    diagnostics.observe(SYMBOL, waiting, now=0)
    diagnostics.observe("ETHUSDT", replace(waiting, symbol="ETHUSDT"), now=0)
    diagnostics.observe(SYMBOL, mixed, now=59.9)
    assert not caplog.records

    diagnostics.retain_symbols({SYMBOL})
    diagnostics.observe(SYMBOL, waiting, now=60)
    diagnostics.observe("ETHUSDT", replace(waiting, symbol="ETHUSDT"), now=60)
    diagnostics.retain_symbols({SYMBOL, "ETHUSDT"})
    diagnostics.observe("ETHUSDT", replace(waiting, symbol="ETHUSDT"), now=70)
    diagnostics.observe(SYMBOL, waiting, now=120)

    assert len(caplog.records) == 2
    first, second = (record.getMessage() for record in caplog.records)
    assert first.startswith(f"SWEEP_SCAN_STATUS symbol={SYMBOL} window_seconds=60.0")
    assert json.loads(first.split(" snapshot_counts=", 1)[1]) == {
        "TOTAL": 2, "WITH_EVALUATIONS": 1, "RETEST_WAIT": 1, "QUALIFIED": 1, "REJECTED": 1,
    }
    assert second.startswith(f"SWEEP_SCAN_STATUS symbol={SYMBOL} window_seconds=60.0")
    assert json.loads(second.split(" snapshot_counts=", 1)[1]) == {"TOTAL": 1, "RETEST_WAIT": 1}
