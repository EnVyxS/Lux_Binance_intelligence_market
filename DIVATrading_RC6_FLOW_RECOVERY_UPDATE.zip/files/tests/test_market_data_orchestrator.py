from __future__ import annotations

import asyncio
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from threading import Event
from types import SimpleNamespace

import pytest

from divatrading.market_data.aggregate_trade_storage import AggregateTradeStreamStateError
from divatrading.market_data.aggregate_trades import AggregateTradeEvent
from divatrading.market_data.aggregate_trade_fanout import (
    AggregateTradeEventFanout,
    AggregateTradeFanoutQueueFullError,
)
from divatrading.market_data.order_book import OrderBookMetrics, OrderBookNotReady
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.order_flow import OrderFlowSnapshot
from divatrading.market_data.orchestrator import (
    MarketDataOrchestratorConfig,
    MarketDataOrchestratorError,
    MarketDataQueueFullError,
    UnifiedMarketDataOrchestrator,
)

NOW = 1_800_000_000_000


def sample_flow(*, status="HEALTHY", fresh=True, last_id=10, trade_time=NOW + 1500):
    return OrderFlowSnapshot(
        symbol="BTCUSDT", status=status, continuity_valid=status == "HEALTHY",
        is_fresh=fresh, data_age_ms=500, baseline_aggregate_trade_id=1,
        last_processed_aggregate_trade_id=last_id, last_trade_time_ms=trade_time,
        cvd_base=Decimal("1"), cvd_quote=Decimal("100"), bucket_interval="1s",
        lookback_buckets=5, window_start_ms=NOW, window_end_ms=NOW + 5000,
        buy_volume_base=Decimal("2"), sell_volume_base=Decimal("1"),
        delta_base=Decimal("1"), buy_volume_quote=Decimal("200"),
        sell_volume_quote=Decimal("100"), delta_quote=Decimal("100"),
        buy_imbalance_base=Decimal("0.33"), buy_imbalance_quote=Decimal("0.33"),
        trade_count=3, integrity_reason=None,
    )


def book_health(*, ready=True, update_id=100):
    return OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED" if ready else "DISCONNECTED",
        snapshot_state="READY" if ready else "RESYNC_REQUIRED", sequence_integrity=ready,
        event_fresh=ready, queue_healthy=ready, ready=ready, update_id=update_id,
        event_age_ms=100, queue_depth=0, queue_capacity=100, buffered_events=0,
        invalid_reason="NONE" if ready else "FEED_DISCONNECTED", last_error=None,
    )


def book_metrics(*, update_id=100, t=NOW + 1800):
    return OrderBookMetrics(
        symbol="BTCUSDT", update_id=update_id, best_bid=Decimal("100"),
        best_ask=Decimal("101"), spread=Decimal("1"), spread_bps=Decimal("99.5"),
        bid_depth=Decimal("10"), ask_depth=Decimal("10"), imbalance=Decimal("0"),
        level_count_bid=20, level_count_ask=20, synchronized=True, last_event_time_ms=t,
    )


def agg_event(symbol="BTCUSDT", aggregate_id=11):
    return AggregateTradeEvent(
        symbol=symbol, aggregate_trade_id=aggregate_id, price=Decimal("100.5"),
        quantity=Decimal("0.1"), first_trade_id=20, last_trade_id=20,
        event_time_ms=NOW + 1500, trade_time_ms=NOW + 1500,
        buyer_is_maker=False, source_endpoint="wss://test", stream_name="btcusdt@aggTrade",
        received_at_utc=datetime.now(UTC),
    )


class FakeAggregateFeed:
    def __init__(self, symbols=("BTCUSDT",), capacity=32):
        self.symbols = tuple(symbols)
        self.events = asyncio.Queue(maxsize=capacity)
        self.is_connected = False
        self.stats = SimpleNamespace(connection_count=0, queue_overflows=0)

    async def get_event(self):
        return await self.events.get()

    async def run(self, stop_event):
        self.stats.connection_count += 1
        self.is_connected = True
        try:
            await stop_event.wait()
        finally:
            self.is_connected = False


class FakeRepository:
    def __init__(self, status="MISSING"):
        self.status = status
        self.ingested = []

    def get_stream_state(self, symbol):
        if self.status == "MISSING":
            raise AggregateTradeStreamStateError("missing")
        return SimpleNamespace(status=self.status, symbol=symbol)


class FakeRecovery:
    def __init__(self, status="MISSING"):
        self.repository = FakeRepository(status)
        self.bootstrapped = []
        self.recoveries = 0

    def bootstrap_latest(self, *, symbol, limit=None):
        self.bootstrapped.append((symbol, limit))
        self.repository.status = "HEALTHY"
        return SimpleNamespace(status="HEALTHY", symbol=symbol)

    def ingest_websocket_event(self, event):
        self.repository.ingested.append(event)
        return SimpleNamespace(status=self.repository.status, symbol=event.symbol)

    def recover_gap(self, *, symbol):
        self.recoveries += 1
        self.repository.status = "HEALTHY"
        return SimpleNamespace(status="HEALTHY", symbol=symbol)


class FakeDelta:
    max_data_age_ms = 10_000
    future_skew_ms = 5_000

    def __init__(self, flow=None):
        self.value = flow or sample_flow()
        self.process_calls = []

    def process_until_caught_up(self, **kwargs):
        self.process_calls.append(kwargs)

    def snapshot(self, **kwargs):
        return self.value


class FakeDepthFeed:
    def __init__(self):
        self.stats = SimpleNamespace(connection_count=0)


class FakeDepthSupervisor:
    def __init__(self, ready=True, symbols=("BTCUSDT",)):
        self.symbols = tuple(symbols)
        self.feed = FakeDepthFeed()
        self._ready = ready
        self._metrics = book_metrics()

    async def run(self, stop_event):
        self.feed.stats.connection_count += 1
        await stop_event.wait()

    def health(self, symbol):
        return book_health(ready=self._ready, update_id=self._metrics.update_id)

    def metrics(self, symbol):
        if not self._ready:
            raise OrderBookNotReady("not ready")
        return self._metrics


@dataclass
class FakeEvidenceResult:
    status: str = "WARMING_UP"
    reason_codes: tuple[str, ...] = ()


class FakeEvidenceService:
    def __init__(self, result=None):
        self.result = result or FakeEvidenceResult()
        self.observations = []
        self.resets = []

    def observe(self, **kwargs):
        self.observations.append(kwargs)
        return self.result

    def reset_symbol(self, symbol, reason):
        self.resets.append((symbol, reason))


def make_orchestrator(*, feed=None, recovery=None, delta=None, depth=None, evidence=None,
                      fanout=None, config=None, now=NOW + 2000, recovery_gate=None):
    feed = feed or FakeAggregateFeed()
    recovery = recovery or FakeRecovery()
    delta = delta or FakeDelta()
    depth = depth or FakeDepthSupervisor()
    evidence = evidence or FakeEvidenceService()
    service = UnifiedMarketDataOrchestrator(
        aggregate_feed=feed, aggregate_recovery=recovery, delta_cvd=delta,
        order_book_supervisor=depth, evidence_service=evidence,
        aggregate_event_fanout=fanout,
        config=config or MarketDataOrchestratorConfig(maintenance_interval_ms=50),
        wall_clock_ms=lambda: now,
        aggregate_recovery_gate=recovery_gate,
    )
    return service, feed, recovery, delta, depth, evidence


async def wait_until(predicate, timeout=1.0):
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        if predicate():
            return
        await asyncio.sleep(0.005)
    raise AssertionError("condition not reached")


def test_config_hard_bounds_are_enforced():
    with pytest.raises(ValueError):
        MarketDataOrchestratorConfig(event_queue_capacity=32769)
    with pytest.raises(ValueError):
        MarketDataOrchestratorConfig(records_per_pass=5001)
    with pytest.raises(ValueError):
        MarketDataOrchestratorConfig(process_max_passes=21)


def test_constructor_requires_identical_symbol_universe():
    with pytest.raises(ValueError, match="same non-empty symbols"):
        make_orchestrator(feed=FakeAggregateFeed(("BTCUSDT", "ETHUSDT")),
                          depth=FakeDepthSupervisor(symbols=("BTCUSDT",)))


def test_initial_health_is_bootstrapping_and_not_ready():
    service, *_ = make_orchestrator()
    state = service.health("BTCUSDT")
    assert state.status == "BOOTSTRAPPING"
    assert not state.ready
    assert state.reason_codes == ("ORCHESTRATOR_NOT_STARTED",)


def test_run_bootstraps_missing_symbols_drains_events_and_exposes_unified_ready():
    async def scenario():
        service, feed, recovery, delta, depth, evidence = make_orchestrator()
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: bool(recovery.bootstrapped))
        await feed.events.put(agg_event())
        await wait_until(lambda: len(recovery.repository.ingested) == 1)
        await wait_until(lambda: service.health("BTCUSDT").ready)
        state = service.health("BTCUSDT")
        assert state.status == "READY"
        assert state.aggregate_trade_continuity
        assert state.delta_cvd_ready and state.order_book_ready and state.queues_healthy
        assert state.evidence_status == "WARMING_UP"
        assert len(evidence.observations) == 1
        assert delta.process_calls
        assert recovery.bootstrapped == [("BTCUSDT", 1000)]
        stop.set()
        await asyncio.wait_for(task, 1)
        assert service.health("BTCUSDT").status == "STOPPED"
        assert not service.is_running
    asyncio.run(scenario())


def test_existing_healthy_stream_is_not_bootstrapped_again():
    async def scenario():
        service, _, recovery, _, _, _ = make_orchestrator(recovery=FakeRecovery(status="HEALTHY"))
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: service.is_running)
        await asyncio.sleep(0.06)
        assert recovery.bootstrapped == []
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_degraded_stream_recovery_is_scheduled_and_restores_readiness():
    async def scenario():
        recovery = FakeRecovery(status="DEGRADED")
        service, _, _, _, _, _ = make_orchestrator(recovery=recovery)
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: recovery.recoveries > 0)
        await wait_until(lambda: service.health("BTCUSDT").ready)
        assert recovery.repository.status == "HEALTHY"
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_recovery_wait_and_fetch_leave_ingest_free_and_recheck_raw_state():
    class BlockingRecovery(FakeRecovery):
        def __init__(self):
            super().__init__("DEGRADED")
            self.fetch_started = Event()
            self.release_fetch = Event()

        def recover_gap(self, *, symbol):
            self.fetch_started.set()
            assert self.release_fetch.wait(2)
            return SimpleNamespace(symbol=symbol, status="DEGRADED")

        def ingest_websocket_event(self, event):
            if event.aggregate_trade_id == 12:
                self.repository.status = "HEALTHY"
            return super().ingest_websocket_event(event)

    async def scenario():
        recovery = BlockingRecovery()
        gate = asyncio.Semaphore(1)
        service, feed, *_ = make_orchestrator(recovery=recovery, recovery_gate=gate)
        feed.is_connected = True
        stop = asyncio.Event()
        async with gate:
            maintenance = asyncio.create_task(service._maintain_symbol("BTCUSDT"))
            worker = asyncio.create_task(service._process_aggregate_events(stop))
            try:
                service._events.put_nowait(agg_event())
                await asyncio.wait_for(service._events.join(), 1)
                assert not recovery.fetch_started.is_set()
            except BaseException:
                maintenance.cancel()
                worker.cancel()
                await asyncio.gather(maintenance, worker, return_exceptions=True)
                raise
        try:
            await wait_until(recovery.fetch_started.is_set)
            service._events.put_nowait(agg_event(aggregate_id=12))
            await asyncio.wait_for(service._events.join(), 1)
            assert [event.aggregate_trade_id for event in recovery.repository.ingested] == [11, 12]
        finally:
            recovery.release_fetch.set()
            stop.set()
            await asyncio.wait_for(asyncio.gather(worker, maintenance), 1)
        assert service.health("BTCUSDT").aggregate_trade_continuity
        assert service.health("BTCUSDT").delta_cvd_ready

    asyncio.run(scenario())


def test_unresolved_trade_gap_blocks_readiness_and_evidence():
    async def scenario():
        recovery = FakeRecovery(status="UNRESOLVED")
        service, _, _, _, _, evidence = make_orchestrator(recovery=recovery)
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: service.health("BTCUSDT").status == "DEGRADED")
        state = service.health("BTCUSDT")
        assert not state.ready
        assert "AGGREGATE_TRADE_CONTINUITY_INVALID" in state.reason_codes
        assert evidence.observations == []
        assert recovery.recoveries == 0
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_depth_not_ready_blocks_evidence_even_when_trade_flow_is_healthy():
    async def scenario():
        service, _, _, _, _, evidence = make_orchestrator(depth=FakeDepthSupervisor(ready=False))
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: service.health("BTCUSDT").status == "DEGRADED")
        state = service.health("BTCUSDT")
        assert not state.ready
        assert "ORDER_BOOK_NOT_READY" in state.reason_codes
        assert evidence.observations == []
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_flow_snapshot_age_is_rechecked_on_every_readiness_refresh():
    service, _, recovery, delta, _, _ = make_orchestrator(now=NOW + 30_000)
    recovery.repository.status = "HEALTHY"
    # Call private refresh contract with a stale snapshot; its historic is_fresh
    # flag cannot override the current wall-clock age check.
    state = SimpleNamespace(status="HEALTHY", symbol="BTCUSDT")
    flow = sample_flow(trade_time=NOW)
    service._runtimes["BTCUSDT"].last_source_status = "HEALTHY"
    service._refresh_symbol("BTCUSDT", state=state, flow=flow)
    result = service.health("BTCUSDT")
    assert not result.delta_cvd_ready
    assert "DELTA_CVD_NOT_READY_OR_STALE" in result.reason_codes


def test_degraded_stream_processes_its_contiguous_prefix_but_withholds_flow():
    async def scenario():
        service, feed, recovery, delta, _, _ = make_orchestrator(
            recovery=FakeRecovery("DEGRADED"),
        )
        feed.is_connected = True
        service._runtimes["BTCUSDT"].last_recovery_attempt_ms = NOW + 2_000
        await service._maintain_symbol("BTCUSDT")
        assert recovery.recoveries == 0
        assert len(delta.process_calls) == 1
        result = service.health("BTCUSDT")
        assert result.flow is not None
        assert not result.aggregate_trade_continuity
        assert not result.delta_cvd_ready
        assert not result.ready
        assert "AGGREGATE_TRADE_CONTINUITY_INVALID" in result.reason_codes

    asyncio.run(scenario())


def test_delta_processing_failure_blocks_cached_flow_until_successful_maintenance():
    class FaultingDelta(FakeDelta):
        fail_process = False
        fail_snapshot = False

        def process_until_caught_up(self, **kwargs):
            if self.fail_process:
                raise sqlite3.OperationalError("database is locked")
            return super().process_until_caught_up(**kwargs)

        def snapshot(self, **kwargs):
            if self.fail_snapshot:
                raise sqlite3.OperationalError("database is locked")
            return super().snapshot(**kwargs)

    async def scenario():
        delta = FaultingDelta()
        service, feed, *_ = make_orchestrator(delta=delta, recovery=FakeRecovery("HEALTHY"))
        feed.is_connected = True
        await service._maintain_symbol("BTCUSDT")
        assert service.health("BTCUSDT").delta_cvd_ready

        delta.fail_process = True
        await service._maintain_symbol("BTCUSDT")
        failed = service.health("BTCUSDT")
        assert failed.flow.is_fresh
        assert failed.order_book_ready
        assert not failed.delta_cvd_ready
        assert not failed.ready
        assert failed.evidence is None
        assert "DELTA_CVD_PROCESS_FAILED" in failed.reason_codes

        delta.fail_process = False
        feed.is_connected = False
        await service._maintain_symbol("BTCUSDT")
        assert "DELTA_CVD_PROCESS_FAILED" in service.health("BTCUSDT").reason_codes
        assert not service.health("BTCUSDT").delta_cvd_ready

        feed.is_connected = True
        delta.fail_snapshot = True
        await service._maintain_symbol("BTCUSDT")
        assert "DELTA_CVD_PROCESS_FAILED" in service.health("BTCUSDT").reason_codes
        assert not service.health("BTCUSDT").delta_cvd_ready

        delta.fail_snapshot = False
        await service._maintain_symbol("BTCUSDT")
        recovered = service.health("BTCUSDT")
        assert recovered.delta_cvd_ready and recovered.ready
        assert "DELTA_CVD_PROCESS_FAILED" not in recovered.reason_codes

    asyncio.run(scenario())


def test_aggregate_worker_batches_available_single_symbol_events_in_queue_order():
    class BatchRecovery(FakeRecovery):
        def __init__(self):
            super().__init__("HEALTHY")
            self.batches = []

        def ingest_websocket_events(self, events):
            self.batches.append(tuple(event.aggregate_trade_id for event in events))
            for event in events:
                state = self.ingest_websocket_event(event)
            return state

    async def scenario():
        recovery = BatchRecovery()
        service, *_ = make_orchestrator(
            recovery=recovery, config=MarketDataOrchestratorConfig(aggregate_ingest_batch_size=2),
        )
        for aggregate_id in range(10, 15):
            service._events.put_nowait(agg_event(aggregate_id=aggregate_id))
        stop = asyncio.Event()
        worker = asyncio.create_task(service._process_aggregate_events(stop))
        try:
            await asyncio.wait_for(service._events.join(), 1)
        finally:
            stop.set()
            await asyncio.wait_for(worker, 1)
        assert recovery.batches == [(10, 11), (12, 13)]
        assert [event.aggregate_trade_id for event in recovery.repository.ingested] == list(range(10, 15))

    asyncio.run(scenario())


def test_aggregate_worker_failure_acknowledges_every_dequeued_batch_event():
    class FailingBatchRecovery(FakeRecovery):
        def ingest_websocket_events(self, events):
            raise RuntimeError("batch write failed")

    async def scenario():
        service, *_ = make_orchestrator(recovery=FailingBatchRecovery("HEALTHY"))
        service._events.put_nowait(agg_event(aggregate_id=10))
        service._events.put_nowait(agg_event(aggregate_id=11))
        stop = asyncio.Event()
        with pytest.raises(MarketDataOrchestratorError, match="persistence failed.*batch write failed"):
            await asyncio.wait_for(service._process_aggregate_events(stop), 1)
        assert stop.is_set()
        await asyncio.wait_for(service._events.join(), 1)

    asyncio.run(scenario())


def test_new_durable_aggregate_gap_immediately_blocks_cached_delta_cvd():
    async def scenario():
        recovery = FakeRecovery("HEALTHY")
        service, feed, *_ = make_orchestrator(recovery=recovery, now=NOW + 2000)
        feed.is_connected = True
        await service._maintain_symbol("BTCUSDT")
        assert service.health("BTCUSDT").delta_cvd_ready

        recovery.repository.status = "DEGRADED"
        service._events.put_nowait(agg_event())
        stop = asyncio.Event()
        worker = asyncio.create_task(service._process_aggregate_events(stop))
        try:
            await asyncio.wait_for(service._events.join(), 1)
            health = service.health("BTCUSDT")
            assert not health.delta_cvd_ready
            assert "AGGREGATE_TRADE_CONTINUITY_INVALID" in health.reason_codes
        finally:
            stop.set()
            await asyncio.wait_for(worker, 1)

    asyncio.run(scenario())


def test_reconnect_generation_resets_evidence_window():
    async def scenario():
        service, feed, _, _, _, evidence = make_orchestrator()
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: service.is_running)
        await wait_until(lambda: service._last_aggregate_connection_count == 1)
        before = len(evidence.resets)
        feed.stats.connection_count += 1
        await wait_until(lambda: service.health("BTCUSDT").aggregate_trade_reconnect_generation == 1)
        assert any(reason == "AGGREGATE_TRADE_RECONNECTED" for _, reason in evidence.resets[before:])
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_internal_queue_overflow_is_explicit_and_stops_collector():
    async def scenario():
        service, feed, *_ = make_orchestrator(config=MarketDataOrchestratorConfig(
            event_queue_capacity=1, maintenance_interval_ms=50))
        service._events.put_nowait(agg_event(aggregate_id=10))
        await feed.events.put(agg_event(aggregate_id=11))
        stop = asyncio.Event()
        with pytest.raises(MarketDataQueueFullError):
            await service._collect_aggregate_events(stop)
        assert stop.is_set()
        assert service._fatal_reason == "AGGREGATE_EVENT_QUEUE_OVERFLOW"
    asyncio.run(scenario())


def test_aggregate_feed_startup_failure_is_not_silently_suppressed():
    class FailingFeed(FakeAggregateFeed):
        async def run(self, stop_event):
            raise ConnectionError("offline")

    async def scenario():
        service, *_ = make_orchestrator(feed=FailingFeed())
        with pytest.raises(Exception, match="before Aggregate Trade connection"):
            await asyncio.wait_for(service.run(asyncio.Event()), 1)
    asyncio.run(scenario())


def test_orchestrator_fans_out_events_without_competing_for_source_feed_queue():
    async def scenario():
        fanout = AggregateTradeEventFanout(default_queue_capacity=4)
        subscription = fanout.subscribe(symbol="BTCUSDT")
        service, feed, recovery, *_ = make_orchestrator(fanout=fanout)
        stop = asyncio.Event()
        task = asyncio.create_task(service.run(stop))
        await wait_until(lambda: bool(recovery.bootstrapped))
        await feed.events.put(agg_event(aggregate_id=77))
        strategy_event = await asyncio.wait_for(subscription.get_event(), 1)
        await wait_until(lambda: len(recovery.repository.ingested) == 1)
        assert strategy_event.aggregate_trade_id == 77
        assert recovery.repository.ingested[0].aggregate_trade_id == 77
        assert fanout.stats.events_published == 1
        assert fanout.stats.events_delivered == 1
        subscription.task_done()
        subscription.unsubscribe()
        stop.set()
        await asyncio.wait_for(task, 1)
    asyncio.run(scenario())


def test_fanout_overflow_fails_orchestrator_closed_before_persist_queue_accepts_event():
    async def scenario():
        fanout = AggregateTradeEventFanout(default_queue_capacity=1)
        subscription = fanout.subscribe(symbol="BTCUSDT")
        fanout.publish(agg_event(aggregate_id=10))
        service, feed, *_ = make_orchestrator(fanout=fanout)
        await feed.events.put(agg_event(aggregate_id=11))
        stop = asyncio.Event()
        with pytest.raises(MarketDataQueueFullError, match="fan-out is full"):
            await service._collect_aggregate_events(stop)
        assert stop.is_set()
        assert service._fatal_reason == "STRATEGY_EVENT_FANOUT_OVERFLOW"
        assert service._events.empty()
        assert subscription.queue_depth == 1
        assert fanout.stats.queue_overflows == 1
    asyncio.run(scenario())


def test_constructor_rejects_wrong_fanout_type():
    with pytest.raises(TypeError, match="AggregateTradeEventFanout"):
        UnifiedMarketDataOrchestrator(
            aggregate_feed=FakeAggregateFeed(), aggregate_recovery=FakeRecovery(),
            delta_cvd=FakeDelta(), order_book_supervisor=FakeDepthSupervisor(),
            evidence_service=FakeEvidenceService(), aggregate_event_fanout=object(),
        )
