"""SQLite persistence foundation with explicit, forward-only migrations."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any, Iterator
from weakref import WeakValueDictionary


SCHEMA_VERSION = 6

MIGRATIONS: tuple[tuple[int, tuple[str, ...]], ...] = (
    (
        1,
        (
            """CREATE TABLE app_settings (
                setting_key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL,
                updated_at_utc TEXT NOT NULL
            )""",
            """CREATE TABLE runtime_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                occurred_at_utc TEXT NOT NULL,
                level TEXT NOT NULL,
                component TEXT NOT NULL,
                event_name TEXT NOT NULL,
                message TEXT NOT NULL,
                details_json TEXT NOT NULL DEFAULT '{}'
            )""",
            "CREATE INDEX idx_runtime_events_time ON runtime_events(occurred_at_utc DESC)",
            "CREATE INDEX idx_runtime_events_component ON runtime_events(component, event_name)",
        ),
    ),
    (
        2,
        (
            """CREATE TABLE exchange_metadata_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_endpoint TEXT NOT NULL,
                fetched_at_utc TEXT NOT NULL,
                saved_at_utc TEXT NOT NULL,
                server_time_ms INTEGER,
                symbol_count INTEGER NOT NULL,
                payload_sha256 TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )""",
            "CREATE INDEX idx_exchange_metadata_fetched ON exchange_metadata_snapshots(fetched_at_utc DESC)",
        ),
    ),
    (
        3,
        (
            """CREATE TABLE market_klines (
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                interval TEXT NOT NULL CHECK (interval IN ('1m', '5m', '15m')),
                open_time_ms INTEGER NOT NULL CHECK (open_time_ms >= 0),
                open TEXT NOT NULL,
                high TEXT NOT NULL,
                low TEXT NOT NULL,
                close TEXT NOT NULL,
                volume TEXT NOT NULL,
                close_time_ms INTEGER NOT NULL,
                quote_asset_volume TEXT NOT NULL,
                trade_count INTEGER NOT NULL CHECK (trade_count >= 0),
                taker_buy_base_volume TEXT NOT NULL,
                taker_buy_quote_volume TEXT NOT NULL,
                ignore_value TEXT NOT NULL,
                source_endpoint TEXT NOT NULL,
                first_seen_at_utc TEXT NOT NULL,
                last_fetched_at_utc TEXT NOT NULL,
                last_saved_at_utc TEXT NOT NULL,
                PRIMARY KEY (exchange, symbol, interval, open_time_ms)
            )""",
            "CREATE INDEX idx_market_klines_saved ON market_klines(last_saved_at_utc DESC)",
        ),
    ),
    (
        4,
        (
            """CREATE TABLE aggregate_trades (
                exchange TEXT NOT NULL CHECK (exchange = 'BINANCE_UM'),
                symbol TEXT NOT NULL,
                aggregate_trade_id INTEGER NOT NULL CHECK (aggregate_trade_id >= 0),
                price TEXT NOT NULL,
                quantity TEXT NOT NULL,
                normal_quantity TEXT,
                first_trade_id INTEGER NOT NULL CHECK (first_trade_id >= 0),
                last_trade_id INTEGER NOT NULL CHECK (last_trade_id >= first_trade_id),
                event_time_ms INTEGER,
                trade_time_ms INTEGER NOT NULL CHECK (trade_time_ms > 0),
                buyer_is_maker INTEGER NOT NULL CHECK (buyer_is_maker IN (0, 1)),
                first_source_kind TEXT NOT NULL CHECK (first_source_kind IN ('REST', 'WEBSOCKET')),
                last_source_kind TEXT NOT NULL CHECK (last_source_kind IN ('REST', 'WEBSOCKET')),
                first_source_endpoint TEXT NOT NULL,
                last_source_endpoint TEXT NOT NULL,
                first_seen_at_utc TEXT NOT NULL,
                last_seen_at_utc TEXT NOT NULL,
                PRIMARY KEY (exchange, symbol, aggregate_trade_id)
            )""",
            "CREATE INDEX idx_aggregate_trades_symbol_time ON aggregate_trades(exchange, symbol, trade_time_ms DESC)",
            """CREATE TABLE aggregate_trade_stream_state (
                exchange TEXT NOT NULL CHECK (exchange = 'BINANCE_UM'),
                symbol TEXT NOT NULL,
                last_contiguous_aggregate_trade_id INTEGER NOT NULL CHECK (last_contiguous_aggregate_trade_id >= -1),
                last_contiguous_trade_time_ms INTEGER,
                latest_observed_aggregate_trade_id INTEGER NOT NULL CHECK (latest_observed_aggregate_trade_id >= -1),
                latest_observed_trade_time_ms INTEGER,
                status TEXT NOT NULL CHECK (status IN ('BOOTSTRAPPING', 'HEALTHY', 'DEGRADED', 'UNRESOLVED')),
                unresolved_gap_from_id INTEGER,
                unresolved_gap_to_id INTEGER,
                updated_at_utc TEXT NOT NULL,
                PRIMARY KEY (exchange, symbol)
            )""",
            """CREATE TABLE aggregate_trade_gaps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL CHECK (exchange = 'BINANCE_UM'),
                symbol TEXT NOT NULL,
                expected_from_id INTEGER NOT NULL CHECK (expected_from_id >= 0),
                observed_id INTEGER NOT NULL CHECK (observed_id > expected_from_id),
                status TEXT NOT NULL CHECK (status IN ('OPEN', 'RESOLVED', 'UNRESOLVED_RETENTION', 'UNRESOLVED_HISTORY')),
                reason TEXT NOT NULL,
                detected_at_utc TEXT NOT NULL,
                resolved_at_utc TEXT
            )""",
            "CREATE INDEX idx_aggregate_trade_gaps_open ON aggregate_trade_gaps(exchange, symbol, status, id DESC)",
        ),
    ),
    (
        5,
        (
            """CREATE TABLE order_flow_state (
                exchange TEXT NOT NULL CHECK (exchange = 'BINANCE_UM'),
                symbol TEXT NOT NULL,
                baseline_aggregate_trade_id INTEGER NOT NULL CHECK (baseline_aggregate_trade_id >= 0),
                last_processed_aggregate_trade_id INTEGER NOT NULL CHECK (last_processed_aggregate_trade_id >= baseline_aggregate_trade_id - 1),
                cumulative_delta_base TEXT NOT NULL,
                cumulative_delta_quote TEXT NOT NULL,
                last_trade_time_ms INTEGER,
                status TEXT NOT NULL CHECK (status IN ('BOOTSTRAPPING', 'HEALTHY', 'DEGRADED', 'UNRESOLVED')),
                integrity_reason TEXT,
                updated_at_utc TEXT NOT NULL,
                PRIMARY KEY (exchange, symbol)
            )""",
            """CREATE TABLE order_flow_buckets (
                exchange TEXT NOT NULL CHECK (exchange = 'BINANCE_UM'),
                symbol TEXT NOT NULL,
                interval TEXT NOT NULL CHECK (interval IN ('1s', '5s', '15s', '1m', '5m')),
                bucket_start_ms INTEGER NOT NULL CHECK (bucket_start_ms >= 0),
                buy_volume_base TEXT NOT NULL,
                sell_volume_base TEXT NOT NULL,
                buy_volume_quote TEXT NOT NULL,
                sell_volume_quote TEXT NOT NULL,
                trade_count INTEGER NOT NULL CHECK (trade_count >= 0),
                first_aggregate_trade_id INTEGER NOT NULL CHECK (first_aggregate_trade_id >= 0),
                last_aggregate_trade_id INTEGER NOT NULL CHECK (last_aggregate_trade_id >= first_aggregate_trade_id),
                first_trade_time_ms INTEGER NOT NULL,
                last_trade_time_ms INTEGER NOT NULL,
                updated_at_utc TEXT NOT NULL,
                PRIMARY KEY (exchange, symbol, interval, bucket_start_ms)
            )""",
            "CREATE INDEX idx_order_flow_buckets_window ON order_flow_buckets(exchange, symbol, interval, bucket_start_ms DESC)",
        ),
    ),
    (
        6,
        (
            """CREATE TABLE signal_publications (
                signal_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                side TEXT NOT NULL CHECK (side IN ('LONG', 'SHORT')),
                created_at_ms INTEGER NOT NULL,
                status TEXT NOT NULL CHECK (status IN ('PENDING', 'SENT', 'DELIVERY_UNKNOWN', 'FAILED')),
                signal_json TEXT NOT NULL,
                telegram_message_id TEXT,
                error_code TEXT,
                created_at_utc TEXT NOT NULL,
                updated_at_utc TEXT NOT NULL
            )""",
            "CREATE INDEX idx_signal_publications_time ON signal_publications(created_at_ms DESC)",
            """CREATE TABLE kronos_shadow_forecasts (
                forecast_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                interval TEXT NOT NULL CHECK (interval = '5m'),
                last_observed_open_time_ms INTEGER NOT NULL,
                model_revision TEXT NOT NULL,
                forecast_json TEXT NOT NULL,
                created_at_utc TEXT NOT NULL
            )""",
            """CREATE TABLE signal_forecast_links (
                signal_id TEXT NOT NULL REFERENCES signal_publications(signal_id),
                forecast_id TEXT NOT NULL REFERENCES kronos_shadow_forecasts(forecast_id),
                PRIMARY KEY(signal_id, forecast_id)
            )""",
            "CREATE INDEX idx_kronos_forecast_signal ON signal_forecast_links(signal_id)",
            """CREATE TABLE kronos_shadow_evaluations (
                forecast_id TEXT PRIMARY KEY REFERENCES kronos_shadow_forecasts(forecast_id),
                evaluation_json TEXT NOT NULL,
                evaluated_at_utc TEXT NOT NULL
            )""",
        ),
    ),
)


def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


_WRITE_LOCKS = WeakValueDictionary()
_WRITE_LOCK_REGISTRY = RLock()


def _write_lock_for(path: Path):
    # Multiple repositories or Database instances can target the same file.
    with _WRITE_LOCK_REGISTRY:
        lock = _WRITE_LOCKS.get(path)
        if lock is None:
            lock = RLock()
            _WRITE_LOCKS[path] = lock
        return lock


class Database:
    """Small SQLite unit-of-work wrapper; each operation owns its connection."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path).expanduser().resolve()
        self._write_lock = _write_lock_for(self.path)

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=10.0, isolation_level=None)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA busy_timeout = 10000")
            yield connection
        finally:
            connection.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._write_lock, self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def initialize(self) -> int:
        with self._write_lock, self.connection() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
        with self.transaction() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    applied_at_utc TEXT NOT NULL
                )"""
            )
            row = connection.execute("SELECT MAX(version) AS version FROM schema_migrations").fetchone()
            current_version = int(row["version"] or 0)
            if current_version > SCHEMA_VERSION:
                raise RuntimeError(
                    f"Database schema {current_version} is newer than this application "
                    f"({SCHEMA_VERSION}); refusing to downgrade."
                )
            for version, statements in MIGRATIONS:
                if version <= current_version:
                    continue
                for statement in statements:
                    connection.execute(statement)
                connection.execute(
                    "INSERT INTO schema_migrations(version, applied_at_utc) VALUES (?, ?)",
                    (version, utc_now_iso()),
                )
        return self.schema_version()

    def schema_version(self) -> int:
        if not self.path.exists():
            return 0
        with self.connection() as connection:
            exists = connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'"
            ).fetchone()
            if not exists:
                return 0
            row = connection.execute("SELECT MAX(version) AS version FROM schema_migrations").fetchone()
            return int(row["version"] or 0)

    def set_setting(self, key: str, value: Any) -> None:
        if not key.strip():
            raise ValueError("Setting key cannot be empty")
        payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        with self.transaction() as connection:
            connection.execute(
                """INSERT INTO app_settings(setting_key, value_json, updated_at_utc)
                   VALUES (?, ?, ?)
                   ON CONFLICT(setting_key) DO UPDATE SET
                       value_json=excluded.value_json,
                       updated_at_utc=excluded.updated_at_utc""",
                (key, payload, utc_now_iso()),
            )

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT value_json FROM app_settings WHERE setting_key = ?", (key,)
            ).fetchone()
        return json.loads(row["value_json"]) if row else default

    def record_event(
        self,
        level: str,
        component: str,
        event_name: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> int:
        if not component.strip() or not event_name.strip():
            raise ValueError("Event component and event_name are required")
        payload = json.dumps(details or {}, ensure_ascii=False, separators=(",", ":"))
        with self.transaction() as connection:
            cursor = connection.execute(
                """INSERT INTO runtime_events(
                    occurred_at_utc, level, component, event_name, message, details_json
                ) VALUES (?, ?, ?, ?, ?, ?)""",
                (utc_now_iso(), level.upper(), component, event_name, message, payload),
            )
            return int(cursor.lastrowid)


    def save_exchange_metadata_snapshot(
        self,
        *,
        source_endpoint: str,
        fetched_at_utc: str,
        server_time_ms: int | None,
        symbol_count: int,
        payload: dict[str, Any],
        retain: int = 10,
    ) -> int:
        """Persist a successful raw Exchange Information snapshot and retain history."""
        if not source_endpoint.strip():
            raise ValueError("source_endpoint cannot be empty")
        if symbol_count < 0:
            raise ValueError("symbol_count cannot be negative")
        if retain < 1 or retain > 100:
            raise ValueError("retain must be between 1 and 100")
        payload_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        digest = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        with self.transaction() as connection:
            cursor = connection.execute(
                """INSERT INTO exchange_metadata_snapshots(
                    source_endpoint, fetched_at_utc, saved_at_utc, server_time_ms,
                    symbol_count, payload_sha256, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    source_endpoint,
                    fetched_at_utc,
                    utc_now_iso(),
                    server_time_ms,
                    symbol_count,
                    digest,
                    payload_json,
                ),
            )
            connection.execute(
                """DELETE FROM exchange_metadata_snapshots
                   WHERE id NOT IN (
                       SELECT id FROM exchange_metadata_snapshots
                       ORDER BY id DESC LIMIT ?
                   )""",
                (retain,),
            )
            return int(cursor.lastrowid)

    def latest_exchange_metadata_snapshot(self) -> dict[str, Any] | None:
        """Return the newest cached raw metadata snapshot, or None when absent."""
        with self.connection() as connection:
            row = connection.execute(
                """SELECT id, source_endpoint, fetched_at_utc, saved_at_utc,
                          server_time_ms, symbol_count, payload_sha256, payload_json
                   FROM exchange_metadata_snapshots ORDER BY id DESC LIMIT 1"""
            ).fetchone()
        if row is None:
            return None
        actual_digest = hashlib.sha256(row["payload_json"].encode("utf-8")).hexdigest()
        if actual_digest != row["payload_sha256"]:
            raise RuntimeError("Cached Binance metadata snapshot failed SHA-256 integrity verification")
        return {
            "id": row["id"],
            "source_endpoint": row["source_endpoint"],
            "fetched_at_utc": row["fetched_at_utc"],
            "saved_at_utc": row["saved_at_utc"],
            "server_time_ms": row["server_time_ms"],
            "symbol_count": row["symbol_count"],
            "payload_sha256": row["payload_sha256"],
            "payload": json.loads(row["payload_json"]),
        }

    def recent_events(self, limit: int = 20) -> list[dict[str, Any]]:
        if limit < 1 or limit > 1000:
            raise ValueError("limit must be between 1 and 1000")
        with self.connection() as connection:
            rows = connection.execute(
                """SELECT id, occurred_at_utc, level, component, event_name, message, details_json
                   FROM runtime_events ORDER BY id DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "occurred_at_utc": row["occurred_at_utc"],
                "level": row["level"],
                "component": row["component"],
                "event_name": row["event_name"],
                "message": row["message"],
                "details": json.loads(row["details_json"]),
            }
            for row in rows
        ]
