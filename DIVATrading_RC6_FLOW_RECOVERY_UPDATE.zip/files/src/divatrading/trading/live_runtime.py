"""Continuous read-only multi-pair market runtime and SMC V2 fan-in.

Feed construction is injected deliberately: deployments can compose the existing
Binance websocket/recovery supervisors without coupling strategy state to transport.
This runtime owns universe refresh, worker lifecycle, bounded capture delivery and
per-symbol SMC state. It never submits orders.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import time
from dataclasses import dataclass
from typing import AsyncIterable, Awaitable, Callable

from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.strategy.scalping_market_data import ScalpingMarketDataView
from divatrading.strategy.scalping_pipeline import SMCV2EvidencePipeline, SMCV2EvidenceSnapshot
from divatrading.trading.universe import SymbolUniverseConfig, SymbolUniverseSelector, UniverseSelection


_LOG = logging.getLogger(__name__)
_FEED_STATUS_INTERVAL_SECONDS = 60.0


@dataclass(frozen=True, slots=True)
class LiveMarketRuntimeConfig:
    universe: SymbolUniverseConfig = SymbolUniverseConfig()
    universe_refresh_seconds: float = 300.0
    metadata_refresh_seconds: float = 3600.0
    worker_restart_seconds: float = 2.0
    max_capture_queue: int = 64
    max_concurrent_workers: int = 24

    def __post_init__(self) -> None:
        for name in ("universe_refresh_seconds", "metadata_refresh_seconds", "worker_restart_seconds"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                raise ValueError(f"{name} must be positive")
        if not 1 <= self.max_capture_queue <= 4096:
            raise ValueError("max_capture_queue must be between 1 and 4096")
        if not 1 <= self.max_concurrent_workers <= 32:
            raise ValueError("max_concurrent_workers must be between 1 and 32")
        if self.universe.max_active_symbols > self.max_concurrent_workers:
            raise ValueError("universe max_active_symbols cannot exceed max_concurrent_workers")


@dataclass(frozen=True, slots=True)
class SymbolRuntimeStatus:
    symbol: str
    status: str
    captures: int
    last_capture_at_ms: int | None
    last_error: str | None


@dataclass(frozen=True, slots=True)
class LiveMarketRuntimeSnapshot:
    running: bool
    universe_mode: str
    selected_symbols: tuple[str, ...]
    rejected_symbols: tuple[tuple[str, str], ...]
    workers: tuple[SymbolRuntimeStatus, ...]
    refreshed_at_ms: int | None


FeedFactory = Callable[[str], AsyncIterable[ScalpingMarketDataView] | Awaitable[AsyncIterable[ScalpingMarketDataView]]]
EvidenceCallback = Callable[[SMCV2EvidenceSnapshot], None | Awaitable[None]]
UniverseCallback = Callable[[UniverseSelection, object], None | Awaitable[None]]


class MultiPairLiveMarketRuntime:
    """Refresh exchange universe and supervise independent per-symbol feed workers."""

    def __init__(self, *, rest_client: BinanceUsdMFuturesRestClient,
                 feed_factory: FeedFactory, on_evidence: EvidenceCallback | None = None,
                 on_universe: UniverseCallback | None = None,
                 on_symbol_reset: Callable[[str], None] | None = None,
                 config: LiveMarketRuntimeConfig | None = None,
                 pipeline: SMCV2EvidencePipeline | None = None,
                 clock_ms: Callable[[], int] | None = None) -> None:
        self.config = config or LiveMarketRuntimeConfig()
        self.rest_client = rest_client
        self.feed_factory = feed_factory
        self.on_evidence = on_evidence
        self.on_universe = on_universe
        self.on_symbol_reset = on_symbol_reset
        self.pipeline = pipeline or SMCV2EvidencePipeline(max_symbols=self.config.max_concurrent_workers)
        self.selector = SymbolUniverseSelector(self.config.universe)
        self._clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._stop = asyncio.Event()
        self._workers: dict[str, asyncio.Task[None]] = {}
        self._statuses: dict[str, SymbolRuntimeStatus] = {}
        self._selection: UniverseSelection | None = None
        self._refreshed_at_ms: int | None = None
        self._running = False
        self._metadata = None
        self._lock = asyncio.Lock()

    @property
    def snapshot(self) -> LiveMarketRuntimeSnapshot:
        selection = self._selection
        return LiveMarketRuntimeSnapshot(
            self._running, self.config.universe.mode,
            selection.symbols if selection else (),
            selection.rejected if selection else (),
            tuple(self._statuses[key] for key in sorted(self._statuses)),
            self._refreshed_at_ms,
        )

    async def run(self, stop_event: asyncio.Event | None = None) -> None:
        if self._running:
            raise RuntimeError("runtime is already running")
        self._running = True
        external = stop_event or asyncio.Event()
        try:
            await self.refresh_universe()
            while not external.is_set() and not self._stop.is_set():
                try:
                    await asyncio.wait_for(external.wait(), timeout=self.config.universe_refresh_seconds)
                except asyncio.TimeoutError:
                    await self.refresh_universe()
        finally:
            self._running = False
            await self._stop_workers()

    async def stop(self) -> None:
        self._stop.set()
        await self._stop_workers()

    async def refresh_universe(self) -> UniverseSelection:
        # REST is synchronous and bounded by the client's timeout/retry policy.
        info_payload, tickers = await asyncio.gather(
            asyncio.to_thread(self.rest_client.get_exchange_info),
            asyncio.to_thread(self.rest_client.get_ticker_24h),
        )
        metadata = parse_exchange_info(info_payload, source_endpoint=self.rest_client.exchange_info_endpoint)
        selection = self.selector.select(metadata, tickers)
        if self.on_universe is not None:
            outcome = self.on_universe(selection, metadata)
            if inspect.isawaitable(outcome):
                await outcome
        # Production feed factories need the exact current SymbolInfo snapshot;
        # plain callable factories remain fully compatible with the v0.41 API.
        metadata_setter = getattr(self.feed_factory, "set_metadata", None)
        if callable(metadata_setter):
            metadata_setter(metadata)
        async with self._lock:
            self._metadata = metadata
            self._selection = selection
            self._refreshed_at_ms = self._clock_ms()
            wanted = set(selection.symbols)
            for symbol in tuple(self._workers):
                if symbol not in wanted:
                    task = self._workers.pop(symbol)
                    task.cancel()
                    self._reset_symbol(symbol)
                    self._statuses.pop(symbol, None)
            for symbol in selection.symbols:
                if symbol not in self._workers:
                    self._statuses[symbol] = SymbolRuntimeStatus(symbol, "STARTING", 0, None, None)
                    self._workers[symbol] = asyncio.create_task(self._worker_supervisor(symbol), name=f"diva:{symbol}")
        return selection

    async def _worker_supervisor(self, symbol: str) -> None:
        captures = 0
        quote_ready_captures = 0
        flow_ready_captures = 0
        next_feed_status = 0.0
        next_error_log = 0.0
        last_capture: int | None = None
        last_error: str | None = None
        while not self._stop.is_set() and self._selection and symbol in self._selection.symbols:
            stream = None
            try:
                stream = self.feed_factory(symbol)
                if inspect.isawaitable(stream):
                    stream = await stream
                if not hasattr(stream, "__aiter__"):
                    raise TypeError("feed_factory must return an async iterable of ScalpingMarketDataView")
                self._set_status(symbol, "RUNNING", captures, last_capture, None)
                async for view in stream:
                    if self._stop.is_set():
                        break
                    if not isinstance(view, ScalpingMarketDataView):
                        raise TypeError("feed emitted a non-ScalpingMarketDataView capture")
                    if view.symbol != symbol:
                        raise ValueError(f"feed symbol mismatch: worker={symbol}, capture={view.symbol}")
                    result = self.pipeline.process(view)
                    readiness = view.readiness
                    if captures == 0:
                        _LOG.info(
                            "MARKET_WORKER_FIRST_CAPTURE symbol=%s m1=%s m5=%s m15=%s entry_quote=%s delta_cvd=%s",
                            symbol, readiness.m1_setup_ready, readiness.m5_setup_ready,
                            readiness.m15_context_available, readiness.entry_quote_ready,
                            readiness.delta_cvd_available,
                        )
                    captures += 1
                    first_ready = (
                        (readiness.entry_quote_ready and quote_ready_captures == 0)
                        or (readiness.delta_cvd_available and flow_ready_captures == 0)
                    )
                    quote_ready_captures += int(readiness.entry_quote_ready)
                    flow_ready_captures += int(readiness.delta_cvd_available)
                    wall = time.monotonic()
                    if first_ready or wall >= next_feed_status:
                        depth = view.component("DEPTH")
                        flow = view.component("DELTA_CVD")
                        sources = view.orchestrator_readiness
                        _LOG.info(
                            "MARKET_WORKER_FEED_STATUS symbol=%s captures=%s m5=%s m15=%s "
                            "entry_quote=%s quote_ready_captures=%s delta_cvd=%s flow_ready_captures=%s "
                            "depth_reasons=%s flow_reasons=%s source_reasons=%s agg_queued=%s internal_queued=%s",
                            symbol, captures, readiness.m5_setup_ready, readiness.m15_context_available,
                            readiness.entry_quote_ready, quote_ready_captures,
                            readiness.delta_cvd_available, flow_ready_captures,
                            ",".join(depth.reason_codes) if depth is not None else "NOT_REPORTED",
                            ",".join(flow.reason_codes) if flow is not None else "NOT_REPORTED",
                            ",".join(sources.reason_codes) if sources is not None else "NOT_REPORTED",
                            sources.aggregate_event_queue_depth if sources is not None else "NOT_REPORTED",
                            sources.internal_queue_depth if sources is not None else "NOT_REPORTED",
                        )
                        next_feed_status = wall + _FEED_STATUS_INTERVAL_SECONDS
                    last_capture = view.captured_at_ms
                    self._set_status(symbol, "RUNNING", captures, last_capture, None)
                    if self.on_evidence is not None:
                        outcome = self.on_evidence(result)
                        if inspect.isawaitable(outcome):
                            await outcome
                if self._stop.is_set():
                    break
                last_error = "FEED_STREAM_ENDED"
                error_code = last_error
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # isolate one symbol; never reset another symbol's state
                last_error = f"{type(exc).__name__}: {exc}"[:500]
                error_types = []
                failure: BaseException | None = exc
                while failure is not None and len(error_types) < 4:
                    error_types.append(type(failure).__name__)
                    failure = failure.__cause__ or (
                        None if failure.__suppress_context__ else failure.__context__
                    )
                error_code = ":".join(error_types)
            finally:
                close_stream = getattr(stream, "aclose", None)
                if callable(close_stream):
                    try:
                        await close_stream()
                    except Exception as cleanup_error:
                        _LOG.warning(
                            "MARKET_WORKER_CLOSE_FAILED symbol=%s reason=%s",
                            symbol, type(cleanup_error).__name__,
                        )
            # A replacement stream reloads bounded history from Binance. Its
            # closed candles may no longer match the old incremental anchors.
            self._reset_symbol(symbol)
            self._set_status(symbol, "DEGRADED", captures, last_capture, last_error)
            wall = time.monotonic()
            if wall >= next_error_log:
                _LOG.warning("MARKET_WORKER_DEGRADED symbol=%s captures=%s reason=%s", symbol, captures, error_code)
                next_error_log = wall + _FEED_STATUS_INTERVAL_SECONDS
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.config.worker_restart_seconds)
            except asyncio.TimeoutError:
                continue
        self._set_status(symbol, "STOPPED", captures, last_capture, last_error)

    def _reset_symbol(self, symbol: str) -> None:
        self.pipeline.reset_symbol(symbol)
        if self.on_symbol_reset is not None:
            self.on_symbol_reset(symbol)

    def _set_status(self, symbol: str, status: str, captures: int,
                    last_capture: int | None, error: str | None) -> None:
        self._statuses[symbol] = SymbolRuntimeStatus(symbol, status, captures, last_capture, error)

    async def _stop_workers(self) -> None:
        tasks = tuple(self._workers.values())
        self._workers.clear()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
