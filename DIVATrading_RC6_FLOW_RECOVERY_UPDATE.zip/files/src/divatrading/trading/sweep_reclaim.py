"""Adapt the sweep–reclaim strategy to RC6 market snapshots and portfolio sizing."""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from threading import RLock

from divatrading.market_data.klines import Kline
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.strategy.scalping_market_data import ScalpingMarketDataView
from divatrading.strategy.scalping_pipeline import SMCV2EvidenceSnapshot
from divatrading.strategy.sweep_reclaim import SweepSetup, SweepStructure

from .models import QualifiedSignal, TradePlan
from .risk import PortfolioRiskManager
from .signal_planner import CandidateEvaluation, TradePlanningResult

SWEEP_RECLAIM_STRATEGY_ID = "SWEEP_RECLAIM_V2"
_BPS = Decimal(10_000)
_ZERO = Decimal(0)


@dataclass(frozen=True, slots=True)
class SweepReclaimConfig:
    swing_bars: int = 2
    reclaim_bars: int = 2
    confirmation_bars: int = 4
    retest_bars: int = 4
    stop_buffer_ticks: int = 2
    target_buffer_ticks: int = 2
    retest_window_ms: int = 15_000
    max_quote_age_ms: int = 2_500
    min_flow_trades: int = 3
    require_flow_alignment: bool = False
    max_spread_bps: Decimal = Decimal("10")
    entry_slippage_bps: Decimal = Decimal("1")
    exit_slippage_bps: Decimal = Decimal("5")
    fee_bps: Decimal = Decimal("5")
    min_net_rr: Decimal = Decimal("2")
    planning_reservation_ttl_ms: int = 60_000

    def __post_init__(self) -> None:
        for name in (
            "swing_bars", "reclaim_bars", "confirmation_bars", "retest_bars",
            "stop_buffer_ticks", "target_buffer_ticks", "retest_window_ms",
            "max_quote_age_ms", "min_flow_trades", "planning_reservation_ttl_ms",
        ):
            value = getattr(self, name)
            if type(value) is not int or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if type(self.require_flow_alignment) is not bool:
            raise ValueError("require_flow_alignment must be bool")
        for name in ("max_spread_bps", "entry_slippage_bps", "exit_slippage_bps", "fee_bps", "min_net_rr"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
                raise ValueError(f"{name} must be a nonnegative finite Decimal")
            if name != "min_net_rr" and value >= _BPS:
                raise ValueError(f"{name} must be below 10000")
        if self.min_net_rr <= 0 or self.max_spread_bps <= 0:
            raise ValueError("min_net_rr and max_spread_bps must be positive")


@dataclass(slots=True)
class _SymbolState:
    structure: SweepStructure
    last_closes: dict[str, int] = field(default_factory=dict)
    last_capture: int = -1
    setup: SweepSetup | None = None
    touch_ms: int | None = None
    extreme: Decimal = _ZERO
    last_quote_id: int | None = None
    last_quote_ms: int | None = None
    source_generation: tuple[int, int | None] | None = None
    emitted: str | None = None

    def clear_retest(self) -> None:
        self.touch_ms = None
        self.last_quote_id = None
        self.last_quote_ms = None


class SweepReclaimPlanner:
    """Turn confirmed M15/M5 structure and observed retests into capped IOC entries."""

    def __init__(
        self,
        *,
        config: SweepReclaimConfig | None = None,
        risk_manager: PortfolioRiskManager | None = None,
    ) -> None:
        self.config = config or SweepReclaimConfig()
        self.risk_manager = risk_manager or PortfolioRiskManager()
        self._parameters = tuple(sorted((key, str(value)) for key, value in asdict(self.config).items()))
        self._states: dict[str, _SymbolState] = {}
        self._reservations: dict[str, tuple[int, str, Decimal, Decimal]] = {}
        self._lock = RLock()

    def reset_symbol(self, symbol: str) -> None:
        with self._lock:
            symbol = symbol.strip().upper()
            self._states.pop(symbol, None)
            self._reservations = {
                key: row for key, row in self._reservations.items() if row[1] != symbol
            }

    def reset_planning_reservations(self) -> None:
        with self._lock:
            self._reservations.clear()

    def release_candidate_signal(self, *, symbol: str, candidate_id: str) -> None:
        with self._lock:
            normalized = symbol.strip().upper()
            state = self._states.get(normalized)
            if state is not None and state.emitted == candidate_id:
                state.emitted = None
            reservation = self._reservations.get(candidate_id)
            if reservation is not None and reservation[1] == normalized:
                self._reservations.pop(candidate_id)

    def _new_state(self, tick: Decimal) -> _SymbolState:
        cfg = self.config
        return _SymbolState(SweepStructure(
            tick, swing_bars=cfg.swing_bars, reclaim_bars=cfg.reclaim_bars,
            confirmation_bars=cfg.confirmation_bars, retest_bars=cfg.retest_bars,
            stop_buffer_ticks=cfg.stop_buffer_ticks, target_buffer_ticks=cfg.target_buffer_ticks,
        ))

    @staticmethod
    def _consume_candles(
        state: _SymbolState, now: int, m5: tuple[Kline, ...], m15: tuple[Kline, ...],
    ) -> None:
        # Anchor bootstrap to shared history, so an M15 pivot cannot survive
        # a period for which we have no M5 bars to check whether it was swept.
        start = max(m5[0].open_time_ms, m15[0].open_time_ms)
        incoming = sorted(
            (bar for bars in (m5, m15) for bar in bars
             if start <= bar.open_time_ms
             and state.last_closes.get(bar.interval, -1) < bar.close_time_ms <= now),
            key=lambda bar: (bar.close_time_ms, bar.interval == "15m"),
        )
        for bar in incoming:
            state.structure.on_candle(bar)
            state.last_closes[bar.interval] = bar.close_time_ms

    @staticmethod
    def _has_kline_gap(state: _SymbolState, m5: tuple[Kline, ...], m15: tuple[Kline, ...]) -> bool:
        for bars in (m5, m15):
            seen = state.last_closes.get(bars[0].interval)
            if seen is not None and bars[0].open_time_ms > seen + 1:
                return True
        return False

    @staticmethod
    def _setup_id(symbol: str, setup: SweepSetup) -> str:
        value = f"{SWEEP_RECLAIM_STRATEGY_ID}|{symbol}|{setup.confirmed_at}|{setup.side}"
        return hashlib.sha256(value.encode("ascii")).hexdigest()[:24]

    def evaluate(
        self,
        evidence: SMCV2EvidenceSnapshot,
        *,
        equity_usdt: Decimal,
        open_risk_usdt: Decimal = _ZERO,
        active_position_count: int = 0,
        symbol_notional_usdt: Decimal = _ZERO,
        qualification_only: bool = False,
        qualification_defer_reason: str = "DEFERRED_TO_AUTONOMOUS_GLOBAL_RISK",
        mark_qualified_emitted: bool = True,
    ) -> TradePlanningResult:
        """Planner-compatible handoff. Autonomous sizing stays in the dispatcher."""
        if not isinstance(evidence, SMCV2EvidenceSnapshot):
            raise TypeError("evidence must be SMCV2EvidenceSnapshot")
        view = evidence.market_view
        symbol = evidence.symbol
        now = evidence.captured_at_ms
        with self._lock:
            state = self._states.get(symbol)
            if state is not None and now < state.last_capture:
                return TradePlanningResult(symbol, now, (), scan_wait_reason="NONMONOTONIC_CAPTURE")
            tick = view.instrument.tick_size
            if (
                symbol != view.symbol or symbol != view.instrument.symbol
                or now != view.captured_at_ms or tick is None
            ):
                self._states.pop(symbol, None)
                return TradePlanningResult(symbol, now, (), scan_wait_reason="INVALID_VIEW")
            m5_ready = view.readiness.m5_setup_ready and bool(view.m5.candles)
            m15_ready = view.readiness.m15_context_available and bool(view.m15.candles)
            if not (m5_ready and m15_ready):
                self._states.pop(symbol, None)
                if not m5_ready and not m15_ready:
                    return TradePlanningResult(symbol, now, (), scan_wait_reason="M5_M15_NOT_READY")
                reason = "M5_NOT_READY" if not m5_ready else "M15_NOT_READY"
                return TradePlanningResult(symbol, now, (), scan_wait_reason=reason)
            m5, m15 = view.m5.candles, view.m15.candles
            if state is None or state.structure.tick_size != tick or self._has_kline_gap(state, m5, m15):
                state = self._states[symbol] = self._new_state(tick)
            state.last_capture = now
            self._consume_candles(state, now, m5, m15)
            setup = state.structure.signal
            if setup != state.setup:
                state.setup = setup
                state.clear_retest()
            if setup is None:
                return TradePlanningResult(symbol, now, (), scan_wait_reason="NO_ACTIVE_SETUP")
            candidate_id = self._setup_id(symbol, setup)
            if now >= setup.expires_at:
                state.structure.consume()
                state.clear_retest()
                return self._result(symbol, now, candidate_id, "REJECTED", ("SWEEP_SETUP_EXPIRED",))
            if state.emitted == candidate_id:
                return self._result(symbol, now, candidate_id, "ALREADY_EMITTED",
                                    ("CANDIDATE_SIGNAL_ALREADY_EMITTED",))

            quote = view.order_book_metrics
            if not self._quote_ready(view, quote, setup, now):
                state.clear_retest()
                return self._result(symbol, now, candidate_id, "REJECTED", ("SWEEP_ENTRY_QUOTE_UNAVAILABLE",))
            assert quote is not None
            source = view.orchestrator_readiness
            generation = None if source is None else (
                source.depth_reconnect_generation,
                source.aggregate_trade_reconnect_generation if self.config.require_flow_alignment else None,
            )
            if state.source_generation != generation:
                state.clear_retest()
                state.source_generation = generation
            decision = self._check_retest(state, setup, quote, now)
            if decision == "WAIT":
                return TradePlanningResult(symbol, now, (), scan_wait_reason="RETEST_WAIT")
            if decision is not None:
                return self._result(symbol, now, candidate_id, "REJECTED", (decision,))
            if self.config.require_flow_alignment and not self._retest_flow_ready(view, state, setup):
                return self._result(symbol, now, candidate_id, "REJECTED", ("SWEEP_RETEST_FLOW_INSUFFICIENT",))
            levels = self._entry_levels(view, setup, quote, tick)
            if isinstance(levels, str):
                return self._result(symbol, now, candidate_id, "REJECTED", (levels,))
            return self._qualify(
                state, setup, view, now, candidate_id, levels,
                equity_usdt=equity_usdt, open_risk_usdt=open_risk_usdt,
                active_position_count=active_position_count, symbol_notional_usdt=symbol_notional_usdt,
                qualification_only=qualification_only, qualification_defer_reason=qualification_defer_reason,
                mark_qualified_emitted=mark_qualified_emitted,
            )

    def _result(
        self, symbol: str, now: int, candidate_id: str, status: str, reasons: tuple[str, ...],
        signal: QualifiedSignal | None = None, plan: TradePlan | None = None,
    ) -> TradePlanningResult:
        rank = 1 if status in ("QUALIFIED", "PLANNED") else None
        item = CandidateEvaluation(None, candidate_id, symbol, "5m", status, 0,
                                   reasons, self._parameters, signal, plan, rank)
        return TradePlanningResult(symbol, now, (item,))

    def _quote_ready(
        self, view: ScalpingMarketDataView, quote: OrderBookMetrics | None,
        setup: SweepSetup, now: int,
    ) -> bool:
        return bool(
            view.readiness.entry_quote_ready and quote is not None
            and quote.synchronized and quote.symbol == view.symbol
            and setup.confirmed_at < quote.last_event_time_ms <= now
            and now - quote.last_event_time_ms <= self.config.max_quote_age_ms
            and _ZERO < quote.best_bid < quote.best_ask
        )

    def _check_retest(
        self, state: _SymbolState, setup: SweepSetup, quote: OrderBookMetrics, now: int,
    ) -> str | None:
        cfg = self.config
        tick = state.structure.tick_size
        ts = quote.last_event_time_ms
        if state.last_quote_id is not None and state.last_quote_ms is not None:
            if quote.update_id == state.last_quote_id:
                return "WAIT"
            if (
                quote.update_id < state.last_quote_id or ts < state.last_quote_ms
                or ts - state.last_quote_ms > cfg.max_quote_age_ms
            ):
                state.clear_retest()
        state.last_quote_id, state.last_quote_ms = quote.update_id, ts

        side = setup.side
        exit_quote = quote.best_bid if side == 1 else quote.best_ask
        if side * (exit_quote - setup.stop) <= 0 or side * (setup.target - exit_quote) <= 0:
            state.structure.consume()
            state.clear_retest()
            return "SWEEP_LEVEL_PASSED_BEFORE_ENTRY"

        mid = (quote.best_bid + quote.best_ask) / 2
        spread = (quote.best_ask - quote.best_bid) / mid * _BPS
        if spread > cfg.max_spread_bps:
            state.touch_ms = None
            return "SWEEP_SPREAD_TOO_WIDE"
        offset = side * (mid - setup.retest_level)
        distance = abs(setup.retest_level - setup.stop)
        if state.touch_ms is not None and now - state.touch_ms > cfg.retest_window_ms:
            state.touch_ms = None
        if state.touch_ms is None:
            if offset <= max(tick * 2, distance * Decimal("0.025")):
                state.touch_ms, state.extreme = ts, offset
            return "WAIT"
        state.extreme = min(offset, state.extreme)
        if offset < 0 or offset - state.extreme < tick:
            return "WAIT"
        if offset > max(tick * 8, distance * Decimal("0.15")):
            return "SWEEP_ENTRY_TOO_FAR_FROM_RETEST"
        return None

    def _retest_flow_ready(
        self, view: ScalpingMarketDataView, state: _SymbolState, setup: SweepSetup,
    ) -> bool:
        flow = view.flow
        if (
            not view.readiness.delta_cvd_available or flow is None or flow.symbol != view.symbol
            or not flow.is_fresh or not flow.continuity_valid or state.touch_ms is None
            or flow.last_trade_time_ms is None
            or not state.touch_ms <= flow.window_start_ms <= flow.last_trade_time_ms <= view.captured_at_ms
            or flow.trade_count < self.config.min_flow_trades
        ):
            return False
        turnover = flow.buy_volume_quote + flow.sell_volume_quote
        return turnover > 0 and setup.side * flow.delta_quote <= -Decimal("0.2") * turnover

    def _entry_levels(
        self, view: ScalpingMarketDataView, setup: SweepSetup, quote: OrderBookMetrics, tick: Decimal,
    ) -> tuple[Decimal, Decimal] | str:
        cfg = self.config
        instrument = view.instrument
        if "IOC" not in instrument.time_in_force or not {
            "LIMIT", "STOP_MARKET", "TAKE_PROFIT_MARKET",
        }.issubset(instrument.order_types):
            return "SWEEP_EXCHANGE_ORDER_FILTERS_UNAVAILABLE"
        if instrument.min_notional is None:
            return "NOTIONAL_FILTER_MINIMUM_UNAVAILABLE"
        side = setup.side
        entry_quote = quote.best_ask if side == 1 else quote.best_bid
        cap = entry_quote * (1 + side * cfg.entry_slippage_bps / _BPS)
        # Round toward the observed quote so the exact exchange tick does not
        # exceed the configured adverse slippage cap.
        rounding = ROUND_FLOOR if side == 1 else ROUND_CEILING
        entry = (cap / tick).to_integral_value(rounding=rounding) * tick
        if (
            side * (entry - entry_quote) < 0 or side * (entry - setup.stop) <= 0
            or side * (setup.target - entry) <= 0
        ):
            return "SWEEP_INVALID_ENTRY_GEOMETRY"
        for price in (entry, setup.stop, setup.target):
            if (
                price <= 0 or price % tick
                or (instrument.min_price and price < instrument.min_price)
                or (instrument.max_price and price > instrument.max_price)
            ):
                return "SWEEP_EXCHANGE_PRICE_FILTER_REJECTED"
        fee = cfg.fee_bps / _BPS
        exit_factor = 1 - side * cfg.exit_slippage_bps / _BPS
        stop_fill, target_fill = setup.stop * exit_factor, setup.target * exit_factor
        loss = side * (entry - stop_fill) + fee * (entry + stop_fill)
        reward = side * (target_fill - entry) - fee * (entry + target_fill)
        if loss <= 0 or reward < loss * cfg.min_net_rr:
            return "SWEEP_NET_RR_BELOW_MINIMUM"
        return entry, reward / loss

    def _qualify(
        self, state: _SymbolState, setup: SweepSetup, view: ScalpingMarketDataView,
        now: int, candidate_id: str, levels: tuple[Decimal, Decimal], *,
        equity_usdt: Decimal, open_risk_usdt: Decimal, active_position_count: int,
        symbol_notional_usdt: Decimal, qualification_only: bool,
        qualification_defer_reason: str, mark_qualified_emitted: bool,
    ) -> TradePlanningResult:
        entry, net_rr = levels
        reasons = (
            "M15_LIQUIDITY_SWEEP", "M5_RECLAIM_AND_BREAK", "DEPTH_RETEST_AND_RECOVERY",
            "STOP_BUFFER_BEYOND_SWEEP", "TARGET_BEFORE_M15_PIVOT",
            f"ESTIMATED_NET_RR_{net_rr:.4f}",
        )
        if self.config.require_flow_alignment:
            reasons += ("RETEST_ADVERSE_FLOW_WITH_PRICE_RECOVERY",)
        signal = QualifiedSignal(
            signal_id=candidate_id, symbol=view.symbol, side="LONG" if setup.side == 1 else "SHORT",
            entry_type="LIMIT_IOC", entry_price=entry, stop_loss=setup.stop, take_profit=setup.target,
            timeframe="5m", strategy_id=SWEEP_RECLAIM_STRATEGY_ID,
            created_at_ms=now, reason_codes=reasons, minimum_net_rr=self.config.min_net_rr,
        )
        if qualification_only:
            if mark_qualified_emitted:
                state.emitted = candidate_id
            return self._result(view.symbol, now, candidate_id, "QUALIFIED",
                                reasons + (qualification_defer_reason,), signal)

        self._reservations = {key: row for key, row in self._reservations.items() if row[0] > now}
        reserve_risk = sum((row[2] for row in self._reservations.values()), _ZERO)
        reserve_notional = sum(
            (row[3] for row in self._reservations.values() if row[1] == view.symbol), _ZERO,
        )
        decision = self.risk_manager.size_signal(
            signal, view.instrument, equity_usdt=equity_usdt,
            open_risk_usdt=open_risk_usdt + reserve_risk,
            active_position_count=active_position_count + len(self._reservations),
            existing_symbol_notional_usdt=symbol_notional_usdt + reserve_notional,
            client_order_id="DIVA" + candidate_id,
        )
        if not decision.accepted or decision.plan is None:
            return self._result(view.symbol, now, candidate_id, "RISK_REJECTED", reasons + (decision.reason,), signal)
        plan = decision.plan
        state.emitted = candidate_id
        self._reservations[candidate_id] = (
            now + self.config.planning_reservation_ttl_ms, view.symbol, plan.risk_usdt, plan.notional_usdt,
        )
        return self._result(view.symbol, now, candidate_id, "PLANNED", reasons + ("GLOBAL_RISK_APPROVED",), signal, plan)
