"""SMC V2 candidate qualification and dynamic, exact-decimal trade planning.

This module is deliberately PAPER-only: it derives decisions and TradePlan
objects but never submits exchange orders. Stage 2–5 strategy semantics remain
owned by the existing engines; this layer only interprets their evidence.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal, ROUND_DOWN, ROUND_UP
import hashlib
import json
from threading import RLock
from typing import Literal

from divatrading.strategy.scalping_market_data import ScalpingMarketDataView
from divatrading.strategy.scalping_pipeline import SMCV2EvidenceSnapshot
from divatrading.strategy.scalping_order_block_formation import OrderBlockCandidate
from divatrading.strategy.scalping_order_block_lifecycle import OrderBlockLifecycleSnapshot
from divatrading.strategy.scalping_market_structure import StructureEvent, StructurePivotState, StructureTimeframeResult
from divatrading.strategy.scalping_liquidity_fvg import FairValueGap, LiquiditySweepEvidence
from .models import QualifiedSignal, TradePlan
from .risk import PortfolioRiskConfig, PortfolioRiskManager

EntryModel = Literal["LIMIT_RETRACEMENT", "CONFIRMATION_MARKET"]


@dataclass(frozen=True, slots=True)
class SMCTradePlannerConfig:
    """Explicit provisional policy. Optional confluence is advisory by default."""

    entry_model: EntryModel = "LIMIT_RETRACEMENT"
    setup_timeframes: tuple[str, ...] = ("1m", "5m")
    allow_touched_ob: bool = True
    max_ob_age_bars: int = 300
    min_candidate_score: int = 55
    stop_buffer_ticks: int = 1
    planning_reservation_ttl_ms: int = 60_000
    target_r_multiple: Decimal = Decimal("2.0")
    min_target_r_multiple: Decimal = Decimal("1.5")
    prefer_structural_target: bool = True
    require_sweep: bool = False
    require_fvg: bool = False
    require_flow_alignment: bool = False
    require_depth_alignment: bool = False
    require_absorption_alignment: bool = False
    require_m15_alignment: bool = False
    score_fvg: int = 8
    score_sweep: int = 8
    score_flow: int = 5
    score_depth: int = 4
    score_absorption: int = 6
    score_m15: int = 5
    # Confirmation-MARKET is a retest/rejection strategy, never a breakout-chase.
    require_market_retest: bool = True
    require_m5_m1_confirmation: bool = True
    max_retest_confirmation_bars: int = 5
    max_sweep_age_bars: int = 12
    max_fvg_age_bars: int = 24
    max_sweep_distance_zone_widths: Decimal = Decimal("2")
    strict_structural_target_rr: bool = False

    def __post_init__(self) -> None:
        if self.entry_model not in ("LIMIT_RETRACEMENT", "CONFIRMATION_MARKET"):
            raise ValueError("unsupported entry_model")
        normalized = tuple(item.strip().lower() for item in self.setup_timeframes)
        if not normalized or len(set(normalized)) != len(normalized) or any(x not in ("1m", "5m") for x in normalized):
            raise ValueError("setup_timeframes must be unique members of ('1m', '5m')")
        object.__setattr__(self, "setup_timeframes", normalized)
        if not isinstance(self.allow_touched_ob, bool):
            raise ValueError("allow_touched_ob must be boolean")
        if isinstance(self.max_ob_age_bars, bool) or not isinstance(self.max_ob_age_bars, int) or not 1 <= self.max_ob_age_bars <= 100_000:
            raise ValueError("max_ob_age_bars must be an integer between 1 and 100000")
        if isinstance(self.min_candidate_score, bool) or not isinstance(self.min_candidate_score, int) or not 0 <= self.min_candidate_score <= 100:
            raise ValueError("min_candidate_score must be an integer between 0 and 100")
        if isinstance(self.stop_buffer_ticks, bool) or not isinstance(self.stop_buffer_ticks, int) or not 0 <= self.stop_buffer_ticks <= 100:
            raise ValueError("stop_buffer_ticks must be an integer between 0 and 100")
        if isinstance(self.planning_reservation_ttl_ms, bool) or not 1_000 <= self.planning_reservation_ttl_ms <= 3_600_000:
            raise ValueError("planning_reservation_ttl_ms must be between 1000 and 3600000")
        for name in ("target_r_multiple", "min_target_r_multiple"):
            value = getattr(self, name)
            if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
                raise ValueError(f"{name} must be a positive finite Decimal")
        if self.target_r_multiple < self.min_target_r_multiple:
            raise ValueError("target_r_multiple cannot be below min_target_r_multiple")
        for name in ("require_sweep", "require_fvg", "require_flow_alignment", "require_depth_alignment", "require_absorption_alignment", "require_m15_alignment", "prefer_structural_target", "require_market_retest", "require_m5_m1_confirmation", "strict_structural_target_rr"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} must be boolean")
        if isinstance(self.max_retest_confirmation_bars, bool) or not 1 <= self.max_retest_confirmation_bars <= 100:
            raise ValueError("max_retest_confirmation_bars must be 1..100")
        if isinstance(self.max_sweep_age_bars, bool) or not 1 <= self.max_sweep_age_bars <= 100:
            raise ValueError("max_sweep_age_bars must be 1..100")
        if isinstance(self.max_fvg_age_bars, bool) or not 1 <= self.max_fvg_age_bars <= 300:
            raise ValueError("max_fvg_age_bars must be 1..300")
        if not isinstance(self.max_sweep_distance_zone_widths, Decimal) or not self.max_sweep_distance_zone_widths.is_finite() or self.max_sweep_distance_zone_widths <= 0:
            raise ValueError("max_sweep_distance_zone_widths must be positive finite Decimal")
        for name in ("score_fvg", "score_sweep", "score_flow", "score_depth", "score_absorption", "score_m15"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 25:
                raise ValueError(f"{name} must be an integer between 0 and 25")

    def parameter_snapshot(self) -> tuple[tuple[str, str], ...]:
        values = asdict(self)
        return tuple(sorted((key, str(value)) for key, value in values.items()))


@dataclass(frozen=True, slots=True)
class SetupCandidate:
    """Immutable linkage from a planner candidate to original SMC evidence."""

    candidate_id: str
    symbol: str
    timeframe: str
    direction: int
    lifecycle_status: str
    age_bars: int
    captured_at_ms: int
    current_mark_price: Decimal
    ob: OrderBlockCandidate
    lifecycle: OrderBlockLifecycleSnapshot
    structure_event: StructureEvent
    matching_fvgs: tuple[FairValueGap, ...]
    matching_sweeps: tuple[LiquiditySweepEvidence, ...]
    structural_targets: tuple[StructurePivotState, ...]

    @property
    def side(self) -> str:
        return "LONG" if self.direction > 0 else "SHORT"

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id, "symbol": self.symbol,
            "timeframe": self.timeframe, "side": self.side,
            "lifecycle_status": self.lifecycle_status, "age_bars": self.age_bars,
            "captured_at_ms": self.captured_at_ms,
            "current_mark_price": str(self.current_mark_price),
            "ob": self.ob.to_dict(), "lifecycle": self.lifecycle.to_dict(),
            "structure_event": {
                "event_id": self.structure_event.event_id,
                "event_type": self.structure_event.event_type,
                "layer": self.structure_event.layer,
                "direction": self.structure_event.direction,
                "confirmation_time_ms": self.structure_event.confirmation_time_ms,
            },
            "matching_fvg_ids": [item.fvg_id for item in self.matching_fvgs],
            "matching_sweep_ids": [item.evidence_id for item in self.matching_sweeps],
            "structural_target_pivots": [
                {"kind": item.pivot.kind, "price": str(item.pivot.price),
                 "confirmation_time_ms": item.pivot.confirmation_close_time_ms}
                for item in self.structural_targets
            ],
        }


@dataclass(frozen=True, slots=True)
class CandidateEvaluation:
    candidate: SetupCandidate | None
    candidate_ref: str
    symbol: str
    timeframe: str
    status: Literal["QUALIFIED", "REJECTED", "RISK_REJECTED", "PLANNED", "ALREADY_EMITTED"]
    score: int
    reason_codes: tuple[str, ...]
    parameter_snapshot: tuple[tuple[str, str], ...]
    signal: QualifiedSignal | None = None
    plan: TradePlan | None = None
    rank: int | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_ref": self.candidate_ref, "symbol": self.symbol,
            "timeframe": self.timeframe, "status": self.status, "score": self.score,
            "rank": self.rank,
            "reason_codes": list(self.reason_codes),
            "parameter_snapshot": dict(self.parameter_snapshot),
            "candidate": None if self.candidate is None else self.candidate.to_dict(),
            "signal": None if self.signal is None else {
                "signal_id": self.signal.signal_id, "side": self.signal.side,
                "entry_type": self.signal.entry_type, "entry_price": str(self.signal.entry_price),
                "stop_loss": str(self.signal.stop_loss), "take_profit": str(self.signal.take_profit),
                "reward_risk": str(self.signal.reward_risk), "score": self.signal.score,
                "reason_codes": list(self.signal.reason_codes),
            },
            "plan": None if self.plan is None else {
                "quantity": str(self.plan.quantity), "notional_usdt": str(self.plan.notional_usdt),
                "risk_usdt": str(self.plan.risk_usdt),
                "margin_estimate_usdt": str(self.plan.margin_estimate_usdt),
                "leverage": self.plan.leverage, "client_order_id": self.plan.client_order_id,
            },
        }


@dataclass(frozen=True, slots=True)
class TradePlanningResult:
    symbol: str
    captured_at_ms: int
    evaluations: tuple[CandidateEvaluation, ...]
    scan_wait_reason: str | None = None

    @property
    def plans(self) -> tuple[TradePlan, ...]:
        return tuple(item.plan for item in self.evaluations if item.plan is not None)

    @property
    def qualified_signals(self) -> tuple[QualifiedSignal, ...]:
        return tuple(item.signal for item in self.evaluations if item.signal is not None)

    def to_jsonl(self) -> str:
        return "\n".join(json.dumps(item.to_dict(), sort_keys=True, separators=(",", ":")) for item in self.evaluations)


def _floor_grid(value: Decimal, step: Decimal) -> Decimal:
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step


def _ceil_grid(value: Decimal, step: Decimal) -> Decimal:
    return (value / step).to_integral_value(rounding=ROUND_UP) * step


def _signal_hash(*parts: object) -> str:
    data = "|".join(str(item) for item in parts).encode("utf-8")
    return hashlib.sha256(data).hexdigest()[:24]


class SMCV2TradePlanner:
    """Qualifies SMC OB candidates and returns risk-sized TradePlans without orders."""

    def __init__(self, *, config: SMCTradePlannerConfig | None = None,
                 risk_manager: PortfolioRiskManager | None = None) -> None:
        self.config = config or SMCTradePlannerConfig()
        self.risk_manager = risk_manager or PortfolioRiskManager(PortfolioRiskConfig())
        self._lock = RLock()
        self._emitted: set[tuple[str, str, str]] = set()
        # Reservations prevent separate pair callbacks in the same live process
        # from independently consuming the full provisional risk budget.
        self._reservations: dict[str, tuple[int, str, Decimal, Decimal]] = {}

    def evaluate(
        self, evidence: SMCV2EvidenceSnapshot, *, equity_usdt: Decimal,
        open_risk_usdt: Decimal = Decimal("0"), active_position_count: int = 0,
        symbol_notional_usdt: Decimal = Decimal("0"), qualification_only: bool = False,
        qualification_defer_reason: str = "DEFERRED_TO_AUTONOMOUS_GLOBAL_RISK",
        mark_qualified_emitted: bool = True,
    ) -> TradePlanningResult:
        if not isinstance(evidence, SMCV2EvidenceSnapshot):
            raise TypeError("evidence must be SMCV2EvidenceSnapshot")
        if not isinstance(equity_usdt, Decimal) or not equity_usdt.is_finite() or equity_usdt <= 0:
            raise ValueError("equity_usdt must be a positive finite Decimal")
        if not isinstance(open_risk_usdt, Decimal) or not open_risk_usdt.is_finite() or open_risk_usdt < 0:
            raise ValueError("open_risk_usdt must be a non-negative finite Decimal")
        if not isinstance(symbol_notional_usdt, Decimal) or not symbol_notional_usdt.is_finite() or symbol_notional_usdt < 0:
            raise ValueError("symbol_notional_usdt must be a non-negative finite Decimal")
        if isinstance(active_position_count, bool) or not isinstance(active_position_count, int) or active_position_count < 0:
            raise ValueError("active_position_count must be a non-negative integer")
        if not isinstance(mark_qualified_emitted, bool):
            raise TypeError("mark_qualified_emitted must be bool")
        if not isinstance(qualification_defer_reason, str) or not qualification_defer_reason.strip():
            raise ValueError("qualification_defer_reason must be a non-empty string")

        # The full evaluation is serialized: per-pair callbacks cannot race the
        # in-memory risk reservations or emit the same candidate twice.
        with self._lock:
            view = evidence.market_view
            cfg = self.config
            params = cfg.parameter_snapshot() + tuple(sorted((
                ("risk." + key, str(value))
                for key, value in asdict(self.risk_manager.config).items()
            )))
            self._prune_reservations(evidence.captured_at_ms)
            reserved_risk = open_risk_usdt + sum(
                (row[2] for row in self._reservations.values()), Decimal("0")
            )
            reserved_count = active_position_count + len(self._reservations)
            reserved_notional_by_symbol: dict[str, Decimal] = {}
            for _, symbol, _, notional in self._reservations.values():
                reserved_notional_by_symbol[symbol] = (
                    reserved_notional_by_symbol.get(symbol, Decimal("0")) + notional
                )
            reserved_notional = symbol_notional_usdt + reserved_notional_by_symbol.get(
                evidence.symbol, Decimal("0")
            )

            raw_evaluations: list[CandidateEvaluation] = []
            for timeframe in cfg.setup_timeframes:
                lifecycle_tf = evidence.ob_lifecycle.timeframe(timeframe)
                structure_tf = evidence.structure.timeframe(timeframe)
                if lifecycle_tf is None:
                    continue
                timeframe_ready = (
                    view.readiness.m1_setup_ready if timeframe == "1m"
                    else view.readiness.m5_setup_ready
                )
                if not timeframe_ready:
                    for item in lifecycle_tf.order_blocks:
                        raw_evaluations.append(self._reject_ref(
                            item.candidate, evidence.captured_at_ms,
                            "SETUP_TIMEFRAME_NOT_READY", params,
                        ))
                    continue
                for lifecycle in lifecycle_tf.order_blocks:
                    raw_evaluations.append(
                        self._evaluate_candidate(evidence, view, lifecycle, structure_tf, params)
                    )

            # Score all setup candidates first, then route by descending score.
            # This is a deterministic ranking, not M5-over-M1 or nested MTF priority.
            rejected = [item for item in raw_evaluations if item.status != "QUALIFIED"]
            qualified = sorted(
                (item for item in raw_evaluations if item.status == "QUALIFIED" and item.signal is not None),
                key=lambda item: (-item.score, item.timeframe, item.candidate_ref),
            )
            ranked: list[CandidateEvaluation] = []
            for rank, evaluation in enumerate(qualified, start=1):
                candidate = evaluation.candidate
                assert candidate is not None and evaluation.signal is not None
                ranked_reasons = evaluation.reason_codes + (f"CANDIDATE_SCORE_RANK_{rank}",)
                key = (candidate.symbol, candidate.candidate_id, cfg.entry_model)
                if key in self._emitted:
                    ranked.append(CandidateEvaluation(
                        evaluation.candidate, candidate.candidate_id, candidate.symbol,
                        candidate.timeframe, "ALREADY_EMITTED", evaluation.score,
                        ("CANDIDATE_SIGNAL_ALREADY_EMITTED",), params,
                        evaluation.signal, None, rank,
                    ))
                    continue
                if qualification_only:
                    # Autonomous dispatch performs authoritative sizing only after
                    # claiming a durable dispatch intent and fetching a fresh account
                    # snapshot. Do not consume a provisional planner risk budget here.
                    # Autonomous path delegates durable at-most-once ownership to
                    # ExecutionLedger. Qualification is not acknowledgement of dispatch.
                    if mark_qualified_emitted:
                        self._emitted.add(key)
                    ranked.append(CandidateEvaluation(
                        evaluation.candidate, candidate.candidate_id, candidate.symbol,
                        candidate.timeframe, "QUALIFIED", evaluation.score,
                        ranked_reasons + (qualification_defer_reason,),
                        params, evaluation.signal, None, rank,
                    ))
                    continue
                decision = self.risk_manager.size_signal(
                    evaluation.signal, view.instrument, equity_usdt=equity_usdt,
                    open_risk_usdt=reserved_risk, active_position_count=reserved_count,
                    existing_symbol_notional_usdt=reserved_notional,
                    client_order_id="DIVA" + _signal_hash(evaluation.signal.signal_id, "ENTRY")[:28],
                )
                if not decision.accepted or decision.plan is None:
                    ranked.append(CandidateEvaluation(
                        evaluation.candidate, candidate.candidate_id, candidate.symbol,
                        candidate.timeframe, "RISK_REJECTED", evaluation.score,
                        ranked_reasons + (decision.reason,), params, evaluation.signal, None, rank,
                    ))
                    continue
                self._emitted.add(key)
                reserved_risk += decision.plan.risk_usdt
                reserved_count += 1
                reserved_notional += decision.plan.notional_usdt
                self._reservations[decision.plan.signal.signal_id] = (
                    evidence.captured_at_ms + cfg.planning_reservation_ttl_ms,
                    candidate.symbol, decision.plan.risk_usdt, decision.plan.notional_usdt,
                )
                ranked.append(CandidateEvaluation(
                    evaluation.candidate, candidate.candidate_id, candidate.symbol,
                    candidate.timeframe, "PLANNED", evaluation.score,
                    ranked_reasons + ("GLOBAL_RISK_APPROVED",), params,
                    evaluation.signal, decision.plan, rank,
                ))
            evaluations = rejected + ranked
            evaluations.sort(key=lambda item: (
                item.rank is None, item.rank if item.rank is not None else 10**9,
                -item.score, item.timeframe, item.candidate_ref,
            ))
            return TradePlanningResult(evidence.symbol, evidence.captured_at_ms, tuple(evaluations))

    def reset_symbol(self, symbol: str) -> None:
        normalized = symbol.strip().upper()
        with self._lock:
            self._emitted = {item for item in self._emitted if item[0] != normalized}
            self._reservations = {
                signal_id: row for signal_id, row in self._reservations.items()
                if row[1] != normalized
            }

    def reset_planning_reservations(self) -> None:
        """Clear short-lived PAPER reservations after caller reconciles portfolio state."""
        with self._lock:
            self._reservations.clear()

    def release_candidate_signal(self, *, symbol: str, candidate_id: str) -> None:
        """Allow a candidate to be reconsidered after its downstream intent is closed."""
        normalized = symbol.strip().upper()
        with self._lock:
            self._emitted = {
                item for item in self._emitted
                if not (item[0] == normalized and item[1] == candidate_id)
            }
            self._reservations = {
                signal_id: row for signal_id, row in self._reservations.items()
                if not (row[1] == normalized and signal_id == _signal_hash(normalized, candidate_id, self.config.entry_model))
            }

    def _prune_reservations(self, now_ms: int) -> None:
        self._reservations = {
            signal_id: row for signal_id, row in self._reservations.items()
            if row[0] > now_ms
        }

    def _reject_ref(self, ob: OrderBlockCandidate, captured_at_ms: int, reason: str,
                    params: tuple[tuple[str, str], ...]) -> CandidateEvaluation:
        return CandidateEvaluation(None, ob.candidate_id, ob.symbol, ob.timeframe,
                                   "REJECTED", 0, (reason,), params)

    def _evaluate_candidate(self, evidence: SMCV2EvidenceSnapshot,
                            view: ScalpingMarketDataView,
                            lifecycle: OrderBlockLifecycleSnapshot,
                            structure_tf: StructureTimeframeResult | None,
                            params: tuple[tuple[str, str], ...]) -> CandidateEvaluation:
        ob = lifecycle.candidate
        reasons: list[str] = []
        cfg = self.config
        allowed_states = ("ACTIVE_FRESH", "TOUCHED", "MITIGATED") if cfg.allow_touched_ob else ("ACTIVE_FRESH",)
        if lifecycle.status not in allowed_states:
            return self._reject_ref(ob, evidence.captured_at_ms, f"OB_LIFECYCLE_{lifecycle.status}", params)
        if lifecycle.status == "MITIGATED" and lifecycle.maximum_mitigation_depth_ratio >= Decimal("1"):
            return self._reject_ref(ob, evidence.captured_at_ms, "OB_FULLY_MITIGATED", params)
        if lifecycle.age_bars > cfg.max_ob_age_bars:
            return self._reject_ref(ob, evidence.captured_at_ms, "OB_AGE_EXCEEDS_PLANNER_LIMIT", params)
        if structure_tf is None or structure_tf.status != "READY":
            return self._reject_ref(ob, evidence.captured_at_ms, "STRUCTURE_TIMEFRAME_NOT_READY", params)
        if (ob.symbol != evidence.symbol or view.symbol != evidence.symbol
                or view.instrument.symbol != evidence.symbol or ob.timeframe not in ("1m", "5m")):
            return self._reject_ref(ob, evidence.captured_at_ms, "CANDIDATE_IDENTITY_MISMATCH", params)
        if ob.source_confirmation_time_ms > evidence.captured_at_ms or ob.break_confirmation_time_ms > evidence.captured_at_ms:
            return self._reject_ref(ob, evidence.captured_at_ms, "LOOKAHEAD_TIMESTAMP_DETECTED", params)
        event = next((item for item in structure_tf.events if item.event_id == ob.event_id), None)
        if event is None or event.confirmation_time_ms > evidence.captured_at_ms:
            return self._reject_ref(ob, evidence.captured_at_ms, "SOURCE_STRUCTURE_EVENT_UNAVAILABLE", params)
        if event.direction != ob.direction or event.symbol != ob.symbol or event.timeframe != ob.timeframe:
            return self._reject_ref(ob, evidence.captured_at_ms, "STRUCTURE_DIRECTION_OR_IDENTITY_MISMATCH", params)
        quote = view.mark_price.mark_price if view.mark_price is not None else None
        candle_snapshot = view.kline(ob.timeframe)
        candle = None if candle_snapshot is None else candle_snapshot.latest_closed_candle
        if quote is None or candle is None:
            return self._reject_ref(ob, evidence.captured_at_ms, "ENTRY_REFERENCE_PRICE_UNAVAILABLE", params)
        if candle.close_time_ms > evidence.captured_at_ms:
            return self._reject_ref(ob, evidence.captured_at_ms, "FUTURE_SETUP_CANDLE_TIMESTAMP", params)
        if quote <= 0 or quote.is_finite() is False or view.mark_price.symbol != evidence.symbol:
            return self._reject_ref(ob, evidence.captured_at_ms, "ENTRY_REFERENCE_PRICE_INVALID", params)
        if view.mark_price.event_time_ms > evidence.captured_at_ms:
            return self._reject_ref(ob, evidence.captured_at_ms, "FUTURE_MARK_PRICE_TIMESTAMP", params)

        tf_fvgs = evidence.liquidity_fvg.timeframe(ob.timeframe)
        interval_ms = 60_000 if ob.timeframe == "1m" else 300_000
        matching_fvgs = tuple(
            item for item in (() if tf_fvgs is None else tf_fvgs.fvgs)
            if item.direction == ob.direction and item.status != "FILLED"
            and item.zone_bottom <= ob.zone_top and item.zone_top >= ob.zone_bottom
            and evidence.captured_at_ms - cfg.max_fvg_age_bars * interval_ms <= item.confirmation_time_ms <= evidence.captured_at_ms
        )
        tf_sweeps = evidence.liquidity_fvg.timeframe(ob.timeframe)
        # A historical sweep must be both causal and geometrically relevant to
        # the OB. Direction alone does not establish confluence.
        sweep_window_ms = cfg.max_sweep_age_bars * interval_ms
        zone_width = ob.zone_top - ob.zone_bottom
        max_sweep_distance = zone_width * cfg.max_sweep_distance_zone_widths
        matching_sweeps = tuple(
            item for item in (() if tf_sweeps is None else tf_sweeps.sweeps)
            if item.symbol == ob.symbol and item.timeframe == ob.timeframe
            and item.direction == ob.direction and item.qualifies_as_sweep
            and item.confirmation_time_ms <= evidence.captured_at_ms
            and ob.break_confirmation_time_ms - sweep_window_ms <= item.confirmation_time_ms
            and item.confirmation_time_ms <= ob.break_confirmation_time_ms
            and ob.zone_bottom - max_sweep_distance <= item.reference_price <= ob.zone_top + max_sweep_distance
        )
        candidate = SetupCandidate(
            ob.candidate_id, ob.symbol, ob.timeframe, ob.direction, lifecycle.status,
            lifecycle.age_bars, evidence.captured_at_ms, quote, ob, lifecycle, event,
            matching_fvgs, matching_sweeps, tuple(structure_tf.pivots),
        )
        score = 45 if lifecycle.status == "ACTIVE_FRESH" else 40
        reasons.append("OB_ACTIVE_FRESH" if lifecycle.status == "ACTIVE_FRESH" else (
            "OB_PARTIALLY_MITIGATED" if lifecycle.status == "MITIGATED" else "OB_TOUCHED"))
        if str(event.event_type).upper() == "CHOCH":
            score += 10
            reasons.append("STRUCTURE_CHOCH")
        else:
            score += 8
            reasons.append("STRUCTURE_BOS")
        if event.layer == "SWING":
            score += 5
            reasons.append("SWING_STRUCTURE_EVENT")
        else:
            reasons.append("INTERNAL_STRUCTURE_EVENT")
        if matching_fvgs:
            score += cfg.score_fvg
            reasons.append("DIRECTIONAL_OB_FVG_OVERLAP")
        elif cfg.require_fvg:
            reasons.append("REQUIRED_FVG_CONFLUENCE_MISSING")
        if matching_sweeps:
            score += cfg.score_sweep
            reasons.append("DIRECTIONAL_LIQUIDITY_SWEEP")
        elif cfg.require_sweep:
            reasons.append("REQUIRED_SWEEP_MISSING")

        flow = view.flow
        flow_aligned = bool(flow and flow.is_fresh and flow.continuity_valid and
            ((flow.delta_quote > 0 and flow.cvd_quote >= 0) if ob.direction > 0
             else (flow.delta_quote < 0 and flow.cvd_quote <= 0)))
        if flow_aligned:
            score += cfg.score_flow
            reasons.append("DELTA_CVD_ALIGNED")
        elif cfg.require_flow_alignment:
            reasons.append("REQUIRED_DELTA_CVD_ALIGNMENT_MISSING")
        elif flow and flow.is_fresh and flow.continuity_valid:
            reasons.append("DELTA_CVD_NOT_ALIGNED_OR_FLAT")
        else:
            reasons.append("DELTA_CVD_ADVISORY_UNAVAILABLE")

        depth = view.order_book_metrics
        depth_aligned = bool(depth and depth.synchronized and
            ((depth.imbalance > 0) if ob.direction > 0 else (depth.imbalance < 0)))
        if depth_aligned:
            score += cfg.score_depth
            reasons.append("ORDER_BOOK_IMBALANCE_ALIGNED")
        elif cfg.require_depth_alignment:
            reasons.append("REQUIRED_DEPTH_ALIGNMENT_MISSING")
        else:
            reasons.append("DEPTH_ADVISORY_NOT_ALIGNED_OR_UNAVAILABLE")

        absorption = view.absorption
        expected_absorbed = "SELL" if ob.direction > 0 else "BUY"
        absorption_aligned = bool(absorption and absorption.status == "CANDIDATE" and
                                  absorption.absorbed_aggressor == expected_absorbed)
        if absorption_aligned:
            score += cfg.score_absorption
            reasons.append("ABSORPTION_ALIGNED")
        elif cfg.require_absorption_alignment:
            reasons.append("REQUIRED_ABSORPTION_ALIGNMENT_MISSING")
        else:
            reasons.append("ABSORPTION_ADVISORY_NOT_ALIGNED_OR_UNAVAILABLE")

        m15_tf = evidence.structure.timeframe("15m")
        m15_direction = self._timeframe_direction(m15_tf, evidence.captured_at_ms)
        m15_aligned = m15_direction == ob.direction
        if m15_aligned:
            score += cfg.score_m15
            reasons.append("M15_ADVISORY_ALIGNED")
        elif cfg.require_m15_alignment:
            reasons.append("REQUIRED_M15_ALIGNMENT_MISSING")
        elif m15_direction == -ob.direction:
            reasons.append("M15_ADVISORY_OPPOSES_SETUP_NO_HARD_VETO")
        else:
            reasons.append("M15_ADVISORY_UNAVAILABLE")

        if score > 100:
            score = 100
            reasons.append("SCORE_CAPPED_AT_100")
        required_missing = any(code.startswith("REQUIRED_") for code in reasons)
        if required_missing:
            return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                       "REJECTED", score, tuple(reasons), params)
        if score < cfg.min_candidate_score:
            return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                       "REJECTED", score, tuple(reasons + ["SCORE_BELOW_MINIMUM"]), params)

        if cfg.entry_model == "CONFIRMATION_MARKET":
            if cfg.require_market_retest:
                first_touch = lifecycle.first_touch_time_ms
                if first_touch is None or first_touch <= ob.break_confirmation_time_ms:
                    return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                               "REJECTED", score, tuple(reasons + ["MARKET_RETEST_NOT_CONFIRMED"]), params)
            else:
                first_touch = None
            confirmation_candle = candle
            if ob.timeframe == "5m" and cfg.require_m5_m1_confirmation:
                if not getattr(view.readiness, "m5_m1_confirmation_ready", False):
                    return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                               "REJECTED", score, tuple(reasons + ["M5_M1_CONFIRMATION_NOT_READY"]), params)
                m1 = view.kline("1m")
                confirmation_candle = None if m1 is None else m1.latest_closed_candle
                if confirmation_candle is None:
                    return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                               "REJECTED", score, tuple(reasons + ["M5_M1_CLOSED_CANDLE_UNAVAILABLE"]), params)
                reasons.append("M5_SETUP_M1_ENTRY_CONFIRMATION")
            if confirmation_candle.close_time_ms > evidence.captured_at_ms:
                return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                           "REJECTED", score, tuple(reasons + ["FUTURE_CONFIRMATION_CANDLE"]), params)
            if first_touch is not None:
                if confirmation_candle.close_time_ms <= first_touch:
                    return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                               "REJECTED", score, tuple(reasons + ["CONFIRMATION_PRECEDES_OR_EQUALS_RETEST"]), params)
                interval_ms = 60_000 if (ob.timeframe == "1m" or (ob.timeframe == "5m" and cfg.require_m5_m1_confirmation)) else 300_000
                if confirmation_candle.close_time_ms - first_touch > cfg.max_retest_confirmation_bars * interval_ms:
                    return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                               "REJECTED", score, tuple(reasons + ["MARKET_RETEST_CONFIRMATION_EXPIRED"]), params)
            candle = confirmation_candle
        planned = self._build_prices(candidate, view, candle.open, candle.close)
        if isinstance(planned, str):
            return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                       "REJECTED", score, tuple(reasons + [planned]), params)
        entry_type, entry_price, stop_loss, take_profit, level_reasons = planned
        reasons.extend(level_reasons)
        reasons.append(
            "ENTRY_LIMIT_RETRACEMENT_MIDPOINT"
            if entry_type == "LIMIT" else "ENTRY_CONFIRMATION_CLOSED_CANDLE_MARKET"
        )
        signal_id = _signal_hash(ob.symbol, ob.candidate_id, cfg.entry_model)
        signal = QualifiedSignal(
            signal_id=signal_id, symbol=ob.symbol,
            side="LONG" if ob.direction > 0 else "SHORT", entry_type=entry_type,
            entry_price=entry_price, stop_loss=stop_loss, take_profit=take_profit,
            timeframe=ob.timeframe, strategy_id="SMC_V2_STAGE2_5",
            created_at_ms=evidence.captured_at_ms, reason_codes=tuple(reasons), score=score,
        )
        return CandidateEvaluation(candidate, ob.candidate_id, ob.symbol, ob.timeframe,
                                   "QUALIFIED", score, tuple(reasons), params, signal, None)

    @staticmethod
    def _timeframe_direction(item: StructureTimeframeResult | None, as_of_ms: int) -> int:
        if item is None or item.status != "READY":
            return 0
        confirmed_events = tuple(event for event in item.events if event.confirmation_time_ms <= as_of_ms)
        if confirmed_events:
            return max(confirmed_events, key=lambda event: event.confirmation_time_ms).direction
        if item.swing.direction:
            return item.swing.direction
        return item.internal.direction

    def _build_prices(self, candidate: SetupCandidate, view: ScalpingMarketDataView,
                      candle_open: Decimal, candle_close: Decimal):
        cfg = self.config
        instrument = view.instrument
        tick = instrument.tick_size
        if tick is None or tick <= 0:
            return "PRICE_FILTER_TICK_SIZE_UNAVAILABLE"
        ob = candidate.ob
        if instrument.min_notional is None:
            return "NOTIONAL_FILTER_MINIMUM_UNAVAILABLE"
        if cfg.entry_model == "LIMIT_RETRACEMENT":
            entry_type = "LIMIT"
            raw_entry = (ob.zone_top + ob.zone_bottom) / Decimal("2")
            entry = _floor_grid(raw_entry, tick) if ob.direction > 0 else _ceil_grid(raw_entry, tick)
            if ob.direction > 0 and candidate.current_mark_price <= ob.zone_top:
                return "LIMIT_RETRACEMENT_NOT_BELOW_CURRENT_MARKET"
            if ob.direction < 0 and candidate.current_mark_price >= ob.zone_bottom:
                return "LIMIT_RETRACEMENT_NOT_ABOVE_CURRENT_MARKET"
        else:
            entry_type = "MARKET"
            if ob.direction > 0 and not (candle_close > ob.zone_top and candle_close > candle_open):
                return "BULLISH_MARKET_CONFIRMATION_NOT_MET"
            if ob.direction < 0 and not (candle_close < ob.zone_bottom and candle_close < candle_open):
                return "BEARISH_MARKET_CONFIRMATION_NOT_MET"
            # Mark is not a tradable quote and need not land on PRICE_FILTER ticks.
            # Use an adverse-side rounded provisional estimate for risk sizing;
            # the final executable depth quote is checked immediately before POST.
            entry = (_ceil_grid(candidate.current_mark_price, tick) if ob.direction > 0
                     else _floor_grid(candidate.current_mark_price, tick))
            if entry <= 0:
                return "MARKET_REFERENCE_PRICE_INVALID"

        buffer = tick * Decimal(cfg.stop_buffer_ticks)
        if ob.direction > 0:
            stop = _floor_grid(ob.zone_bottom - buffer, tick)
            if stop <= 0 or not stop < entry:
                return "LONG_STOP_GEOMETRY_INVALID"
            risk_distance = entry - stop
            rr_target = _ceil_grid(entry + risk_distance * cfg.target_r_multiple, tick)
        else:
            stop = _ceil_grid(ob.zone_top + buffer, tick)
            if not entry < stop:
                return "SHORT_STOP_GEOMETRY_INVALID"
            risk_distance = stop - entry
            rr_target = _floor_grid(entry - risk_distance * cfg.target_r_multiple, tick)
            if rr_target <= 0:
                return "SHORT_TARGET_NON_POSITIVE"

        target = rr_target
        target_reason = "TARGET_CONFIGURED_R_MULTIPLE"
        if cfg.prefer_structural_target:
            eligible: list[Decimal] = []
            for state in candidate.structural_targets:
                pivot = state.pivot
                if state.broken or pivot.confirmation_close_time_ms > candidate.captured_at_ms:
                    continue
                if ob.direction > 0 and pivot.kind == "HIGH" and pivot.price > entry and pivot.price > candidate.current_mark_price:
                    candidate_rr = (pivot.price - entry) / risk_distance
                    if candidate_rr >= (cfg.target_r_multiple if cfg.strict_structural_target_rr else cfg.min_target_r_multiple):
                        eligible.append(_ceil_grid(pivot.price, tick))
                elif ob.direction < 0 and pivot.kind == "LOW" and pivot.price < entry and pivot.price < candidate.current_mark_price:
                    candidate_rr = (entry - pivot.price) / risk_distance
                    if candidate_rr >= (cfg.target_r_multiple if cfg.strict_structural_target_rr else cfg.min_target_r_multiple):
                        eligible.append(_floor_grid(pivot.price, tick))
            if eligible:
                target = min(eligible) if ob.direction > 0 else max(eligible)
                target_reason = "TARGET_CONFIRMED_STRUCTURE_PIVOT"
        if ob.direction > 0 and target <= entry:
            return "LONG_TARGET_GEOMETRY_INVALID"
        if ob.direction < 0 and target >= entry:
            return "SHORT_TARGET_GEOMETRY_INVALID"

        prices = (entry, stop, target)
        if instrument.min_price is not None and instrument.min_price > 0 and any(p < instrument.min_price for p in prices):
            return "PRICE_BELOW_EXCHANGE_MINIMUM"
        if instrument.max_price is not None and instrument.max_price > 0 and any(p > instrument.max_price for p in prices):
            return "PRICE_ABOVE_EXCHANGE_MAXIMUM"
        expected_types = {"LIMIT" if entry_type == "LIMIT" else "MARKET", "STOP_MARKET", "TAKE_PROFIT_MARKET"}
        if not instrument.order_types or not expected_types.issubset(set(instrument.order_types)):
            return "EXCHANGE_ENTRY_OR_BRACKET_ORDER_TYPE_UNAVAILABLE"
        if entry_type == "LIMIT" and "GTC" not in instrument.time_in_force:
            return "EXCHANGE_LIMIT_TIME_IN_FORCE_UNAVAILABLE"
        for price in prices:
            if price % tick:
                return "PLANNED_PRICE_OFF_EXCHANGE_TICK"
        return entry_type, entry, stop, target, ("DYNAMIC_SL_BEYOND_OB_INVALIDATION", target_reason)
