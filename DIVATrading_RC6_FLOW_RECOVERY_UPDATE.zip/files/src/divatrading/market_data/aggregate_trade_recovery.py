"""Durable Aggregate Trade bootstrap, gap detection and REST reconciliation."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import islice
from typing import Callable, Iterable

from divatrading.market_data.aggregate_trade_history import (
    BINANCE_AGG_TRADE_HISTORY_WINDOW_MS,
    AggregateTradeRecord,
    BinanceAggregateTradeHistoryService,
)
from divatrading.market_data.aggregate_trade_storage import (
    MAX_AGG_TRADE_WRITE_BATCH,
    AggregateTradeRepository,
    AggregateTradeStreamState,
    AggregateTradeStreamStateError,
)
from divatrading.market_data.aggregate_trades import AggregateTradeEvent


class AggregateTradeRecoveryError(RuntimeError):
    """Base class for Aggregate Trade recovery failures."""


class AggregateTradeRecoveryRequired(AggregateTradeRecoveryError):
    """Raised when a stream needs bootstrap/reconciliation before use."""


@dataclass(frozen=True, slots=True)
class AggregateTradeRecoveryResult:
    symbol: str
    status: str
    records_recovered: int
    pages_fetched: int
    complete: bool
    next_from_id: int | None
    missing_id: int | None
    reason: str | None


class AggregateTradeRecoveryService:
    """Connect Unit 04A WebSocket events to REST history and SQLite continuity.

    The caller must connect the WebSocket and start draining its bounded queue
    before calling ``bootstrap_latest``. This overlaps the REST baseline window
    with live traffic so events arriving during bootstrap are not discarded.
    """

    def __init__(
        self,
        history: BinanceAggregateTradeHistoryService,
        repository: AggregateTradeRepository,
        *,
        history_window_ms: int = BINANCE_AGG_TRADE_HISTORY_WINDOW_MS,
        now_ms: Callable[[], int] | None = None,
    ) -> None:
        if isinstance(history_window_ms, bool) or not isinstance(history_window_ms, int) or history_window_ms <= 0:
            raise ValueError("history_window_ms must be a positive integer")
        self.history = history
        self.repository = repository
        self.history_window_ms = history_window_ms
        self._now_ms = now_ms or (lambda: int(datetime.now(UTC).timestamp() * 1000))

    def bootstrap_latest(self, *, symbol: str, limit: int | None = None) -> AggregateTradeStreamState:
        """Establish an explicit recent baseline from a contiguous latest REST page."""
        batch = self.history.fetch_latest(symbol=symbol, limit=limit)
        if not batch.records:
            raise AggregateTradeRecoveryRequired(
                "Binance returned no recent aggregate trades; no baseline can be established"
            )
        return self.repository.bootstrap_latest(batch.records)

    def ingest_websocket_event(self, event: AggregateTradeEvent) -> AggregateTradeStreamState:
        """Persist a live event; gaps remain durable and block HEALTHY status."""
        if not isinstance(event, AggregateTradeEvent):
            raise TypeError("event must be an AggregateTradeEvent")
        return self.repository.record_observed(AggregateTradeRecord.from_websocket(event))

    def ingest_websocket_events(self, events: Iterable[AggregateTradeEvent]) -> AggregateTradeStreamState:
        """Persist a bounded, single-symbol batch in WebSocket receive order."""
        batch = tuple(islice(events, MAX_AGG_TRADE_WRITE_BATCH + 1))
        if not 1 <= len(batch) <= MAX_AGG_TRADE_WRITE_BATCH:
            raise ValueError(f"batch must contain 1..{MAX_AGG_TRADE_WRITE_BATCH} Aggregate Trade events")
        if any(not isinstance(event, AggregateTradeEvent) for event in batch):
            raise TypeError("batch must contain AggregateTradeEvent values")
        records = tuple(AggregateTradeRecord.from_websocket(event) for event in batch)
        return self.repository.record_observed_many(records)

    def recover_gap(self, *, symbol: str) -> AggregateTradeRecoveryResult:
        """Backfill missing IDs in a bounded pass; never synthesize missing trades."""
        try:
            state = self.repository.get_stream_state(symbol)
        except AggregateTradeStreamStateError as exc:
            raise AggregateTradeRecoveryRequired(
                f"Stream {symbol} must be bootstrapped before recovery"
            ) from exc

        if state.status == "HEALTHY":
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=True, next_from_id=None, missing_id=None, reason=None,
            )
        if state.status == "UNRESOLVED":
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=False,
                next_from_id=state.unresolved_gap_from_id,
                missing_id=state.unresolved_gap_from_id,
                reason="A previous recovery marked this gap as outside/unavailable in exchange history",
            )

        expected_id = state.last_contiguous_aggregate_trade_id + 1
        through_id = state.latest_observed_aggregate_trade_id - 1
        if through_id < expected_id:
            # This can be a just-registered stream awaiting its first expected row.
            return AggregateTradeRecoveryResult(
                symbol=state.symbol, status=state.status, records_recovered=0,
                pages_fetched=0, complete=False, next_from_id=expected_id,
                missing_id=expected_id, reason="No later observed ID defines a closed recovery range",
            )

        cutoff_ms = self._now_ms() - self.history_window_ms
        baseline_time = state.last_contiguous_trade_time_ms
        observed_time = state.latest_observed_trade_time_ms
        if baseline_time is not None and baseline_time < cutoff_ms:
            reason = (
                "The missing range begins before the exchange's documented recent aggregate-trade history window; "
                "historical IDs cannot be assumed retrievable."
            )
            return self._mark_missing(
                symbol=state.symbol, status="UNRESOLVED_RETENTION", missing_id=expected_id, reason=reason,
            )
        if observed_time is not None and observed_time < cutoff_ms:
            reason = "Observed gap endpoint is older than the supported exchange history window."
            return self._mark_missing(
                symbol=state.symbol, status="UNRESOLVED_RETENTION", missing_id=expected_id, reason=reason,
            )

        batch = self.history.fetch_range(
            symbol=state.symbol, from_id=expected_id, through_id=through_id
        )
        recovered = self.repository.persist_recovered(batch.records, symbol=state.symbol)
        if batch.missing_id is not None:
            reason = (
                f"REST history did not provide expected aggregate trade ID {batch.missing_id}. "
                "The range remains unresolved; no synthetic trade was created."
            )
            return self._mark_missing(
                symbol=state.symbol, status="UNRESOLVED_HISTORY", missing_id=batch.missing_id,
                reason=reason, records_recovered=len(batch.records), pages_fetched=batch.pages_fetched,
            )
        complete = recovered.status == "HEALTHY"
        reason = None
        if not complete:
            if batch.complete:
                reason = "The current stream still has a gap; continue from next_from_id."
            else:
                reason = "Per-pass page cap reached; continue from next_from_id in another bounded pass."
        unresolved = recovered.unresolved_gap_from_id if recovered.status == "UNRESOLVED" else None
        return AggregateTradeRecoveryResult(
            symbol=state.symbol, status=recovered.status,
            records_recovered=len(batch.records), pages_fetched=batch.pages_fetched,
            complete=complete,
            next_from_id=None if complete else self._next_gap_id(recovered),
            missing_id=unresolved, reason=reason,
        )

    def _mark_missing(
        self, *, symbol: str, status: str, missing_id: int, reason: str,
        records_recovered: int = 0, pages_fetched: int = 0,
    ) -> AggregateTradeRecoveryResult:
        updated = self.repository.mark_unresolved(
            symbol=symbol, status=status, reason=reason, expected_missing_id=missing_id,
        )
        complete = updated.status == "HEALTHY"
        unresolved = updated.unresolved_gap_from_id if updated.status == "UNRESOLVED" else None
        if complete:
            reason = None
        elif unresolved != missing_id:
            reason = "Recovery observation superseded by the current stream state."
        return AggregateTradeRecoveryResult(
            symbol=symbol, status=updated.status, records_recovered=records_recovered,
            pages_fetched=pages_fetched, complete=complete,
            next_from_id=None if complete else self._next_gap_id(updated),
            missing_id=unresolved, reason=reason,
        )

    @staticmethod
    def _next_gap_id(state: AggregateTradeStreamState) -> int:
        if state.unresolved_gap_from_id is not None:
            return state.unresolved_gap_from_id
        return state.last_contiguous_aggregate_trade_id + 1
