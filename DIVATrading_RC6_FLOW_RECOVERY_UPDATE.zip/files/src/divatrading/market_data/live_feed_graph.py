"""Production read-only Binance USD-M feed graph for one selected symbol.

Each graph is isolated to one exact symbol.  It composes the existing Kline,
Mark Price, Aggregate Trade, depth, recovery, Delta/CVD and absorption services
and emits only complete, fresh ``ScalpingMarketDataView`` snapshots.  It never
submits, modifies or cancels exchange orders.
"""
from __future__ import annotations

import asyncio
import logging
import time
import threading
from collections import deque
from contextlib import aclosing
from dataclasses import dataclass, replace
from typing import AsyncIterator, Callable

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import ExchangeInfoSnapshot, SymbolInfo
from divatrading.market_data.absorption import DepthAggressorAlignmentService
from divatrading.market_data.aggregate_trade_history import BinanceAggregateTradeHistoryService
from divatrading.market_data.aggregate_trade_recovery import AggregateTradeRecoveryService
from divatrading.market_data.aggregate_trade_storage import AggregateTradeRepository
from divatrading.market_data.aggregate_trades import BinanceAggregateTradeWebSocketFeed
from divatrading.market_data.history import HistoricalKlineService
from divatrading.market_data.klines import INTERVAL_MILLISECONDS
from divatrading.market_data.mark_price import BinanceMarkPriceWebSocketFeed, MarkPriceEvent
from divatrading.market_data.order_book import (
    BINANCE_UM_DEMO_DEPTH_WS_ENDPOINT, BINANCE_UM_DEPTH_WS_ENDPOINT,
    BinanceDepthSnapshotClient, BinanceDepthWebSocketFeed, OrderBookMetrics,
)
from divatrading.market_data.order_book_supervisor import BinanceOrderBookSupervisor
from divatrading.market_data.order_flow import DeltaCvdService, OrderFlowRepository
from divatrading.market_data.orchestrator import (
    MarketDataOrchestratorConfig,
    MarketDataReadiness,
    UnifiedMarketDataOrchestrator,
)
from divatrading.market_data.recovery import FeedHealth, KlineRecoveryService
from divatrading.market_data.storage import KlineRepository
from divatrading.market_data.strategy_snapshot import KlineSeriesInput
from divatrading.market_data.websocket import (
    BinanceKlineWebSocketFeed, MarketKlineEvent,
    BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
)
from divatrading.strategy.scalping_market_data import (
    ScalpingMarketDataAdapter,
    ScalpingMarketDataConfig,
    ScalpingMarketDataView,
)

_LOG = logging.getLogger(__name__)
_KLINE_RETRY_SECONDS = 0.2


@dataclass(frozen=True, slots=True)
class BinanceFeedGraphConfig:
    """Hard-bounded resource and freshness settings for one symbol feed graph."""

    intervals: tuple[str, ...] = ("1m", "5m", "15m")
    ws_endpoint: str = BINANCE_UM_MARKET_WS_ENDPOINT
    bootstrap_candles: int = 500
    strategy_candles: int = 500
    snapshot_interval_seconds: float = 0.5
    kline_queue_capacity: int = 1024
    mark_queue_capacity: int = 256
    aggregate_queue_capacity: int = 2048
    depth_queue_capacity: int = 2048
    max_pending_closed_klines: int = 128
    bootstrap_request_pause_seconds: float = 0.25

    def __post_init__(self) -> None:
        intervals = tuple(self.intervals)
        if intervals != ("1m", "5m", "15m"):
            raise ValueError("Feed graph must subscribe to M1, M5 and M15 in canonical order")
        object.__setattr__(self, "intervals", intervals)
        if self.ws_endpoint not in (BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT):
            raise ValueError("Feed graph WebSocket endpoint must be a canonical production or Demo market stream")
        if isinstance(self.bootstrap_candles, bool) or not 20 <= self.bootstrap_candles <= 1000:
            raise ValueError("bootstrap_candles must be between 20 and 1000")
        if isinstance(self.strategy_candles, bool) or not 20 <= self.strategy_candles <= 1000:
            raise ValueError("strategy_candles must be between 20 and 1000")
        if self.strategy_candles < 2:
            raise ValueError("strategy_candles must be at least 2")
        if not 0.1 <= self.snapshot_interval_seconds <= 5:
            raise ValueError("snapshot_interval_seconds must be between 0.1 and 5 seconds")
        for name in (
            "kline_queue_capacity", "mark_queue_capacity", "aggregate_queue_capacity",
            "depth_queue_capacity", "max_pending_closed_klines",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 8192:
                raise ValueError(f"{name} must be between 1 and 8192")
        if not 0 <= self.bootstrap_request_pause_seconds <= 5:
            raise ValueError("bootstrap_request_pause_seconds must be between 0 and 5 seconds")


class BinanceFeedGraphError(RuntimeError):
    """A feed graph could not maintain a complete validated market snapshot."""


class _RestRequestBudget:
    """Serialize history requests across all active pair workers."""

    def __init__(self, client: BinanceUsdMFuturesRestClient, min_interval_seconds: float = 0.12) -> None:
        self._client = client
        self._min_interval = float(min_interval_seconds)
        self._lock = threading.Lock()
        self._last_request = float("-inf")

    def _call(self, method_name: str, **kwargs):
        with self._lock:
            remaining = self._min_interval - (time.monotonic() - self._last_request)
            if remaining > 0:
                time.sleep(remaining)
            self._last_request = time.monotonic()
            return getattr(self._client, method_name)(**kwargs)

    def get_klines(self, **kwargs):
        return self._call("get_klines", **kwargs)

    def get_aggregate_trades(self, **kwargs):
        return self._call("get_aggregate_trades", **kwargs)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


class _SharedDepthSnapshotGate:
    """Pace/serialize depth snapshot REST calls across symbol supervisors."""

    def __init__(self, client: BinanceDepthSnapshotClient, min_interval_seconds: float = 0.2) -> None:
        self._client = client
        self._min_interval = float(min_interval_seconds)
        self._lock = threading.Lock()
        self._last_request = float("-inf")

    def fetch(self, symbol: str):
        with self._lock:
            remaining = self._min_interval - (time.monotonic() - self._last_request)
            if remaining > 0:
                time.sleep(remaining)
            self._last_request = time.monotonic()
            return self._client.fetch(symbol)

    def close(self) -> None:
        self._client.close()


class BinancePublicFeedFactory:
    """Build one isolated public market-data graph for each runtime-selected symbol.

    The factory is compatible with ``MultiPairLiveMarketRuntime.feed_factory``.
    Metadata is pushed by the runtime after every universe refresh so each worker
    uses the exact current ``SymbolInfo``; metadata is never guessed from a ticker.
    """

    def __init__(
        self,
        *,
        rest_client: BinanceUsdMFuturesRestClient,
        database: Database,
        config: BinanceFeedGraphConfig | None = None,
        bootstrap_lock: asyncio.Lock | None = None,
    ) -> None:
        if not isinstance(rest_client, BinanceUsdMFuturesRestClient):
            raise TypeError("rest_client must be BinanceUsdMFuturesRestClient")
        if not isinstance(database, Database):
            raise TypeError("database must be Database")
        self.rest_client = rest_client
        self.database = database
        self.config = config or BinanceFeedGraphConfig()
        self._metadata_by_symbol: dict[str, SymbolInfo] = {}
        self._bootstrap_lock = bootstrap_lock or asyncio.Lock()
        self._aggregate_recovery_gate = asyncio.Semaphore(1)
        self._start_counter = 0
        self._counter_lock = asyncio.Lock()
        self._history_rest = _RestRequestBudget(rest_client, min_interval_seconds=0.12)
        self._depth_snapshot = _SharedDepthSnapshotGate(
            BinanceDepthSnapshotClient(
                base_url=rest_client.base_url, limit=100, min_request_interval_seconds=0.0,
            ),
            min_interval_seconds=0.2,
        )

    def close(self) -> None:
        """Close factory-owned shared HTTP resources after all symbol workers stop."""
        self._depth_snapshot.close()

    def set_metadata(self, snapshot: ExchangeInfoSnapshot) -> None:
        """Update exact metadata used by new per-symbol workers."""
        if not isinstance(snapshot, ExchangeInfoSnapshot):
            raise TypeError("snapshot must be an ExchangeInfoSnapshot")
        self._metadata_by_symbol = {item.symbol: item for item in snapshot.symbols}

    def __call__(self, symbol: str) -> AsyncIterator[ScalpingMarketDataView]:
        normalized = self._normalize_symbol(symbol)
        info = self._metadata_by_symbol.get(normalized)
        if info is None:
            raise BinanceFeedGraphError(f"No current Exchange Information metadata for {normalized}")
        return self._stream_symbol(normalized, info)

    async def _stream_symbol(
        self, symbol: str, symbol_info: SymbolInfo
    ) -> AsyncIterator[ScalpingMarketDataView]:
        # Small deterministic staggering prevents every pair from issuing all
        # bootstrap REST calls in the same event-loop instant.
        async with self._counter_lock:
            start_slot = self._start_counter
            self._start_counter += 1
        if start_slot:
            await asyncio.sleep(min(start_slot * 0.15, 3.0))

        graph = _BinanceSymbolFeedGraph(
            symbol=symbol,
            symbol_info=symbol_info,
            rest_client=self.rest_client,
            history_rest_client=self._history_rest,
            depth_snapshot_client=self._depth_snapshot,
            database=self.database,
            config=self.config,
            bootstrap_lock=self._bootstrap_lock,
            aggregate_recovery_gate=self._aggregate_recovery_gate,
        )
        async with aclosing(graph.stream()) as views:
            async for view in views:
                yield view

    @staticmethod
    def _normalize_symbol(value: str) -> str:
        if not isinstance(value, str):
            raise ValueError("symbol must be a string")
        normalized = value.strip().upper()
        if not normalized or not normalized.isalnum():
            raise ValueError("symbol must be an exact uppercase contract symbol")
        return normalized


class _BinanceSymbolFeedGraph:
    """Own all public data services and their lifecycle for exactly one symbol."""

    def __init__(
        self,
        *,
        symbol: str,
        symbol_info: SymbolInfo,
        rest_client: BinanceUsdMFuturesRestClient,
        history_rest_client,
        depth_snapshot_client,
        database: Database,
        config: BinanceFeedGraphConfig,
        bootstrap_lock: asyncio.Lock,
        aggregate_recovery_gate: asyncio.Semaphore | None = None,
    ) -> None:
        self.symbol = symbol
        self.symbol_info = symbol_info
        self.rest = rest_client
        self.history_rest = history_rest_client
        self.depth_snapshot = depth_snapshot_client
        self.db = database
        self.config = config
        self.bootstrap_lock = bootstrap_lock
        self.now_ms: Callable[[], int] = lambda: time.time_ns() // 1_000_000

        self.kline_repository = KlineRepository(database)
        self.kline_history = HistoricalKlineService(
            self.history_rest, page_limit=min(499, config.bootstrap_candles),
            max_pages=3, min_request_interval_seconds=config.bootstrap_request_pause_seconds,
        )
        self.kline_recovery = KlineRecoveryService(
            self.kline_history, self.kline_repository,
            max_pages_per_recovery=min(20, self.kline_history.max_pages),
        )
        self.kline_feed = BinanceKlineWebSocketFeed(
            symbols=(symbol,), intervals=config.intervals, max_subscriptions=3,
            queue_capacity=config.kline_queue_capacity, endpoint=config.ws_endpoint,
        )
        self.mark_feed = BinanceMarkPriceWebSocketFeed(
            symbols=(symbol,), update_speed="1s", max_subscriptions=1,
            queue_capacity=config.mark_queue_capacity, endpoint=config.ws_endpoint,
        )

        self.aggregate_repository = AggregateTradeRepository(database)
        self.order_flow_repository = OrderFlowRepository(database)
        self.aggregate_history = BinanceAggregateTradeHistoryService(
            self.history_rest, page_limit=1000, max_pages_per_pass=3, page_pause_seconds=0.2,
        )
        self.aggregate_recovery = AggregateTradeRecoveryService(
            self.aggregate_history, self.aggregate_repository,
        )
        self.aggregate_feed = BinanceAggregateTradeWebSocketFeed(
            symbols=(symbol,), max_subscriptions=1,
            queue_capacity=config.aggregate_queue_capacity, endpoint=config.ws_endpoint,
        )
        depth_endpoint = (BINANCE_UM_DEMO_DEPTH_WS_ENDPOINT
                          if config.ws_endpoint == BINANCE_UM_DEMO_MARKET_WS_ENDPOINT
                          else BINANCE_UM_DEPTH_WS_ENDPOINT)
        self.depth_feed = BinanceDepthWebSocketFeed(
            symbols=(symbol,), update_speed="100ms", max_subscriptions=1,
            queue_capacity=config.depth_queue_capacity, endpoint=depth_endpoint,
        )
        self.depth_supervisor = BinanceOrderBookSupervisor(
            feed=self.depth_feed, snapshot_client=self.depth_snapshot,
            max_buffered_events=min(2048, config.depth_queue_capacity),
            max_levels=100, depth_levels=20,
        )
        self.delta_cvd = DeltaCvdService(
            self.aggregate_repository, self.order_flow_repository,
            bucket_intervals=("1s", "5s", "15s", "1m", "5m"),
            max_data_age_ms=10_000,
        )
        self.absorption = DepthAggressorAlignmentService()
        self.market_orchestrator = UnifiedMarketDataOrchestrator(
            aggregate_feed=self.aggregate_feed,
            aggregate_recovery=self.aggregate_recovery,
            delta_cvd=self.delta_cvd,
            order_book_supervisor=self.depth_supervisor,
            evidence_service=self.absorption,
            aggregate_recovery_gate=aggregate_recovery_gate,
            config=MarketDataOrchestratorConfig(
                event_queue_capacity=2048, startup_timeout_seconds=30,
                bootstrap_limit=1000, maintenance_interval_ms=500,
                recovery_retry_interval_ms=1500, flow_interval="1s",
                flow_lookback_buckets=5, process_max_passes=2,
                records_per_pass=1000,
            ),
        )
        self.adapter = ScalpingMarketDataAdapter(
            config=ScalpingMarketDataConfig(
                max_candles_per_interval=config.strategy_candles,
                max_kline_age_intervals=2,
                max_mark_price_age_ms=10_000,
                max_flow_age_ms=10_000,
                max_depth_age_ms=5_000,
                max_orchestrator_age_ms=2_000,
            )
        )
        self.stop_event = asyncio.Event()
        self.wake_event = asyncio.Event()
        self.latest_mark_price: MarkPriceEvent | None = None
        self.forming_klines: dict[str, MarketKlineEvent] = {}
        self.pending_closed: dict[str, deque[MarketKlineEvent]] = {
            interval: deque() for interval in config.intervals
        }
        self._last_kline_connection_generation = 0
        self._last_emitted_key: tuple[int, int, int, int, int] | None = None
        self._tasks: list[asyncio.Task] = []
        self._last_pending_warning_ms = 0

    async def stream(self) -> AsyncIterator[ScalpingMarketDataView]:
        await self._bootstrap_klines()
        self._tasks = [
            asyncio.create_task(self.kline_feed.run(self.stop_event), name=f"kline-feed:{self.symbol}"),
            asyncio.create_task(self._consume_klines(), name=f"kline-consumer:{self.symbol}"),
            asyncio.create_task(self.mark_feed.run(self.stop_event), name=f"mark-feed:{self.symbol}"),
            asyncio.create_task(self._consume_mark_price(), name=f"mark-consumer:{self.symbol}"),
            asyncio.create_task(
                # The orchestrator sets its own stop flag on failure. Keep the
                # outer stream polling so that failure is raised to the worker.
                self.market_orchestrator.run(asyncio.Event()), name=f"market-orchestrator:{self.symbol}"
            ),
        ]
        try:
            while not self.stop_event.is_set():
                for task in self._tasks:
                    if task.done() and not self.stop_event.is_set():
                        error = task.exception() if not task.cancelled() else None
                        raise BinanceFeedGraphError(
                            f"{task.get_name()} terminated unexpectedly"
                        ) from error
                try:
                    await asyncio.wait_for(
                        self.wake_event.wait(), timeout=self.config.snapshot_interval_seconds
                    )
                except asyncio.TimeoutError:
                    pass
                self.wake_event.clear()
                view = await self._build_complete_view()
                if view is None:
                    continue
                key = self._capture_key(view)
                if key == self._last_emitted_key:
                    continue
                self._last_emitted_key = key
                yield view
        finally:
            self.stop_event.set()
            for task in self._tasks:
                if not task.done():
                    task.cancel()
            if self._tasks:
                await asyncio.gather(*self._tasks, return_exceptions=True)

    async def _bootstrap_klines(self) -> None:
        """Seed each interval with real, closed REST candles before live readiness."""
        async with self.bootstrap_lock:
            now = self.now_ms()
            for interval in self.config.intervals:
                duration = INTERVAL_MILLISECONDS[interval]
                target_open = (now // duration) * duration - duration
                start_open = target_open - (self.config.bootstrap_candles - 1) * duration
                batch = await asyncio.to_thread(
                    self.kline_history.fetch,
                    symbol=self.symbol,
                    interval=interval,
                    start_time_ms=start_open,
                    end_time_ms=target_open + duration - 1,
                )
                if not batch.candles:
                    raise BinanceFeedGraphError(f"No bootstrap Klines returned for {self.symbol} {interval}")
                # Store only source candles returned by Binance. A detected gap is
                # retained as a gap and repaired by KlineRecoveryService after WS
                # connection; this path never synthesizes a candle.
                await asyncio.to_thread(self.kline_repository.upsert_many, batch.candles)
                self.kline_recovery.register_stream(
                    symbol=self.symbol,
                    interval=interval,
                    bootstrap_start_open_time_ms=batch.candles[0].open_time_ms,
                )
                if not batch.complete:
                    _LOG.warning(
                        "%s %s bootstrap is paginated/incomplete (%s candles); recovery gate remains closed",
                        self.symbol, interval, len(batch.candles),
                    )

    async def _consume_klines(self) -> None:
        next_retry = 0.0
        while not self.stop_event.is_set():
            try:
                event = await asyncio.wait_for(self.kline_feed.get_event(), timeout=_KLINE_RETRY_SECONDS)
            except asyncio.TimeoutError:
                event = None
            self.kline_recovery.observe_websocket_feed(self.kline_feed)
            connection_generation = self.kline_feed.stats.connection_count
            if self.kline_feed.is_connected and connection_generation != self._last_kline_connection_generation:
                self._last_kline_connection_generation = connection_generation
                await self._recover_all_intervals()
            if event is not None:
                if event.kline.symbol != self.symbol:
                    raise BinanceFeedGraphError("Kline WebSocket emitted a different symbol")
                interval = event.kline.interval
                if event.is_closed:
                    pending = self.pending_closed[interval]
                    if len(pending) >= self.config.max_pending_closed_klines:
                        raise BinanceFeedGraphError(
                            f"Closed Kline retry queue exceeded for {self.symbol} {interval}; fail closed"
                        )
                    pending.append(event)
                    self.forming_klines.pop(interval, None)
                else:
                    self.forming_klines[interval] = event
                self.wake_event.set()
            if time.monotonic() >= next_retry:
                await self._retry_pending_closed()
                next_retry = time.monotonic() + _KLINE_RETRY_SECONDS

    async def _recover_all_intervals(self) -> None:
        now = self.now_ms()
        for interval in self.config.intervals:
            duration = INTERVAL_MILLISECONDS[interval]
            target_open = (now // duration) * duration - duration
            try:
                await asyncio.to_thread(
                    self.kline_recovery.recover_stream,
                    symbol=self.symbol,
                    interval=interval,
                    target_end_open_time_ms=target_open,
                )
            except Exception as exc:
                _LOG.warning("Kline recovery degraded %s %s: %s", self.symbol, interval, exc)
        self.wake_event.set()

    async def _retry_pending_closed(self) -> None:
        for interval in self.config.intervals:
            await self._retry_pending_interval(interval)

    async def _retry_pending_interval(self, interval: str) -> None:
        pending = self.pending_closed[interval]
        while pending and not self.stop_event.is_set():
            event = pending[0]
            try:
                self.kline_recovery.observe_websocket_feed(self.kline_feed)
                await asyncio.to_thread(self.kline_recovery.ingest_websocket_event, event)
            except Exception as exc:
                if self.now_ms() - self._last_pending_warning_ms > 1000:
                    _LOG.warning(
                        "Closed Kline remains pending %s %s open=%s: %s",
                        self.symbol, interval, event.kline.open_time_ms, exc,
                    )
                    self._last_pending_warning_ms = self.now_ms()
                break
            pending.popleft()
            _LOG.debug("Closed Kline persisted %s %s open=%s", self.symbol, interval, event.kline.open_time_ms)
            self.wake_event.set()

    async def _consume_mark_price(self) -> None:
        while not self.stop_event.is_set():
            try:
                event = await asyncio.wait_for(self.mark_feed.get_event(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            if event.symbol != self.symbol:
                raise BinanceFeedGraphError("Mark Price WebSocket emitted a different symbol")
            self.latest_mark_price = event
            self.wake_event.set()

    async def _build_complete_view(self) -> ScalpingMarketDataView | None:
        if not self.kline_feed.is_connected or not self.mark_feed.is_connected:
            return None
        if self.latest_mark_price is None:
            return None
        if not self.market_orchestrator.is_running:
            return None
        if self.now_ms() - self.latest_mark_price.event_time_ms > 10_000:
            return None

        series: list[KlineSeriesInput] = []
        for interval in self.config.intervals:
            if (self.pending_closed[interval]
                    or self.kline_recovery.stream_health(symbol=self.symbol, interval=interval) is not FeedHealth.HEALTHY):
                # Missing M15 context or one setup timeframe is not a global veto.
                # Omit it; the adapter explicitly marks that timeframe unready.
                continue
            stored = await asyncio.to_thread(
                self.kline_repository.read_tail,
                symbol=self.symbol,
                interval=interval,
                limit=self.config.strategy_candles,
            )
            candles = tuple(item.kline for item in stored)
            if len(candles) < 2:
                continue
            series.append(
                KlineSeriesInput(
                    symbol=self.symbol,
                    interval=interval,
                    candles=candles,
                    source_observed_at_ms=self.now_ms(),
                    source_healthy=True,
                    source_complete=True,
                    missing_open_times_ms=(),
                    forming_event=self.forming_klines.get(interval),
                )
            )
        # Feed state can change while the database reads yield to the event loop.
        mark_price = self.latest_mark_price
        if (mark_price is None or not self.kline_feed.is_connected or not self.mark_feed.is_connected
                or not self.market_orchestrator.is_running):
            return None
        readiness, order_book_metrics = self._capture_depth_state(self.market_orchestrator.health(self.symbol))
        now = self.now_ms()
        if now - mark_price.event_time_ms > 10_000:
            return None
        view = self.adapter.build_view(
            symbol=self.symbol,
            now_ms=now,
            symbol_info=self.symbol_info,
            kline_series=tuple(item for item in series if not self.pending_closed[item.interval]),
            mark_price=mark_price,
            mark_price_connected=self.mark_feed.is_connected,
            readiness=readiness,
            order_book_metrics=order_book_metrics,
        )
        if view.status != "READY" or not view.readiness.can_scan_setups:
            return None
        # Mark is currently used for provisional entry geometry. A stale mark
        # is never permitted as an entry reference; optional flow/depth isn't
        # allowed to block otherwise valid structure analysis.
        if not view.readiness.mark_price_available:
            return None
        return view

    def _capture_depth_state(self, readiness: MarketDataReadiness) -> tuple[MarketDataReadiness, OrderBookMetrics | None]:
        # The cached orchestrator health may refer to an earlier depth update.
        # Read both parts from the live supervisor in the same event-loop turn.
        generation = max(0, self.depth_feed.stats.connection_count - 1)
        health = None
        metrics = None
        if generation == readiness.depth_reconnect_generation:
            try:
                health = self.depth_supervisor.health(self.symbol)
                if health.ready:
                    current_metrics = self.depth_supervisor.metrics(self.symbol)
                    if current_metrics.update_id == health.update_id:
                        metrics = current_metrics
            except Exception:
                # DEPTH remains optional for structure scans.
                pass
        projected = replace(readiness, order_book_ready=metrics is not None, order_book_health=health)
        if metrics is None and projected.evidence is not None:
            projected = replace(projected, evidence=None, evidence_status="UNAVAILABLE")
        return projected, metrics

    @staticmethod
    def _capture_key(view: ScalpingMarketDataView) -> tuple[int, ...]:
        flow = view.flow
        sources = view.orchestrator_readiness
        return (
            view.m1.latest_closed_candle.open_time_ms if view.m1.latest_closed_candle else -1,
            view.m5.latest_closed_candle.open_time_ms if view.m5.latest_closed_candle else -1,
            view.m15.latest_closed_candle.open_time_ms if view.m15.latest_closed_candle else -1,
            view.mark_price.event_time_ms if view.mark_price else -1,
            view.order_book_metrics.update_id if view.order_book_metrics else -1,
            flow.last_processed_aggregate_trade_id if flow else -1,
            flow.window_end_ms if flow else -1,
            sources.aggregate_trade_reconnect_generation if sources else -1,
            sources.depth_reconnect_generation if sources else -1,
            int(view.readiness.entry_quote_ready),
            int(view.readiness.delta_cvd_available),
        )
