"""SQLite storage and contiguous-ID state for Binance aggregate trades."""

from __future__ import annotations

from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from itertools import islice
from typing import Iterable

from divatrading.core.database import Database, utc_now_iso
from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord

MAX_AGG_TRADE_READ_LIMIT = 5_000
MAX_AGG_TRADE_WRITE_BATCH = 5_000
MAX_CONTIGUOUS_SCAN = 10_000
MAX_RETAINED_AGG_TRADES_PER_SYMBOL = 2_000_000


class AggregateTradeStorageError(ValueError):
    """Raised when an aggregate-trade storage contract is violated."""


class AggregateTradeIdentityConflict(AggregateTradeStorageError):
    """Raised when the same aggregate ID is returned with a different immutable payload."""


class AggregateTradeStreamStateError(AggregateTradeStorageError):
    """Raised when stream state is missing or would be reset unsafely."""


@dataclass(frozen=True, slots=True)
class StoredAggregateTrade:
    record: AggregateTradeRecord
    first_seen_at_utc: str
    last_seen_at_utc: str


@dataclass(frozen=True, slots=True)
class AggregateTradeStreamState:
    exchange: str
    symbol: str
    last_contiguous_aggregate_trade_id: int
    last_contiguous_trade_time_ms: int | None
    latest_observed_aggregate_trade_id: int
    latest_observed_trade_time_ms: int | None
    status: str
    unresolved_gap_from_id: int | None
    unresolved_gap_to_id: int | None
    updated_at_utc: str


class AggregateTradeRepository:
    """Persist immutable aggTrade identities and a durable contiguous-ID cursor."""

    def __init__(self, database: Database) -> None:
        self.database = database

    @staticmethod
    def _utc(value: str, name: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise AggregateTradeStorageError(f"{name} must be a non-empty ISO-8601 timestamp")
        raw = value.strip()
        normalized = raw[:-1] + "+00:00" if raw.endswith("Z") else raw
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError as exc:
            raise AggregateTradeStorageError(f"{name} must be a valid ISO-8601 timestamp") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None or parsed.utcoffset().total_seconds() != 0:
            raise AggregateTradeStorageError(f"{name} must use UTC timezone")
        return parsed.astimezone(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    @staticmethod
    def _validate(record: AggregateTradeRecord) -> None:
        if not isinstance(record, AggregateTradeRecord):
            raise AggregateTradeStorageError("Only AggregateTradeRecord instances can be stored")
        if record.exchange != "BINANCE_UM":
            raise AggregateTradeStorageError("Only BINANCE_UM aggregate trades are supported")
        if not record.symbol or record.symbol != record.symbol.strip().upper() or not record.symbol.isalnum():
            raise AggregateTradeStorageError("symbol must be an exact uppercase Binance contract symbol")
        if isinstance(record.aggregate_trade_id, bool) or not isinstance(record.aggregate_trade_id, int) or record.aggregate_trade_id < 0:
            raise AggregateTradeStorageError("aggregate_trade_id must be a non-negative integer")
        if not isinstance(record.price, Decimal) or not record.price.is_finite() or record.price <= 0:
            raise AggregateTradeStorageError("price must be a positive finite Decimal")
        if not isinstance(record.quantity, Decimal) or not record.quantity.is_finite() or record.quantity <= 0:
            raise AggregateTradeStorageError("quantity must be a positive finite Decimal")
        if record.normal_quantity is not None:
            if not isinstance(record.normal_quantity, Decimal) or not record.normal_quantity.is_finite():
                raise AggregateTradeStorageError("normal_quantity must be a finite Decimal")
            if record.normal_quantity < 0 or record.normal_quantity > record.quantity:
                raise AggregateTradeStorageError("normal_quantity must be between zero and quantity")
        for name, value in (("first_trade_id", record.first_trade_id), ("last_trade_id", record.last_trade_id), ("trade_time_ms", record.trade_time_ms)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise AggregateTradeStorageError(f"{name} must be a non-negative integer")
        if record.trade_time_ms <= 0:
            raise AggregateTradeStorageError("trade_time_ms must be positive")
        if record.last_trade_id < record.first_trade_id:
            raise AggregateTradeStorageError("last_trade_id cannot be lower than first_trade_id")
        if record.event_time_ms is not None and (
            isinstance(record.event_time_ms, bool)
            or not isinstance(record.event_time_ms, int)
            or record.event_time_ms <= 0
        ):
            raise AggregateTradeStorageError("event_time_ms must be positive or None")
        if not isinstance(record.buyer_is_maker, bool):
            raise AggregateTradeStorageError("buyer_is_maker must be boolean")
        if record.source_kind not in {"REST", "WEBSOCKET"}:
            raise AggregateTradeStorageError("source_kind must be REST or WEBSOCKET")
        if not isinstance(record.source_endpoint, str) or not record.source_endpoint.strip():
            raise AggregateTradeStorageError("source_endpoint cannot be empty")
        AggregateTradeRepository._utc(record.received_at_utc, "received_at_utc")

    @staticmethod
    def _upsert_one(connection, record: AggregateTradeRecord, received_at: str) -> bool:
        key = (record.exchange, record.symbol, record.aggregate_trade_id)
        existing = connection.execute(
            """SELECT price, quantity, first_trade_id, last_trade_id, trade_time_ms, buyer_is_maker,
                      normal_quantity, event_time_ms
               FROM aggregate_trades WHERE exchange=? AND symbol=? AND aggregate_trade_id=?""",
            key,
        ).fetchone()
        if existing is None:
            connection.execute(
                """INSERT INTO aggregate_trades(
                    exchange, symbol, aggregate_trade_id, price, quantity, normal_quantity,
                    first_trade_id, last_trade_id, event_time_ms, trade_time_ms, buyer_is_maker,
                    first_source_kind, last_source_kind, first_source_endpoint, last_source_endpoint,
                    first_seen_at_utc, last_seen_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record.exchange,
                    record.symbol,
                    record.aggregate_trade_id,
                    str(record.price),
                    str(record.quantity),
                    str(record.normal_quantity) if record.normal_quantity is not None else None,
                    record.first_trade_id,
                    record.last_trade_id,
                    record.event_time_ms,
                    record.trade_time_ms,
                    int(record.buyer_is_maker),
                    record.source_kind,
                    record.source_kind,
                    record.source_endpoint,
                    record.source_endpoint,
                    received_at,
                    received_at,
                ),
            )
            return True

        immutable = (
            Decimal(existing["price"]) == record.price
            and Decimal(existing["quantity"]) == record.quantity
            and existing["first_trade_id"] == record.first_trade_id
            and existing["last_trade_id"] == record.last_trade_id
            and existing["trade_time_ms"] == record.trade_time_ms
            and existing["buyer_is_maker"] == int(record.buyer_is_maker)
        )
        if not immutable:
            raise AggregateTradeIdentityConflict(
                f"Aggregate trade {record.symbol}#{record.aggregate_trade_id} conflicts with stored immutable data"
            )
        if (
            existing["normal_quantity"] is not None
            and record.normal_quantity is not None
            and Decimal(existing["normal_quantity"]) != record.normal_quantity
        ):
            raise AggregateTradeIdentityConflict(
                f"Aggregate trade {record.symbol}#{record.aggregate_trade_id} has conflicting normal_quantity"
            )
        if (
            existing["event_time_ms"] is not None
            and record.event_time_ms is not None
            and existing["event_time_ms"] != record.event_time_ms
        ):
            raise AggregateTradeIdentityConflict(
                f"Aggregate trade {record.symbol}#{record.aggregate_trade_id} has conflicting event_time_ms"
            )
        connection.execute(
            """UPDATE aggregate_trades SET
                   normal_quantity=COALESCE(normal_quantity, ?),
                   event_time_ms=COALESCE(event_time_ms, ?),
                   last_source_kind=?, last_source_endpoint=?, last_seen_at_utc=?
               WHERE exchange=? AND symbol=? AND aggregate_trade_id=?""",
            (
                str(record.normal_quantity) if record.normal_quantity is not None else None,
                record.event_time_ms,
                record.source_kind,
                record.source_endpoint,
                received_at,
                *key,
            ),
        )
        return False

    def upsert_many(self, records: Iterable[AggregateTradeRecord]) -> int:
        rows = list(records)
        if not rows:
            return 0
        if len(rows) > MAX_AGG_TRADE_WRITE_BATCH:
            raise AggregateTradeStorageError(
                f"A write batch cannot exceed {MAX_AGG_TRADE_WRITE_BATCH} records"
            )
        for record in rows:
            self._validate(record)
        if len({(r.exchange, r.symbol) for r in rows}) != 1:
            raise AggregateTradeStorageError("A write batch must contain one exchange/symbol stream")
        inserted = 0
        with self.database.transaction() as connection:
            for record in rows:
                received_at = self._utc(record.received_at_utc, "received_at_utc")
                inserted += int(self._upsert_one(connection, record, received_at))
        return inserted

    def bootstrap_latest(self, records: Iterable[AggregateTradeRecord]) -> AggregateTradeStreamState:
        """Create a new baseline from a validated contiguous recent REST page.

        The first returned ID is an intentional history boundary; earlier IDs are
        not represented as a recoverable gap.
        """
        rows = list(records)
        if not rows:
            raise AggregateTradeStreamStateError("Cannot bootstrap from an empty aggregate-trade page")
        if len(rows) > MAX_AGG_TRADE_WRITE_BATCH:
            raise AggregateTradeStorageError("Bootstrap batch exceeds bounded write capacity")
        for record in rows:
            self._validate(record)
        symbol = rows[0].symbol
        if any(r.symbol != symbol or r.exchange != "BINANCE_UM" for r in rows):
            raise AggregateTradeStorageError("Bootstrap records must belong to one BINANCE_UM symbol")
        ids = [r.aggregate_trade_id for r in rows]
        if ids != list(range(ids[0], ids[-1] + 1)):
            raise AggregateTradeStorageError("Bootstrap records must have contiguous ascending aggregate IDs")

        now = utc_now_iso()
        with self.database.transaction() as connection:
            exists = connection.execute(
                "SELECT 1 FROM aggregate_trade_stream_state WHERE exchange='BINANCE_UM' AND symbol=?",
                (symbol,),
            ).fetchone()
            if exists:
                raise AggregateTradeStreamStateError(
                    f"Stream {symbol} already has durable state; bootstrap cannot reset its cursor"
                )
            for record in rows:
                self._upsert_one(
                    connection, record, self._utc(record.received_at_utc, "received_at_utc")
                )
            connection.execute(
                """INSERT INTO aggregate_trade_stream_state(
                    exchange, symbol, last_contiguous_aggregate_trade_id,
                    last_contiguous_trade_time_ms, latest_observed_aggregate_trade_id,
                    latest_observed_trade_time_ms, status, unresolved_gap_from_id,
                    unresolved_gap_to_id, updated_at_utc
                ) VALUES ('BINANCE_UM', ?, ?, ?, ?, ?, 'HEALTHY', NULL, NULL, ?)""",
                (symbol, ids[-1], rows[-1].trade_time_ms, ids[-1], rows[-1].trade_time_ms, now),
            )
        return self.get_stream_state(symbol)

    def register_from_id(self, *, symbol: str, start_from_id: int) -> AggregateTradeStreamState:
        """Register an explicit inclusive starting ID without inventing a baseline."""
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized or not normalized.isalnum():
            raise AggregateTradeStorageError("symbol must be an exact Binance contract symbol")
        if isinstance(start_from_id, bool) or not isinstance(start_from_id, int) or start_from_id < 0:
            raise AggregateTradeStorageError("start_from_id must be a non-negative integer")
        now = utc_now_iso()
        with self.database.transaction() as connection:
            connection.execute(
                """INSERT INTO aggregate_trade_stream_state(
                    exchange, symbol, last_contiguous_aggregate_trade_id,
                    last_contiguous_trade_time_ms, latest_observed_aggregate_trade_id,
                    latest_observed_trade_time_ms, status, unresolved_gap_from_id,
                    unresolved_gap_to_id, updated_at_utc
                ) VALUES ('BINANCE_UM', ?, ?, NULL, ?, NULL, 'BOOTSTRAPPING', NULL, NULL, ?) 
                ON CONFLICT(exchange, symbol) DO NOTHING""",
                (normalized, start_from_id - 1, start_from_id - 1, now),
            )
            row = connection.execute(
                "SELECT last_contiguous_aggregate_trade_id FROM aggregate_trade_stream_state WHERE exchange='BINANCE_UM' AND symbol=?",
                (normalized,),
            ).fetchone()
            if row["last_contiguous_aggregate_trade_id"] != start_from_id - 1:
                raise AggregateTradeStreamStateError("Existing stream state has a different cursor")
        return self.get_stream_state(normalized)

    def record_observed(self, record: AggregateTradeRecord) -> AggregateTradeStreamState:
        """Persist one WebSocket event and update durable continuity state."""
        return self.record_observed_many((record,))

    def record_observed_many(self, records: Iterable[AggregateTradeRecord]) -> AggregateTradeStreamState:
        """Persist one symbol's WebSocket events in receive order in a single transaction."""
        rows = list(islice(records, MAX_AGG_TRADE_WRITE_BATCH + 1))
        if not rows:
            raise AggregateTradeStorageError("A WebSocket batch must contain at least one record")
        if len(rows) > MAX_AGG_TRADE_WRITE_BATCH:
            raise AggregateTradeStorageError(
                f"A WebSocket batch cannot exceed {MAX_AGG_TRADE_WRITE_BATCH} records"
            )
        for record in rows:
            self._validate(record)
            if record.source_kind != "WEBSOCKET":
                raise AggregateTradeStorageError("record_observed accepts WebSocket records only")
        exchange, symbol = rows[0].exchange, rows[0].symbol
        if any((record.exchange, record.symbol) != (exchange, symbol) for record in rows):
            raise AggregateTradeStorageError("A WebSocket batch must contain one exchange/symbol stream")

        with self.database.transaction() as connection:
            if (
                1 < len(rows) <= MAX_CONTIGUOUS_SCAN
                and self._is_unseen_contiguous_batch(connection, exchange, symbol, rows)
            ):
                for record in rows:
                    received_at = self._utc(record.received_at_utc, "received_at_utc")
                    self._upsert_one(connection, record, received_at)
                last_record = rows[-1]
                connection.execute(
                    """UPDATE aggregate_trade_stream_state SET
                           latest_observed_aggregate_trade_id=?, latest_observed_trade_time_ms=?
                       WHERE exchange=? AND symbol=?""",
                    (last_record.aggregate_trade_id, last_record.trade_time_ms, exchange, symbol),
                )
                self._advance_in_transaction(connection, exchange, symbol)
            else:
                for record in rows:
                    received_at = self._utc(record.received_at_utc, "received_at_utc")
                    self._record_observed_in_transaction(connection, record, received_at)
            return self._read_stream_state(connection, exchange, symbol)

    @staticmethod
    def _is_unseen_contiguous_batch(
        connection, exchange: str, symbol: str, rows: list[AggregateTradeRecord]
    ) -> bool:
        state = connection.execute(
            """SELECT last_contiguous_aggregate_trade_id, latest_observed_aggregate_trade_id, status
               FROM aggregate_trade_stream_state WHERE exchange=? AND symbol=?""",
            (exchange, symbol),
        ).fetchone()
        if state is None or state["status"] != "HEALTHY":
            return False
        cursor = int(state["last_contiguous_aggregate_trade_id"])
        if cursor != state["latest_observed_aggregate_trade_id"] or any(
            record.aggregate_trade_id != expected_id
            for expected_id, record in enumerate(rows, start=cursor + 1)
        ):
            return False

        # REST recovery can stage rows before advancing its state. Keep the
        # per-event transitions whenever existing rows could affect the cursor.
        return connection.execute(
            """SELECT 1 FROM aggregate_trades WHERE exchange=? AND symbol=?
                 AND aggregate_trade_id>? LIMIT 1""",
            (exchange, symbol, cursor),
        ).fetchone() is None

    def _record_observed_in_transaction(self, connection, record: AggregateTradeRecord, now: str) -> None:
        state = connection.execute(
            "SELECT * FROM aggregate_trade_stream_state WHERE exchange=? AND symbol=?",
            (record.exchange, record.symbol),
        ).fetchone()
        if state is None:
            raise AggregateTradeStreamStateError(
                f"Stream {record.symbol} must be bootstrapped or registered before WebSocket ingestion"
            )
        self._upsert_one(connection, record, now)
        cursor = int(state["last_contiguous_aggregate_trade_id"])
        latest = max(int(state["latest_observed_aggregate_trade_id"]), record.aggregate_trade_id)
        latest_trade_time = state["latest_observed_trade_time_ms"]
        if record.aggregate_trade_id >= int(state["latest_observed_aggregate_trade_id"]):
            latest_trade_time = record.trade_time_ms

        if record.aggregate_trade_id > cursor + 1:
            open_gap = connection.execute(
                """SELECT id, expected_from_id FROM aggregate_trade_gaps
                   WHERE exchange=? AND symbol=? AND status='OPEN' ORDER BY id DESC LIMIT 1""",
                (record.exchange, record.symbol),
            ).fetchone()
            if open_gap is None:
                connection.execute(
                    """INSERT INTO aggregate_trade_gaps(
                        exchange, symbol, expected_from_id, observed_id, status, reason,
                        detected_at_utc, resolved_at_utc
                    ) VALUES (?, ?, ?, ?, 'OPEN', ?, ?, NULL)""",
                    (
                        record.exchange,
                        record.symbol,
                        cursor + 1,
                        record.aggregate_trade_id,
                        f"WebSocket observed aggregate ID {record.aggregate_trade_id} while expecting {cursor + 1}",
                        now,
                    ),
                )
            else:
                connection.execute(
                    "UPDATE aggregate_trade_gaps SET observed_id=MAX(observed_id, ?) WHERE id=?",
                    (record.aggregate_trade_id, open_gap["id"]),
                )
        connection.execute(
            """UPDATE aggregate_trade_stream_state SET
                   latest_observed_aggregate_trade_id=?, latest_observed_trade_time_ms=?,
                   status=CASE WHEN status='UNRESOLVED' THEN status ELSE 'DEGRADED' END,
                   unresolved_gap_from_id=CASE WHEN status='UNRESOLVED' THEN unresolved_gap_from_id
                                               WHEN ?>last_contiguous_aggregate_trade_id+1 THEN last_contiguous_aggregate_trade_id+1 ELSE NULL END,
                   unresolved_gap_to_id=CASE WHEN status='UNRESOLVED' THEN unresolved_gap_to_id
                                             WHEN ?>last_contiguous_aggregate_trade_id+1 THEN ?-1 ELSE NULL END,
                   updated_at_utc=?
               WHERE exchange=? AND symbol=?""",
            (
                latest,
                latest_trade_time,
                latest,
                latest,
                latest,
                now,
                record.exchange,
                record.symbol,
            ),
        )
        self._advance_in_transaction(connection, record.exchange, record.symbol)

    def persist_recovered(self, records: Iterable[AggregateTradeRecord], *, symbol: str) -> AggregateTradeStreamState:
        rows = list(records)
        if rows:
            if any(r.symbol != symbol or r.source_kind != "REST" for r in rows):
                raise AggregateTradeStorageError("Recovered rows must be REST records for the requested symbol")
            self.upsert_many(rows)
        with self.database.transaction() as connection:
            if rows:
                latest_record = max(rows, key=lambda item: item.aggregate_trade_id)
                connection.execute(
                    """UPDATE aggregate_trade_stream_state SET
                           latest_observed_aggregate_trade_id=MAX(latest_observed_aggregate_trade_id, ?),
                           latest_observed_trade_time_ms=CASE
                               WHEN ?>=latest_observed_aggregate_trade_id THEN ?
                               ELSE latest_observed_trade_time_ms END,
                           updated_at_utc=?
                       WHERE exchange='BINANCE_UM' AND symbol=?""",
                    (latest_record.aggregate_trade_id, latest_record.aggregate_trade_id,
                     latest_record.trade_time_ms, utc_now_iso(), symbol),
                )
            self._advance_in_transaction(connection, "BINANCE_UM", symbol)
        return self.get_stream_state(symbol)

    @staticmethod
    def _advance_in_transaction(connection, exchange: str, symbol: str) -> None:
        state = connection.execute(
            "SELECT * FROM aggregate_trade_stream_state WHERE exchange=? AND symbol=?",
            (exchange, symbol),
        ).fetchone()
        if state is None:
            raise AggregateTradeStreamStateError(f"No registered stream state for {symbol}")
        cursor = int(state["last_contiguous_aggregate_trade_id"])
        latest = int(state["latest_observed_aggregate_trade_id"])
        trade_time = state["last_contiguous_trade_time_ms"]
        with closing(connection.execute(
            """SELECT aggregate_trade_id, trade_time_ms FROM aggregate_trades
               WHERE exchange=? AND symbol=? AND aggregate_trade_id>?
               ORDER BY aggregate_trade_id ASC LIMIT ?""",
            (exchange, symbol, cursor, MAX_CONTIGUOUS_SCAN),
        )) as rows:
            for row in rows:
                aggregate_id = int(row["aggregate_trade_id"])
                if aggregate_id != cursor + 1:
                    break
                cursor = aggregate_id
                trade_time = int(row["trade_time_ms"])
        new_status = state["status"]
        gap_from = state["unresolved_gap_from_id"]
        gap_to = state["unresolved_gap_to_id"]
        if new_status != "UNRESOLVED":
            if cursor >= latest:
                new_status = "HEALTHY"
                gap_from = None
                gap_to = None
                connection.execute(
                    """UPDATE aggregate_trade_gaps SET status='RESOLVED', resolved_at_utc=?
                       WHERE exchange=? AND symbol=? AND status='OPEN'""",
                    (utc_now_iso(), exchange, symbol),
                )
            else:
                new_status = "DEGRADED"
                gap_from = cursor + 1
                gap_to = max(gap_from, latest - 1)
        connection.execute(
            """UPDATE aggregate_trade_stream_state SET
                   last_contiguous_aggregate_trade_id=?, last_contiguous_trade_time_ms=?,
                   status=?, unresolved_gap_from_id=?, unresolved_gap_to_id=?, updated_at_utc=?
               WHERE exchange=? AND symbol=?""",
            (cursor, trade_time, new_status, gap_from, gap_to, utc_now_iso(), exchange, symbol),
        )

    def mark_unresolved(
        self, *, symbol: str, status: str, reason: str, expected_missing_id: int | None = None,
    ) -> AggregateTradeStreamState:
        """Mark the current gap unresolved, optionally matching a REST request's missing ID."""
        if status not in {"UNRESOLVED", "UNRESOLVED_RETENTION", "UNRESOLVED_HISTORY"}:
            raise ValueError("Unsupported unresolved status")
        if expected_missing_id is not None and (type(expected_missing_id) is not int or expected_missing_id < 0):
            raise ValueError("expected_missing_id must be a non-negative integer or None")
        with self.database.transaction() as connection:
            state = connection.execute(
                "SELECT * FROM aggregate_trade_stream_state WHERE exchange='BINANCE_UM' AND symbol=?",
                (symbol,),
            ).fetchone()
            if state is None:
                raise AggregateTradeStreamStateError(f"No registered stream state for {symbol}")
            expected = int(state["last_contiguous_aggregate_trade_id"]) + 1
            latest = int(state["latest_observed_aggregate_trade_id"])
            if expected_missing_id is not None:
                if state["status"] != "DEGRADED" or expected != expected_missing_id or latest <= expected:
                    return self._read_stream_state(connection, "BINANCE_UM", symbol)
                present = connection.execute(
                    """SELECT 1 FROM aggregate_trades
                       WHERE exchange='BINANCE_UM' AND symbol=? AND aggregate_trade_id=?""",
                    (symbol, expected),
                ).fetchone()
                if present is not None:
                    return self._read_stream_state(connection, "BINANCE_UM", symbol)
            observed = max(expected + 1, latest)
            now = utc_now_iso()
            connection.execute(
                """UPDATE aggregate_trade_gaps SET status=?, reason=?
                   WHERE exchange='BINANCE_UM' AND symbol=? AND status='OPEN'""",
                (status, reason, symbol),
            )
            open_count = connection.execute(
                "SELECT COUNT(*) AS n FROM aggregate_trade_gaps WHERE exchange='BINANCE_UM' AND symbol=? AND status=?",
                (symbol, status),
            ).fetchone()["n"]
            if not open_count:
                connection.execute(
                    """INSERT INTO aggregate_trade_gaps(
                        exchange, symbol, expected_from_id, observed_id, status, reason,
                        detected_at_utc, resolved_at_utc
                    ) VALUES ('BINANCE_UM', ?, ?, ?, ?, ?, ?, NULL)""",
                    (symbol, expected, observed, status, reason, now),
                )
            connection.execute(
                """UPDATE aggregate_trade_stream_state SET status='UNRESOLVED',
                       unresolved_gap_from_id=?, unresolved_gap_to_id=?, updated_at_utc=?
                   WHERE exchange='BINANCE_UM' AND symbol=?""",
                (expected, observed - 1, now, symbol),
            )
            return self._read_stream_state(connection, "BINANCE_UM", symbol)

    def get_stream_state(self, symbol: str, *, exchange: str = "BINANCE_UM") -> AggregateTradeStreamState:
        with self.database.connection() as connection:
            return self._read_stream_state(connection, exchange, symbol.strip().upper())

    @staticmethod
    def _read_stream_state(connection, exchange: str, symbol: str) -> AggregateTradeStreamState:
        row = connection.execute(
            "SELECT * FROM aggregate_trade_stream_state WHERE exchange=? AND symbol=?",
            (exchange, symbol),
        ).fetchone()
        if row is None:
            raise AggregateTradeStreamStateError(f"No registered stream state for {symbol}")
        return AggregateTradeStreamState(
            exchange=row["exchange"],
            symbol=row["symbol"],
            last_contiguous_aggregate_trade_id=int(row["last_contiguous_aggregate_trade_id"]),
            last_contiguous_trade_time_ms=row["last_contiguous_trade_time_ms"],
            latest_observed_aggregate_trade_id=int(row["latest_observed_aggregate_trade_id"]),
            latest_observed_trade_time_ms=row["latest_observed_trade_time_ms"],
            status=row["status"],
            unresolved_gap_from_id=row["unresolved_gap_from_id"],
            unresolved_gap_to_id=row["unresolved_gap_to_id"],
            updated_at_utc=row["updated_at_utc"],
        )

    def prune_oldest(self, *, symbol: str, keep_latest_rows: int = 250_000) -> int:
        """Explicitly trim old rows for a HEALTHY stream; never prune an unresolved gap.

        Pruning is opt-in rather than automatic so historical data is never deleted
        without a caller-configured retention decision. Durable stream cursors and
        gap audit rows are preserved.
        """
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized or not normalized.isalnum():
            raise AggregateTradeStorageError("symbol must be an exact Binance contract symbol")
        if (
            isinstance(keep_latest_rows, bool)
            or not isinstance(keep_latest_rows, int)
            or not 1 <= keep_latest_rows <= MAX_RETAINED_AGG_TRADES_PER_SYMBOL
        ):
            raise AggregateTradeStorageError(
                f"keep_latest_rows must be between 1 and {MAX_RETAINED_AGG_TRADES_PER_SYMBOL}"
            )
        with self.database.transaction() as connection:
            state = connection.execute(
                "SELECT status FROM aggregate_trade_stream_state WHERE exchange='BINANCE_UM' AND symbol=?",
                (normalized,),
            ).fetchone()
            if state is None:
                raise AggregateTradeStreamStateError(f"No registered stream state for {normalized}")
            if state["status"] != "HEALTHY":
                raise AggregateTradeStreamStateError(
                    "Retention pruning is blocked while aggregate-trade continuity is not HEALTHY"
                )
            cutoff = connection.execute(
                """SELECT aggregate_trade_id FROM aggregate_trades
                   WHERE exchange='BINANCE_UM' AND symbol=?
                   ORDER BY aggregate_trade_id DESC LIMIT 1 OFFSET ?""",
                (normalized, keep_latest_rows - 1),
            ).fetchone()
            if cutoff is None:
                return 0
            cursor = connection.execute(
                """DELETE FROM aggregate_trades
                   WHERE exchange='BINANCE_UM' AND symbol=? AND aggregate_trade_id<?""",
                (normalized, int(cutoff["aggregate_trade_id"])),
            )
            return int(cursor.rowcount)

    def read(
        self,
        *,
        symbol: str,
        from_id: int | None = None,
        through_id: int | None = None,
        limit: int = 1000,
    ) -> list[StoredAggregateTrade]:
        normalized = symbol.strip().upper() if isinstance(symbol, str) else ""
        if not normalized or not normalized.isalnum():
            raise AggregateTradeStorageError("symbol must be an exact Binance contract symbol")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_AGG_TRADE_READ_LIMIT:
            raise AggregateTradeStorageError(f"limit must be between 1 and {MAX_AGG_TRADE_READ_LIMIT}")
        for name, value in (("from_id", from_id), ("through_id", through_id)):
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
                raise AggregateTradeStorageError(f"{name} must be a non-negative integer")
        if from_id is not None and through_id is not None and through_id < from_id:
            raise AggregateTradeStorageError("through_id cannot be lower than from_id")
        clauses = ["exchange='BINANCE_UM'", "symbol=?"]
        args: list[object] = [normalized]
        if from_id is not None:
            clauses.append("aggregate_trade_id>=?")
            args.append(from_id)
        if through_id is not None:
            clauses.append("aggregate_trade_id<=?")
            args.append(through_id)
        args.append(limit)
        with self.database.connection() as connection:
            rows = connection.execute(
                f"SELECT * FROM aggregate_trades WHERE {' AND '.join(clauses)} ORDER BY aggregate_trade_id ASC LIMIT ?",
                args,
            ).fetchall()
        from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord
        result: list[StoredAggregateTrade] = []
        for row in rows:
            record = AggregateTradeRecord(
                exchange=row["exchange"], symbol=row["symbol"],
                aggregate_trade_id=int(row["aggregate_trade_id"]),
                price=Decimal(row["price"]), quantity=Decimal(row["quantity"]),
                normal_quantity=Decimal(row["normal_quantity"]) if row["normal_quantity"] is not None else None,
                first_trade_id=int(row["first_trade_id"]), last_trade_id=int(row["last_trade_id"]),
                event_time_ms=row["event_time_ms"], trade_time_ms=int(row["trade_time_ms"]),
                buyer_is_maker=bool(row["buyer_is_maker"]),
                source_kind=row["last_source_kind"], source_endpoint=row["last_source_endpoint"],
                received_at_utc=row["last_seen_at_utc"],
            )
            result.append(StoredAggregateTrade(record, row["first_seen_at_utc"], row["last_seen_at_utc"]))
        return result
