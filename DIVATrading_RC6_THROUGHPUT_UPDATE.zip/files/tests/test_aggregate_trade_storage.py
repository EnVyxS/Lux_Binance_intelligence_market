from contextlib import contextmanager
from dataclasses import replace
from datetime import UTC, datetime
from decimal import Decimal
from itertools import repeat
from pathlib import Path
from unittest.mock import patch

import pytest

from divatrading.core.database import Database, SCHEMA_VERSION
from divatrading.market_data.aggregate_trade_history import AggregateTradeRecord, parse_aggregate_trade_rest_row
from divatrading.market_data.aggregate_trade_storage import (
    MAX_AGG_TRADE_WRITE_BATCH,
    AggregateTradeIdentityConflict,
    AggregateTradeRepository,
    AggregateTradeStorageError,
    AggregateTradeStreamStateError,
)

NOW = datetime(2026, 11, 10, 1, 0, tzinfo=UTC)
BASE_MS = 1_800_000_000_000


def record(agg_id: int, *, source: str = "REST", time_ms: int = BASE_MS) -> AggregateTradeRecord:
    row = {
        "a": agg_id, "p": "100.000000000000000001", "q": "0.100000000000000001",
        "nq": "0.090000000000000001", "f": agg_id * 2, "l": agg_id * 2 + 1,
        "T": time_ms, "m": (agg_id % 2 == 0),
    }
    rec = parse_aggregate_trade_rest_row(row, symbol="BTCUSDT", received_at_utc=NOW)
    if source == "REST":
        return rec
    return AggregateTradeRecord(
        exchange=rec.exchange, symbol=rec.symbol, aggregate_trade_id=rec.aggregate_trade_id,
        price=rec.price, quantity=rec.quantity, normal_quantity=None,
        first_trade_id=rec.first_trade_id, last_trade_id=rec.last_trade_id,
        event_time_ms=time_ms, trade_time_ms=rec.trade_time_ms,
        buyer_is_maker=rec.buyer_is_maker, source_kind="WEBSOCKET",
        source_endpoint="wss://fstream.binance.com/market/ws", received_at_utc=rec.received_at_utc,
    )


@pytest.fixture
def repo(tmp_path: Path):
    database = Database(tmp_path / "state.db")
    assert database.initialize() == SCHEMA_VERSION == 6
    return AggregateTradeRepository(database)


def test_schema_v6_preserves_trade_and_order_flow_tables_and_indexes(repo):
    with repo.database.connection() as connection:
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        indexes = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert {"aggregate_trades", "aggregate_trade_stream_state", "aggregate_trade_gaps", "order_flow_state", "order_flow_buckets"} <= tables
    assert "idx_aggregate_trades_symbol_time" in indexes


def test_decimal_persistence_round_trip_and_exact_primary_key(repo):
    assert repo.upsert_many([record(100)]) == 1
    assert repo.upsert_many([record(100)]) == 0
    saved = repo.read(symbol="BTCUSDT", from_id=100, through_id=100)[0].record
    assert str(saved.price) == "100.000000000000000001"
    assert str(saved.quantity) == "0.100000000000000001"
    assert saved.normal_quantity == Decimal("0.090000000000000001")
    assert saved.aggregate_trade_id == 100


def test_duplicate_identity_merges_rest_metadata_into_websocket_record(repo):
    repo.upsert_many([record(100, source="WEBSOCKET")])
    assert repo.upsert_many([record(100, source="REST")]) == 0
    saved = repo.read(symbol="BTCUSDT", from_id=100, through_id=100)[0].record
    assert saved.normal_quantity == Decimal("0.090000000000000001")
    assert saved.event_time_ms == BASE_MS
    with repo.database.connection() as connection:
        row = connection.execute("SELECT first_source_kind, last_source_kind FROM aggregate_trades").fetchone()
    assert row["first_source_kind"] == "WEBSOCKET"
    assert row["last_source_kind"] == "REST"


def test_rest_and_websocket_overlap_merges_equal_decimals_with_different_scales(repo):
    baseline = record(100)
    repo.bootstrap_latest([baseline])

    updated = repo.record_observed(replace(
        record(100, source="WEBSOCKET"),
        price=Decimal("100.0000000000000000010"),
        quantity=Decimal("0.1000000000000000010"),
    ))
    assert updated.status == "HEALTHY"
    assert updated.last_contiguous_aggregate_trade_id == 100
    assert repo.upsert_many([replace(baseline, normal_quantity=Decimal("0.0900000000000000010"))]) == 0

    saved, = repo.read(symbol="BTCUSDT", from_id=100)
    assert saved.record.event_time_ms == BASE_MS
    assert saved.record.price.as_tuple() == baseline.price.as_tuple()
    assert saved.record.quantity.as_tuple() == baseline.quantity.as_tuple()
    assert saved.record.normal_quantity.as_tuple() == baseline.normal_quantity.as_tuple()


def test_immutable_payload_conflict_is_rejected_and_transaction_rolls_back(repo):
    repo.upsert_many([record(100)])
    conflicting = record(100)
    conflicting = AggregateTradeRecord(
        exchange=conflicting.exchange, symbol=conflicting.symbol,
        aggregate_trade_id=conflicting.aggregate_trade_id, price=Decimal("101"),
        quantity=conflicting.quantity, normal_quantity=conflicting.normal_quantity,
        first_trade_id=conflicting.first_trade_id, last_trade_id=conflicting.last_trade_id,
        event_time_ms=conflicting.event_time_ms, trade_time_ms=conflicting.trade_time_ms,
        buyer_is_maker=conflicting.buyer_is_maker, source_kind=conflicting.source_kind,
        source_endpoint=conflicting.source_endpoint, received_at_utc=conflicting.received_at_utc,
    )
    with pytest.raises(AggregateTradeIdentityConflict):
        repo.upsert_many([record(101), conflicting])
    assert [r.record.aggregate_trade_id for r in repo.read(symbol="BTCUSDT")] == [100]


def test_batches_are_bounded_and_single_symbol(repo):
    with pytest.raises(AggregateTradeStorageError, match="one exchange/symbol"):
        repo.upsert_many([record(1), AggregateTradeRecord(
            exchange="BINANCE_UM", symbol="ETHUSDT", aggregate_trade_id=2,
            price=Decimal("1"), quantity=Decimal("1"), normal_quantity=None,
            first_trade_id=2, last_trade_id=2, event_time_ms=None, trade_time_ms=BASE_MS,
            buyer_is_maker=False, source_kind="REST", source_endpoint="fixture",
            received_at_utc="2026-11-10T01:00:00.000Z",
        )])
    with pytest.raises(AggregateTradeStorageError, match="cannot exceed"):
        repo.upsert_many([record(i) for i in range(5001)])


def test_latest_bootstrap_creates_healthy_explicit_baseline(repo):
    state = repo.bootstrap_latest([record(100), record(101), record(102)])
    assert state.last_contiguous_aggregate_trade_id == 102
    assert state.latest_observed_aggregate_trade_id == 102
    assert state.status == "HEALTHY"
    with pytest.raises(AggregateTradeStreamStateError, match="cannot reset"):
        repo.bootstrap_latest([record(200), record(201)])


def test_from_id_registration_is_explicit_and_idempotent(repo):
    state = repo.register_from_id(symbol="btcusdt", start_from_id=500)
    assert state.last_contiguous_aggregate_trade_id == 499
    assert state.status == "BOOTSTRAPPING"
    assert repo.register_from_id(symbol="BTCUSDT", start_from_id=500).status == "BOOTSTRAPPING"
    with pytest.raises(AggregateTradeStreamStateError, match="different cursor"):
        repo.register_from_id(symbol="BTCUSDT", start_from_id=501)


def test_stream_rejects_websocket_ingestion_before_bootstrap(repo):
    from divatrading.market_data.aggregate_trade_storage import AggregateTradeStreamStateError
    with pytest.raises(AggregateTradeStreamStateError, match="must be bootstrapped"):
        repo.record_observed(record(1, source="WEBSOCKET"))


def test_record_observed_tracks_gap_then_advances_when_backfill_arrives(repo):
    repo.bootstrap_latest([record(100), record(101), record(102)])
    state = repo.record_observed(record(105, source="WEBSOCKET"))
    assert state.status == "DEGRADED"
    assert state.last_contiguous_aggregate_trade_id == 102
    assert state.unresolved_gap_from_id == 103
    assert state.unresolved_gap_to_id == 104
    state = repo.persist_recovered([record(103), record(104)], symbol="BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 105
    with repo.database.connection() as connection:
        gaps = connection.execute("SELECT status FROM aggregate_trade_gaps").fetchall()
    assert [row["status"] for row in gaps] == ["RESOLVED"]


def test_observed_batch_uses_one_transaction_and_keeps_gap_history(repo):
    repo.bootstrap_latest([record(100)])
    events = (record(i, source="WEBSOCKET") for i in (101, 104, 103, 102, 105))

    with patch.object(repo.database, "transaction", wraps=repo.database.transaction) as transaction:
        state = repo.record_observed_many(events)
    transaction.assert_called_once()

    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == state.latest_observed_aggregate_trade_id == 105
    assert state == repo.get_stream_state("BTCUSDT")
    with repo.database.connection() as connection:
        gap, = connection.execute(
            "SELECT expected_from_id, observed_id, status FROM aggregate_trade_gaps"
        ).fetchall()
    assert tuple(gap) == (102, 104, "RESOLVED")


def test_contiguous_observed_batch_advances_the_durable_cursor_once(repo):
    repo.bootstrap_latest([record(100)])
    events = [record(i, source="WEBSOCKET", time_ms=BASE_MS + i) for i in range(101, 165)]

    with patch.object(repo, "_advance_in_transaction", wraps=repo._advance_in_transaction) as advance:
        state = repo.record_observed_many(events)
    advance.assert_called_once()

    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == state.latest_observed_aggregate_trade_id == 164
    assert state.last_contiguous_trade_time_ms == state.latest_observed_trade_time_ms == BASE_MS + 164
    assert state.unresolved_gap_from_id is state.unresolved_gap_to_id is None
    assert [row.record for row in repo.read(symbol="BTCUSDT", from_id=101)] == events


def test_contiguous_observed_batch_conflict_with_staged_rest_rolls_back(repo):
    baseline = repo.bootstrap_latest([record(100)])
    repo.upsert_many([record(102)])
    conflict = replace(record(102, source="WEBSOCKET"), quantity=Decimal("10"))

    with pytest.raises(AggregateTradeIdentityConflict):
        repo.record_observed_many([record(101, source="WEBSOCKET"), conflict])

    assert repo.get_stream_state("BTCUSDT") == baseline
    assert [item.record.aggregate_trade_id for item in repo.read(symbol="BTCUSDT")] == [100, 102]


def test_observed_batch_preserves_gaps_for_unreceived_trades(repo):
    repo.bootstrap_latest([record(100)])
    state = repo.record_observed_many(record(i, source="WEBSOCKET") for i in (101, 104, 105))
    assert state.status == "DEGRADED"
    assert state.last_contiguous_aggregate_trade_id == 101
    assert state.latest_observed_aggregate_trade_id == 105
    assert (state.unresolved_gap_from_id, state.unresolved_gap_to_id) == (102, 104)


def test_observed_batch_does_not_materialize_rows_beyond_the_first_gap(repo, monkeypatch):
    repo.bootstrap_latest([record(100)])
    repo.upsert_many(record(i) for i in range(102, 166))
    transaction = repo.database.transaction
    materialized = []

    @contextmanager
    def tracked_transaction():
        with transaction() as connection:
            row_factory = connection.row_factory

            def track(cursor, values):
                if tuple(column[0] for column in cursor.description) == ("aggregate_trade_id", "trade_time_ms"):
                    materialized.append(values[0])
                return row_factory(cursor, values)

            connection.row_factory = track
            yield connection

    monkeypatch.setattr(repo.database, "transaction", tracked_transaction)
    observed = [record(i, source="WEBSOCKET") for i in range(166, 170)]
    state = repo.record_observed_many(observed)

    assert state.status == "DEGRADED"
    assert state.last_contiguous_aggregate_trade_id == 100
    assert state.latest_observed_aggregate_trade_id == 169
    assert materialized == [102] * len(observed)


def test_observed_batch_conflict_rolls_back_records_cursor_and_gap(repo):
    original = repo.bootstrap_latest([record(100)])
    conflict = replace(record(100, source="WEBSOCKET"), quantity=Decimal("10"))

    with pytest.raises(AggregateTradeIdentityConflict):
        repo.record_observed_many([record(104, source="WEBSOCKET"), record(101, source="WEBSOCKET"), conflict])

    assert repo.get_stream_state("BTCUSDT") == original
    assert [item.record.aggregate_trade_id for item in repo.read(symbol="BTCUSDT")] == [100]
    with repo.database.connection() as connection:
        assert connection.execute("SELECT COUNT(*) FROM aggregate_trade_gaps").fetchone()[0] == 0


def test_observed_batch_enforces_size_and_source_contract(repo):
    observed = record(101, source="WEBSOCKET")
    with pytest.raises(AggregateTradeStorageError, match="at least one"):
        repo.record_observed_many([])
    with pytest.raises(AggregateTradeStorageError, match="cannot exceed"):
        repo.record_observed_many(repeat(observed, MAX_AGG_TRADE_WRITE_BATCH + 1))
    with pytest.raises(AggregateTradeStorageError, match="one exchange/symbol"):
        repo.record_observed_many([observed, replace(observed, symbol="ETHUSDT")])
    with pytest.raises(AggregateTradeStorageError, match="WebSocket records only"):
        repo.record_observed_many([observed, record(102)])


def test_duplicate_and_out_of_order_observed_events_do_not_regress_cursor(repo):
    repo.bootstrap_latest([record(100), record(101), record(102)])
    state = repo.record_observed(record(101, source="WEBSOCKET"))
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 102


def test_unresolved_state_is_not_auto_cleared_by_later_event(repo):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(104, source="WEBSOCKET"))
    unresolved = repo.mark_unresolved(symbol="BTCUSDT", status="UNRESOLVED_RETENTION", reason="expired")
    assert unresolved.status == "UNRESOLVED"
    state = repo.record_observed(record(105, source="WEBSOCKET"))
    assert state.status == "UNRESOLVED"


def test_bounded_read_order_and_inclusive_range(repo):
    repo.upsert_many([record(i) for i in range(100, 110)])
    values = repo.read(symbol="BTCUSDT", from_id=103, through_id=107, limit=3)
    assert [r.record.aggregate_trade_id for r in values] == [103, 104, 105]
    with pytest.raises(AggregateTradeStorageError):
        repo.read(symbol="BTCUSDT", limit=5001)


def test_non_utc_received_timestamp_is_rejected(repo):
    source = record(1)
    invalid = AggregateTradeRecord(
        exchange=source.exchange, symbol=source.symbol,
        aggregate_trade_id=source.aggregate_trade_id, price=source.price,
        quantity=source.quantity, normal_quantity=source.normal_quantity,
        first_trade_id=source.first_trade_id, last_trade_id=source.last_trade_id,
        event_time_ms=source.event_time_ms, trade_time_ms=source.trade_time_ms,
        buyer_is_maker=source.buyer_is_maker, source_kind=source.source_kind,
        source_endpoint=source.source_endpoint, received_at_utc="2026-11-10T08:00:00+07:00",
    )
    with pytest.raises(AggregateTradeStorageError, match="UTC"):
        repo.upsert_many([invalid])


def test_contiguous_cursor_and_trade_rows_survive_database_reopen(repo, tmp_path: Path):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(102, source="WEBSOCKET"))
    reopened = AggregateTradeRepository(Database(tmp_path / "state.db"))
    state = reopened.get_stream_state("BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 102
    assert [row.record.aggregate_trade_id for row in reopened.read(symbol="BTCUSDT")] == [100, 101, 102]


def test_manual_retention_prunes_only_oldest_rows_on_healthy_stream(repo):
    repo.bootstrap_latest([record(i) for i in range(100, 110)])
    removed = repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=4)
    assert removed == 6
    assert [r.record.aggregate_trade_id for r in repo.read(symbol="BTCUSDT")] == [106, 107, 108, 109]
    state = repo.get_stream_state("BTCUSDT")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 109


def test_retention_pruning_is_blocked_when_stream_has_a_gap(repo):
    repo.bootstrap_latest([record(100), record(101)])
    repo.record_observed(record(104, source="WEBSOCKET"))
    with pytest.raises(AggregateTradeStreamStateError, match="not HEALTHY"):
        repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=1)


def test_retention_pruning_validates_bound(repo):
    repo.bootstrap_latest([record(100)])
    with pytest.raises(AggregateTradeStorageError, match="keep_latest_rows"):
        repo.prune_oldest(symbol="BTCUSDT", keep_latest_rows=0)
