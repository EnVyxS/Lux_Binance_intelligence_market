from __future__ import annotations

import asyncio
from collections import deque
from decimal import Decimal
from pathlib import Path
from threading import Event
from types import SimpleNamespace

import pytest

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.market_data.live_feed_graph import (
    BinanceFeedGraphConfig,
    BinanceFeedGraphError,
    BinancePublicFeedFactory,
    _BinanceSymbolFeedGraph,
    _KlineTail,
)
from divatrading.market_data.order_book import OrderBookMetrics
from divatrading.market_data.order_book_supervisor import OrderBookSymbolHealth
from divatrading.market_data.orchestrator import MarketDataReadiness
from divatrading.market_data.strategy_snapshot import StrategyMarketDataAdapter

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def test_feed_graph_config_enforces_canonical_timeframes_and_bounds():
    assert BinanceFeedGraphConfig().intervals == ("1m", "5m", "15m")
    with pytest.raises(ValueError, match="canonical production or Demo"):
        BinanceFeedGraphConfig(ws_endpoint="wss://untrusted.example/stream")
    with pytest.raises(ValueError, match="canonical order"):
        BinanceFeedGraphConfig(intervals=("1m", "15m", "5m"))
    with pytest.raises(ValueError, match="bootstrap_candles"):
        BinanceFeedGraphConfig(bootstrap_candles=10)
    with pytest.raises(ValueError, match="snapshot_interval_seconds"):
        BinanceFeedGraphConfig(snapshot_interval_seconds=0.01)


def test_feed_factory_requires_exact_exchange_metadata(tmp_path):
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("BTCUSDT")
    finally:
        client.close()


def test_feed_factory_accepts_only_exchange_info_symbols(tmp_path):
    payload = __import__("json").loads(FIXTURE.read_text(encoding="utf-8"))
    snapshot = parse_exchange_info(
        payload, source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo"
    )
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        factory.set_metadata(snapshot)
        stream = factory("BTCUSDT")
        assert hasattr(stream, "__aiter__")
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("NOTAREALCONTRACT")
    finally:
        client.close()


@pytest.mark.parametrize(("rest_url", "ws_origin"), [
    ("https://fapi.binance.com", "wss://fstream.binance.com"),
    ("https://demo-fapi.binance.com", "wss://demo-fstream.binance.com"),
], ids=["paper", "demo"])
def test_market_feed_graph_routes_depth_on_same_hosts_public_channel(tmp_path, rest_url, ws_origin):
    import json

    market_endpoint = ws_origin + "/market/stream"
    snapshot = parse_exchange_info(
        json.loads(FIXTURE.read_text(encoding="utf-8")),
        source_endpoint=rest_url + "/fapi/v1/exchangeInfo",
    )
    symbol_info = snapshot.get_symbol("BTCUSDT")
    assert symbol_info is not None
    client = BinanceUsdMFuturesRestClient(base_url=rest_url)
    database = Database(tmp_path / "test.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(
        rest_client=client, database=database,
        config=BinanceFeedGraphConfig(ws_endpoint=market_endpoint),
    )
    try:
        graph = _BinanceSymbolFeedGraph(
            symbol="BTCUSDT", symbol_info=symbol_info,
            rest_client=client, history_rest_client=factory._history_rest,
            depth_snapshot_client=factory._depth_snapshot,
            database=database, config=factory.config, bootstrap_lock=asyncio.Lock(),
        )
        assert factory.rest_client.base_url == rest_url
        assert factory._depth_snapshot._client.endpoint == rest_url + "/fapi/v1/depth"
        for feed in (graph.kline_feed, graph.mark_feed, graph.aggregate_feed):
            assert feed.endpoint == market_endpoint
        assert graph.depth_feed.endpoint == ws_origin + "/public/stream"
    finally:
        factory.close()
        client.close()


def test_capture_key_changes_when_flow_advances_or_a_feed_reconnects():
    candles = SimpleNamespace(latest_closed_candle=SimpleNamespace(open_time_ms=5))
    flow = SimpleNamespace(last_processed_aggregate_trade_id=10, window_end_ms=20)
    sources = SimpleNamespace(aggregate_trade_reconnect_generation=0, depth_reconnect_generation=0)
    view = SimpleNamespace(
        m1=candles, m5=candles, m15=candles, flow=flow, orchestrator_readiness=sources,
        mark_price=SimpleNamespace(event_time_ms=6),
        order_book_metrics=SimpleNamespace(update_id=7),
        readiness=SimpleNamespace(entry_quote_ready=True, delta_cvd_available=True),
    )
    capture = _BinanceSymbolFeedGraph._capture_key
    initial = capture(view)
    assert capture(view) == initial

    flow.last_processed_aggregate_trade_id += 1
    after_trade = capture(view)
    assert after_trade != initial

    sources.depth_reconnect_generation += 1
    after_reconnect = capture(view)
    assert after_reconnect != after_trade

    view.readiness.entry_quote_ready = False
    assert capture(view) != after_reconnect


def _kline_graph():
    graph = _BinanceSymbolFeedGraph.__new__(_BinanceSymbolFeedGraph)
    graph.symbol = "BTCUSDT"
    graph.config = BinanceFeedGraphConfig()
    graph.pending_closed = {interval: deque() for interval in graph.config.intervals}
    graph._kline_tails = {interval: _KlineTail() for interval in graph.config.intervals}
    graph.forming_klines = {}
    graph.stop_event = asyncio.Event()
    graph.wake_event = asyncio.Event()
    graph.depth_feed = SimpleNamespace(stats=SimpleNamespace(connection_count=1))
    return graph


def _snapshot_graph():
    from divatrading.market_data.recovery import FeedHealth

    graph = _kline_graph()
    graph.now_ms = lambda: 1_800_000_000_000
    graph.symbol_info = object()
    graph.kline_feed = graph.mark_feed = SimpleNamespace(is_connected=True)
    graph.latest_mark_price = SimpleNamespace(event_time_ms=graph.now_ms())
    graph.market_orchestrator = SimpleNamespace(is_running=True, health=lambda symbol: _readiness())
    graph.depth_supervisor = SimpleNamespace(health=lambda symbol: _depth_health(ready=False))
    graph.kline_recovery = SimpleNamespace(
        stream_health=lambda **kwargs: FeedHealth.HEALTHY, observe_websocket_feed=lambda feed: None,
    )
    graph.adapter = SimpleNamespace(
        build_view=lambda *, kline_series, **kwargs: SimpleNamespace(
            status="READY",
            readiness=SimpleNamespace(can_scan_setups=True, mark_price_available=True),
            candles={item.interval: item.candles for item in kline_series},
        ),
    )
    graph._last_pending_warning_ms = 0
    return graph


@pytest.mark.asyncio
async def test_snapshot_reuses_kline_tails_until_a_closed_candle_is_written():
    graph = _snapshot_graph()
    reads = []
    newest_m5 = "previous"

    def read_tail(*, symbol, interval, limit):
        reads.append(interval)
        return (
            SimpleNamespace(kline="older"),
            SimpleNamespace(kline=newest_m5 if interval == "5m" else interval),
        )

    def ingest(event):
        nonlocal newest_m5
        newest_m5 = "closed"

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.kline_recovery.ingest_websocket_event = ingest

    first = await graph._build_complete_view()
    second = await graph._build_complete_view()
    assert first.candles == second.candles
    assert reads == ["1m", "5m", "15m"]

    graph.pending_closed["5m"].append(SimpleNamespace(kline=SimpleNamespace(open_time_ms=0)))
    await graph._retry_pending_interval("5m")
    updated = await graph._build_complete_view()
    assert reads == ["1m", "5m", "15m", "5m"]
    assert updated.candles["5m"] == ("older", "closed")


@pytest.mark.asyncio
@pytest.mark.parametrize("delayed_interval", ["5m", "15m"])
async def test_snapshot_excludes_a_tail_invalidated_while_awaiting_a_read(delayed_interval):
    graph = _snapshot_graph()
    loop = asyncio.get_running_loop()
    entered = asyncio.Event()
    release = Event()
    newest_m5 = "previous"

    def read_tail(*, symbol, interval, limit):
        row = newest_m5 if interval == "5m" else interval
        if interval == delayed_interval:
            loop.call_soon_threadsafe(entered.set)
            assert release.wait(3)
        return (SimpleNamespace(kline="older"), SimpleNamespace(kline=row))

    def ingest(event):
        nonlocal newest_m5
        newest_m5 = "closed"

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.kline_recovery.ingest_websocket_event = ingest
    building = asyncio.create_task(graph._build_complete_view())
    try:
        await asyncio.wait_for(entered.wait(), timeout=3)
        graph.pending_closed["5m"].append(SimpleNamespace(kline=SimpleNamespace(open_time_ms=0)))
        await graph._retry_pending_interval("5m")
        assert not graph.pending_closed["5m"]
    finally:
        release.set()
    old_read = await building
    assert "5m" not in old_read.candles
    fresh = await graph._build_complete_view()
    assert fresh.candles["5m"] == ("older", "closed")


@pytest.mark.asyncio
async def test_failed_recovery_never_exposes_its_previous_cached_tail():
    graph = _snapshot_graph()
    loop = asyncio.get_running_loop()
    entered = asyncio.Event()
    release = Event()
    newest_m5 = "previous"

    def read_tail(*, symbol, interval, limit):
        row = newest_m5 if interval == "5m" else interval
        return (SimpleNamespace(kline="older"), SimpleNamespace(kline=row))

    def recover_stream(*, symbol, interval, target_end_open_time_ms):
        nonlocal newest_m5
        if interval == "5m":
            newest_m5 = "committed_partial_recovery"
            loop.call_soon_threadsafe(entered.set)
            assert release.wait(3)
            raise RuntimeError("a later recovery page failed")

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.kline_recovery.recover_stream = recover_stream
    assert (await graph._build_complete_view()).candles["5m"] == ("older", "previous")
    recovering = asyncio.create_task(graph._recover_all_intervals())
    try:
        await asyncio.wait_for(entered.wait(), timeout=3)
        assert "5m" not in (await graph._build_complete_view()).candles
    finally:
        release.set()
    await recovering
    assert (await graph._build_complete_view()).candles["5m"] == ("older", "committed_partial_recovery")


@pytest.mark.asyncio
async def test_cancelled_kline_writer_waits_for_the_synchronous_operation_to_finish():
    graph = _snapshot_graph()
    loop = asyncio.get_running_loop()
    entered = asyncio.Event()
    release = Event()
    writes = []

    def write():
        loop.call_soon_threadsafe(entered.set)
        assert release.wait(3)
        writes.append("finished")

    writer = asyncio.create_task(graph._write_klines("5m", write))
    try:
        await asyncio.wait_for(entered.wait(), timeout=3)
        writer.cancel()
        await asyncio.sleep(0)
        assert not writer.done()
        assert not graph._kline_ready("5m")
    finally:
        release.set()
    with pytest.raises(asyncio.CancelledError):
        await writer
    assert writes == ["finished"]
    assert graph._kline_ready("5m")


@pytest.mark.asyncio
async def test_failed_orchestrator_stop_is_reported_as_a_worker_failure():
    graph = _kline_graph()
    failure = RuntimeError("aggregate queue disconnected")

    async def bootstrap():
        return None

    async def wait_for_stop(stop):
        await stop.wait()

    async def fail(stop):
        stop.set()
        graph.wake_event.set()
        raise failure

    async def no_view():
        return None

    graph._bootstrap_klines = bootstrap
    graph._consume_klines = lambda: wait_for_stop(graph.stop_event)
    graph._consume_mark_price = lambda: wait_for_stop(graph.stop_event)
    graph._build_complete_view = no_view
    graph.kline_feed = graph.mark_feed = SimpleNamespace(run=wait_for_stop)
    graph.market_orchestrator = SimpleNamespace(run=fail)

    with pytest.raises(BinanceFeedGraphError, match="market-orchestrator:BTCUSDT") as error:
        await anext(graph.stream())

    assert error.value.__cause__ is failure
    assert all(task.done() for task in graph._tasks)


@pytest.mark.asyncio
async def test_pending_close_retries_on_monotonic_cadence_with_continuous_forming_events(monkeypatch):
    from divatrading.market_data import live_feed_graph

    graph = _kline_graph()
    clock = SimpleNamespace(seconds=0.0)
    monkeypatch.setattr(live_feed_graph, "time", SimpleNamespace(monotonic=lambda: clock.seconds))
    graph.now_ms = lambda: 10_000 - round(clock.seconds * 1_000)
    graph._last_pending_warning_ms = 0
    graph._last_kline_connection_generation = 1

    close = SimpleNamespace(
        is_closed=True, kline=SimpleNamespace(symbol=graph.symbol, interval="5m", open_time_ms=0),
    )
    forming = SimpleNamespace(
        is_closed=False, kline=SimpleNamespace(symbol=graph.symbol, interval="1m"),
    )
    arrivals = iter((0.0, 0.05, 0.10, 0.15, 0.21, 0.26, 0.31, 0.36, 0.42, 0.46))

    async def get_event():
        clock.seconds = next(arrivals)
        if clock.seconds == 0.46:
            graph.stop_event.set()
        return close if clock.seconds == 0 else forming

    attempts = []

    def ingest(event):
        assert event is close
        attempts.append(clock.seconds)
        if len(attempts) < 3:
            raise RuntimeError("REST candle not available yet")

    graph.kline_feed = SimpleNamespace(
        get_event=get_event, is_connected=True, stats=SimpleNamespace(connection_count=1),
    )
    graph.kline_recovery = SimpleNamespace(
        observe_websocket_feed=lambda feed: None, ingest_websocket_event=ingest,
    )

    await graph._consume_klines()

    assert attempts == pytest.approx([0.0, 0.21, 0.42])
    assert not graph.pending_closed["5m"]
    assert graph.forming_klines["1m"] is forming


@pytest.mark.asyncio
@pytest.mark.parametrize("queued_during_read", [None, "5m", "15m"])
async def test_build_view_omits_interval_while_a_closed_candle_is_pending(queued_during_read):
    from divatrading.market_data.recovery import FeedHealth

    graph = _kline_graph()
    graph.now_ms = lambda: 1_800_000_000_000
    graph.symbol_info = object()
    graph.kline_feed = graph.mark_feed = SimpleNamespace(is_connected=True)
    graph.latest_mark_price = SimpleNamespace(event_time_ms=graph.now_ms())
    graph.market_orchestrator = SimpleNamespace(is_running=True, health=lambda symbol: _readiness())
    graph.depth_supervisor = SimpleNamespace(health=lambda symbol: _depth_health(ready=False))
    graph.kline_recovery = SimpleNamespace(stream_health=lambda **kwargs: FeedHealth.HEALTHY)

    if queued_during_read is None:
        graph.pending_closed["5m"].append(object())

    reads = []

    def read_tail(*, symbol, interval, limit):
        reads.append(interval)
        if interval == queued_during_read:
            graph.pending_closed["5m"].append(object())
        return (SimpleNamespace(kline=object()), SimpleNamespace(kline=object()))

    def build_view(*, kline_series, **kwargs):
        return SimpleNamespace(
            status="READY",
            readiness=SimpleNamespace(can_scan_setups=True, mark_price_available=True),
            intervals=tuple(item.interval for item in kline_series),
        )

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.adapter = SimpleNamespace(build_view=build_view)

    view = await graph._build_complete_view()

    assert view.intervals == ("1m", "15m")
    assert ("5m" in reads) is (queued_during_read is not None)

    graph.pending_closed["5m"].clear()
    queued_during_read = None
    restored = await graph._build_complete_view()
    assert restored.intervals == ("1m", "5m", "15m")


@pytest.mark.asyncio
async def test_capture_uses_quote_and_time_from_after_kline_reads():
    from divatrading.market_data.recovery import FeedHealth
    from divatrading.strategy.sweep_reclaim import SweepSetup
    from divatrading.trading.sweep_reclaim import SweepReclaimPlanner

    graph = _kline_graph()
    startup_ms = 1_800_000_000_000
    market = SimpleNamespace(now_ms=startup_ms, health=_readiness(startup_ms), quote=None)
    graph.now_ms = lambda: market.now_ms
    graph.symbol_info = object()
    graph.kline_feed = graph.mark_feed = SimpleNamespace(is_connected=True)
    graph.latest_mark_price = SimpleNamespace(event_time_ms=startup_ms)
    graph.market_orchestrator = SimpleNamespace(is_running=True, health=lambda symbol: market.health)
    graph.depth_supervisor = SimpleNamespace(
        health=lambda symbol: _depth_health(update_id=101), metrics=lambda symbol: market.quote,
    )
    graph.kline_recovery = SimpleNamespace(stream_health=lambda **kwargs: FeedHealth.HEALTHY)

    def read_tail(*, symbol, interval, limit):
        if interval == "15m":
            market.now_ms += 150
            market.quote = SimpleNamespace(
                symbol=symbol, update_id=101, last_event_time_ms=market.now_ms - 5, synchronized=True,
                best_bid=Decimal("99.99"), best_ask=Decimal("100.01"),
            )
            market.health = _readiness(market.now_ms)
            graph.latest_mark_price = SimpleNamespace(event_time_ms=market.now_ms - 10)
        return (SimpleNamespace(kline=object()), SimpleNamespace(kline=object()))

    def build_view(*, symbol, now_ms, mark_price, readiness, order_book_metrics, **kwargs):
        return SimpleNamespace(
            symbol=symbol, captured_at_ms=now_ms, status="READY", mark_price=mark_price,
            readiness=SimpleNamespace(can_scan_setups=True, mark_price_available=True, entry_quote_ready=True),
            orchestrator_readiness=readiness, order_book_metrics=order_book_metrics,
        )

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.adapter = SimpleNamespace(build_view=build_view)
    view = await graph._build_complete_view()
    setup = SweepSetup(1, startup_ms, Decimal(100), Decimal(99), Decimal(103), startup_ms + 10_000)

    assert view.captured_at_ms == market.now_ms
    assert view.mark_price is graph.latest_mark_price
    assert view.orchestrator_readiness.updated_at_ms == market.now_ms
    assert view.orchestrator_readiness.order_book_health.update_id == view.order_book_metrics.update_id
    assert SweepReclaimPlanner()._quote_ready(view, view.order_book_metrics, setup, view.captured_at_ms)


def _depth_health(*, ready=True, update_id=100):
    return OrderBookSymbolHealth(
        symbol="BTCUSDT", connection_state="CONNECTED" if ready else "DISCONNECTED",
        snapshot_state="READY" if ready else "RESYNC_REQUIRED",
        sequence_integrity=ready, event_fresh=ready, queue_healthy=True, ready=ready,
        update_id=update_id, event_age_ms=10, queue_depth=0, queue_capacity=10,
        buffered_events=0, invalid_reason="NONE", last_error=None,
    )


def _readiness(now=0):
    return MarketDataReadiness(
        symbol="BTCUSDT", status="DEGRADED", ready=False, reason_codes=("TEST",),
        aggregate_trade_connected=True, aggregate_trade_continuity=False, delta_cvd_ready=False,
        order_book_ready=True, queues_healthy=True, aggregate_trade_reconnect_generation=0,
        depth_reconnect_generation=0, aggregate_event_queue_depth=0, aggregate_event_queue_capacity=10,
        internal_queue_depth=0, internal_queue_capacity=10, order_book_health=_depth_health(),
        flow=None, evidence_status="UNAVAILABLE", evidence=None, updated_at_ms=now,
    )


@pytest.mark.parametrize(("connection_count", "live_ready", "metrics_id", "metrics_age", "expected_reason"), [
    (1, True, 101, 10, None),
    (2, True, 101, 10, "DEPTH_HEALTH_MISSING"),
    (1, False, 101, 10, "DEPTH_SEQUENCE_OR_READINESS_INVALID"),
    (1, True, 102, 10, "DEPTH_METRICS_MISSING"),
    (1, True, 101, 20_000, "DEPTH_METRICS_STALE"),
], ids=["new-update", "reconnect", "disconnected", "mismatch", "stale"])
def test_capture_pairs_live_depth_health_with_its_update(
    connection_count, live_ready, metrics_id, metrics_age, expected_reason,
):
    graph = _kline_graph()
    graph.depth_feed.stats.connection_count = connection_count
    now = 1_800_000_000_000
    cached = _readiness(now)
    live_health = _depth_health(ready=live_ready, update_id=101)
    live_metrics = OrderBookMetrics(
        symbol=graph.symbol, update_id=metrics_id, best_bid=Decimal("100"), best_ask=Decimal("101"),
        spread=Decimal("1"), spread_bps=Decimal("99.5"), bid_depth=Decimal("10"),
        ask_depth=Decimal("12"), imbalance=Decimal("-0.09"), level_count_bid=20,
        level_count_ask=20, synchronized=True, last_event_time_ms=now - metrics_age,
    )
    graph.depth_supervisor = SimpleNamespace(health=lambda symbol: live_health, metrics=lambda symbol: live_metrics)

    readiness, metrics = graph._capture_depth_state(cached)
    source = StrategyMarketDataAdapter().build_snapshot(
        symbol=graph.symbol, now_ms=now, kline_series=(), mark_price=None,
        mark_price_connected=False, readiness=readiness, order_book_metrics=metrics,
    )

    assert cached.order_book_health.update_id == 100
    depth = source.component("DEPTH")
    if expected_reason is None:
        assert readiness.order_book_health.update_id == metrics.update_id == 101
        assert depth.ready
    else:
        assert not depth.ready
        assert expected_reason in depth.reason_codes


def test_autonomous_environment_selection_has_no_mainnet_testnet_mixing():
    from divatrading.cli import _autonomous_market_endpoints
    from divatrading.execution.service import ExecutionMode
    from divatrading.execution.binance_private import TESTNET_BASE_URL
    from divatrading.exchange.binance.client import DEFAULT_BASE_URL
    from divatrading.market_data.websocket import (
        BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )

    assert _autonomous_market_endpoints(ExecutionMode.TESTNET) == (
        TESTNET_BASE_URL, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )
    assert _autonomous_market_endpoints(ExecutionMode.PAPER) == (
        DEFAULT_BASE_URL, BINANCE_UM_MARKET_WS_ENDPOINT,
    )
