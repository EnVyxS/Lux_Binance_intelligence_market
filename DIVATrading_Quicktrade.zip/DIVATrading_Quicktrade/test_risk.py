import unittest
from decimal import Decimal
from types import SimpleNamespace

from risk import RISK_USDT, plan_order, validate_fill


D = Decimal


def inputs(side='BUY'):
    symbol = 'SOLUSDT'
    stop, target = ('99.601', '101.209') if side == 'BUY' else ('100.409', '98.801')
    signal = SimpleNamespace(symbol=symbol, side=side, entry_low=D('99.98'), entry_high=D('100.02'),
                             stop=D(stop), target=D(target))
    return dict(
        signal=signal,
        metadata={'symbol': symbol, 'filters': [
            {'filterType': 'PRICE_FILTER', 'tickSize': '0.01', 'minPrice': '0.01', 'maxPrice': '100000'},
            {'filterType': 'LOT_SIZE', 'stepSize': '0.01', 'minQty': '0.01', 'maxQty': '200'},
            {'filterType': 'MARKET_LOT_SIZE', 'stepSize': '0.01', 'minQty': '0.01', 'maxQty': '100'},
            {'filterType': 'MIN_NOTIONAL', 'notional': '5'},
        ]},
        book={'symbol': symbol, 'bidPrice': '100', 'askPrice': '100.01'},
        mark=D('100.005'),
        commission={'symbol': symbol, 'takerCommissionRate': '0.0005'},
        config={'symbol': symbol, 'marginType': 'CROSSED', 'leverage': '20', 'maxNotionalValue': '50000'},
        brackets=[{'symbol': symbol, 'brackets': [{
            'notionalFloor': '0', 'notionalCap': '50000', 'initialLeverage': 50, 'maintMarginRatio': '0.004',
        }]}],
        available=D('3.24'),
    )


class RiskTest(unittest.TestCase):
    def test_long_accounts_for_fees_and_slippage(self):
        params = inputs()
        plan = plan_order(**params)
        self.assertEqual((plan.price, plan.stop, plan.target), (D('100'), D('99.60'), D('101.20')))
        self.assertEqual(plan.quantity, D('0.26'))
        stop_fill = plan.stop * D('0.9995')
        loss_per_unit = plan.price - stop_fill + (plan.price + stop_fill) * D('0.0006')
        self.assertEqual(plan.risk, plan.quantity * loss_per_unit)
        self.assertLessEqual(plan.risk, RISK_USDT)
        self.assertGreater(plan.risk + D('0.01') * loss_per_unit, RISK_USDT)
        validate_fill(plan, plan.quantity, plan.price, params['mark'], params['commission'])
        validate_fill(plan, D('0.11'), D('99.99'), params['mark'], params['commission'])

    def test_short_passive_exit_rounding_and_asymmetric_collateral(self):
        params = inputs('SELL')
        plan = plan_order(**params)
        self.assertEqual((plan.price, plan.stop, plan.target), (D('100.01'), D('100.41'), D('98.81')))
        self.assertLessEqual(plan.risk, RISK_USDT)
        self.assertGreater(plan.required_margin, plan.price * plan.quantity / 20)
        validate_fill(plan, plan.quantity, plan.price, params['mark'], params['commission'])

    def test_low_balance_never_rounds_up_to_minimum(self):
        with self.assertRaisesRegex(ValueError, 'minimum order'):
            plan_order(**(inputs() | {'available': D('0.25')}))

    def test_symbol_requires_current_cross_mode(self):
        params = inputs()
        params['config']['marginType'] = 'ISOLATED'
        with self.assertRaisesRegex(ValueError, 'must already be CROSS'):
            plan_order(**params)

    def test_never_enters_outside_setup_range(self):
        params = inputs()
        params['book'] = {'bidPrice': '100.04', 'askPrice': '100.05'}
        with self.assertRaisesRegex(ValueError, 'outside the setup entry range'):
            plan_order(**params)

    def test_refuses_trigger_prices_at_or_past_mark(self):
        for side, mark in [('BUY', D('99.60')), ('SELL', D('98.70'))]:
            with self.subTest(side=side), self.assertRaisesRegex(ValueError, 'already been reached'):
                plan_order(**(inputs(side) | {'mark': mark}))

    def test_refuses_unprofitable_target_after_costs(self):
        params = inputs()
        params['signal'].target = D('100.73')
        with self.assertRaisesRegex(ValueError, 'after fees and slippage'):
            plan_order(**params)

    def test_limit_must_fit_binance_percent_price_filter(self):
        params = inputs() | {'mark': D('99.93')}
        params['metadata']['filters'].append({'filterType': 'PERCENT_PRICE', 'multiplierUp': '1.0005',
                                              'multiplierDown': '0.9995'})
        with self.assertRaisesRegex(ValueError, 'violates Binance mark price band'):
            plan_order(**params)

    def test_leverage_is_limited_by_notional_tier(self):
        params = inputs()
        params['brackets'][0]['brackets'][0]['initialLeverage'] = 10
        with self.assertRaisesRegex(ValueError, 'minimum order'):
            plan_order(**params)

    def test_enforces_both_limit_and_emergency_market_quantity_step(self):
        params = inputs()
        params['metadata']['filters'][2]['stepSize'] = '0.015'
        self.assertEqual(plan_order(**params).quantity, D('0.24'))

    def test_fill_rejects_unexpected_qty_price_mark_or_fee(self):
        params = inputs()
        plan = plan_order(**params)
        bad_fills = [(D('0.99'), plan.price, params['mark'], params['commission']),
                     (plan.quantity, D('100.01'), params['mark'], params['commission']),
                     (plan.quantity, plan.price, plan.target, params['commission']),
                     (plan.quantity, plan.price, params['mark'], {'takerCommissionRate': '0.001'})]
        for fill in bad_fills:
            with self.subTest(fill=fill), self.assertRaises(ValueError):
                validate_fill(plan, *fill)

    def test_non_finite_exchange_numbers_fail_closed(self):
        for value in ('NaN', 'Infinity', '-1'):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, 'invalid available USDT'):
                plan_order(**(inputs() | {'available': value}))


if __name__ == '__main__':
    unittest.main()
