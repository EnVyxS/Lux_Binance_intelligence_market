"""Offline wire tests for the Binance REST adapter."""

from decimal import Decimal
from hashlib import sha256
import hmac
from io import BytesIO
import json
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit

from exchange import ApiError, Binance


KEY = "offline-fixture-key"
SECRET = "offline-fixture-secret"
SYMBOL = "XRPUSDT"
SERVER_TIME = 1_790_000_000_000


class Reply(BytesIO):
    status = 200

    def __init__(self, payload):
        super().__init__(json.dumps(payload).encode("utf-8"))


def rejected(status, code):
    payload = json.dumps({"code": code, "msg": f"{KEY} {SECRET}"}).encode("utf-8")
    return HTTPError("https://example.invalid", status, "offline fixture", {}, BytesIO(payload))


class ExchangeWireTests(unittest.TestCase):
    def setUp(self):
        self.opener = Mock()
        with patch("exchange.build_opener", return_value=self.opener):
            self.api = Binance("DEMO", KEY, SECRET)

    def script(self, *responses, clock=True):
        values = [Reply({"serverTime": SERVER_TIME})] if clock else []
        values.extend(value if isinstance(value, Exception) else Reply(value) for value in responses)
        self.opener.open.side_effect = values

    def request(self, index=-1):
        return self.opener.open.call_args_list[index].args[0]

    def signed(self, method, path, index=-1):
        request = self.request(index)
        actual_url = urlsplit(request.full_url)
        self.assertEqual((actual_url.scheme, actual_url.netloc, actual_url.path),
                         ("https", "demo-fapi.binance.com", path))
        self.assertEqual(request.get_method(), method)
        self.assertEqual(request.get_header("X-mbx-apikey"), KEY)
        if method == "POST":
            self.assertFalse(actual_url.query)
            self.assertEqual(request.get_header("Content-type"), "application/x-www-form-urlencoded")
            encoded = request.data.decode("ascii")
        else:
            self.assertIsNone(request.data)
            encoded = actual_url.query
        params, signature = encoded.rsplit("&signature=", maxsplit=1)
        self.assertEqual(signature, hmac.new(SECRET.encode("utf-8"), params.encode("ascii"), sha256).hexdigest())
        fields = {key: values[0] for key, values in parse_qs(params).items()}
        self.assertEqual(fields.pop("recvWindow"), "5000")
        self.assertGreaterEqual(int(fields.pop("timestamp")), SERVER_TIME)
        return fields

    def test_public_roots_are_pinned_and_have_no_auth(self):
        self.script({}, {}, clock=False)
        self.api.ping()
        with patch("exchange.build_opener", return_value=self.opener):
            Binance("LIVE", KEY, SECRET).ping()
        for index, host in enumerate(("demo-fapi.binance.com", "fapi.binance.com")):
            with self.subTest(host=host):
                request = self.request(index)
                self.assertEqual(request.full_url, f"https://{host}/fapi/v1/ping")
                self.assertEqual(request.get_method(), "GET")
                self.assertIsNone(request.get_header("X-mbx-apikey"))

    def test_entry_is_post_only_and_queries_by_client_id(self):
        self.script({"status": "NEW"}, {"status": "NEW"}, {"status": "CANCELED"})
        self.api.entry(SYMBOL, "BUY", Decimal("20.00"), Decimal("0.5200"), "qt-entry")
        self.api.get_entry(SYMBOL, "qt-entry")
        self.api.cancel_entry(SYMBOL, "qt-entry")
        self.assertEqual(self.signed("POST", "/fapi/v1/order", 1), {
            "symbol": SYMBOL, "side": "BUY", "positionSide": "BOTH", "type": "LIMIT", "timeInForce": "GTX",
            "quantity": "20.00", "price": "0.5200", "newClientOrderId": "qt-entry", "newOrderRespType": "ACK",
        })
        for method, index in (("GET", 2), ("DELETE", 3)):
            self.assertEqual(self.signed(method, "/fapi/v1/order", index), {
                "symbol": SYMBOL, "origClientOrderId": "qt-entry",
            })
        self.assertEqual(self.request(0).full_url, "https://demo-fapi.binance.com/fapi/v1/time")
        self.assertIsNone(self.request(0).get_header("X-mbx-apikey"))

    def test_stop_and_take_profit_close_position_without_quantity(self):
        self.script({"algoStatus": "NEW"}, {"algoStatus": "NEW"})
        protections = (
            ("STOP_MARKET", Decimal("0.50"), "qt-stop"),
            ("TAKE_PROFIT_MARKET", Decimal("0.55"), "qt-take"),
        )
        for index, (kind, trigger, client_id) in enumerate(protections, 1):
            with self.subTest(kind=kind):
                self.api.protect(SYMBOL, "SELL", kind, trigger, client_id)
                self.assertEqual(self.signed("POST", "/fapi/v1/algoOrder", index), {
                    "algoType": "CONDITIONAL", "symbol": SYMBOL, "side": "SELL", "positionSide": "BOTH",
                    "type": kind, "triggerPrice": str(trigger), "workingType": "MARK_PRICE",
                    "closePosition": "true", "priceProtect": "false", "clientAlgoId": client_id,
                })

    def test_market_flatten_is_reduce_only(self):
        self.script({"status": "FILLED"})
        self.api.flatten(SYMBOL, "SELL", Decimal("7.25"), "qt-flat")
        self.assertEqual(self.signed("POST", "/fapi/v1/order"), {
            "symbol": SYMBOL, "side": "SELL", "positionSide": "BOTH", "type": "MARKET",
            "quantity": "7.25", "reduceOnly": "true", "newClientOrderId": "qt-flat", "newOrderRespType": "RESULT",
        })

    def test_unknown_write_and_definitive_rejection_are_distinct(self):
        self.script(URLError(SECRET), rejected(503, -1007), rejected(400, -5022), rejected(400, -2013))
        for code, uncertain in ((None, True), (-1007, True), (-5022, False)):
            with self.subTest(code=code):
                with self.assertRaises(ApiError) as result:
                    self.api.entry(SYMBOL, "BUY", Decimal("20"), Decimal("0.52"), "qt-entry")
                self.assertEqual(result.exception.code, code)
                self.assertEqual(result.exception.uncertain, uncertain)
                self.assertNotIn(KEY, str(result.exception))
                self.assertNotIn(SECRET, str(result.exception))
        with self.assertRaises(ApiError) as result:
            self.api.get_entry(SYMBOL, "qt-entry")
        self.assertEqual(result.exception.code, -2013)
        self.assertFalse(result.exception.uncertain)
        self.assertEqual(self.opener.open.call_count, 5)

    def test_http_451_reports_location_without_peer_body(self):
        self.script(rejected(451, 0), clock=False)
        with self.assertRaises(ApiError) as result:
            self.api.ping()
        self.assertEqual(result.exception.status, 451)
        self.assertFalse(result.exception.uncertain)
        self.assertIn("restricted location", str(result.exception))
        self.assertNotIn(SECRET, str(result.exception))
        self.assertEqual(self.opener.open.call_count, 1)

    def test_symbol_metadata_accepts_object_or_array_and_binds_symbol(self):
        config = {"symbol": SYMBOL, "marginType": "CROSSED", "leverage": "150"}
        brackets = {"symbol": SYMBOL, "brackets": [{"initialLeverage": 150}]}
        self.script([config], brackets, {"symbol": "OTHERUSDT"})
        self.assertEqual(self.api.symbol_config(SYMBOL), config)
        self.assertEqual(self.api.brackets(SYMBOL), brackets)
        with self.assertRaisesRegex(ApiError, "symbol metadata"):
            self.api.commission(SYMBOL)


if __name__ == "__main__":
    unittest.main()
