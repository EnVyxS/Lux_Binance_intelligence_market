@echo off
setlocal
pushd "%~dp0" || exit /b 1

set "QUICKTRADE_PY=py -3"
%QUICKTRADE_PY% -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto start

set "QUICKTRADE_PY=python"
%QUICKTRADE_PY% -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto start

echo Instal Python 3.10 atau lebih baru dari https://www.python.org/downloads/windows/.
set "QUICKTRADE_EXIT=1"
goto finish

:start
if "%~1"=="" goto preflight
%QUICKTRADE_PY% run.py %*
set "QUICKTRADE_EXIT=%errorlevel%"
goto finish

:preflight
%QUICKTRADE_PY% run.py preflight
set "QUICKTRADE_EXIT=%errorlevel%"

:finish
popd
exit /b %QUICKTRADE_EXIT%
