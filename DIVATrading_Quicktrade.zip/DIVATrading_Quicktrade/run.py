"""Command-line entry point for the standalone Binance trader."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import os
from pathlib import Path
import sys
import time

from engine import Engine, Halt, Store, number
from exchange import ApiError, Binance
from risk import RISK_USDT, plan_order
from strategy import detect_signal, scan_symbols

ROOT = Path(__file__).resolve().parent
CONFIG_KEYS = ("DIVA_QUICK_MODE", "BINANCE_API_KEY", "BINANCE_API_SECRET")
WORKERS = 4
EVALUATION_LIMIT = 12


def log(message):
    print(time.strftime("%Y-%m-%d %H:%M:%S"), message, flush=True)


def config():
    values = {}
    path = ROOT / ".env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            key, equal, value = line.partition("=")
            if equal and key.strip() in CONFIG_KEYS:
                value = value.strip()
                if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                    value = value[1:-1]
                values[key.strip()] = value
    for key in CONFIG_KEYS:
        if key in os.environ:
            values[key] = os.environ[key].strip()
    return values


@contextmanager
def process_lock(path):
    with path.open("a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise Halt("Another Quicktrade process is using this venue's state") from None
        yield


def available(api):
    account = api.account()
    assets = account.get("assets")
    if isinstance(assets, list):
        for asset in assets:
            if asset.get("asset") == "USDT":
                return number(asset.get("availableBalance"))
        return number(0)
    return number(account.get("availableBalance"))


class Scanner:
    def __init__(self, api, symbols):
        self.api = api
        self.symbols = symbols
        self.metadata = {}
        self.exchange_info = {}
        self.refresh_after = 0
        self.cursor = 0

    def candidates(self):
        now = self.api.now_ms()
        if now >= self.refresh_after:
            self.exchange_info = self.api.exchange_info()
            self.metadata = {row["symbol"]: row for row in self.exchange_info["symbols"]}
            self.refresh_after = now + 600_000
        ranked = scan_symbols(self.exchange_info, self.api.tickers(), self.api.books(), limit=len(self.metadata))
        if self.symbols:
            ranked = [symbol for symbol in ranked if symbol in self.symbols]
        if len(ranked) <= EVALUATION_LIMIT:
            return ranked, len(ranked)
        # Keep the most liquid half of the batch and rotate the rest.
        focus, rest = ranked[:6], ranked[6:]
        offset = self.cursor % len(rest)
        self.cursor += EVALUATION_LIMIT - len(focus)
        return focus + (rest[offset:] + rest[:offset])[:EVALUATION_LIMIT - len(focus)], len(ranked)

    def signal(self, symbol):
        latest = self.api.klines(symbol, "1m", 40)
        context = self.api.klines(symbol, "5m", 30)
        return detect_signal(symbol, latest, context, self.api.now_ms())

    def scan(self):
        candidates, eligible = self.candidates()
        log(f"SCAN universe={len(self.metadata)} eligible={eligible} evaluating={','.join(candidates) or 'none'}")
        signals = []
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            attempts = [(symbol, pool.submit(self.signal, symbol)) for symbol in candidates]
            for symbol, task in attempts:
                try:
                    signal = task.result()
                except ApiError as exc:
                    log(f"{symbol} SCAN_READ_FAILED {exc}")
                    continue
                if signal:
                    signals.append(signal)
                    log(f"{symbol} SETUP {signal.side} zone={signal.entry_low}..{signal.entry_high} "
                        f"SL={signal.stop} TP={signal.target}")
        log(f"SCAN setups={len(signals)}")
        return signals

    def plan(self, signal):
        symbol = signal.symbol
        if symbol not in self.metadata:
            self.candidates()
        if symbol not in self.metadata:
            raise ValueError("symbol is missing from current exchange metadata")
        return plan_order(
            signal, self.metadata[symbol], self.api.book(symbol), self.api.mark(symbol),
            self.api.commission(symbol), self.api.symbol_config(symbol), self.api.brackets(symbol),
            available(self.api),
        )


def drain(engine):
    try:
        engine.repricer = None
        end = time.monotonic() + 12
        while engine.active and engine.active["phase"] != "managed" and time.monotonic() < end:
            engine.active["entry_deadline"] = 0
            engine.store.save()
            engine.tick()
            if engine.active and engine.active["phase"] != "managed":
                time.sleep(0.5)
    except (ApiError, Halt, ValueError) as exc:
        log(f"SHUTDOWN reconcile incomplete {exc}")
    if engine.active:
        log(f"SHUTDOWN exchange state retained phase={engine.active['phase']} file={engine.store.path.name}")
    else:
        log("SHUTDOWN no managed exposure")


def trade(engine, scanner):
    next_scan = 0
    delay = 1
    try:
        while True:
            try:
                if engine.active:
                    engine.tick()
                elif engine.api.now_ms() >= next_scan:
                    now = engine.api.now_ms()
                    next_scan = (now // 60_000 + 1) * 60_000 + 1_500
                    for signal in scanner.scan():
                        if engine.seen(signal):
                            continue
                        try:
                            plan = scanner.plan(signal)
                        except (ApiError, ValueError) as exc:
                            log(f"{signal.symbol} ENTRY_SKIP {exc}")
                            continue
                        if engine.enter(signal, plan):
                            break
                delay = 1
                time.sleep(0.8 if engine.active and engine.active["phase"] == "entry" else 2.5)
            except ApiError as exc:
                if exc.status in {418, 429}:
                    delay = max(delay, 30)
                log(f"EXCHANGE_RETRY in {delay}s {exc}")
                if not engine.active and (exc.status in {401, 403, 451} or exc.code in {-2014, -2015}):
                    raise
                time.sleep(delay)
                delay = min(delay * 2, max(delay, 5 if engine.active else 30))
    except KeyboardInterrupt:
        drain(engine)


def main(argv=None):
    parser = argparse.ArgumentParser(description="DIVATrading Quicktrade for Binance USD-M")
    parser.add_argument("--mode", choices=("demo", "live"), help="defaults to DIVA_QUICK_MODE or Demo")
    parser.add_argument("--symbols", help="optional comma-separated subset for the scanner")
    commands = parser.add_subparsers(dest="command")
    commands.add_parser("preflight", help="perform public and signed read-only checks")
    commands.add_parser("scan", help="evaluate setups using public data only")
    execute = commands.add_parser("run", help="place and manage exchange orders")
    execute.add_argument("--confirm-live", action="store_true", help="authorize real mainnet order routing")
    args = parser.parse_args(argv)
    command = args.command or "preflight"
    try:
        values = config()
        configured = values.get("DIVA_QUICK_MODE", "").lower()
        mode = args.mode or configured or "demo"
        if mode not in {"demo", "live"}:
            raise Halt("DIVA_QUICK_MODE must be DEMO or LIVE")
        if command == "run" and mode == "live" and not args.confirm_live:
            raise Halt("Live trading requires run --confirm-live")
        symbols = {value.strip().upper() for value in args.symbols.split(",") if value.strip()} if args.symbols else set()
        if command == "scan":
            api = Binance(mode)
            api.ping()
            api.sync_clock()
            Scanner(api, symbols).scan()
            return 0
        if configured and mode != configured:
            raise Halt("Signed requests require DIVA_QUICK_MODE to match the selected venue")
        key, secret = (values.get(name, "") for name in CONFIG_KEYS[1:])
        if not key or not secret:
            raise Halt("Set the Binance API key and secret for the selected venue in .env")
        api = Binance(mode, key, secret)
        scanner = Scanner(api, symbols)
        state_path = ROOT / f".state-{mode}.json"
        if command == "preflight":
            engine = Engine(api, Store(state_path, key), log)
            engine.verify()
            log(f"PREFLIGHT PASS venue={mode.upper()} available_usdt={available(api)} "
                f"active_state={bool(engine.active)}")
            return 0
        with process_lock(ROOT / f".state-{mode}.lock"):
            engine = Engine(api, Store(state_path, key), log, repricer=scanner.plan)
            engine.verify()
            log(f"RUN venue={mode.upper()} planned_risk_usdt={RISK_USDT} cross=true max_positions=1")
            trade(engine, scanner)
        return 0
    except (ApiError, Halt, OSError, ValueError) as exc:
        log(f"STOP {exc}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
