# DIVATrading Quicktrade

Bot mandiri untuk Binance USDⓈ-M Futures dengan satu posisi maksimum, margin **Cross** dan mode posisi **One-way**. Quicktrade menggunakan leverage yang sudah terpasang pada simbol dan membatasi risiko rencana ke **0,15 USDT per trade**, termasuk estimasi fee dan cadangan slippage. Selisih waktu antara baca harga dan eksekusi, gap, serta funding bila posisi melewati jadwal pembayaran dapat menambah rugi aktual.

## Menjalankan di Windows

1. Ekstrak folder, instal Python 3.10 atau lebih baru, lalu buka PowerShell dari folder yang berisi `START_WINDOWS.bat`. Modul memakai pustaka standar Python.
2. Salin `.env.example` menjadi `.env`. Isi `BINANCE_API_KEY` dan `BINANCE_API_SECRET` dari **Binance Demo Trading**. Biarkan `DIVA_QUICK_MODE=DEMO`.
3. Jalankan preflight untuk mengecek koneksi dan akun secara baca-saja. Jalankan scan untuk melihat simbol dan setup dari data publik. Gunakan `run` saat ingin mengaktifkan pengiriman order Demo.

```powershell
if (!(Test-Path .env)) { Copy-Item .env.example .env }
notepad .env
.\START_WINDOWS.bat --mode demo preflight
.\START_WINDOWS.bat --mode demo scan
.\START_WINDOWS.bat --mode demo run
```

Launcher tanpa argumen menjalankan `preflight`. Di Linux atau macOS, gunakan `python3 run.py` dengan argumen yang sama. Simpan `.env` di komputer sendiri. Untuk membatasi scanner ke simbol tertentu, tambahkan `--symbols XRPUSDT,SOLUSDT` sebelum `scan` atau `run`. Simbol tetap harus lolos filter likuiditas.

Untuk mainnet, atur `DIVA_QUICK_MODE=LIVE` dan ganti kedua kredensial dengan API key mainnet di `.env`. Pastikan akun dalam mode One-way dan Single-Asset, serta set simbol yang ingin diperdagangkan ke Cross dari Binance. Mulai dari akun tanpa posisi atau order aktif. Jalankan satu instans bot per akun dan hindari aktivitas manual pada akun selama bot aktif.

```powershell
.\START_WINDOWS.bat --mode live preflight
.\START_WINDOWS.bat --mode live run --confirm-live
```

`run --confirm-live` mengirim order dengan saldo asli ketika setup memenuhi syarat. Pada pengujian 19 November 2026, REST Demo dan mainnet sama-sama mengembalikan HTTP 451 dari cloud. Windows sebelumnya bisa mengakses REST mainnet. Jika preflight mengembalikan 451, jalankan dari koneksi yang diizinkan Binance.

## Cara bot mengambil dan mengelola posisi

- Scanner menilai kontrak perpetual USDT aktif menggunakan volume dan spread. Setiap candle, bot mengevaluasi hingga 12 simbol. Enam teratas diprioritaskan dan enam tempat lain bergantian di antara simbol yang layak.
- Bot memuat candle terbaru lewat REST saat mulai. Bot mencari sweep dan reclaim pada candle 1 menit yang sudah tutup, dengan struktur 5 menit sebagai konteks.
- Entry memakai limit post-only. Bot dapat mengganti harga sekali saat entry awal berakhir tanpa fill atau Binance menolak order post-only, selama setup masih aktif dan harga ada di zona. Partial fill dipertahankan sesuai ukuran yang terisi dan sisa entry dibatalkan.
- SL berada di luar ekstrem sweep dengan buffer. TP memakai target likuiditas lawan yang tersedia atau proyeksi dari jarak SL. Bot memasang keduanya sebagai order bersyarat di Binance. Pertahankan `.state-demo.json` atau `.state-live.json` agar bot dapat memeriksa order setelah restart.
- Bot melewati setup ketika saldo, filter minimum Binance, atau batas risiko menghasilkan ukuran order yang tak layak. `run` menunggu setup yang valid.

`PREFLIGHT PASS` mengonfirmasi koneksi dan pemeriksaan akun. `RUN` menandakan bot aktif, `SCAN` menampilkan hasil pemindaian, `ENTRY_SKIP` memberi alasan setup dilewati, dan `ENTRY_GTX` menandakan Binance menerima entry. `PROTECTED` berarti bot telah mengonfirmasi SL dan TP. `FLAT verified` berarti posisi dan order terkait telah bersih. Jika status entry belum bisa dipastikan, bot mencatat `ENTRY_ACK_UNKNOWN` atau `ENTRY_STATUS_PENDING` dan menahan slot sampai statusnya terkonfirmasi di Binance.

Tekan `Ctrl+C` sekali untuk menghentikan bot. Bot mencoba merekonsiliasi entry atau pembatalan yang masih berjalan. Entry GTX yang terbuka saat koneksi atau proses putus masih dapat terisi sebelum bot memasang proteksi. Untuk posisi yang telah menampilkan `PROTECTED`, SL dan TP tetap di Binance. Jika log menampilkan `SHUTDOWN exchange state retained`, pertahankan file status dan gunakan akun serta API key yang sama saat restart. Periksa posisi dan order langsung di Binance jika rekonsiliasi tertunda.

## Uji offline

Jalankan dari folder modul dengan Python bawaan Windows. Pengujian memakai data sintetis dan simulator exchange.

```powershell
py -3 -m unittest discover -v
py -3 run.py --help
```
