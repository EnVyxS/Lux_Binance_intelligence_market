"""Exercise the operator entry point without contacting Binance."""

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import run


class LaunchTests(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        mock_root = patch.object(run, "ROOT", Path(temporary.name))
        mock_root.start()
        self.addCleanup(mock_root.stop)
        self.output = StringIO()
        self.values = {
            "DIVA_QUICK_MODE": "DEMO", "BINANCE_API_KEY": "dummy", "BINANCE_API_SECRET": "dummy-secret",
        }

    def invoke(self, args):
        with redirect_stdout(self.output), patch.object(run, "config", return_value=self.values):
            return run.main(args)

    @patch.object(run, "Binance")
    def test_live_run_without_confirmation_never_opens_connection(self, client):
        self.values["DIVA_QUICK_MODE"] = "LIVE"
        self.assertEqual(2, self.invoke(["--mode", "live", "run"]))
        client.assert_not_called()
        self.assertIn("requires run --confirm-live", self.output.getvalue())

    @patch.object(run, "Binance")
    def test_live_preflight_refuses_credentials_configured_for_demo(self, client):
        self.assertEqual(2, self.invoke(["--mode", "live", "preflight"]))
        client.assert_not_called()
        self.assertIn("match the selected venue", self.output.getvalue())

    @patch.object(run, "Binance")
    def test_default_command_is_read_only_demo_preflight(self, client):
        api = client.return_value
        api.account_config.return_value = {"canTrade": True, "multiAssetsMargin": False}
        api.position_mode.return_value = False
        api.positions.return_value = api.orders.return_value = api.algo_orders.return_value = []
        api.account.return_value = {"assets": [{"asset": "USDT", "availableBalance": "2.95"}]}
        self.assertEqual(0, self.invoke([]))
        client.assert_called_once_with("demo", "dummy", "dummy-secret")
        api.entry.assert_not_called()
        api.protect.assert_not_called()
        api.flatten.assert_not_called()
        self.assertIn("PREFLIGHT PASS venue=DEMO available_usdt=2.95", self.output.getvalue())
