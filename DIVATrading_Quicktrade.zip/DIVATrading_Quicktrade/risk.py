"""Price and size a Binance USDⓈ-M order within a fixed planned loss budget."""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from math import lcm


RISK_USDT = Decimal('0.15')
SLIPPAGE = Decimal('0.0005')
FEE_BUFFER = Decimal('1.20')
MARGIN_FRACTION = Decimal('0.75')
MIN_NET_REWARD_RISK = Decimal('1.15')


@dataclass(frozen=True)
class Plan:
    symbol: str
    side: str
    quantity: Decimal
    price: Decimal
    stop: Decimal
    target: Decimal
    risk: Decimal
    required_margin: Decimal
    maker_rate: Decimal
    taker_rate: Decimal


def _decimal(value, field, *, allow_zero=False):
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f'invalid {field}') from exc
    if not number.is_finite() or number < 0 or (not allow_zero and number == 0):
        raise ValueError(f'invalid {field}')
    return number


def _quantize(value, step, rounding=ROUND_FLOOR):
    return (value / step).to_integral_value(rounding=rounding) * step


def _fee_rates(commission, symbol):
    if not isinstance(commission, dict) or commission.get('symbol', symbol) != symbol:
        raise ValueError('commission symbol mismatch')
    taker = _decimal(commission.get('takerCommissionRate'), 'taker commission', allow_zero=True)
    maker = _decimal(commission.get('makerCommissionRate', taker), 'maker commission', allow_zero=True)
    if maker >= 1 or taker >= 1:
        raise ValueError('invalid commission')
    return maker * FEE_BUFFER, taker * FEE_BUFFER


def _exit_costs(side, entry, stop, target, maker, taker):
    direction = 1 if side == 'BUY' else -1
    stop_fill = stop * (1 - direction * SLIPPAGE)
    target_fill = target * (1 - direction * SLIPPAGE)
    entry_fee = entry * maker
    stop_fees = entry_fee + stop_fill * taker
    loss = direction * (entry - stop_fill) + stop_fees
    reward = direction * (target_fill - entry) - entry_fee - target_fill * taker
    return loss, reward, stop_fees, stop_fill


def _check_protection(side, price, mark, stop, target):
    if side == 'BUY' and stop < min(price, mark) and max(price, mark) < target:
        return
    if side == 'SELL' and target < min(price, mark) and max(price, mark) < stop:
        return
    raise ValueError('stop or target has already been reached, or is on the wrong side')


def _get_brackets(raw, symbol):
    if isinstance(raw, list):
        matches = [row for row in raw if isinstance(row, dict) and row.get('symbol') == symbol]
        raw = matches[0] if len(matches) == 1 else {}
    if not isinstance(raw, dict) or raw.get('symbol', symbol) != symbol:
        raise ValueError('leverage bracket symbol mismatch')
    if not isinstance(raw.get('brackets'), list) or not raw['brackets']:
        raise ValueError('missing account leverage brackets')
    if any(not isinstance(tier, dict) for tier in raw['brackets']):
        raise ValueError('invalid maintenance bracket')
    return raw['brackets']


def _common_step(first, second):
    if not second:
        return first
    exponent = min(first.as_tuple().exponent, second.as_tuple().exponent)
    return Decimal(lcm(int(first.scaleb(-exponent)), int(second.scaleb(-exponent)))).scaleb(exponent)


def _quantity_limits(filters):
    lot = filters['LOT_SIZE']
    market_lot = filters.get('MARKET_LOT_SIZE', {})
    step = _decimal(lot.get('stepSize'), 'quantity step')
    market_step = _decimal(market_lot.get('stepSize', '0'), 'market quantity step', allow_zero=True)
    mins = [_decimal(rule.get('minQty', '0'), 'minimum quantity', allow_zero=True)
            for rule in (lot, market_lot)]
    max_qty = _decimal(lot.get('maxQty'), 'maximum quantity')
    market_max = _decimal(market_lot.get('maxQty', '0'), 'market maximum quantity', allow_zero=True)
    return _common_step(step, market_step), max(mins), min(max_qty, market_max or max_qty)


def plan_order(signal, metadata, book, mark, commission, config, brackets, available):
    """Size a passive order for a flat, one-way, single-asset cross account."""
    symbol, side = signal.symbol, signal.side
    if side not in {'BUY', 'SELL'}:
        raise ValueError('invalid order side')
    if any(not isinstance(payload, dict) or payload.get('symbol', symbol) != symbol
           for payload in (metadata, book, config)):
        raise ValueError('order input symbol mismatch')
    if str(config.get('marginType', '')).upper() not in {'CROSSED', 'CROSS'}:
        raise ValueError('symbol margin mode must already be CROSS')
    leverage = _decimal(config.get('leverage'), 'current leverage')
    if leverage != leverage.to_integral_value() or leverage < 1:
        raise ValueError('invalid current leverage')
    available = _decimal(available, 'available USDT')
    mark = _decimal(mark, 'mark price')
    bid = _decimal(book.get('bidPrice'), 'best bid')
    ask = _decimal(book.get('askPrice'), 'best ask')
    if bid >= ask:
        raise ValueError('crossed or invalid order book')

    rules = metadata.get('filters')
    if not isinstance(rules, list) or any(not isinstance(rule, dict) for rule in rules):
        raise ValueError('invalid exchange price and lot filters')
    filters = {rule.get('filterType'): rule for rule in rules}
    if not {'PRICE_FILTER', 'LOT_SIZE'} <= filters.keys():
        raise ValueError('missing exchange price or lot filter')
    price_filter = filters['PRICE_FILTER']
    tick = _decimal(price_filter.get('tickSize'), 'price tick')
    min_price = _decimal(price_filter.get('minPrice', '0'), 'minimum price', allow_zero=True)
    max_price = _decimal(price_filter.get('maxPrice', '0'), 'maximum price', allow_zero=True)
    rounding = ROUND_FLOOR if side == 'BUY' else ROUND_CEILING
    price = _quantize(bid if side == 'BUY' else ask, tick, rounding)
    stop = _quantize(_decimal(signal.stop, 'stop'), tick, rounding)
    target = _quantize(_decimal(signal.target, 'target'), tick, rounding)
    if not _decimal(signal.entry_low, 'entry low') <= price <= _decimal(signal.entry_high, 'entry high'):
        raise ValueError('passive price is outside the setup entry range')
    for level in (price, stop, target):
        if level <= 0 or level < min_price or (max_price and level > max_price):
            raise ValueError('price violates Binance symbol limits')
    _check_protection(side, price, mark, stop, target)
    percent_price = filters.get('PERCENT_PRICE')
    if percent_price:
        up = _decimal(percent_price.get('multiplierUp'), 'upper price multiplier')
        down = _decimal(percent_price.get('multiplierDown'), 'lower price multiplier')
        if (side == 'BUY' and price > mark * up) or (side == 'SELL' and price < mark * down):
            raise ValueError('passive price violates Binance mark price band')

    maker, taker = _fee_rates(commission, symbol)
    loss, reward, fees, stop_fill = _exit_costs(side, price, stop, target, maker, taker)
    if reward < loss * MIN_NET_REWARD_RISK:
        raise ValueError('target reward/risk is too low after fees and slippage')
    step, min_qty, max_qty = _quantity_limits(filters)
    min_filter = filters.get('MIN_NOTIONAL', {})
    min_notional = _decimal(min_filter.get('notional', min_filter.get('minNotional', '0')),
                            'minimum notional', allow_zero=True)
    notional_filter = filters.get('NOTIONAL', {})
    min_notional = max(min_notional,
                       _decimal(notional_filter.get('minNotional', '0'), 'minimum notional', allow_zero=True))
    max_notional = _decimal(notional_filter.get('maxNotional', '0'), 'maximum notional', allow_zero=True)
    worst_price = max(price, mark, stop_fill)
    initial_margin = worst_price / leverage + fees
    margin_budget = available * MARGIN_FRACTION
    quantity_bound = min(max_qty, RISK_USDT / loss, margin_budget / initial_margin)
    if max_notional:
        quantity_bound = min(quantity_bound, max_notional / price)
    configured_cap = config.get('maxNotionalValue')
    if configured_cap is not None and str(configured_cap).upper() != 'INF':
        quantity_bound = min(quantity_bound, _decimal(configured_cap, 'current notional cap') / worst_price)

    quantity = Decimal('0')
    for tier in _get_brackets(brackets, symbol):
        tier_cap = _decimal(tier.get('notionalCap'), 'tier cap')
        tier_floor = _decimal(tier.get('notionalFloor'), 'tier floor', allow_zero=True)
        tier_leverage = _decimal(tier.get('initialLeverage'), 'tier maximum leverage')
        ratio = _decimal(tier.get('maintMarginRatio'), 'maintenance ratio', allow_zero=True)
        if tier_cap <= tier_floor or ratio >= 1:
            raise ValueError('invalid maintenance bracket')
        if leverage > tier_leverage:
            continue
        # Assume no maintenance deductions and require equity for twice the
        # budgeted loss plus maintenance, even at the adverse stop fill.
        liquidation_bound = margin_budget / (loss * 2 + ratio * worst_price)
        candidate = _quantize(min(quantity_bound, liquidation_bound, tier_cap / worst_price), step)
        if candidate * worst_price >= tier_cap:
            candidate -= step
        if candidate * worst_price >= tier_floor:
            quantity = max(quantity, candidate)

    if quantity <= 0 or quantity < min_qty or quantity * price < min_notional:
        raise ValueError('risk, margin, or leverage cannot meet exchange minimum order size')
    return Plan(symbol, side, quantity, price, stop, target, quantity * loss, quantity * initial_margin, maker, taker)


def validate_fill(plan, qty, price, mark, commission=None):
    """Reject a reported fill that breaks the original limit, levels or loss budget."""
    quantity = _decimal(qty, 'fill quantity')
    price = _decimal(price, 'fill price')
    mark = _decimal(mark, 'mark price')
    if quantity > plan.quantity:
        raise ValueError('filled quantity exceeds the original order')
    if (plan.side == 'BUY' and price > plan.price) or (plan.side == 'SELL' and price < plan.price):
        raise ValueError('fill price exceeded the original order limit')
    _check_protection(plan.side, price, mark, plan.stop, plan.target)
    rates = (plan.maker_rate, plan.taker_rate) if commission is None else _fee_rates(commission, plan.symbol)
    loss, _, _, _ = _exit_costs(plan.side, price, plan.stop, plan.target, *rates)
    if quantity * loss > min(plan.risk, RISK_USDT):
        raise ValueError('fill exceeds the original estimated loss budget')
