import unittest
from decimal import Decimal

from strategy import MINUTE_MS, detect_signal, scan_symbols


NOW_MS = 7_200_010


def candles(prices, interval=MINUTE_MS):
    open_ms = (NOW_MS // interval - len(prices)) * interval
    rows = []
    for prices_in_bar in prices:
        rows.append([open_ms, *prices_in_bar, "0", open_ms + interval - 1])
        open_ms += interval
    return rows


def mirror(prices):
    return [
        tuple(str(200 - Decimal(price)) for price in (open_price, low, high, close))
        for open_price, high, low, close in prices
    ]


class StrategyTests(unittest.TestCase):
    def setUp(self):
        self.minute_prices = [("100", "100.8", "99.6", "100.2")] * 28
        self.minute_prices[15] = ("100.2", "101.8", "99.6", "100.4")
        self.minute_prices[-1] = ("99.8", "100.6", "99.35", "100.4")
        self.context_prices = [("100", "101", "99", "100")] * 14

    def get_signal(self, minute_prices=None, context_prices=None, now_ms=NOW_MS):
        return detect_signal(
            "TESTUSDT",
            candles(minute_prices or self.minute_prices),
            candles(context_prices or self.context_prices, 5 * MINUTE_MS),
            now_ms,
        )

    def test_long_reclaims_old_low_and_targets_before_nearest_confirmed_high(self):
        signal = self.get_signal()
        self.assertIsNotNone(signal)
        self.assertEqual(signal.side, "BUY")
        self.assertLess(signal.stop, Decimal("99.35"))
        self.assertGreater(signal.entry_low, Decimal("99.6"))
        self.assertLess(signal.entry_low, signal.entry_high)
        self.assertGreater(signal.target, signal.entry_high)
        self.assertLess(signal.target, Decimal("101.8"))

    def test_short_mirrors_sweep_and_orders_levels(self):
        buy = self.get_signal()
        sell = self.get_signal(mirror(self.minute_prices), mirror(self.context_prices))
        self.assertIsNotNone(sell)
        self.assertEqual(sell.side, "SELL")
        self.assertAlmostEqual(sell.entry_low, 200 - buy.entry_high)
        self.assertAlmostEqual(sell.entry_high, 200 - buy.entry_low)
        self.assertAlmostEqual(sell.stop, 200 - buy.stop)
        self.assertAlmostEqual(sell.target, 200 - buy.target)

    def test_confirmation_one_bar_after_sweep(self):
        self.minute_prices[-2] = ("99.9", "100.3", "99.25", "99.4")
        self.minute_prices[-1] = ("99.5", "100.65", "99.5", "100.45")
        signal = self.get_signal()
        self.assertIsNotNone(signal)
        self.assertEqual(signal.side, "BUY")
        self.assertLess(signal.stop, Decimal("99.25"))

    def test_no_signal_against_strong_five_minute_structure(self):
        self.context_prices[:8] = [("103", "104", "102", "103")] * 8
        self.assertIsNone(self.get_signal())

    def test_ignores_open_bar_and_rejects_stale_closed_bar(self):
        minute_rows = candles(self.minute_prices)
        open_ms = minute_rows[-1][6] + 1
        minute_rows.append([open_ms, "100", "140", "10", "12", "0", open_ms + MINUTE_MS - 1])
        context_rows = candles(self.context_prices, 5 * MINUTE_MS)
        self.assertEqual(detect_signal("TESTUSDT", minute_rows, context_rows, NOW_MS), self.get_signal())
        self.assertIsNone(self.get_signal(now_ms=NOW_MS + 76_000))

    def test_gap_near_end_rejects_insufficient_contiguous_history(self):
        minute_rows = candles(self.minute_prices)
        del minute_rows[-4]
        self.assertIsNone(detect_signal("TESTUSDT", minute_rows, candles(self.context_prices, 5 * MINUTE_MS), NOW_MS))

    def test_small_body_does_not_trigger_entry(self):
        self.minute_prices[-1] = ("100.2", "100.6", "99.35", "100.4")
        self.assertIsNone(self.get_signal())

    def test_excessive_range_does_not_trigger_entry(self):
        self.minute_prices[-1] = ("99.8", "105.0", "99.35", "104.7")
        self.assertIsNone(self.get_signal())

    def test_scanner_filters_unhealthy_pairs_and_caps_work_after_ranking(self):
        active = {
            "status": "TRADING",
            "contractType": "PERPETUAL",
            "quoteAsset": "USDT",
        }
        metadata = [{"symbol": f"PAIR{i}USDT", **active} for i in range(20)]
        metadata[-1]["status"] = "PENDING_TRADING"
        metadata[-2]["contractType"] = "CURRENT_QUARTER"
        metadata[-3]["quoteAsset"] = "USDC"
        tickers = [{"symbol": row["symbol"], "quoteVolume": str(100_000_000 * (i + 1))} for i, row in enumerate(metadata)]
        tickers[-4]["quoteVolume"] = "5000"
        books = [{"symbol": row["symbol"], "bidPrice": "1.0", "askPrice": "1.0001"} for row in metadata]
        books[-5]["askPrice"] = "1.1"
        books[-6]["bidPrice"] = "NaN"
        ranked = scan_symbols({"symbols": metadata}, tickers, books)
        self.assertEqual(ranked, [f"PAIR{i}USDT" for i in range(13, 1, -1)])
        self.assertEqual(scan_symbols({"symbols": metadata}, tickers, books, limit=2), ranked[:2])


if __name__ == "__main__":
    unittest.main()
