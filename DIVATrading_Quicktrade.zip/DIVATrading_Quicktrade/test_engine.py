"""Offline replays of entry, protection, and interrupted execution."""

from decimal import Decimal as D
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from engine import Engine, Halt, Store
from exchange import ApiError
from risk import plan_order
from strategy import Signal


SYMBOL = "SOLUSDT"
MARK = D("100.01")
BOOK = {"bidPrice": "100", "askPrice": "100.01"}
COMMISSION = {"takerCommissionRate": "0.0005", "makerCommissionRate": "0.0002"}
CONFIG = {"symbol": SYMBOL, "marginType": "CROSSED", "leverage": "20", "maxNotionalValue": "100000"}
BRACKETS = {"symbol": SYMBOL, "brackets": [
    {"bracket": 1, "notionalFloor": "0", "notionalCap": "50000", "initialLeverage": 50,
     "maintMarginRatio": "0.004", "cum": "0"},
]}
METADATA = {"symbol": SYMBOL, "filters": [
    {"filterType": "PRICE_FILTER", "tickSize": "0.01", "minPrice": "0.01", "maxPrice": "2000"},
    {"filterType": "LOT_SIZE", "stepSize": "0.01", "minQty": "0.01", "maxQty": "1000"},
    {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.01", "minQty": "0.01", "maxQty": "1000"},
    {"filterType": "MIN_NOTIONAL", "notional": "5"},
]}


class ExchangeReplay:
    def __init__(self):
        self.clock = 1_800_000_060_020
        self.amount = D("0")
        self.average = D("0")
        self.standard = {}
        self.algo = {}
        self.writes = []
        self.reject_stop = False
        self.reject_entry = False
        self.drop_entry_ack = False
        self.lose_entry_request = False
        self.drop_stop_ack = False
        self.hide_entry = False
        self.hide_entry_on_stop = False
        self.fill_during_cancel = D("0")
        self.stale_flat_reads = 0

    def ping(self):
        return {}

    def sync_clock(self):
        return self.clock

    def now_ms(self):
        return self.clock

    def account_config(self):
        return {"canTrade": True, "multiAssetsMargin": False}

    def position_mode(self):
        return False

    def account(self):
        rows = self._position_rows()
        for row in rows:
            row.pop("entryPrice")
            row.pop("markPrice")
            row.pop("liquidationPrice")
        return {"availableBalance": "3.24", "totalWalletBalance": "3.24", "positions": rows}

    def positions(self, symbol=None):
        if self.stale_flat_reads:
            self.stale_flat_reads -= 1
            return []
        return self._position_rows(symbol)

    def _position_rows(self, symbol=None):
        if not self.amount or symbol not in (None, SYMBOL):
            return []
        return [{"symbol": SYMBOL, "positionSide": "BOTH", "positionAmt": str(self.amount),
                 "markPrice": str(MARK), "entryPrice": str(self.average), "liquidationPrice": "0.00"}]

    def orders(self, symbol=None):
        return [row.copy() for row in self.standard.values()
                if row["status"] in {"NEW", "PARTIALLY_FILLED"} and symbol in (None, row["symbol"])]

    def algo_orders(self, symbol=None):
        return [row.copy() for row in self.algo.values()
                if row["algoStatus"] == "NEW" and symbol in (None, row["symbol"])]

    def mark(self, symbol):
        return MARK

    def commission(self, symbol):
        return COMMISSION.copy()

    def symbol_config(self, symbol):
        return CONFIG.copy()

    def entry(self, symbol, side, quantity, price, client_id):
        self.writes.append(("entry", client_id))
        if self.lose_entry_request:
            raise ApiError("simulated request lost before Binance", uncertain=True)
        if self.reject_entry:
            raise ApiError("simulated post-only rejection", code=-5022)
        self.standard[client_id] = {
            "symbol": symbol, "side": side, "positionSide": "BOTH", "type": "LIMIT", "timeInForce": "GTX",
            "clientOrderId": client_id, "origQty": str(quantity), "price": str(price), "avgPrice": "0",
            "status": "NEW", "executedQty": "0", "orderId": len(self.standard) + 1,
        }
        if self.drop_entry_ack:
            raise ApiError("simulated missing ACK", uncertain=True)
        return self.standard[client_id].copy()

    def get_entry(self, symbol, client_id):
        if self.hide_entry or client_id not in self.standard:
            raise ApiError("simulated missing order", code=-2013)
        return self.standard[client_id].copy()

    def cancel_entry(self, symbol, client_id):
        self.writes.append(("cancel_entry", client_id))
        if client_id not in self.standard:
            raise ApiError("simulated missing order", code=-2011)
        if self.fill_during_cancel:
            self.fill(client_id, self.fill_during_cancel)
            self.fill_during_cancel = D("0")
        self.standard[client_id]["status"] = "CANCELED"
        return self.standard[client_id].copy()

    def fill(self, client_id, quantity):
        row = self.standard[client_id]
        self.amount = quantity if row["side"] == "BUY" else -quantity
        self.average = D(row["price"])
        row["executedQty"] = str(quantity)
        row["avgPrice"] = str(self.average)
        row["status"] = "FILLED" if quantity == D(row["origQty"]) else "PARTIALLY_FILLED"

    def protect(self, symbol, side, kind, trigger, client_id):
        self.writes.append((kind, client_id))
        if kind == "STOP_MARKET" and self.hide_entry_on_stop:
            self.hide_entry = True
        if kind == "STOP_MARKET" and self.reject_stop:
            raise ApiError("simulated invalid stop", code=-2021)
        self.algo[client_id] = {
            "symbol": symbol, "side": side, "positionSide": "BOTH", "orderType": kind,
            "clientAlgoId": client_id, "algoStatus": "NEW", "algoId": len(self.algo) + 1,
            "triggerPrice": str(trigger), "workingType": "MARK_PRICE", "closePosition": True,
        }
        if kind == "STOP_MARKET" and self.drop_stop_ack:
            raise ApiError("simulated missing stop ACK", uncertain=True)
        return self.algo[client_id].copy()

    def get_protection(self, client_id):
        if client_id not in self.algo:
            raise ApiError("simulated missing algo", code=-2013)
        return self.algo[client_id].copy()

    def cancel_protection(self, client_id):
        self.writes.append(("cancel_protection", client_id))
        if client_id not in self.algo:
            raise ApiError("simulated missing algo", code=-2011)
        self.algo[client_id]["algoStatus"] = "CANCELED"
        return self.algo[client_id].copy()

    def flatten(self, symbol, side, quantity, client_id):
        self.writes.append(("flatten", client_id))
        if (self.amount > 0 and side != "SELL") or (self.amount < 0 and side != "BUY"):
            raise AssertionError("Emergency order would increase exposure")
        if quantity != abs(self.amount):
            raise AssertionError("Emergency order does not match remaining position")
        self.standard[client_id] = {
            "symbol": symbol, "side": side, "clientOrderId": client_id, "status": "FILLED",
            "positionSide": "BOTH", "avgPrice": str(MARK), "executedQty": str(quantity),
            "reduceOnly": True, "orderId": len(self.standard) + 1,
        }
        self.amount = D("0")
        return self.standard[client_id].copy()

    def trigger(self, client_id):
        self.algo[client_id]["algoStatus"] = "FINISHED"
        self.amount = D("0")


class EngineReplayTests(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.path = Path(temporary.name) / ".state-demo.json"
        self.api = ExchangeReplay()
        self.logs = []
        self.engine = self.open_engine()
        self.signal = Signal(SYMBOL, "BUY", self.api.now_ms() - 21, D("99.95"), D("100.05"), D("99.60"), D("101.20"))
        self.plan = plan_order(self.signal, METADATA, BOOK, MARK, COMMISSION, CONFIG, BRACKETS, D("3.24"))

    def open_engine(self):
        engine = Engine(self.api, Store(self.path, "dummy replay key"), self.logs.append)
        engine.verify()
        return engine

    def enter(self):
        self.engine.enter(self.signal, self.plan)
        return self.engine.store.data["active"]["entry_id"]

    def event_names(self):
        return [event for event, _ in self.api.writes]

    def tick(self, count=4):
        for _ in range(count):
            if self.engine.store.data["active"] is None:
                break
            self.api.clock += 1000
            self.engine.tick()

    def test_filled_entry_sets_protection_and_exit_cancels_sibling(self):
        entry_id = self.enter()
        self.api.fill(entry_id, self.plan.quantity)
        self.tick()

        stop_id = self.engine.store.data["active"]["stop_id"]
        target_id = self.engine.store.data["active"]["target_id"]
        self.assertEqual(["entry", "STOP_MARKET", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual(D(self.api.algo[stop_id]["triggerPrice"]), self.plan.stop)
        self.assertEqual(D(self.api.algo[target_id]["triggerPrice"]), self.plan.target)
        self.assertTrue(all(row["closePosition"] and row["side"] == "SELL" for row in self.api.algo_orders()))

        self.api.trigger(target_id)
        self.tick()
        self.assertEqual([], self.api.algo_orders())
        self.assertIn(("cancel_protection", stop_id), self.api.writes)
        self.assertIsNone(self.engine.store.data["active"])

    def test_zero_fill_timeout_cancels_without_protection(self):
        self.enter()
        self.api.clock += 9000
        self.tick()
        self.assertEqual(["entry", "cancel_entry"], self.event_names())
        self.assertEqual([], self.api.orders())
        self.assertIsNone(self.engine.store.data["active"])

    def test_single_stale_flat_read_does_not_cancel_working_protection(self):
        entry_id = self.enter()
        self.api.fill(entry_id, self.plan.quantity)
        self.tick()

        self.api.stale_flat_reads = 1
        self.tick(count=1)
        self.assertEqual(["entry", "STOP_MARKET", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual(2, len(self.api.algo_orders()))
        self.assertIsNotNone(self.engine.store.data["active"])

    def test_partial_fill_sets_stop_before_canceling_unfilled_remainder(self):
        entry_id = self.enter()
        self.api.fill(entry_id, D("0.13"))
        self.tick()
        self.assertEqual(["entry", "STOP_MARKET", "cancel_entry", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual("CANCELED", self.api.standard[entry_id]["status"])
        self.assertEqual(D("0.13"), self.api.amount)
        self.assertTrue(all(row["closePosition"] for row in self.api.algo_orders()))

    def test_fill_racing_timeout_cancellation_still_gets_protection(self):
        self.enter()
        self.api.fill_during_cancel = D("0.11")
        self.api.clock += 9000
        self.tick()
        self.assertEqual(["entry", "cancel_entry", "STOP_MARKET", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual(D("0.11"), self.api.amount)

    def test_stop_rejection_cancels_entry_and_flattens_partial_fill(self):
        entry_id = self.enter()
        self.api.fill(entry_id, D("0.13"))
        self.api.reject_stop = True
        with self.assertRaises(Halt):
            self.tick()
        self.assertEqual(["entry", "STOP_MARKET", "cancel_entry", "flatten"], self.event_names())
        self.assertEqual(0, self.api.amount)
        self.assertEqual([], self.api.orders())
        self.assertEqual([], self.api.algo_orders())

    def test_restart_queries_persisted_client_id_after_missing_entry_ack(self):
        self.api.drop_entry_ack = True
        try:
            self.enter()
        except ApiError as error:
            self.assertTrue(error.uncertain)
        entry_id = next(iter(self.api.standard))
        self.api.fill(entry_id, self.plan.quantity)

        self.engine = self.open_engine()
        self.assertEqual(entry_id, self.engine.store.data["active"]["entry_id"])
        self.tick()
        self.assertEqual(["entry", "STOP_MARKET", "TAKE_PROFIT_MARKET"], self.event_names())

    def test_unknown_entry_keeps_exclusive_slot_reserved(self):
        self.api.drop_entry_ack = True
        self.api.hide_entry = True
        try:
            entry_id = self.enter()
        except ApiError as error:
            self.assertTrue(error.uncertain)
            entry_id = next(iter(self.api.standard))
        self.api.clock += 12_000
        self.tick()
        self.assertEqual(entry_id, self.engine.store.data["active"]["entry_id"])
        self.assertEqual(1, self.event_names().count("entry"))
        self.assertTrue(all(client_id == entry_id for _, client_id in self.api.writes))

    def test_unacknowledged_absent_entry_releases_slot_only_after_two_flat_checks(self):
        self.api.lose_entry_request = True
        started = self.api.now_ms()
        entry_id = self.enter()

        self.api.clock = started + 29_999
        self.engine.tick()
        self.assertNotIn("flat_missing_since", self.engine.store.data["active"])

        self.api.clock = started + 30_000
        self.engine.tick()
        self.assertEqual(started + 30_000, self.engine.store.data["active"]["flat_missing_since"])

        self.api.clock = started + 32_999
        self.engine.tick()
        self.assertEqual(entry_id, self.engine.store.data["active"]["entry_id"])

        self.api.clock = started + 33_000
        self.engine.tick()
        self.assertIsNone(self.engine.store.data["active"])
        self.assertEqual(1, self.event_names().count("entry"))
        self.assertTrue(any("UNKNOWN_ENTRY_RECONCILED_FLAT" in row for row in self.logs))

    def test_confirmed_partial_fill_remains_protected_when_only_account_shows_position(self):
        entry_id = self.enter()
        self.api.fill(entry_id, D("0.13"))
        self.api.stale_flat_reads = 8
        self.tick()

        self.assertEqual(["entry", "STOP_MARKET", "cancel_entry", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual(D("0.13"), self.api.amount)
        self.assertEqual(2, len(self.api.algo_orders()))
        self.assertEqual("managed", self.engine.store.data["active"]["phase"])

    def check_position_visible_during_entry_lookup_failure(self, *, only_account=False):
        entry_id = self.enter()
        self.api.fill(entry_id, D("0.13"))
        self.api.hide_entry = True
        if only_account:
            self.api.stale_flat_reads = 8
        self.tick(count=1)
        self.assertEqual(["entry", "STOP_MARKET", "cancel_entry"], self.event_names())
        self.assertTrue(self.api.algo_orders()[0]["closePosition"])
        self.assertEqual("CANCELED", self.api.standard[entry_id]["status"])

        self.api.hide_entry = False
        self.tick()
        self.assertEqual("TAKE_PROFIT_MARKET", self.event_names()[-1])

    def test_position_visible_during_entry_lookup_failure_still_gets_stop(self):
        self.check_position_visible_during_entry_lookup_failure()

    def test_account_position_gets_stop_when_entry_and_position_risk_are_missing(self):
        self.check_position_visible_during_entry_lookup_failure(only_account=True)

    def test_emergency_attempts_reduction_when_entry_lookup_fails(self):
        entry_id = self.enter()
        self.api.fill(entry_id, D("0.13"))
        self.api.reject_stop = True
        self.api.hide_entry_on_stop = True
        self.tick(count=1)
        self.assertEqual(["entry", "STOP_MARKET", "cancel_entry", "flatten"], self.event_names())
        self.assertEqual(0, self.api.amount)
        self.assertEqual([], self.api.orders())

    def test_uncertain_stop_ack_resolves_without_duplicate_order(self):
        entry_id = self.enter()
        self.api.fill(entry_id, self.plan.quantity)
        self.api.drop_stop_ack = True
        self.tick()
        self.assertEqual(["entry", "STOP_MARKET", "TAKE_PROFIT_MARKET"], self.event_names())
        self.assertEqual(2, len(self.api.algo_orders()))

    def test_explicit_gtx_rejection_allows_only_one_repricing_attempt(self):
        repricings = []

        def reprice(signal):
            repricings.append(signal)
            return self.plan

        self.engine.repricer = reprice
        self.api.reject_entry = True
        self.enter()
        self.tick()
        self.assertEqual([self.signal], repricings)
        self.assertEqual(["entry", "entry"], self.event_names())
        self.assertNotEqual(self.api.writes[0][1], self.api.writes[1][1])
        self.assertIsNone(self.engine.store.data["active"])

    def test_existing_foreign_order_blocks_entry(self):
        self.api.standard["manual-order"] = {"symbol": "BTCUSDT", "clientOrderId": "manual-order", "status": "NEW"}
        with self.assertRaises(Halt):
            self.engine.enter(self.signal, self.plan)
        self.assertEqual([], self.api.writes)


if __name__ == "__main__":
    unittest.main()
