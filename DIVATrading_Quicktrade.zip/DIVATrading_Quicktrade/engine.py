"""One durable Binance position lifecycle."""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from dataclasses import asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

from exchange import ApiError
from risk import Plan, validate_fill
from strategy import Signal

TERMINAL = {"FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"}
WORKING = {"NEW", "PARTIALLY_FILLED", "PENDING_CANCEL"}
MISSING = {-2011, -2013}
ENTRY_MS = 8_000


class Halt(RuntimeError):
    """Automatic trading needs operator review."""


def number(raw):
    try:
        value = Decimal(str(raw))
    except (InvalidOperation, ValueError):
        raise Halt("Binance returned an invalid numeric value") from None
    if not value.is_finite():
        raise Halt("Binance returned a non-finite numeric value")
    return value


def _values(model):
    return {key: str(value) if isinstance(value, Decimal) else value for key, value in asdict(model).items()}


def _model(cls, values):
    return cls(**{
        key: value if key in {"symbol", "side", "candle_ms"} else number(value)
        for key, value in values.items()
    })


class Store:
    def __init__(self, path, account_key):
        self.path = Path(path)
        key_id = hashlib.sha256(account_key.encode()).hexdigest()[:24]
        self.data = {"version": 1, "key_id": key_id, "seen": {}, "active": None}
        if self.path.exists():
            old = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(old, dict) or old.get("version") != 1 or not isinstance(old.get("seen"), dict):
                raise Halt("Local state could not be verified")
            if old.get("key_id") != key_id and old.get("active") is not None:
                raise Halt("The API key changed while a trade was recorded in local state")
            if old.get("key_id") == key_id:
                self.data = old

    def save(self):
        temp = self.path.with_name(self.path.name + ".tmp")
        with temp.open("w", encoding="utf-8") as file:
            json.dump(self.data, file, sort_keys=True)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp, self.path)


class Engine:
    def __init__(self, api, store, log=print, repricer=None):
        self.api = api
        self.store = store
        self.log = log
        self.repricer = repricer

    @property
    def active(self):
        return self.store.data["active"]

    def seen(self, signal):
        return self.store.data["seen"].get(signal.symbol, 0) >= signal.candle_ms

    def verify(self):
        self.api.ping()
        self.api.sync_clock()
        config = self.api.account_config()
        if config.get("canTrade") is not True or config.get("multiAssetsMargin") is not False:
            raise Halt("Binance must report trading enabled and Single-Asset Mode")
        if self.api.position_mode() is not False:
            raise Halt("Binance Futures must use One-way Mode")
        self._exclusive()

    def _exclusive(self, *, require_flat=False):
        active = None if require_flat else self.active
        entry_ids = {active["entry_id"]} if active else set()
        if active and active.get("flatten_id"):
            entry_ids.add(active["flatten_id"])
        algo_ids = {active["stop_id"], active["target_id"]} if active else set()
        symbol = active["plan"]["symbol"] if active else None
        for row in self.api.orders():
            if row.get("symbol") != symbol or row.get("clientOrderId") not in entry_ids:
                raise Halt("Binance has a standard order outside this bot's active trade")
        for row in self.api.algo_orders():
            if row.get("symbol") != symbol or row.get("clientAlgoId") not in algo_ids:
                raise Halt("Binance has a conditional order outside this bot's active trade")
        for row in self.api.positions():
            if number(row.get("positionAmt")) and row.get("symbol") != symbol:
                raise Halt("Binance has a position outside this bot's active trade")

    def enter(self, signal, plan):
        if self.active is not None or self.seen(signal):
            return False
        if plan.symbol != signal.symbol or plan.side != signal.side:
            raise Halt("The order plan does not match the signal")
        self._exclusive(require_flat=True)
        now = self.api.now_ms()
        if not signal.candle_ms <= now <= signal.candle_ms + 60_000:
            return False
        prefix = "dq-" + uuid.uuid4().hex[:20]
        self.store.data["seen"][signal.symbol] = signal.candle_ms
        self.store.data["active"] = {
            "signal": _values(signal), "plan": _values(plan), "phase": "entry", "prefix": prefix,
            "entry_id": prefix + "-e0", "attempt": 0, "entry_deadline": now + ENTRY_MS,
            "entry_sent_at": now, "entry_acknowledged": False,
            "chase_deadline": min(signal.candle_ms + 60_000, now + 2 * ENTRY_MS + 4_000),
            "stop_id": prefix + "-sl", "target_id": prefix + "-tp",
            "protection_attempted": [], "flatten_count": 0,
        }
        self.store.save()
        self._submit_entry(plan)
        return True

    def _submit_entry(self, plan):
        active = self.active
        try:
            self.api.entry(plan.symbol, plan.side, plan.quantity, plan.price, active["entry_id"])
        except ApiError as exc:
            if exc.uncertain:
                self.log(f"{plan.symbol} ENTRY_ACK_UNKNOWN {active['entry_id']}")
                return
            if exc.code == -5022:
                active["phase"] = "reprice"
                self.store.save()
            else:
                self._finish(f"{plan.symbol} ENTRY_REJECTED {exc}")
            return
        active["entry_acknowledged"] = True
        self.store.save()
        self.log(f"{plan.symbol} ENTRY_GTX {plan.side} qty={plan.quantity} price={plan.price} "
                 f"risk={plan.risk} SL={plan.stop} TP={plan.target} id={active['entry_id']}")

    def _position(self, plan, rows=None):
        if rows is None:
            rows = self.api.positions(plan.symbol)
        positions = [row for row in rows if number(row.get("positionAmt"))]
        if not positions:
            return None
        if len(positions) != 1:
            raise Halt("Multiple positions returned for the managed symbol")
        row = positions[0]
        amount = number(row.get("positionAmt"))
        if (row.get("symbol") != plan.symbol or row.get("positionSide", "BOTH") != "BOTH"
                or (amount > 0) != (plan.side == "BUY")):
            raise Halt("Binance reports an unexpected position side or symbol")
        return row

    def _account_position(self, plan):
        rows = self.api.account().get("positions")
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise Halt("Binance account position data was invalid")
        return self._position(plan, [row for row in rows if row.get("symbol") == plan.symbol])

    def _exposure(self, plan):
        return self._position(plan) or self._account_position(plan)

    def _order(self, plan):
        row = self.api.get_entry(plan.symbol, self.active["entry_id"])
        status = row.get("status")
        if (row.get("clientOrderId", self.active["entry_id"]) != self.active["entry_id"]
                or row.get("symbol", plan.symbol) != plan.symbol or status not in TERMINAL | WORKING):
            raise Halt("Binance returned an unexpected entry order")
        return status, number(row.get("executedQty"))

    def _algo(self, plan, key, submit=False):
        active = self.active
        client_id = active[key]
        side = "SELL" if plan.side == "BUY" else "BUY"
        kind, trigger = ("STOP_MARKET", plan.stop) if key == "stop_id" else ("TAKE_PROFIT_MARKET", plan.target)
        if submit and key not in active["protection_attempted"]:
            active["protection_attempted"].append(key)
            self.store.save()
            try:
                row = self.api.protect(plan.symbol, side, kind, trigger, client_id)
            except ApiError as exc:
                if not exc.uncertain:
                    raise
                row = self.api.get_protection(client_id)
            self.log(f"{plan.symbol} {kind} submitted id={client_id}")
        else:
            row = self.api.get_protection(client_id)
        if (row.get("clientAlgoId") != client_id or row.get("algoStatus") != "NEW"
                or row.get("symbol", plan.symbol) != plan.symbol or row.get("side", side) != side
                or row.get("orderType", row.get("type", kind)) != kind
                or row.get("workingType", "MARK_PRICE") != "MARK_PRICE"
                or row.get("closePosition", True) not in (True, "true")
                or number(row.get("triggerPrice", trigger)) != trigger):
            raise Halt(f"{plan.symbol} exchange did not confirm working {kind}")

    def _validate_position(self, plan, row):
        mark = number(row["markPrice"]) if "markPrice" in row else self.api.mark(plan.symbol)
        # Account V3 omits entryPrice. The GTX limit bounds the adverse fill price.
        price = number(row["entryPrice"]) if "entryPrice" in row else plan.price
        validate_fill(plan, abs(number(row["positionAmt"])), price, mark)
        liquidation = number(row.get("liquidationPrice", 0))
        if liquidation > 0:
            buffered_stop = plan.stop * (Decimal("0.9995") if plan.side == "BUY" else Decimal("1.0005"))
            if (plan.side == "BUY" and liquidation >= buffered_stop
                    or plan.side == "SELL" and liquidation <= buffered_stop):
                raise Halt("Exchange liquidation is too close to the stop")

    def _cancel_remainder(self, plan):
        now = self.api.now_ms()
        if now < self.active.get("cancel_after", 0):
            return
        self.active["cancel_after"] = now + 2_500
        try:
            self.api.cancel_entry(plan.symbol, self.active["entry_id"])
        except ApiError as exc:
            if exc.code not in MISSING and not exc.uncertain:
                raise

    def _finish(self, message):
        self.store.data["active"] = None
        self.store.save()
        self.log(message)

    def _cleanup(self, plan, *, emergency=False):
        if self._exposure(plan):
            return
        owned = {self.active[key] for key in self.active["protection_attempted"]}
        for row in self.api.algo_orders(plan.symbol):
            client_id = row.get("clientAlgoId")
            if client_id not in owned:
                raise Halt("A conditional order on the managed symbol is outside local state")
            try:
                self.api.cancel_protection(client_id)
            except ApiError as exc:
                if exc.code not in MISSING and not exc.uncertain:
                    raise
        if self._exposure(plan) or self.api.orders(plan.symbol) or self.api.algo_orders(plan.symbol):
            return
        self._finish(f"{plan.symbol} FLAT verified")
        if emergency:
            raise Halt(f"{plan.symbol} emergency exit completed, review the trade before restarting")

    def _emergency(self, plan, reason):
        self.active["phase"] = "emergency"
        self.store.save()
        self.log(f"{plan.symbol} EMERGENCY_EXIT {reason}")
        self._emergency_tick(plan)

    def _emergency_tick(self, plan):
        try:
            status, executed = self._order(plan)
        except ApiError as exc:
            if exc.status in {418, 429}:
                raise
            status, executed = None, None
        if status not in TERMINAL:
            try:
                self._cancel_remainder(plan)
            except ApiError as exc:
                self.log(f"{plan.symbol} ENTRY_CANCEL_RETRY {exc}")
        row = self._position(plan)
        if row is None and (executed or self.active.get("last_position_seen")):
            row = self._account_position(plan)
        if not row:
            if status in TERMINAL:
                self._cleanup(plan, emergency=True)
            return
        active = self.active
        now = self.api.now_ms()
        if now < active.get("flatten_after", 0):
            return
        active["flatten_count"] += 1
        active["flatten_id"] = f"{active['prefix']}-x{active['flatten_count']}"
        active["flatten_after"] = now + 4_000
        self.store.save()
        side = "SELL" if plan.side == "BUY" else "BUY"
        # Every retry is reduce-only and uses a fresh position snapshot.
        self.api.flatten(plan.symbol, side, abs(number(row["positionAmt"])), active["flatten_id"])

    def _retry(self, plan):
        active = self.active
        now = self.api.now_ms()
        if not self.repricer or active["attempt"] or now > active["chase_deadline"]:
            self._finish(f"{plan.symbol} ENTRY_NO_FILL")
            return
        try:
            revised = self.repricer(_model(Signal, active["signal"]))
        except ValueError as exc:
            self._finish(f"{plan.symbol} REPRICE_SKIPPED {exc}")
            return
        if self.api.now_ms() > active["chase_deadline"]:
            self._finish(f"{plan.symbol} ENTRY_NO_FILL")
            return
        self._exclusive(require_flat=True)
        now = self.api.now_ms()
        active.update(
            phase="entry", plan=_values(revised), attempt=1, entry_id=active["prefix"] + "-e1",
            entry_deadline=min(active["chase_deadline"], now + ENTRY_MS),
            entry_sent_at=now, entry_acknowledged=False,
        )
        for key in ("cancel_after", "flat_missing_since", "entry_visibility_pending"):
            active.pop(key, None)
        self.store.save()
        self._submit_entry(revised)

    def _reconcile_missing(self, plan):
        active = self.active
        now = self.api.now_ms()
        if (active["entry_acknowledged"] or active["protection_attempted"] or active.get("last_position_seen")
                or now - active["entry_sent_at"] < 30_000):
            return
        if self.api.orders(plan.symbol) or self.api.algo_orders(plan.symbol):
            active.pop("flat_missing_since", None)
            return
        # The original signature's receive window has expired. Confirm twice
        # that its ID is missing and both position views and open orders are flat.
        if now - active.setdefault("flat_missing_since", now) >= 3_000:
            self._finish(f"{plan.symbol} UNKNOWN_ENTRY_RECONCILED_FLAT")

    def tick(self):
        active = self.active
        if active is None:
            return
        plan = _model(Plan, active["plan"])
        if active["phase"] == "emergency":
            self._emergency_tick(plan)
            return
        if active["phase"] == "reprice":
            self._retry(plan)
            return
        if active["phase"] == "managed":
            if not self._exposure(plan):
                self._cleanup(plan)
                return
            try:
                self._algo(plan, "stop_id")
                self._algo(plan, "target_id")
            except Halt as exc:
                self._emergency(plan, str(exc))
            except ApiError as exc:
                if exc.code in MISSING:
                    self._emergency(plan, str(exc))
                else:
                    raise
            return
        lookup_error = None
        try:
            status, executed = self._order(plan)
            if not active["entry_acknowledged"]:
                active["entry_acknowledged"] = True
                self.store.save()
        except ApiError as exc:
            if exc.status in {418, 429}:
                raise
            if not active.get("entry_visibility_pending"):
                active["entry_visibility_pending"] = True
                self.store.save()
                self.log(f"{plan.symbol} ENTRY_STATUS_PENDING {active['entry_id']} {exc}")
            lookup_error = exc
            status, executed = None, None
        row = self._position(plan)
        if row is None and (executed or lookup_error or active.get("last_position_seen")):
            row = self._account_position(plan)
        if row:
            try:
                active["last_position_seen"] = True
                if not active["protection_attempted"]:
                    self._validate_position(plan, row)
                self._algo(plan, "stop_id", submit=True)
                if status not in TERMINAL:
                    self._cancel_remainder(plan)
                    return
                self._algo(plan, "target_id", submit=True)
                active["phase"] = "managed"
                self.store.save()
                self.log(f"{plan.symbol} PROTECTED qty={abs(number(row['positionAmt']))} SL={plan.stop} TP={plan.target}")
            except ApiError as exc:
                if exc.status in {418, 429}:
                    raise
                self._emergency(plan, str(exc))
            except (Halt, ValueError) as exc:
                self._emergency(plan, str(exc))
            return
        if executed is None:
            if self.api.now_ms() >= active["entry_deadline"]:
                self._cancel_remainder(plan)
            if lookup_error.code == -2013:
                self._reconcile_missing(plan)
            else:
                active.pop("flat_missing_since", None)
            return
        if executed > 0:
            if status in WORKING:
                self._cancel_remainder(plan)
            if active["protection_attempted"] and status in TERMINAL:
                self._cleanup(plan)
                return
            if not active.get("fill_without_position_notified"):
                active["fill_without_position_notified"] = True
                self.store.save()
                self.log(f"{plan.symbol} POSITION_VISIBILITY_PENDING; entry reports a fill")
            return
        if status in TERMINAL:
            self._retry(plan)
        elif self.api.now_ms() >= active["entry_deadline"]:
            self._cancel_remainder(plan)
