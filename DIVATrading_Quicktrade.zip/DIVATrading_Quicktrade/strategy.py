"""Closed-candle liquidity sweep and reclaim signals for USDT perpetuals."""

from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from statistics import median


MIN_QUOTE_VOLUME = Decimal("20000000")
MAX_SPREAD_BPS = Decimal("12")
LOOKBACK = 12
MINUTE_MS = 60_000
MAX_SIGNAL_AGE_MS = 75_000


@dataclass(frozen=True)
class Signal:
    symbol: str
    side: str
    candle_ms: int
    entry_low: Decimal
    entry_high: Decimal
    stop: Decimal
    target: Decimal


@dataclass(frozen=True)
class _Candle:
    close_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal

    def mirrored(self):
        return _Candle(self.close_ms, -self.open, -self.low, -self.high, -self.close)


def _positive(value):
    number = Decimal(str(value))
    if not number.is_finite() or number <= 0:
        raise ValueError("Expected a finite positive decimal")
    return number


def scan_symbols(exchange_info, tickers, books, limit=12) -> list[str]:
    """Rank the active USDT perpetual universe by volume adjusted for spread."""
    active = {
        row["symbol"]
        for row in exchange_info.get("symbols", [])
        if isinstance(row, Mapping)
        and row.get("symbol")
        and row.get("status") == "TRADING"
        and row.get("contractType") == "PERPETUAL"
        and row.get("quoteAsset") == "USDT"
    }
    quote_by_symbol = {row.get("symbol"): row for row in books if isinstance(row, Mapping)}
    ranked = []
    for row in tickers:
        if not isinstance(row, Mapping):
            continue
        symbol = row.get("symbol")
        quote = quote_by_symbol.get(symbol)
        if symbol not in active or quote is None:
            continue
        try:
            volume = _positive(row.get("quoteVolume"))
            bid = _positive(quote.get("bidPrice"))
            ask = _positive(quote.get("askPrice"))
        except (InvalidOperation, ValueError):
            continue
        spread_bps = (ask - bid) / ((bid + ask) / 2) * 10_000
        if volume >= MIN_QUOTE_VOLUME and 0 < spread_bps <= MAX_SPREAD_BPS:
            ranked.append((volume / (1 + spread_bps), symbol))
    ranked.sort(key=lambda row: (-row[0], row[1]))
    return [symbol for _, symbol in ranked[:max(0, limit)]]


def _closed_candles(rows, now_ms, interval_ms):
    candles = []
    for row in rows:
        try:
            close_ms = int(row[6])
            if close_ms >= now_ms or close_ms - int(row[0]) + 1 != interval_ms:
                continue
            open_price, high, low, close = (_positive(value) for value in row[1:5])
        except (IndexError, InvalidOperation, TypeError, ValueError):
            continue
        if low <= min(open_price, close) <= max(open_price, close) <= high:
            candles.append(_Candle(close_ms, open_price, high, low, close))
    # Keep the newest contiguous run. A missing candle invalidates older levels.
    for index in range(len(candles) - 1, 0, -1):
        if candles[index].close_ms - candles[index - 1].close_ms != interval_ms:
            return candles[index:]
    return candles


def _atr(candles):
    ranges = [
        max(
            current.high - current.low,
            abs(current.high - previous.close),
            abs(current.low - previous.close),
        )
        for previous, current in zip(candles, candles[1:])
    ]
    return sum(ranges) / len(ranges)


def _opposed(candles):
    earlier, recent = candles[-12:-6], candles[-6:]
    tolerance = median(candle.high - candle.low for candle in candles[-12:]) * Decimal("0.10")
    return (
        max(candle.high for candle in recent) < max(candle.high for candle in earlier) - tolerance
        and min(candle.low for candle in recent) < min(candle.low for candle in earlier) - tolerance
    )


def _swing_highs(candles):
    for index in range(2, len(candles) - 2):
        center = candles[index].high
        left = max(candle.high for candle in candles[index - 2:index])
        right = max(candle.high for candle in candles[index + 1:index + 3])
        # Allow equal highs on one side of a confirmed pivot.
        if center >= max(left, right) and center > min(left, right):
            yield center


def _setup(symbol, side, candles, context, atr):
    if side == "SELL":
        candles = [candle.mirrored() for candle in candles]
        context = [candle.mirrored() for candle in context]
    if _opposed(context):
        return None

    confirm = candles[-1]
    body = confirm.close - confirm.open
    confirm_range = confirm.high - confirm.low
    if body < atr * Decimal("0.28") or confirm_range > atr * Decimal("2.50"):
        return None
    if confirm.high - confirm.close > confirm_range * Decimal("0.40"):
        return None

    # Check the confirmation candle first, then a sweep one candle earlier.
    for sweep_index in (-1, -2):
        sweep = candles[sweep_index]
        level = min(candle.low for candle in candles[sweep_index - LOOKBACK:sweep_index])
        extreme = min(sweep.low, confirm.low)
        penetration = level - extreme
        if not atr * Decimal("0.04") <= penetration <= atr * Decimal("1.10"):
            continue
        if sweep.low >= level or confirm.close < level + atr * Decimal("0.08"):
            continue
        if confirm.close - extreme < atr * Decimal("0.55"):
            continue
        if sweep_index == -2 and confirm.close - sweep.close < atr * Decimal("0.20"):
            continue

        stop = extreme - atr * Decimal("0.12")
        entry_low = level + atr * Decimal("0.04")
        target = confirm.close + min((confirm.close - stop) * Decimal("1.90"), atr * 3)
        buffer = atr * Decimal("0.10")
        opposing = [
            price
            for series in (candles[-30:], context[-24:])
            for price in _swing_highs(series)
            if price > confirm.high
        ]
        if opposing:
            target = min(target, min(opposing) - buffer)
        if target <= confirm.close:
            continue
        # Restrict the chase to prices that retain at least 1.15R before fees.
        maximum_entry = (target + stop * Decimal("1.15")) / Decimal("2.15")
        entry_high = min(confirm.close, maximum_entry)
        if entry_low > entry_high:
            continue

        if side == "SELL":
            return Signal(symbol, side, confirm.close_ms, -entry_high, -entry_low, -stop, -target)
        return Signal(symbol, side, confirm.close_ms, entry_low, entry_high, stop, target)
    return None


def detect_signal(symbol, candles_1m, candles_5m, now_ms) -> Signal | None:
    """Use the most recent 1m close and 5m structure from a single REST fetch."""
    candles = _closed_candles(candles_1m, now_ms, MINUTE_MS)
    context = _closed_candles(candles_5m, now_ms, 5 * MINUTE_MS)
    if len(candles) < 17 or len(context) < 12:
        return None
    if now_ms - candles[-1].close_ms > MAX_SIGNAL_AGE_MS:
        return None
    if now_ms - context[-1].close_ms > 5 * MINUTE_MS + 15_000:
        return None
    atr = _atr(candles[-17:-2])
    if atr <= 0:
        return None
    for side in ("BUY", "SELL"):
        signal = _setup(symbol, side, candles, context, atr)
        if signal is not None and min(signal.entry_low, signal.stop, signal.target) > 0:
            return signal
    return None
