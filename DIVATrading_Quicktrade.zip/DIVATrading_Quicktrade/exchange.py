"""Small Binance USD-M REST client for the standalone trader."""

from __future__ import annotations

import hashlib
import hmac
import http.client
import json
import time
from decimal import Decimal, InvalidOperation
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener


class ApiError(RuntimeError):
    def __init__(self, message, *, code=None, uncertain=False, status=None):
        super().__init__(message)
        self.code = code
        self.uncertain = uncertain
        self.status = self.status_code = status


class _NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Binance:
    def __init__(self, mode, key="", secret=""):
        mode = mode.upper()
        if mode not in {"DEMO", "TESTNET", "LIVE"}:
            raise ValueError("Binance mode must be DEMO or LIVE")
        self.base_url = (
            "https://fapi.binance.com" if mode == "LIVE" else "https://demo-fapi.binance.com"
        )
        if any(not 33 <= ord(character) <= 126 for character in key):
            raise ValueError("Binance API key contains invalid header characters")
        self._key = key
        self._secret = secret.encode("utf-8")
        self._opener = build_opener(_NoRedirects())
        self._clock = None

    @staticmethod
    def _wire_value(value):
        if isinstance(value, Decimal):
            return format(value, "f")
        if isinstance(value, bool):
            return str(value).lower()
        return str(value)

    @staticmethod
    def _decode(data):
        try:
            return json.loads(data, parse_float=Decimal)
        except (ValueError, UnicodeError):
            return None

    def _request(self, method, path, params=None, *, signed=False, expect=dict):
        writing = method != "GET"
        query = [(name, self._wire_value(value)) for name, value in (params or {}).items() if value is not None]
        headers = {"Accept": "application/json", "User-Agent": "DIVAQuickTrade/1.0"}
        if signed:
            if not self._key or not self._secret:
                raise ApiError("Binance API key and secret are required")
            if self._clock is None or time.monotonic() - self._clock[1] > 300:
                self.sync_clock()
            query.extend((("recvWindow", "5000"), ("timestamp", str(self.now_ms()))))
            headers["X-MBX-APIKEY"] = self._key
        encoded = urlencode(query)
        if signed:
            signature = hmac.new(self._secret, encoded.encode("ascii"), hashlib.sha256).hexdigest()
            encoded += "&signature=" + signature
        url = self.base_url + path
        body = None
        if method == "POST":
            body = encoded.encode("ascii")
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        elif encoded:
            url += "?" + encoded
        request = Request(url, data=body, headers=headers, method=method)
        try:
            with self._opener.open(request, timeout=3.0) as response:
                status = response.status
                payload = self._decode(response.read())
        except HTTPError as error:
            status = error.code
            try:
                with error:
                    payload = self._decode(error.read())
            except (OSError, http.client.HTTPException):
                payload = None
        except (URLError, OSError, http.client.HTTPException) as error:
            raise ApiError(
                f"Binance {method} {path} transport failure ({type(error).__name__})",
                uncertain=writing,
            ) from None

        raw_code = payload.get("code") if isinstance(payload, dict) else None
        code = raw_code if type(raw_code) is int else None
        if code == -1021:
            self._clock = None
        if not 200 <= status < 300 or (code is not None and code < 0):
            detail = " (restricted location)" if status == 451 else ""
            unknown = status >= 500 or status == 408 or code in {-1000, -1001, -1006, -1007, -4116}
            raise ApiError(
                f"Binance {method} {path} failed (HTTP {status}, code {code}){detail}",
                code=code,
                uncertain=writing and unknown,
                status=status,
            )
        if not isinstance(payload, expect):
            raise ApiError(f"Binance {method} {path} returned an unexpected response", uncertain=writing)
        return payload

    def _rows(self, path, symbol=None, *, signed=False):
        payload = self._request("GET", path, {"symbol": symbol}, signed=signed, expect=list)
        if any(not isinstance(row, dict) for row in payload):
            raise ApiError(f"Binance GET {path} returned invalid rows")
        return payload

    def _symbol_row(self, path, symbol):
        payload = self._request("GET", path, {"symbol": symbol}, signed=True, expect=(list, dict))
        rows = [payload] if isinstance(payload, dict) else payload
        matching = [row for row in rows if isinstance(row, dict) and row.get("symbol") == symbol]
        if len(matching) != 1:
            raise ApiError(f"Binance GET {path} returned unexpected symbol metadata")
        return matching[0]

    def ping(self):
        return self._request("GET", "/fapi/v1/ping")

    def sync_clock(self):
        payload = self._request("GET", "/fapi/v1/time")
        server_ms = payload.get("serverTime")
        if type(server_ms) is not int or server_ms <= 0:
            raise ApiError("Binance server time is invalid")
        self._clock = server_ms, time.monotonic()
        return server_ms

    def now_ms(self):
        if self._clock is None:
            self.sync_clock()
        server_ms, sampled = self._clock
        return server_ms + int((time.monotonic() - sampled) * 1000)

    def exchange_info(self):
        return self._request("GET", "/fapi/v1/exchangeInfo")

    def tickers(self):
        return self._rows("/fapi/v1/ticker/24hr")

    def books(self):
        return self._rows("/fapi/v1/ticker/bookTicker")

    def book(self, symbol):
        return self._request("GET", "/fapi/v1/ticker/bookTicker", {"symbol": symbol})

    def klines(self, symbol, interval, limit):
        return self._request(
            "GET", "/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": limit}, expect=list
        )

    def mark(self, symbol):
        payload = self._request("GET", "/fapi/v1/premiumIndex", {"symbol": symbol})
        try:
            price = Decimal(payload.get("markPrice"))
            if payload.get("symbol") != symbol or not price.is_finite() or price <= 0:
                raise ValueError
        except (InvalidOperation, TypeError, ValueError):
            raise ApiError("Binance mark price response is invalid") from None
        return price

    def account(self):
        return self._request("GET", "/fapi/v3/account", signed=True)

    def account_config(self):
        return self._request("GET", "/fapi/v1/accountConfig", signed=True)

    def position_mode(self):
        payload = self._request("GET", "/fapi/v1/positionSide/dual", signed=True)
        value = payload.get("dualSidePosition")
        if type(value) is not bool:
            raise ApiError("Binance position mode response is invalid")
        return value

    def positions(self, symbol=None):
        return self._rows("/fapi/v3/positionRisk", symbol, signed=True)

    def orders(self, symbol=None):
        return self._rows("/fapi/v1/openOrders", symbol, signed=True)

    def algo_orders(self, symbol=None):
        return self._rows("/fapi/v1/openAlgoOrders", symbol, signed=True)

    def symbol_config(self, symbol):
        return self._symbol_row("/fapi/v1/symbolConfig", symbol)

    def commission(self, symbol):
        return self._symbol_row("/fapi/v1/commissionRate", symbol)

    def brackets(self, symbol):
        return self._symbol_row("/fapi/v1/leverageBracket", symbol)

    def entry(self, symbol, side, quantity, price, client_id):
        return self._request("POST", "/fapi/v1/order", {
            "symbol": symbol, "side": side, "positionSide": "BOTH", "type": "LIMIT", "timeInForce": "GTX",
            "quantity": quantity, "price": price, "newClientOrderId": client_id, "newOrderRespType": "ACK",
        }, signed=True)

    def get_entry(self, symbol, client_id):
        return self._request(
            "GET", "/fapi/v1/order", {"symbol": symbol, "origClientOrderId": client_id}, signed=True
        )

    def cancel_entry(self, symbol, client_id):
        return self._request(
            "DELETE", "/fapi/v1/order", {"symbol": symbol, "origClientOrderId": client_id}, signed=True
        )

    def protect(self, symbol, side, kind, trigger, client_id):
        if kind not in {"STOP_MARKET", "TAKE_PROFIT_MARKET"}:
            raise ValueError("Invalid protective order type")
        return self._request("POST", "/fapi/v1/algoOrder", {
            "algoType": "CONDITIONAL", "symbol": symbol, "side": side, "positionSide": "BOTH", "type": kind,
            "triggerPrice": trigger, "workingType": "MARK_PRICE", "closePosition": True,
            "priceProtect": False, "clientAlgoId": client_id,
        }, signed=True)

    def get_protection(self, client_id):
        return self._request("GET", "/fapi/v1/algoOrder", {"clientAlgoId": client_id}, signed=True)

    def cancel_protection(self, client_id):
        return self._request("DELETE", "/fapi/v1/algoOrder", {"clientAlgoId": client_id}, signed=True)

    def flatten(self, symbol, side, quantity, client_id):
        return self._request("POST", "/fapi/v1/order", {
            "symbol": symbol, "side": side, "positionSide": "BOTH", "type": "MARKET",
            "quantity": quantity, "reduceOnly": True, "newClientOrderId": client_id, "newOrderRespType": "RESULT",
        }, signed=True)
