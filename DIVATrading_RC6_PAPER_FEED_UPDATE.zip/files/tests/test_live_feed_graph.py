from __future__ import annotations

import asyncio
from collections import deque
from pathlib import Path
from types import SimpleNamespace

import pytest

from divatrading.core.database import Database
from divatrading.exchange.binance.client import BinanceUsdMFuturesRestClient
from divatrading.exchange.binance.models import parse_exchange_info
from divatrading.market_data.live_feed_graph import (
    BinanceFeedGraphConfig,
    BinanceFeedGraphError,
    BinancePublicFeedFactory,
    _BinanceSymbolFeedGraph,
)

FIXTURE = Path(__file__).parent / "fixtures" / "exchange_info_valid.json"


def test_feed_graph_config_enforces_canonical_timeframes_and_bounds():
    assert BinanceFeedGraphConfig().intervals == ("1m", "5m", "15m")
    with pytest.raises(ValueError, match="canonical production or Demo"):
        BinanceFeedGraphConfig(ws_endpoint="wss://untrusted.example/stream")
    with pytest.raises(ValueError, match="canonical order"):
        BinanceFeedGraphConfig(intervals=("1m", "15m", "5m"))
    with pytest.raises(ValueError, match="bootstrap_candles"):
        BinanceFeedGraphConfig(bootstrap_candles=10)
    with pytest.raises(ValueError, match="snapshot_interval_seconds"):
        BinanceFeedGraphConfig(snapshot_interval_seconds=0.01)


def test_feed_factory_requires_exact_exchange_metadata(tmp_path):
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("BTCUSDT")
    finally:
        client.close()


def test_feed_factory_accepts_only_exchange_info_symbols(tmp_path):
    payload = __import__("json").loads(FIXTURE.read_text(encoding="utf-8"))
    snapshot = parse_exchange_info(
        payload, source_endpoint="https://fapi.binance.com/fapi/v1/exchangeInfo"
    )
    client = BinanceUsdMFuturesRestClient()
    database = Database(tmp_path / "diva.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(rest_client=client, database=database)
    try:
        factory.set_metadata(snapshot)
        stream = factory("BTCUSDT")
        assert hasattr(stream, "__aiter__")
        with pytest.raises(BinanceFeedGraphError, match="No current Exchange Information"):
            factory("NOTAREALCONTRACT")
    finally:
        client.close()


@pytest.mark.parametrize(("rest_url", "ws_origin"), [
    ("https://fapi.binance.com", "wss://fstream.binance.com"),
    ("https://demo-fapi.binance.com", "wss://demo-fstream.binance.com"),
], ids=["paper", "demo"])
def test_market_feed_graph_routes_depth_on_same_hosts_public_channel(tmp_path, rest_url, ws_origin):
    import json

    market_endpoint = ws_origin + "/market/stream"
    snapshot = parse_exchange_info(
        json.loads(FIXTURE.read_text(encoding="utf-8")),
        source_endpoint=rest_url + "/fapi/v1/exchangeInfo",
    )
    symbol_info = snapshot.get_symbol("BTCUSDT")
    assert symbol_info is not None
    client = BinanceUsdMFuturesRestClient(base_url=rest_url)
    database = Database(tmp_path / "test.sqlite")
    database.initialize()
    factory = BinancePublicFeedFactory(
        rest_client=client, database=database,
        config=BinanceFeedGraphConfig(ws_endpoint=market_endpoint),
    )
    try:
        graph = _BinanceSymbolFeedGraph(
            symbol="BTCUSDT", symbol_info=symbol_info,
            rest_client=client, history_rest_client=factory._history_rest,
            depth_snapshot_client=factory._depth_snapshot,
            database=database, config=factory.config, bootstrap_lock=asyncio.Lock(),
        )
        assert factory.rest_client.base_url == rest_url
        assert factory._depth_snapshot._client.endpoint == rest_url + "/fapi/v1/depth"
        for feed in (graph.kline_feed, graph.mark_feed, graph.aggregate_feed):
            assert feed.endpoint == market_endpoint
        assert graph.depth_feed.endpoint == ws_origin + "/public/stream"
    finally:
        factory.close()
        client.close()


def test_capture_key_changes_when_flow_advances_or_a_feed_reconnects():
    candles = SimpleNamespace(latest_closed_candle=SimpleNamespace(open_time_ms=5))
    flow = SimpleNamespace(last_processed_aggregate_trade_id=10, window_end_ms=20)
    sources = SimpleNamespace(aggregate_trade_reconnect_generation=0, depth_reconnect_generation=0)
    view = SimpleNamespace(
        m1=candles, m5=candles, m15=candles, flow=flow, orchestrator_readiness=sources,
        mark_price=SimpleNamespace(event_time_ms=6),
        order_book_metrics=SimpleNamespace(update_id=7),
        readiness=SimpleNamespace(entry_quote_ready=True, delta_cvd_available=True),
    )
    capture = _BinanceSymbolFeedGraph._capture_key
    initial = capture(view)
    assert capture(view) == initial

    flow.last_processed_aggregate_trade_id += 1
    after_trade = capture(view)
    assert after_trade != initial

    sources.depth_reconnect_generation += 1
    after_reconnect = capture(view)
    assert after_reconnect != after_trade

    view.readiness.entry_quote_ready = False
    assert capture(view) != after_reconnect


def _kline_graph():
    graph = _BinanceSymbolFeedGraph.__new__(_BinanceSymbolFeedGraph)
    graph.symbol = "BTCUSDT"
    graph.config = BinanceFeedGraphConfig()
    graph.pending_closed = {interval: deque() for interval in graph.config.intervals}
    graph.forming_klines = {}
    graph.stop_event = asyncio.Event()
    graph.wake_event = asyncio.Event()
    return graph


@pytest.mark.asyncio
async def test_pending_close_retries_on_monotonic_cadence_with_continuous_forming_events(monkeypatch):
    from divatrading.market_data import live_feed_graph

    graph = _kline_graph()
    clock = SimpleNamespace(seconds=0.0)
    monkeypatch.setattr(live_feed_graph, "time", SimpleNamespace(monotonic=lambda: clock.seconds))
    graph.now_ms = lambda: 10_000 - round(clock.seconds * 1_000)
    graph._last_pending_warning_ms = 0
    graph._last_kline_connection_generation = 1

    close = SimpleNamespace(
        is_closed=True, kline=SimpleNamespace(symbol=graph.symbol, interval="5m", open_time_ms=0),
    )
    forming = SimpleNamespace(
        is_closed=False, kline=SimpleNamespace(symbol=graph.symbol, interval="1m"),
    )
    arrivals = iter((0.0, 0.05, 0.10, 0.15, 0.21, 0.26, 0.31, 0.36, 0.42, 0.46))

    async def get_event():
        clock.seconds = next(arrivals)
        if clock.seconds == 0.46:
            graph.stop_event.set()
        return close if clock.seconds == 0 else forming

    attempts = []

    def ingest(event):
        assert event is close
        attempts.append(clock.seconds)
        if len(attempts) < 3:
            raise RuntimeError("REST candle not available yet")

    graph.kline_feed = SimpleNamespace(
        get_event=get_event, is_connected=True, stats=SimpleNamespace(connection_count=1),
    )
    graph.kline_recovery = SimpleNamespace(
        observe_websocket_feed=lambda feed: None, ingest_websocket_event=ingest,
    )

    await graph._consume_klines()

    assert attempts == pytest.approx([0.0, 0.21, 0.42])
    assert not graph.pending_closed["5m"]
    assert graph.forming_klines["1m"] is forming


@pytest.mark.asyncio
@pytest.mark.parametrize("queued_during_read", [None, "5m", "15m"])
async def test_build_view_omits_interval_while_a_closed_candle_is_pending(queued_during_read):
    from divatrading.market_data.recovery import FeedHealth

    graph = _kline_graph()
    graph.now_ms = lambda: 1_800_000_000_000
    graph.symbol_info = object()
    graph.kline_feed = graph.mark_feed = SimpleNamespace(is_connected=True)
    graph.latest_mark_price = SimpleNamespace(event_time_ms=graph.now_ms())
    graph.market_orchestrator = SimpleNamespace(is_running=True, health=lambda symbol: None)
    graph.depth_supervisor = SimpleNamespace(metrics=lambda symbol: None)
    graph.kline_recovery = SimpleNamespace(stream_health=lambda **kwargs: FeedHealth.HEALTHY)

    if queued_during_read is None:
        graph.pending_closed["5m"].append(object())

    reads = []

    def read_tail(*, symbol, interval, limit):
        reads.append(interval)
        if interval == queued_during_read:
            graph.pending_closed["5m"].append(object())
        return (SimpleNamespace(kline=object()), SimpleNamespace(kline=object()))

    def build_view(*, kline_series, **kwargs):
        return SimpleNamespace(
            status="READY",
            readiness=SimpleNamespace(can_scan_setups=True, mark_price_available=True),
            intervals=tuple(item.interval for item in kline_series),
        )

    graph.kline_repository = SimpleNamespace(read_tail=read_tail)
    graph.adapter = SimpleNamespace(build_view=build_view)

    view = await graph._build_complete_view()

    assert view.intervals == ("1m", "15m")
    assert ("5m" in reads) is (queued_during_read is not None)

    graph.pending_closed["5m"].clear()
    queued_during_read = None
    restored = await graph._build_complete_view()
    assert restored.intervals == ("1m", "5m", "15m")


def test_autonomous_environment_selection_has_no_mainnet_testnet_mixing():
    from divatrading.cli import _autonomous_market_endpoints
    from divatrading.execution.service import ExecutionMode
    from divatrading.execution.binance_private import TESTNET_BASE_URL
    from divatrading.exchange.binance.client import DEFAULT_BASE_URL
    from divatrading.market_data.websocket import (
        BINANCE_UM_MARKET_WS_ENDPOINT, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )

    assert _autonomous_market_endpoints(ExecutionMode.TESTNET) == (
        TESTNET_BASE_URL, BINANCE_UM_DEMO_MARKET_WS_ENDPOINT,
    )
    assert _autonomous_market_endpoints(ExecutionMode.PAPER) == (
        DEFAULT_BASE_URL, BINANCE_UM_MARKET_WS_ENDPOINT,
    )
