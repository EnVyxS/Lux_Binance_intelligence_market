"""Unified, read-only orchestration and readiness for Binance USDⓈ-M market data.

The orchestrator coordinates existing feed/recovery/order-flow/depth/evidence
components. It does not own strategy decisions and never places orders.
"""
from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass
from typing import Callable

from divatrading.market_data.absorption import AbsorptionEvidence, DepthAggressorAlignmentService
from divatrading.market_data.aggregate_trade_recovery import (
    AggregateTradeRecoveryService,
)
from divatrading.market_data.aggregate_trade_storage import (
    MAX_AGG_TRADE_WRITE_BATCH,
    AggregateTradeStreamState,
    AggregateTradeStreamStateError,
)
from divatrading.market_data.aggregate_trades import (
    AggregateTradeEvent,
    BinanceAggregateTradeWebSocketFeed,
)
from divatrading.market_data.aggregate_trade_fanout import (
    AggregateTradeEventFanout,
    AggregateTradeFanoutQueueFullError,
)
from divatrading.market_data.order_book import OrderBookMetrics, OrderBookNotReady
from divatrading.market_data.order_book_supervisor import (
    BinanceOrderBookSupervisor,
    OrderBookSymbolHealth,
)
from divatrading.market_data.order_flow import (
    MAX_PROCESS_BATCH,
    OrderFlowNotReady,
    OrderFlowSnapshot,
    DeltaCvdService,
)


class MarketDataOrchestratorError(RuntimeError):
    """Base error for unified market-data orchestration."""


class MarketDataQueueFullError(MarketDataOrchestratorError):
    """Raised when the orchestrator's bounded aggregate-event queue overflows."""


class MarketDataStartupError(MarketDataOrchestratorError):
    """Raised when initial public feed connection or trade baseline fails."""


@dataclass(frozen=True, slots=True)
class MarketDataOrchestratorConfig:
    """Hard-bounded orchestration parameters suitable for a local 8 GB PC."""

    event_queue_capacity: int = 4096
    queue_health_watermark: float = 0.80
    startup_timeout_seconds: float = 20.0
    bootstrap_limit: int = 1000
    maintenance_interval_ms: int = 500
    recovery_retry_interval_ms: int = 1000
    flow_interval: str = "1s"
    flow_lookback_buckets: int = 5
    process_max_passes: int = 2
    records_per_pass: int = 2000
    aggregate_ingest_batch_size: int = 64

    def __post_init__(self) -> None:
        if isinstance(self.event_queue_capacity, bool) or not 1 <= self.event_queue_capacity <= 32768:
            raise ValueError("event_queue_capacity must be between 1 and 32768")
        if not 0.5 <= self.queue_health_watermark <= 0.95:
            raise ValueError("queue_health_watermark must be between 0.5 and 0.95")
        if not math.isfinite(self.startup_timeout_seconds) or not 0.1 <= self.startup_timeout_seconds <= 120:
            raise ValueError("startup_timeout_seconds must be between 0.1 and 120 seconds")
        if isinstance(self.bootstrap_limit, bool) or not 1 <= self.bootstrap_limit <= 1000:
            raise ValueError("bootstrap_limit must be between 1 and 1000")
        for name in ("maintenance_interval_ms", "recovery_retry_interval_ms", "flow_lookback_buckets"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.flow_interval not in {"1s", "5s", "15s", "1m", "5m"}:
            raise ValueError("flow_interval must be one of 1s, 5s, 15s, 1m, 5m")
        if isinstance(self.process_max_passes, bool) or not 1 <= self.process_max_passes <= 20:
            raise ValueError("process_max_passes must be between 1 and 20")
        if (
            isinstance(self.records_per_pass, bool)
            or not 1 <= self.records_per_pass <= MAX_PROCESS_BATCH
        ):
            raise ValueError(f"records_per_pass must be between 1 and {MAX_PROCESS_BATCH}")
        if (
            type(self.aggregate_ingest_batch_size) is not int
            or not 1 <= self.aggregate_ingest_batch_size <= MAX_AGG_TRADE_WRITE_BATCH
        ):
            raise ValueError(f"aggregate_ingest_batch_size must be between 1 and {MAX_AGG_TRADE_WRITE_BATCH}")


@dataclass(frozen=True, slots=True)
class MarketDataReadiness:
    """Immutable unified health/evidence contract for one exact contract symbol."""

    symbol: str
    status: str  # READY, DEGRADED, BOOTSTRAPPING, STOPPED
    ready: bool
    reason_codes: tuple[str, ...]
    aggregate_trade_connected: bool
    aggregate_trade_continuity: bool
    delta_cvd_ready: bool
    order_book_ready: bool
    queues_healthy: bool
    aggregate_trade_reconnect_generation: int
    depth_reconnect_generation: int
    aggregate_event_queue_depth: int
    aggregate_event_queue_capacity: int
    internal_queue_depth: int
    internal_queue_capacity: int
    order_book_health: OrderBookSymbolHealth | None
    flow: OrderFlowSnapshot | None
    evidence_status: str
    evidence: AbsorptionEvidence | None
    updated_at_ms: int


@dataclass(slots=True)
class _SymbolRuntime:
    symbol: str
    readiness: MarketDataReadiness | None = None
    last_source_status: str | None = None
    last_recovery_attempt_ms: int = 0
    last_evidence_fingerprint: tuple[int, int, int, int] | None = None
    last_error: str | None = None
    delta_cvd_process_failed: bool = False


class UnifiedMarketDataOrchestrator:
    """Coordinate bounded public feeds, recovery, Delta/CVD and evidence.

    The object is caller-managed. Construct the underlying clients/services,
    then run this service with an asyncio stop event. Public feed queues are
    drained independently from SQLite/recovery work. All synchronous database
    and REST-backed service calls execute in worker threads and are serialized
    behind one async lock.
    """

    def __init__(
        self,
        *,
        aggregate_feed: BinanceAggregateTradeWebSocketFeed,
        aggregate_recovery: AggregateTradeRecoveryService,
        delta_cvd: DeltaCvdService,
        order_book_supervisor: BinanceOrderBookSupervisor,
        evidence_service: DepthAggressorAlignmentService,
        aggregate_event_fanout: AggregateTradeEventFanout | None = None,
        config: MarketDataOrchestratorConfig | None = None,
        wall_clock_ms: Callable[[], int] | None = None,
    ) -> None:
        self.config = config or MarketDataOrchestratorConfig()
        self.aggregate_feed = aggregate_feed
        self.aggregate_recovery = aggregate_recovery
        self.delta_cvd = delta_cvd
        self.order_book_supervisor = order_book_supervisor
        self.evidence_service = evidence_service
        if aggregate_event_fanout is not None and not isinstance(
            aggregate_event_fanout, AggregateTradeEventFanout
        ):
            raise TypeError("aggregate_event_fanout must be an AggregateTradeEventFanout or None")
        self.aggregate_event_fanout = aggregate_event_fanout
        self._now_ms = wall_clock_ms or (lambda: time.time_ns() // 1_000_000)

        feed_symbols = tuple(getattr(aggregate_feed, "symbols", ()))
        depth_symbols = tuple(getattr(order_book_supervisor, "symbols", ()))
        normalized_feed_symbols = tuple(
            value.strip().upper() for value in feed_symbols
            if isinstance(value, str) and value.strip()
        )
        normalized_depth_symbols = tuple(
            value.strip().upper() for value in depth_symbols
            if isinstance(value, str) and value.strip()
        )
        if not normalized_feed_symbols or set(normalized_feed_symbols) != set(normalized_depth_symbols):
            raise ValueError("Aggregate Trade and order-book supervisors must use the same non-empty symbols")
        if len(normalized_feed_symbols) > 32:
            raise ValueError("The unified orchestrator supports at most 32 symbols")
        if len(set(normalized_feed_symbols)) != len(normalized_feed_symbols):
            raise ValueError("Aggregate Trade symbols must be unique")
        queue = getattr(aggregate_feed, "events", None)
        if queue is None or int(getattr(queue, "maxsize", 0)) <= 0:
            raise ValueError("Aggregate Trade feed must expose a bounded events queue")
        if not callable(getattr(aggregate_feed, "get_event", None)) or not callable(getattr(aggregate_feed, "run", None)):
            raise TypeError("Aggregate Trade feed must provide async run() and get_event()")
        if not callable(getattr(aggregate_recovery, "bootstrap_latest", None)):
            raise TypeError("aggregate_recovery must provide bootstrap_latest()")
        if not callable(getattr(delta_cvd, "snapshot", None)):
            raise TypeError("delta_cvd must provide snapshot()")
        if not callable(getattr(order_book_supervisor, "health", None)) or not callable(
            getattr(order_book_supervisor, "metrics", None)
        ):
            raise TypeError("order_book_supervisor must provide health() and metrics()")

        self.symbols = normalized_feed_symbols
        self._runtimes = {symbol: _SymbolRuntime(symbol) for symbol in self.symbols}
        self._events: asyncio.Queue[AggregateTradeEvent] = asyncio.Queue(
            maxsize=self.config.event_queue_capacity
        )
        self._database_lock = asyncio.Lock()
        self._running = False
        self._fatal_reason: str | None = None
        self._last_aggregate_connection_count: int | None = None
        self._last_depth_connection_count: int | None = None
        self._aggregate_reconnect_generation = 0
        self._depth_reconnect_generation = 0
        self._active_stop_event: asyncio.Event | None = None

    @property
    def is_ready(self) -> bool:
        return all(
            (snapshot := self.health(symbol)).ready and snapshot.status == "READY"
            for symbol in self.symbols
        )

    @property
    def is_running(self) -> bool:
        return self._running

    def health(self, symbol: str) -> MarketDataReadiness:
        runtime = self._state(symbol)
        if runtime.readiness is None:
            return self._not_initialized(runtime.symbol)
        return runtime.readiness

    def evidence(self, symbol: str) -> AbsorptionEvidence | None:
        return self.health(symbol).evidence

    async def run(self, stop_event: asyncio.Event) -> None:
        """Run all read-only market-data components until stopped or failed."""
        if not isinstance(stop_event, asyncio.Event):
            raise TypeError("stop_event must be an asyncio.Event")
        if self._running:
            raise RuntimeError("Unified market-data orchestrator is already running")
        self._running = True
        self._active_stop_event = stop_event
        tasks: dict[str, asyncio.Task] = {}
        try:
            tasks["aggregate_feed"] = asyncio.create_task(
                self.aggregate_feed.run(stop_event), name="unified-aggregate-trade-feed"
            )
            tasks["aggregate_collector"] = asyncio.create_task(
                self._collect_aggregate_events(stop_event), name="unified-aggregate-trade-collector"
            )
            tasks["order_book_supervisor"] = asyncio.create_task(
                self.order_book_supervisor.run(stop_event), name="unified-order-book-supervisor"
            )

            await self._wait_for_aggregate_connection(tasks, stop_event)
            self._last_aggregate_connection_count = self._connection_count(self.aggregate_feed)
            await self._bootstrap_symbols()
            self._observe_connection_generations()

            tasks["aggregate_worker"] = asyncio.create_task(
                self._process_aggregate_events(stop_event), name="unified-aggregate-trade-worker"
            )
            tasks["maintenance"] = asyncio.create_task(
                self._maintenance_loop(stop_event), name="unified-market-data-maintenance"
            )

            done, _ = await asyncio.wait(tuple(tasks.values()), return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                if task.cancelled():
                    continue
                error = task.exception()
                if error is not None:
                    raise MarketDataOrchestratorError(
                        f"{task.get_name()} terminated unexpectedly: {error}"
                    ) from error
                if not stop_event.is_set():
                    raise MarketDataOrchestratorError(
                        f"{task.get_name()} stopped before orchestrator shutdown"
                    )
        finally:
            stop_event.set()
            for task in tasks.values():
                if not task.done():
                    task.cancel()
            if tasks:
                await asyncio.gather(*tasks.values(), return_exceptions=True)
            for symbol in self.symbols:
                self._reset_evidence(symbol, "ORCHESTRATOR_STOPPED")
                self._publish_stopped(symbol)
            self._running = False
            self._active_stop_event = None

    async def _wait_for_aggregate_connection(
        self, tasks: dict[str, asyncio.Task], stop_event: asyncio.Event
    ) -> None:
        deadline = asyncio.get_running_loop().time() + self.config.startup_timeout_seconds
        while not stop_event.is_set():
            if bool(getattr(self.aggregate_feed, "is_connected", False)):
                return
            for name, task in tasks.items():
                if task.done():
                    error = task.exception() if not task.cancelled() else None
                    raise MarketDataStartupError(
                        f"{name} stopped before Aggregate Trade connection"
                    ) from error
            if asyncio.get_running_loop().time() >= deadline:
                raise MarketDataStartupError("Timed out waiting for initial Aggregate Trade WebSocket connection")
            await asyncio.sleep(0.02)
        raise MarketDataStartupError("Startup cancelled before Aggregate Trade connection")

    async def _bootstrap_symbols(self) -> None:
        """Create missing baselines only after feed connection and queue draining begin."""
        repository = self.aggregate_recovery.repository
        for symbol in self.symbols:
            async with self._database_lock:
                try:
                    await asyncio.to_thread(repository.get_stream_state, symbol)
                except AggregateTradeStreamStateError:
                    try:
                        await asyncio.to_thread(
                            self.aggregate_recovery.bootstrap_latest,
                            symbol=symbol,
                            limit=self.config.bootstrap_limit,
                        )
                    except Exception as exc:
                        self._runtimes[symbol].last_error = f"BOOTSTRAP_FAILED:{type(exc).__name__}"
                        raise MarketDataStartupError(
                            f"Could not establish Aggregate Trade baseline for {symbol}: {exc}"
                        ) from exc

    async def _collect_aggregate_events(self, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            try:
                event = await asyncio.wait_for(self.aggregate_feed.get_event(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            if event.symbol not in self._runtimes:
                self._fatal_reason = "UNCONFIGURED_AGGREGATE_TRADE_SYMBOL"
                stop_event.set()
                raise MarketDataOrchestratorError(
                    f"Received unconfigured Aggregate Trade symbol {event.symbol}"
                )
            if self._events.full():
                runtime = self._runtimes[event.symbol]
                runtime.last_error = "AGGREGATE_EVENT_QUEUE_OVERFLOW"
                self._reset_evidence(event.symbol, "AGGREGATE_EVENT_QUEUE_OVERFLOW")
                self._fatal_reason = "AGGREGATE_EVENT_QUEUE_OVERFLOW"
                stop_event.set()
                raise MarketDataQueueFullError(
                    f"Unified Aggregate Trade queue is full; event {event.aggregate_trade_id} was not accepted"
                )
            if self.aggregate_event_fanout is not None:
                try:
                    # Fan-out publish is synchronous/atomic across subscribers and
                    # runs before the durable-processing queue accepts this event.
                    self.aggregate_event_fanout.publish(event)
                except AggregateTradeFanoutQueueFullError as exc:
                    runtime = self._runtimes[event.symbol]
                    runtime.last_error = "STRATEGY_EVENT_FANOUT_OVERFLOW"
                    self._reset_evidence(event.symbol, "STRATEGY_EVENT_FANOUT_OVERFLOW")
                    self._fatal_reason = "STRATEGY_EVENT_FANOUT_OVERFLOW"
                    stop_event.set()
                    raise MarketDataQueueFullError(
                        "Strategy Aggregate Trade fan-out is full; the event was not accepted"
                    ) from exc
            # No await separates the queue precheck, fan-out and internal enqueue.
            # The internal collector is the sole producer for this queue.
            self._events.put_nowait(event)

    async def _process_aggregate_events(self, stop_event: asyncio.Event) -> None:
        ingest_many = getattr(self.aggregate_recovery, "ingest_websocket_events", None)
        # The live graph uses one symbol per worker. Keep shared multi-symbol
        # workers in receive order, with no cross-symbol transaction or prefetch.
        batch_size = (
            self.config.aggregate_ingest_batch_size
            if len(self.symbols) == 1 and callable(ingest_many) else 1
        )
        while not stop_event.is_set():
            try:
                event = await asyncio.wait_for(self._events.get(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            batch = [event]
            try:
                async with self._database_lock:
                    # Consume only what already arrived while the lock was
                    # occupied. A quiet feed does not wait to form a batch.
                    for _ in range(min(batch_size - 1, self._events.qsize())):
                        batch.append(self._events.get_nowait())
                    if len(batch) > 1:
                        state = await asyncio.to_thread(ingest_many, tuple(batch))
                    else:
                        state = await asyncio.to_thread(
                            self.aggregate_recovery.ingest_websocket_event, event
                        )
                runtime = self._runtimes[event.symbol]
                runtime.last_error = None
                if runtime.last_source_status is not None and runtime.last_source_status != state.status:
                    if state.status != "HEALTHY":
                        self._reset_evidence(event.symbol, f"AGGREGATE_TRADE_{state.status}")
                runtime.last_source_status = state.status
                if state.status != "HEALTHY" and runtime.readiness and runtime.readiness.delta_cvd_ready:
                    self._refresh_symbol(event.symbol, state=state, flow=runtime.readiness.flow)
            except Exception as exc:
                self._runtimes[event.symbol].last_error = f"AGGREGATE_INGEST_FAILED:{type(exc).__name__}"
                self._reset_evidence(event.symbol, "AGGREGATE_TRADE_INGEST_FAILED")
                stop_event.set()
                raise MarketDataOrchestratorError(
                    f"Aggregate Trade persistence failed for {event.symbol}: {exc}"
                ) from exc
            finally:
                for _ in batch:
                    self._events.task_done()

    async def _maintenance_loop(self, stop_event: asyncio.Event) -> None:
        interval = self.config.maintenance_interval_ms / 1000
        while not stop_event.is_set():
            self._observe_connection_generations()
            for symbol in self.symbols:
                if stop_event.is_set():
                    return
                await self._maintain_symbol(symbol)
            await self._refresh_all_symbols()
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=interval)
            except asyncio.TimeoutError:
                pass

    async def _maintain_symbol(self, symbol: str) -> None:
        runtime = self._runtimes[symbol]
        repository = self.aggregate_recovery.repository
        runtime.last_error = None
        flow_processed = False
        try:
            async with self._database_lock:
                try:
                    state: AggregateTradeStreamState = await asyncio.to_thread(
                        repository.get_stream_state, symbol
                    )
                except AggregateTradeStreamStateError:
                    runtime.last_error = "AGGREGATE_TRADE_BASELINE_MISSING"
                    self._reset_evidence(symbol, "AGGREGATE_TRADE_BASELINE_MISSING")
                    return

                now = self._now_ms()
                if state.status == "DEGRADED" and (
                    now - runtime.last_recovery_attempt_ms >= self.config.recovery_retry_interval_ms
                ):
                    runtime.last_recovery_attempt_ms = now
                    try:
                        await asyncio.to_thread(self.aggregate_recovery.recover_gap, symbol=symbol)
                    except Exception as exc:  # keep the symbol degraded; retry on the bounded cadence
                        runtime.last_error = f"AGGREGATE_RECOVERY_FAILED:{type(exc).__name__}"
                    state = await asyncio.to_thread(repository.get_stream_state, symbol)

                # The service consumes only the durable contiguous prefix. A
                # gap can keep the source degraded even while that prefix is
                # large enough for derived processing to catch up safely.
                if (
                    state.status in {"HEALTHY", "DEGRADED"}
                    and bool(getattr(self.aggregate_feed, "is_connected", False))
                ):
                    try:
                        await asyncio.to_thread(
                            self.delta_cvd.process_until_caught_up,
                            symbol=symbol,
                            max_passes=self.config.process_max_passes,
                            records_per_pass=self.config.records_per_pass,
                        )
                    except OrderFlowNotReady:
                        # No derived baseline/data yet; the next maintenance pass retries.
                        pass
                    except Exception:
                        runtime.delta_cvd_process_failed = True
                    else:
                        flow_processed = True
                try:
                    flow = await asyncio.to_thread(
                        self.delta_cvd.snapshot,
                        symbol=symbol,
                        interval=self.config.flow_interval,
                        lookback_buckets=self.config.flow_lookback_buckets,
                        now_ms=self._now_ms(),
                    )
                except (OrderFlowNotReady, KeyError):
                    flow = None
                except Exception as exc:
                    runtime.last_error = f"DELTA_CVD_SNAPSHOT_FAILED:{type(exc).__name__}"
                    flow = None
                if flow_processed and flow is not None:
                    runtime.delta_cvd_process_failed = False
        except Exception as exc:
            runtime.last_error = f"MARKET_DATA_MAINTENANCE_FAILED:{type(exc).__name__}"
            self._reset_evidence(symbol, "MARKET_DATA_MAINTENANCE_FAILED")
            return

        self._refresh_symbol(symbol, state=state, flow=flow)

    async def _refresh_all_symbols(self) -> None:
        # Depth health can change between aggregate maintenance passes. Refresh
        # against the last persisted/processed flow snapshot without reprocessing.
        for symbol in self.symbols:
            current = self._runtimes[symbol].readiness
            if current is None:
                continue
            self._refresh_symbol(symbol, flow=current.flow, state=None)

    def _refresh_symbol(
        self,
        symbol: str,
        *,
        state: AggregateTradeStreamState | None,
        flow: OrderFlowSnapshot | None,
    ) -> None:
        runtime = self._runtimes[symbol]
        now = self._now_ms()
        agg_connected = bool(getattr(self.aggregate_feed, "is_connected", False))
        agg_queue = getattr(self.aggregate_feed, "events", None)
        agg_qdepth = int(agg_queue.qsize()) if agg_queue is not None else 0
        agg_qcapacity = int(agg_queue.maxsize) if agg_queue is not None else 0
        internal_qdepth = self._events.qsize()
        internal_qcapacity = self._events.maxsize
        threshold = math.ceil(internal_qcapacity * self.config.queue_health_watermark)
        queues_healthy = (
            (not agg_qcapacity or agg_qdepth < math.ceil(agg_qcapacity * self.config.queue_health_watermark))
            and internal_qdepth < threshold
        )
        if state is None:
            continuity = runtime.last_source_status == "HEALTHY"
        else:
            continuity = state.status == "HEALTHY"
        flow_age_ms = None if flow is None or flow.last_trade_time_ms is None else now - flow.last_trade_time_ms
        flow_max_age = int(getattr(self.delta_cvd, "max_data_age_ms", 10_000))
        flow_future_skew = int(getattr(self.delta_cvd, "future_skew_ms", 5_000))
        flow_age_valid = (
            flow_age_ms is not None
            and -flow_future_skew <= flow_age_ms <= flow_max_age
        )
        flow_ready = bool(
            flow is not None
            and continuity
            and agg_connected
            and queues_healthy
            and not runtime.delta_cvd_process_failed
            and flow.status == "HEALTHY"
            and flow.continuity_valid
            and flow.is_fresh
            and flow_age_valid
            and flow.trade_count > 0
        )
        try:
            book_health = self.order_book_supervisor.health(symbol)
        except Exception as exc:
            book_health = None
            runtime.last_error = f"ORDER_BOOK_HEALTH_FAILED:{type(exc).__name__}"
        book_ready = bool(book_health and book_health.ready)
        reasons: list[str] = []
        if not agg_connected:
            reasons.append("AGGREGATE_TRADE_FEED_DISCONNECTED")
        if not continuity:
            reasons.append("AGGREGATE_TRADE_CONTINUITY_INVALID")
        if not flow_ready:
            reasons.append("DELTA_CVD_NOT_READY_OR_STALE")
        if runtime.delta_cvd_process_failed:
            reasons.append("DELTA_CVD_PROCESS_FAILED")
        if not book_ready:
            reasons.append("ORDER_BOOK_NOT_READY")
        if not queues_healthy:
            reasons.append("MARKET_DATA_QUEUE_BACKPRESSURE")
        if runtime.last_error or runtime.delta_cvd_process_failed:
            reasons.append("COMPONENT_ERROR")

        evidence: AbsorptionEvidence | None = None
        evidence_status = "UNAVAILABLE"
        sources_ready = not reasons
        if sources_ready:
            try:
                book = self.order_book_supervisor.metrics(symbol)
                assert flow is not None and book_health is not None
                fingerprint = (
                    flow.last_processed_aggregate_trade_id,
                    flow.last_trade_time_ms or 0,
                    book.update_id,
                    book.last_event_time_ms,
                )
                previous = runtime.readiness
                if runtime.last_evidence_fingerprint == fingerprint and previous is not None:
                    # Do not manufacture additional evidence samples by polling
                    # the same pair of source observations repeatedly.
                    evidence = previous.evidence
                    evidence_status = previous.evidence_status
                    if evidence_status == "UNAVAILABLE":
                        reasons.extend(previous.reason_codes)
                else:
                    evidence = self.evidence_service.observe(
                        symbol=symbol,
                        flow=flow,
                        book_health=book_health,
                        book=book,
                        observed_at_ms=now,
                    )
                    evidence_status = evidence.status
                    runtime.last_evidence_fingerprint = fingerprint
                    if evidence.status == "UNAVAILABLE":
                        reasons.extend(evidence.reason_codes)
            except OrderBookNotReady:
                reasons.append("ORDER_BOOK_BECAME_NOT_READY")
                self._reset_evidence(symbol, "ORDER_BOOK_BECAME_NOT_READY")
            except Exception as exc:
                reasons.append("EVIDENCE_ALIGNMENT_FAILED")
                runtime.last_error = f"EVIDENCE_ALIGNMENT_FAILED:{type(exc).__name__}"
                self._reset_evidence(symbol, "EVIDENCE_ALIGNMENT_FAILED")

        if not sources_ready or evidence_status == "UNAVAILABLE":
            if not sources_ready:
                self._reset_evidence(symbol, reasons[0] if reasons else "MARKET_DATA_NOT_READY")
            evidence = None
            evidence_status = "UNAVAILABLE"

        ready = sources_ready and evidence_status != "UNAVAILABLE"
        status = "READY" if ready else ("BOOTSTRAPPING" if not agg_connected and state is None else "DEGRADED")
        snapshot = MarketDataReadiness(
            symbol=symbol,
            status=status,
            ready=ready,
            reason_codes=tuple(dict.fromkeys(reasons)),
            aggregate_trade_connected=agg_connected,
            aggregate_trade_continuity=continuity,
            delta_cvd_ready=flow_ready,
            order_book_ready=book_ready,
            queues_healthy=queues_healthy,
            aggregate_trade_reconnect_generation=self._aggregate_reconnect_generation,
            depth_reconnect_generation=self._depth_reconnect_generation,
            aggregate_event_queue_depth=agg_qdepth,
            aggregate_event_queue_capacity=agg_qcapacity,
            internal_queue_depth=internal_qdepth,
            internal_queue_capacity=internal_qcapacity,
            order_book_health=book_health,
            flow=flow,
            evidence_status=evidence_status,
            evidence=evidence,
            updated_at_ms=now,
        )
        runtime.readiness = snapshot
        if state is not None:
            runtime.last_source_status = state.status

    def _observe_connection_generations(self) -> None:
        aggregate_count = self._connection_count(self.aggregate_feed)
        if aggregate_count > 0:
            if self._last_aggregate_connection_count is None:
                self._last_aggregate_connection_count = aggregate_count
                self._aggregate_reconnect_generation = max(0, aggregate_count - 1)
            elif aggregate_count > self._last_aggregate_connection_count:
                self._aggregate_reconnect_generation += aggregate_count - self._last_aggregate_connection_count
                self._last_aggregate_connection_count = aggregate_count
                for symbol in self.symbols:
                    self._reset_evidence(symbol, "AGGREGATE_TRADE_RECONNECTED")

        depth_feed = getattr(self.order_book_supervisor, "feed", None)
        depth_count = self._connection_count(depth_feed)
        if depth_count > 0:
            if self._last_depth_connection_count is None:
                self._last_depth_connection_count = depth_count
                self._depth_reconnect_generation = max(0, depth_count - 1)
            elif depth_count > self._last_depth_connection_count:
                self._depth_reconnect_generation += depth_count - self._last_depth_connection_count
                self._last_depth_connection_count = depth_count
                for symbol in self.symbols:
                    self._reset_evidence(symbol, "ORDER_BOOK_RECONNECTED")

    @staticmethod
    def _connection_count(feed: object | None) -> int:
        stats = getattr(feed, "stats", None)
        value = getattr(stats, "connection_count", 0)
        return int(value) if isinstance(value, int) and value >= 0 else 0

    def _reset_evidence(self, symbol: str, reason: str) -> None:
        if symbol in self._runtimes:
            self._runtimes[symbol].last_evidence_fingerprint = None
        try:
            self.evidence_service.reset_symbol(symbol, reason)
        except Exception:
            # Preserve the original data-path failure; readiness will stay blocked.
            pass

    def _state(self, symbol: str) -> _SymbolRuntime:
        if not isinstance(symbol, str):
            raise ValueError("symbol must be a string")
        normalized = symbol.strip().upper()
        try:
            return self._runtimes[normalized]
        except KeyError as exc:
            raise KeyError(f"Unconfigured market-data symbol: {normalized}") from exc

    def _not_initialized(self, symbol: str) -> MarketDataReadiness:
        return MarketDataReadiness(
            symbol=symbol,
            status="BOOTSTRAPPING",
            ready=False,
            reason_codes=("ORCHESTRATOR_NOT_STARTED",),
            aggregate_trade_connected=False,
            aggregate_trade_continuity=False,
            delta_cvd_ready=False,
            order_book_ready=False,
            queues_healthy=False,
            aggregate_trade_reconnect_generation=self._aggregate_reconnect_generation,
            depth_reconnect_generation=self._depth_reconnect_generation,
            aggregate_event_queue_depth=0,
            aggregate_event_queue_capacity=0,
            internal_queue_depth=self._events.qsize(),
            internal_queue_capacity=self._events.maxsize,
            order_book_health=None,
            flow=None,
            evidence_status="UNAVAILABLE",
            evidence=None,
            updated_at_ms=self._now_ms(),
        )

    def _publish_stopped(self, symbol: str) -> None:
        previous = self._runtimes[symbol].readiness
        self._runtimes[symbol].readiness = MarketDataReadiness(
            symbol=symbol,
            status="STOPPED",
            ready=False,
            reason_codes=("ORCHESTRATOR_STOPPED",),
            aggregate_trade_connected=False,
            aggregate_trade_continuity=False,
            delta_cvd_ready=False,
            order_book_ready=False,
            queues_healthy=False,
            aggregate_trade_reconnect_generation=self._aggregate_reconnect_generation,
            depth_reconnect_generation=self._depth_reconnect_generation,
            aggregate_event_queue_depth=0,
            aggregate_event_queue_capacity=0,
            internal_queue_depth=self._events.qsize(),
            internal_queue_capacity=self._events.maxsize,
            order_book_health=previous.order_book_health if previous else None,
            flow=None,
            evidence_status="UNAVAILABLE",
            evidence=None,
            updated_at_ms=self._now_ms(),
        )


__all__ = [
    "MarketDataOrchestratorError",
    "MarketDataQueueFullError",
    "MarketDataStartupError",
    "MarketDataOrchestratorConfig",
    "MarketDataReadiness",
    "UnifiedMarketDataOrchestrator",
]
