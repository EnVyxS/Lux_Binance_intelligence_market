from datetime import UTC, datetime, timedelta
from decimal import Decimal
from pathlib import Path

import pytest

from divatrading.core.database import Database
from divatrading.market_data.aggregate_trade_history import (
    AggregateTradeRecord,
    BinanceAggregateTradeHistoryService,
    parse_aggregate_trade_rest_row,
)
from divatrading.market_data.aggregate_trade_recovery import (
    AggregateTradeRecoveryRequired,
    AggregateTradeRecoveryService,
)
from divatrading.market_data.aggregate_trade_storage import AggregateTradeRepository
from divatrading.market_data.aggregate_trades import AggregateTradeEvent

NOW_MS = 1_800_000_000_000
NOW = datetime.fromtimestamp(NOW_MS / 1000, UTC)


def rest_row(agg_id: int, *, time_ms: int | None = None) -> dict:
    return {
        "a": agg_id, "p": "100.25", "q": "0.10", "nq": "0.09",
        "f": agg_id * 2, "l": agg_id * 2 + 1,
        "T": time_ms if time_ms is not None else NOW_MS - 60_000, "m": False,
    }


def ws_event(agg_id: int, *, time_ms: int | None = None) -> AggregateTradeEvent:
    timestamp = time_ms if time_ms is not None else NOW_MS - 60_000
    return AggregateTradeEvent(
        symbol="BTCUSDT", aggregate_trade_id=agg_id, price=Decimal("100.25"),
        quantity=Decimal("0.10"), first_trade_id=agg_id * 2,
        last_trade_id=agg_id * 2 + 1, event_time_ms=timestamp,
        trade_time_ms=timestamp, buyer_is_maker=False,
        source_endpoint="wss://fstream.binance.com/market/ws",
        stream_name="btcusdt@aggTrade", received_at_utc=NOW,
    )


class FakeClient:
    aggregate_trades_endpoint = "https://fapi.binance.com/fapi/v1/aggTrades"

    def __init__(self, pages):
        self.pages = pages
        self.calls = []

    def get_aggregate_trades(self, *, symbol, from_id=None, limit=1000):
        self.calls.append((symbol, from_id, limit))
        return self.pages.get(from_id, [])


@pytest.fixture
def setup(tmp_path: Path):
    db = Database(tmp_path / "state.db")
    db.initialize()
    repo = AggregateTradeRepository(db)
    return db, repo


def make_service(repo, pages, *, page_limit=1000, max_pages=3, now_ms=NOW_MS):
    client = FakeClient(pages)
    history = BinanceAggregateTradeHistoryService(
        client, page_limit=page_limit, max_pages_per_pass=max_pages,
        page_pause_seconds=0, sleep=lambda _: None,
        now=lambda: datetime.fromtimestamp(now_ms / 1000, UTC),
    )
    recovery = AggregateTradeRecoveryService(history, repo, now_ms=lambda: now_ms)
    return recovery, client


def seed_latest(repo):
    records = tuple(
        parse_aggregate_trade_rest_row(
            rest_row(agg_id), symbol="BTCUSDT", received_at_utc=NOW
        )
        for agg_id in (100, 101, 102)
    )
    return repo.bootstrap_latest(records)


def test_bootstrap_latest_establishes_healthy_baseline(setup):
    _, repo = setup
    service, _ = make_service(repo, {None: [rest_row(100), rest_row(101), rest_row(102)]})
    state = service.bootstrap_latest(symbol="btcusdt")
    assert state.status == "HEALTHY"
    assert state.last_contiguous_aggregate_trade_id == 102


def test_bootstrap_refuses_empty_history_page(setup):
    _, repo = setup
    service, _ = make_service(repo, {None: []})
    with pytest.raises(AggregateTradeRecoveryRequired, match="no recent aggregate trades"):
        service.bootstrap_latest(symbol="BTCUSDT")


def test_live_gap_is_persisted_and_rest_recovery_restores_continuity(setup):
    _, repo = setup
    seed_latest(repo)
    service, client = make_service(repo, {
        103: [rest_row(103), rest_row(104)],
    })
    state = service.ingest_websocket_event(ws_event(105))
    assert state.status == "DEGRADED"
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.complete is True
    assert result.status == "HEALTHY"
    assert result.records_recovered == 2
    assert client.calls == [("BTCUSDT", 103, 1000)]
    assert repo.get_stream_state("BTCUSDT").last_contiguous_aggregate_trade_id == 105
    assert [row.record.aggregate_trade_id for row in repo.read(symbol="BTCUSDT")] == [100, 101, 102, 103, 104, 105]


def test_batched_live_events_keep_the_same_durable_gap_and_recovery(setup):
    _, repo = setup
    seed_latest(repo)
    service, client = make_service(repo, {104: [rest_row(104), rest_row(105)]})
    state = service.ingest_websocket_events(ws_event(agg_id) for agg_id in (103, 105, 106))
    assert state.status == "DEGRADED"
    assert state.last_contiguous_aggregate_trade_id == 103
    assert state.latest_observed_aggregate_trade_id == 106
    assert service.recover_gap(symbol="BTCUSDT").complete
    assert client.calls == [("BTCUSDT", 104, 1000)]
    assert [row.record.aggregate_trade_id for row in repo.read(symbol="BTCUSDT")] == list(range(100, 107))


def test_recovery_is_idempotent_when_rest_and_websocket_overlap(setup):
    _, repo = setup
    seed_latest(repo)
    service, _ = make_service(repo, {103: [rest_row(103), rest_row(104)]})
    service.ingest_websocket_event(ws_event(105))
    assert service.recover_gap(symbol="BTCUSDT").complete is True
    assert service.ingest_websocket_event(ws_event(104)).status == "HEALTHY"
    assert len(repo.read(symbol="BTCUSDT")) == 6


def test_recovery_is_bounded_and_returns_resume_id(setup):
    _, repo = setup
    seed_latest(repo)
    pages = {
        103: [rest_row(103), rest_row(104)],
        105: [rest_row(105), rest_row(106)],
    }
    service, client = make_service(repo, pages, page_limit=2, max_pages=1)
    service.ingest_websocket_event(ws_event(107))
    first = service.recover_gap(symbol="BTCUSDT")
    assert first.complete is False
    assert first.next_from_id == 105
    assert first.records_recovered == 2
    second = service.recover_gap(symbol="BTCUSDT")
    assert second.complete is True
    assert second.status == "HEALTHY"
    assert client.calls == [("BTCUSDT", 103, 2), ("BTCUSDT", 105, 2)]


def test_empty_rest_response_marks_unavailable_history_unresolved(setup):
    _, repo = setup
    seed_latest(repo)
    service, _ = make_service(repo, {103: []})
    service.ingest_websocket_event(ws_event(105))
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.complete is False
    assert result.status == "UNRESOLVED"
    assert result.missing_id == 103
    assert repo.get_stream_state("BTCUSDT").status == "UNRESOLVED"


def test_api_retention_boundary_blocks_old_backfill_without_request(setup):
    _, repo = setup
    old_ms = NOW_MS - 49 * 60 * 60 * 1000
    seed = tuple(
        parse_aggregate_trade_rest_row(
            rest_row(agg_id, time_ms=old_ms), symbol="BTCUSDT", received_at_utc=NOW
        ) for agg_id in (100, 101, 102)
    )
    repo.bootstrap_latest(seed)
    service, client = make_service(repo, {})
    service.ingest_websocket_event(ws_event(105))
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    assert "history window" in result.reason
    assert client.calls == []


def test_explicit_from_id_can_be_recovered_without_guessing_a_time_anchor(setup):
    _, repo = setup
    repo.register_from_id(symbol="BTCUSDT", start_from_id=100)
    service, client = make_service(repo, {100: [rest_row(100), rest_row(101)]})
    service.ingest_websocket_event(ws_event(102))
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.status == "HEALTHY"
    assert result.complete is True
    assert client.calls == [("BTCUSDT", 100, 1000)]


def test_explicit_from_id_with_empty_rest_response_is_unresolved_history(setup):
    _, repo = setup
    repo.register_from_id(symbol="BTCUSDT", start_from_id=100)
    service, client = make_service(repo, {100: []})
    service.ingest_websocket_event(ws_event(102))
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    assert result.missing_id == 100
    assert client.calls == [("BTCUSDT", 100, 1000)]


def test_missing_id_in_rest_response_is_never_fabricated(setup):
    _, repo = setup
    seed_latest(repo)
    service, _ = make_service(repo, {103: [rest_row(103), rest_row(105)]})
    service.ingest_websocket_event(ws_event(106))
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.status == "UNRESOLVED"
    assert result.missing_id == 104
    ids = [row.record.aggregate_trade_id for row in repo.read(symbol="BTCUSDT")]
    assert ids == [100, 101, 102, 103, 106]


def test_healthy_stream_recovery_is_a_noop(setup):
    _, repo = setup
    seed_latest(repo)
    service, client = make_service(repo, {})
    result = service.recover_gap(symbol="BTCUSDT")
    assert result.complete is True
    assert result.records_recovered == 0
    assert client.calls == []


def test_recovery_requires_bootstrap_or_registered_stream(setup):
    _, repo = setup
    service, _ = make_service(repo, {})
    with pytest.raises(AggregateTradeRecoveryRequired, match="must be bootstrapped"):
        service.recover_gap(symbol="BTCUSDT")
