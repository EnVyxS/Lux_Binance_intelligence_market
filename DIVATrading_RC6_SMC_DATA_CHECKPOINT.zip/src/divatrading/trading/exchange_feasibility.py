"""Account-specific Binance USD-M leverage and fee feasibility.

All calculations are conservative estimates. They do not predict liquidation price
or replace exchange-side margin checks. This module never changes account settings.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable


def dec(value: Any, field: str) -> Decimal:
    try: out = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc: raise ValueError(f"invalid {field}") from exc
    if not out.is_finite() or out < 0: raise ValueError(f"invalid {field}")
    return out


@dataclass(frozen=True, slots=True)
class LeverageBracket:
    bracket: int
    initial_leverage: int
    notional_floor: Decimal
    notional_cap: Decimal
    maintenance_margin_ratio: Decimal
    cumulative: Decimal

    def maintenance_margin(self, notional: Decimal) -> Decimal:
        return max(Decimal("0"), notional * self.maintenance_margin_ratio - self.cumulative)


@dataclass(frozen=True, slots=True)
class SymbolCommission:
    maker_rate: Decimal
    taker_rate: Decimal

    @classmethod
    def from_binance(cls, payload: dict[str, Any]) -> "SymbolCommission":
        return cls(dec(payload.get("makerCommissionRate"), "makerCommissionRate"),
                   dec(payload.get("takerCommissionRate"), "takerCommissionRate"))

    def round_trip_reserve(self, notional: Decimal, *, entry_is_maker: bool = False,
                           exit_is_maker: bool = False, multiplier: Decimal = Decimal("1")) -> Decimal:
        if multiplier < 1: raise ValueError("fee reserve multiplier must be >= 1")
        entry_rate = self.maker_rate if entry_is_maker else self.taker_rate
        exit_rate = self.maker_rate if exit_is_maker else self.taker_rate
        return notional * (entry_rate + exit_rate) * multiplier



@dataclass(frozen=True, slots=True)
class SymbolRiskInputs:
    """Fresh account-specific inputs required before a non-PAPER entry."""
    symbol: str
    brackets: tuple[LeverageBracket, ...]
    commission: SymbolCommission
    captured_at_ms: int

    def __post_init__(self) -> None:
        if not self.symbol or self.symbol != self.symbol.strip().upper():
            raise ValueError("risk input symbol must be normalized uppercase")
        if not self.brackets:
            raise ValueError("account leverage brackets are required")
        if (isinstance(self.captured_at_ms, bool) or not isinstance(self.captured_at_ms, int)
                or self.captured_at_ms <= 0):
            raise ValueError("captured_at_ms must be a positive integer")
        if not isinstance(self.commission, SymbolCommission):
            raise TypeError("commission must be a SymbolCommission")

def parse_leverage_brackets(payload: Iterable[dict[str, Any]], symbol: str) -> tuple[LeverageBracket, ...]:
    symbol = symbol.upper()
    rows = [row for row in payload if str(row.get("symbol", "")).upper() == symbol]
    if len(rows) != 1: raise ValueError(f"expected exactly one account leverage bracket row for {symbol}")
    raw = rows[0].get("brackets")
    if not isinstance(raw, list) or not raw: raise ValueError("leverage bracket tiers missing")
    tiers = []
    for item in raw:
        lev = int(item["initialLeverage"])
        if not 1 <= lev <= 125: raise ValueError("exchange leverage tier out of range")
        tiers.append(LeverageBracket(int(item["bracket"]), lev,
            dec(item["notionalFloor"], "notionalFloor"), dec(item["notionalCap"], "notionalCap"),
            dec(item["maintMarginRatio"], "maintMarginRatio"), dec(item.get("cum", "0"), "cum")))
    tiers.sort(key=lambda x: x.notional_floor)
    for i, tier in enumerate(tiers):
        if tier.notional_cap <= tier.notional_floor: raise ValueError("invalid notional bracket bounds")
        if i and tier.notional_floor > tiers[i-1].notional_cap: raise ValueError("gap in notional leverage brackets")
    return tuple(tiers)


@dataclass(frozen=True, slots=True)
class FeasibilityDecision:
    accepted: bool
    leverage: int | None
    initial_margin_estimate: Decimal | None
    maintenance_margin_estimate: Decimal | None
    fee_reserve: Decimal | None
    total_required_margin: Decimal | None
    reason: str
    liquidation_price_estimated: bool = False


def assess_margin_feasibility(*, notional: Decimal, available_margin: Decimal,
        brackets: tuple[LeverageBracket, ...], commission: SymbolCommission,
        max_leverage: int, slippage_reserve: Decimal = Decimal("0"),
        funding_reserve: Decimal = Decimal("0"), fee_multiplier: Decimal = Decimal("1.2"),
        fixed_leverage: int | None = None) -> FeasibilityDecision:
    if notional <= 0 or available_margin <= 0 or not brackets or not 1 <= max_leverage <= 125:
        return FeasibilityDecision(False, None, None, None, None, None, "INVALID_FEASIBILITY_INPUT")
    tier = next((b for b in brackets if b.notional_floor <= notional <= b.notional_cap), None)
    if tier is None: return FeasibilityDecision(False, None, None, None, None, None, "NOTIONAL_OUTSIDE_ACCOUNT_BRACKETS")
    leverage_cap = min(max_leverage, tier.initial_leverage)
    if min(slippage_reserve, funding_reserve) < 0 or fee_multiplier < 1:
        return FeasibilityDecision(False, None, None, None, None, None, "INVALID_RESERVE_INPUT")
    if fixed_leverage is not None and (isinstance(fixed_leverage, bool)
                                       or not 1 <= fixed_leverage <= leverage_cap):
        return FeasibilityDecision(False, None, None, None, None, None, "FIXED_LEVERAGE_EXCEEDS_BRACKET")
    fees = commission.round_trip_reserve(notional, multiplier=fee_multiplier)
    reserves = slippage_reserve + funding_reserve
    maintenance = tier.maintenance_margin(notional)
    # The smallest leverage that fits the configured margin envelope gives a
    # larger buffer than blindly using the maximum bracket leverage.
    candidates = (fixed_leverage,) if fixed_leverage is not None else range(1, leverage_cap + 1)
    for lev in candidates:
        initial = notional / Decimal(lev)
        total = initial + fees + reserves
        if total <= available_margin:
            return FeasibilityDecision(True, lev, initial, maintenance, fees, total, "MARGIN_FEASIBLE_ESTIMATE")
    initial = notional / Decimal(leverage_cap)
    return FeasibilityDecision(False, leverage_cap, initial, maintenance, fees,
                               initial + fees + reserves, "INSUFFICIENT_AVAILABLE_MARGIN")
